# Covariance and Correlation changes

## 1.1.0 — dev097

- Public CORE statistical interpretation and persisted result records.
- Reconciled module, package and current producer identities for this release.

## 1.0.1 — 2026-09-28

- Classified the independently packaged module as a managed external plugin.

## 1.0.0 — development candidate

- Added pairwise covariance, Pearson and Spearman analysis with explicit
  pairwise/listwise missing data, unit-aware covariance, stable Dataset
  bindings, published pair table and a public Plot Dataset heatmap.
