# Test Results — GX-TXT Geospatial Examples 1.0.0

Baseline: GX-TXT 0.9.7.77.

## Executed in the build environment

- PASS — source-bundle SHA-256 verification for every listed bundled source resource.
- PASS — deterministic normalized cartographic grid: 68 × 80 = 5,440 unique 1 km cells.
- PASS — EPSG:25832/local-coordinate reversibility against the fixed origin.
- PASS — finite terrain values, non-negative population and distance-to-Ticino values.
- PASS — CLC fractions constrained to 0…1 using documented source-class mappings.
- PASS — ordered river chainage and 443 deterministic river samples.
- PASS — 573 deterministic ISTAT locality records selected by documented rules.
- PASS — 560 deterministic synthetic hydraulic samples, non-negative depth/velocity, and `water_surface = bed + depth` within serialized floating-point tolerance.
- PASS — GX-TXT Session Generator Library API v1 import on GX-TXT 0.9.7.77.
- PASS — generator discovery as `Environmental / Cartography → Ticino Valley 3D Cartography`.
- PASS — two independently generated Sessions produced byte-identical CSV and metadata resources.

## Not applicable to this package

GNU Octave rendering is a plugin responsibility and is not executed by the Session Generator Library test.

The optional external historical hydrological-observation subset remains SKIP because the acquisition bundle did not establish a suitable redistributable ARPA/SIDRO subset. The synthetic hydraulic demonstration does not depend on it.
