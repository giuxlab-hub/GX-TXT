#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, math, sys
import pandas as pd
import numpy as np
root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1])
g=root/'generators'/'ticino_valley_3d'
t=g/'template'
def fail(m): raise SystemExit('FAIL '+m)
def check(c,m):
    if not c: fail(m)
check((root/'session-generator-library.ini').is_file(),'library descriptor missing')
check((g/'generator.ini').is_file(),'generator descriptor missing')
for f in ['README.md','reference/SOURCES.md','reference/ATTRIBUTIONS.md','reference/NORMALIZATION.md','reference/SOURCE_BUNDLE_VALIDATION.md','reference/source_bundle_manifest.tsv']:
    check((t/f).is_file(),f'missing template/{f}')
expected={
 'ticino_valley_grid.csv':'d19726af82fbee408f7be33e644ac2b5aaf82c8ea9b3720a964c44576aab8343',
 'ticino_valley_settlements.csv':'2bc59dd5eaa76b7fcc224994dc0bad92b030b88aec03e24aa79a537aeb205bee',
 'ticino_river_centerline.csv':'e55291f82bd3f11f1cc8220a5a9ba0055dc50ef6d1ab9eae23a912cfa3157f0f',
 'ticino_hydraulic_demo.csv':'a51462a88b8e2bfd240c4d3ef9b2f9030a0b3ee34f1d93a6637df1fa505e11e9',
}
for f,h in expected.items():
    p=t/'raw'/f; check(p.is_file(),f'missing {f}'); check(hashlib.sha256(p.read_bytes()).hexdigest()==h,f'{f} hash mismatch')

grid=pd.read_csv(t/'raw'/'ticino_valley_grid.csv')
check(len(grid)==5440,'grid row count')
check(grid.grid_id.nunique()==5440,'grid IDs unique')
check(grid[['grid_i','grid_j']].drop_duplicates().shape[0]==5440,'duplicate grid cells')
check(sorted(grid.grid_i.unique())==list(range(68)),'grid_i range')
check(sorted(grid.grid_j.unique())==list(range(80)),'grid_j range')
check(np.allclose(grid.x_km,(grid.easting_m-458000)/1000,rtol=0,atol=1e-10),'x_km reversibility')
check(np.allclose(grid.y_km,(grid.northing_m-4995000)/1000,rtol=0,atol=1e-10),'y_km reversibility')
for c in ['elevation_m','min_elevation_m','max_elevation_m','population','population_density_km2','built_fraction','forest_fraction','agriculture_fraction','water_fraction','distance_to_ticino_km']:
    check(np.isfinite(grid[c]).all(),f'nonfinite {c}')
check((grid.population>=0).all(),'negative population')
for c in ['built_fraction','forest_fraction','agriculture_fraction','water_fraction','other_land_fraction']:
    check(((grid[c]>=-1e-12)&(grid[c]<=1+1e-9)).all(),f'invalid fraction {c}')
check((grid[['built_fraction','forest_fraction','agriculture_fraction','water_fraction','other_land_fraction']].sum(axis=1)<=1.00001).all(),'land-cover fractions sum >1')
check(set(grid.in_study_corridor.unique())<= {0,1},'corridor mask not binary')
check(int(grid.in_study_corridor.sum())==3578,'corridor cell count')
check((grid.distance_to_ticino_km>=0).all(),'negative distance')

sett=pd.read_csv(t/'raw'/'ticino_valley_settlements.csv')
check(len(sett)==573,'settlement count')
check(sett.settlement_id.nunique()==len(sett),'settlement IDs unique')
check(set(sett.settlement_class.unique())<= {'inhabited_centre','inhabited_nucleus'},'settlement classes')
check((sett.population>=50).all(),'settlement population selection')
check((sett.distance_to_ticino_km<=20+1e-9).all(),'settlement corridor selection')
check(sett.name.notna().all(),'settlement names missing')

river=pd.read_csv(t/'raw'/'ticino_river_centerline.csv')
check(len(river)==443,'river point count')
check(river.river_point_id.nunique()==len(river),'river IDs unique')
check(np.all(np.diff(river.chainage_km.to_numpy())>0),'river chainage not strictly increasing')
check(abs(river.chainage_km.iloc[0])<1e-12,'river chainage start')
check(abs(river.chainage_km.iloc[-1]-110.2677263)<1e-6,'river chainage end')
check(np.isfinite(river.terrain_or_bed_reference_elevation_m).all(),'river terrain nonfinite')

hyd=pd.read_csv(t/'raw'/'ticino_hydraulic_demo.csv')
check(len(hyd)==560,'hydraulic point count')
check(hyd.hydro_cell_id.nunique()==len(hyd),'hydraulic IDs unique')
check((hyd.water_depth_m>=0).all(),'negative hydraulic depth')
check((hyd.velocity_m_s>=0).all(),'negative hydraulic velocity')
check(np.isfinite(hyd[['bed_elevation_m','water_surface_elevation_m','water_depth_m','velocity_m_s']]).all().all(),'nonfinite hydraulics')
check(np.allclose(hyd.water_surface_elevation_m,hyd.bed_elevation_m+hyd.water_depth_m,rtol=0,atol=2e-8),'water surface != bed + depth')
check(hyd.chainage_km.nunique()==112,'hydraulic station count')
check(set(np.round(hyd.lateral_offset_m).astype(int).unique())=={-400,-200,0,200,400},'hydraulic lateral offsets')
w=hyd.groupby('chainage_km',sort=True).water_surface_elevation_m.first()
check(abs((w.iloc[0]-w.iloc[-1])-142.5)<1e-6,'hydraulic synthetic water-surface drop')
for f in ['ticino_valley.metadata.txt','ticino_valley_grid.metadata.txt','ticino_valley_settlements.metadata.txt','ticino_river_centerline.metadata.txt','ticino_hydraulic_demo.metadata.txt']:
    p=t/'metadata'/f; check(p.is_file(),f'missing metadata {f}'); txt=p.read_text(encoding='utf-8'); check('geospatial.crs=EPSG:25832' in txt,f'CRS metadata missing {f}')
check('data.hydraulics.synthetic=true' in (t/'metadata'/'ticino_hydraulic_demo.metadata.txt').read_text(encoding='utf-8'),'synthetic hydraulic flag missing')
print('PASS geospatial Session Generator normalized resources, provenance, grid, river, settlements and hydraulic invariants')
