#!/usr/bin/env tclsh
# GX-TXT 0.9.7.77 integration test for GX-TXT Geospatial Examples.
# SPDX-License-Identifier: GPL-3.0-or-later
proc fail {m} {puts stderr "FAIL $m";exit 1}
proc check {c m} {if {![uplevel 1 [list expr $c]]} {fail $m}}
if {![info exists ::env(GXTXT_ROOT)] || ![info exists ::env(GEOSPATIAL_GENERATOR_PACKAGE)]} {fail "GXTXT_ROOT and GEOSPATIAL_GENERATOR_PACKAGE are required"}
set root [file normalize $::env(GXTXT_ROOT)]
set package [file normalize $::env(GEOSPATIAL_GENERATOR_PACKAGE)]
set tmp [file normalize [file join /tmp gxtxt_geospatial_generator_[pid]]]
file delete -force -- $tmp;file mkdir $tmp
set ::env(XDG_CONFIG_HOME) [file join $tmp config]
set ::env(XDG_DATA_HOME) [file join $tmp data]
set ::env(HOME) [file join $tmp home]
cd $root;set argv0 __not_main__;source [file join $root gxtxt_pipeline.tcl];::GX::defaults
check {[string trim $::GX::version] eq "0.9.7.77"} "wrong framework version"
set info [::GX::sessionGeneratorInstallLibrary $package]
check {[dict get $info library_id] eq "org.giuxlab.gxtxt.geospatial_examples"} "library identity mismatch"
set gens [::GX::sessionGeneratorListGenerators org.giuxlab.gxtxt.geospatial_examples]
set found 0;foreach g $gens {if {[dict get $g generator_id] eq "ticino_valley_3d"} {set found 1}}
check {$found} "generator discovery failed"
set ::GX::cfg(output_root) [file join $tmp sessions]
set s1 [::GX::sessionGeneratorGenerate org.giuxlab.gxtxt.geospatial_examples ticino_valley_3d $::GX::cfg(output_root) ticino-valley-3d-a]
set s2 [::GX::sessionGeneratorGenerate org.giuxlab.gxtxt.geospatial_examples ticino_valley_3d $::GX::cfg(output_root) ticino-valley-3d-b]
foreach f {ticino_valley_grid.csv ticino_valley_settlements.csv ticino_river_centerline.csv ticino_hydraulic_demo.csv} {
  set a [file join $s1 raw $f];set b [file join $s2 raw $f]
  check {[file isfile $a] && [file isfile $b]} "generated file missing: $f"
  check {[::GX::sha256File $a] eq [::GX::sha256File $b]} "non-deterministic generated file: $f"
}
foreach f {ticino_valley.metadata.txt ticino_valley_grid.metadata.txt ticino_valley_settlements.metadata.txt ticino_river_centerline.metadata.txt ticino_hydraulic_demo.metadata.txt} {check {[file isfile [file join $s1 metadata $f]]} "metadata missing: $f"}
check {[file isfile [file join $s1 metadata session_generator.ini]]} "Session Generator provenance missing"
check {[file isfile [file join $s1 reference SOURCES.md]]} "source provenance missing"
check {[file isfile [file join $s1 reference ATTRIBUTIONS.md]]} "attribution missing"
file delete -force -- $tmp
puts "PASS GX-TXT 0.9.7.77 geospatial Session Generator library import and deterministic generation"
