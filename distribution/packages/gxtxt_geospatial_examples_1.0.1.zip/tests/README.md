# Tests

Run the static resource test:

```text
python3 tests/test_static.py .
```

Run the GX-TXT Session Generator Library API integration test against GX-TXT 0.9.7.77:

```text
GXTXT_ROOT=<GX-TXT_0.9.7.77_ROOT> \
GEOSPATIAL_GENERATOR_PACKAGE=<gxtxt_geospatial_examples_1.0.0.zip> \
tclsh tests/test_library_integration.tcl
```
