# Changelog

## 1.0.0 - 2026-09-23

- Added the `GX-TXT Geospatial Examples` Session Generator Library.
- Added `Environmental / Cartography / Ticino Valley 3D Cartography`.
- Added an offline deterministic 1 km EPSG:25832 cartographic grid derived from Copernicus DEM GLO-30, ISTAT 2021 population grid and CORINE Land Cover 2018.
- Added a representative ISTAT 2021 settlement subset and an ordered Ticino route derived from Regione Lombardia RIRU.
- Added a clearly identified deterministic synthetic hydraulic ribbon for 3D visualization only.
- Added portable Dataset Metadata files, provenance, attribution and normalization documentation.
