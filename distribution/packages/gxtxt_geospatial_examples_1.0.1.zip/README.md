# GX-TXT Geospatial Examples

External Session Generator Library for GX-TXT 0.9.7.77 or newer.

The `Ticino Valley 3D Cartography` generator creates a normal offline GX-TXT Session containing normalized public cartographic data for the Italian sublacual Ticino valley plus a clearly identified synthetic hydraulic visualization field.

The library contains no live network dependency. Source acquisition and one-time geospatial preprocessing are documented inside the generator package.

License: GNU GPL v3 for generator/package code and documentation. Bundled derived public data retain the source attribution and license obligations documented in the generated Session under `reference/`.
