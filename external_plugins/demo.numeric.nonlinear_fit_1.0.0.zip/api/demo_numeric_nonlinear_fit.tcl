# Public-API adapter for the generated Nonlinear Fitting Session and plot.dataset.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::DemoNumericNonlinearFit {}

proc ::DemoNumericNonlinearFit::prepareSource {session} {
    set sourceId demo.nonlinear.source
    if {[::GX::datasetField $sourceId kind ""] ne ""} { return $sourceId }
    set raw [file join $session raw nonlinear_fitting.csv]
    set truth [file join $session metadata ground_truth.txt]
    if {![file isfile $raw] || ![file isfile $truth]} { error "Nonlinear generator Session source/truth missing" }
    set fd [open $raw r]
    set header [gets $fd]
    if {$header ne "x,y"} { close $fd; error "Expected generated x,y CSV" }
    set xs {}; set ys {}
    while {[gets $fd line] >= 0} {
        if {[string trim $line] eq ""} continue
        set values [split $line ,]
        if {[llength $values] != 2} { close $fd; error "Malformed generated source row" }
        foreach value $values { if {![string is double -strict $value]} { close $fd; error "Non-numeric generated source row" } }
        lappend xs [lindex $values 0]
        lappend ys [lindex $values 1]
    }
    close $fd
    if {[llength $xs] < 10} { error "Insufficient nonlinear source rows" }
    set refs [dict create]
    set fd [open $truth r]
    while {[gets $fd line] >= 0} {
        if {[regexp {^(A|k|c)=([^=]+)$} $line -> name value]} {
            if {![string is double -strict $value]} { close $fd; error "Invalid reference $name" }
            dict set refs reference.$name $value
        }
    }
    close $fd
    foreach key {reference.A reference.k reference.c} { if {![dict exists $refs $key]} { error "Missing $key" } }
    set definition [dict create dataset_id $sourceId contract timeseries.table storage csv producer_version 1.0.0 \
        source [file join raw nonlinear_fitting.csv] provenance "Generated Nonlinear Fitting Session source imported through Dataset Publication API v2"]
    set plan [::GX::datasetPublicationV2Prepare $session demo.numeric.nonlinear_fit $definition]
    set writer [::GX::datasetPublicationV2OpenWriter $plan]
    if {[catch {
        ::GX::datasetPublicationV2DeclareDimension $writer row 0 [dict create extendible 1]
        ::GX::datasetPublicationV2DeclareVariable $writer x [dict create name x unit {} dtype float64 dimension_ids row semantic_role independent coordinate_role coordinate]
        ::GX::datasetPublicationV2DeclareVariable $writer y [dict create name y unit {} dtype float64 dimension_ids row semantic_role measured coordinate_variable_ids x]
        ::GX::datasetPublicationV2Append $writer row [dict create x $xs y $ys]
        ::GX::datasetPublicationV2Finalize $writer
    } issue options]} {
        catch {::GX::datasetPublicationV2Abort $writer}
        return -options $options $issue
    }
    ::GX::datasetMetadataUpdate $session $sourceId $refs
    return $sourceId
}

proc ::DemoNumericNonlinearFit::plotResult {session} {
    set plotDescriptor [::GX::moduleField plot.dataset descriptor ""]
    if {$plotDescriptor eq ""} { error "plot.dataset unavailable" }
    set description [::GX::parseIni $plotDescriptor]
    set entry [::GX::descriptorValue $description public_api.PLOT_DATASET_API_v2 entrypoint ""]
    if {$entry eq ""} { error "PLOT_DATASET_API_v2 unavailable" }
    source [file join [file dirname $plotDescriptor] $entry]
    set spec [::GX::PlotDatasetAPIv2::newSpec -title "Nonlinear example: measured data and exponential fit"]
    set panel [lindex [dict get $spec panels] 0]
    dict set panel axes x [dict create label "X"]
    dict set panel axes y_left [dict create label "Y"]
    dict set panel series [list \
        [dict create id measured dataset_id demo.nonlinear.fit x_variable_id x y_variable_id measured axis left kind scatter label "Generated observations" style [dict create marker circle]] \
        [dict create id fitted dataset_id demo.nonlinear.fit x_variable_id x y_variable_id fitted axis left kind line label "Exponential least-squares fit" style [dict create line_width 2]]]
    dict set spec panels [list $panel]
    set ref [::GX::PlotDatasetAPIv2::createPlotFromSpec $spec base]
    set rendered [::GX::PlotDatasetAPIv2::render $ref]
    set artifact [dict get [dict get $rendered artifacts] graph_artifact]
    if {![file isfile $artifact]} { error "plot.dataset did not render graph" }
    return [dict create ref $ref artifact $artifact]
}
