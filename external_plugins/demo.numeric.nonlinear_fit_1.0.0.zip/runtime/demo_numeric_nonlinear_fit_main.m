function demo_numeric_nonlinear_fit_main(args)
% Fit a canonical Dataset with the public NUMERIC_API_v1 and publish through v2.
% SPDX-License-Identifier: GPL-3.0-or-later
  config_path=arg_value(args,'--config','');
  if(isempty(config_path)), error('demo.numeric.nonlinear_fit: --config is required'); endif
  cfg=gxtxt_ini_read(config_path);
  session=strtrim(gxtxt_ini_get(cfg,'runtime.session',''));
  outdir=strtrim(gxtxt_ini_get(cfg,'runtime.output_dir',''));
  source_id=strtrim(gxtxt_ini_get(cfg,'analysis_source.primary.dataset_id',''));
  if(isempty(session)||isempty(outdir)||isempty(source_id)), error('demo.numeric.nonlinear_fit: runtime source/session/output missing'); endif
  if(exist(outdir,'dir')!=7), mkdir(outdir); endif
  expected=zeros(1,3); names={'A','k','c'};
  for i=1:3
    [value,found]=gxtxt_analysis_source_dataset_metadata_get(cfg,'primary',['reference.' names{i}]);
    if(!found), error('demo.numeric.nonlinear_fit: missing source reference.%s',names{i}); endif
    expected(i)=str2double(value);
  endfor
  if(any(!isfinite(expected))), error('demo.numeric.nonlinear_fit: invalid reference parameters'); endif
  model=@(p,x) p(1).*exp(-p(2).*x)+p(3);
  opts=struct('solver','auto','max_iterations',500,'tolerance',1e-9);
  result=gxtxt_numeric_v1('dataset_nonlinear_fit',session,source_id,'x','y',model,[4;0.5;0.2],opts);
  recovered=result.parameters(:).';
  tolerance=[0.10,0.05,0.08];
  errors=abs(recovered-expected);
  if(any(!isfinite(recovered))||any(errors>tolerance))
    error('demo.numeric.nonlinear_fit: fit outside reference tolerances: errors=%s tolerances=%s',mat2str(errors),mat2str(tolerance));
  endif
  % Table Stream v3 supplies the source X/Y; no provider-private file is opened.
  stream=gxtxt_table_stream_open_dataset(session,source_id,{'x','y'},4096,struct('start',0,'count',-1,'require_direct',false,'numeric_transport','auto'));
  x=[]; measured=[];
  unwind_protect
    while(!stream.eof)
      [stream,chunk]=gxtxt_table_stream_next(stream);
      if(chunk.nrows>0), x=[x;double(chunk.values{1}(:))]; measured=[measured;double(chunk.values{2}(:))]; endif
    endwhile
  unwind_protect_cleanup
    stream=gxtxt_table_stream_close(stream);
  end_unwind_protect
  if(numel(x)!=numel(result.predicted)), error('demo.numeric.nonlinear_fit: fitted/source length mismatch'); endif
  pub_id='demo.nonlinear.fit';
  options=struct('storage','csv','producer_version','1.0.0','source_dataset_ids',source_id, ...
                 'source_variable_ids','x;y','provenance','NUMERIC_API_v1 dataset_nonlinear_fit', ...
                 'replace_owned',true);
  P=gxtxt_publication_v2_open(session,'demo.numeric.nonlinear_fit',pub_id,'timeseries.table',options);
  complete=false;
  unwind_protect
    P=gxtxt_publication_v2_declare_dimension(P,'row',0,true);
    P=gxtxt_publication_v2_declare_variable(P,'x',struct('name','x','unit',result.x_unit,'dtype','float64','dimension_ids','row','semantic_role','independent','coordinate_role','coordinate'));
    P=gxtxt_publication_v2_declare_variable(P,'measured',struct('name','measured','unit',result.y_unit,'dtype','float64','dimension_ids','row','semantic_role','measured','coordinate_variable_ids','x'));
    P=gxtxt_publication_v2_declare_variable(P,'fitted',struct('name','fitted','unit',result.y_unit,'dtype','float64','dimension_ids','row','semantic_role','fitted','coordinate_variable_ids','x'));
    P=gxtxt_publication_v2_append(P,'row',{'x',x;'measured',measured;'fitted',result.predicted(:)});
    [P,published]=gxtxt_publication_v2_finalize(P); complete=true;
  unwind_protect_cleanup
    if(!complete), try P=gxtxt_publication_v2_abort(P); catch; end_try_catch, endif
  end_unwind_protect
  metric_path=fullfile(outdir,'fit_metrics.ini'); fid=fopen(metric_path,'w');
  if(fid<0), error('demo.numeric.nonlinear_fit: cannot write metrics'); endif
  fprintf(fid,'[fit]\nsource_dataset_id=%s\nderived_dataset_id=%s\nmodel=y=A*exp(-k*x)+c\n',source_id,pub_id);
  for i=1:3, fprintf(fid,'expected_%s=%.15g\nrecovered_%s=%.15g\nabsolute_error_%s=%.15g\ntolerance_%s=%.15g\n',names{i},expected(i),names{i},recovered(i),names{i},errors(i),names{i},tolerance(i)); endfor
  fprintf(fid,'solver=%s\nconverged=%d\nsse=%.15g\nrmse=%.15g\nr_squared=%.15g\n',result.solver,result.converged,result.sse,result.rmse,result.r_squared);
  fclose(fid);
  report_path=fullfile(outdir,'fit_report.txt'); fid=fopen(report_path,'w');
  if(fid<0), error('demo.numeric.nonlinear_fit: cannot write report'); endif
  fprintf(fid,'Nonlinear fitting: y = A*exp(-k*x) + c\nSource Dataset: %s\nDerived Dataset: %s\n',source_id,pub_id);
  for i=1:3, fprintf(fid,'%s: expected %.9g; recovered %.9g; absolute error %.9g; tolerance %.9g\n',names{i},expected(i),recovered(i),errors(i),tolerance(i)); endfor
  fprintf(fid,'Solver: %s; SSE: %.9g; RMSE: %.9g; R-squared: %.9g\n',result.solver,result.sse,result.rmse,result.r_squared);
  fclose(fid);
  fprintf('PASS demo.numeric.nonlinear_fit: A=%.9g k=%.9g c=%.9g, derived=%s\n',recovered,pub_id);
endfunction

function value=arg_value(args,name,default_value)
  value=default_value;
  for i=1:(numel(args)-1), if(strcmp(args{i},name)), value=args{i+1}; return; endif, endfor
endfunction
