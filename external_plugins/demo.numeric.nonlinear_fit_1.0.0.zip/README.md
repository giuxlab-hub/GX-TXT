# Nonlinear fit integration demo

This is one external GX-TXT module, installable with Plugin Install API v1. It
consumes the generated `GX-TXT Numerical Examples / Nonlinear Fitting` Session.
The generated CSV is imported once as a canonical source Dataset through Dataset
Publication API v2 by `api/demo_numeric_nonlinear_fit.tcl`; reference parameters
are attached through Dataset Metadata API v1. The standard Octave module obtains
the source through Analysis Source, calls `math.numeric`'s advertised
`NUMERIC_API_v1` `dataset_nonlinear_fit`, checks reference tolerances, and
publishes the measured/fitted result through Publication API v2. The companion
public-API adapter makes a `plot.dataset` plot and renders it.

The module does not read installed generator-library files. Both source and
result Datasets persist independently of plugin installation.

Expected model: `y = A*exp(-k*x)+c`, with generator reference values read from
the Session. Numerical tolerance is 0.10 for A, 0.05 for k, and 0.08 for c;
the requested solver tolerance is 1e-9. The larger parameter tolerances account
for the generated Gaussian observation noise, not solver imprecision.
