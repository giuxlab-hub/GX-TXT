# GX-TXT dev108 — C++ Viewer compilation-cache and terminal diagnostics v2

## Target and scope

- **Public source:** [giuxlab-hub/GX-TXT](https://github.com/giuxlab-hub/GX-TXT), commit `6371001a219a4e611ce89c8b396c62294e6b979c`, version `0.9.8.10-dev-108`.
- **Required original Git blob:** `5d77772e22ce6eb0befcdc3e32ac783c7d46fbb0`.
- **Single modified framework file:** `core/python/gxtxt_viewer_development.py`.
- **No changes to:** `script_job_api_v1.tcl`, Tcl pipe redirection, Python/Octave Script Job stdout/stderr handling, other plugins, GitHub, or dev109.
- **License:** GNU GPL-3.0-or-later.

This is an independent backport based solely on public dev108, **not** a verified copy of dev109.

## Behavior

- Every native C++ Viewer event normally called `validate()` and rebuilt `viewer.so` via Clang even when no source had changed.
- v2 retains the v1 verified-project cache: after a successful compile, an unchanged project reuses `derived/viewer.so` and the corresponding preflight record. CORE design/capability checks still run. Exact SHA-256 identity of source/design/project/SDK/policy/compiler/adapter/toolchain/backend/binary is checked before reuse.
- Source or build environment changes trigger a fresh compile. Explicit Build/Export and debugger builds are *not* cached by this backport.
- On an **actual C++ compilation**, the worker emits `COMPILE START`, then `COMPILE OK`, `COMPILE FAILED`, or `COMPILE ERROR` messages, directly to **`/dev/tty`** (the controlling terminal) without writing to the worker's stdout/stderr streams.
- If a controlling terminal is unavailable, messages go to the project-local `derived/viewer_compilation.log` (bounded to approximately 1 MiB). This file must be a regular, nonlinked file owned by the current account. Logging is best-effort and cannot change compiler decisions.
- **A cache hit emits no compile messages**. If repeated clicks cause repeated `COMPILE START` messages for the *same* project, the recompilation remains and should be investigated.
- Opening a separately installed restricted Viewer may create a *new runtime project*; this can legitimately produce an initial compilation for each new runtime instance. The fix targets repeated events in an unchanged project, not cross-project binary reuse.

Example terminal output when compilation actually occurs:

```text
[GX-TXT Viewer C++] 2026-10-20T09:30:00Z project-name: COMPILE START (release)
[GX-TXT Viewer C++] 2026-10-20T09:30:02Z project-name: COMPILE OK after 2.318 s
```

These are `/dev/tty` diagnostics, **not** stderr writes. This distinction is essential because GX-TXT dev108's managed Tcl request pipe merges child stderr into the structured response channel.

## Installation on fotoserv (after removing v1)

**Close GX-TXT first.** The *v1* rollback should already have been performed, using the original v1 `backport.py` and its printed backup path. The v2 installer requires the exact **unmodified public dev108** source; it deliberately refuses to overwrite v1 or any other local edits.

Extract this ZIP to a separate folder, for example `~/gxtxt/viewer-patch-v2`, then from that folder run:

```bash
ROOT="$HOME/gxtxt/gxtxt_pipeline_v09810dev_108"
python3 backport.py --check "$ROOT"
python3 backport.py --apply "$ROOT"
```

The first command performs no modifications. The second creates a checked source backup under `<ROOT>/.gxtxt_patch_backups/dev108_restricted_viewer_cache_tty_v2_<UTC>/` before an atomic replacement, and prints the exact command to roll back **v2**.

After restarting GX-TXT from an interactive terminal, open an unchanged restricted C++ Viewer and invoke the same action repeatedly. One initial pair of `COMPILE START` / `COMPILE OK` messages is expected; subsequent events in the same project should not produce new compile messages. If no terminal message is visible (e.g. GX-TXT was launched by a graphical launcher), inspect the corresponding Viewer project:

```bash
tail -f "/path/to/viewer-project/derived/viewer_compilation.log"
```

The project path depends on the chosen Viewer and can differ from the framework installation path.

## Rollback v2

Use the exact `ROLLBACK:` command printed by `--apply` with the **v2** backup directory. The installer verifies the original SHA and refuses rollback if another edit occurred after installation.

## Tests and limitations

Run standalone offline regression tests:

```bash
python3 -m unittest -v test_patch
```

Tests cover original-source enforcement, reversible application, cache hits and invalidation for every tracked input, TTY-only reporting, fallback logging, no stdout/stderr pollution, refusal to follow a log symlink, and single-file scope.

**Limit:** tests run with isolated fixtures and mocked compiler events; they are *not* a completed integration test of an actual Debian GX-TXT GUI. The target machine's first real C++ Viewer run remains the acceptance test.
