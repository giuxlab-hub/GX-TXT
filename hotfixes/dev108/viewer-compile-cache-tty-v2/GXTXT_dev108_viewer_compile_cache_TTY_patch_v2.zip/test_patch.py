#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline tests for exact-source patch, cache and diagnostics (no native GX-TXT required)."""
import ast
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import time
import unittest
from unittest import mock
import backport

class PatchTests(unittest.TestCase):
    def source_fixture(self):
        # An AST-valid miniature of the public dev108 anchors. The exact Git
        # blob check remains authoritative for a real installation.
        r=backport.REPLACEMENTS
        return (
            r[0][0] + 'from pathlib import Path\nimport tempfile\nimport time\n\n'
            + r[1][0]
            + '    return meta, report, None, None\n\n'
            + r[2][0]
            + "    with tempfile.TemporaryDirectory(prefix='build-',dir=project/'derived/tmp') as temporary:\n"
            + "        stage=Path(temporary)\n        for command in []:\n"
            + r[6][0]
            + "            if code:\n                result={'status':'BUILD_FAILED'}\n"
            + r[7][0]
            + "        result={'status':'BUILT'}\n"
            + r[3][0]
            + "        return result\n\n"
            + r[4][0]
            + '    return built\n'
        ).encode('utf-8')

    def test_exact_source_patch_and_rejection(self):
        fixture=self.source_fixture()
        baseline=backport.SOURCE_GIT_BLOB
        try:
            backport.SOURCE_GIT_BLOB=backport.blob_sha1(fixture)
            changed=backport.make_patch(fixture)
            ast.parse(changed)
            self.assertIn(b'_viewer_compile_notice',changed)
            self.assertIn(b'cache_hit=True',changed)
            self.assertIn(b'validate(project,reuse_compiled=True)',changed)
            self.assertIn(b'import stat',changed)
            self.assertIn(b'COMPILE START',changed)
            self.assertIn(b'COMPILE FAILED',changed)
            self.assertIn(b'COMPILE ERROR',changed)
            self.assertIn(b'COMPILE OK',changed)
            with self.assertRaises(ValueError):
                backport.make_patch(fixture+b'\n')
        finally:
            backport.SOURCE_GIT_BLOB=baseline

    def test_apply_and_rollback(self):
        fixture=self.source_fixture()
        baseline=backport.SOURCE_GIT_BLOB
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            target=root/backport.TARGET
            target.parent.mkdir(parents=True)
            target.write_bytes(fixture)
            (root/'VERSION.txt').write_text(backport.EXPECTED_VERSION+'\n')
            backport.SOURCE_GIT_BLOB=backport.blob_sha1(fixture)
            try:
                backport.apply(root,dry_run=True)
                self.assertEqual(target.read_bytes(),fixture)
                backport.apply(root,dry_run=False)
                patch=target.read_bytes()
                self.assertNotEqual(patch,fixture)
                dirs=list((root/'.gxtxt_patch_backups').iterdir())
                self.assertEqual(len(dirs),1)
                with self.assertRaises(ValueError):backport.apply(root,dry_run=False)
                target.write_bytes(patch+b'\n# an intervening edit\n')
                with self.assertRaises(ValueError):backport.rollback(root,dirs[0])
                target.write_bytes(patch)
                backport.rollback(root,dirs[0])
                self.assertEqual(target.read_bytes(),fixture)
            finally:
                backport.SOURCE_GIT_BLOB=baseline

    def setup_cache(self,base):
        project=base/'project';(project/'derived').mkdir(parents=True)
        sdk=base/'sdk.hpp';compiler=base/'clang';dev=base/'development'
        (dev/'toolchain').mkdir(parents=True)
        backend=base/'backend.py';cpp_policy=base/'core/python/gxtxt_cpp_policy.py'
        cpp_policy.parent.mkdir(parents=True)
        paths={
            'source_sha256':project/'handlers.cpp',
            'design_sha256':project/'design.gxtxt-viewer',
            'project_sha256':project/'project.json',
            'sdk_sha256':sdk,
            'policy_sha256':dev/'policy_v1.json',
            'compiler_sha256':compiler,
            'adapter_sha256':sdk.parent/'trusted_adapter_v1.cpp',
            'toolchain_manifest_sha256':dev/'toolchain/manifest.json',
            'development_backend_sha256':backend,
            'cpp_policy_backend_sha256':cpp_policy,
        }
        for key,path in paths.items():path.write_text('fixture-'+key)
        ns={'Path':Path,'json':json,'digest':lambda data:hashlib.sha256(data).hexdigest(),
            'SDK':sdk,'DEVELOPMENT':dev,'COMPILER':compiler,'FRAMEWORK':base,'BACKEND_PATH':backend}
        exec(compile(backport.CACHE_HELPER.replace('Path(__file__)','BACKEND_PATH'),'helpers','exec'),ns)
        fingerprints=ns['_viewer_compilation_cache_fingerprints'](project)
        validation={'status':'PASS',**{k:fingerprints[k] for k in (
            'source_sha256','design_sha256','project_sha256','sdk_sha256','policy_sha256','compiler_sha256')}}
        binary=project/'derived/viewer.so';binary.write_bytes(b'ELF-test')
        receipt={'schema':'gxtxt.viewer_build.v1','status':'BUILT','debug_symbols':False,
            'cache_schema':'gxtxt.viewer_compilation_cache.v1','cache_fingerprints':fingerprints,
            'validation':validation,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'adapter_sha256':fingerprints['adapter_sha256']}
        (project/'derived/build.json').write_text(json.dumps(receipt))
        return project, paths, ns, validation, receipt, binary

    def test_cache_and_all_invalidation_rules(self):
        with tempfile.TemporaryDirectory() as tmp:
            project,paths,ns,validation,receipt,binary=self.setup_cache(Path(tmp))
            self.assertIsNotNone(ns['_viewer_reusable_build'](project))
            count={'compiled':0}
            ns['count']=count
            # Source entrance to compiled path is simulated; the cache hit logic is real.
            simulated=(backport.REPLACEMENTS[2][1]
                + "    count['compiled']+=1\n"
                + "    return {'status':'BUILT','code_generation_invoked':True}\n")
            exec(compile(simulated,'simulated.py','exec'),ns)
            for _ in range(6):
                result=ns['_compile_admitted'](project,{},validation,{},set(),reuse=True)
                self.assertTrue(result['cache_hit'])
                self.assertFalse(result['code_generation_invoked'])
            self.assertEqual(count['compiled'],0)
            ns['_compile_admitted'](project,{},validation,{},set())
            ns['_compile_admitted'](project,{},validation,{},set(),debug=True,reuse=True)
            self.assertEqual(count['compiled'],2)
            for name,path in paths.items():
                original=path.read_bytes();path.write_bytes(original+b'!')
                self.assertIsNone(ns['_viewer_reusable_build'](project),name)
                path.write_bytes(original)
            binary.write_bytes(b'broken')
            self.assertIsNone(ns['_viewer_reusable_build'](project))
            binary.write_bytes(b'ELF-test')
            receipt['cache_schema']='nope'
            (project/'derived/build.json').write_text(json.dumps(receipt))
            self.assertIsNone(ns['_viewer_reusable_build'](project))

    def test_tty_logging_isolated_from_stdout_stderr(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'derived').mkdir()
            namespace={'os':os,'stat':stat,'time':time}
            exec(backport.LOG_HELPER,namespace)
            read_fd,write_fd=os.pipe()
            actual_open=os.open
            def fake_open(path,flags,mode=0o777):
                if path=='/dev/tty':return os.dup(write_fd)
                return actual_open(path,flags,mode)
            stdout,stderr=io.StringIO(),io.StringIO()
            try:
                with mock.patch.object(os,'open',side_effect=fake_open), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                    namespace['_viewer_compile_notice'](root,'COMPILE START (release)')
                data=os.read(read_fd,4096).decode()
                self.assertIn('COMPILE START (release)',data)
                self.assertEqual(stdout.getvalue(),'')
                self.assertEqual(stderr.getvalue(),'')
                self.assertFalse((root/'derived/viewer_compilation.log').exists())
            finally:
                os.close(read_fd);os.close(write_fd)

    def test_without_terminal_log_fallback_and_no_stream_pollution(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'derived').mkdir()
            namespace={'os':os,'stat':stat,'time':time}
            exec(backport.LOG_HELPER,namespace)
            actual_open=os.open
            def fake_open(path,flags,mode=0o777):
                if path=='/dev/tty':raise OSError('no tty')
                return actual_open(path,flags,mode)
            stdout,stderr=io.StringIO(),io.StringIO()
            with mock.patch.object(os,'open',side_effect=fake_open), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                namespace['_viewer_compile_notice'](root,'COMPILE OK after 1.23 s')
            self.assertEqual(stdout.getvalue(),'')
            self.assertEqual(stderr.getvalue(),'')
            log=root/'derived/viewer_compilation.log'
            self.assertIn('COMPILE OK after 1.23 s',log.read_text())
            log.unlink()
            log.symlink_to(root/'sentinel')
            (root/'sentinel').write_text('untouched')
            namespace['_viewer_compile_notice'](root,'COMPILE START')
            self.assertEqual((root/'sentinel').read_text(),'untouched')

    def test_no_tcl_or_script_job_modifications(self):
        self.assertEqual(str(backport.TARGET),'core/python/gxtxt_viewer_development.py')
        all_patched='\n'.join(new for _,new in backport.REPLACEMENTS)
        self.assertNotIn('scriptJobAsync',all_patched)
        self.assertNotIn('sys.stderr',all_patched)
        self.assertNotIn('print(',backport.LOG_HELPER)

if __name__=='__main__':
    unittest.main()
