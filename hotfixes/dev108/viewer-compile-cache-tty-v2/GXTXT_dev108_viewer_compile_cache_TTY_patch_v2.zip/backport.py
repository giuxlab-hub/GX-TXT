#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact-source, reversible backport: Viewer C++ cache and isolated TTY diagnostics."""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
from datetime import datetime, timezone

SOURCE_COMMIT = '6371001a219a4e611ce89c8b396c62294e6b979c'
SOURCE_GIT_BLOB = '5d77772e22ce6eb0befcdc3e32ac783c7d46fbb0'
EXPECTED_VERSION = '0.9.8.10-dev-108'
TARGET = Path('core/python/gxtxt_viewer_development.py')
PATCH_ID = 'dev108_restricted_viewer_cache_tty_v2'

LOG_HELPER = r'''def _viewer_compile_notice(project, message):
    """Report actual Clang builds without writing to managed stdout/stderr.

    Tcl Script Job merges the Python worker's stderr into its protocol stdout.
    The controlling terminal is a separate destination, never an inherited fd.
    When detached, retain a bounded project-local diagnostic log instead.
    Logging is best-effort and cannot change the build outcome.
    """
    name = str(project.name).replace('\n', ' ').replace('\r', ' ')[:96]
    event = str(message).replace('\n', ' ').replace('\r', ' ')[:256]
    now = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    line = ('[GX-TXT Viewer C++] ' + now + ' ' + name + ': ' + event + '\n').encode('utf-8')
    try:
        fd = os.open('/dev/tty', os.O_WRONLY | os.O_NOCTTY | os.O_CLOEXEC | os.O_NONBLOCK)
    except OSError:
        fd = None
    if fd is not None:
        try:
            if os.write(fd, line) == len(line):
                return
        except OSError:
            pass
        finally:
            try:
                os.close(fd)
            except OSError:
                pass
    # No usable controlling terminal: do not contaminate the Job's protocol.
    try:
        path = project/'derived/viewer_compilation.log'
        flags = os.O_WRONLY | os.O_APPEND | os.O_CREAT | os.O_CLOEXEC | os.O_NOFOLLOW
        out = os.open(path, flags, 0o600)
        try:
            info = os.fstat(out)
            if (stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and
                    info.st_uid == os.geteuid() and info.st_size < 1048576):
                os.write(out, line)
        finally:
            try:
                os.close(out)
            except OSError:
                pass
    except OSError:
        pass


'''

CACHE_HELPER = '''def _viewer_compilation_cache_fingerprints(project):
    """Bind a trusted build receipt to all relevant source and toolchain inputs."""
    inputs = {
        'source_sha256': project/'handlers.cpp',
        'design_sha256': project/'design.gxtxt-viewer',
        'project_sha256': project/'project.json',
        'sdk_sha256': SDK,
        'policy_sha256': DEVELOPMENT/'policy_v1.json',
        'compiler_sha256': COMPILER,
        'adapter_sha256': SDK.parent/'trusted_adapter_v1.cpp',
        'toolchain_manifest_sha256': DEVELOPMENT/'toolchain/manifest.json',
        'development_backend_sha256': Path(__file__),
        'cpp_policy_backend_sha256': FRAMEWORK/'core/python/gxtxt_cpp_policy.py',
    }
    return {key: digest(path.read_bytes()) for key, path in inputs.items()}


def _viewer_reusable_build(project):
    """Reuse only the binary described by an exact, intact local build receipt.

    A cache miss falls back to the existing validation and Clang build path.
    Explicit Build/Export and debugger builds are deliberately unaffected.
    """
    receipt_path = project/'derived/build.json'
    binary_path = project/'derived/viewer.so'
    try:
        for path, maximum in ((receipt_path, 1048576), (binary_path, 33554432)):
            if (not path.is_file() or path.is_symlink() or
                    path.stat().st_nlink != 1 or path.stat().st_size > maximum):
                return None
        receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
        if (not isinstance(receipt, dict) or
                receipt.get('schema') != 'gxtxt.viewer_build.v1' or
                receipt.get('status') != 'BUILT' or
                receipt.get('debug_symbols') is not False or
                receipt.get('cache_schema') != 'gxtxt.viewer_compilation_cache.v1'):
            return None
        previous = receipt.get('validation')
        if not isinstance(previous, dict) or previous.get('status') != 'PASS':
            return None
        current = _viewer_compilation_cache_fingerprints(project)
        if receipt.get('cache_fingerprints') != current:
            return None
        for key in ('source_sha256', 'design_sha256', 'project_sha256',
                    'sdk_sha256', 'policy_sha256', 'compiler_sha256'):
            if previous.get(key) != current[key]:
                return None
        if receipt.get('adapter_sha256') != current['adapter_sha256']:
            return None
        if receipt.get('binary_sha256') != digest(binary_path.read_bytes()):
            return None
        return receipt
    except (OSError, ValueError, TypeError, KeyError, UnicodeError):
        return None


'''

REPLACEMENTS = [
    (
        'import signal\nimport subprocess\n',
        'import signal\nimport stat\nimport subprocess\n'
    ),
    (
        'def validate(project):\n    meta=read_project(project)\n    report=validate_source((project/\'handlers.cpp\').read_bytes(),project/\'derived/tmp\')\n',
        LOG_HELPER + CACHE_HELPER +
        'def validate(project, reuse_compiled=False):\n'
        '    meta=read_project(project)\n'
        '    cached=_viewer_reusable_build(project) if reuse_compiled else None\n'
        '    report=(dict(cached[\'validation\']) if cached is not None else\n'
        '            validate_source((project/\'handlers.cpp\').read_bytes(),project/\'derived/tmp\'))\n'
    ),
    (
        'def _compile_admitted(project, meta, report, design, requested, debug=False):\n'
        '    """Compile only this request\'s freshly validated in-memory admission.\n\n'
        '    No project-authored report or previous binary can supply this context.\n'
        '    The post-compile source/design/project checks below remain mandatory.\n'
        '    """\n'
        "    if report['status']!='PASS': return {'status':'REJECTED','validation':report,'code_generation_invoked':False}\n"
        "    source=(project/'handlers.cpp').read_bytes()\n",
        'def _compile_admitted(project, meta, report, design, requested, debug=False, reuse=False):\n'
        '    """Build explicitly, or reuse an identical admitted release binary for events.\n\n'
        '    Admission still rechecks the live CORE design and requested capabilities.\n'
        '    The post-compile source/design/project checks remain mandatory.\n'
        '    """\n'
        "    if report['status']!='PASS': return {'status':'REJECTED','validation':report,'code_generation_invoked':False}\n"
        '    if reuse and not debug:\n'
        '        cached=_viewer_reusable_build(project)\n'
        '        if cached is not None and all(\n'
        "                cached['validation'].get(key)==report.get(key)\n"
        "                for key in ('source_sha256','design_sha256','project_sha256',\n"
        "                            'sdk_sha256','policy_sha256','compiler_sha256')):\n"
        "            return dict(cached, code_generation_invoked=False, cache_hit=True)\n"
        "    source=(project/'handlers.cpp').read_bytes()\n"
    ),
    (
        "        result['debug_symbols']=debug\n"
        "        write_json(project/('derived/debug-build.json' if debug else 'derived/build.json'),result)\n",
        "        result['debug_symbols']=debug\n"
        "        if not debug:\n"
        "            fingerprints=_viewer_compilation_cache_fingerprints(project)\n"
        "            if any(fingerprints.get(key)!=report.get(key) for key in\n"
        "                   ('source_sha256','design_sha256','project_sha256','sdk_sha256',\n"
        "                    'policy_sha256','compiler_sha256')) or (\n"
        "                    fingerprints['adapter_sha256']!=result['adapter_sha256']):\n"
        "                raise DevelopmentError('Build inputs changed during compilation','SOURCE_CHANGED')\n"
        "            result['cache_schema']='gxtxt.viewer_compilation_cache.v1'\n"
        "            result['cache_fingerprints']=fingerprints\n"
        "            result['cache_hit']=False\n"
        "        write_json(project/('derived/debug-build.json' if debug else 'derived/build.json'),result)\n"
    ),
    (
        'def run(project,event=None,state=None):\n'
        '    meta,validation,design,requested=validate(project)\n'
        '    built=_compile_admitted(project,meta,validation,design,requested)\n',
        'def run(project,event=None,state=None):\n'
        '    meta,validation,design,requested=validate(project,reuse_compiled=True)\n'
        '    built=_compile_admitted(project,meta,validation,design,requested,reuse=True)\n'
    ),
    (
        "    source=(project/'handlers.cpp').read_bytes()\n"
        "    with tempfile.TemporaryDirectory(prefix='build-',dir=project/'derived/tmp') as temporary:\n",
        "    _viewer_compile_notice(project, 'COMPILE START (' + ('debug' if debug else 'release') + ')')\n"
        "    compile_started=time.monotonic()\n"
        "    source=(project/'handlers.cpp').read_bytes()\n"
        "    with tempfile.TemporaryDirectory(prefix='build-',dir=project/'derived/tmp') as temporary:\n"
    ),
    (
        "            code,output,errors=bounded_command(command,stage,30)\n",
        "            try:\n"
        "                code,output,errors=bounded_command(command,stage,30)\n"
        "            except Exception as problem:\n"
        "                _viewer_compile_notice(project, 'COMPILE ERROR after %.3f s: %s' % (time.monotonic()-compile_started, str(problem)[:120]))\n"
        "                raise\n"
    ),
    (
        "                write_json(project/'derived/build.json',result);return result\n",
        "                write_json(project/'derived/build.json',result)\n"
        "                _viewer_compile_notice(project, 'COMPILE FAILED after %.3f s (exit=%s)' % (time.monotonic()-compile_started, code))\n"
        "                return result\n"
    ),
    (
        "        write_json(project/('derived/debug-build.json' if debug else 'derived/build.json'),result)\n"
        "        return result\n",
        "        write_json(project/('derived/debug-build.json' if debug else 'derived/build.json'),result)\n"
        "        _viewer_compile_notice(project, 'COMPILE OK after %.3f s' % (time.monotonic()-compile_started))\n"
        "        return result\n"
    ),
]

def blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def make_patch(original: bytes) -> bytes:
    if blob_sha1(original) != SOURCE_GIT_BLOB:
        raise ValueError('Target does not match the exact GitHub dev108 source blob; no changes made')
    text = original.decode('utf-8')
    for old, new in REPLACEMENTS:
        if text.count(old) != 1:
            raise ValueError('Dev108 source anchor is absent or repeated; no changes made')
        text = text.replace(old, new, 1)
    ast.parse(text, filename=str(TARGET))
    compile(text, str(TARGET), 'exec')
    return text.encode('utf-8')


def atomic_write(path: Path, data: bytes, mode: int):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb',prefix='.gxtxt-viewer-patch-',dir=path.parent,delete=False) as fp:
            temporary = Path(fp.name)
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary,path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def apply(root: Path, dry_run: bool):
    if (root/'VERSION.txt').read_text(encoding='utf-8').strip() != EXPECTED_VERSION:
        raise ValueError('VERSION.txt must identify exact GX-TXT dev108')
    target = root/TARGET
    if not target.is_file() or target.is_symlink():
        raise ValueError('Required ordinary source file missing or symbolic link')
    original = target.read_bytes()
    updated = make_patch(original)
    patched_sha256 = hashlib.sha256(updated).hexdigest()
    if dry_run:
        print('CHECK OK: GitHub commit',SOURCE_COMMIT)
        print('CHECK OK: exact Git blob',SOURCE_GIT_BLOB)
        print('CHECK OK: resulting file parses and compiles as Python')
        print('CHECK OK: standalone C++ cache + /dev/tty notifications; no Tcl/job stream changes')
        print('PATCHED SHA256:', patched_sha256)
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup_dir = root/'.gxtxt_patch_backups'/(PATCH_ID+'_'+stamp)
    if backup_dir.exists():
        raise ValueError('Backup directory already exists; retry after one second')
    backup_dir.mkdir(parents=True,exist_ok=False)
    backup_path = backup_dir/'gxtxt_viewer_development.py'
    backup_path.write_bytes(original)
    if blob_sha1(backup_path.read_bytes()) != SOURCE_GIT_BLOB:
        raise ValueError('Backup verification failed; target left unchanged')
    mode=stat.S_IMODE(target.stat().st_mode)
    manifest = dict(patch_id=PATCH_ID, source_commit=SOURCE_COMMIT,
                    original_git_blob=SOURCE_GIT_BLOB,
                    patched_sha256=patched_sha256, original_mode=mode,
                    target=str(TARGET), backup=str(backup_path.relative_to(root)))
    (backup_dir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    atomic_write(target,updated,mode)
    if hashlib.sha256(target.read_bytes()).hexdigest()!=patched_sha256:
        atomic_write(target,original,mode)
        raise ValueError('Post-install checksum mismatch; original restored')
    print('APPLIED:',target)
    print('BACKUP:',backup_dir)
    print('ROLLBACK: python3 backport.py',root,'--rollback',backup_dir)


def rollback(root: Path, directory: Path):
    backup_dir=directory.resolve(strict=True)
    if backup_dir.parent != (root/'.gxtxt_patch_backups').resolve():
        raise ValueError('Rollback directory does not belong to this framework installation')
    record=json.loads((backup_dir/'manifest.json').read_text(encoding='utf-8'))
    if record.get('patch_id')!=PATCH_ID or record.get('target')!=str(TARGET):
        raise ValueError('Unrecognized rollback manifest')
    backup=(backup_dir/'gxtxt_viewer_development.py').read_bytes()
    if blob_sha1(backup)!=SOURCE_GIT_BLOB:
        raise ValueError('Backup does not match the original public dev108 blob')
    target=root/TARGET
    if target.is_symlink() or not target.is_file():
        raise ValueError('Invalid rollback target')
    if hashlib.sha256(target.read_bytes()).hexdigest()!=record['patched_sha256']:
        raise ValueError('Current source changed after patch; refuse to overwrite local changes')
    atomic_write(target,backup,record['original_mode'])
    print('RESTORED:',target)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('framework',type=Path,help='GX-TXT dev108 root containing VERSION.txt')
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--check',action='store_true',help='Read-only preflight')
    action.add_argument('--apply',action='store_true',help='Apply with verified backup')
    action.add_argument('--rollback',type=Path,metavar='BACKUP_DIRECTORY')
    args=parser.parse_args()
    root=args.framework.resolve(strict=True)
    try:
        if args.rollback: rollback(root,args.rollback)
        else: apply(root,dry_run=args.check)
    except (ValueError,OSError,UnicodeError,SyntaxError) as exc:
        parser.exit(2,'REFUSED: '+str(exc)+'\n')

if __name__=='__main__':
    main()
