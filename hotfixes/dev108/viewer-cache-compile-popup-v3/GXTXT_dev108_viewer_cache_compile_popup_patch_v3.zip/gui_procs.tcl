# Per-event, nonmodal Tk notice. No Script Job stderr/stdout changes.
proc ::GX::_viewerDevelopmentCompilePoll {window token} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || ![winfo exists $window]} return
    set record [dict get $::GX::ViewerDevelopment::windows $window]
    if {![dict exists $record compile_token] || [dict get $record compile_token] ne $token} return
    set marker [file join [dict get $record project] derived tmp viewer-compiling-${token}.marker]
    if {[file isfile $marker] && ![dict exists $record compile_notice_shown]} {
        dict set ::GX::ViewerDevelopment::windows $window compile_notice_shown 1
        set notice ${window}.cppBuildNotice
        if {![winfo exists $notice]} {
            toplevel $notice
            wm title $notice {GX-TXT - C++ compilation}
            wm transient $notice $window
            wm resizable $notice 0 0
            ttk::label $notice.message -text {Compilazione C++ del viewer in corso...} -padding {22 18}
            pack $notice.message -fill both -expand 1
        }
    }
    after 100 [list ::GX::_viewerDevelopmentCompilePoll $window $token]
}
proc ::GX::_viewerDevelopmentCompileFinish {window} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    set record [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict exists $record compile_token]} {
        set token [dict get $record compile_token]
        set marker [file join [dict get $record project] derived tmp viewer-compiling-${token}.marker]
        catch {file delete -- $marker}
        dict unset ::GX::ViewerDevelopment::windows $window compile_token
    }
    if {[winfo exists ${window}.cppBuildNotice]} {destroy ${window}.cppBuildNotice}
}
