#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline verification of dev108 exact-source backport and nonmodal compile notice."""
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock
import backport

class PatchTests(unittest.TestCase):
    def fixture_sources(self):
        r=backport.REPLACEMENTS
        python=(
            'import os\nimport json\nimport tempfile\nfrom pathlib import Path\n'
            +r[0][0]
            +'    return meta, report, {}, set()\n\n'
            +r[1][0]
            +'    with tempfile.TemporaryDirectory() as temporary:\n'
            +'        result={"status":"BUILT"}\n'
            +r[2][0]
            +'        return result\n\n'
            +r[3][0]
            +'    result={"status":"COMPLETED",\n'
            +r[4][0]
            +'    return result\n\n'
            +'def main():\n'
            +'    import argparse\n'
            +'    parser=argparse.ArgumentParser()\n'
            +r[5][0]
            +'    arguments=parser.parse_args([])\n'
            +'    project=Path("/tmp")\n'
            +'    try:\n'
            +r[6][0]
            +'        else:\n'
            +'            if arguments.operation=="build": result=build(project)\n'
            +r[7][0]
            +'    except Exception:\n'
            +'        return None\n')
        gui='\n'.join(old.rstrip('\n') for old,_ in backport.GUI_REPLACEMENTS)+'\n'
        return python.encode(),gui.encode()

    def test_replace_both_and_strict_blobs(self):
        original,gui=self.fixture_sources()
        a,b=backport.SOURCE_GIT_BLOB,backport.GUI_SOURCE_GIT_BLOB
        try:
            backport.SOURCE_GIT_BLOB=backport.blob_sha1(original)
            backport.GUI_SOURCE_GIT_BLOB=backport.blob_sha1(gui)
            py,tk=backport.make_patch(original,gui)
            self.assertIn(b'compile_cache_hit',py)
            self.assertIn(b'_viewer_compile_signal',py)
            self.assertIn(b'compile_token=compile_token',py)
            self.assertIn(b'viewerDevelopmentCompilePoll',tk)
            self.assertIn(b' (C++ binary reused)',tk)
            with self.assertRaises(ValueError):backport.make_patch(original+b'\n',gui)
            with self.assertRaises(ValueError):backport.make_patch(original,gui+b'\n')
        finally:
            backport.SOURCE_GIT_BLOB=a
            backport.GUI_SOURCE_GIT_BLOB=b

    def test_install_preflight_rollback_and_changed_target(self):
        original,gui=self.fixture_sources()
        a,b=backport.SOURCE_GIT_BLOB,backport.GUI_SOURCE_GIT_BLOB
        try:
            backport.SOURCE_GIT_BLOB=backport.blob_sha1(original)
            backport.GUI_SOURCE_GIT_BLOB=backport.blob_sha1(gui)
            with tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp)
                (root/'VERSION.txt').write_text(backport.EXPECTED_VERSION+'\n')
                for path,raw in ((backport.TARGET,original),(backport.GUI_TARGET,gui)):
                    file=root/path
                    file.parent.mkdir(parents=True,exist_ok=True)
                    file.write_bytes(raw)
                backport.apply(root,True)
                self.assertEqual((root/backport.TARGET).read_bytes(),original)
                backport.apply(root,False)
                save=next((root/'.gxtxt_patch_backups').iterdir())
                with self.assertRaises(ValueError):backport.apply(root,False)
                target=root/backport.GUI_TARGET
                fixed=target.read_bytes()
                target.write_bytes(fixed+b'\n# untracked edit')
                with self.assertRaises(ValueError):backport.rollback(root,save)
                target.write_bytes(fixed)
                backport.rollback(root,save)
                self.assertEqual((root/backport.TARGET).read_bytes(),original)
                self.assertEqual((root/backport.GUI_TARGET).read_bytes(),gui)
        finally:
            backport.SOURCE_GIT_BLOB=a
            backport.GUI_SOURCE_GIT_BLOB=b

    def test_compilation_marker_no_stream_pollution(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'derived/tmp').mkdir(parents=True)
            functions=backport.CACHE_HELPER.split('def _viewer_compilation_cache_fingerprints')[0]
            globals_={'os':os}
            exec(functions,globals_)
            stdout,stderr=io.StringIO(),io.StringIO()
            with contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
                globals_['_viewer_compile_signal'](root,None)
                self.assertFalse(list((root/'derived/tmp').iterdir()))
                globals_['_viewer_compile_signal'](root,'compile_123')
                globals_['_viewer_compile_signal'](root,'compile_123')
            self.assertEqual(stdout.getvalue(),'')
            self.assertEqual(stderr.getvalue(),'')
            self.assertTrue((root/'derived/tmp/viewer-compiling-compile_123.marker').is_file())

    def test_tcl_notice_create_once_finish_and_cache_hit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'derived/tmp').mkdir(parents=True)
            marker=root/'derived/tmp/viewer-compiling-tokenabc.marker'
            tcl=Path(tmp)/'test.tcl'
            tcl.write_text('''
namespace eval ::GX::ViewerDevelopment {variable windows {}}
namespace eval ::ttk {}
set ::shown 0
set ::closed 0
set ::popup 0
set ::again {}
proc winfo {op path} {
    if {$path eq {.test}} {return 1}
    if {$path eq {.test.cppBuildNotice}} {return $::popup}
    return 0
}
proc toplevel {path} {incr ::shown;set ::popup 1}
proc wm {args} {}
proc ttk::label {args} {}
proc pack {args} {}
proc after {delay callback} {set ::again $callback}
proc destroy {path} {incr ::closed;set ::popup 0}
set root [lindex $argv 0]
dict set ::GX::ViewerDevelopment::windows .test [dict create project $root compile_token tokenabc]
source [lindex $argv 1]
::GX::_viewerDevelopmentCompilePoll .test tokenabc
if {$::shown != 0} {error {popup on cache hit}}
set f [open [file join $root derived tmp viewer-compiling-tokenabc.marker] w];close $f
::GX::_viewerDevelopmentCompilePoll .test tokenabc
::GX::_viewerDevelopmentCompilePoll .test tokenabc
if {$::shown != 1} {error {popup must be shown once}}
::GX::_viewerDevelopmentCompileFinish .test
if {$::closed != 1} {error {popup not dismissed}}
if {[file exists [file join $root derived tmp viewer-compiling-tokenabc.marker]]} {error {marker not removed}}
::GX::_viewerDevelopmentCompilePoll .test tokenabc
if {$::shown != 1} {error {stale watcher reopened popup}}
puts {TCL_POPUP_TEST_OK}
''')
            gui=Path(__file__).with_name('gui_procs.tcl')
            result=subprocess.run(['tclsh',str(tcl),str(root),str(gui)],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('TCL_POPUP_TEST_OK',result.stdout)

    def setup_cache(self,base):
        project=base/'project';(project/'derived').mkdir(parents=True)
        sdk=base/'sdk.hpp';compiler=base/'clang';dev=base/'development'
        (dev/'toolchain').mkdir(parents=True)
        backend=base/'backend.py';cpp_policy=base/'core/python/gxtxt_cpp_policy.py'
        cpp_policy.parent.mkdir(parents=True)
        paths={
            'source_sha256':project/'handlers.cpp',
            'design_sha256':project/'design.gxtxt-viewer',
            'project_sha256':project/'project.json',
            'sdk_sha256':sdk,
            'policy_sha256':dev/'policy_v1.json',
            'compiler_sha256':compiler,
            'adapter_sha256':sdk.parent/'trusted_adapter_v1.cpp',
            'toolchain_manifest_sha256':dev/'toolchain/manifest.json',
            'development_backend_sha256':backend,
            'cpp_policy_backend_sha256':cpp_policy,
        }
        for key,path in paths.items():path.write_text('fixture-'+key)
        ns={'os':os,'Path':Path,'json':json,'digest':lambda data:hashlib.sha256(data).hexdigest(),
            'SDK':sdk,'DEVELOPMENT':dev,'COMPILER':compiler,'FRAMEWORK':base,'BACKEND_PATH':backend, '_viewer_compile_signal': lambda project,token: None}
        exec(compile(backport.CACHE_HELPER.replace('Path(__file__)','BACKEND_PATH'),'helpers','exec'),ns)
        fingerprints=ns['_viewer_compilation_cache_fingerprints'](project)
        validation={'status':'PASS',**{k:fingerprints[k] for k in (
            'source_sha256','design_sha256','project_sha256','sdk_sha256','policy_sha256','compiler_sha256')}}
        binary=project/'derived/viewer.so';binary.write_bytes(b'ELF-test')
        receipt={'schema':'gxtxt.viewer_build.v1','status':'BUILT','debug_symbols':False,
            'cache_schema':'gxtxt.viewer_compilation_cache.v1','cache_fingerprints':fingerprints,
            'validation':validation,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
            'adapter_sha256':fingerprints['adapter_sha256']}
        (project/'derived/build.json').write_text(json.dumps(receipt))
        return project, paths, ns, validation, receipt, binary

    def test_cache_and_all_invalidation_rules(self):
        with tempfile.TemporaryDirectory() as tmp:
            project,paths,ns,validation,receipt,binary=self.setup_cache(Path(tmp))
            self.assertIsNotNone(ns['_viewer_reusable_build'](project))
            count={'compiled':0}
            ns['count']=count
            # Source entrance to compiled path is simulated; the cache hit logic is real.
            simulated=(backport.REPLACEMENTS[1][1]
                + "    count['compiled']+=1\n"
                + "    return {'status':'BUILT','code_generation_invoked':True}\n")
            exec(compile(simulated,'simulated.py','exec'),ns)
            for _ in range(6):
                result=ns['_compile_admitted'](project,{},validation,{},set(),reuse=True)
                self.assertTrue(result['cache_hit'])
                self.assertFalse(result['code_generation_invoked'])
            self.assertEqual(count['compiled'],0)
            # A changed original source must force a real build path.
            path=paths['source_sha256']; path.write_bytes(path.read_bytes()+b'!')
            ns['_compile_admitted'](project,{},validation,{},set(),reuse=True,compile_token='attempt_1')
            self.assertEqual(count['compiled'],1)
            path.write_bytes(path.read_bytes()[:-1])
            ns['_compile_admitted'](project,{},validation,{},set())
            ns['_compile_admitted'](project,{},validation,{},set(),debug=True,reuse=True)
            self.assertEqual(count['compiled'],3)
            for name,path in paths.items():
                original=path.read_bytes();path.write_bytes(original+b'!')
                self.assertIsNone(ns['_viewer_reusable_build'](project),name)
                path.write_bytes(original)
            binary.write_bytes(b'broken')
            self.assertIsNone(ns['_viewer_reusable_build'](project))
            binary.write_bytes(b'ELF-test')
            receipt['cache_schema']='nope'
            (project/'derived/build.json').write_text(json.dumps(receipt))
            self.assertIsNone(ns['_viewer_reusable_build'](project))

    def test_no_global_script_job_or_stream_changes(self):
        self.assertEqual({str(backport.TARGET),str(backport.GUI_TARGET)},
            {'core/python/gxtxt_viewer_development.py','core/tcl/viewer_development_api_v1.tcl'})
        changed='\n'.join(v for k,v in backport.REPLACEMENTS+backport.GUI_REPLACEMENTS)
        self.assertNotIn('scriptJobAsync $command',changed)
        self.assertNotIn('sys.stderr',changed)
        self.assertNotIn('stderr.write',changed)

if __name__=='__main__':unittest.main()
