#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Exact-source reversible GX-TXT dev108 C++ Viewer cache and GUI build notification."""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
from datetime import datetime, timezone

SOURCE_COMMIT = '6371001a219a4e611ce89c8b396c62294e6b979c'
SOURCE_GIT_BLOB = '5d77772e22ce6eb0befcdc3e32ac783c7d46fbb0'
EXPECTED_VERSION = '0.9.8.10-dev-108'
TARGET = Path('core/python/gxtxt_viewer_development.py')
GUI_TARGET = Path('core/tcl/viewer_development_api_v1.tcl')
GUI_SOURCE_GIT_BLOB = 'c8512866a872015d99938816a868f97ad2a4fc5d'
PATCH_ID = 'dev108_restricted_viewer_compile_popup_v3'

CACHE_HELPER = '''def _viewer_compile_signal(project, token):
    """Tell the matching GUI request an actual Clang build is starting.

    Never use stdout or stderr: Tcl's managed-job protocol merges both streams.
    The token belongs to this one GUI event, not an arbitrary caller path.
    Signalling is auxiliary and cannot influence build success or failure.
    """
    if token is None:
        return
    try:
        path = project/'derived/tmp'/('viewer-compiling-' + token + '.marker')
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC | os.O_NOFOLLOW
        fd = os.open(path, flags, 0o600)
        os.close(fd)
    except OSError:
        pass


def _viewer_compilation_cache_fingerprints(project):
    """Bind a trusted build receipt to all relevant source and toolchain inputs."""
    inputs = {
        'source_sha256': project/'handlers.cpp',
        'design_sha256': project/'design.gxtxt-viewer',
        'project_sha256': project/'project.json',
        'sdk_sha256': SDK,
        'policy_sha256': DEVELOPMENT/'policy_v1.json',
        'compiler_sha256': COMPILER,
        'adapter_sha256': SDK.parent/'trusted_adapter_v1.cpp',
        'toolchain_manifest_sha256': DEVELOPMENT/'toolchain/manifest.json',
        'development_backend_sha256': Path(__file__),
        'cpp_policy_backend_sha256': FRAMEWORK/'core/python/gxtxt_cpp_policy.py',
    }
    return {key: digest(path.read_bytes()) for key, path in inputs.items()}


def _viewer_reusable_build(project):
    """Reuse only the binary described by an exact, intact local build receipt.

    A cache miss falls back to the existing validation and Clang build path.
    Explicit Build/Export and debugger builds are deliberately unaffected.
    """
    receipt_path = project/'derived/build.json'
    binary_path = project/'derived/viewer.so'
    try:
        for path, maximum in ((receipt_path, 1048576), (binary_path, 33554432)):
            if (not path.is_file() or path.is_symlink() or
                    path.stat().st_nlink != 1 or path.stat().st_size > maximum):
                return None
        receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
        if (not isinstance(receipt, dict) or
                receipt.get('schema') != 'gxtxt.viewer_build.v1' or
                receipt.get('status') != 'BUILT' or
                receipt.get('debug_symbols') is not False or
                receipt.get('cache_schema') != 'gxtxt.viewer_compilation_cache.v1'):
            return None
        previous = receipt.get('validation')
        if not isinstance(previous, dict) or previous.get('status') != 'PASS':
            return None
        current = _viewer_compilation_cache_fingerprints(project)
        if receipt.get('cache_fingerprints') != current:
            return None
        for key in ('source_sha256', 'design_sha256', 'project_sha256',
                    'sdk_sha256', 'policy_sha256', 'compiler_sha256'):
            if previous.get(key) != current[key]:
                return None
        if receipt.get('adapter_sha256') != current['adapter_sha256']:
            return None
        if receipt.get('binary_sha256') != digest(binary_path.read_bytes()):
            return None
        return receipt
    except (OSError, ValueError, TypeError, KeyError, UnicodeError):
        return None


'''

REPLACEMENTS = [
    (
        'def validate(project):\n    meta=read_project(project)\n    report=validate_source((project/\'handlers.cpp\').read_bytes(),project/\'derived/tmp\')\n',
        CACHE_HELPER +
        'def validate(project, reuse_compiled=False):\n'
        '    meta=read_project(project)\n'
        '    cached=_viewer_reusable_build(project) if reuse_compiled else None\n'
        '    report=(dict(cached[\'validation\']) if cached is not None else\n'
        '            validate_source((project/\'handlers.cpp\').read_bytes(),project/\'derived/tmp\'))\n'
    ),
    (
        'def _compile_admitted(project, meta, report, design, requested, debug=False):\n'
        '    """Compile only this request\'s freshly validated in-memory admission.\n\n'
        '    No project-authored report or previous binary can supply this context.\n'
        '    The post-compile source/design/project checks below remain mandatory.\n'
        '    """\n'
        "    if report['status']!='PASS': return {'status':'REJECTED','validation':report,'code_generation_invoked':False}\n"
        "    source=(project/'handlers.cpp').read_bytes()\n",
        'def _compile_admitted(project, meta, report, design, requested, debug=False, reuse=False, compile_token=None):\n'
        '    """Build explicitly, or reuse an identical admitted release binary for events.\n\n'
        '    Admission still rechecks the live CORE design and requested capabilities.\n'
        '    The post-compile source/design/project checks remain mandatory.\n'
        '    """\n'
        "    if report['status']!='PASS': return {'status':'REJECTED','validation':report,'code_generation_invoked':False}\n"
        '    if reuse and not debug:\n'
        '        cached=_viewer_reusable_build(project)\n'
        '        if cached is not None and all(\n'
        "                cached['validation'].get(key)==report.get(key)\n"
        "                for key in ('source_sha256','design_sha256','project_sha256',\n"
        "                            'sdk_sha256','policy_sha256','compiler_sha256')):\n"
        "            return dict(cached, code_generation_invoked=False, cache_hit=True)\n"
        "    source=(project/'handlers.cpp').read_bytes()\n"
        "    _viewer_compile_signal(project, compile_token)\n"
    ),
    (
        "        result['debug_symbols']=debug\n"
        "        write_json(project/('derived/debug-build.json' if debug else 'derived/build.json'),result)\n",
        "        result['debug_symbols']=debug\n"
        "        if not debug:\n"
        "            fingerprints=_viewer_compilation_cache_fingerprints(project)\n"
        "            if any(fingerprints.get(key)!=report.get(key) for key in\n"
        "                   ('source_sha256','design_sha256','project_sha256','sdk_sha256',\n"
        "                    'policy_sha256','compiler_sha256')) or (\n"
        "                    fingerprints['adapter_sha256']!=result['adapter_sha256']):\n"
        "                raise DevelopmentError('Build inputs changed during compilation','SOURCE_CHANGED')\n"
        "            result['cache_schema']='gxtxt.viewer_compilation_cache.v1'\n"
        "            result['cache_fingerprints']=fingerprints\n"
        "            result['cache_hit']=False\n"
        "        write_json(project/('derived/debug-build.json' if debug else 'derived/build.json'),result)\n"
    ),
    (
        'def run(project,event=None,state=None):\n'
        '    meta,validation,design,requested=validate(project)\n'
        '    built=_compile_admitted(project,meta,validation,design,requested)\n',
        'def run(project,event=None,state=None,compile_token=None):\n'
        '    meta,validation,design,requested=validate(project,reuse_compiled=True)\n'
        '    built=_compile_admitted(project,meta,validation,design,requested,reuse=True,compile_token=compile_token)\n'
    ),
    (
        "                        'execution':'compiled restricted C++ in isolated native worker; typed public CORE broker'}\n",
        "                        'execution':'compiled restricted C++ in isolated native worker; typed public CORE broker',\n"
        "                        'compile_cache_hit':bool(built.get('cache_hit',False)),\n"
        "                        'compiled_this_event':bool(built.get('code_generation_invoked',False))}\n"
    ),
    (
        "    parser.add_argument('--debug-token',help='Opaque request identity for source-bound debugger status/control; no command text')\n",
        "    parser.add_argument('--debug-token',help='Opaque request identity for source-bound debugger status/control; no command text')\n"
        "    parser.add_argument('--compile-token',help='Opaque GUI build-notification identity for run only')\n"
    ),
    (
        "        if arguments.operation=='init': result=initialize(project,arguments.module_id)\n",
        "        if arguments.compile_token is not None and (arguments.operation!='run' or not re.fullmatch(r'[a-zA-Z0-9_-]{1,96}',arguments.compile_token)):\n"
        "            raise DevelopmentError('Invalid GUI compile-notice identity','REQUEST_LIMIT')\n"
        "        if arguments.operation=='init': result=initialize(project,arguments.module_id)\n"
    ),
    (
        "            elif arguments.operation=='run': result=run(project,arguments.event,arguments.state)\n",
        "            elif arguments.operation=='run': result=run(project,arguments.event,arguments.state,arguments.compile_token)\n"
    ),
]

GUI_PROCS = r'''# Per-event, nonmodal Tk notice. No Script Job stderr/stdout changes.
proc ::GX::_viewerDevelopmentCompilePoll {window token} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || ![winfo exists $window]} return
    set record [dict get $::GX::ViewerDevelopment::windows $window]
    if {![dict exists $record compile_token] || [dict get $record compile_token] ne $token} return
    set marker [file join [dict get $record project] derived tmp viewer-compiling-${token}.marker]
    if {[file isfile $marker] && ![dict exists $record compile_notice_shown]} {
        dict set ::GX::ViewerDevelopment::windows $window compile_notice_shown 1
        set notice ${window}.cppBuildNotice
        if {![winfo exists $notice]} {
            toplevel $notice
            wm title $notice {GX-TXT - C++ compilation}
            wm transient $notice $window
            wm resizable $notice 0 0
            ttk::label $notice.message -text {Compilazione C++ del viewer in corso...} -padding {22 18}
            pack $notice.message -fill both -expand 1
        }
    }
    after 100 [list ::GX::_viewerDevelopmentCompilePoll $window $token]
}
proc ::GX::_viewerDevelopmentCompileFinish {window} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    set record [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict exists $record compile_token]} {
        set token [dict get $record compile_token]
        set marker [file join [dict get $record project] derived tmp viewer-compiling-${token}.marker]
        catch {file delete -- $marker}
        dict unset ::GX::ViewerDevelopment::windows $window compile_token
    }
    if {[dict exists $record compile_notice_shown]} {
        dict unset ::GX::ViewerDevelopment::windows $window compile_notice_shown
    }
    if {[winfo exists ${window}.cppBuildNotice]} {destroy ${window}.cppBuildNotice}
}
'''

GUI_REPLACEMENTS = [
    (
        "foreach key [dict keys $options] {if {$key ni {module_id event state file source request_json breakpoints target document debug_token}} {error {Unknown restricted development option}}}\n",
        "foreach key [dict keys $options] {if {$key ni {module_id event state file source request_json breakpoints target document debug_token compile_token}} {error {Unknown restricted development option}}}\n"
    ),
    (
        "    if {[dict exists $options debug_token]} {\n",
        "    if {[dict exists $options compile_token]} {\n"
        "        set token [dict get $options compile_token]\n"
        "        if {$operation ne {run} || ![regexp {^[a-zA-Z0-9_-]{1,96}$} $token]} {error {Invalid GUI compile-notice token}}\n"
        "        lappend command --compile-token $token\n"
        "    }\n"
        "    if {[dict exists $options debug_token]} {\n"
    ),
    (
        "proc ::GX::viewerDevelopmentInvoke {window action} {\n",
        GUI_PROCS + "proc ::GX::viewerDevelopmentInvoke {window action} {\n"
    ),
    (
        "    dict incr r generation;set generation [dict get $r generation]\n"
        "    set request [viewerDevelopmentRequest run [dict get $r project] [list ::GX::_viewerDevelopmentRan $window $generation] [dict create event [dict create kind $kind component $component value $value] state [dict get $r state]]]\n"
        "    dict set r busy $request;dict set r status RUNNING\n",
        "    dict incr r generation;set generation [dict get $r generation]\n"
        "    set token [format {compile_%d_%d} [pid] [clock microseconds]]\n"
        "    set request [viewerDevelopmentRequest run [dict get $r project] [list ::GX::_viewerDevelopmentRan $window $generation] [dict create event [dict create kind $kind component $component value $value] state [dict get $r state] compile_token $token]]\n"
        "    dict set r busy $request;dict set r status RUNNING;dict set r compile_token $token\n"
    ),
    (
        "    [dict get $::GX::ViewerGui::instances $window slots status] configure -text {C++ Demo · native event running in its bounded worker…}\n"
        "    return [dict create status submitted request $request]\n",
        "    [dict get $::GX::ViewerGui::instances $window slots status] configure -text {C++ Demo · native event running in its bounded worker…}\n"
        "    after 100 [list ::GX::_viewerDevelopmentCompilePoll $window $token]\n"
        "    return [dict create status submitted request $request]\n"
    ),
    (
        "    dict set ::GX::ViewerDevelopment::windows $window busy {}\n"
        "    set status FAILED\n",
        "    ::GX::_viewerDevelopmentCompileFinish $window\n"
        "    dict set ::GX::ViewerDevelopment::windows $window busy {}\n"
        "    set status FAILED\n"
    ),
    (
        '    [dict get $::GX::ViewerGui::instances $window slots status] configure -text "Restricted Viewer · $status"\n',
        '    set compileDetail {}\n'
        '    if {$status eq {COMPLETED} && [dict get $response ok]} {\n'
        '        set result [dict get $response result]\n'
        '        if {[dict exists $result compile_cache_hit]} {\n'
        '            set compileDetail [expr {[dict get $result compile_cache_hit] ? { (C++ binary reused)} : { (C++ compiled)}}]\n'
        '        }\n'
        '    }\n'
        '    [dict get $::GX::ViewerGui::instances $window slots status] configure -text "Restricted Viewer · $status$compileDetail"\n'
    ),
    (
        "    set request [dict get $::GX::ViewerDevelopment::windows $window busy]\n"
        "    if {$request ne {}} {scriptJobRequestCancel $request closed}\n",
        "    set request [dict get $::GX::ViewerDevelopment::windows $window busy]\n"
        "    ::GX::_viewerDevelopmentCompileFinish $window\n"
        "    if {$request ne {}} {scriptJobRequestCancel $request closed}\n"
    ),
]


def blob_sha1(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def _replace_anchors(raw: bytes, replacements, target: Path) -> bytes:
    value=raw.decode('utf-8')
    for old, new in replacements:
        if value.count(old) != 1:
            raise ValueError(f'Unexpected or repeated original anchor in {target}; nothing changed')
        value=value.replace(old,new,1)
    return value.encode('utf-8')


def make_patch(original: bytes, gui_original: bytes) -> tuple[bytes, bytes]:
    if blob_sha1(original) != SOURCE_GIT_BLOB:
        raise ValueError('Python source is not the original GitHub dev108 blob')
    if blob_sha1(gui_original) != GUI_SOURCE_GIT_BLOB:
        raise ValueError('Tcl source is not the original GitHub dev108 blob')
    python=_replace_anchors(original, REPLACEMENTS, TARGET)
    ast.parse(python.decode('utf-8'), filename=str(TARGET))
    compile(python, str(TARGET), 'exec')
    gui=_replace_anchors(gui_original,GUI_REPLACEMENTS,GUI_TARGET)
    return python,gui


def atomic_write(path: Path, data: bytes, mode: int):
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb',prefix='.gxtxt-viewer-patch-',dir=path.parent,delete=False) as fp:
            temporary = Path(fp.name)
            fp.write(data)
            fp.flush()
            os.fsync(fp.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary,path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def _original_sources(root: Path):
    if (root/'VERSION.txt').read_text(encoding='utf-8').strip() != EXPECTED_VERSION:
        raise ValueError('VERSION.txt does not identify GX-TXT dev108')
    originals={}
    for rel, blob in ((TARGET,SOURCE_GIT_BLOB),(GUI_TARGET,GUI_SOURCE_GIT_BLOB)):
        target=root/rel
        if not target.is_file() or target.is_symlink() or target.stat().st_nlink != 1:
            raise ValueError(f'Non-ordinary or absent target: {rel}')
        raw=target.read_bytes()
        if blob_sha1(raw)!=blob:
            raise ValueError(f'Target differs from exact public dev108 Git blob: {rel}')
        originals[rel]=(raw,stat.S_IMODE(target.stat().st_mode))
    return originals


def apply(root: Path, dry_run: bool):
    originals=_original_sources(root)
    patched=make_patch(originals[TARGET][0],originals[GUI_TARGET][0])
    changes={TARGET:patched[0],GUI_TARGET:patched[1]}
    checksums={str(rel):hashlib.sha256(raw).hexdigest() for rel,raw in changes.items()}
    if dry_run:
        print('CHECK OK: GitHub commit',SOURCE_COMMIT)
        print('CHECK OK: Python Git blob',SOURCE_GIT_BLOB)
        print('CHECK OK: Tcl GUI Git blob',GUI_SOURCE_GIT_BLOB)
        print('CHECK OK: Python syntax and anchored Tcl source edits')
        for rel,checksum in checksums.items():print('PATCHED SHA256:',rel,checksum)
        print('CHECK OK: no changes made')
        return
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup_dir=root/'.gxtxt_patch_backups'/(PATCH_ID+'_'+stamp)
    if backup_dir.exists():raise ValueError('Backup already exists; retry after one second')
    backup_dir.mkdir(parents=True,exist_ok=False)
    manifest={'patch_id':PATCH_ID,'source_commit':SOURCE_COMMIT,'version':EXPECTED_VERSION,'files':[]}
    for rel,(raw,mode) in originals.items():
        destination=backup_dir/rel
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(raw)
        if destination.read_bytes()!=raw:raise ValueError('Backup verification failed: '+str(rel))
        manifest['files'].append(dict(path=str(rel),git_blob=blob_sha1(raw),
                original_mode=mode,patched_sha256=checksums[str(rel)]))
    (backup_dir/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    installed=[]
    try:
        for rel,(raw,mode) in originals.items():
            # Recheck both sources immediately before modifying them.
            if (root/rel).read_bytes()!=raw:raise ValueError('Concurrent modification: '+str(rel))
        for rel,(raw,mode) in originals.items():
            atomic_write(root/rel,changes[rel],mode)
            installed.append(rel)
            if hashlib.sha256((root/rel).read_bytes()).hexdigest()!=checksums[str(rel)]:
                raise ValueError('Installed checksum does not match: '+str(rel))
    except Exception:
        for rel in reversed(installed):
            try:atomic_write(root/rel,originals[rel][0],originals[rel][1])
            except OSError:pass
        raise
    print('APPLIED: GX-TXT dev108 C++ viewer cache and Tk compile notice')
    for rel in changes:print('  ',root/rel)
    print('BACKUP:',backup_dir)
    print('ROLLBACK: python3 backport.py',root,'--rollback',backup_dir)


def rollback(root: Path, directory: Path):
    backup_dir=directory.resolve(strict=True)
    if backup_dir.parent != (root/'.gxtxt_patch_backups').resolve():
        raise ValueError('Rollback directory does not belong to this GX-TXT installation')
    record=json.loads((backup_dir/'manifest.json').read_text(encoding='utf-8'))
    if record.get('patch_id')!=PATCH_ID or record.get('version')!=EXPECTED_VERSION:
        raise ValueError('Unrecognized rollback manifest')
    restored={}
    expected={str(TARGET):SOURCE_GIT_BLOB,str(GUI_TARGET):GUI_SOURCE_GIT_BLOB}
    files=record.get('files',[])
    if {item.get('path') for item in files}!=set(expected) or len(files)!=len(expected):
        raise ValueError('Unexpected rollback file list')
    for item in files:
        name=item['path']; rel=Path(name)
        original=(backup_dir/rel).read_bytes()
        target=root/rel
        if blob_sha1(original)!=expected[name] or item.get('git_blob')!=expected[name]:
            raise ValueError('Invalid original Git blob in backup: '+name)
        if not target.is_file() or target.is_symlink() or target.stat().st_nlink!=1:
            raise ValueError('Invalid rollback target: '+name)
        current=target.read_bytes()
        if hashlib.sha256(current).hexdigest()!=item.get('patched_sha256'):
            raise ValueError('File changed since patch; rollback refused: '+name)
        restored[rel]=(original,item['original_mode'],current)
    completed=[]
    try:
        for rel,(raw,mode,current) in restored.items():
            atomic_write(root/rel,raw,mode)
            completed.append(rel)
            if (root/rel).read_bytes()!=raw:raise ValueError('Rollback checksum failure: '+str(rel))
    except Exception:
        for rel in reversed(completed):
            try:atomic_write(root/rel,restored[rel][2],restored[rel][1])
            except OSError:pass
        raise
    print('RESTORED: original public GX-TXT dev108 Python and Tcl sources')
    for rel in restored: print('  ',root/rel)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('framework',type=Path,help='GX-TXT dev108 root containing VERSION.txt')
    action=parser.add_mutually_exclusive_group(required=True)
    action.add_argument('--check',action='store_true',help='Read-only preflight')
    action.add_argument('--apply',action='store_true',help='Apply with verified backup')
    action.add_argument('--rollback',type=Path,metavar='BACKUP_DIRECTORY')
    args=parser.parse_args()
    root=args.framework.resolve(strict=True)
    try:
        if args.rollback: rollback(root,args.rollback)
        else: apply(root,dry_run=args.check)
    except (ValueError,OSError,UnicodeError,SyntaxError) as exc:
        parser.exit(2,'REFUSED: '+str(exc)+'\n')

if __name__=='__main__':
    main()
