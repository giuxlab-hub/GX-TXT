function tdfft_print_extra(fig,outdir,primary_file,format)
% Write an optional vector/portable companion while keeping the Graph Provider PNG authoritative.
% SPDX-License-Identifier: GPL-3.0-or-later
  format=lower(strtrim(format));if(isempty(format)||strcmp(format,'none')),return;endif
  [~,base,~]=fileparts(primary_file);target=fullfile(outdir,[base '.' format]);
  switch(format)
    case 'pdf'
      print(fig,target,'-dpdf','-color');
    case 'svg'
      print(fig,target,'-dsvg');
    otherwise
      error('analysis.time_dependent_fft: unsupported additional plot format: %s',format);
  endswitch
endfunction
