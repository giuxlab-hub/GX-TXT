function analysis_time_dependent_fft_render(outdir,cfg,D)
% Render time-dependent FFT products from the compact Render Cache.
% Scientific FFT computation and canonical Dataset publication are not repeated here.
% SPDX-License-Identifier: GPL-3.0-or-later
  if(!isfield(D,'plot_cache')),error('analysis.time_dependent_fft render: compact plot cache is missing; recalculate once with module 1.3.0');endif
  enabled=parse_list(gxtxt_ini_get(cfg,'graph_provider.enabled','analysis.time_dependent_fft.time_frequency_2d;analysis.time_dependent_fft.time_frequency_surface'));
  gxtxt_setup_graphics();pcfg=gxtxt_plot_config();

  window_graph='analysis.time_dependent_fft.window_spectra';selected=(1:D.window_count)';
  need_selected=any(strcmp(enabled,window_graph)) || strcmpi(strtrim(gxtxt_ini_get(cfg,'config.split_export','none')),'selected_windows') || ...
    strcmpi(strtrim(gxtxt_ini_get(cfg,'plot.analysis.time_dependent_fft.time_frequency_2d.window_scope','all')),'selected') || ...
    strcmpi(strtrim(gxtxt_ini_get(cfg,'plot.analysis.time_dependent_fft.time_frequency_surface.window_scope','all')),'selected');
  if(need_selected),selected=tdfft_select_windows(cfg,window_graph,D.time_centers,D.member_ids);endif

  window_index_path=fullfile(outdir,'window_plot_index.txt');
  write_text(window_index_path,'Individual window plot export is disabled or the Window spectrum plots graph is disabled.\n');

  if(any(strcmp(enabled,'analysis.time_dependent_fft.time_frequency_2d'))),render_heatmap(outdir,cfg,D,pcfg,selected);endif
  if(any(strcmp(enabled,'analysis.time_dependent_fft.time_frequency_surface'))),render_surface(outdir,cfg,D,pcfg,selected);endif
  if(any(strcmp(enabled,window_graph)))
    render_window_spectra(outdir,cfg,D,pcfg,selected,window_index_path);
  else
    cleanup_dir(fullfile(outdir,'window_plots'));
  endif
endfunction

function render_heatmap(outdir,cfg,D,pcfg,selected)
  graph='analysis.time_dependent_fft.time_frequency_2d';widx=overview_windows(cfg,graph,D,selected);
  maxw=parse_nonnegative(gxtxt_ini_get(cfg,['plot.' graph '.max_windows'],'256'),256);maxf=parse_nonnegative(gxtxt_ini_get(cfg,['plot.' graph '.max_frequency_bins'],'2048'),2048);
  reduction=lower(strtrim(gxtxt_ini_get(cfg,['plot.' graph '.reduction'],'peak')));G=tdfft_reduce_grid(D,widx,maxw,maxf,reduction);
  t=G.time;f=G.frequency;Z=G.Z;
  [td,tdu,tf]=safe_scale(t,D.time_unit,gxtxt_plot_axis_unit_mode(cfg,graph,'x','auto'));[fd,fdu,ff]=safe_scale(f,'Hz',gxtxt_plot_axis_unit_mode(cfg,graph,'y','auto'));
  cs=gxtxt_plot_color_settings(cfg,graph,pcfg);cmode=cs.color_unit;if(isempty(strtrim(cmode))||strcmpi(cmode,'inherit')),cmode='auto';endif
  [Zd,zdu,zf]=safe_color_scale(Z,D.value_unit,cmode);
  fig=gxtxt_plot_new_figure(pcfg);ax=axes('parent',fig);set(ax,'tag','gxtxt_primary_axis');
  unwind_protect
    [XX,YY]=meshgrid(td(:)',fd(:));surface(ax,XX,YY,zeros(size(XX)),Zd','edgecolor','none');view(ax,2);axis(ax,'tight');
    gxtxt_plot_set_axis_metadata(ax,'x','time',D.time_unit,tdu,tf,0);gxtxt_plot_set_axis_metadata(ax,'y','frequency','Hz',fdu,ff,0);gxtxt_plot_set_axis_metadata(ax,'c','spectral_value',D.value_unit,zdu,zf,0);
    xlabel(ax,tdfft_config_label(cfg,graph,'x_label','Time',tdu),'interpreter','none');ylabel(ax,tdfft_config_label(cfg,graph,'y_label','Frequency',fdu),'interpreter','none');
    title(ax,strtrim(gxtxt_ini_get(cfg,['plot.' graph '.title'],'Time-dependent FFT')),'interpreter','none');gxtxt_plot_apply_axes(ax,pcfg);gxtxt_plot_axis_overrides(ax,graph,{},pcfg,cfg);
    if(!explicit_colorbar(cfg,graph)),cs.colorbar_visible=true;endif
    clabel=strtrim(gxtxt_ini_get(cfg,['plot.' graph '.color_label'],'auto'));if(isempty(clabel)||strcmpi(clabel,'auto')),clabel=tdfft_axis_label(D.value_name,zdu);endif
    gxtxt_plot_apply_color_settings(ax,cs,clabel);primary='01_time_frequency.png';gxtxt_print_png_atomic(fig,fullfile(outdir,primary),pcfg.dpi);tdfft_print_extra(fig,outdir,primary,gxtxt_ini_get(cfg,['plot.' graph '.extra_format'],'none'));
  unwind_protect_cleanup
    close(fig);
  end_unwind_protect
endfunction

function render_surface(outdir,cfg,D,pcfg,selected)
  graph='analysis.time_dependent_fft.time_frequency_surface';widx=overview_windows(cfg,graph,D,selected);
  maxw=parse_nonnegative(gxtxt_ini_get(cfg,['plot.' graph '.max_windows'],'128'),128);maxf=parse_nonnegative(gxtxt_ini_get(cfg,['plot.' graph '.max_frequency_bins'],'1024'),1024);
  reduction=lower(strtrim(gxtxt_ini_get(cfg,['plot.' graph '.reduction'],'mean')));G=tdfft_reduce_grid(D,widx,maxw,maxf,reduction);
  t=G.time;f=G.frequency;Z=G.Z;
  [td,tdu,tf]=safe_scale(t,D.time_unit,gxtxt_plot_axis_unit_mode(cfg,graph,'x','auto'));[fd,fdu,ff]=safe_scale(f,'Hz',gxtxt_plot_axis_unit_mode(cfg,graph,'y','auto'));
  [Zd,zdu,zf]=safe_scale(Z,D.value_unit,gxtxt_plot_axis_unit_mode(cfg,graph,'z','auto'));cs=gxtxt_plot_color_settings(cfg,graph,pcfg);cmode=cs.color_unit;if(isempty(strtrim(cmode))||strcmpi(cmode,'inherit')),cmode='auto';endif
  [Cd,cdu,cf]=safe_color_scale(Z,D.value_unit,cmode);fig=gxtxt_plot_new_figure(pcfg);ax=axes('parent',fig);set(ax,'tag','gxtxt_primary_axis');
  unwind_protect
    gxtxt_plot_surface(ax,td,fd,Zd',Cd');gxtxt_plot_set_axis_metadata(ax,'x','time',D.time_unit,tdu,tf,0);gxtxt_plot_set_axis_metadata(ax,'y','frequency','Hz',fdu,ff,0);
    gxtxt_plot_set_axis_metadata(ax,'z','spectral_value',D.value_unit,zdu,zf,0);gxtxt_plot_set_axis_metadata(ax,'c','spectral_value',D.value_unit,cdu,cf,0);
    xlabel(ax,tdfft_config_label(cfg,graph,'x_label','Time',tdu),'interpreter','none');ylabel(ax,tdfft_config_label(cfg,graph,'y_label','Frequency',fdu),'interpreter','none');zlabel(ax,tdfft_config_label(cfg,graph,'z_label',D.value_name,zdu),'interpreter','none');
    title(ax,strtrim(gxtxt_ini_get(cfg,['plot.' graph '.title'],'Time-dependent FFT - 3D surface')),'interpreter','none');gxtxt_plot_apply_axes3d(ax,pcfg);gxtxt_plot_axis_overrides(ax,graph,{},pcfg,cfg);
    if(!explicit_colorbar(cfg,graph)),cs.colorbar_visible=true;endif;gxtxt_plot_apply_color_settings(ax,cs,tdfft_axis_label(D.value_name,cdu));
    primary='02_time_frequency_surface.png';gxtxt_print_png_atomic(fig,fullfile(outdir,primary),pcfg.dpi);tdfft_print_extra(fig,outdir,primary,gxtxt_ini_get(cfg,['plot.' graph '.extra_format'],'none'));
  unwind_protect_cleanup
    close(fig);
  end_unwind_protect
endfunction

function render_window_spectra(outdir,cfg,D,pcfg,selected,index_path)
  graph='analysis.time_dependent_fft.window_spectra';maxf=parse_nonnegative(gxtxt_ini_get(cfg,['plot.' graph '.max_frequency_bins'],'8192'),8192);
  G=tdfft_reduce_grid(D,selected,0,maxf,'peak');f=G.frequency;[fd,fdu,ff]=safe_scale(f,'Hz',gxtxt_plot_axis_unit_mode(cfg,graph,'x','auto'));[Zd,zdu,zf]=safe_scale(G.Z,D.value_unit,gxtxt_plot_axis_unit_mode(cfg,graph,'y','auto'));
  preview=lower(strtrim(gxtxt_ini_get(cfg,['plot.' graph '.preview_mode'],'first_selected')));if(!any(strcmp(preview,{'first_selected','overlay_selected'}))),preview='first_selected';endif
  fig=gxtxt_plot_new_figure(pcfg);ax=axes('parent',fig);set(ax,'tag','gxtxt_primary_axis');hold(ax,'on');handles=[];labels={};mode=lower(strtrim(gxtxt_ini_get(cfg,['plot.' graph '.legend_label_mode'],'none')));
  unwind_protect
    if(strcmp(preview,'first_selected')),rows=1;else rows=1:numel(selected);endif
    for r=rows
      h=plot(ax,fd,Zd(r,:),'-','linewidth',pcfg.line_width);handles(end+1)=h;labels{end+1}=window_label(mode,selected(r),D.time_centers(selected(r)),D.time_unit);
    endfor
    gxtxt_plot_set_axis_metadata(ax,'x','frequency','Hz',fdu,ff,0);gxtxt_plot_set_axis_metadata(ax,'y','spectral_value',D.value_unit,zdu,zf,0);
    xlabel(ax,tdfft_config_label(cfg,graph,'x_label','Frequency',fdu),'interpreter','none');ylabel(ax,tdfft_config_label(cfg,graph,'y_label',D.value_name,zdu),'interpreter','none');
    if(strcmp(preview,'first_selected'))
      title_text=expand_title(gxtxt_ini_get(cfg,['plot.' graph '.individual_title_template'],'FFT window {index} - t={time}'),selected(1),D.member_ids{selected(1)},D.time_centers(selected(1)));
    else
      title_text=strtrim(gxtxt_ini_get(cfg,['plot.' graph '.title'],'Selected FFT windows'));
    endif
    title(ax,title_text,'interpreter','none');gxtxt_plot_apply_axes(ax,pcfg);gxtxt_plot_axis_overrides(ax,graph,{},pcfg,cfg);if(strcmp(preview,'overlay_selected')&&!strcmp(mode,'none')),gxtxt_plot_legend(handles,labels,pcfg,graph,cfg);endif
    primary='03_selected_window_spectra.png';gxtxt_print_png_atomic(fig,fullfile(outdir,primary),pcfg.dpi);tdfft_print_extra(fig,outdir,primary,gxtxt_ini_get(cfg,['plot.' graph '.extra_format'],'none'));
  unwind_protect_cleanup
    close(fig);
  end_unwind_protect
  if(parse_bool(gxtxt_ini_get(cfg,['plot.' graph '.export_individual'],'1')))
    render_individual_files(outdir,cfg,D,pcfg,selected,index_path,G.frequency,G.Z);
  else
    cleanup_dir(fullfile(outdir,'window_plots'));write_text(index_path,'Individual window plot export is disabled.\n');
  endif
endfunction

function render_individual_files(outdir,cfg,D,pcfg,selected,index_path,freq,Z)
  graph='analysis.time_dependent_fft.window_spectra';fmt=lower(strtrim(gxtxt_ini_get(cfg,['plot.' graph '.individual_format'],'png')));base=sanitize_basename(gxtxt_ini_get(cfg,['plot.' graph '.individual_basename'],'fft_window'));
  template=gxtxt_ini_get(cfg,['plot.' graph '.individual_title_template'],'FFT window {index} - t={time}');dirp=fullfile(outdir,'window_plots');cleanup_dir(dirp);mkdir(dirp);
  [fd,fdu,ff]=safe_scale(freq,'Hz',gxtxt_plot_axis_unit_mode(cfg,graph,'x','auto'));[Zd,zdu,zf]=safe_scale(Z,D.value_unit,gxtxt_plot_axis_unit_mode(cfg,graph,'y','auto'));
  fid=fopen(index_path,'w');if(fid<0),error('analysis.time_dependent_fft: cannot write window plot index');endif
  unwind_protect
    fprintf(fid,'window_index\tmember_id\ttime\tfile\n');
    for q=1:numel(selected)
      wi=selected(q);fig=gxtxt_plot_new_figure(pcfg);ax=axes('parent',fig);set(ax,'tag','gxtxt_primary_axis');
      unwind_protect
        plot(ax,fd,Zd(q,:),'-','linewidth',pcfg.line_width);gxtxt_plot_set_axis_metadata(ax,'x','frequency','Hz',fdu,ff,0);gxtxt_plot_set_axis_metadata(ax,'y','spectral_value',D.value_unit,zdu,zf,0);
        xlabel(ax,tdfft_config_label(cfg,graph,'x_label','Frequency',fdu),'interpreter','none');ylabel(ax,tdfft_config_label(cfg,graph,'y_label',D.value_name,zdu),'interpreter','none');
        title(ax,expand_title(template,wi,D.member_ids{wi},D.time_centers(wi)),'interpreter','none');gxtxt_plot_apply_axes(ax,pcfg);gxtxt_plot_axis_overrides(ax,graph,{},pcfg,cfg);
        name=sprintf('%s_%04d.%s',base,wi,fmt);print_any(fig,fullfile(dirp,name),fmt,pcfg.dpi);
      unwind_protect_cleanup
        close(fig);
      end_unwind_protect
      fprintf(fid,'%d\t%s\t%.17g\t%s\n',wi,D.member_ids{wi},D.time_centers(wi),fullfile('window_plots',name));
    endfor
  unwind_protect_cleanup
    fclose(fid);
  end_unwind_protect
endfunction

function idx=overview_windows(cfg,graph,D,selected),scope=lower(strtrim(gxtxt_ini_get(cfg,['plot.' graph '.window_scope'],'all')));if(strcmp(scope,'selected')),idx=selected;else idx=(1:D.window_count)';endif;endfunction
function [d,u,f]=safe_scale(v,unit,mode),try [d,u,f]=gxtxt_plot_display_scale(v,unit,mode);catch d=v;u=unit;f=1;end_try_catch;endfunction
function [d,u,f]=safe_color_scale(v,unit,mode),try [d,u,f]=gxtxt_plot_color_scale(v,unit,mode);catch d=v;u=unit;f=1;end_try_catch;endfunction
function tf=explicit_colorbar(cfg,graph),v=strtrim(gxtxt_ini_get(cfg,['axis.' graph '.colorbar_visible'],''));tf=!isempty(v)&&!strcmpi(v,'inherit');endfunction
function n=parse_nonnegative(raw,def),n=str2double(strtrim(raw));if(!isfinite(n)||n<0||n!=fix(n)),n=def;endif;endfunction
function tf=parse_bool(raw),tf=any(strcmpi(strtrim(raw),{'1','true','yes','on'}));endfunction
function s=window_label(mode,idx,t,unit),switch mode,case 'index',s=sprintf('#%d',idx);case 'time',s=sprintf('t=%.6g %s',t,unit);case 'index_time',s=sprintf('#%d, t=%.6g %s',idx,t,unit);otherwise,s='';endswitch;endfunction
function s=expand_title(tpl,idx,member_id,t),s=strrep(tpl,'{index}',num2str(idx));s=strrep(s,'{member_id}',member_id);s=strrep(s,'{time}',sprintf('%.9g',t));endfunction
function s=sanitize_basename(s),s=regexprep(strtrim(s),'[^A-Za-z0-9_.-]','_');if(isempty(s)),s='fft_window';endif;endfunction
function print_any(fig,path,fmt,dpi),switch fmt,case 'png',gxtxt_print_png_atomic(fig,path,dpi);case 'pdf',print(fig,path,'-dpdf','-color');case 'svg',print(fig,path,'-dsvg');otherwise,error('analysis.time_dependent_fft: unsupported individual plot format: %s',fmt);endswitch;endfunction
function cleanup_dir(path),if(exist(path,'dir')==7),rmdir(path,'s');endif;endfunction
function write_text(path,text),fid=fopen(path,'w');if(fid<0),error('analysis.time_dependent_fft: cannot write %s',path);endif;unwind_protect fputs(fid,text);unwind_protect_cleanup fclose(fid);end_unwind_protect;endfunction
function out=parse_list(s),s=strrep(s,',',';');if(isempty(strtrim(s))),out={};return;endif;out=strsplit(s,';');out=cellfun(@strtrim,out,'UniformOutput',false);out=out(!cellfun(@isempty,out));endfunction
