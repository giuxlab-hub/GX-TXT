function q=ir_shell_quote(value)
% Shell-quote one local filesystem argument for the standard Octave bridge.
  q=['''' strrep(value,'''','''"''"''') ''''];
endfunction
