# Changelog

## 1.2.0 - 2026-09-24

- Added `CURVE_DIGITIZER_COMPANION_API_v1` for tightly coupled assistant modules without a second authoritative state model.
- Added stable configuration/curve context discovery and source Image Dataset integrity resolution through public GX-TXT APIs.
- Added guarded pixel-point commit that reuses the Curve Digitalizer calibration model and writes accepted points into the existing Interactive Document.
- Added document SHA-256 optimistic concurrency so an open Curve Digitalizer window cannot silently overwrite newer companion-module changes.

## 1.0.1 - 2026-09-24

- Added a source-image preview confirmation dialog when selecting a new Image Dataset for a configuration.
- Prevented accidental binding to the wrong image by requiring explicit confirmation before the source association is persisted.
- Kept packaged GUI validation deterministic by auto-accepting the preview step only in the non-interactive regression scenario.

All notable changes to `viewer.curve_digitizer` are documented here.

## 1.0.0 - 2026-09-24

- Initial GX-TXT-native release for GX-TXT 0.9.7.78.
- Reused the original Curve Digitizer homography/calibration model and interactive image canvas behavior where scientifically appropriate.
- Replaced standalone image-open, project-file, and CSV-export workflows with current GX-TXT Image Dataset selection, Session-persistent Interactive Documents, Dataset Metadata, and Dataset Publication API v2.
- Added named configurations with stable IDs, rename/duplicate/delete management, and support for multiple independent configurations per source Image Dataset.
- Added source byte integrity verification with SHA-256 and explicit missing/stale-source diagnostics.
- Added linear/log X/Y calibration, labels, units, semantic roles, calibration verification, curves, numerical curve families, point editing, undo/redo, zoom/pan, overlays, and darkest-pixel snapping.
- Added publication of independent curves as `table.generic` and numerical curve families as `curve_family.table` with stable variable IDs and preserved point order.
- Added same-owner deterministic republishing, output Dataset Metadata, Variable Schema enrichment, source Dataset lineage, and CSV artifact creation in the publication transaction.
- Added lazy Viewer Provider backend activation and interactive dependency preflight for Python/Tk/NumPy/Pillow.
- Added deterministic scientific, static host-independence, and real Xvfb/Tk integration tests.
