# GX-TXT Numerical Examples — Measurement Uncertainty

Portable Session Generator for the `demo.numeric.uncertainty` reference plugin.

It creates `raw/measurement_uncertainty_demo.csv` with five deterministic voltage measurements, their measurement standard uncertainties, and a separately labelled explicit inverse-variance reference-weight column. The plugin consumes only the normal Canonical Dataset after Acquisition; it does not read generator-private ground truth.

The weight column is generated explicitly as `1/sigma^2` for demonstration and validation. This conversion is deliberately performed by the generator, not silently by the analysis plugin.

License: GNU GPL v3 or later.
