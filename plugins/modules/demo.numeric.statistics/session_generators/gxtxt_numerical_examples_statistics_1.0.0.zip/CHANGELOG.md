# Changelog

## 1.0.0

- Initial deterministic Statistics Session Generator.
- Added explicit weights and intentional missing-value validation rows that the public CSV provider exposes as NaN.
