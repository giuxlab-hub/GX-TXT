# Statistics Session Generator

Portable GX-TXT Session Generator API v1 package for `demo.numeric.statistics`.

```text
Library: GX-TXT Numerical Examples
Generator ID: statistics
Name: Statistics
Category: Mathematics
Version: 1.0.0
```

The generated ordinary Session contains `raw/statistics_demo.csv` and `metadata/ground_truth.txt`. The CSV is deterministic and intentionally includes three missing-value markers (`NA`, `missing`, and `invalid`) that the public CSV provider exposes numerically as `NaN`, plus one zero-weight finite observation. This demonstrates the public non-finite and weight policies without relying on Tcl parsing of literal infinity tokens.

The `weight` column is an explicit statistical weight. It is not a measurement-uncertainty column.

The generated Session does not depend on this package after creation.

License: GNU GPL v3 or later.
