# Changelog

## 1.0.0

- Initial portable Session Generator API v1 release.
- Added deterministic Smoothing example data for `demo.numeric.smoothing`.
- Added clean reference, seeded Gaussian measurement noise and three fixed
  measurement spikes.
- Added generated scientific ground-truth metadata.
