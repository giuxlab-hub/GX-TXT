# Changelog

## 1.0.0 —

- Initial portable deterministic Peak Detection Session Generator for GX-TXT 0.9.7.82.
