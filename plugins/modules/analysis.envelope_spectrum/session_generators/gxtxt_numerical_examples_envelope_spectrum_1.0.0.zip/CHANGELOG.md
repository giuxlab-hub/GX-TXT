# Changelog

## 1.0.0

- Initial deterministic envelope-spectrum teaching generator.
