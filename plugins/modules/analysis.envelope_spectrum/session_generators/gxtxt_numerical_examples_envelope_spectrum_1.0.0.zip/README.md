# GX-TXT Numerical Examples — Envelope Spectrum Demodulation

Deterministic Session Generator for `analysis.envelope_spectrum`.

It creates an 8 s, 8192 Hz amplitude-modulated carrier with known 47 Hz and 93 Hz envelope components and deterministic white noise.
