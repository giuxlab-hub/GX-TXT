# Changelog

## 1.0.0 — 2026-09-24

- Initial deterministic Harmonic Analysis teaching generator.
- Added known H1-H5 amplitudes, phases, DC offset and analytical THD ground truth.
- Added complete student workflow from CSV import through FFT and Harmonic Analysis.
