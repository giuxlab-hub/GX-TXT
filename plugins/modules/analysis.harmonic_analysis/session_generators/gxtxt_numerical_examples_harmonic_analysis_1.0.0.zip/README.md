# GX-TXT Numerical Examples — Harmonic Analysis

Portable Session Generator for a coherent multi-harmonic waveform with analytical THD ground truth.

Import this package through the normal GX-TXT Session Generator Library UI/API. It creates the files needed for the student workflow; it does not install the Harmonic Analysis plugin itself.
