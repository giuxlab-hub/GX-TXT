# GX-TXT Numerical Examples — Cepstrum Analysis

Import this package into the normal GX-TXT **Session Generator Library**.

It creates a deterministic harmonic-series Session designed for `analysis.cepstrum`. The known fundamental is 128 Hz, corresponding to a 7.8125 ms fundamental period (32 samples at 4096 Hz).
