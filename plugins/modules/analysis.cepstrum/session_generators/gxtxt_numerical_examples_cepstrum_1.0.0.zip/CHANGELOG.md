# Changelog

## 1.0.0 —

- Added deterministic 128 Hz harmonic-series teaching waveform.
- Added ground-truth metadata and a student exercise for real-cepstrum analysis.
