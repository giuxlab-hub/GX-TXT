# Changelog

## 1.0.0 —

- Initial deterministic GX-TXT Numerical Examples generator for one-dimensional minimization.
