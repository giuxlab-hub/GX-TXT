# GX-TXT Numerical Examples — 1D Minimization

Portable Session Generator for `demo.numeric.minimization` 1.0.0.

It creates `raw/minimization_1d.csv` with deterministic columns `x,f` sampled from:

```text
f(x) = (x - 1.75)^2 + 2
```

on `[-3,5]` with step `0.05`. The exact reference minimum is `x=1.75`, `f=2`.

Import the CSV through normal GX-TXT Acquisition as a `table.generic` Canonical Dataset. A human/test reference file is written to `metadata/ground_truth.txt`; the analysis plugin must not read it during normal execution.

SPDX-License-Identifier: GPL-3.0-or-later
