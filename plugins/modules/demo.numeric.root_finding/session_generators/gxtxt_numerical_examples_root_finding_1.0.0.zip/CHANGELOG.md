# Changelog

## 1.0.0 —

- Initial deterministic Root Finding Session Generator.
- Added sampled cubic source data and independently documented analytical roots.
