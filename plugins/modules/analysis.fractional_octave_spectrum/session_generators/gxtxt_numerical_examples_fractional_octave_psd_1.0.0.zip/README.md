# Fractional-Octave PSD Session Generator

Creates a deterministic linear PSD from 0 to 4096 Hz with 1 Hz spacing, a known white PSD floor, and known line powers at 125, 500 and 2000 Hz. Intended for `analysis.fractional_octave_spectrum`.
