# Changelog

## 1.0.0 —

- Added deterministic coherent three-tone teaching Session for FFT-to-Spectral-Features workflows.
