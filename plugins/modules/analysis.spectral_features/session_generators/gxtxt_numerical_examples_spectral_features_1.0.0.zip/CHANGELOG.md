# Changelog

## 1.0.0 — 2026-09-24

- Added deterministic coherent three-tone teaching Session for FFT-to-Spectral-Features workflows.
