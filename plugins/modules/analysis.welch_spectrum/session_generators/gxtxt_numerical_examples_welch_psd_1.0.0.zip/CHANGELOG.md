# Changelog

## 1.0.0

- Initial deterministic Welch PSD student Session Generator.
- Added 50 Hz and 123 Hz reference tones plus seeded white Gaussian noise.
- Added ground-truth metadata and step-by-step student exercise.
