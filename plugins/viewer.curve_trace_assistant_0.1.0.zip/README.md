# GX-TXT Curve Trace Assistant

Plugin ID: `viewer.curve_trace_assistant`  
Version: `0.1.0`  
Minimum framework: GX-TXT `0.9.7.78`  
Required companion: `viewer.curve_digitizer >= 1.2.0`

This first package implements only the integration foundation required before seed-guided tracing is added.

The assistant does not own a second digitization project. It operates on the existing Session-persistent Curve Digitalizer Interactive Document through `CURVE_DIGITIZER_COMPANION_API_v1`.

Current capabilities:

- enumerate Curve Digitalizer configurations by stable Interactive Document/configuration identity;
- obtain one selected curve by stable `curve_id`;
- obtain the existing calibration and axis context without creating a second calibration model;
- resolve the associated Image Dataset through public GX-TXT Dataset APIs;
- verify source SHA-256 before an assisted write;
- commit accepted pixel points into the existing Curve Digitalizer curve;
- reuse the Curve Digitalizer calibration implementation for pixel-to-scientific conversion;
- reject stale Session/document/source state rather than silently overwriting it.

No tracing algorithm or tracing GUI is included in 0.1.0. Proposed/rejected trace state will remain transient when those features are implemented.
