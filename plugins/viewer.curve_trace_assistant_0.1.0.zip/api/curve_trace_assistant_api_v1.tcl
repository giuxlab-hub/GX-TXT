# GX-TXT Curve Trace Assistant API v1 — integration foundation
# SPDX-License-Identifier: GPL-3.0-or-later

namespace eval ::GX::CurveTraceAssistant {
    variable moduleId viewer.curve_trace_assistant
    variable version 0.1.0
    variable digitizerModule viewer.curve_digitizer
    variable digitizerApi CURVE_DIGITIZER_COMPANION_API_v1
}

proc ::GX::CurveTraceAssistant::_activateDigitizerCompanion {} {
    variable digitizerModule
    variable digitizerApi
    if {[package vcompare [::GX::moduleField $digitizerModule version "0"] 1.2.0] < 0} {
        error "Curve Trace Assistant requires viewer.curve_digitizer 1.2.0 or newer."
    }
    ::GX::modulePublicApiActivate $digitizerModule $digitizerApi
    foreach command {
        ::GX::CurveDigitizerCompanion::sessionToken
        ::GX::CurveDigitizerCompanion::configurationList
        ::GX::CurveDigitizerCompanion::configurationRead
        ::GX::CurveDigitizerCompanion::curveContext
        ::GX::CurveDigitizerCompanion::sourceResolve
        ::GX::CurveDigitizerCompanion::commitPixelPoints
    } {
        if {![llength [info commands $command]]} {
            error "Curve Digitalizer Companion API did not provide required command '$command'."
        }
    }
    return 1
}

proc ::GX::CurveTraceAssistant::sessionToken {} {
    _activateDigitizerCompanion
    return [::GX::CurveDigitizerCompanion::sessionToken]
}

proc ::GX::CurveTraceAssistant::configurationList {} {
    _activateDigitizerCompanion
    return [::GX::CurveDigitizerCompanion::configurationList]
}

proc ::GX::CurveTraceAssistant::configurationRead {documentId} {
    _activateDigitizerCompanion
    return [::GX::CurveDigitizerCompanion::configurationRead $documentId]
}

proc ::GX::CurveTraceAssistant::curveContext {documentId curveId} {
    _activateDigitizerCompanion
    return [::GX::CurveDigitizerCompanion::curveContext $documentId $curveId]
}

proc ::GX::CurveTraceAssistant::sourceResolve {documentId} {
    _activateDigitizerCompanion
    return [::GX::CurveDigitizerCompanion::sourceResolve $documentId]
}

proc ::GX::CurveTraceAssistant::commitPixelPoints {documentId curveId expectedDocumentSha sessionToken pointsText} {
    _activateDigitizerCompanion
    return [::GX::CurveDigitizerCompanion::commitPixelPoints \
        $documentId $curveId $expectedDocumentSha $sessionToken $pointsText]
}
