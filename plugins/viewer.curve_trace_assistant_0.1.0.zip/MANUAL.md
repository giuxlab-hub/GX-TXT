# Curve Trace Assistant 0.1.0 — Integration Foundation

## Purpose

This release establishes the safe integration contract between Curve Trace Assistant and Curve Digitalizer. It deliberately does not implement curve-following algorithms yet.

## Authoritative state

The authoritative scientific object remains:

```text
Curve Digitalizer Interactive Document
    configuration_id
    source Image Dataset identity/hash
    calibration
    curves
    ordered points
```

Curve Trace Assistant does not create a project file, a duplicate calibration, or an assistant-owned scientific point store.

## Public API

`CURVE_TRACE_ASSISTANT_API_v1` exposes:

- `sessionToken`
- `configurationList`
- `configurationRead`
- `curveContext`
- `sourceResolve`
- `commitPixelPoints`

The API delegates authoritative writes to `CURVE_DIGITIZER_COMPANION_API_v1` from Curve Digitalizer 1.2.0 or newer.

## Configuration and curve identity

Callers select a Curve Digitalizer Interactive Document and then a stable `curve_id`. Display labels are never used as technical identity.

## Source image

`sourceResolve` uses the Dataset identity stored in the Curve Digitalizer configuration and the public GX-TXT Dataset API. The current resolved image bytes are SHA-256 checked against the configuration before points can be committed.

## Calibration

The assistant receives the existing axis/calibration context. Accepted pixel points are transformed by the Curve Digitalizer calibration implementation during commit. The assistant does not own another calibration model.

## Commit semantics

`commitPixelPoints` appends ordered accepted pixel points to one existing curve. The write requires:

- the live Session token;
- the expected Interactive Document SHA-256;
- the stable document ID;
- the stable curve ID;
- a still-valid source Image Dataset/hash;
- a complete valid Curve Digitalizer calibration.

A changed document, changed Session or changed source image produces an explicit error.

## Rejected/proposed state

This release stores no proposal state. Future trace proposals remain transient until the user explicitly accepts them. Therefore rejecting a proposal will leave the Curve Digitalizer configuration unchanged.

## Host independence

Plugin discovery only reads descriptors. Activating the assistant API loads Tcl integration code but no Tk/Pillow GUI. The Curve Digitalizer calibration bridge invokes Python only when a state/context operation actually requires it.

## Known limitation

There is no tracing GUI or trace-following algorithm in 0.1.0. This is intentional: it completes the integration model before image-analysis behavior is added.
