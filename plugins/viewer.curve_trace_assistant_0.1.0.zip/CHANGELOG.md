# Changelog

## 0.1.0

- Added initial `CURVE_TRACE_ASSISTANT_API_v1` integration foundation.
- Added dependency on Curve Digitalizer companion API 1.2.0 or newer.
- Added configuration/curve/source context delegation.
- Added guarded accepted pixel-point commit into the existing Curve Digitalizer Interactive Document.
- No tracing algorithm or tracing GUI is included yet.
