function demo_numeric_peaks_render(outdir,x,y,result,x_name,y_name,x_unit,y_unit,cfg)
% Render source signal plus public detected-peak markers through GX-TXT graphics helpers.
% SPDX-License-Identifier: GPL-3.0-or-later
  graph='demo.numeric.peaks.detected';enabled=split_list_local(gxtxt_ini_get(cfg,'graph_provider.enabled',graph));if(!any(strcmp(enabled,graph))),return;endif
  progress_stage_safe('rendering_graphs','Rendering peak-detection graph','determinate',1);gxtxt_setup_graphics();pcfg=gxtxt_plot_config();fig=gxtxt_plot_new_figure(pcfg);hold on;
  lw=positive_number(gxtxt_ini_get(cfg,['plot.' graph '.line_width'],'1.3'),1.3);ms=positive_number(gxtxt_ini_get(cfg,['plot.' graph '.marker_size'],'8'),8);
  h1=plot(x,y,'-','linewidth',lw);handles=h1;labels={'Source signal'};
  if(result.n>0),h2=plot(result.x,result.heights,'o','linestyle','none','markersize',ms,'linewidth',max(1,lw));handles=[handles h2];labels{end+1}='Detected peaks';endif
  xlabel(axis_label(gxtxt_ini_get(cfg,['plot.' graph '.x_label'],'auto'),x_name,x_unit));ylabel(axis_label(gxtxt_ini_get(cfg,['plot.' graph '.y_label'],'auto'),y_name,y_unit));title(gxtxt_ini_get(cfg,['plot.' graph '.title'],'Peak detection demo'));gxtxt_plot_apply_axes(gca(),pcfg);gxtxt_plot_legend(handles,labels,pcfg,graph,cfg);gxtxt_print_png_atomic(fig,fullfile(outdir,'01_peak_detection.png'),pcfg.dpi);close(fig);progress_update_safe(1,1);
endfunction
function s=axis_label(raw,name,unit),if(!strcmpi(strtrim(raw),'auto')),s=raw;return;endif;s=strrep(strtrim(name),'_',' ');if(!isempty(strtrim(unit))),s=[s ' [' strtrim(unit) ']'];endif,endfunction
function v=positive_number(raw,def),v=str2double(raw);if(!isfinite(v)||v<=0),v=def;endif,endfunction
function out=split_list_local(raw),raw=strrep(raw,',',';');parts=strsplit(raw,';');out={};for k=1:numel(parts),q=strtrim(parts{k});if(!isempty(q)),out{end+1}=q;endif,endfor,endfunction
function progress_stage_safe(stage,message,mode,total),if(exist('gxtxt_progress_stage','file')!=2),return;endif;try,gxtxt_progress_stage(stage,message,mode,total);catch;end_try_catch,endfunction
function progress_update_safe(current,total),if(exist('gxtxt_progress_update','file')!=2),return;endif;try,gxtxt_progress_update(current,total,'rendering_graphs','Rendering peak-detection graph');catch;end_try_catch,endfunction
