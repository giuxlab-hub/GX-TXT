# Changelog

## 1.0.0 — 2026-09-24

- Initial external `demo.numeric.peaks` reference plugin for GX-TXT 0.9.7.82.
- Added Dataset-aware `NUMERIC_API_v1 dataset_find_peaks` execution, detected-peak Dataset Publication, report and automatic graph.
- Added portable deterministic `GX-TXT Numerical Examples → Mathematics → Peak Detection` Session Generator package.
