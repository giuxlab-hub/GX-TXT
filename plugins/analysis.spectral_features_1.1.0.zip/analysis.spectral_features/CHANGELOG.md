# Changelog

## 1.1.0 — 2026-09-25

- Added explicit `math.numeric` dependency and migrated generic grid/reduction operations to public `NUMERIC_API_v1`.
- Extended `math.numeric` 1.4.0 with generic `weighted_quantiles` and `cumulative_sum` primitives required by this consumer.
- Published a reusable plot-ready distribution Dataset instead of private render-cache state.
- Migrated all scientific result graphics to persistent `plot.dataset` / `PLOT_DATASET_API_v2` variants.
- Removed the private Octave renderer and rerender path.

## 1.0.0 — 2026-09-24

- Added `analysis.spectral_features` as an external Dataset-native spectrum consumer.
- Added dominant/centroid/RMS/bandwidth, cumulative-frequency, occupied-bandwidth, flatness, crest-factor and entropy descriptors.
- Added explicit amplitude/power/PSD semantics and optional DC exclusion.
- Added canonical summary Dataset publication, report, metrics, cache-only graph variants, tests, and a portable student Session Generator.
