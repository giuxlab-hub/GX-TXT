# SPDX-License-Identifier: GPL-3.0-or-later
# Thin C++ source-notebook adapter to the same common source-note editor.
proc ::GX::ViewerDevelopmentWorkspace::projectNotesActive {} {
    variable s
    if {![info exists s(notes)] || ![winfo exists .gxViewerDevelopment.body.center.sources]} {return {}}
    set selected [.gxViewerDevelopment.body.center.sources select]
    dict for {name note} $s(notes) {if {[dict get $note page] eq $selected} {return $name}}
    return {}
}
proc ::GX::ViewerDevelopmentWorkspace::projectNoteRef {name} {
    return [dict create owner cpp_viewer_project reference [dict create relative $name]]
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesShow {{visible 1}} {
    variable s
    if {$s(mode) ne {cpp} || $s(project) eq {} || $s(busy) ne {}} {error {Open an idle C++ source project first}}
    set name $s(file);set book .gxViewerDevelopment.body.center.sources
    if {$name ni [::GX::viewerDevelopmentSourceFiles $s(project)]} {error {Choose a declared C++ source or header}}
    if {!$visible} {
        if {[dict exists $s(notes) $name]} {set page [dict get $s(notes) $name page];if {$page in [$book tabs]} {$book forget $page;$book select [dict get $s(tabs) $name page]}}
        set s(showNotes) 0;return
    }
    if {![dict exists $s(notes) $name]} {
        set page $book.notes[incr s(tabSerial)];ttk::frame $page
        set cap [dict get [::GX::_datasetPrivateModuleContext viewer.development_workspace] capability]
        if {[catch {set handle [::GX::sourceNoteEditorMount $page.editor $cap [projectNoteRef $name] [dict create on_change [list ::GX::ViewerDevelopmentWorkspace::projectNotesChanged $name] on_saved ::GX::ViewerDevelopmentWorkspace::projectNotesSaved]]} reason options]} {destroy $page;return -options $options $reason}
        pack $page.editor -fill both -expand 1
        dict set s(notes) $name [dict create page $page editor $handle]
    }
    set note [dict get $s(notes) $name];set page [dict get $note page]
    if {$page ni [$book tabs]} {
        set at [expr {[$book index [dict get $s(tabs) $name page]]+1}];if {$at>=[llength [$book tabs]]} {set at end}
        $book insert $at $page -text "$name — Notes"
    }
    $book select $page;set s(showNotes) 1
    focus [dict get [::GX::_documentEditorRecord [dict get $note editor]] source]
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesToggle {} {variable s;projectNotesShow $s(showNotes)}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesChanged {name handle receipt} {
    variable s
    if {![info exists s(notes)] || ![dict exists $s(notes) $name]} return
    set page [dict get $s(notes) $name page];set book .gxViewerDevelopment.body.center.sources
    if {$page in [$book tabs]} {$book tab $page -text "$name — Notes[expr {[dict get $receipt dirty]?{ *}:{}}]"}
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesSaved {handle receipt} {
    variable s
    set s(projectHash) [dict get $receipt source owner_revision]
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesReview {{name {}}} {
    variable s
    if {![info exists s(notes)]} {return 1}
    dict for {source note} $s(notes) {
        if {$name ne {} && $source ne $name} continue
        if {![::GX::sourceNoteEditorReview [dict get $note editor]]} {return 0}
    }
    return 1
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesDispose {name} {
    variable s
    if {![dict exists $s(notes) $name]} return
    destroy [dict get $s(notes) $name page];dict unset s(notes) $name
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesSaveAll {} {
    variable s
    dict for {name note} $s(notes) {
        set handle [dict get $note editor]
        if {[dict get [::GX::documentEditorCommand $handle inspect] dirty] && ![::GX::sourceNoteEditorSaveSafe $handle]} {return 0}
        ::GX::sourceNoteEditorSnapshot $handle
    }
    return 1
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesSourceUpdated {} {
    variable s
    if {![info exists s(notes)]} return
    dict for {name note} $s(notes) {
        if {$name ni [::GX::viewerDevelopmentSourceFiles $s(project)]} continue
        ::GX::sourceNoteEditorSourceUpdated [dict get $note editor] [projectNoteRef $name] [dict create owner_revision $s(projectHash)]
    }
}
proc ::GX::ViewerDevelopmentWorkspace::projectNotesSnapshotExport {} {
    variable s
    set cap [dict get [::GX::_datasetPrivateModuleContext viewer.development_workspace] capability]
    foreach name [::GX::viewerDevelopmentSourceFiles $s(project)] {
        set ref [projectNoteRef $name];set note [::GX::sourceNoteRead $cap $ref]
        if {[dict get $note state] eq {canonical}} {
            set result [::GX::sourceNoteSnapshotRef $cap $ref $note]
            ::GX::_sourceNoteEditorOwnerCommitted {} $result
            set s(projectHash) [dict get [sourceNoteOwner describe [dict create relative $name]] owner_revision]
            if {[::GX::datasetPublicationV2DictDefault $result assets_present 0]} {
                set inert [::GX::datasetPublicationV2DictDefault [dict get $result source] asset_snapshots {}]
                if {[lsort [dict keys $inert]] ne [lsort [dict keys [dict get $result assets]]]} {error {Source image snapshot closure is incomplete}}
                dict for {name resource} [dict get $result assets] {if {[dict get $inert $name sha256] ne [dict get $resource sha256]} {error {Source image snapshot identity differs}}}
            }
        }
    }
}
