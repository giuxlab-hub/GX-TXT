# SPDX-License-Identifier: GPL-3.0-or-later
# Dataset consultation shares the installed native engine; no script evaluation.
namespace eval ::GX::DocumentSource {variable serial 0;variable zoom {}}
proc ::GX::documentPresentationZoomAttach {widget {bodyFont TkDefaultFont}} {
    variable ::GX::DocumentSource::zoom
    documentPresentationZoomDispose $widget $widget
    set fonts {};set byRole {}
    foreach {role base} {body TkDefaultFont heading TkHeadingFont bold TkDefaultFont italic TkDefaultFont code TkFixedFont} {
        if {$role eq {body}} {set base $bodyFont}
        set options [font actual $base]
        if {$role eq {bold}} {dict set options -weight bold}
        if {$role eq {italic}} {dict set options -slant italic}
        set name [font create {*}$options]
        lappend fonts [list $name [dict get $options -size]];dict set byRole $role $name
    }
    $widget configure -font [dict get $byRole body]
    foreach role {heading bold italic} {$widget tag configure $role -font [dict get $byRole $role]}
    foreach role {code tag attribute string} {$widget tag configure $role -font [dict get $byRole code]}
    dict set zoom $widget [dict create factor 1.0 fonts $fonts]
    set tag GXDocumentZoom:$widget
    if {$tag ni [bindtags $widget]} {bindtags $widget [linsert [bindtags $widget] 1 $tag]}
    foreach {sequence action} {<Control-plus> in <Control-equal> in <Control-minus> out <Control-0> reset} {bind $tag $sequence "[list ::GX::documentPresentationZoom $widget $action];break"}
    bind $tag <Destroy> [list ::GX::documentPresentationZoomDispose $widget %W]
}
proc ::GX::documentPresentationZoomDispose {widget actual} {
    variable ::GX::DocumentSource::zoom
    if {$widget ne $actual || ![dict exists $zoom $widget]} return
    foreach font [dict get $zoom $widget fonts] {catch {font delete [lindex $font 0]}}
    dict unset zoom $widget
    set tag GXDocumentZoom:$widget
    catch {foreach sequence [bind $tag] {bind $tag $sequence {}}}
}
proc ::GX::documentPresentationZoom {widget action} {
    variable ::GX::DocumentSource::zoom
    if {![dict exists $zoom $widget] || ![winfo exists $widget]} {return {}}
    set factor [dict get $zoom $widget factor]
    switch -- $action {in {set factor [expr {min(3.0,$factor+.25)}]} out {set factor [expr {max(.5,$factor-.25)}]} reset {set factor 1.0} current {} default {error {Document zoom action must be in, out or reset}}}
    set view [$widget yview]
    foreach font [dict get $zoom $widget fonts] {
        lassign $font name size
        set scaled [expr {max(4,round(abs($size)*$factor))}]
        font configure $name -size [expr {$size<0?-$scaled:$scaled}]
    }
    dict set zoom $widget factor $factor
    if {[dict exists $zoom $widget label] && [winfo exists [dict get $zoom $widget label]]} {[dict get $zoom $widget label] configure -text "[expr {round(100*$factor)}]%"}
    update idletasks
    if {[llength $view] && [winfo exists $widget]} {$widget yview moveto [lindex $view 0]}
    return [dict create zoom_percent [expr {round(100*$factor)}] source_mutation 0 scope widget]
}
proc ::GX::documentPresentationZoomControls {parent widget} {
    variable ::GX::DocumentSource::zoom
    if {![dict exists $zoom $widget]} {error {Rendered document must be ready before its zoom controls}}
    ttk::frame $parent
    ttk::label $parent.title -text {Text size:}
    ttk::button $parent.smaller -text {Smaller} -command [list ::GX::documentPresentationZoom $widget out]
    ttk::label $parent.level -text {100%} -width 5 -anchor center
    ttk::button $parent.larger -text {Larger} -command [list ::GX::documentPresentationZoom $widget in]
    ttk::button $parent.reset -text {Reset} -command [list ::GX::documentPresentationZoom $widget reset]
    pack $parent.title $parent.smaller $parent.level $parent.larger $parent.reset -side left -padx 3 -pady 2
    dict set zoom $widget label $parent.level
    return $parent
}
proc ::GX::documentNativeEnsure {} {
    if {![llength [info commands ::GX::NativeDocument::xml]]} {
        set library [file join $::GX::scriptDir core nativegui document libgxtxt_document[info sharedlibextension]]
        if {![file isfile $library]} {error {Native document/source capability is unavailable; install the matching native library.}}
        load $library Gxtxtdocument
    }
}
proc ::GX::xmlDocumentApiInfo {} {return [dict create api_id XML_DOCUMENT_API_v1 api_version 1 owner CORE native_engine libxml2 operations {create parse parse_file root describe append insert text add_text attribute remove move query serialize write release} limits {input_bytes 4194304 depth 64 nodes 50000 documents 64} entities disabled network disabled]}
proc ::GX::xmlDocument {operation args} {
    documentNativeEnsure
    if {$operation eq {parse_file}} {
        set path [lindex $args 0]
        if {![file isfile $path] || [file type $path] eq {link} || [file size $path]>4194304} {error {XML input must be a regular authorized file of at most 4 MiB}}
        set ch [open $path rb];try {set text [encoding convertfrom utf-8 [read $ch]]} finally {close $ch}
        return [::GX::NativeDocument::xml parse $text]
    }
    if {$operation eq {write}} {
        lassign $args document destination
        if {[llength $args]!=2} {error {XML write requires document and explicitly authorized destination}}
        return [filePublicationTextDocument $destination [::GX::NativeDocument::xml serialize $document 0] text]
    }
    return [::GX::NativeDocument::xml $operation {*}$args]
}
proc ::GX::documentRenderModel {language source} {
    documentNativeEnsure
    return [::GX::NativeDocument::render $language $source]
}
proc ::GX::documentRenderToWidget {widget language source} {
    set model [documentRenderModel $language $source]
    $widget configure -state normal -wrap word
    $widget delete 1.0 end
    $widget tag configure heading -font TkHeadingFont -spacing1 10 -spacing3 6
    $widget tag configure bold -font [list [font actual TkDefaultFont -family] [font actual TkDefaultFont -size] bold]
    $widget tag configure italic -font [list [font actual TkDefaultFont -family] [font actual TkDefaultFont -size] italic]
    foreach tag {code tag attribute string} {$widget tag configure $tag -font TkFixedFont}
    $widget tag configure tag -foreground #084c9e
    $widget tag configure attribute -foreground #753b00
    $widget tag configure link -foreground #064ca8 -underline 1
    documentPresentationZoomAttach $widget
    foreach run $model {lassign $run tag text;$widget insert end $text $tag}
    if {$language eq {html}} {$widget insert end "\n\nSafe minimal HTML: scripts, external assets, forms and CSS are inactive. Images are omitted.\n"}
    $widget configure -state disabled
    uiTextEditingAttach [winfo toplevel $widget] [list $widget]
    return [dict create renderer native_c language $language runs [llength $model]]
}
proc ::GX::datasetDocumentKind {id} {
    set contract [datasetField $id contract [datasetField $id kind {}]]
    if {$contract ni {document.text code.source}} {return {}}
    set media [string tolower [datasetField $id media_type {}]]
    set metadata [datasetMetadataRead $::GX::currentSession $id]
    set language {};foreach key {code.language text.language} {if {[dict exists $metadata $key]} {set language [string tolower [dict get $metadata $key]];break}}
    set payload [sessionInspectionDatasetPayload $id]
    set extension [string tolower [file extension [dict get $payload path]]]
    if {$media eq {text/markdown} || $language eq {markdown}} {return markdown}
    if {$media eq {text/html} || $language eq {html}} {return html}
    if {$media in {application/xml text/xml} || $language eq {xml}} {return xml}
    if {$language ne {} && $language ni {unknown plaintext}} {return code}
    if {$media ni {{} text/plain application/octet-stream}} {return {}}
    if {$extension in {.md .markdown}} {return markdown}
    if {$extension in {.html .htm}} {return html}
    if {$extension eq {.xml}} {return xml}
    if {$contract eq {code.source}} {return code}
    return {}
}
proc ::GX::documentUtf8Prefix {bytes limit} {
    # Validate every scalar which starts inside the requested prefix. Lookahead
    # distinguishes an incomplete valid scalar from malformed leading, trailing,
    # overlong, surrogate and out-of-range encodings; only the former is omitted.
    set size [string length $bytes];set position 0;set accepted 0
    set end [expr {min($limit,$size)}]
    while {$position<$end} {
        if {![regexp -indices -start $position {[\u0080-\u00ff]} $bytes found] || [lindex $found 0]>=$end} {set accepted $end;break}
        set position [lindex $found 0];set accepted $position
        scan [string index $bytes $position] %c lead
        if {$lead>=0xc2 && $lead<=0xdf} {set width 2
        } elseif {$lead>=0xe0 && $lead<=0xef} {set width 3
        } elseif {$lead>=0xf0 && $lead<=0xf4} {set width 4
        } else {error {Canonical document is not valid UTF-8}}
        if {$position+$width>$size} {error {Canonical document has an incomplete UTF-8 scalar}}
        for {set offset 1} {$offset<$width} {incr offset} {
            scan [string index $bytes [expr {$position+$offset}]] %c next
            if {$next<0x80 || $next>0xbf || ($offset==1 &&
                (($lead==0xe0 && $next<0xa0) || ($lead==0xed && $next>0x9f) ||
                 ($lead==0xf0 && $next<0x90) || ($lead==0xf4 && $next>0x8f)))} {error {Canonical document is not valid UTF-8}}
        }
        if {$position+$width>$end} break
        incr position $width;set accepted $position
    }
    return [string range $bytes 0 [expr {$accepted-1}]]
}
proc ::GX::datasetDocumentRead {id {limit 262144}} {
    if {![string is integer -strict $limit] || $limit<1 || $limit>4194304} {error {Document read limit must be1..4194304 UTF-8 bytes}}
    set payload [sessionInspectionDatasetPayload $id]
    set file [dict get $payload path]
    if {[sha256File $file] ne [dict get $payload sha256]} {error {Canonical document integrity changed}}
    set ch [open $file rb]
    try {set bytes [read $ch [expr {$limit+4}]];set complete [expr {[string length $bytes]<=$limit && [eof $ch]}]} finally {close $ch}
    set bytes [documentUtf8Prefix $bytes $limit]
    set text [encoding convertfrom utf-8 $bytes]
    if {[sha256File $file] ne [dict get $payload sha256]} {error {Canonical document changed during read}}
    return [dict create source $text complete $complete bytes [string length $bytes] sha256 [dict get $payload sha256]]
}
proc ::GX::datasetDocumentRender {widget id} {
    set kind [datasetDocumentKind $id]
    set read [datasetDocumentRead $id]
    set source [dict get $read source]
    if {[winfo exists $widget.source_surface]} {destroy $widget.source_surface}
    if {$kind eq {code}} {
        set notice [expr {[dict get $read complete] ? {Read-only canonical source consultation} : {Bounded source Preview: first 256 Ki characters. Open for a larger consultation.}}]
        set text [sourceSurfaceCreate $widget.source_surface [dict create mode read_only language [sourceSurfaceDatasetLanguage $id] notice $notice]]
        place $widget.source_surface -relx 0 -rely 0 -relwidth 1 -relheight 1
        sourceSurfaceSet $text $source
        return 1
    }
    if {$kind eq {markdown}} {markupRenderStringToWidget $widget $source
    } elseif {$kind in {html xml}} {documentRenderToWidget $widget $kind $source
    } else {return 0}
    if {![dict get $read complete]} {$widget configure -state normal;$widget insert end "\n\nTruncated preview: first 256 Ki characters. Open for a larger bounded consultation.\n";$widget configure -state disabled}
    return 1
}
proc ::GX::datasetDocumentOpen {id {obeyAssociation 1}} {
    set kind [datasetDocumentKind $id]
    if {$obeyAssociation && $kind in {markdown html}} {
        set command [configurationGet runtime.${kind}_viewer]
        if {$command ni {{} internal auto}} {
            if {[catch {llength $command}] || ![llength $command]} {error {Viewer association must be a valid executable argv prefix}}
            set executable [auto_execok [lindex $command 0]]
            if {$executable eq {}} {error "Configured $kind viewer is unavailable: [lindex $command 0]"}
            set payload [sessionInspectionDatasetPayload $id]
            return [exec {*}$executable {*}[lrange $command 1 end] [dict get $payload path] &]
        }
    }
    if {$kind eq {html}} {return [viewerOpen viewer.html html [dict create dataset_id $id]]}
    set w [datasetViewerWindow $id {CORE document consultation}]
    if {$kind eq {code}} {
        set read [datasetDocumentRead $id 4194304]
        set notice [expr {[dict get $read complete]?{Read-only canonical source consultation}:{Bounded Open: first 4 Mi characters; original source is preserved.}}]
        set surface [sourceSurfaceCreate $w.source [dict create mode read_only language [sourceSurfaceDatasetLanguage $id] notice $notice]]
        pack $w.source -fill both -expand 1
        sourceSurfaceSet $surface [dict get $read source]
    } else {
        if {$kind eq {xml}} {ttk::button $w.sourceButton -text {View source} -command [list ::GX::datasetDocumentSourceAction $id [interactiveDocumentSessionToken]];pack $w.sourceButton -anchor w -padx 5 -pady 4}
        text $w.content -wrap word -state disabled
        ttk::scrollbar $w.scroll -command [list $w.content yview]
        $w.content configure -yscrollcommand [list $w.scroll set]
        pack $w.scroll -side right -fill y;pack $w.content -fill both -expand 1
        datasetDocumentRender $w.content $id
    }
    return $w
}

proc ::GX::datasetDocumentSourceOpen {id {expectedToken {}}} {
    if {$expectedToken ne {} && $expectedToken ne [interactiveDocumentSessionToken]} {error {Session changed; reopen the document before viewing source}}
    set read [datasetDocumentRead $id 4194304]
    set w [datasetViewerWindow $id {CORE read-only source consultation}]
    set notice [expr {[dict get $read complete]?{Read-only canonical source consultation}:{Bounded source: first 4 Mi characters; original bytes are preserved.}}]
    set source [sourceSurfaceCreate $w.source [dict create mode read_only language [sourceSurfaceDatasetLanguage $id] notice $notice]]
    pack $w.source -fill both -expand 1;sourceSurfaceSet $source [dict get $read source]
    return $w
}
proc ::GX::datasetDocumentSourceAction {id token} {if {[catch {datasetDocumentSourceOpen $id $token} reason]} {tk_messageBox -icon error -type ok -title {Source unavailable} -message $reason}}

# Interactive HTML receives an owner-created presentation derivative containing
# only the canonical HTML file. A Session/Dataset directory is never an asset
# root: no existing Dataset contract declares authority over sibling files.
proc ::GX::documentInteractiveDatasetSnapshot {id} {
    if {[datasetDocumentKind $id] ne {html}} {error {Select a canonical HTML Dataset.}}
    set payload [sessionInspectionDatasetPayload $id]
    set path [dict get $payload path]
    if {![file isfile $path] || [file size $path]>4194304} {error {Interactive HTML requires a complete source no larger than4MiB.}}
    set sha [dict get $payload sha256]
    if {[sha256File $path] ne $sha} {error {Canonical HTML source integrity changed.}}
    return [dict create dataset_id $id path $path source_sha256 $sha session [interactiveDocumentSessionToken] stamp [datasetViewerStamp $id $path]]
}
proc ::GX::documentInteractiveDatasetSource {id} {
    set before [documentInteractiveDatasetSnapshot $id]
    set allocation [resourceManagementAllocate html_presentation [dict create category temporary lifetime viewer retention_seconds 0]]
    try {
        set root [dict get $allocation path]
        set target [file join $root index.html]
        file copy -- [dict get $before path] $target
        if {[sha256File $target] ne [dict get $before source_sha256] || [documentInteractiveDatasetSnapshot $id] ne $before} {error {Canonical HTML changed during presentation preparation.}}
        return [dict create source [dict create kind dataset dataset_id $id source_sha256 [dict get $before source_sha256]] snapshot $before asset_root $root relative index.html allocation $allocation asset_scope canonical_html_only]
    } on error {message options} {
        catch {documentInteractiveAllocationRelease $allocation}
        return -options $options $message
    }
}
proc ::GX::documentInteractiveAllocationRelease {allocation} {
    if {$allocation eq {}} return
    set id [dict get $allocation id]
    resourceManagementRelease $id verified_orphan 0
    # Only this authority-created allocation is eligible; never source paths.
    resourceManagementCleanup [list $id]
}

# Same document authority; the subordinate file supplies guarded authoring and
# embedded shared-editor projections, not another reader or persistence store.
source [file join [file dirname [info script]] document_edit_v1.tcl]
