# Curve Digitalizer 2.0.5 — corrected GitHub-based packaging

SPDX-License-Identifier: GPL-3.0-or-later

Authoritative GitHub baseline: giuxlab-hub/GX-TXT commit c84faff8a87d,
Curve Digitalizer 2.0.3 (GX-TXT dev098), 90 SHA256-confirmed source files.
Changes:
- Opt-in assisted tracing smoothness, red-X exclusion paths and calibration identification.
- Public viewer discovery: semantic_group=images, group_title=Imaging & Documents.
- ZIP internal entry names use / with proper api/, python/, tests/ directories.
- Plugin version: 2.0.5; baseline APIs and numerical model otherwise retained.

Archive integrity is checked after extraction using all SHA256SUMS entries.
Dynamic GUI/Tk, Numeric, and GLS/ODR integration tests remain pending.
No framework source was modified; zero-pixel Numeric integration is separate.

## 2.0.6 tests and integration caveat

Verified source baseline: GX-TXT Curve Digitalizer 2.0.5, itself rebased on GitHub Curve Digitalizer 2.0.3 (dev098 commit c84faff8a87d). No framework CORE source changes.

Hermetic tests tests/test_exclusion_undo_206.py exercise legacy path migration, stable IDs, path toggle, node drag as one undo transaction, clearing paths and preference checkpoints. tests/test_unified_history_206.py extracts and runs the real 2.0.6 Undo/Redo methods without Tk and verifies interleaved edits, branch invalidation, drag preimage and Session guard. The installed GUI must still be tested with actual mouse interactions, user Sessions and Numeric assisted proposals.

The Numeric provider patch to support exactly-zero pixel uncertainty, managed covariance and Fitter GLS/ODR tests remain separate integration tasks and are not claimed here.

## 2.0.7 icon restoration
The two icon assets are original GitHub blobs from giuxlab-hub/GX-TXT under plugins/modules/viewer.curve_digitizer/icons/: PNG 9,056 bytes, blob caeeef9fcb7f40a7c48a56bac0058d45aca65696, and SVG 1,227 bytes, blob 00f9707dd785ca0bc467228d90032f010fb04794. The package descriptor explicitly references the existing PNG; no substitution or regeneration of the artwork occurred.
## 2.0.8 validation scope
The new stroke-width diagnostics live entirely within the viewer package and expose a read-only CURVE_DIGITIZER_STROKE_WIDTH_API_v1, leaving the public CORE unchanged. Existing Curve/Quality/Uncertainty/Calibration APIs and source-image/digitization dataset behavior remain intact. The original icons restored in 2.0.7 are preserved.

All tests are isolated package checks unless separately confirmed within the installed host. The full GUI/Tk, Numeric and Fitter integration must be tested in GX-TXT dev108. The Numeric provider zero-localization patch remains a separate framework task.

## 2.0.9 additional verification
Two new headless tests exercise the actual GUI `on_curve_selected()` method through a minimal harness. All prior bundled 2.0.6 and 2.0.8 headless regression tests passed against the updated 2.0.9 tree (18 test cases across six files). The public Stroke Width API was also exercised with Tcl 8.6 under a stub of public CORE calls, confirming read-only configuration, curve and Dataset metadata access; synthetic raster tests demonstrate line-width estimates but not instrument uncertainty. Final archive SHA256SUMS and structural ZIP checks are required and recorded separately before installation. Actual installed GUI/CORE/Fitter integration remains pending.
