# Current C/C++ Viewer support catalog

Generated from the installed Development policy, SDK and runtime owners. Open this catalog from **Develop → C/C++ support catalog** in the Viewer Development Workspace. The existing rendered Markdown manual window provides find, links and scrolling.

## Language and ownership

C++17 including C facilities.

functions, pointers/references, classes/structs/enums/unions, inheritance/virtual dispatch/RTTI, overloads/templates, recursion, callbacks/lambdas, malloc/free/new/delete/RAII, containers/algorithms, preprocessing/macros/assert, exceptions, threads/synchronization, fork/wait.

Debian system libc/libstdc++/libm/pthread; extra libraries and compiler options require purpose-specific review

Local project logic/data/concurrency are allowed. Canonical Dataset/Schema/Publication/Session/Workspace/History/Job/scientific Plot remain public CORE responsibilities. Language admission does not approve an architectural bypass.

The compiler performs real Clang parsing and checks the fixed public on_event ABI and typed Host calls. Ordinary local C/C++ functions and standard library facilities supplied by the admitted headers are available, subject to their actual Debian implementation. Headers below are the exact direct-include admission list; transitive system dependencies are supplied by those headers. A new direct header, dependency or compiler/link option requires a concrete purpose and MAIN architectural review. Language availability does not grant a competing canonical store, scheduler or scientific renderer.

## Project source closure

One existing Viewer project contains handlers.cpp plus declared src/**/*.cpp translation units and include/**/*.hpp local headers. source_files is ordered with the unique handlers.cpp entrypoint first, at most32 files/64KiB each/1MiB total. The same official lexer/AST admits every translation unit and local header against an immutable complete source snapshot; fixed SDK linking includes every admitted unit. Source manifests retain path/role/size/SHA plus complete source/project digests. Any declared source/header edit invalidates stale runtime/build/package/debug identities. Literal reviewed includes use # or %: directives with phase2 splices; macro/external/escaped includes, numeric source remapping, trigraph/embed and header-existence queries require review. Ordinary/raw string content is inert. No authored compiler/build hook is available.

Independent Source Surface tabs retain per-file dirty state and Save All preimages; file add/rename/move/remove and checked editable package reimport delegate to the same Development owner. Original GDB/MI frames retain authentic full source names and normalized project_file identities across helper translation units and executable headers. External/native frames stay external; pending breakpoints do not establish an executable stop.

## Admitted headers and review decisions

Exactly 46 explicitly admitted header identities. Each row records the facilities/purpose and architectural decision; all are accepted for local project logic, with CORE public ownership retained. Presence here establishes admission, not exhaustive testing of every library function or platform.

| Exact header | Facilities, purpose and architectural review |
| --- | --- |
| `vector` | Reviewed local application containers; canonical Dataset access stays in public CORE |
| `array` | Reviewed local fixed-size application containers |
| `list` | Reviewed local application sequences |
| `deque` | Reviewed local application queues |
| `map` | Reviewed local application key/value state, not a canonical store |
| `unordered_map` | Reviewed local application indexes, not a canonical store |
| `set` | Reviewed local application sets |
| `unordered_set` | Reviewed local application sets |
| `queue` | Reviewed local application traversal/queues, not a CORE Job scheduler |
| `stack` | Reviewed local algorithm/application stacks |
| `memory` | Reviewed RAII and smart pointers for project memory |
| `utility` | Reviewed move/forward/pair facilities |
| `algorithm` | Reviewed local application algorithms; no replacement scientific service |
| `functional` | Reviewed callable wrappers/callbacks |
| `string` | Reviewed project strings; SDK transport remains bounded |
| `string_view` | Reviewed non-owning strings; respect lifetime and SDK transport |
| `tuple` | Reviewed local typed values |
| `type_traits` | Reviewed templates/type introspection |
| `typeinfo` | Reviewed ordinary RTTI/polymorphism |
| `exception` | Reviewed C++ exception lifecycle |
| `stdexcept` | Reviewed project error handling |
| `new` | Reviewed allocation/placement/lifetime |
| `limits` | Reviewed type bounds |
| `thread` | Reviewed local application threads; managed CORE Jobs remain authoritative |
| `mutex` | Reviewed local synchronization |
| `condition_variable` | Reviewed local synchronization |
| `atomic` | Reviewed local synchronization |
| `chrono` | Reviewed local time/duration measurement |
| `cassert` | Reviewed genuine native assertions |
| `assert.h` | Reviewed genuine native assertions |
| `cstddef` | Reviewed size/pointer types |
| `stddef.h` | Reviewed size/pointer types |
| `cstdint` | Reviewed exact-width local types |
| `stdint.h` | Reviewed exact-width local types |
| `cstdlib` | Reviewed allocation/conversion; inspect actual process/file use for CORE ownership |
| `stdlib.h` | Reviewed allocation/conversion; inspect actual process/file use for CORE ownership |
| `cstring` | Reviewed bounded project memory/string handling |
| `string.h` | Reviewed bounded project memory/string handling |
| `cstdio` | Reviewed project-scoped I/O; never private canonical Dataset/Workspace access |
| `stdio.h` | Reviewed project-scoped I/O; never private canonical Dataset/Workspace access |
| `cerrno` | Reviewed native operation diagnostics |
| `errno.h` | Reviewed native operation diagnostics |
| `unistd.h` | Reviewed fork/_exit local process workflow; not a replacement CORE execution service or canonical file bypass |
| `sys/types.h` | Reviewed native pid/type declarations |
| `sys/wait.h` | Reviewed wait/waitpid for own forked child lifecycle |
| `pthread.h` | Reviewed ordinary local thread/synchronization facilities |

## Supported public Host functions

Only these currently compiled SDK methods integrate the C++ author with GX-TXT. Each still requires its explicit compatible project capability, component/form and version. Discovery of another public Tcl/Script API does not admit an arbitrary C++ call.

```cpp
void text(unsigned component, const char* value) const;
void number(unsigned component, double value) const;
void flag(unsigned component, bool value) const;
double numeric_add(double left, double right) const;
double numeric_sqrt(double value) const;
double numeric_exp(double value) const;
void diagram_open(unsigned component) const;
void diagram_tool(unsigned component, const char* tool) const;
void diagram_command(unsigned component, const char* command) const;
void scientific_discover(unsigned form) const;
void scientific_prepare(unsigned diagram, unsigned form) const;
void scientific_submit(unsigned form) const;
void scientific_status(unsigned form) const;
void scientific_cancel(unsigned form) const;
void scientific_reconnect(unsigned form) const;
void scientific_log(unsigned form) const;
void scientific_import(unsigned form, unsigned dataset_selector) const;
void plot_discover(unsigned form) const;
void plot_bind(unsigned plot, unsigned form) const;
void document_bind(unsigned document, unsigned dataset_selector) const;
void raster_bind(unsigned viewport, unsigned dataset_selector) const;
void raster_tool(unsigned viewport, const char* tool) const;
void raster_command(unsigned viewport, const char* command) const;
void tex_command(unsigned form, const char* operation) const;
void em_command(unsigned form, const char* operation) const;
void workbench_command(unsigned form, const char* operation) const;
const char* input(unsigned component) const;
const char* data() const;
void cad_command(unsigned component, const char* action) const;
void diagnostics_command(unsigned form, const char* operation, const char* request = "{}") const;
void text_runs(unsigned component, const char* runs_json) const;
void table(unsigned component, const char* rows_json) const;
void catalog_refresh(unsigned form) const;
void catalog_inspect(unsigned form) const;
void catalog_action(unsigned form, const char* action) const;
void numeric_discover(unsigned form) const;
void numeric_evaluate(unsigned form) const;
void numeric_statistics(unsigned form) const;
void numeric_compare(unsigned form) const;
void numeric_publish(unsigned form, unsigned dataset_selector) const;
void demo(unsigned component, unsigned fixture) const;
Workspace workspace() const;
WorkspaceValue state() const;
WorkspaceValue property(const std::string& name) const;
WorkspaceStatus status() const;
std::vector<WorkspaceEntry> query(const std::string& prefix = "") const;
void set_state(const WorkspaceValue& value) const;
void set_property(const std::string& name, const WorkspaceValue& value) const;
void save(bool asynchronous = false) const;
void save_as(const std::string& name) const;
void rename(const std::string& name) const;
void open(const std::string& id) const;
void close() const;
void send(const char*, const WorkspaceValue&) const;
```

Presentation operations run through the shared GUI Host. Numerical methods use Numeric; canonical diagrams use Native2D/Interactive Document; scientific forms use Scientific Execution/Jobs; scientific graphs use Plot v4. document_bind uses existing HTML/PDF/Source Surface/paged Dataset consultation. catalog_refresh/inspect/action use a declared GUI Host section and the existing Scientific Library Manager, with exact per-action grants; they do not expose a generic invoke or scientific library parser. demo is explicitly a RAM demonstration and cannot establish scientific acceptance.

tex_command uses a complete declared TeX form and finite GUI Host operations. Source Surface, canonical TeX Workspace/Resource, managed native TeX builds, PDF consultation and File Publication retain their existing ownership. Build saves the guarded draft before running the typesetter; installed C++ execution still uses the packaged binary. The additive nonvirtual method/opcode30 preserves old Event/State/Host storage and operations1–29. See VIEWER_GUI_HOST_API_v1 for exact form and lifecycle contracts; source admission is not installed Viewer acceptance.

New Viewer scientific 2D and 3D graphs require PLOT_DATASET_API_v4. PLOT_DATASET_API_v3 is deprecated and denied for new restricted declarations/source/build/export/runtime admission; preserved historical consumers keep their existing compatibility API.

## ABI, compiler and runtime

```text
--no-default-config
-std=c++17
-x
c++
-Werror
-fno-color-diagnostics
-pthread
-isystem
/usr/lib/gcc/x86_64-linux-gnu/14/include
```

The trusted adapter links a shared library with system libstdc++, libm and pthread (-shared -pthread -Wl,-z,defs -lstdc++ -lm). The SDK is automatically supplied. The event handler is void on_event(gx::Host&, gx::State&, const gx::Event&). State has sixteen double slots and one unsigned counter; these are bounded public event transport, not a restriction on ordinary local C++ types or project memory. Host callbacks use bounded finite values/text and enumerated operations.

Development validates and builds once per actual source/build dependency version. Preview, Test and Export reuse the retained binary; closing and reopening an unchanged project does not rebuild it. Installed packages distribute native/viewer.so. Plugin admission verifies that artifact and SDK compatibility; normal installed startup/events load it directly without compiler/linker invocation or a silent rebuild fallback. Missing/incompatible artifacts require a precise error and a compatible package. No development compiler is needed to execute a compatible installed Viewer. Local compiled events use the existing managed persistent worker and apply their public GUI plan before the next queued pointer action; scientific Jobs remain asynchronous.

Current admission/build budgets: source 65536 bytes; compile 30 seconds; active event wall budget 12 seconds. The native worker currently applies CPU3s, address-space256MiB, output-file1MiB and no core dumps. These are actual execution budgets, not a claim of hostile-code security or a general language prohibition. Purpose-specific legitimate workload changes need owner review.

## Scalar Numeric transport

Persistent native author limits remain CPU3s/address-space256MiB/file-size1MiB and wall12s. Explicit scalar add/sqrt/exp grants use a conditional pre-limit trusted transport to the exact original broker_message/core Numeric owner, matching the nonpersistent broker boundary. It is not a numerical implementation, scheduler, registry, compiler or new SDK permission. Bounded typed framing/frozen hashes/exact grants and existing supervisor identities/subreaping drain broker plus CORE groups on normal close, failure, cancellation and parent death. A Viewer without scalar grants starts no child. Domain failure discards event UI/state and permits a later valid event in the same native library. Cancellation cannot unwind through ctypes as an uninitialized success.

## Integrated debugger

GDB/MI supports breakpoints, Continue, Step Into/Over/Out, Pause/Stop and stack-frame selection through the managed Development owner. Read-only opaque variable identities provide real struct/array children: all aggregates initially collapsed; click to expand vertical fields/elements, click again to collapse. Children load only on request, in pages of at most64; maximum depth8 and512 displayed nodes per stop/frame. A further page is explicit. Each new stop/frame/continuation invalidates old child identities. Unavailable or optimized-out values retain actual debugger diagnostics. No arbitrary GDB console/expression injection is exposed.

Threads and fork/wait are admitted ordinary project logic. This catalog does not promise additional debugger thread-switch or follow-fork controls: the present enumerated control contract remains authoritative. Authors are encouraged to use the integrated debugger for actual development problems and report reproducible CPP_DEBUGGER_BUGs.

## Synchronization fingerprints

Generated by the catalogued validation/dev111_p027_cpp/support_catalog.py; regenerate on every admitted-header/SDK/compiler/runtime/debugger change, and require --check before final packaging. These fingerprints describe the exact current inputs; scientific/installed acceptance remains in the independent release matrix.

| Input | SHA256 |
| --- | --- |
| `core/development/policy_v1.json` | `19575e86f2f905f36e63bb6c7de08f66fa94924e97f6dc78073696c9745712f5` |
| `core/development/sdk/gxtxt_viewer_sdk_v1.hpp` | `b55073e021bc8b78f72758122418e17d7e4ca0a6f91f1e252858091932d8a74a` |
| `core/python/gxtxt_cpp_policy.py` | `0822274b6e3e98ce890eb42be85d916463ff25fbb3bba42a3fb09d4b94f5e5bf` |
| `core/python/gxtxt_viewer_development.py` | `1cd4faf468b48991e8b6d80ea9282a22641eed4a1192a06344795cbf56e37e59` |
| `core/development/sdk/trusted_adapter_v1.cpp` | `6e0f8ecc89de84da9eafe41858d91e3e2e3205ccaf6c519f287f835282a23629` |
| `core/python/gxtxt_viewer_native_worker.py` | `159dcc0fffd78730ebe3284a22a4cbe3c8139bb807cd9c33d3a28542ca2086e8` |
| `core/python/gxtxt_viewer_scalar_broker.py` | `007748202c53ad9240df5128662f1a8be12969ced73faec35dd22b1181c87324` |
| `core/python/gxtxt_viewer_cpp_debug.py` | `f74968107fbb00830cded8f51b2b233fbb475008f5ae605117ccfcf566ac4931` |
| `plugins/modules/viewer.development_workspace/api/debugger.tcl` | `2fcfc820f8d1142ae7a7eb0f573b071cd9fc35da53d85ba203e3fff246236d65` |
| `plugins/modules/viewer.development_workspace/api/workspace.tcl` | `799587162e90be3c63038b4ca029921ddb7af767368cefd5c3b000c6bf92ba72` |
| `plugins/modules/viewer.development_workspace/api/project_files.tcl` | `02b18d64ae04860f90f4ecf287212f96bf4383af0b329f1dcb38d9c7cad388a3` |
| `core/tcl/viewer_development_api_v1.tcl` | `cd41fcc38b10c2d4c79e38c65e7fb9949849be76b91d6bcd6260e51dcde8d600` |
| `core/tcl/viewer_development_api_browser_v1.tcl` | `d46c69f2f532ee8fc44aa2ad6142b25337c37b0f7f99fbfa4713c3f99e69ac2e` |
| `core/tcl/ui_field_api_v1.tcl` | `dce433cea170c921adaf0c93e14feeeb720895cc8873608e0422c4f460b88da8` |
| `core/tcl/viewer_development_request.tcl` | `cb8cbd69c365e2992af947c1c0bd181f5c8f1c951c8a06ddc6554c2bfbf227b3` |
| `core/tcl/script_job_api_v1.tcl` | `d829077d0473ad5c3606a4dc6e01378aaf6f22c955713cc93835e47a92bb478e` |
| `core/tcl/plugin_install_api_v1.tcl` | `33ca4d796ad28e109eedb28d002a44ff54f2eaeec1899ebcd321e13d1a7c4eef` |
