#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""P029→P030 guard; default read-only. Stop GX-TXT and its workers first."""
from pathlib import Path
import argparse, sys, zipfile
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import GuardError, apply_overlay

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('framework', type=Path);p.add_argument('archive', type=Path)
    group = p.add_mutually_exclusive_group();group.add_argument('--check', action='store_true');group.add_argument('--apply', action='store_true')
    p.add_argument('--stopped', action='store_true', help='Acknowledge target GX-TXT/workers stopped; this is not process detection')
    p.add_argument('--sha256', help='Externally verified ZIP SHA256 instead of adjacent sidecar')
    a = p.parse_args()
    if a.apply and not a.stopped:p.error('--apply requires --stopped acknowledgment; no runtime-stop enforcement is implemented')
    m = apply_overlay(a.framework, a.archive, a.apply, a.sha256)
    print(('APPLIED; restart and independent GUI acceptance required' if a.apply else 'CHECK PASS; no writes') + ': ' + m['source_commit'])
if __name__ == '__main__':
    try:main()
    except (GuardError, OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as e:raise SystemExit('REFUSED: ' + str(e))
