# P021 graphics launch and initial-frame recovery contracts

`fallback.tcl FRAMEWORK NEW_OUTPUT` sources the real v2 host implementation with
small deterministic process/GUI boundary fixtures. Checks one initial read-only
Auto frame retry, retained exact scene and quality request, ordered pending
navigation, projection/capability restoration, no retry of scientific errors,
explicit Hardware/Software, stale source, completed frames or repeated failure,
and bounded worker stderr retrieval. Writes only NEW_OUTPUT under agent scratch.
This is a contract test, not native rendering or GUI qualification.

Real native/GUI counterparts are separately cataloged in the NVIDIA support
scratch area and MAIN2 post-reboot validation snapshots. Production code changes
only existing Tcl launch/policy adapters; no native engine or binary rebuild.

`startup.tcl FRAMEWORK NEW_OUTPUT component|legacy Auto|Software EXPECTED_RETRY`
uses the actual public component/native renderer (legacy graphicsCheck as a
white-box launch counterpart) with private HOME/XDG/config/cache/Job paths.
Component draws one synthetic display-only cube, waits at most45s for readiness,
checks actual device/policy/retry, saves own Canvas/native images and bounded
worker logs, then disposes only its own window/workers. Legacy checks actual
software device plus exact parent graphics-environment restoration. The existing
authorized remote display may be used once to reproduce its demonstrated initial
OpenGL crash and validate Auto recovery; this is API/native-worker integration,
not real mouse/GUI acceptance or general Windows-X11 qualification. No user input,
original configuration, Session, source or OS changes; no full matrix.
