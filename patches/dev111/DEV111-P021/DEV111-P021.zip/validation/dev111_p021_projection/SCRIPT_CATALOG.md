# DEV111-P021 bounded projection adapter

P020 final source6f6c1ce5 only. Protected Native3D engine source, public engine ABI,
renderer/picking/navigation algorithms and libgx3de binaries remain unchanged.

`build.py FRAMEWORK NEW_OUTPUT`: targeted C++17 Release build of the existing Tcl
viewer adapter against its packaged native engine and the new Tcl-only projection
evaluator (no VTK/engine linkage in the GUI module). Writes binaries and matching
commands/source/library hashes only in NEW_OUTPUT. No full Native3D rebuild,
install/user Session/release writes. MAIN reviews/copies artifacts into component.

`test.tcl FRAMEWORK NEW_OUTPUT`: mapped private X11 native-render/component
projection contract, not CAD real-GUI acceptance. Existing native camera and
plane C API are the gold authority for perspective/orthographic/inclined-plane/
scientific-figure margins, stale frame/size, behind/edge-on, disposal and batching.
Writes its own PNGs/receipts only in NEW_OUTPUT. Run with bounded xvfb-run and
private HOME/XDG/TMPDIR below the component root. No live/original Sessions.

`negative.tcl FRAMEWORK SUCCESSFUL_RECEIPT NEW_OUTPUT`: pure native-mapper
negative checks against the actual prior native camera samples: behind-camera,
edge-on plane, malformed frame identity/dimensions and excessive batch refusal.
No renderer/scientific state or GUI is created; new receipt only. Complements,
does not replace, real-GUI or native golden projection qualification.

`fit_degenerate.tcl FRAMEWORK NEW_OUTPUT`: bounded native-render API test of public FitObject delegation for horizontal, vertical and point extents. Private X11/HOME/XDG/TMPDIR; writes three native PNGs and receipt only. Not CAD real-GUI acceptance.

`random_planes.tcl FRAMEWORK NEW_OUTPUT`: six deterministic-seeded native-normalized random tilted planes, alternating projection modes and viewport sizes; 150 public native-golden point/inverse checks. Same private X11/HOME/XDG/TMPDIR rules. Native-render/component validation, not actual CAD GUI acceptance.
