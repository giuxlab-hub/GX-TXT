# P021 scoped presentation validation

`contract.tcl FRAMEWORK NEW_OUTPUT`: source the exact presentation procedures in
a deterministic TclOO host/selection/History fixture. Measure query counts across
four shared mounts plus authored controls; check scoped state refresh, exception
cleanup, invalidation and finite Finish semantics. Baseline P020 runs the same
query stimulus without new batching. Writes receipt/log only NEW_OUTPUT. No Tk
GUI, native geometry, Session, installed framework or release mutation. This is
not real-GUI acceptance. Actual GUI Finish must be qualified by MAIN2.
