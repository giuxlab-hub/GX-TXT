# External P021 release qualification contract

SPDX-License-Identifier: GPL-3.0-or-later

MAIN1 supplies this reviewed JSON only after inspecting independent evidence.
The helpers do not infer successful GUI behavior from process exit codes, copy
old source qualification, or manufacture Native3D hardware/color acceptance.
Technical ZIP integrity and actual GUI qualification are separate results.

Required top-level fields:

```json
{
  "schema": "gxtxt.dev111.p021.qualification.v1",
  "source_commit": "EXACT_FINAL_COMMIT",
  "reviewed_by": "MAIN1",
  "package_authorized": true,
  "deposit_authorized": false,
  "ready_for_user_acceptance": false,
  "incomplete_candidate_authorized": false,
  "publish_viewer_exports": false,
  "installed": false,
  "user_vnc_acceptance": "OPEN",
  "final_runtime_pins": {"framework/relative/path": "SHA256"},
  "native_builds": [],
  "gates": []
}
```

`final_runtime_pins` must cover every changed runtime file under CORE/app/plugins
and `gxtxt_pipeline.tcl`. Each digest must match the final committed framework.
Documentation/helper-only changes do not silently invalidate prior legitimate
runtime evidence, but the external reviewer must identify source equivalence.

`native_builds` must contain exactly the three P021 native binaries:
`core/native2d/bin/gx2dtcl.so`,
`core/native3d/bin/libgx3de_viewer_tcl.so`,
`core/native3d/bin/gx3de_projection_tcl_v1.so`.
Every row contains `binary`, `binary_sha256`, nonempty `source_pins` (framework
relative path→SHA256), `receipt` (reviewed local evidence file) and
`receipt_sha256`. Their combined source pins must cover all changed C/C++/header
sources. Receipt hashes are checked; inspecting the actual compiler commands,
source dependencies and successful build remains MAIN1's review responsibility.

Every gate contains `id`, `status`, `required_for_release`, `note`, and a nonempty
`evidence` array of `{ "path": "LOCAL_FILE", "sha256": "DIGEST" }`.
Statuses are exactly `PASS`, `FAIL`, `NOT_VERIFIED`, `KNOWN_LIMITATION`.
Use distinct gates for actual GUI, lifecycle, current-source qualification,
performance and hardware/software Native3D results. In particular, a software
color PASS does not replace a hardware color FAIL. Preserve both observations
and the actual tested device, source and conditions.

An unresolved required gate blocks final-ready packaging. MAIN1 may explicitly
set `incomplete_candidate_authorized: true` to produce a clearly recorded
incomplete technical candidate; in that case `ready_for_user_acceptance` must
remain false. This is not authorization to claim completion or disregard the
mandate's stopping conditions. Deposit additionally requires explicit
`deposit_authorized: true`. The helper performs neither authorization itself.
All recorded gate statuses survive unchanged into verification/deposit reports.

Final reports default to eight files beneath `docs/development/DEV111-P021/`:
`README.md`, `FINAL_HANDOFF.md`, `VALIDATION_REPORT.md`, `PERFORMANCE_REPORT.md`,
`KNOWN_LIMITATIONS.md`, `ARCHITECTURE_HANDOFF.md`, `LIFECYCLE_REPORT.md`,
`CUBE_COLOR_REPORT.md`. Optional `reports` maps those exact canonical names to
other reviewed committed relative files within the same P021 documentation
folder; this avoids rewriting already valid reports merely for naming.

The separate Viewer exports input is:

```json
{
  "modules": [{
    "module_id": "viewer.test_cad_1",
    "authoring_api": "VIEWER_DEVELOPMENT_API_v1",
    "package": "/scratch/public-export.zip",
    "package_sha256": "SHA256",
    "export_receipt": "/scratch/public-export-receipt.json",
    "export_receipt_sha256": "SHA256"
  }]
}
```

Include one row each for CAD1 and CAD2, no unrelated Viewer. Their archive members
must exactly equal the final ordinary module files and current checksum lists.
C++ source, admitted native SDK and Viewer binary must remain P020-identical.
The helper verifies exports and stages copies. Separate external-plugin
archive/expanded mirrors are created only when `publish_viewer_exports` is true;
the incremental framework overlay includes the necessary module deltas either
way. No Session Generator is added or changed by P021.

Rollback is all-files-preflight then per-file replacement, not a multi-file
filesystem transaction against power failure. Close GX-TXT, retain the release,
check sufficient disk space and run the read-only preflight first. Divergent
product files or altered rollback backups cause refusal before the first write.
Unrelated Sessions, preferences, diagnostic logs and old P020 notes are untouched.
