#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Copy explicit reviewed synthetic P021 evidence, never a Session/cache tree."""
from pathlib import Path
import hashlib
import json
import shutil
import sys

ALLOWED = {
    'main2': Path('/srv/gxtxt/agents/scratch/DEV111-P021-VALIDATION-MAIN2'),
    'projection': Path('/srv/gxtxt/agents/scratch/DEV111-P021-NATIVE-API'),
    'cad': Path('/srv/gxtxt/agents/scratch/DEV111-P021-CAD-PROJECTION'),
    'viewers': Path('/srv/gxtxt/agents/scratch/DEV111-P021-VIEWERS'),
}
manifest, output = map(lambda value: Path(value).resolve(), sys.argv[1:])
assert output.is_relative_to('/srv/gxtxt/agents/scratch/DEV111-P021-MAIN/framework/docs/development/DEV111-P021')
assert not output.exists()
rows = json.loads(manifest.read_text(encoding='utf-8'))['files']
seen = set()
total = 0
for row in rows:
    root = ALLOWED[row['root']].resolve()
    relative, target = Path(row['source']), Path(row['target'])
    for value in (relative, target):
        assert not value.is_absolute() and '..' not in value.parts
        assert not any(part.lower() in {'sessions', 'session', 'cache', 'config', 'configuration', 'framework', 'resources', 'installation', 'real-fixture'} for part in value.parts)
    source = root / relative
    assert source.is_file() and not source.is_symlink() and source.resolve().is_relative_to(root)
    assert target.as_posix() not in seen
    seen.add(target.as_posix())
    assert source.suffix in {'.json', '.md', '.tcl', '.py', '.tcldict', '.tcllist', '.txt', '.png', '.log'}
    assert hashlib.sha256(source.read_bytes()).hexdigest() == row['sha256']
    total += source.stat().st_size
assert total <= 32 * 1024 * 1024
output.mkdir(parents=True)
for row in rows:
    source = ALLOWED[row['root']] / row['source']
    target = output / row['target']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
shutil.copy2(manifest, output / 'WHITELIST.json')
print(json.dumps({'status': 'PASS', 'files': len(rows), 'bytes': total}))
