#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Bounded read-only P021 snapshot preparation; not final qualification."""
from pathlib import Path
import argparse, struct, subprocess, sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import BASE_COMMIT, BINARIES, MODULES, GuardError, require, sha, digest, read_json, write_json, git
from package import protected, validate_module


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('snapshot','source_repository','commit','baseline_json','new_report_json'):
        parser.add_argument(name)
    args=parser.parse_args();snapshot=Path(args.snapshot).resolve();repo=Path(args.source_repository).resolve()
    output=Path(args.new_report_json).resolve()
    require(output.is_relative_to('/srv/gxtxt/agents/scratch') and not output.exists(),'New scratch report required')
    commit=git(repo,'rev-parse',args.commit);pins=read_json(args.baseline_json)
    require(pins['baseline_commit']==BASE_COMMIT,'Wrong baseline pins')
    paths=git(repo,'diff','--name-only',BASE_COMMIT,commit).splitlines();changes=[]
    for name in paths:
        expected=digest(subprocess.check_output(['git','-C',str(repo),'show',commit+':'+name],timeout=120))
        actual=sha(snapshot/name)
        changes.append(dict(path=name,expected_sha256=expected,actual_sha256=actual,status='PASS' if expected==actual else 'FAIL'))
    anchors=[]
    for name,expected in pins['files'].items():
        if protected(name):
            actual=sha(snapshot/name)
            anchors.append(dict(path=name,expected_sha256=expected,actual_sha256=actual,status='PASS' if expected==actual else 'FAIL'))
    modules={ident:validate_module(snapshot,ident) for ident in MODULES}
    binaries=[]
    for name in BINARIES:
        raw=(snapshot/name).read_bytes()
        valid=raw[:6]==b'\x7fELF\x02\x01' and struct.unpack('<H',raw[18:20])[0]==62
        binaries.append(dict(path=name,sha256=sha(snapshot/name),linux_x86_64=valid,
                             matching_compiler_provenance='NOT_VERIFIED; external final build receipt required'))
    failures=[row['path'] for row in changes+anchors if row['status']!='PASS']
    result=dict(status='SOURCE_CONSISTENCY_PASS' if not failures and all(b['linux_x86_64'] for b in binaries) else 'FAIL',
                source_commit=commit,snapshot=str(snapshot),scope='bounded snapshot preparation, not GUI/release qualification',
                changed_files=changes,protected_anchors=anchors,module_checksum_entries=modules,native_binaries=binaries,
                failures=failures,actual_gui='NOT_VERIFIED',cad_performance='NOT_VERIFIED',final_release_ready=False,
                original_source_mutations=False,release_writes=False)
    output.parent.mkdir(parents=True,exist_ok=True);write_json(output,result)
    print(result['status'],len(changes),'changed files;',len(anchors),'protected anchors;',modules)
    require(result['status']=='SOURCE_CONSISTENCY_PASS','Snapshot source inconsistency; inspect preserved report')

if __name__=='__main__':
    try:main()
    except (GuardError,OSError,ValueError,KeyError,subprocess.SubprocessError) as error:raise SystemExit('REFUSED: '+str(error))
