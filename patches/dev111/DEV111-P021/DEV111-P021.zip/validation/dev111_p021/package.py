#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Reviewed exact-P020 to P021 incremental package; scratch proof, no installation."""
from pathlib import Path
import argparse, datetime, json, os, shutil, stat, struct, subprocess, sys, zipfile
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import (PATCH, BASE_COMMIT, P019_COMMIT, BASE_ZIP_SHA, BASE_ZIP_BYTES,
                            NOTES, MODULES, BINARIES, GuardError, require, sha, digest,
                            read_json, write_json, relpath, member_path, inventory,
                            git, fresh_scratch, zip_members, check_qualification,
                            apply_overlay, rollback_overlay)


def protected(name):
    return (name.startswith(('core/native3d/src/', 'core/native3d/include/', 'core/native3d/lib/',
                             'core/history/', 'core/development/sdk/', 'core/diagnostics/',
                             'plugins/modules/viewer.stderr_diagnostics/',
                             'plugins/modules/viewer.scientific_3d_workbench/')) or
            name.startswith('core/') and 'history' in name.lower() or
            name == 'core/tcl/gui_update_scheduler_v1.tcl' or
            name.startswith('core/native2d/') and Path(name).suffix in ('.c', '.h') or
            any(name.startswith('plugins/modules/' + m + '/native/') or
                name == 'plugins/modules/' + m + '/source/handlers.cpp' for m in MODULES[1:]))


def validate_module(root, ident):
    directory = root / 'plugins/modules' / ident
    raw = (directory / 'SHA256SUMS.txt').read_text(encoding='utf-8')
    listed = {}
    for line in raw.splitlines():
        value, name = line.split('  ', 1);relpath(name)
        require(name not in listed and sha(member_path(directory, name)) == value,
                'Invalid module checksum: ' + ident + '/' + name)
        listed[name] = value
    expected = {n for n in inventory(directory) if n not in ('SHA256SUMS', 'SHA256SUMS.txt')}
    require(set(listed) == expected, 'Incomplete module inventory: ' + ident)
    if (directory / 'SHA256SUMS').exists():
        require((directory / 'SHA256SUMS').read_text(encoding='utf-8') == raw, 'Module checksum copies differ: ' + ident)
    return len(listed)


def validate_exports(value, source):
    rows = value.get('modules', [])
    require({row.get('module_id') for row in rows} == set(MODULES[1:]) and len(rows) == 2,
            'Only normal Test CAD1/2 public exports required')
    for row in rows:
        require(row.get('authoring_api') == 'VIEWER_DEVELOPMENT_API_v1', 'Ordinary public Development export required')
        package = Path(row['package']).resolve()
        require(package.is_file() and sha(package) == row['package_sha256'], 'Viewer export changed')
        receipt = Path(row['export_receipt']).resolve()
        require(receipt.is_file() and sha(receipt) == row['export_receipt_sha256'], 'Public export receipt changed')
        module = source / 'plugins/modules' / row['module_id']
        with zipfile.ZipFile(package) as archive:
            entries = zip_members(archive)
            actual = inventory(module)
            require(set(entries) == set(actual), 'Export/module membership differs: ' + row['module_id'])
            for name in entries:
                require(digest(archive.read(name)) == actual[name], 'Export postimage differs: ' + name)
    return rows


def write_archive(payload, target, epoch):
    date = datetime.datetime.fromtimestamp(max(epoch, 315532800), datetime.timezone.utc)
    timestamp = (date.year, date.month, date.day, date.hour, date.minute, date.second)
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(payload.rglob('*')):
            if path.is_file():
                entry = zipfile.ZipInfo(path.relative_to(payload).as_posix(), timestamp)
                entry.create_system = 3
                entry.external_attr = (stat.S_IFREG | stat.S_IMODE(path.stat().st_mode)) << 16
                entry.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(entry, path.read_bytes(), compresslevel=9)


def baseline_guards(base, pins):
    require(pins.get('baseline_commit') == BASE_COMMIT, 'Wrong exact P020 baseline')
    require(pins.get('archive_sha256') == BASE_ZIP_SHA and pins.get('archive_bytes') == BASE_ZIP_BYTES,
            'Wrong P020 archive pin')
    require(git(base, 'rev-parse', 'HEAD') == BASE_COMMIT and not git(base, 'status', '--porcelain'),
            'Exact clean protected P020 source required')
    before = inventory(base)
    require(before == pins['files'], 'Protected P020 filesystem changed since preparation')
    archive = Path(pins['archive']).resolve()
    require(sha(archive) == BASE_ZIP_SHA and archive.stat().st_size == BASE_ZIP_BYTES, 'P020 ZIP changed')
    with zipfile.ZipFile(archive) as z:
        entries = zip_members(z)
        old = json.loads(z.read('patch_notes/DEV111-P020/FILES.json'))
        require(old['source_commit'] == BASE_COMMIT and old['baseline_commit'] == P019_COMMIT, 'Wrong P020 source manifest')
        for row in old['changed_files']:
            require(before.get(row['path']) == row['after_sha256'], 'P020 manifest/source differs')
        for name in entries:
            if not name.startswith('patch_notes/'):
                require(before.get(name) == digest(z.read(name)), 'P020 archive/source differs: ' + name)
    for label, expected in pins['protected'].items():
        tree = Path('/srv/gxtxt/agents/scratch') / ('DEV111-' + label + '-MAIN') / 'framework'
        for key, args in (('head', ('rev-parse', 'HEAD')), ('status', ('status', '--porcelain')),
                          ('git_dir', ('rev-parse', '--absolute-git-dir'))):
            require(git(tree, *args) == expected[key], 'Protected ' + label + ' Git identity changed: ' + key)
    for name, expected in pins['todo_pins'].items():
        value = expected['sha256'] if isinstance(expected, dict) else expected
        require(sha(name) == value, 'Protected TODO changed: ' + name)
    p019_archive = Path('/srv/gxtxt/releases/dev111/patches/0019-advanced-cad-tools/DEV111-P019.zip')
    require(sha(p019_archive) == '59e6579030c68548b3e76f750f048d356a5503fc4f5342960402c7f9f1679c55' and
            p019_archive.stat().st_size == 8972405, 'Protected accepted P019 ZIP changed')
    return before, archive, old


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('p020_framework', 'p021_source', 'new_stage', 'baseline_json', 'qualification_json', 'viewer_packages_json'):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    base, source = args.p020_framework.resolve(), args.p021_source.resolve()
    stage = fresh_scratch(args.new_stage)
    pins = read_json(args.baseline_json)
    before, old_zip, old_manifest = baseline_guards(base, pins)
    require(source != base and not git(source, 'status', '--porcelain'), 'Clean committed separate P021 worktree required')
    commit = git(source, 'rev-parse', 'HEAD')
    require(commit != BASE_COMMIT and not git(source, 'remote'), 'Local-only reviewed P021 commit required')
    require(git(source, 'rev-parse', '--absolute-git-dir') != git(base, 'rev-parse', '--absolute-git-dir'),
            'P021/P020 Git admin ownership is not isolated')
    subprocess.run(['git', '-C', str(source), 'merge-base', '--is-ancestor', BASE_COMMIT, commit], check=True, timeout=30)
    after = inventory(source)
    require(not (set(before) - set(after)), 'Unexpected product deletions')
    changed = sorted(name for name in after if before.get(name) != after[name])
    require(changed, 'No incremental changes')
    for name, value in before.items():
        if protected(name):
            require(after.get(name) == value, 'Protected accepted implementation changed: ' + name)
    allowed = ('core/', 'app/', 'docs/api/', 'docs/development/DEV111-P021/',
               'validation/dev111_p021', 'validation/p021_projection/')
    for name in changed:
        relpath(name)
        require(name in ('gxtxt_pipeline.tcl', 'SCRIPT_CATALOG.md', 'SCRIPT_CATALOG.md.sha256', 'SHA256SUMS') or name.startswith(allowed) or
                any(name.startswith('plugins/modules/' + m + '/') for m in MODULES), 'Out-of-scope change: ' + name)
        require('TODO' not in name.upper() and not any(x in Path(name).parts for x in
                ('Sessions', '__pycache__', '.git', 'REAL-FIXTURE', 'support-diagnostics-withdrawn')), 'Private/protected payload: ' + name)
    qualified = read_json(args.qualification_json)
    blocked = check_qualification(qualified, commit, after, changed)
    inventories = {m: validate_module(source, m) for m in MODULES}
    exports = validate_exports(read_json(args.viewer_packages_json), source)
    for name in BINARIES:
        raw = (source / name).read_bytes()
        require(raw[:6] == b'\x7fELF\x02\x01' and struct.unpack('<H', raw[18:20])[0] == 62,
                'Ready-to-run Linux x86-64 ELF required: ' + name)
        require(os.access(source / name, os.X_OK), 'Native binary executable mode required: ' + name)
    for name in ('package.py', 'apply.py', 'rollback.py', 'release_common.py', 'deposit.py', 'fresh_startup.py'):
        require(sha(Path(__file__).parent / name) == sha(source / 'validation/dev111_p021' / name),
                'Invoked helper differs from committed source: ' + name)
    docs = source / 'docs/development/DEV111-P021'
    reports = ('README.md', 'FINAL_HANDOFF.md', 'VALIDATION_REPORT.md', 'PERFORMANCE_REPORT.md',
               'KNOWN_LIMITATIONS.md', 'ARCHITECTURE_HANDOFF.md', 'LIFECYCLE_REPORT.md', 'CUBE_COLOR_REPORT.md')
    report_paths = qualified.get('reports', {name: 'docs/development/DEV111-P021/' + name for name in reports})
    require(set(report_paths) == set(reports), 'Complete final P021 report mapping required')
    for name, relative in report_paths.items():
        require(relative.startswith('docs/development/DEV111-P021/') and member_path(source, relative).is_file(),
                'Final P021 report missing: ' + name)
    stage.mkdir(mode=0o700)
    payload = stage / 'payload';payload.mkdir()
    notes = payload / NOTES;notes.mkdir(parents=True)
    rows = []
    for name in changed:
        target = payload / name;target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source / name, target)
        prior = before.get(name)
        rows.append(dict(path=name, action='replace' if prior else 'add', before_sha256=prior,
                         after_sha256=after[name], bytes=(source / name).stat().st_size,
                         before_mode=stat.S_IMODE((base / name).stat().st_mode) if prior else None,
                         after_mode=stat.S_IMODE((source / name).stat().st_mode)))
        if prior:
            backup = notes / 'rollback-preimages' / name;backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(base / name, backup)
    manifest = dict(patch=PATCH, baseline_commit=BASE_COMMIT, baseline_archive_sha256=BASE_ZIP_SHA,
                    source_commit=commit, changed_files=rows,
                    protected_files={name: value for name, value in before.items() if protected(name)})
    write_json(notes / 'FILES.json', manifest)
    (notes / 'CHANGED_FILES.txt').write_text('\n'.join(changed) + '\n', encoding='utf-8')
    write_json(notes / 'SOURCE.json', dict(commit=commit, baseline_commit=BASE_COMMIT,
               cumulative_chain=[P019_COMMIT, BASE_COMMIT, commit], installed=False,
               p020_user_acceptance='WITHHELD', user_vnc_acceptance='OPEN',
               ready_for_user_acceptance=qualified['ready_for_user_acceptance']))
    shutil.copy2(args.qualification_json, notes / 'QUALIFICATION.json')
    for name in reports:
        shutil.copy2(member_path(source, report_paths[name]), notes / name)
    for name in ('apply.py', 'rollback.py', 'release_common.py'):
        shutil.copy2(Path(__file__).parent / name, notes / name)
    (notes / 'PAYLOAD_SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(payload).as_posix()}\n'
        for p in sorted(payload.rglob('*')) if p.is_file()), encoding='utf-8')
    archive = stage / (PATCH + '.zip')
    write_archive(payload, archive, int(git(source, 'show', '-s', '--format=%ct', commit)))
    (stage / (archive.name + '.sha256')).write_text(f'{sha(archive)}  {archive.name}\n', encoding='utf-8')
    exported = []
    for row in exports:
        target = stage / 'viewer_packages' / Path(row['package']).name
        target.parent.mkdir(exist_ok=True);shutil.copy2(row['package'], target)
        record = dict(row);record['stage_relative_package'] = target.relative_to(stage).as_posix();exported.append(record)
    write_json(stage / 'VIEWER_PACKAGES.json', dict(modules=exported,
               publish_exports=qualified.get('publish_viewer_exports') is True))
    # Cumulative proof uses only a new private copy; previous source and ZIP stay read-only.
    p019 = Path('/srv/gxtxt/agents/scratch/DEV111-P019-MAIN/framework')
    require(git(p019, 'rev-parse', 'HEAD') == P019_COMMIT and not git(p019, 'status', '--porcelain'), 'P019 source changed')
    fresh = stage / 'fresh-cumulative'
    shutil.copytree(p019, fresh, ignore=shutil.ignore_patterns('.git', '__pycache__'))
    with zipfile.ZipFile(old_zip) as z:
        entries = zip_members(z)
        for name, entry in entries.items():
            target = member_path(fresh, name);target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(z.read(name));target.chmod((entry.external_attr >> 16) & 0o777 or 0o644)
    for name, value in before.items():
        require(sha(member_path(fresh, name)) == value, 'P019 + exact P020 differs from baseline: ' + name)
    old_notes = inventory(fresh / 'patch_notes/DEV111-P020')
    apply_overlay(fresh, archive, mutate=True)
    for name, value in after.items():
        require(sha(member_path(fresh, name)) == value, 'Fresh cumulative P021 source differs: ' + name)
    subprocess.run([sys.executable, '-I', '-B', str(source / 'validation/dev111_p021/fresh_startup.py'),
                    str(fresh), str(stage / 'fresh-startup')], check=True, timeout=90)
    # A divergent postimage must fail globally before any rollback mutation.
    probe = fresh / rows[-1]['path'];original = probe.read_bytes();probe.write_bytes(original + b'\nP021 divergence test\n')
    poisoned = {row['path']: sha(fresh / row['path']) for row in rows}
    try:
        rollback_overlay(fresh, mutate=True)
    except GuardError:
        pass
    else:
        raise GuardError('Divergent rollback was not refused')
    require(poisoned == {row['path']: sha(fresh / row['path']) for row in rows}, 'Rollback mutated before rejecting divergence')
    probe.write_bytes(original)
    rollback_overlay(fresh, mutate=True)
    for name, value in before.items():
        require(sha(member_path(fresh, name)) == value, 'Rollback did not restore full P020 source: ' + name)
    for row in rows:
        if row['before_sha256'] is None:
            require(not (fresh / row['path']).exists(), 'Added P021 file survived rollback')
    require(inventory(fresh / 'patch_notes/DEV111-P020') == old_notes, 'Historical P020 notes changed')
    baseline_guards(base, pins)
    require(inventory(source) == after and not git(source, 'status', '--porcelain'), 'Source changed during packaging')
    result = dict(status='TECHNICAL_INTEGRITY_PASS', patch=PATCH, source_commit=commit,
                  zip_sha256=sha(archive), zip_bytes=archive.stat().st_size, changed_files=len(rows),
                  baseline_files_verified=len(before), p020_manifest_postimages_verified=len(old_manifest['changed_files']),
                  cumulative_p019_p020_p021='PASS', guarded_p021_p020_rollback='PASS', divergence_before_mutation='PASS',
                  historical_p020_notes_retained='PASS', fresh_public_api_startup='PASS', protected_originals_unchanged=True,
                  module_checksum_entries=inventories, native_source_binary_identity=qualified['native_builds'],
                  actual_qualification_gates=qualified['gates'], blocked_required_gates=blocked,
                  ready_for_user_acceptance=qualified['ready_for_user_acceptance'],
                  incomplete_candidate=qualified.get('incomplete_candidate_authorized') is True,
                  deposit_authorized=qualified.get('deposit_authorized') is True,
                  installed=False, p020_user_acceptance='WITHHELD', user_vnc_acceptance='OPEN')
    write_json(stage / 'VERIFICATION.json', result)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    try:
        main()
    except (GuardError, OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        raise SystemExit('REFUSED: ' + str(error))
