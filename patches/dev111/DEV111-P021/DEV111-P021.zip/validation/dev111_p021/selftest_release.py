#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Synthetic P021 release guards only: no real framework, GUI or release writes."""
from pathlib import Path
import argparse, copy, json, shutil, stat, sys, zipfile
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import (PATCH, BASE_COMMIT, NOTES, BINARIES, GuardError, require,
                            digest, sha, inventory, write_json, fresh_scratch,
                            apply_overlay, rollback_overlay, zip_members, check_qualification)


def expect_refusal(operation, note):
    try:
        operation()
    except GuardError:
        return dict(test=note, status='PASS')
    raise GuardError('Unexpected acceptance: ' + note)


def make_package(root, archive_path, malicious=None):
    before = b'P020 geometry adapter\n';after = b'P021 geometry adapter\n';added = b'new mapper\n';anchor = b'unchanged science\n'
    (root / 'core').mkdir(parents=True)
    (root / 'core/a').write_bytes(before);(root / 'core/a').chmod(0o644)
    (root / 'core/science').write_bytes(anchor)
    prior_notes = root / 'patch_notes/DEV111-P020';prior_notes.mkdir(parents=True)
    (prior_notes / 'historical.md').write_bytes(b'Original P020 technical baseline, not accepted\n')
    rows = [dict(path='core/a', action='replace', before_sha256=digest(before), after_sha256=digest(after),
                 before_mode=0o644, after_mode=0o755, bytes=len(after)),
            dict(path='core/z', action='add', before_sha256=None, after_sha256=digest(added),
                 before_mode=None, after_mode=0o755, bytes=len(added))]
    manifest = dict(patch=PATCH, baseline_commit=BASE_COMMIT, source_commit='synthetic-reviewed-P021',
                    changed_files=rows, protected_files={'core/science': digest(anchor)})
    data = {'core/a': after, 'core/z': added,
            NOTES + '/FILES.json': (json.dumps(manifest) + '\n').encode(),
            NOTES + '/rollback-preimages/core/a': before,
            NOTES + '/README.md': b'Synthetic test only\n'}
    data[NOTES + '/PAYLOAD_SHA256SUMS'] = ''.join(f'{digest(raw)}  {name}\n' for name, raw in sorted(data.items())).encode()
    with zipfile.ZipFile(archive_path, 'x') as archive:
        for name, raw in data.items():
            entry = zipfile.ZipInfo(name);entry.create_system = 3
            entry.external_attr = (stat.S_IFREG | (0o755 if name in ('core/a','core/z') else 0o644)) << 16
            archive.writestr(entry, raw)
        if malicious:
            name, raw, mode = malicious
            entry = zipfile.ZipInfo(name);entry.create_system=3;entry.external_attr=mode << 16
            archive.writestr(entry, raw)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__);parser.add_argument('new_scratch_output', type=Path)
    args = parser.parse_args();output = fresh_scratch(args.new_scratch_output);output.mkdir(mode=0o700)
    root = output / 'framework';archive = output / 'DEV111-P021.zip';manifest=make_package(root, archive)
    initial = inventory(root);old_notes = inventory(root / 'patch_notes/DEV111-P020');results=[]
    apply_overlay(root, archive, mutate=False)
    require(inventory(root)==initial, 'Apply preflight wrote files');results.append(dict(test='apply read-only preflight', status='PASS'))
    # Invalid final path must be caught before even the first valid replacement.
    (root / 'core/z').write_bytes(b'foreign file')
    poisoned=inventory(root);results.append(expect_refusal(lambda:apply_overlay(root,archive,True), 'all-before-mutation added-path collision'))
    require(inventory(root)==poisoned, 'Apply mutated before refusing collision');(root/'core/z').unlink()
    apply_overlay(root, archive, mutate=True)
    require(stat.S_IMODE((root/'core/a').stat().st_mode)==0o755 and stat.S_IMODE((root/'core/z').stat().st_mode)==0o755, 'Executable modes lost')
    results.append(dict(test='exact postimages and executable modes',status='PASS'))
    changed=(root/'core/z').read_bytes();(root/'core/z').write_bytes(changed+b'changed')
    poisoned=inventory(root);results.append(expect_refusal(lambda:rollback_overlay(root,True),'all-before-mutation divergent rollback'))
    require(inventory(root)==poisoned,'Rollback changed earlier file before refusing later file');(root/'core/z').write_bytes(changed)
    backup=root/NOTES/'rollback-preimages/core/a';prior=backup.read_bytes();backup.write_bytes(b'bad preimage')
    poisoned=inventory(root);results.append(expect_refusal(lambda:rollback_overlay(root,True),'rollback backup integrity'))
    require(inventory(root)==poisoned,'Bad backup caused mutation');backup.write_bytes(prior)
    (root/'core/science').write_bytes(b'wrong science')
    poisoned=inventory(root);results.append(expect_refusal(lambda:rollback_overlay(root,True),'protected scientific anchor integrity'))
    require(inventory(root)==poisoned,'Anchor refusal caused mutation');(root/'core/science').write_bytes(b'unchanged science\n')
    rollback_overlay(root,False);require((root/'core/z').exists(),'Rollback preflight wrote files')
    rollback_overlay(root,True)
    require((root/'core/a').read_bytes()==b'P020 geometry adapter\n' and not(root/'core/z').exists(), 'P020 restore differs')
    require(stat.S_IMODE((root/'core/a').stat().st_mode)==0o644,'Original mode not restored')
    require(inventory(root/'patch_notes/DEV111-P020')==old_notes,'Historical notes changed')
    results.append(dict(test='full P020 preimages/modes and historical notes restored',status='PASS'))
    for name in ('../escape','/absolute','evil\\escape','C:drive'):
        path=output/('bad'+str(len(results))+'.zip')
        with zipfile.ZipFile(path,'x') as z:z.writestr(name,b'bad')
        with zipfile.ZipFile(path) as z:results.append(expect_refusal(lambda:zip_members(z),'unsafe archive path '+repr(name)))
    path=output/'symlink.zip'
    with zipfile.ZipFile(path,'x') as z:
        entry=zipfile.ZipInfo('link');entry.create_system=3;entry.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(entry,b'/tmp')
    with zipfile.ZipFile(path) as z:results.append(expect_refusal(lambda:zip_members(z),'archive symlink refusal'))
    path=output/'prefix.zip'
    with zipfile.ZipFile(path,'x') as z:z.writestr('a',b'file');z.writestr('a/b',b'child')
    with zipfile.ZipFile(path) as z:results.append(expect_refusal(lambda:zip_members(z),'archive file/directory prefix collision'))
    # Qualification preserves a real FAIL separately from technical/source checks.
    evidence=output/'synthetic-evidence.json';write_json(evidence,{'hardware_color':'FAIL','software_color':'PASS'})
    pin=dict(path=str(evidence),sha256=sha(evidence));files={name:digest(name.encode()) for name in BINARIES};files['core/native3d/test.cpp']=digest(b'source')
    value=dict(schema='gxtxt.dev111.p021.qualification.v1',source_commit='reviewed',reviewed_by='MAIN1',package_authorized=True,
               ready_for_user_acceptance=False,installed=False,user_vnc_acceptance='OPEN',final_runtime_pins=files,
               native_builds=[dict(binary=n,binary_sha256=files[n],source_pins={'core/native3d/test.cpp':files['core/native3d/test.cpp']},receipt=str(evidence),receipt_sha256=sha(evidence)) for n in BINARIES],
               gates=[dict(id='hardware-color',status='FAIL',required_for_release=True,note='Observed hardware color failure',evidence=[pin]),
                      dict(id='software-color',status='PASS',required_for_release=True,note='Observed software colors correct',evidence=[pin])])
    results.append(expect_refusal(lambda:check_qualification(value,'reviewed',files,set(files)), 'required hardware FAIL blocks ready packaging'))
    candidate=copy.deepcopy(value);candidate['incomplete_candidate_authorized']=True
    blocked=check_qualification(candidate,'reviewed',files,set(files))
    require(blocked==['hardware-color'] and candidate['gates'][0]['status']=='FAIL','Candidate hid failure')
    results.append(dict(test='explicit incomplete candidate preserves hardware FAIL and software PASS',status='PASS'))
    stale=copy.deepcopy(candidate);stale['source_commit']='different'
    results.append(expect_refusal(lambda:check_qualification(stale,'reviewed',files,set(files)),'qualification source identity refusal'))
    write_json(output/'RESULT.json',dict(status='PASS',scope='synthetic packaging contracts, not GUI/product acceptance',tests=results,
               original_frameworks_touched=False,release_or_mirror_writes=False))
    print(json.dumps({'status':'PASS','tests':len(results),'output':str(output)},indent=2))

if __name__=='__main__':
    try:main()
    except (GuardError,OSError,ValueError,KeyError) as error:raise SystemExit('FAIL: '+str(error))
