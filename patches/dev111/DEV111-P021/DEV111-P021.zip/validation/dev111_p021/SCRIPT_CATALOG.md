# DEV111-P021 incremental packaging helpers

Scope: exact deposited P020 `6f6c1ce584321a522d440219dd22101541a0180d` to
reviewed P021 only. P019 is accepted; P020 is the technical baseline with user
acceptance withheld. These new helpers replace neither historical scripts nor
scientific services. MAIN1 alone authorizes final packaging and deposition.

- `python3 -I -B selftest_release.py NEW_SCRATCH_OUTPUT`: synthetic small-file
  contract tests of path/member guards, all-before-mutation apply/rollback,
  divergence rejection, executable modes and explicit qualification status.
  Writes only its new output under `/srv/gxtxt/agents/scratch/`; no real framework,
  release, user Session, GUI, native build or acceptance claim.
- `package.py P020_FRAMEWORK P021_SOURCE NEW_STAGE BASELINE_JSON QUALIFICATION_JSON
  VIEWER_PACKAGES_JSON`: final reviewed source-only entrypoint. Requires clean
  local committed P021 source, immutable baseline/archive/history/TODO pins,
  explicit externally supplied MAIN1 qualification and source/binary identities.
  Creates only a fresh scratch stage, incremental ZIP, full isolated cumulative
  P019→P020→P021 application proof and guarded P021→P020 rollback. Does not execute
  old pinned deployment scripts, install, activate, fetch or change originals.
- `apply.py FRAMEWORK P021_ZIP [--apply]`: default read-only preflight of all
  supplied postimages and actual P020 preimages. `--apply` is an explicit product
  overlay command after application shutdown; validates everything before its
  first write. Packaging uses it only inside its new private proof copy.
- `rollback.py FRAMEWORK [--check]`: explicit guarded P021 product rollback;
  `--check` is read-only. Checks every modified postimage and backup before its
  first write; preserves P020/P021 notes and all Session/preferences/log files.
  Packaging invokes it only in the new private application proof copy.
- `deposit.py STAGE NEW_RELEASE GXTXT_MIRROR_ROOT`: final MAIN1-only new-target
  deposit. Validates reviewed stage/archive/evidence before creating a new P021
  release and matching framework archive/expanded mirrors. Optional CAD1/CAD2
  exports are copied only when supplied as exact public Development exports;
  no other external plugin or Session Generator is migrated. No activation,
  prior release overwrite or private user content collection.

`release_common.py` is the shared finite packaging guard implementation, not a
runtime CORE subsystem. `QUALIFICATION_SCHEMA.md` documents required external
review evidence; none of these helpers synthesizes GUI/performance PASS.
- `inspect_candidate.py SNAPSHOT LOCAL_SOURCE_REPOSITORY COMMIT BASELINE_JSON
  NEW_REPORT_JSON`: bounded read-only source preparation check against a frozen
  snapshot. Verifies every P020→specified-commit changed file, protected native/
  History/scheduler/SDK anchors, three module checksum lists and three Linux
  x86-64 binary headers. Writes only a new scratch JSON report; does not assert
  GUI acceptance or matching compiler provenance without external receipts.
- `fresh_startup.py FRAMEWORK NEW_OUTPUT`: P021-specific public Development
  `api_catalog` startup smoke, with private HOME/XDG/TMPDIR/Job paths and60s
  subprocess bound. Verifies shared Native2D/3D, scheduling, sprite and diagnostics
  contracts remain discoverable. Writes only new scratch logs/receipt; no GUI or
  compiled Viewer qualification claim. Packaging runs it once on fresh unpacking.

`collect_evidence.py WHITELIST_JSON NEW_OUTPUT`: copy only explicit reviewed SHA-pinned synthetic evidence from enumerated P021 MAIN2/component scratch roots. At most32MiB; refuse symlinks/traversal, Session/cache/config/resource/framework trees and all non-whitelisted files. Never reads original user screenshots or private Sessions; writes only NEW_OUTPUT inside isolated MAIN1framework documentation. Not a test execution/acceptance claim. OS NVIDIA files are outside allowed roots and never included.

Post-reboot Software-policy regression: focused native/GUI checks are cataloged separately in `/srv/gxtxt/agents/scratch/DEV111-P021-SUPPORT-NVIDIA/SCRIPT_CATALOG.md` and MAIN2 postreboot-plan. No OS/package/Session writes from these checks; product change is limited to explicit child-only Mesa vendor selection in the existing v1/v2 Software launchers. No native binary rebuild is needed.

Final source metadata refresh hashes the current SCRIPT_CATALOG.md checksum leaf
and updates only changed/new P021 source/evidence entries in the inherited root
SHA256SUMS, excluding that inventory's self hash. It preserves unrelated baseline
entries; the release FILES.json is authoritative for incremental pre/post images.
Runs only in MAIN1's isolated source before its clean final commit, not against
installed or protected sources.
