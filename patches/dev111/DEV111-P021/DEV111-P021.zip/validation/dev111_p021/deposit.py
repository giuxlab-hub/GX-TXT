#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""MAIN1-only new P021 release/mirrors; never install or activate."""
from pathlib import Path
import argparse, json, shutil, sys, zipfile
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import PATCH, NOTES, GuardError, require, sha, digest, read_json, write_json, member_path, zip_members, validate_rows


def unpack(archive, target):
    with zipfile.ZipFile(archive) as z:
        entries = zip_members(z)
        target.mkdir(parents=True)
        for name, entry in entries.items():
            path = member_path(target, name);path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(z.read(name));path.chmod((entry.external_attr >> 16) & 0o777 or 0o644)
            require(sha(path) == digest(z.read(name)), 'Expanded mirror differs: ' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('stage', 'new_release', 'gxtxt_mirror_root'):
        parser.add_argument(name, type=Path)
    args = parser.parse_args()
    stage, release, mirrors = args.stage.resolve(), args.new_release.resolve(), args.gxtxt_mirror_root.resolve()
    require(stage.is_relative_to('/srv/gxtxt/agents/scratch'), 'Reviewed scratch stage required')
    require(release.parent == Path('/srv/gxtxt/releases/dev111/patches') and release.name.startswith('0021-'),
            'New DEV111 0021 patch-series destination required')
    require(mirrors == Path('/home/giu/electronics-server/scripts/GXTXT').resolve(), 'Established GXTXT mirror root required')
    archive = stage / (PATCH + '.zip');proof = read_json(stage / 'VERIFICATION.json')
    require(proof.get('status') == 'TECHNICAL_INTEGRITY_PASS' and proof.get('patch') == PATCH,
            'Verified technical package required')
    require(proof.get('installed') is False and proof.get('user_vnc_acceptance') == 'OPEN', 'Invalid install/acceptance claim')
    require(proof.get('deposit_authorized') is True, 'Explicit external MAIN1 deposit authorization required')
    require(sha(archive) == proof['zip_sha256'] and archive.stat().st_size == proof['zip_bytes'], 'Staged archive changed')
    require((stage / (archive.name + '.sha256')).read_text().strip() == f'{sha(archive)}  {archive.name}', 'Archive checksum file differs')
    with zipfile.ZipFile(archive) as z:
        zip_members(z)
        manifest = json.loads(z.read(NOTES + '/FILES.json'));validate_rows(manifest)
        qualified = json.loads(z.read(NOTES + '/QUALIFICATION.json'))
        require(manifest['source_commit'] == proof['source_commit'] == qualified['source_commit'], 'Source identity differs')
        require(proof['actual_qualification_gates'] == qualified['gates'], 'Qualification status changed')
        require(proof['ready_for_user_acceptance'] == qualified['ready_for_user_acceptance'], 'Readiness claim changed')
        require(qualified.get('deposit_authorized') is True, 'Archive does not authorize deposit')
    packages = read_json(stage / 'VIEWER_PACKAGES.json')
    module_rows = packages.get('modules', [])
    require({r['module_id'] for r in module_rows} == {'viewer.test_cad_1', 'viewer.test_cad_2'}, 'Only CAD1/CAD2 exports admitted')
    framework_archive = mirrors / 'framework/archives/patches' / archive.name
    expanded = mirrors / 'framework/expanded/patches' / PATCH
    targets = [release, framework_archive, Path(str(framework_archive) + '.sha256'), expanded]
    exports = []
    for row in module_rows:
        package = member_path(stage, row['stage_relative_package'])
        require(package.is_file() and sha(package) == row['package_sha256'], 'Staged public export changed')
        with zipfile.ZipFile(package) as z:
            zip_members(z)
        if packages.get('publish_exports') is True:
            ident = package.stem + '_dev111_p021'
            ma = mirrors / 'external_plugins/archives' / (ident + '.zip')
            me = mirrors / 'external_plugins/expanded' / ident
            targets.extend([ma, Path(str(ma) + '.sha256'), me])
            exports.append((row, package, ma, me))
    require(all(not p.exists() and not p.is_symlink() for p in targets), 'Refusing existing release/mirror target')
    # Everything above is read-only. The following writes create only new destinations.
    release.mkdir(parents=True)
    for name in (archive.name, archive.name + '.sha256', 'VERIFICATION.json', 'VIEWER_PACKAGES.json'):
        shutil.copy2(stage / name, release / name)
    with zipfile.ZipFile(archive) as z:
        for name in ('README.md', 'FINAL_HANDOFF.md', 'VALIDATION_REPORT.md', 'PERFORMANCE_REPORT.md',
                     'KNOWN_LIMITATIONS.md', 'ARCHITECTURE_HANDOFF.md', 'LIFECYCLE_REPORT.md',
                     'CUBE_COLOR_REPORT.md', 'FILES.json', 'SOURCE.json', 'QUALIFICATION.json',
                     'apply.py', 'rollback.py', 'release_common.py'):
            (release / name).write_bytes(z.read(NOTES + '/' + name))
    framework_archive.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(archive, framework_archive)
    shutil.copy2(stage / (archive.name + '.sha256'), Path(str(framework_archive) + '.sha256'))
    unpack(archive, expanded)
    delivered = []
    for row, package, mirror, mirror_expanded in exports:
        target = release / 'viewer_packages' / package.name;target.parent.mkdir(exist_ok=True)
        shutil.copy2(package, target)
        target.with_name(target.name + '.sha256').write_text(f'{sha(target)}  {target.name}\n', encoding='utf-8')
        mirror.parent.mkdir(parents=True, exist_ok=True);shutil.copy2(package, mirror)
        mirror.with_name(mirror.name + '.sha256').write_text(f'{sha(mirror)}  {mirror.name}\n', encoding='utf-8')
        unpack(package, mirror_expanded)
        require(sha(target) == sha(mirror) == row['package_sha256'], 'Export deposit differs')
        delivered.append(dict(module_id=row['module_id'], archive=str(target), sha256=sha(target),
                              mirror=str(mirror), expanded=str(mirror_expanded)))
    require(sha(release / archive.name) == sha(framework_archive) == proof['zip_sha256'], 'Deposited patch differs')
    result = dict(status='DEPOSITED_WITH_RECORDED_QUALIFICATION', source_commit=proof['source_commit'],
                  archive=str(release / archive.name), bytes=archive.stat().st_size, sha256=sha(archive),
                  framework_archive=str(framework_archive), framework_expanded=str(expanded), viewer_exports=delivered,
                  ready_for_user_acceptance=proof['ready_for_user_acceptance'],
                  incomplete_candidate=proof['incomplete_candidate'], actual_qualification_gates=proof['actual_qualification_gates'],
                  installed=False, p020_user_acceptance='WITHHELD', user_vnc_acceptance='OPEN')
    write_json(release / 'DEPOSIT.json', result)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    try:
        main()
    except (GuardError, OSError, ValueError, KeyError) as error:
        raise SystemExit('REFUSED: ' + str(error))
