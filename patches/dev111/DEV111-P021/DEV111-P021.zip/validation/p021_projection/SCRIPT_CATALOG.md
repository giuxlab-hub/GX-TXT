# P021 projected CAD component validation

`xvfb-run -a tclsh validation/p021_projection/component.tcl FRAMEWORK FRESH_OUTPUT`
loads the public P020 CORE plus the P021 projection adapter from the specified
isolated framework. Uses an independent mapper fixture initially, then the
public Native3D mapper when available. Creates only a private Tk scene, synthetic
native geometry, screenshots, input/geometry receipts and private environment
state under FRESH_OUTPUT. No installed framework, user Session, release, TODO,
Native3D engine, network or activation writes. API checks are supplemental;
real GUI claims require recorded xdotool input and inspected screenshot evidence.

Optional component arguments `NATIVE_FIXTURES ZERO_BASED_CASE` load a private copy
of the compiled public Native3D projection module, native contract RECEIPT.tcldict
and matching native frame-N.png. Cases 2/6 exercise actual native snapshots for
inclined perspective/orthographic planes. This reuses immutable native rendered
frames; it qualifies projected pointer interaction over those real frames, not
live camera/worker GUI integration. No writes to the source evidence directory.

`python3 validation/p021_projection/build_sprite_alpha.py FRAMEWORK NEW_OUTPUT ?CAIRO_INCLUDE_DIRECTORY?`
builds only the existing gx2dtcl CMake target in a fresh private build directory
with Release/C++17 and BUILD_TESTING=OFF; no C/native3D geometry-engine edits.
Writes exact source/compiler/build commands, logs and binary SHA receipt in the
new output. Optional existing read-only Cairo header directory supplies the
normal CMake override when system development headers are absent; exact external
header hashes are recorded. MAIN1 reviews matching built artifact; no install/deposit/user writes.

`xvfb-run -a tclsh validation/p021_projection/sprite_alpha.tcl FRAMEWORK NEW_OUTPUT`
loads the matched private binary through normal CORE, draws actual Cairo sprites
over two different underlying Canvas frame colors, captures native X11 pixels
and verifies real alpha composition, legacy Tk colors (including spaced names),
transparent-hit behavior and atomic rejection. Writes screenshots, pixel/source
receipts only in fresh output; bounded public API GUI-render component check,
not production Native3D navigation acceptance. No private Session or activation.
