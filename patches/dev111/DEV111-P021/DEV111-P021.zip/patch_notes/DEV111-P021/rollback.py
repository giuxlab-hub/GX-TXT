#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit guarded P021-to-P020 rollback; no Session/preferences/log cleanup."""
from pathlib import Path
import argparse, sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import GuardError, rollback_overlay

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('framework', type=Path)
    parser.add_argument('--check', action='store_true', help='Read-only all-file rollback preflight')
    args = parser.parse_args()
    rollback_overlay(args.framework, mutate=not args.check)
    print('PREFLIGHT PASS (no writes)' if args.check else
          'Exact P020 product preimages restored; P020 and P021 notes retained. Restart required.')

if __name__ == '__main__':
    try:
        main()
    except (GuardError, OSError, ValueError, KeyError) as error:
        raise SystemExit('REFUSED: ' + str(error))
