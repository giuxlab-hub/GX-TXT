# SPDX-License-Identifier: GPL-3.0-or-later
# Three presentations of one Host.Advanced action surface. ViewerCommands owns
# command binding/menu/button state; the shared stock library owns every icon.
namespace eval ::GX::NativeCadSketch {variable mounts {};variable iconAssets {}}
proc ::GX::native2DCadActions {} {
    set result {}
    foreach {id label icon group} {
        select Select select Edit rectangle_selection {Box selection} selection_box Edit
        translate Move pan Edit rotate Rotate rotate Edit mirror Mirror mirror Edit pan Pan pan View
        point Point add_point Create line Line draw_line Create construction_line {Construction line} draw_line Create
        path Path draw_polyline Create polyline Polyline draw_polyline Create spline Spline draw_polyline Create
        rectangle Rectangle draw_rectangle Create circle Circle draw_circle Create arc Arc draw_circle Create
        ellipse Ellipse draw_circle Create quadratic_bezier {Quadratic Bezier} draw_polyline Create cubic_bezier {Cubic Bezier} draw_polyline Create
        join_points {Join points} junction Topology join_path {Join path} link Topology compound Compound group_rows Topology
        separate Separate duplicate Topology split_path {Split path} cut Topology split_composition {Split composition} cut Topology
        dimension Dimension label Relations horizontal Horizontal draw_line Relations vertical Vertical draw_line Relations
        coincident Coincident junction Relations parallel Parallel draw_line Relations perpendicular Perpendicular draw_line Relations
        tangent Tangent draw_circle Relations equal_length {Equal length} draw_line Relations equal_radius {Equal radius} draw_circle Relations fixed Fixed attach Relations
        finish Finish validate View cancel Cancel stop View fit Fit fit View undo Undo undo View redo Redo redo View save Save save View
    } {dict set result $id [dict create label $label icon $icon group $group default {}]}
    dict set result undo default Ctrl+z
    dict set result redo default Ctrl+y
    dict set result save default Ctrl+s
    return $result
}
proc ::GX::native2DCadActionState {sketch action} {
    set catalog [native2DCadActions]
    if {![dict exists $catalog $action]} {error {Unknown shared CAD action}}
    set live [expr {![catch {$sketch guard}]}];set checked 0;set enabled $live
    if {$live} {
        set host [$sketch get host];set advanced [$host advanced];set construct [dict get [$advanced state] construction]
        set selection [[$host context] selection snapshot]
        set selected [dict get $selection objects]
        set selectedCount [llength $selected]
        if {$action in {translate rotate mirror separate split_path split_composition}} {set enabled [expr {$selectedCount>0}]}
        if {$action in {join_path compound}} {set enabled [expr {$selectedCount>=2}]}
        if {$action eq {join_points}} {
            set refs [dict get $selection references]
            set enabled [expr {$selectedCount==2 && [llength $refs]==2}]
            foreach ref $refs {if {[dict get $ref entity] ne {control}} {set enabled 0}}
        }
        if {$action in {split_path split_composition separate}} {
            set enabled 0
            if {$selectedCount==1} {
                set definition [[$host context] object definition [lindex $selected 0]]
                set family [dict get $definition family]
                if {$action eq {separate}} {set enabled [expr {$family in {compound composite_path}}]}
                if {$action eq {split_composition}} {set enabled [expr {$family eq {composite_path} && [llength [dict get $definition parts]]>=2}]}
                if {$action eq {split_path}} {set enabled [expr {$family eq {path} && [llength [dict get $definition controls]]>=3}]}
            }
        }
        if {$action in {select pan translate rotate mirror rectangle_selection}} {set checked [expr {[$host tool] eq [dict get {select select pan pan translate translate rotate rotate mirror mirror rectangle_selection rectangle} $action] && $construct eq {}}]}
        if {$construct ne {} && [dict get $construct family] eq $action} {set checked 1}
        if {$action in {undo redo}} {
            set history [scientificHistoryViewerStatus [$sketch get history_context]]
            set cursor [dict get $history cursor];set count [dict get $history count]
            set enabled [expr {$action eq {undo}?$cursor>0:$cursor<$count}]
        }
    }
    return [dict merge [dict get $catalog $action] [dict create id $action enabled $enabled checked $checked]]
}
proc ::GX::native2DCadActionPredicate {sketch action key} {return [dict get [native2DCadActionState $sketch $action] $key]}
proc ::GX::native2DCadActionInvoke {sketch action} {
    if {![dict get [native2DCadActionState $sketch $action] enabled]} {error {CAD action is unavailable in the current selection or lifetime}}
    set host [$sketch get host];set advanced [$host advanced]
    switch -- $action {
        select - translate - rotate - mirror - pan {$host tool $action}
        rectangle_selection {$host tool rectangle}
        point - line - construction_line - path - polyline - spline - rectangle - circle - arc - ellipse - quadratic_bezier - cubic_bezier {$host tool select;$advanced construction start $action}
        horizontal - vertical - coincident - parallel - perpendicular - tangent - equal_length - equal_radius - fixed {
            set refs [dict get [[$host context] selection snapshot] references]
            $advanced constraint start $action $refs
            set proposal [$advanced constraint state]
            if {[dict get $proposal status] eq {ready}} {$advanced constraint apply 0 [dict get $proposal specification]}
        }
        dimension {$advanced dimension start {} [dict get [[$host context] selection snapshot] references]}
        join_points - join_path - compound - separate - split_path - split_composition {
            set ids [dict get [[$host context] selection snapshot] objects]
            set options {}
            if {$action in {split_path split_composition}} {dict set options index 1}
            if {$action eq {join_points}} {
                set refs [dict get [[$host context] selection snapshot] references]
                if {[llength $refs]!=2} {error {Select two defining point controls}}
                dict set options index [[$host context] control point_index [lindex $refs 0]]
                dict set options target_index [[$host context] control point_index [lindex $refs 1]]
                dict set options tolerance 1e-8
                set ids [list [dict get [lindex $refs 0] object] [dict get [lindex $refs 1] object]]
            }
            set created [$advanced topology apply $action $ids $options]
            if {$action ne {join_points}} {
                set members {};foreach id $created {lappend members [dict create kind object id $id index 0]}
                $host select $members
            }
        }
        finish {$host event key Return}
        cancel {$host cancel explicit_cancel}
        fit {$host fit}
        undo - redo {$host cancel history;scientificHistoryViewerNavigate [$sketch get history_context] $action}
        save {$sketch save}
    }
    $host refresh final
    $sketch changed [dict get [native2DCadActions] $action label]
    return [dict create action $action status completed document_id [$sketch get document_id] state [$sketch actionState $action]]
}
proc ::GX::native2DCadPresentationAttach {sketch window} {
    variable ::GX::NativeCadSketch::mounts
    set module framework.native_cad_sketch
    if {![dict exists $::GX::ViewerCommands::catalogs $module]} {viewerCommandCatalogRegister $module [native2DCadActions] {} shortcuts framework}
    set handlers {}
    dict for {id spec} [native2DCadActions] {
        dict set handlers $id [dict create command [list $sketch invoke $id] enabled [list ::GX::native2DCadActionPredicate $sketch $id enabled] checked [list ::GX::native2DCadActionPredicate $sketch $id checked]]
    }
    viewerCommandsAttach $window $module $handlers [list $sketch guard]
    dict set mounts $window $sketch
    bind $window <Destroy> +[list ::GX::native2DCadPresentationDestroyed $window %W]
    return $window
}
proc ::GX::native2DCadPresentationDestroyed {window actual} {
    variable ::GX::NativeCadSketch::mounts
    if {$window eq $actual} {dict unset mounts $window}
}
proc ::GX::native2DCadMenu {sketch menu} {
    if {![winfo exists $menu]} {menu $menu -tearoff 0}
    set owner [$sketch widget]
    if {![dict exists $::GX::ViewerCommands::windows $owner]} {native2DCadPresentationAttach $sketch $owner}
    foreach group {Create Edit Topology Relations View} {
        set sub $menu.[string tolower $group];menu $sub -tearoff 0
        $menu add cascade -label $group -menu $sub
        dict for {id descriptor} [native2DCadActions] {
            if {[dict get $descriptor group] ne $group} continue
            viewerCommandMenuAdd $owner $sub $id
            set asset [native2DCadStockIcon [dict get $descriptor icon]]
            $sub entryconfigure end -image [viewerGuiIconPhoto $asset 20] -compound left
        }
    }
    return $menu
}
proc ::GX::native2DCadStockIcon {id} {
    variable ::GX::NativeCadSketch::iconAssets
    if {![dict exists $iconAssets $id]} {
        set record [dict get [viewerGuiIconCatalog] icons $id]
        dict set iconAssets $id [viewerGuiIconImport [dict get $record path] [dict get $record title] [dict get $record category] [dict get $record license]]
    }
    return [dict get $iconAssets $id]
}
proc ::GX::native2DCadPalette {sketch parent} {
    set frame $parent.cadPalette[incr ::GX::NativeCadSketch::serial]
    ttk::notebook $frame
    foreach group {Create Edit Topology Relations View} {
        set tab $frame.[string tolower $group];ttk::frame $tab
        $frame add $tab -text $group
        native2DCadPresentationAttach $sketch $tab
        set ids {};dict for {id spec} [native2DCadActions] {if {[dict get $spec group] eq $group} {lappend ids $id}}
        viewerCommandToolbarCreate $tab $tab.tools $ids
        pack $tab.tools -fill x -expand 1
        dict for {id button} [dict get $::GX::ViewerCommands::windows $tab toolbar buttons] {
            set asset [native2DCadStockIcon [dict get [native2DCadActions] $id icon]]
            uiFieldIconApply $button [dict create presentation icon_text icon_size 20 tooltip [dict get [native2DCadActions] $id label]] $asset
        }
    }
    return $frame
}
proc ::GX::native2DCadCanvasControls {sketch {parent {}}} {
    set host [$sketch get host];set canvas [$host canvas];set owner [$sketch widget]
    if {$parent ne {} && $parent ni [list $owner [winfo parent $canvas]]} {error {Canvas-owned controls use their existing ViewportHost; use palette for external placement}}
    set panel [native2DViewportPanelWidget $canvas cad_tools]
    if {[winfo exists $panel]} {native2DViewportPanelShow $canvas cad_tools 1;return $panel.body}
    set frame [native2DViewportPanelCreate $canvas cad_tools {Sketch tools} top-left {max_width 340 max_height 220 min_width 160 priority 0 close 0}]
    if {![dict exists $::GX::ViewerCommands::windows $owner]} {native2DCadPresentationAttach $sketch $owner}
    viewerCommandToolbarCreate $owner $frame.tools {select line circle dimension finish cancel fit undo redo save}
    pack $frame.tools -fill x
    dict for {id button} [dict get $::GX::ViewerCommands::windows $owner toolbar buttons] {
        set asset [native2DCadStockIcon [dict get [native2DCadActions] $id icon]]
        uiFieldIconApply $button [dict create presentation icon_only icon_size 24 tooltip [dict get [native2DCadActions] $id label]] $asset
    }
    ttk::menubutton $frame.commands -text {All CAD actions…} -menu $frame.commands.menu -takefocus 1
    native2DCadMenu $sketch $frame.commands.menu
    pack $frame.commands -anchor w -padx 3 -pady 2
    # Same command catalog and predicates in the embedded popup and the panel;
    # no second controller or independent selected/enabled state is introduced.
    bind $canvas <Button-3> +[list ::GX::uiMenuPopup $frame.commands.menu %X %Y]
    return $frame
}
proc ::GX::native2DCadPresentationRefresh {sketch} {
    variable ::GX::NativeCadSketch::mounts
    dict for {window owner} $mounts {
        if {$owner eq $sketch && [winfo exists $window]} {viewerCommandToolbarStatesRefresh $window;viewerCommandMenusRefresh $window;viewerCommandWidgetsRefresh $window}
    }
}

oo::define ::GX::NativeCadSketch::Component {
    variable w host scene scene3d document generation revision session model viewport opts worldCache worldBuilding worldDirty worldStamp rendererError status
    method attachViewer {} {
        set viewport [::GX::native3DViewportCreate $w.context [dict create projection orthographic axes_world 1]]
        pack $w.context -side right -fill both -expand 1 -before $w.surface
        ::GX::native3DViewportSubscribe $viewport error [list [self] rendererEvent]
        ::GX::native3DViewportBind $viewport [dict create kind cad_sketch sketch [self]]
    }
    method updateViewer {} {my guard;::GX::native3DViewportUpdate $viewport}
    method rendererEvent {handle event detail} {
        set rendererError [dict get $detail message];set status "3D preview unavailable: $rendererError"
        if {[winfo exists $w.status]} {$w.status configure -text $status}
        if {[dict get $opts changed_command] ne {} && ![catch {my state} state]} {uplevel #0 [list {*}[dict get $opts changed_command] $state]}
    }
    method worldBase {} {
        set view [::GX::viewerSceneDefaults]
        dict set view projection orthographic
        foreach {source target} {origin working_plane_origin normal working_plane_normal u_axis working_plane_u_axis} {dict set view $target [join [dict get $model plane $source] {;}]}
        dict set view working_plane_visible 1
        return [dict create layers {} view $view caption {Sketch · bounded Native3D visual sampling; exact definitions remain canonical} \
            document_id $document generation $generation session_token $session revision $revision display_policy bounded_visual_sampling publication 0]
    }
    method world_scene {} {
        my guard
        if {$worldCache eq {}} {set worldCache [my worldBase]}
        if {$worldBuilding || ([info exists ::GX::Engine3D::workerBusy] && $::GX::Engine3D::workerBusy)} {return [dict merge $worldCache {display_pending 1}]}
        if {$worldDirty} {
            set stamp $worldStamp;set worldBuilding 1
            try {set worldCache [my buildWorldScene];set worldDirty [expr {$stamp!=$worldStamp}]} finally {set worldBuilding 0}
        }
        return [dict merge $worldCache [dict create display_pending $worldDirty]]
    }
    method buildWorldScene {} {
        set layers {};set total 0
        foreach native [::GX::Native2D::core ids $scene] {
            set style [::GX::Native2D::core object_style $scene $native]
            if {![dict get $style visible]} continue
            set definition [::GX::Native2D::core sketch_definition $scene $native]
            # Each exact constituent receives its own bounded display line, so
            # Compound gaps never become invented connecting segments.
            set parts [list [dict create definition $definition]]
            if {[dict get $definition family] in {compound composite_path}} {
                set parts {}
                for {set ordinal 0} {$ordinal<[llength [dict get $definition parts]]} {incr ordinal} {lappend parts [::GX::Native2D::core composition_part $scene $native $ordinal]}
            }
            set partIndex 0
            foreach part $parts {
                if {[incr total]>4096} {error {Sketch 3D display exceeds4096 constituents}}
                set temp [::GX::Native2D::core scene]
                try {
                    set object [::GX::Native2D::core sketch_create $temp [dict get $part definition] 129]
                    if {[dict get $part definition family] eq {point}} {
                        set local [list [dict get [::GX::Native2D::core sketch_evaluate $temp $object 0] point]]
                    } else {set local [::GX::Native2D::core sketch_sample $temp $object 0 1 129 0 129]}
                } finally {::GX::Native2D::core destroy $temp}
                set world [dict get [my transform to_world $local] points]
                set indices {};for {set i 0} {$i<[llength $world]} {incr i} {lappend indices $i}
                set lines [list $indices];set points {}
                if {[llength $world]==1} {set lines {};set points {0}}
                set color [dict get $style color]
                dict set layers sketch_${native}_[incr partIndex] [dict create source_mode memory_geometry provenance cad_sketch_bounded_visual_sampling dataset_id {} layer_order $total visible 1 opacity 1 \
                    representation wireframe base_color [join [lrange $color 0 2] {;}] line_width 2 point_size 5 backface_culling 0 scalar_coloring 0 scalar_array {} local_transform {} texture {} \
                    vertices $world polylines $lines points $points triangles {} sketch_object $native]
            }
        }
        return [dict merge [my worldBase] [dict create layers $layers]]
    }
}
proc ::GX::nativeCadSketchIsManaged {handle} {
    return [expr {[info object isa object $handle] && [info object isa typeof $handle ::GX::NativeCadSketch::Component]}]
}
