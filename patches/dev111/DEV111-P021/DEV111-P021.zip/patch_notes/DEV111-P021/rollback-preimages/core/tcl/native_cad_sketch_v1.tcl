# SPDX-License-Identifier: GPL-3.0-or-later
# Managed exact planar Sketch. Native2D owns definitions/constraints; the
# existing Interactive Document and CORE History own durability and navigation.
namespace eval ::GX::NativeCadSketch {variable serial 0}
proc ::GX::nativeCadSketchApiInfo {} {
    return [dict create api_id NATIVE2D_API_v1 api_version 1 component cad_sketch factory nativeCadSketchCreate \
        methods {widget get state dirty world_scene command actions actionState invoke menu palette canvasControls present transform save close} \
        options {document_id working_unit plane presentation changed_command recovery_choice} \
        scientific_format gxtxt.native_cad_sketch.v1 history CORE_P017 exact_owner Native2D display_policy bounded_visual_sampling]
}
proc ::GX::nativeCadSketchCreate {parent {options {}}} {
    if {![winfo exists $parent]} {error {Sketch parent is unavailable}}
    return [::GX::NativeCadSketch::Component new $parent $options]
}
proc ::GX::NativeCadSketch::validate {record} {
    set state [expr {[dict exists $record base] ? [dict get $record base] : $record}]
    if {![dict exists $state format] || [dict get $state format] ne {gxtxt.native_cad_sketch.v1}} {error {Unsupported exact Sketch model}}
    foreach key {working_unit plane} {dict get $state $key}
    ::GX::unitRegistryConversionPlan [dict get $state working_unit] mm
    return 1
}
proc ::GX::NativeCadSketch::unavailable {args} {error {Use the managed Sketch component for scientific replay}}
::GX::scientificRecipeHostRegister core.native2d [dict create capture ::GX::NativeCadSketch::unavailable validate ::GX::NativeCadSketch::validate replay ::GX::NativeCadSketch::unavailable]

oo::class create ::GX::NativeCadSketch::Component {
    variable w host scene scene3d document generation revision session history model opts objects relations counter before status closing viewport timer failedConstruction newDocument worldCache worldBuilding worldDirty worldStamp rendererError savedHistoryRevision
    constructor {parent options} {
        set w {};set host {};set scene {};set scene3d {};set history {};set viewport {};set timer {};set closing 0;set failedConstruction 1;set newDocument {}
        set objects {};set relations {};set counter 0;set before {};set status Ready
        set worldCache {};set worldBuilding 0;set worldDirty 1;set worldStamp 0;set rendererError {}
        set savedHistoryRevision 0
        set opts [dict create document_id new working_unit mm plane {origin {0 0 0} normal {0 0 1} u_axis {1 0 0}} presentation canvas changed_command {}]
        foreach key [dict keys $options] {if {$key ni {document_id working_unit plane presentation changed_command recovery_choice}} {error "Unknown Sketch option: $key"}}
        set opts [dict merge $opts $options]
        if {[dict get $opts presentation] ni {canvas viewer}} {error {Sketch presentation must be canvas or viewer}}
        llength [dict get $opts changed_command]
        ::GX::unitRegistryConversionPlan [dict get $opts working_unit] mm
        ::GX::native2DEnsure
        set scene [::GX::Native2D::core scene]
        set model [dict create format gxtxt.native_cad_sketch.v1 working_unit [dict get $opts working_unit] plane [dict get $opts plane]]
        set document [dict get $opts document_id];set record {}
        if {$document eq {new} || $document eq {}} {
            set document [dict get [::GX::interactiveDocumentCreate core.native2d sketch gxtxt.native_cad_sketch.v1 1 [dict create model $model allocation_counter 0]] id]
            set newDocument $document
        } else {
            set saved [::GX::interactiveDocumentRead $document]
            if {[dict get $saved format] ne {gxtxt.native_cad_sketch.v1}} {error {Document is not an exact Sketch}}
            set payload [dict get $saved payload];set model [dict get $payload model]
            set counter [::GX::datasetPublicationV2DictDefault $payload allocation_counter 0]
            set record [::GX::datasetPublicationV2DictDefault $payload scientific_history {}]
        }
        ::GX::NativeCadSketch::validate $model
        set metadata [::GX::interactiveDocumentMetadata $document]
        set generation [dict get $metadata generation];set revision [dict get $metadata revision];set session [::GX::interactiveDocumentSessionToken]
        set scene3d [::GX::native3DGeometryOpen $document]
        # Existing Native3D validates/normalizes every physical frame. No Tcl
        # cross products or independent coordinate implementation belongs here.
        set frame [::GX::native3DGeometryCall $scene3d plane_frame [dict create plane [dict get $model plane]]]
        dict set model plane [dict remove $frame v_axis]
        set w $parent.sketch[incr ::GX::NativeCadSketch::serial]
        ttk::frame $w
        ttk::label $w.caption -text {Exact Sketch · local working plane}
        ttk::label $w.status -text $status -anchor w
        ttk::frame $w.surface
        pack $w.caption -side top -fill x
        pack $w.status -side bottom -fill x
        pack $w.surface -fill both -expand 1
        set callbacks {}
        foreach key {guard admit begin committed rollback advanced selected error presentation} {dict set callbacks $key [list [self] callback $key]}
        set host [::GX::native2DCadCanvasCreate $w.surface $scene [dict create selection_target detail callbacks $callbacks]]
        pack [$host canvas] -fill both -expand 1
        my restore $model
        set callbacks [dict create capture [list [self] capture] restore [list [self] restore] commit [list [self] project] guard [list [self] historyGuard] document_id $document parent $w]
        if {[dict exists $opts recovery_choice]} {dict set callbacks recovery_choice [dict get $opts recovery_choice]}
        set history [::GX::scientificHistoryContextAttach core.native2d $callbacks $record]
        set savedHistoryRevision [dict get [::GX::scientificHistoryViewerStatus $history] revision]
        bind $w <Destroy> [list [self] destroyed %W]
        my attachViewer
        $host refresh final
        set failedConstruction 0
    }
    destructor {
        set closing 1
        if {$timer ne {}} {after cancel $timer}
        if {$history ne {}} {catch {::GX::scientificHistoryContextClose $history 0}}
        if {$viewport ne {}} {catch {::GX::native3DViewportRelease $viewport}}
        if {$host ne {} && [llength [info commands $host]]} {catch {$host dispose}}
        if {$scene ne {}} {catch {::GX::Native2D::core destroy $scene}}
        if {$scene3d ne {}} {catch {::GX::native3DGeometryClose $scene3d}}
        if {$failedConstruction && $newDocument ne {}} {catch {::GX::interactiveDocumentDelete $newDocument}}
        if {$w ne {} && [winfo exists $w]} {destroy $w}
    }
    method widget {} {return $w}
    method get {key} {
        switch -- $key {
            scene {return $scene} host {return $host} context {return [$host context]} advanced {return [$host advanced]}
            document_id {return $document} plane {return [dict get $model plane]} working_unit {return [dict get $model working_unit]}
            history_context {return $history} viewport {return $viewport} widget {return $w} model {return [my capture]}
            default {error {Unknown Sketch property}}
        }
    }
    method guard {} {
        if {$closing || $session ne [::GX::interactiveDocumentSessionToken]} {error {Sketch Session lifetime is stale}}
        set owner [::GX::interactiveDocumentMetadata $document]
        if {[dict get $owner generation] ne $generation || [dict get $owner revision]!=$revision} {error {Sketch Document scope changed; reopen it}}
        ::GX::native3DGeometrySceneInfo $scene3d
        return 1
    }
    method historyGuard {} {my guard;return 1}
    method state {} {
        my guard
        return [dict create api_id NATIVE2D_API_v1 component cad_sketch widget $w document_id $document revision $revision generation $generation session_token $session \
            working_unit [dict get $model working_unit] plane [dict get $model plane] object_map $objects relationship_map $relations \
            host [$host state] advanced [[$host advanced] state] history_context $history history [::GX::scientificHistoryViewerStatus $history] \
            presentation [dict get $opts presentation] viewport $viewport status $status renderer_error $rendererError display_policy bounded_visual_sampling]
    }
    method logical {native mapping prefix} {
        dict for {id value} $mapping {if {$native==$value} {return $id}}
        return ${prefix}[incr counter]
    }
    method capture {} {
        set next [dict create format gxtxt.native_cad_sketch.v1 working_unit [dict get $model working_unit] plane [dict get $model plane]]
        set map {};set excluded [$host feedbackObjects]
        foreach native [::GX::Native2D::core ids $scene] {
            if {$native in $excluded} continue
            set id [my logical $native $objects s];dict set map $id $native
            set entry [dict create definition [::GX::Native2D::core sketch_definition $scene $native] style [::GX::Native2D::core object_style $scene $native] \
                direction [::GX::Native2D::core direction_marker $scene $native] role [::GX::Native2D::core identity_geometry_role $scene $native] \
                name [::GX::Native2D::core identity_name $scene $native] attributes [::GX::Native2D::core identity_attributes $scene $native]]
            # Selection is presentation state and never creates a scientific step.
            dict set entry style selected 0
            dict set next object/$id $entry
        }
        set objects $map;set map {}
        foreach rule [::GX::Native2D::core constraint_list $scene] {
            set native [dict get $rule id];set id [my logical $native $relations r];dict set map $id $native
            set rule [dict remove $rule id valid geometry_supported measured_value residual angular_residual enforcement general_solver]
            foreach field {a b axis} {
                if {[dict get $rule $field]==0} continue
                set found 0
                dict for {logical value} $objects {if {$value==[dict get $rule $field]} {dict set rule $field $logical;set found 1;break}}
                if {!$found} {error {Relationship references geometry outside this Sketch}}
            }
            dict set next relationship/$id $rule
        }
        set relations $map;set model $next
        return $next
    }
    method hydrate {staged snapshot} {
        set nextObjects {};set nextRelations {}
        try {
            dict for {key entry} $snapshot {
                if {![string match object/* $key]} continue
                set native [::GX::Native2D::core sketch_create $staged [dict get $entry definition] 257]
                set id [string range $key 7 end];dict set nextObjects $id $native
                ::GX::Native2D::core object_style $staged $native [dict get $entry style]
                ::GX::Native2D::core direction_marker $staged $native [dict get $entry direction]
                dict for {name value} [dict get $entry attributes] {::GX::Native2D::core identity_attribute $staged $native $name $value}
                # Role/name getters have implicit defaults. Writing those
                # defaults would invent identity attributes on first reopen.
                if {[::GX::Native2D::core identity_geometry_role $staged $native] ne [dict get $entry role] || [::GX::Native2D::core identity_name $staged $native] ne [dict get $entry name]} {error {Sketch identity fields disagree with their exact retained attributes}}
            }
            dict for {key rule} $snapshot {
                if {![string match relationship/* $key]} continue
                foreach field {a b axis} {if {[dict get $rule $field] ne {0}} {dict set rule $field [dict get $nextObjects [dict get $rule $field]]}}
                set receipt [::GX::Native2D::core constraint_create $staged $rule]
                dict set nextRelations [string range $key 13 end] [dict get $receipt id]
            }
            return [list $nextObjects $nextRelations]
        } on error {message options} {
            foreach native [dict values $nextObjects] {catch {::GX::Native2D::core delete $staged $native}}
            return -options $options $message
        }
    }
    method restore {snapshot} {
        ::GX::NativeCadSketch::validate $snapshot
        set staged [::GX::Native2D::core scene]
        try {my hydrate $staged $snapshot} finally {::GX::Native2D::core destroy $staged}
        # Preserve the native scene's monotonic ID allocation. Replacing it
        # would allow an old raw object/epoch reference to alias a restored ID.
        # Append/validate all new owners before removing any current science.
        [$host advanced] dispose
        $host cancel restore
        set prior [::GX::Native2D::core ids $scene]
        lassign [my hydrate $scene $snapshot] nextObjects nextRelations
        $host select {}
        foreach native $prior {::GX::Native2D::core delete $scene $native}
        set objects $nextObjects;set relations $nextRelations;set model $snapshot
        my changed {Sketch restored}
    }
    method project {record} {
        my guard
        set result [::GX::native3DGeometryCheckpoint $scene3d [dict create model [my capture] allocation_counter $counter scientific_history $record]]
        set revision [dict get $result revision]
        set savedHistoryRevision [dict get [::GX::scientificHistoryViewerStatus $history] revision]
        return $result
    }
    method begin {} {
        my guard
        if {![::GX::scientificHistoryViewerPrepareEdit $history]} {error {Sketch History edit cancelled}}
        set before [my capture]
        return sketch-edit
    }
    method committed {operation} {
        foreach native [::GX::Native2D::core ids $scene] {
            if {$native in [dict values $objects] || $native in [$host feedbackObjects]} continue
            set style [::GX::Native2D::core object_style $scene $native]
            if {[dict get $style color] eq {1.0 1.0 1.0 1.0}} {::GX::Native2D::core object_style $scene $native {color {0.1 0.45 0.75 1} line_width 2}}
        }
        set after [my capture];set patch {}
        dict for {key value} $after {if {![dict exists $before $key] || [dict get $before $key] ne $value} {dict set patch $key $value}}
        foreach key [dict keys $before] {if {![dict exists $after $key]} {dict set patch $key @gxtxt.recipe.delete}}
        if {$patch eq {}} {return {changed 0}}
        set semantic [dict create api_id NATIVE_2D_GEOMETRY_API_v1 api_version 1 operation $operation parameters {} targets {} result_ids {} working_unit [dict get $model working_unit]]
        set receipt [::GX::scientificHistoryViewerSubmitPatch $history $patch $operation $semantic]
        set before {};my changed $operation
        return $receipt
    }
    method callback {kind event} {
        switch -- $kind {
            guard - admit {return [my guard]}
            begin {return [my begin]}
            committed {return [my committed [dict get $event operation]]}
            rollback {if {$before ne {}} {my restore $before};set before {};return}
            advanced {
                switch -- [dict get $event phase] {
                    admit {return [my guard]}
                    begin {return [my begin]}
                    committed {return [my committed [dict get $event operation]]}
                    rollback {if {$before ne {}} {my restore $before};set before {}}
                    rejected - cancelled {set before {};my changed Cancelled}
                }
            }
            selected {my changed {Selection changed}}
            error {my changed [dict get $event error]}
            presentation {my changed $status}
        }
        return {}
    }
    method changed {message} {
        set status $message
        set worldDirty 1;incr worldStamp
        if {$w ne {} && [winfo exists $w.status]} {$w.status configure -text $message}
        if {$timer eq {} && !$closing} {set timer [after idle [list [self] notify]]}
    }
    method notify {} {
        set timer {}
        if {$closing} return
        if {[info exists ::GX::Engine3D::workerBusy] && $::GX::Engine3D::workerBusy} {set timer [after 25 [list [self] notify]];return}
        if {$viewport ne {} && [catch {my updateViewer} message]} {
            set rendererError $message;set status "3D preview unavailable: $message"
            if {[winfo exists $w.status]} {$w.status configure -text $status}
        }
        ::GX::native2DCadPresentationRefresh [self]
        if {[dict get $opts changed_command] ne {} && ![catch {my state} state]} {uplevel #0 [list {*}[dict get $opts changed_command] $state]}
    }
    method transform {direction points} {
        my guard
        if {[llength $points]>65536} {error {Sketch transform batch exceeds65536 points}}
        if {$direction in {local_to_device device_to_local}} {
            set op [expr {$direction eq {local_to_device}?{device}:{world}}];set result {}
            foreach point $points {lappend result [::GX::Native2D::core $op $scene $point]}
            return [dict create direction $direction points $result working_unit [dict get $model working_unit] owner Native2D]
        }
        if {$direction ni {to_world to_plane}} {error {Choose to_world, to_plane, local_to_device or device_to_local}}
        set source {}
        foreach point $points {
            if {$direction eq {to_world} && [llength $point]==2} {lappend point 0}
            if {[llength $point]!=3} {error {World frame mapping requires explicit XYZ; local XY is accepted only for to_world}}
            lappend source $point
        }
        set receipt [::GX::native3DGeometryCall $scene3d plane_frame [dict create plane [dict get $model plane] points $source direction $direction]]
        return [dict merge $receipt [dict create direction $direction working_unit [dict get $model working_unit] owner Native3D.plane_frame]]
    }
    method command {action} {return [my invoke $action]}
    method actions {} {return [::GX::native2DCadActions]}
    method actionState {action} {return [::GX::native2DCadActionState [self] $action]}
    method invoke {action} {
        my guard
        return [::GX::native2DCadActionInvoke [self] $action]
    }
    method menu {menu} {return [::GX::native2DCadMenu [self] $menu]}
    method palette {parent} {return [::GX::native2DCadPalette [self] $parent]}
    method canvasControls {{parent {}}} {if {$parent eq {}} {set parent $w};return [::GX::native2DCadCanvasControls [self] $parent]}
    method present {mode parent} {
        switch -- $mode {menu {return [my menu $parent]} palette {return [my palette $parent]} canvas {return [my canvasControls $parent]} default {error {Choose menu, palette or canvas}}}
    }
    method dirty {} {my guard;return [expr {[dict get [::GX::scientificHistoryViewerStatus $history] revision]!=$savedHistoryRevision}]}
    method save {} {my guard;$host cancel save;return [::GX::scientificHistoryViewerFlush $history]}
    method close {} {my save;my destroy}
    method destroyed {actual} {if {$actual eq $w && !$closing} {my destroy}}
}
source [file join [file dirname [info script]] native2d_cad_presentation_v1.tcl]
