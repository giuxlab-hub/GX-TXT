# SPDX-License-Identifier: GPL-3.0-or-later
# Legacy presentation bridge to the same public CORE managed Sketch component.
# The Workbench retains its existing Document, plane and P017 History owner.
namespace eval ::GX::Workbench3D {variable sketchComponent {};variable sketchWindow {}}
proc ::GX::Workbench3D::sketchClose {} {
    variable sketchComponent;variable sketchWindow
    if {$sketchComponent ne {} && [llength [info commands $sketchComponent]]} {
        if {[catch {$sketchComponent guard}]} {$sketchComponent destroy} else {$sketchComponent close}
    }
    set sketchComponent {}
    if {$sketchWindow ne {} && [winfo exists $sketchWindow]} {destroy $sketchWindow}
    set sketchWindow {}
}
proc ::GX::Workbench3D::sketchGuiCommand {action {values {}}} {
    variable sketchComponent;variable sketchWindow;variable document;variable model;variable module;variable provider
    if {$action ni {sketch_create sketch_open sketch_close}} {error {Unknown finite Workbench Sketch command}}
    if {$action eq {sketch_close}} {
        if {$values ne {}} {error {Sketch close accepts no values}}
        sketchClose
        return [dict create action $action status closed workbench_document_id $document]
    }
    if {![llength [info commands ::GX::nativeCadSketchCreate]]} {source [file join $::GX::scriptDir core tcl native_cad_sketch_v1.tcl]}
    set requested new
    if {$action eq {sketch_create}} {
        if {$values ne {}} {error {Sketch create uses the Workbench working plane and unit}}
    } else {
        if {$values ne {} && [dict keys $values] ne {document_id}} {error {Sketch open accepts only document_id}}
        if {[dict exists $values document_id]} {
            set requested [dict get $values document_id]
            if {![dict exists $model sketch_documents $requested]} {error {Sketch is not associated with this Workbench Document}}
        } elseif {[dict exists $model sketch_documents] && [dict size [dict get $model sketch_documents]]} {
            set requested [lindex [dict keys [dict get $model sketch_documents]] end]
        } else {error {Create an associated Sketch first}}
    }
    sketchClose
    set view [::GX::viewerSceneGet $module $provider]
    set plane {}
    foreach {target source} {origin working_plane_origin normal working_plane_normal u_axis working_plane_u_axis} {dict set plane $target [split [dict get $view $source] {;}]}
    set sketchWindow $::GX::Engine3D::window.sketch
    toplevel $sketchWindow
    wm title $sketchWindow {Workbench3D · exact Sketch on the working plane}
    wm geometry $sketchWindow 1200x760
    try {
        set sketchComponent [::GX::nativeCadSketchCreate $sketchWindow [dict create document_id $requested working_unit [dict get $model working_unit] plane $plane presentation viewer]]
        pack [$sketchComponent widget] -fill both -expand 1
        set palette [$sketchComponent palette $sketchWindow]
        pack $palette -side top -fill x -before [$sketchComponent widget]
        wm protocol $sketchWindow WM_DELETE_WINDOW ::GX::Workbench3D::sketchClose
        set id [$sketchComponent get document_id]
        if {$requested eq {new}} {
            set before $model
            dict set model sketch_documents $id [dict create document_id $id working_unit [$sketchComponent get working_unit] plane [$sketchComponent get plane]]
            commit $before {Create working-plane Sketch} [dict create sketch_document_id $id] {} [list $id]
        }
        return [dict create action $action status open workbench_document_id $document sketch_document_id $id component $sketchComponent widget [$sketchComponent widget] sketch [$sketchComponent state]]
    } on error {message options} {
        sketchClose
        return -options $options $message
    }
}
