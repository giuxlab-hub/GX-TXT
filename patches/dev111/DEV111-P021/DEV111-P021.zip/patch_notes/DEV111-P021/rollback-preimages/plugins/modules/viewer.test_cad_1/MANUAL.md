# TEST CAD 1

This TEST Viewer is an ordinary GPL-3.0-or-later Module authored in public Viewer
Interface Builder and Viewer Development with C++17. It demonstrates shared
exact two-dimensional CAD editing together with its three-dimensional context.
It is a development exercise; numerical or visual acceptance is recorded
separately from successful compilation.

Viewer menu, responsive icon toolbar and tabbed tool palette. The **TEST Viewer action** calls ordinary class-based C++ logic
and increments its visible counter. It can be used while the CAD tools remain
available. Open Help for this guide and the public API references.

Start in millimetres on the XY plane. Create points, lines, construction lines,
paths, polylines, splines, rectangles, circles, arcs, ellipses or quadratic/cubic
Bézier curves, and use **Finish** to commit a multistep tool. **Cancel** abandons
the current unfinished gesture. Select or rectangle-select existing entities;
translate, rotate and mirror them. **Fit** frames the current document and
**Pan** changes the view. The shared exact editor owns all coordinates and
constraints; Viewer C++ never stores a second geometry model.

The Modify tools join points/paths, form and separate compounds and split paths
or compositions. Constrain exposes dimensions, horizontal, vertical,
coincident, parallel, perpendicular, tangent, equal-length, equal-radius and
fixed constraints. Selection-dependent controls use the shared CAD action's
enabled/checked state. A disabled command needs an applicable selection. The
shared component's normal editor provides precise values and recovery messages.

**Undo** and **Redo** navigate the shared Interactive Document History. **Save**
stores the exact document through its existing owner. Workspace Save captures a
reference to that document together with the Viewer interface state; reopening
the Workspace restores the document. Original Sessions are never copied into
this package. The 3D context maps the declared plane; editing remains exact 2D.

The package retains the original Builder design, project metadata, C++ source,
admitted SDK, native binary and public build/export receipts. Changes must be
explicitly rebuilt in Viewer Development; installed opening uses its packaged
binary. No authored Tcl, private CAD engine or manual TkViewer is included.


Right-click inside the actual Sketch editing canvas to open the Viewer-owned context menu. Select, Line, Circle, Pan, Fit, Undo and Redo use the same shared CAD actions and enabled/checked state as the Viewer menus and palette. TEST Viewer action uses the same independent C++ Viewer handler. This context menu does not create another CAD controller or History owner.
