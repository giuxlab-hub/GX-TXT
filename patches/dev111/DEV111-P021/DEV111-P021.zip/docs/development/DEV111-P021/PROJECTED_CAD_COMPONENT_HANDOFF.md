# Projected CAD component checkpoint

SPDX-License-Identifier: GPL-3.0-or-later

Baseline: exact local P020 commit `6f6c1ce584321a522d440219dd22101541a0180d`.
Development: isolated `component/dev111-p021-cad-projection` worktree under
`/srv/gxtxt/agents/scratch/DEV111-P021-CAD-PROJECTION/framework`.
No Native2D/Native3D scientific kernel, binary, release, user Session or installed
framework was modified by this component.

Implemented: opt-in projection in existing CAD Host; actual-screen coordinate
adapters for basic/advanced interaction; transparent same-Canvas retained Cairo
geometry/grid/controls/segment/gizmo/direction presentation; projected native
constraint/dimension presentation; actual scientific references; existing native
transactions; independent component contract fixture. Public details and honest
boundaries are in `docs/api/NATIVE2D_CAD_CANVAS_HOST_PROJECTED_ADAPTER.md`.

Component evidence (isolated scratch, not packaged private data):

- `component08`: 15 scoped assertions PASS, including genuine xdotool pointer
  control edit and Escape cancellation, exact definitions, transparent retained
  presentation, native dimension label/line hit and consumer-scene survival.
  Screenshot `component08/component.png` visually inspected: grid, tilted affine
  geometry, highlights, defining controls and dimension visible over blue frame.
  This uses an affine mapper fixture: it is NOT Native3D camera GUI acceptance.
- `planar01`: existing focused P019 independent constraints consumer, 25 assertions
  PASS using genuine pointer/editor events. Includes native driving dimension,
  rejection/reference fallback, annotation preview/cancel, read-only edit gates,
  exact geometry and scene disposal. No background errors.
- Preserved diagnostic runs `component01/02` caught native aspect spelling;
  `component07` caught the obsolete item-count expectation after adding bounded
  axis labels. Corrected the driver to count the one retained geometry item plus
  bounded actual axis labels; no scientific assertion was weakened.

Integration required from MAIN1: source new adapter after Host/Advanced mixin;
add its command to public API discovery; provide current immutable public mapper,
route navigation through Native3D, pin camera while pointer transactions are
active, raise existing cube chrome, supply verified plane-unit descriptor and
qualify actual Native3D perspective/orthographic GUI through MAIN2. These remain
integration tasks, not component PASS claims. No user acceptance is claimed.

## Native camera component qualification

The later `native-persp03` uses a private copied actual Native3D rendered frame and
its matching inclined-plane perspective snapshot from the native adapter's
`test02` contract receipt (case 2). `native-ortho01` uses actual orthographic case 6.
The public compiled Tcl-only mapper is loaded; no camera equations are reproduced
by this consumer. Both cases passed actual X11 control dragging, native
translation/rotation with observed drag ownership and matrix-aware scientific
control queries, Escape rollback, native dimension presentation/hit, transparent
frame preservation and resource cleanup. Their screenshots were inspected.
`native-persp03` additionally passes actual button-selected line construction,
actual pointer placement, Escape/restart, cancellation without a new canonical
object, and bounded preview cache. These are component integration tests over
real native frames; live navigation/worker ownership remains MAIN2's qualification.

A component09 driver check originally compared unchanged local control arrays
without applying the authoritative retained transform. Its retained evidence is
preserved. The corrected assertion queries `interaction_controls` actual scientific
points; it verifies the expected pointer-derived translation and native drag release.
No scientific behavior was changed to make that test pass.

Follow-up hardening cancels pending scheduler work when adapter ownership changes,
retires a projection on source reassociation, checks scene generation, removes
only owned annotations on disposal, and clips behind-camera annotation proposals
without changing their scientific relationships. Selection presentation distinguishes
whole-object from segment/control membership. Preview object caches are pruned.

Final native module qualification uses a new private `native-fixtures-final`
copy, preserving the earlier fixtures. It pins SHA-256
`fcc4925bfa630b927cdcce84b539ef33c714c4d78ea4672dbd8bb01ff8208872`
for the final compiled public mapper (native adapter commit `5bafec358a909562d786f25789e8b0c8374dc40d`).
`native-final-persp` passes 26 interaction/scientific/lifecycle checks plus five
unchanged-source SHA-256 checks. Its result contains exact hashes of all four
loaded CAD scripts and the unchanged Native2D binary; input traces are retained.
The driver performs actual pointer rejection on an explicitly invalid plane and
verifies unchanged science plus recovery to a valid plane.
