# DEV111-P021 — Native CAD in the existing 3D viewport

SPDX-License-Identifier: GPL-3.0-or-later

Incremental overlay after exact deposited P020. Cumulative order: accepted P019
→ deposited P020 → P021. P020 acceptance remains withheld; P021 user VNC
acceptance remains open. This source has not been installed by the agent.

Shared CAD tools now edit directly on the existing Native3D Canvas. Exact
Native2D geometry and P017 History retain authority. A retained transparent
Cairo overlay displays the grid, geometry, controls, constraints and dimensions;
Native3D retains its scene, camera, solids and Navigation Cube.

## Installation and rollback

Close GX-TXT and preserve the current framework. Verify the delivered ZIP SHA256.
Extract it to a **separate staging directory**, then run the staged helper:

```sh
python3 -I -B P021-STAGING/validation/dev111_p021/apply.py FRAMEWORK DEV111-P021.zip
python3 -I -B P021-STAGING/validation/dev111_p021/apply.py FRAMEWORK DEV111-P021.zip --apply
```

The first command is read-only. The second refuses divergent P020 preimages
before its first write; it does not activate GX-TXT. Restart only after success.
Rollback similarly requires shutdown and the exact patched postimages:

```sh
python3 -I -B FRAMEWORK/patch_notes/DEV111-P021/rollback.py FRAMEWORK --check
python3 -I -B FRAMEWORK/patch_notes/DEV111-P021/rollback.py FRAMEWORK
```

Rollback restores P020 product bytes and modes; it preserves patch notes,
Sessions, preferences and diagnostic logs. It is a preflighted sequence of
per-file replacements, not a power-failure-atomic filesystem transaction.

## User VNC inspection

Open Test CAD 1/2 and Scientific 3D Workbench. Select a working plane, create a
Sketch and draw inside the existing viewport. Check Finish, Cancel/Escape,
selection/control editing, Undo/Redo, grid and units. Use **Space-drag** to orbit,
**Space+Shift-drag** to pan and the wheel to zoom. Alt-drag also exists but can be
intercepted by the desktop window manager. Test the native Navigation Cube.
Save, Close, reopen, and create another Sketch. Check the original examples and
STDERR Diagnostics Viewer. Rendering execution **Auto** retains hardware
acceleration when available and makes one bounded software retry if initial
read-only rendering fails. Software explicitly selects Mesa under GLVND; no
shell prefix is required in the patched framework. The user's current saved
Software setting remains Software until changed through Configuration.

Local GT610/NVIDIA390 hardware colors and Navigation Cube input now pass, as do
separate llvmpipe/CAD checks. The initial driver installation is separate OS work,
not part of this ZIP or its rollback. No OS-driver packages, private Sessions or
credentials are distributed. Other GPUs and Windows-hosted X11 remain outside
this focused hardware qualification; supported Linux/VNC user acceptance is open.
