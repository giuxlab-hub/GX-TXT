# P021 Sketch lifecycle qualification

SPDX-License-Identifier: GPL-3.0-or-later

Independent actual Linux/X11 GUI checks use owned synthetic Sessions and frozen
sources. Scientific assertions observe exact retained definitions and P017
receipts; callback-only tests are supplementary.

| Workflow | Result |
|---|---|
| Two-point Line, Finish, another Line | PASS; Finish leaves Select without an extra scientific step |
| Incomplete Line/Polyline Finish | PASS after correction; rejected proposal retained |
| Variable-length Polyline Finish | PASS; exact definition committed, tool exits |
| Toolbar action then immediate Escape | PASS; actions return focus to Canvas; editors retain their own focus |
| Native control movement and Undo/Redo | PASS |
| Tilted plane behind old camera | PASS; native Fit before pointer admission |
| Sketch Save, Close, associated reopen | PASS; same exact Document/geometry |
| Pending Sketch Close: Cancel / discard staged | PASS; live state retained or explicitly discarded |
| Pending containing-Viewer WM Close | PASS after public dirty-state correction; Workspace Cancel retains draft, No closes, reopen retains committed geometry only |
| History Branch mouse confirmation followed by unpressed motion | PASS after correction; lost release cancels native preview before geometry moves; next real held drag commits and Undo restores exact geometry |
| Close while native renderer work retires | Owned v2 worker retirement uses the existing bounded owner; representative normal closures have no orphan callback/background exception |

Initially, the common Host error path cancelled incomplete constructions. Finish
now preserves a rejected construction, with existing advanced rollback still
authoritative. An associated Workbench Sketch was missing from its owner's dirty
receipt; additive `sketch_pending`/`sketch_dirty` fields now reach the normal
Workspace close guard. A modal History admission could consume the initiating
button release; the surface now uses actual delivered Tk button state to cancel
that stale preview. No internal native transaction flag is cleared arbitrarily.

Save rejects a pending edit rather than silently cancelling it. A close decision
precedes lifetime invalidation. Original P017 accepted/durable semantics and
recovery journals remain authoritative. Large-History persistence redesign and
named saved Histories remain outside P021.
