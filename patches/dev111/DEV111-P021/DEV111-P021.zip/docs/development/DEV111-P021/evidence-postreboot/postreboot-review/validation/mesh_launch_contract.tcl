lassign $argv source output
if {[file exists $output]} {error {Fresh output required}}
file mkdir $output
namespace eval ::GX {variable scriptDir /pinned/framework;variable currentSession private_fixture}
namespace eval ::GX::DatasetViewer {variable state;array set state {}}
namespace eval ::GX::PreviewCache {variable worker 1}
source $source
set checks {};set commands {};set mode Auto;set intercepted {}
proc check {value label} {if {![uplevel 1 [list expr $value]]} {error "FAIL $label"};lappend ::checks $label;puts "PASS $label"}
proc ::GX::configurationGet {key} {if {$key eq {viewers.native3d.execution}} {return $::mode};if {$key eq {viewers.native3d.worker_address_space_budget_mib}} {return 8192};error "Unexpected config $key"}
proc ::GX::native3dGraphicsPolicy {} {return [dict create execution $::mode worker_address_space_budget_mib 8192 msaa Off]}
proc ::GX::sessionInspectionDatasetPayload {id} {return [dict create format stl path /private/fixture.stl sha256 fixture]}
rename open real_open
proc open {args} {if {[lindex [lindex $args 0] 0] eq {|}} {set ::intercepted [lindex $args 0];error {INTERCEPTED_NO_CHILD}};return [real_open {*}$args]}
set before [array get ::env];set environment [dict create]
foreach key {__GLX_VENDOR_LIBRARY_NAME LIBGL_ALWAYS_SOFTWARE LIBGL_ALWAYS_INDIRECT MESA_LOADER_DRIVER_OVERRIDE GALLIUM_DRIVER LD_LIBRARY_PATH LD_PRELOAD} {if {[info exists ::env($key)]} {dict set environment $key $::env($key)}}
foreach {name execution marker software} {explicitSoftware Software none 1 autoPreview Auto previewWidget 1 autoCompact Auto compactCanvas 1 normalAuto Auto none 0 normalHardware Hardware none 0} {
 array unset ::GX::DatasetViewer::state
 set mode $execution;set intercepted {};set ::GX::DatasetViewer::state(.fixture,temp) [file join $output $name];file mkdir $::GX::DatasetViewer::state(.fixture,temp)
 if {$marker ne {none}} {set ::GX::DatasetViewer::state(.fixture,$marker) .private}
 ::GX::meshDatasetWorkerStart .fixture
 check {$intercepted ne {} && $::GX::DatasetViewer::state(.fixture,status) eq {INTERCEPTED_NO_CHILD}} "$name reached exact child launch boundary"
 check {{LIBGL_ALWAYS_INDIRECT=0} in $intercepted} "$name direct GLX child flag"
 foreach token {__GLX_VENDOR_LIBRARY_NAME=mesa LIBGL_ALWAYS_SOFTWARE=1 MESA_LOADER_DRIVER_OVERRIDE=llvmpipe GALLIUM_DRIVER=llvmpipe} {check {($token in $intercepted)==$software} "$name $token expected=$software"}
 lappend commands [dict create case $name command $intercepted]
}
set mode Hardware;set intercepted {};set result [catch {::GX::meshDatasetPreviewArtifact private [file join $output managed]} message]
check {$result==1 && $message eq {INTERCEPTED_NO_CHILD}} {managedPreview reached exact child launch boundary}
foreach token {__GLX_VENDOR_LIBRARY_NAME=mesa LIBGL_ALWAYS_SOFTWARE=1 LIBGL_ALWAYS_INDIRECT=0 MESA_LOADER_DRIVER_OVERRIDE=llvmpipe GALLIUM_DRIVER=llvmpipe} {check {$token in $intercepted} "managedPreview $token"}
lappend commands [dict create case managedPreview command $intercepted]
check {[lsort $before] eq [lsort [array get ::env]]} {all launch paths preserve parent environment}
foreach {name value} [list CHECKS.tcllist $checks COMMANDS.tcllist $commands ENVIRONMENT.tcldict $environment] {set f [real_open [file join $output $name] w];puts $f $value;close $f}
puts "PASS [llength $checks] intercepted launch checks; NOT GUI/native rendering"
