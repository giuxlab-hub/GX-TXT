# P021 ordinary Viewer startup and color investigation

## Verified startup defect and correction

The catalog entry **C++ Native3D** is
`viewer.dev107_restricted_native3d/development_example`, not a Test CAD provider.
The exact P020 packaged SDK-v1 binary passes installed source, interface, ABI and
capability admission. Its historical compilation report predates
`workspace_callback_contract_sha256`. The GUI opening callback unconditionally
reads that key, raises a background exception, and leaves the actual Viewer at
its opening placeholder. This was reproduced under real mapped Linux Tk/X11.

The public Development installed-admission owner now derives the missing
presentation-compatible Workspace contract from the already verified packaged
source identity, authored interface and current admitted project capabilities.
It does this only for an absent legacy field, after the existing guards pass.
It does not change packaged receipts, compile at runtime, replace the existing
binary, override a present contract or relax Workspace restoration guards.
Runtime-only projection dictionaries are excluded by using the original
admitted authored design.

## Focused results

Evidence was recorded in the specialist's private
`/srv/gxtxt/agents/scratch/DEV111-P021-VIEWERS/` tree.

| Check | Result | Evidence |
|---|---|---|
| P020 ordinary C++ Native3D launch | FAIL reproduced | `runs/compiled-native3d02/errors.tcllist`, opening screenshot; exact missing-key traceback |
| Corrected ordinary C++ Native3D launch and compiled opening event | PASS | `runs/compiled-native3d04/runtime.tcldict`, `compiled-cube.png` |
| Native3D example normal provider launch | PASS | same run, `embedded-cube.png`, `embedded-viewport.tcldict` |
| Actual Canvas click / Right-key camera navigation / Alt-F4 close | PASS | `input.tcllist`, camera receipts; no background exceptions |
| Legacy contract derivation, no receipt mutation/runtime compilation | PASS | `runs/compiled-admission01/RESULT.json` |
| Existing contract preserved, source/interface/binary tampering rejected | PASS | same result; original rejection codes retained |
| Workspace mismatch restoration GUI | NOT VERIFIED in this focused batch | Existing Tcl guards unchanged; no claim of separate GUI restoration acceptance |

The first private test failed before product admission because the fixture's
resource directory was group-writable. That harness error was corrected and
its evidence retained under `compiled-native3d01`; it was not a product defect.

## Color and Navigation Cube boundaries

Both actual ordinary authored Viewers display a blue scientific RAM cube and a
separate multicolored upper-right Navigation Cube. Screenshots were visually
inspected. The native PNG and Tk photo readback are RGB pixel-identical:
0 differing pixels at 769×654 (compiled) and 769×645 (declarative example).
The measured renderer is OpenGL / Software / llvmpipe LLVM 19.1.7 with Mesa
25.0.7. This establishes local software-rendered correctness for these cases,
not a reproduction or correction of the user's reported grayscale display.

The Preview and old compiled example both use the same public v2 RAM demo
source: a blue triangle mesh, no `points` or `polylines` keys. No Viewer-side
palette, grayscale or gamma conversion was found. The P020 memory-line adapter
branch therefore cannot explain this particular reference cube case.

The v2 GUI Host does have an independently confirmed Navigation Cube input
routing defect: its stationary click is sent to ordinary scene picking rather
than native Navigation Cube pick/click, unlike the mature editable v1 Host.
An actual click on the visible cube leaves the camera unchanged and records a
normal pick miss. Correction belongs in the shared v2 adapter; this batch does
not modify Native3D engine, rendering, shader, camera, picking or cube code.
MAIN1 integrates and independently validates that adapter correction.

Read-only observation of the active user application found the installed
adapter, worker, both GUI Hosts and component/Preview sources byte-identical
to deposited P020. Its inherited graphics variables were DISPLAY=:0.0 and
LIBGL_ALWAYS_INDIRECT=1, without software override variables. No native worker
was running at observation time, so no active renderer backend or displayed
cube was inferred. No application events, configuration changes or Session
writes were made. Source introduction of the reported gray appearance remains
unknown and is not attributed to P020.

## Subsequent actual-desktop reproduction

After the initial local-Xvfb checks, the user supplied screenshots of genuinely
black main and Navigation Cubes on the actual desktop. A new explicitly
authorized private synthetic test reproduced that appearance on DISPLAY=:0.0.
The original user application and scientific Session were not operated by the
validation actor.

| Same public RAM demo / actual desktop | Native output | Observation |
|---|---|---|
| Auto, High; OpenGL Hardware NVD9 / Mesa 4.3 | Black | First frame before any pointer click; zero pixels with RGB channel spread>50 |
| Auto, Low; same hardware, parent INDIRECT unset | Black | MSAA Off, Standard transparency, shadows Off; still zero chromatic pixels |
| Software, High; llvmpipe / Mesa 4.5 | Correct blue solid and multicolored Navigation Cube | Visually inspected first frame and ordinary example |

Native PNG and Tk photo RGB match exactly in both failing and successful cases.
The failure is already present in native GPU output, so this reproduction excludes
Tk photo conversion, VNC composition and an earlier Navigation Cube pick as its
necessary cause. Disabling High-policy effects does not correct it. The specific
GPU/driver/render-operation cause remains unproven; no shader, renderer, camera
or protected engine implementation was modified. Existing explicit Software
execution is a verified diagnostic alternative, not a silently imposed policy.

Lightweight worker dispatch-to-completed-PNG/Tk-photo measurements, in milliseconds:
Auto first render297.566, resize69.006/79.095, ordinary pick97.131, orbit60.961;
Software first render515.421, resize71.210, pick71.823, orbit55.969. A second
ordinary example's first render was126.563 /133.454 respectively. These tiny
fixtures do not reproduce a multi-second per-frame stall and cannot establish
full CAD interaction performance. Initial admission/worker startup is excluded;
image dimensions vary during initial resize, so no precise relative speedup is
claimed. The first failed timing harness recorded no values and was retained.

Private evidence: `runs/desktop-auto01`, `desktop-auto-low01`,
`desktop-software01`, `desktop-auto-timed02`, `desktop-software-timed01` and
`DESKTOP_COLOR_PAIR01.json`. The first actual-desktop harness discovered that
`storage.cache_dir` defaults independently of XDG; it created only its own
PID-named native cache entries before that setting was redirected explicitly to
scratch. It did not alter existing user cache entries, configuration or Session
records. Subsequent actors set the actual cache preference to private scratch.
MAIN1 coordinates any separately authorized desktop restart and final reporting.

A single first-frame repeat after MAIN1's separately authorized local desktop
restart and fresh X11 login also fails: DISPLAY=:2, NVD9 Hardware/Mesa4.3,
769×654 native PNG, 53,409 nearly-black pixels and zero chromatic pixels. The
Tk photo matches exactly and no pointer/keyboard input was sent before capture.
Evidence is `runs/desktop-postrestart-auto01/COLOR_CHECK.json` and its synthetic
Viewer screenshot. All test-owned windows were closed afterward. This rules out
a merely stale Xserver process as a sufficient explanation; it does not prove
which GPU/driver/native render operation is responsible. No automatic Software
fallback or protected engine change is included in the specialist batch.

The final bounded Mesa transport control set `LIBGL_DRI3_DISABLE=1` while keeping
public execution policy Auto/High. The actual worker environment confirms that
variable, `MESA_DEBUG=context`, DISPLAY=:2 and INDIRECT=0, with no software/Gallium
override. Colors become correct, but the actual renderer changes to **Software
llvmpipe/Mesa4.5**. Consequently this is another verified software-selection
alternative, not proof that accelerated NVD9 rendering was repaired or that a
pure DRI2 hardware transport fixed the problem. Native PNG/photo are identical;
52,364 pixels have RGB channel spread>50 at769×594, and worker stderr is empty.
Evidence: `runs/desktop-postrestart-dri2-auto01/COLOR_CHECK.json`. The test-owned
window was closed. No system configuration, renderer policy default or protected
native implementation was changed, and no further driver matrix was run.
