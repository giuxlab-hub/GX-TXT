# Native3D post-driver startup correction

SPDX-License-Identifier: GPL-3.0-or-later

The user confirmed the launch workaround after the proprietary driver activation.
The new failure was distinct from the former Nouveau black-pixel result.

**Verified cause:** the saved Software policy supplied Mesa driver hints, but
GLVND could select NVIDIA's GLX library first. On the reported remote display the
worker greeted successfully, then VTK reported no usable OpenGL3.2 implementation
and exited with SIGSEGV. A native control with the same scientific cube and an
explicit Mesa vendor succeeded. Locally, a Software-labelled receipt could even
name the NVIDIA hardware device before the correction, because the existing
native status also considers the forced software environment flag.

**Correction:** existing shared v1/v2 Viewer, Dataset/compact Preview and managed
Preview launchers now select the Mesa GLX vendor for Software execution. The v1
adapter restores every parent graphics variable exactly; other adapters put
variables only in the child command. Auto's healthy hardware path is unchanged.
The native engine, shaders, projection, picking and Navigation Cube are unchanged.

The v2 host additionally retries one failed initial **read-only render** in Auto
using the same scientific scene and quality settings. It preserves pending
relative input, capability checks and the CAD projection subscription. It never
replays a completed frame, camera action or scientific edit; scientific validation
errors, explicit policies and source/Session guards remain authoritative. There
is no retry loop or silent quality reduction. The original hardware error remains
in `inspect.hardware_error`; `software_retry` and the visible status disclose the
fallback. Both worker logs remain available for the current binding. A malformed
protocol reply fails cleanly rather than raising an unexpected Tcl list error.

## Measured/observed verification

| Check | Result and scope |
|---|---|
| Local Auto/High/MSAA4x | PASS real mapped GUI, Hardware GT610/NVIDIA390.157, correct colors, actual Navigation Cube click and close; retry0 |
| Local Software/Custom/MSAAOff | PASS real mapped GUI, actual llvmpipe, colors/navigation and shared CAD Canvas, rejected Finish, Escape |
| Initial failure→Auto software retry | PASS actual worker/API integration on the reported display; exactly one retry, unchanged Auto/High4x, actual llvmpipe, colored800x542 native frame, exact decoded RGBA photo parity |
| Legacy Software initialization | PASS actual llvmpipe with parent NVIDIA-vendor sentinel and all graphics variables restored |
| Recovery contract |17 PASS, including scientific errors, explicit policies, stale source, already presented frames, ordered requests and malformed replies |
| Preview launch coverage |37 independent intercepted child-launch checks PASS; this is not a new scientific Preview GUI campaign |
| Cleanup |0 retained instances,0 retiring workers, empty legacy worker and no background errors in the native integration fixtures |

MAIN2 independently reviewed source equivalence and raw proof hashes. Its real
GUI tests use frozen4c71e293/f7b27890; final runtime4ad3cda8 changes only the scoped
launch/recovery paths plus malformed-response handling and request-reference
release. Earlier full CAD/lifecycle/performance evidence remains explicitly
attributed to its original runtime. No new hardware performance claim is made.

During testing the local user desktop became inactive when its automatic locker
switched to a separate LightDM greeter. Even plain Tk windows stayed iconic1x1;
intermediate MSAA/mapping/harness failures remain recorded. A window-manager
restart did not solve that condition. Standard activation of the existing user
session after resetting its screensaver restored normal mapping. Applications
and scientific Sessions were preserved; no permanent locking preference changed.

The single reported-display recovery is a bounded native/API test, not Windows
remote-X11 acceptance or a reliability campaign. Use supported Linux/VNC. Missing
Mesa, an unavailable display, unsupported quality or resource exhaustion can
still fail explicitly. This patch does not promise every GPU/driver combination
works, and it does not require globally forcing Software. The separately
installed server390 driver is for GT610/Fermi, not RTX3050. No driver, original
user screenshot, credential or private Session payload is distributed here.
