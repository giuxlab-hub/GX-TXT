# Cube color and example startup

SPDX-License-Identifier: GPL-3.0-or-later

Two distinct issues were established.

1. The ordinary legacy **C++ Native3D** example failed startup because its
   admitted historical build report lacked `workspace_callback_contract_sha256`.
   Admission now derives only that missing field from already verified source,
   interface and grants. Existing fields/tamper guards remain intact. Both
   ordinary compiled 3D examples open, render and close through the real GUI.
2. The v2 GUI Host routed a stationary cube click to ordinary scene picking.
   It now delegates native Navigation Cube probe/click and preserves queued
   coordinates. The existing native algorithms are unchanged; actual camera
   changes and staged CAD point preservation pass.

The reported local black cube was reproduced before any click in the exact P020
example. The native PNG was already black; its Tk photo matched every pixel.
Auto High and Low failed on Mesa NVD9/GF119 hardware. Software llvmpipe produced
correct blue main cube and colored Navigation Cube. Builder and examples share
this lower rendering path; no introducing revision is claimed.

The user-authorized desktop X restart and fresh XFCE/X11 login did not cure the
Nouveau hardware result. A DRI3-disable control rendered correctly only because
it selected llvmpipe; it did not repair accelerated NVD9. No engine/shader change
or automatic hardware blacklist/fallback is included in P021.

Separately, the user requested a compatible proprietary NVIDIA driver. MAIN1
verified GT610 PCI10de:104a/Fermi, currentkernel6.12.101+deb13-amd64 and XorgABI25;
Debian's patched390.157-16 built all four modules in isolation, then installed
with DKMS for that exact kernel (29new packages, zero upgrades/removals). The
kernel image and existing Mesa packages were not upgraded. No permanent Sid
repository was added. After the user's reboot, NVIDIA is bound to GT610 and the
actual local renderer reports Hardware/GeForceGT610/NVIDIA390.157. MAIN2's
Auto/High/MSAA4x orthographic real GUI test shows correct blue main cube and
multicolor Navigation Cube; a real face click changes the native camera and
normal close succeeds. Software llvmpipe was independently retested with colors,
navigation and the shared CAD Canvas. No fallback was used in the healthy
hardware case. These results do not qualify a different GPU or imply a precise
low-level Nouveau shader diagnosis.

The new post-reboot renderer-exit report reproduced on the remote display. The
native process logged unavailable OpenGL3.2 before exiting. The saved Software
configuration supplied Mesa-only driver hints, while GLVND could still dispatch
to NVIDIA. Explicit Mesa-vendor selection restored the exact native control;
the user confirmed the launch workaround. P021 fixes the child launchers rather
than requiring a global environment change. Auto component initialization now
makes one bounded software attempt on initial graphics failure, retaining the
original error and unchanged requested quality. Native algorithms remain intact.

A distinct inactive local desktop/LightDM greeter caused intermediate MSAA and
iconic1x1 test failures, including plain Tk. Those failures are not relabelled as
passes. Once the existing desktop was active, hardware Auto/High4x and software
GUI checks passed. See RUNTIME_STARTUP_REPORT.md and evidence-postreboot.

The OS driver work is not distributed in P021. Original user screenshots,
Sessions, credentials and driver package payloads are excluded. Final human
visual/performance acceptance remains open.
