# P021 Phase A: shared CAD on the existing Native3D surface

SPDX-License-Identifier: GPL-3.0-or-later

The exact deposited P020 commit6f6c1ce5/archive82071be2 is the technical baseline;
the user has withheld its acceptance. P019 acceptance is preserved. Development
uses a proper separate local Git worktree, with a frozen private MAIN2 baseline.
No engine, installed framework, original Session, historical release or TODO is
changed by this audit.

## Verified ownership and usable capabilities

- Native2D C owns exact definitions, relationships, scientific references,
  snapping and transactions. P019 shared Canvas/Advanced controllers already
  implement construction, controls, constraints, dimensions and topology.
- Native3D exposes authoritative world_to_screen/screen_to_world, plane frame,
  camera/orthographic height, native fit and Navigation Cube picking/click APIs.
  Unprojection depth is positive camera-forward distance, not normalized depth;
  physical pixel centers and scientific-figure margins matter. viewport_ray's
  existing margin behavior differs, so it is not substituted for unprojection.
- Native3D Host v1 owns the mature Workbench viewport and global worker; Host v2
  owns separately embedded ordinary Builder components. Both use the existing
  native adapter/renderer worker. The normal 3D Workbench is a v1 consumer.
- P017 owns History. The current Sketch's exact Document/flat patch model can
  remain; its dual display and world-scene mirror are presentation policy.
- The existing Native2D retained sprite custom item is alpha-cleared Cairo on a
  Tk Canvas. It can present projected primitives over the existing native frame
  without a second Canvas, renderer, scientific scene or thousands of Tk lines.

## Demonstrated gaps and baseline findings

The GUI Host does not expose projection state at the required bounded level.
A camera position/FOV copy would omit orthographic height and figure margins.
The additive native adapter therefore samples the existing unprojection API at
depths1/2, only when a CAD surface opts in. A small CORE mapping object consumes
this exact receipt and a normalized native plane; no camera formulas belong in
a Viewer. Frame/size/source generations guard pointer interpretation.

Host v1 currently deletes every Canvas item when presenting a frame; v2 appends
its frame above overlays. Opt-in presentation must preserve CAD items and put
the existing frame below them. Native chrome is preserved above CAD.

V2 stationary clicks invoke scene picking, never the existing Navigation Cube
pick/click route. MAIN2 reproduced the unchanged-camera failure. V1 already has
the correct native route and remains its authority. Cube grayscale is not yet
reproduced locally; introducing revision is unknown, and renderer changes are
not justified. The old C++ Native3D example startup separately fails because a
legacy admitted build report lacks a newer callback-contract field.

MAIN2's lightweight P020 50-object replay measured Canvas2.84ms, action refresh
351.56ms, world-scene417.42ms and notify782.34ms. These are inclusive diagnostic
samples, not a VNC latency estimate. They justify removing the mirror and batching
command predicates, rather than replacing Native3D rendering.

## Implementation boundary

One existing Native3D Canvas receives the shared CAD Host, projected retained
sprite layer, controls, annotations and native grid. A public surface adapter
borrows v1/v2 ownership, subscribes to presented-frame receipts and routes input.
It never owns/destroys the consumer's 3D scene. Pointer motion uses a local native
mapping object, not synchronous worker/Document calls. Native2D references remain
authoritative; projected sprite hits coordinate graphical candidate selection.

CAD is an explicit on-top editing overlay (not depth-tested solid geometry).
The existing renderer's Navigation Cube chrome stays above it; native Cube input
is delegated intact. Alt/Space gestures navigate the existing camera. Native
pointer transactions are cancelled safely if their pinned mapping changes;
already placed local construction points retain scientific coordinates.

Unrelated Native3D consumers do not opt in to sampling/overlay work. Native3D
engine sources, libraries, camera/projection/picking/render algorithms and public
C ABI remain protected. Any demonstrated need to change them requires user
authorization before mutation. Phase A findings lead directly to implementation,
not a substitute design/audit delivery.
