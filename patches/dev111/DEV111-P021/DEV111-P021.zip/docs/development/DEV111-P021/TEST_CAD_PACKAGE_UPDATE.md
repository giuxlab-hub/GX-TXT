# Test CAD package update and isolated native-worker entrypoint

Test CAD 1 and Test CAD 2 remain ordinary public Builder/Development C++17
consumers. Their version 1.0.1 updates use the public Development `save`, Builder
`metadata version`, `build`, `test` and `export` operations. The existing C++
source, component identities, capability grants, callback contract and distributed
native binaries are unchanged. The semantic `cad_sketch` component adopts the
CORE single-viewport implementation; neither package introduces a private GUI
or recreates shared CAD geometry.

The new Help explains the transparent working-plane presentation, camera input,
Finish/Cancel, scientific versus annotation state, Workspace association and
supported topology boundaries. Original genuine compilation receipts are retained
as `review/original-build.json`; current metadata admission is recorded separately.

| Module | Build | Declared compiled tests | Native binary SHA-256 |
|---|---|---|---|
| viewer.test_cad_1 | reused, no code generation | PASS | d332a33587674ba19261ff1344ba347c2a2c727f95be056cc8656251cbbdb90f |
| viewer.test_cad_2 | reused, no code generation | PASS | 9005be210454e29ab73ea238e5d924b21a46111ff154b75bf41b74d1d1f19acc |

Both exported SHA256SUMS manifests were checked against every listed file (40
and 19 entries). Source/project/Builder/export evidence remains in the specialist
scratch `authoring/test-cad-update02/`; no package was installed. Independent
real-GUI qualification of these metadata updates belongs to MAIN2's coherent
P021 candidate, not to these headless declared-event results.

## Isolated native-worker startup correction

Normal public Development `test` exposed a separate P020 entrypoint defect:
`python3 -I -B gxtxt_viewer_native_worker.py` omits its script directory from
Python module search, so its trusted optional diagnostics sibling import failed
with `No module named 'gxtxt_stderr_diagnostics'`. The persistent GUI runtime
already imports through the anchored Development backend and did not exhibit
this particular failure.

The native-worker executable now anchors only its own resolved CORE Python
directory, matching the existing Development backend convention. No diagnostics
routing, producer policy, ABI, collector or Viewer logic changes. Public declared
compiled tests pass after the correction. A separate exact `-I` worker check
executes the unchanged Test CAD 1 close event with optional capture OFF and ON:
both typed replies are successful, the ON collector records one real producer
attachment, and cleanup returns helper/IPC/writer to OFF. This event emits no
stderr payload, so the check establishes isolated import/protocol/lifecycle
compatibility, not a new diagnostic load or lossless-capture claim.

The failed first authoring attempt is preserved at `test-cad-update01/`; it was
not relabeled as successful. No private Session contents are distributed.
