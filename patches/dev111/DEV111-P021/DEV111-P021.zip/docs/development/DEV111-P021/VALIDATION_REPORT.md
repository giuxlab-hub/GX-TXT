# P021 focused validation

SPDX-License-Identifier: GPL-3.0-or-later

MAIN2 was configured as requested: Sol6.1, low reasoning, with its own subordinate
validation worker. All their writes and fixtures remained below the assigned
MAIN2 scratch tree. They used frozen coherent source copies, not MAIN1's changing
worktree. MAIN1 reviewed actual screenshots, source identities, scientific
receipts and failures rather than accepting exit status alone.

The final independent report records22 scoped cases. Final Software gates pass;
three historical failures are preserved with their resolving later cases:
pending owner Close, clipped projected unit title, and unpressed preview after
modal Branch admission. Earlier incomplete-Finish failures and actor focus/menu/
scroll assumptions also remain in their original outputs.

Actual GUI checks cover CAD1/2 ordinary C++ startup and domain action, same Canvas
identity, Line/Polyline construction, rejected Finish, Escape/Cancel, exact
control edits, Undo/Redo, Save/Close/reopen, tilted perspective/orthographic
Workbench editing, native Navigation Cube camera changes, retained staged
placements, native grid/tick/unit presentation, Space orbit/pan/wheel, driving
length dimension, Horizontal constraint, Bezier defining-control drag and Undo.

Transparency tests retain real scientific solid/mesh pixels under the overlay
across two backgrounds. Native sprite alpha pixel tests also blend against a
real native red solid, not a nominal background. Units/titles remain readable
within Canvas bounds after tilted camera movement. Callback-only tests are
labelled separately from GUI tests.

History/geometry assertions inspect exact captures, receipts and public portable
rescope of a private synthetic50-object clone. Original seed journal/checkpoint
hashes remain unchanged. No original user scientific Session is used. No new
scientific model, canonical sampled Dataset or solver is introduced.

Diagnostics OFF ordinary Viewer startup/status/close passes with helper0, IPC0,
writer0. The isolated native worker's OFF/ON import/protocol check passes; this
is not a repeated diagnostic throughput campaign. Post-OS-GLX Software cube,
Navigation Cube click and close pass. Subsequent post-reboot independent local
Auto/High4x uses actual GT610/NVIDIA390 hardware with correct colors/navigation
and software_retry0. Independent Software/CustomOff checks use actual llvmpipe
and include the shared CAD Canvas, rejected Finish and Escape.

Component native golden projection, malformed/stale input, disposal, batching,
plain2D compatibility, and guarded release helpers supplement these GUI checks.
Final cumulative unpack/startup/rollback and hashes are reported separately by
the generated release verification, not inferred from these GUI checks.
See the independent JSON and pinned evidence index for commands, expected versus
observed behavior, source hashes and reproduction steps.

Post-reboot launch changes have17 focused recovery contract checks,37 independent
Preview/mesh child-launch checks, actual v1 software initialization with exact
parent environment restoration, and actual v2 failed hardware initialization
followed by one Mesa retry. The latter preserves Auto/High4x, produces a colored
800x542 native frame with exact decoded RGBA parity to the Tk photo and cleans
all workers/callbacks. It is native/API integration, not a mouse-GUI claim or
broad Windows-X11 acceptance. MAIN2 reviewed final source equivalence and proof
hashes; its own Software and Hardware GUI results retain original commit labels.
