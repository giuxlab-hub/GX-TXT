# P021 single-viewport architecture

SPDX-License-Identifier: GPL-3.0-or-later

The protected Native3D engine, headers, library, rendering, camera, picking and
Navigation Cube algorithms remain P020-identical. Native2D C remains exact
planar geometry/constraint authority. The P017 History and P012 scheduler owners
are unchanged. Changes are additive native Tcl adapters, shared GUI ownership,
projected presentation and the two ordinary public TEST consumers.

`native3DViewportSurface` borrows an existing v2 Canvas; `native3DGuiHostSurface`
borrows the established v1 Workbench Canvas. `nativeCadSketchCreate` accepts this
surface or creates one normal v2 viewport. There is no mandatory second planar
Canvas, Toplevel or continuous derived scientific scene. The consumer's 3D
scene survives Sketch disposal.

The existing native world/screen and plane-frame APIs supply bounded camera
samples. A GUI-side C++ mapper evaluates the immutable receipt locally, including
orthographic height, scientific margins and tilted planes. Golden comparisons
cover perspective/orthographic/random planes; maximum screen error7.11e-13px.
Pointer motion does not issue a native3D worker/Document RPC. Frame/source
changes invalidate input; native cancellation restores an active transaction.

The existing Cairo sprite item draws a transparent retained layer on that same
Canvas. Manual colors add a backward-compatible UI Field RGB/alpha descriptor;
existing alpha composition is reused. CAD depth is explicitly always-on-top.
Native Navigation Cube pixels and input remain above/reserved from CAD. Exact
Native2D references own hit/control/constraint semantics; samples are display
geometry, never canonical Dataset rows.

Normal source preparation uses lightweight `presentation_scene`. The P020
`world_scene` remains an explicit, bounded compatibility snapshot only; it is
not called on ordinary pointer, selection, camera or frame updates. Shared action
refresh scopes one authoritative predicate snapshot across menus/toolbars rather
than repeating their guard/selection/History scans. No new persistent cache,
registry, scientific model, renderer, scheduler or Undo engine is introduced.

See docs/api/NATIVE_CAD_SURFACE_P021.md and the native projection/Host contracts
for lifetimes, finite callbacks, scale bounds and rejected-plane diagnostics.
