from PIL import Image, ImageChops
import collections,hashlib,json,pathlib,sys
r=pathlib.Path(sys.argv[1]); bounds=(48,107,1142,803); results={}
for mode in ['preview','runtime']:
 p=r/f'{mode}-ortho.png';im=Image.open(p).convert('RGB').crop(bounds)
 results[mode]=dict(source=str(p),source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),viewport_rgb_sha256=hashlib.sha256(im.tobytes()).hexdigest(),common_colors=collections.Counter(im.getdata()).most_common(8))
 if mode=='preview':first=im
 else:results['difference']=dict(bounds=bounds,differing_pixels=sum(a!=b for a,b in zip(first.getdata(),im.getdata())),total_pixels=im.width*im.height)
pathlib.Path(sys.argv[2]).write_text(json.dumps(results,indent=2)+'\n')
