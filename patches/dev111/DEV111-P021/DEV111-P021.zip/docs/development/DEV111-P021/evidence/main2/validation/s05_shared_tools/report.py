import hashlib,json,pathlib,platform,sys,tkinter
R=pathlib.Path(__file__).resolve().parent; run=pathlib.Path(sys.argv[1]).resolve(); out=pathlib.Path(sys.argv[2]).resolve();commit=sys.argv[3];framework=pathlib.Path(sys.argv[4]).resolve()
if R not in run.parents or R not in out.parents:raise SystemExit('Owned subtree paths required')
T=tkinter.Tcl()
def seq(p):return T.splitlist(p.read_text()) if p.exists() else []
def d(s):
 a=T.splitlist(s);return dict(zip(a[::2],a[1::2]))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[d(x) for x in seq(run/'checks.tcllist')]
expected=['Horizontal native constraint makes exact Line horizontal','Driving dimension .7 changes authoritative exact Line length','Dimension Undo restores exact pre-dimension capture','Constraint Undo restores exact pre-constraint capture','Actual defining-control drag edits exact Bezier controls','Bezier defining-control Undo restores exact capture']
observed={x['name']:x['status'] for x in checks}; passed=all(observed.get(x)=='PASS' for x in expected) and (run/'RESULT.txt').exists()
pins={}
for p in (run/'framework/core').rglob('*'):
 if p.is_file() and (p.suffix=='.so' or p.name in ['native_cad_sketch_v1.tcl','native2d_cad_canvas_v1.tcl','native2d_cad_tools_v1.tcl','native2d_cad_tools_constraints_v1.tcl','native2d_cad_projection_v1.tcl','native2d_cad_presentation_v1.tcl','native3d_cad_surface_v1.tcl']):pins[str(p.relative_to(run))]=sha(p)
evidence={str(p.relative_to(run)):sha(p) for p in run.iterdir() if p.is_file() and (p.suffix in ['.png','.tcldict','.tcllist'] or p.name=='RESULT.txt')}
model_facts={}
for label in ['line-before-constraint','horizontal','driving-dimension','constraint-dimension-undone','bezier-before-control','bezier-edited','bezier-undo','failure']:
 p=run/(label+'-model.tcldict');state=run/(label+'-state.tcldict')
 if p.exists():
  x=d(p.read_text()); model_facts[label]={'sha256':sha(p),'objects':{k:d(v).get('definition') for k,v in x.items() if k.startswith('object/')},'history':d(state.read_text()).get('history') if state.exists() else None}
result={'id':'P021-S06-SHARED-TOOLS-GUI','api':['NATIVE2D_API_v1','NATIVE_3D_GUI_HOST_API_v2','CORE_P017 History','public viewer.test_cad_2/test_cad_2'], 'source_commit':commit,'actor':{'path':str(R/'shared_tools.tcl'),'sha256':sha(R/'shared_tools.tcl')},'runtime_pins':pins,'environment':{'platform':platform.platform(),'Tcl':T.call('info','patchlevel'),'display':'private Xvfb 1600x1000x24; xfwm4; software graphics only','HOME':str(R/'private/home'),'TMPDIR':str(R/'private/tmp'),'XDG/GXTXT':'all beneath fresh run output'},'command':f'''HOME="{R}/private/home" TMPDIR="{R}/private/tmp" timeout 300s xvfb-run -a -s '-screen 0 1600x1000x24' tclsh "{R}/shared_tools.tcl" "{framework}" "{run}" >"{R}/private/{run.name}.log" 2>&1''','expected':expected,'observed':observed,'status':'PASS' if passed else 'FAIL','model_facts':model_facts,'evidence':evidence,'repro':'Read own SCRIPT_CATALOG.md. Run the actor on the exact frozen s05 framework with fresh owned output and log. Semantic changes use actual X11 menu, pointer and numeric keyboard input; introspection only observes canonical geometry/History.','limitations':['Software X11 does not qualify actual GPU colors.','No private Workbench imports, direct scientific setters, fake GUI events, source changes or release acceptance.','A failure requires inspecting retained log/screenshots to distinguish product failure from actor lookup/input assumptions.']}
out.write_text(json.dumps(result,indent=2)+'\n');print(result['status'],len(checks),'checks',sha(out))
