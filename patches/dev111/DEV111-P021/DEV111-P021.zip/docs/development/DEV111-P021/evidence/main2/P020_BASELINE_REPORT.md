# P020 independent GUI baseline

Independent frozen P020 baseline only; no P021 candidate qualification; P020 user acceptance WITHHELD;P019 accepted;P021 acceptance open.

All 1/10/50-object actual TESTCAD1 workflows passed geometry/control/Undo/Save/Close/reopen checks. Normal scientific3D Workbench oriented-plane Line/Point/History/Save/reopen passed. Source-authored demo Preview/runtime viewport pixels match exactly. Navigation Cube top-face click failed to change camera. Compiled generated-provider/scientific-solid color parity remains NOT_VERIFIED.

|Phase|Canvas render ms (count)|Action refresh ms (count)|World scene ms (count)|Notify ms (count)|Queue ms (count)|
|---|---:|---:|---:|---:|---:|
|create-1-0-begin|2.38 (1)|214.75 (1)|8.32 (1)|224.65 (1)|0.07 (1)|
|create-1-0-finish|4.74 (2)|441.64 (2)|13.76 (2)|458.81 (2)|0.30 (2)|
|control-1-motion|2.44 (1)|220.49 (1)|13.18 (1)|235.59 (1)|0.23 (1)|
|create-10-9-begin|2.65 (1)|361.27 (1)|72.74 (1)|438.40 (1)|0.63 (1)|
|create-10-9-finish|5.61 (2)|726.28 (2)|155.43 (2)|891.14 (4)|1.62 (2)|
|control-10-motion|3.17 (1)|363.44 (1)|81.75 (1)|450.20 (1)|0.76 (1)|
|create-50-49-begin|2.68 (1)|346.17 (1)|357.58 (1)|717.43 (1)|2.95 (1)|
|create-50-49-finish|5.52 (2)|346.50 (1)|450.47 (1)|810.54 (14)|2.93 (1)|
|control-50-motion|2.84 (1)|351.56 (1)|417.42 (1)|782.34 (1)|3.05 (1)|

Times are inclusive and overlap. Rendering of the first Tk Canvas feedback is much cheaper than repeated action refresh plus sampled world-scene rebuilding. Full exact values, counts, API/source/environment/commands/expected/observed/status/evidence/repro are in [P020_BASELINE_REPORT.json](P020_BASELINE_REPORT.json).

Evidence stays under this MAIN2 root. Read [SCRIPT_CATALOG.md](SCRIPT_CATALOG.md) before reusing actors. P021 frozen candidate required before changed-path qualification.
