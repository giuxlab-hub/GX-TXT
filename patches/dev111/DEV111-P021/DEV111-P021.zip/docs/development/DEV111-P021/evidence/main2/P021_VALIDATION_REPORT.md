# P021 independent GUI qualification

Software X11 qualification; acceptance remains open.

|Case|Status|
|---|---|
|P021-MAIN2-S03-CAD1|PASS|
|P021-MAIN2-S03-CAD2|PASS|
|P021-MAIN2-S03-WORKBENCH|PASS|
|P021-MAIN2-S04-FINISH-FOCUS|PASS|
|P021-MAIN2-S04-INITIAL-BORROWED-FIT|PASS|
|P021-MAIN2-S04-PERFORMANCE|PASS|
|P021-MAIN2-S04-NAVCUBE-V2|PASS|
|P021-MAIN2-S04-OWNER-PENDING-CLOSE|FAIL (resolved)|
|P021-MAIN2-S04-TILTED-VIEWS-LEGACY-CUBE|PASS|
|P021-MAIN2-GPU-COLOR|NOT_VERIFIED|
|P021-MAIN2-S06-OWNER-PENDING-CLOSE|PASS|
|P021-MAIN2-S06-UPDATED-VIEWERS|PASS|
|P021-MAIN2-S06-SCIENTIFIC-ALPHA|PASS|
|P021-MAIN2-S06-DIAGNOSTICS-OFF|PASS|
|P021-MAIN2-S06-SHARED-TOOLS|PASS|
|P021-MAIN2-S07-GRID-NAVIGATION|PASS|
|P021-MAIN2-S07-AXIS-TITLE-VISIBILITY|FAIL (resolved)|
|P021-MAIN2-S08-GRID-TITLES-HINT|PASS|
|P021-MAIN2-S08-WARM50|PASS|
|P021-MAIN2-S08-BRANCH-RELEASED-POINTER|FAIL (resolved)|
|P021-MAIN2-S09-BRANCH-RECOVERY|PASS|
|P021-MAIN2-S09-POST-OS-GLX-SOFTWARE|PASS|

Final s08 warm-50 motion with grid enabled: projected render 11.64 ms, inclusive Host render 12.78 ms, action refresh 15.74 ms, Notify 16.37 ms; first Tk feedback 34.80 ms. Native3D queue and geometry calls: zero. The earlier s04 continuous-view 50-object reference is retained in JSON. View/lifecycle differences make these scoped observations, not a controlled speedup claim. The native binary is unchanged through s09; no new timing was accepted during the private driver build.

The owner-close, clipped-title, and released-pointer failures are resolved by later frozen cases; historical failures remain visible below. Scoped software GUI gates passed through s09. Hardware graphics remains outside MAIN2 qualification; release and user acceptance remain open. Full API, source, environment, commands, expected/observed results, evidence, reproduction steps, and limitations: [P021_VALIDATION_REPORT.json](P021_VALIDATION_REPORT.json).
