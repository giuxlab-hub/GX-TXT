from pathlib import Path
from PIL import Image
import tkinter,json,hashlib,sys
R=Path(sys.argv[1]);T=tkinter.Tcl();cases=[]
def d(s):
 a=T.splitlist(s);return dict(zip(a[::2],a[1::2]))
for name in ['slate','warm']:
 native=Image.open(R/f'{name}-native.png').convert('RGBA');actual=Image.open(R/f'{name}-canvas.png').convert('RGB')
 info=d((R/f'{name}-canvas.tcldict').read_text());hex=info['background'].lstrip('#');bg=tuple(int(hex[n:n+2],16) for n in [0,2,4])
 expected=Image.alpha_composite(Image.new('RGBA',native.size,bg+(255,)),native).convert('RGB')
 a=list(actual.getdata());n=list(native.getdata());e=list(expected.getdata());mesh=bgcount=mesh_same=bg_same=0;overlay=[];w,h=native.size
 for i,(source,want,seen) in enumerate(zip(n,e,a)):
  x=i%w;y=i//w
  if x<240 and y<250:continue
  if source[3]==255 and min(source[:3])>100 and max(source[:3])-min(source[:3])<40:
   mesh+=1;mesh_same+=seen==want
   if seen!=want and len(overlay)<8:overlay.append(dict(x=x,y=y,native=source,canvas=seen))
  if source[3]==0:bgcount+=1;bg_same+=seen==want
 result=dict(name=name,background_rgb=bg,size=[w,h],visible_mesh_pixels=mesh,unchanged_mesh_pixels=mesh_same,mesh_unchanged_fraction=mesh_same/mesh if mesh else 0,transparent_background_pixels=bgcount,unchanged_background_pixels=bg_same,background_unchanged_fraction=bg_same/bgcount if bgcount else 0,overlay_difference_samples=overlay,expected_composite_rgb_sha256=hashlib.sha256(expected.tobytes()).hexdigest(),native_sha256=hashlib.sha256((R/f'{name}-native.png').read_bytes()).hexdigest(),canvas_sha256=hashlib.sha256((R/f'{name}-canvas.png').read_bytes()).hexdigest())
 result['status']='PASS' if mesh>1000 and result['mesh_unchanged_fraction']>.99 and result['background_unchanged_fraction']>.99 else 'FAIL';cases.append(result)
Path(sys.argv[2]).write_text(json.dumps(dict(id='P021-MAIN2-S06-SOFTWARE-ALPHA',expected='Projected CAD sprite transparency preserves actual Native3D opaque mesh and composited transparent background; line/control pixels may differ.',cases=cases,limits='Software Xvfb only. Excludes native child panel capture rectangle. Actual CAD Line geometry/History and source pins retained in adjacent receipts; no hardware graphics claim.'),indent=2)+'\n')
print([(c['name'],c['status'],c['mesh_unchanged_fraction'],c['background_unchanged_fraction']) for c in cases])
