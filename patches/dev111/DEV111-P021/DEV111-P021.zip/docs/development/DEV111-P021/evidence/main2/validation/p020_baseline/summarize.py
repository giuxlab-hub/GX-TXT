import collections, hashlib, json, pathlib, platform, statistics, subprocess, sys, tkinter
run=pathlib.Path(sys.argv[1]); T=tkinter.Tcl()
def seq(p):return T.splitlist(p.read_text()) if p.exists() else []
def dct(s):
 l=T.splitlist(s);return dict(zip(l[::2],l[1::2]))
counts=collections.defaultdict(list)
for row in seq(run/'calls.tcllist'):
 p,k,ms=T.splitlist(row)
 if k.startswith('::oo::'):
  method=k.split(' ',1)[1]
  if method not in ['event','render','refresh','notify','updateViewer','world_scene','buildWorldScene','begin','committed','down','move','finish']:continue
  k='object.'+method
 counts[(p,k)].append(float(ms))
metrics=[]
for (p,k),v in counts.items():metrics.append(dict(phase=p,call=k,count=len(v),inclusive_total_ms=round(sum(v),3),maximum_ms=round(max(v),3),median_ms=round(statistics.median(v),3)))
feedback=[]
for row in seq(run/'measurements.tcllist'):
 d=dct(row);d.pop('state');feedback.append(d)
pins={}
for p in sorted((run/'framework').rglob('*')):
 if p.is_file() and (p.suffix=='.so' or p.name in ['native_cad_sketch_v1.tcl','native2d_cad_canvas_v1.tcl','native2d_cad_presentation_v1.tcl','viewer_gui_host_api_v1.tcl','native3d_gui_host_v2.tcl']):pins[str(p.relative_to(run))]=hashlib.sha256(p.read_bytes()).hexdigest()
result=dict(test_id='P021-MAIN2-P020-CAD-BASELINE',api='NATIVE2D_API_v1 / NATIVE_3D_GUI_HOST_API_v2 / ordinary TESTCAD1',source_commit='6f6c1ce584321a522d440219dd22101541a0180d',environment=dict(platform=platform.platform(),python=sys.version,tcl=T.call('info','patchlevel'),x11='private Xvfb 1600x1000x24; xfwm4; software renderer'),feedback=feedback,metrics=metrics,pins=pins,checks=[dct(x) for x in seq(run/'checks.tcllist')],limitations=['Inclusive nested timings overlap; traced object commands add overhead.','Input to first Tk Canvas render completion includes xdotool default click delay; this is not physical input-to-display latency.','Broad diagnostic run only: create-10-1-finish and create-50-10-finish include manual branch-History confirmation waits; exclude those latency samples. Narrow replay uses native OK watcher.'])
pathlib.Path(sys.argv[2]).write_text(json.dumps(result,indent=2)+'\n')
