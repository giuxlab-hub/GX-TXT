# P019 focused mapped Native2D/Curve Workbench verification; private data only.
lassign $argv framework output
if {[file exists $output]} {error {Fresh output required}}
set framework [file normalize $framework];file mkdir $output;set output [file normalize $output];file attributes $output -permissions 0700
foreach {key dir} {XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p019_stress__
set catalog [file join $output framework];file mkdir [file join $catalog plugins modules]
foreach name {core app docs services gxtxt_pipeline.tcl} {file copy [file join $framework $name] [file join $catalog $name]}
foreach name {math.numeric plot.dataset viewer.curve_workbench viewer.test_cad_1 viewer.test_cad_2 viewer.scientific_3d_workbench viewer.3d_workbench} {file copy [file join $framework plugins modules $name] [file join $catalog plugins modules $name]}
source [file join $catalog gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {path text} {set f [open $path w];puts -nonewline $f $text;close $f}
proc pause {{ms 120}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {test label} {
 if {![uplevel 1 [list expr $test]]} {error "FAIL: $label"}
 lappend ::checks [dict create name $label status PASS];write [file join $::output checks.tcllist] $::checks
 puts "PASS: $label";flush stdout
}
set checks {};set inputTrace {};set errors {};set evaluations {};set publications 0;set nativeEvents {};set modalEvents {};set inTrace 0
proc bgerror {message} {lappend ::errors $message;puts stderr "BACKGROUND: $message"}
proc traceEvaluate {command op} {lappend ::evaluations [lindex $command 2]}
proc tracePublish {command op} {incr ::publications}
proc traceInput {cmd op} {
 if {[lindex $cmd 1] eq {xdotool}} {lappend ::inputTrace [list [clock milliseconds] {*}[lrange $cmd 1 end]];write [file join $::output input.tcllist] $::inputTrace}
}
trace add execution exec enter traceInput
proc stockChoice {widget value} {
 click $widget;set i [lsearch -exact [$widget cget -values] $value]
 if {$i<0} {error "Missing actual choice $value in $widget"}
 exec xdotool key Home
 for {set n 0} {$n<$i} {incr n} {exec xdotool key Down}
 exec xdotool key Return;pause 100
 check {[$widget get] eq $value} "actual keyboard choice $value"
}
proc branchWatch {} {
 if {[winfo exists .]} {
  foreach top [guiWidgets .] {
   if {![winfo exists $top]} continue
   if {[winfo toplevel $top] ne $top || [wm title $top] ne {Branch Workspace History}} continue
   foreach button [guiWidgets $top] {
    if {[winfo class $button] in {Button TButton} && [winfo viewable $button] && [$button cget -text] eq {OK}} {
     lappend ::modalEvents [list branch_confirmation [clock milliseconds]]
     exec xdotool mousemove [expr {[winfo rootx $button]+[winfo width $button]/2}] [expr {[winfo rooty $button]+[winfo height $button]/2}] click 1
     break
    }
   }
  }
  set ::branchWatcher [after 70 branchWatch]
 }
}
proc guiWidgets {w} {set all [list $w];foreach c [winfo children $w] {lappend all {*}[guiWidgets $c]};return $all}
proc see {widget} {::GX::native2DViewportSeeWidget $::canvas $widget;pause 60}
proc click {widget} {
    see $widget
    check {[winfo ismapped $widget]} "mapped control $widget"
    exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1
    pause
}
proc combo {widget pattern} {
    click $widget
    set popup [::GX::_uiFieldSelectorPanel $widget [winfo toplevel $widget]];set list $popup.options
    check {[winfo ismapped $popup]} {public Viewer-bounded selector opens}
    set wanted -1;set i 0;foreach label [$list get 0 end] {if {[string match $pattern $label]} {set wanted $i;break};incr i}
    check {$wanted>=0} "choice exists: $pattern"
    $list see $wanted;pause 50
    lassign [$list bbox $wanted] x y width height
    exec xdotool mousemove [expr {[winfo rootx $list]+$x+20}] [expr {[winfo rooty $list]+$y+$height/2}] click 1
    pause
}
proc typeInto {widget text} {click $widget;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $text;pause 80}
proc shot {name} {::GX::native2DViewportTooltipHide;pause 80;exec timeout 8s import -silent -window root [file join $::output $name.png]}
proc menuIndex {menu pattern} {for {set i 0} {$i<=[$menu index end]} {incr i} {if {[$menu type $i] ne {separator} && [string match $pattern [$menu entrycget $i -label]]} {return $i}};error "Missing menu $pattern"}
proc menuChoose {button pattern} {
    click $button;set m [$button cget -menu];set i [menuIndex $m $pattern]
    set height [expr {[font metrics [$m cget -font] -linespace]+6}]
    if {$i<[$m index end]} {set height [expr {[$m yposition [expr {$i+1}]]-[$m yposition $i]}]}
    exec xdotool mousemove [expr {[winfo rootx $m]+40}] [expr {[winfo rooty $m]+[$m yposition $i]+$height/2}] click 1
    pause
}
proc selectCurve {id} {
    set tree $::w.leftScroll.viewport.content.curves
    $tree see $id;pause 50;lassign [$tree bbox $id name] x y width height
    exec xdotool mousemove [expr {[winfo rootx $tree]+$x+25}] [expr {[winfo rooty $tree]+$y+$height/2}] click 1
    pause
}


proc points {} {::GX::Native2D::core points $::scene [dict get $::GX::CurveWorkbench::st($::w,curves) $::a native]}
proc movePointer {xy} {lassign $xy x y;exec xdotool mousemove [expr {[winfo rootx $::canvas]+int(round($x))}] [expr {[winfo rooty $::canvas]+int(round($y))}]}
proc gizmoDrag {mode {finish release}} {
    menuChoose $::w.sketchbar.modify [string totitle $mode]
    set items [::GX::Native2D::core render_gizmo $::scene]
    set start {};set end {}
    foreach item $items {
        if {$mode eq {translate} && [dict get $item handle] eq {x} && [dict get $item kind] eq {line}} {
            lassign [dict get $item a] ax ay;lassign [dict get $item b] bx by
            set start [list [expr {($ax+$bx)/2.0}] [expr {($ay+$by)/2.0}]]
            set end [list [expr {[lindex $start 0]+$::translationPixels}] [lindex $start 1]];break
        }
        if {$mode eq {rotate} && [dict get $item handle] eq {rotate}} {
            set start [dict get $item a]
            set pivot [dict get [::GX::Native2D::core pivot $::scene] point]
            lassign [::GX::Native2D::core device $::scene $pivot] cx cy
            set radius [expr {[lindex $start 0]-$cx}]
            set end [list $cx [expr {$cy-$radius}]];break
        }
    }
    check {$start ne {} && $end ne {}} "existing $mode gizmo geometry available"
    set expectedHandle [expr {$mode eq {translate}?{x}:{rotate}}]
    check {[::GX::Native2D::core gizmo_hit $::scene $start 5] eq $expectedHandle} "actual $mode handle hit"
    set before [points]
    if {$finish eq {reject}} {set end [::GX::Native2D::core device $::scene [dict get [::GX::Native2D::core pivot $::scene] point]]}
    movePointer $start;exec xdotool mousedown 1;pause 70
    set activeBegin [::GX::Native2D::core drag_active $::scene]
    movePointer $end;pause 120
    set preview [points];set activePreview [::GX::Native2D::core drag_active $::scene]
    if {$finish eq {escape}} {exec xdotool key Escape;pause 80}
    exec xdotool mouseup 1;pause 150
    set after [points];set activeAfter [::GX::Native2D::core drag_active $::scene]
    set record [dict create mode $mode finish $finish before $before preview $preview after $after start $start end $end active_begin $activeBegin active_preview $activePreview active_after $activeAfter]
    lappend ::gestures $record
    write [file join $::output gestures.tcllist] $::gestures
    shot $mode-$finish-[llength $::gestures]
    puts "GESTURE: $record";flush stdout
    return $record
}

::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p019_perf {} 0]
::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
if {[::GX::configurationGet preview.cache_enabled] != 0} {error {Private preview cache guard failed}}
if {![string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {error {Cache root escaped output}}
package require Tk;wm geometry . 500x120+0+0;wm title . {P020 validation owned root}

set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 300
set windows {};set exitStatus 0
proc component {w id} {return [dict get $::GX::ViewerGui::instances $w widgets $id]}
proc inputClick {widget} {
 check {[winfo viewable $widget]} "native visible $widget"
 exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1;pause 250
}
proc sketchSnapshot {sketch label} {
 write [file join $::output $label-state.tcldict] [$sketch state]
 write [file join $::output $label-model.tcldict] [$sketch capture]
 write [file join $::output $label-world.tcldict] [$sketch world_scene]
 shot $label
}
proc canvasPoint {sketch point {phase click}} {
 set c [[$sketch get host] canvas];set xy [dict get [$sketch transform local_to_device [list $point]] points]
 # transform contract points is a list of pairs.
 lassign [lindex $xy 0] x y
 exec xdotool mousemove [expr {[winfo rootx $c]+int(round($x))}] [expr {[winfo rooty $c]+int(round($y))}]
 if {$phase eq {click}} {exec xdotool click 1} elseif {$phase eq {press}} {exec xdotool mousedown 1} elseif {$phase eq {release}} {exec xdotool mouseup 1}
 pause 180
}

proc awaitOpen {w} {
 set deadline [expr {[clock milliseconds]+45000}]
 while {![dict exists $::GX::ViewerGui::instances $w] && [clock milliseconds]<$deadline} {pause 100}
 check {[dict exists $::GX::ViewerGui::instances $w]} {ordinary provider mounted}
 pause 500
 set deadline [expr {[clock milliseconds]+10000}]
 while {[dict get $::GX::ViewerDevelopment::windows $w busy] ne {} && [clock milliseconds]<$deadline} {pause 100}
 write [file join $::output runtime-[file tail $w].tcldict] [dict get $::GX::ViewerDevelopment::windows $w]
 check {[dict get $::GX::ViewerDevelopment::windows $w status] eq {COMPLETED}} {actual native opening event completed}
 exec xdotool windowfocus --sync [winfo id $w];pause 150
}
proc nativeMenu {w label item} {
 set main [$w cget -menu];set target -1
 for {set i 0} {$i<=[$main index end]} {incr i} {if {[$main entrycget $i -label] eq $label} {set target $i;break}}
 check {$target>=0} "native menu $label exists"
 exec xdotool windowfocus --sync [winfo id $w];exec xdotool key Escape Escape F10;pause 120
 for {set i 0} {$i<$target} {incr i} {exec xdotool key Right;pause 35}
 pause 150
 set sub {};set mapped {}
 foreach q [guiWidgets .] {if {[winfo class $q] eq {Menu} && [winfo ismapped $q]} {lappend mapped $q;if {![catch {menuIndex $q $item} index]} {set sub $q}}}
 write [file join $::output native-menu-[string map {{ } _} $label].tcllist] $mapped
 check {$sub ne {}} "actual $label popup mapped"
 set i [menuIndex $sub $item];set h [expr {[font metrics [$sub cget -font] -linespace]+6}]
 if {$i<[$sub index end]} {set h [expr {[$sub yposition [expr {$i+1}]]-[$sub yposition $i]}]}
 exec xdotool mousemove [expr {[winfo rootx $sub]+40}] [expr {[winfo rooty $sub]+[$sub yposition $i]+$h/2}] click 1;pause 350
}
proc cadButton {sketch action} {
 set owner [$sketch widget]
 if {[dict exists $::GX::ViewerCommands::windows $owner toolbar buttons $action]} {return [dict get $::GX::ViewerCommands::windows $owner toolbar buttons $action]}
 error "No actual Canvas action $action"
}
proc action {w sketch action} {
 if {[dict exists $::GX::ViewerCommands::windows $w toolbar buttons cad_$action]} {set b [dict get $::GX::ViewerCommands::windows $w toolbar buttons cad_$action]} else {set b [cadButton $sketch $action]}
 inputClick $b
 set deadline [expr {[clock milliseconds]+10000}]
 while {[dict exists $::GX::ViewerDevelopment::windows $w] && [dict get $::GX::ViewerDevelopment::windows $w busy] ne {} && [clock milliseconds]<$deadline} {pause 80}
 pause 250
}
proc objectCount {sketch} {return [llength [lsearch -all -inline [dict keys [$sketch capture]] object/*]]}
proc contextFit {sketch} {
 set widget [$sketch widget].context
 foreach q [guiWidgets $widget] {if {[winfo class $q] in {Button TButton} && [winfo viewable $q] && ![catch {$q cget -text} text] && $text eq {Fit}} {inputClick $q;break}}
 pause 700
 write [file join $::output viewport-[file tail [$sketch widget]].tcldict] [::GX::native3DViewportInspect [$sketch get viewport]]
}
proc viewerPopup {w sketch label} {
 canvasPoint $sketch {0.6 0.0} move;exec xdotool click 3;pause 200
 set menu $w.context;check {[winfo ismapped $menu]} {actualViewerOwnedRightclickPopupMappedOnSketchCanvas}
 set rows {};for {set i 0} {$i<=[$menu index end]} {incr i} {
  if {[$menu type $i] eq {separator}} continue
  set row [dict create label [$menu entrycget $i -label] state [$menu entrycget $i -state] type [$menu type $i] image [$menu entrycget $i -image]]
  if {[$menu type $i] eq {checkbutton}} {set variable [$menu entrycget $i -variable];dict set row checked_value [set $variable]}
  lappend rows $row
 }
 write [file join $::output popup-[string map {{ } _} $label].tcllist] $rows;shot popup-[string map {{ } _} $label]
 return $menu
}
proc popupClick {menu pattern} {
 set i [menuIndex $menu $pattern];set h [expr {[font metrics [$menu cget -font] -linespace]+6}]
 if {$i<[$menu index end]} {set h [expr {[$menu yposition [expr {$i+1}]]-[$menu yposition $i]}]}
 exec xdotool mousemove [expr {[winfo rootx $menu]+45}] [expr {[winfo rooty $menu]+[$menu yposition $i]+$h/2}] click 1;pause 400
}
# Bounded execution traces. Inclusive elapsed times retain nested-call attribution.
set measurements {};set phase startup;set calls {};set pending {};set firstFeedback {};set inputStart 0
proc measured {cmd args} {
 set op [lindex $args end];set key [lindex $cmd 0]
 if {[string match ::oo::* $key]} {append key { } [lindex $cmd 1]}
 if {$op eq {enter}} {dict lappend ::pending $key [clock microseconds];return}
 if {![dict exists $::pending $key]} return
 set stack [dict get $::pending $key];set start [lindex $stack end];dict set ::pending $key [lrange $stack 0 end-1]
 if {$start eq {}} return
 set elapsed [expr {([clock microseconds]-$start)/1000.0}]
 lappend ::calls [list $::phase $key $elapsed]
 if {$::inputStart && $::firstFeedback eq {} && ([string match {* render} $key] || [string match {* updateViewer} $key])} {set ::firstFeedback [expr {([clock microseconds]-$::inputStart)/1000.0}]}
}
oo::class create ::Main2Timing {}
foreach method {event render refresh notify updateViewer world_scene buildWorldScene begin committed down move finish} {
 oo::define ::Main2Timing method $method {args} [format {
  set start [clock microseconds]
  try {next {*}$args} finally {
   set elapsed [expr {([clock microseconds]-$start)/1000.0}]
   lappend ::calls [list $::phase object.%s $elapsed]
   if {$::inputStart && $::firstFeedback eq {} && {%s} eq {render}} {set ::firstFeedback [expr {([clock microseconds]-$::inputStart)/1000.0}]}
  }
 } $method $method]
}
proc awaitProjection {sketch} {
 set deadline [expr {[clock milliseconds]+30000}]
 while {([$sketch get projection] eq {} || [[$sketch get surface] busy]) && [clock milliseconds]<$deadline} {pause 100}
 check {[$sketch get projection] ne {} && ![[$sketch get surface] busy]} {matched Native3D projection ready and Surface idle}
 pause 200
}
oo::class create ::Main2ProjectedTiming {
 method render {args} {
  set start [clock microseconds]
  try {next {*}$args} finally {
   lappend ::calls [list $::phase object.projected_render [expr {([clock microseconds]-$start)/1000.0}]]
   if {$::inputStart && $::firstFeedback eq {}} {set ::firstFeedback [expr {([clock microseconds]-$::inputStart)/1000.0}]}
  }
 }
}
proc instrument {sketch} {
 foreach obj [list $sketch [$sketch get host] [$sketch get advanced]] {oo::objdefine $obj mixin ::Main2Timing}
 oo::objdefine [$sketch get projection] mixin ::Main2ProjectedTiming
 foreach cmd {::GX::viewerGuiActionsRefresh ::GX::native2DCadPresentationRefresh ::GX::native3DGeometryCall ::GX::_native3DViewportQueue} {
  catch {trace remove execution $cmd {enter leave} measured};trace add execution $cmd {enter leave} measured
 }
}
proc measuredPoint {sketch point event label} {
 set ::phase $label;set ::firstFeedback {};set ::inputStart [clock microseconds]
 canvasPoint $sketch $point $event
 lappend ::measurements [dict create phase $label input_to_first_render_ms $::firstFeedback elapsed_with_actor_pause_ms [expr {([clock microseconds]-$::inputStart)/1000.0}] state [$sketch state]]
 set ::inputStart 0
 set ::phase idle
 write [file join $::output measurements.tcllist] $::measurements
 write [file join $::output calls.tcllist] $::calls
}
try {
 set ::branchWatcher [after 70 branchWatch]
 set w [::GX::viewerOpen viewer.test_cad_1 test_cad_1 [dict create workspace_id new workspace_name {P021 singleCanvas measured baseline}]];lappend windows $w;awaitOpen $w
 set sketch [dict get $::GX::ViewerGui::instances $w cad_sketches sketch];awaitProjection $sketch;instrument $sketch
 sketchSnapshot $sketch initial
 foreach target {1 10 50} {
  for {set n [objectCount $sketch]} {$n<$target} {incr n} {
   set ::phase create-$target-action;action $w $sketch line
   set x [expr {0.1+($n%10)*0.06}];set y [expr {0.1+int($n/10)*0.11}]
   measuredPoint $sketch [list $x $y] click create-$target-$n-begin
   measuredPoint $sketch [list [expr {$x+0.04}] [expr {$y+0.07}]] click create-$target-$n-finish
   exec xdotool key Escape;pause 100
   check {[objectCount $sketch]==$n+1} "actual Line object [expr {$n+1}] committed"
  }
  set ::phase checkpoint-$target
  sketchSnapshot $sketch objects-$target
  set pre [$sketch capture];action $w $sketch select
  measuredPoint $sketch {0.14 0.17} press control-$target-begin
  measuredPoint $sketch {0.145 0.175} move control-$target-motion
  measuredPoint $sketch {0.145 0.175} release control-$target-finish
  set changed [$sketch capture];write [file join $output control-$target.tcldict] [dict create before $pre after $changed]
  check {$pre ne $changed} "actual control movement at $target objects changes geometry"
  action $w $sketch undo;check {[$sketch capture] eq $pre} "control Undo restores exact $target geometry"
  nativeMenu $w Workspace Save
  set workspace [dict get $::GX::ViewerGui::instances $w workspace_id];set saved [$sketch capture]
  sketchSnapshot $sketch saved-$target
  exec xdotool windowfocus --sync [winfo id $w];exec xdotool key alt+F4;pause 700
  check {![winfo exists $w]} "normal Close at $target"
  set w [::GX::viewerOpen viewer.test_cad_1 test_cad_1 [dict create workspace_id $workspace]];lappend windows $w;awaitOpen $w
  set sketch [dict get $::GX::ViewerGui::instances $w cad_sketches sketch];awaitProjection $sketch;instrument $sketch
  check {[$sketch capture] eq $saved} "normal reopen restores exact $target model"
  sketchSnapshot $sketch reopened-$target
 }
 write [file join $output RESULT.txt] {P021 independent TESTCAD 1/10/50 actual input baseline completed; timing and pixels require assessment.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {shot failure};set exitStatus 1} finally {
 write [file join $output errors.tcllist] $errors
 write [file join $output calls.tcllist] $calls
 foreach w $windows {catch {destroy $w}}
 catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
exit $exitStatus
