# P020 / P021 CAD performance

SPDX-License-Identifier: GPL-3.0-or-later

Measurements use the same machine, Tcl/Tk8.6, private Xvfb1600x1000x24/xfwm4 and
OpenGL Software llvmpipe. Actors use actual ordinary authored Viewers and native
mouse/key input. Timing wrappers are lightweight and selected; values below are
observations, not an uninstrumented universal speed guarantee.

| Representative 50-object control motion | P020 | P021 S04 | P021 S08 warm/grid-on |
|---|---:|---:|---:|
| Shared action refresh |351.56ms|15.00ms|15.736ms|
| Mirrored world-scene preparation |417.42ms|not in update path|not in update path|
| Notify, inclusive of action refresh |782.34ms|15.47ms|16.365ms|
| Host render, inclusive of projected render |2.84ms (planar)|12.52ms|12.784ms|
| Projected retained render |not applicable|11.72ms|11.640ms|
| First Tk feedback observation |different two-pane path|32.81ms|34.803ms|
| Native3D geometry RPC / viewport queue calls during motion |mirror queue present|0 /0|0 /0|

S04 normal1/10/50 control motion projected rendering was1.43/3.16/11.72ms;
shared action refresh14.95/14.80/15.00ms. It completed122 GUI assertions. The final
warm50 check uses the same Native2D binary as S09, the grid visible, a public
portable-History rescope of an unpublished private clone, actual held drag and
exact Undo. No performance figure was accepted while OS driver builds ran.

The measured hot costs were repeated action predicates and complete per-change
world mirroring: constituent sampling, temporary scenes, geometry-worker calls
and native3D queueing. P021 removes that mirror from normal updates and scopes
action facts per refresh. It retains the existing native renderer, rasterizer,
scientific sampling quality and History.

Comparability limits: P020 has two surfaces, P021 one; pixel area/layout differ.
P020 reopened at each size, P021 used a fixed view continuously then reopened50.
The warm check is separately labelled. First feedback includes xdotool initiation
and Tk render completion, not photon/VNC latency; clicks include an actor delay.
Nested Host/projected and Notify/action timings must not be summed. GUI editing
improvement is supported; no guaranteed FPS or machine-independent factor is
claimed.

Small native3D cube frame-dispatch→PNG/Tk observations on the local desktop were
about61ms orbit for Nouveau GPU and56ms Software; initial frames298/515ms with
other resized examples126/133ms. They do not explain the P020 CAD782ms mirror
cost and are not a controlled hardware-speed comparison. OS proprietary-driver
activation and focused colors/navigation now pass on GT610/NVIDIA390; no new
controlled proprietary-driver performance comparison is claimed. Existing final
CAD timings remain the scoped Software observations above. Explicit large-History Save and
bootstrap modernization are outside this patch.
