# DEV111-P021 final handoff

SPDX-License-Identifier: GPL-3.0-or-later

Status: implementation, focused software/hardware GUI qualification and startup
recovery checks are complete. Final archive/application/rollback results and
source commit are supplied by the generated release verification. P020 remains
the cumulative technical baseline with user acceptance withheld. P021 is NOT
INSTALLED; human VNC acceptance remains OPEN.

- Exact P020 baseline6f6c1ce584321a522d440219dd22101541a0180d;
  archiveSHA82071be2df3524783c66ef5a3531be6895ac7203ca6da8491c0852dd0099b214,
  6119464bytes. Source and previous releases remain protected.
- MAIN1 implemented the shared borrowed Native3D surface, managed Sketch and
  owning Workbench integration, lifecycle/input corrections and source integration.
- Native specialist supplied opt-in native camera receipts, local mapper, native
  fit adapter, matching binaries and guarded release helpers. Protected engine
  algorithms/libraries remain unchanged.
- Projected Host specialist supplied transparent retained presentation, native
  reference selection/snapping/controls, alpha support and component qualification.
- Viewer specialist restored legacy admitted startup, public TESTCAD1/2v1.0.1
  exports, isolated Python worker imports and bounded actual-desktop diagnosis.
- MAIN2 Sol6.1low plus its child qualified actual independent public Viewers,
  lifecycle, constraints/dimensions/Bezier, backgrounds, native navigation,
  grid/units, exact History/geometry and focused performance.

The broad focused runtime evidence uses S09
`dc4ca880799027689ee30f9cbb2513708d48ec38`. After the user-managed OS reboot,
`4c71e293` explicitly selects Mesa for Software workers. `f7b27890` adds bounded
initial Auto-frame recovery and Preview launch coverage; `4ad3cda8` handles
malformed replies and releases the active request after success. Independent
review establishes scoped equivalence with the earlier GUI paths. Post-reboot
actual Software/CAD and Auto/High hardware GUI checks qualify those launch paths.
The three native binaries/build inputs remain unchanged by these Tcl corrections;
TEST Viewer C++/SDK/binary identities remain P020-identical.

The old dual-pane mirror is absent from normal updates. At50objects, final warm
projected render11.640ms, action refresh15.736ms, first observed Tk feedback34.803ms;
zero Native3D geometry RPC/viewport queue during control motion. P020's scoped
notify782.34ms included417.42ms mirrored-world preparation and351.56ms action
refresh. Comparability limits and remaining explicit costs are documented.

Local Nouveau hardware colors failed independently of Tk and an X restart.
After the separately authorized, compatible NVIDIA390 installation and user
reboot, actual local Hardware GT610 colors and Navigation Cube interaction pass.
The post-install reported renderer exit exposed a separate GLVND library-selection
problem: Mesa driver hints alone could still select NVIDIA. Software now selects
Mesa explicitly in shared Viewers and Preview workers. A genuine initial OpenGL
failure was also recovered through exactly one Auto software retry with unchanged
quality; hardware success remains hardware. Detailed evidence and limits are in
RUNTIME_STARTUP_REPORT.md and CUBE_COLOR_REPORT.md.

Final packaging verifies the exact P019→P020→P021 chain, fresh public-API startup,
preimage/postimage guards and P021→P020 rollback. The generated verification and
FILES manifest supply exact source commit, changed-file identities and results;
the external release checksum supplies ZIP size/SHA. No older release, installed
GX-TXT copy, user Session or authoritative TODO is changed. Stop after deposition
for the user's own VNC acceptance; no P022 or unrelated CORE work is authorized.
