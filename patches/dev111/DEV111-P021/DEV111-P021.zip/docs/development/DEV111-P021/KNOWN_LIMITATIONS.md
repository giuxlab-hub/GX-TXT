# P021 current limitations

SPDX-License-Identifier: GPL-3.0-or-later

- The former Nouveau/NVD9 hardware path produced black native output. The
  separately installed NVIDIA390 driver now passes focused GT610 hardware colors
  and navigation; this does not establish the exact low-level Nouveau defect or
  qualify other GPU/driver combinations. No engine/shader workaround is included.
- Auto recovery is limited to the first read-only frame and one software retry;
  it never silently reduces quality or replays edits/camera operations. Missing
  Mesa, unsupported requested quality, resource exhaustion or a broken display can
  still fail explicitly. Windows-hosted remote X11 is not generally qualified;
  use the supported Linux/VNC environment.
- The desktop automatically locked during post-reboot testing, making normal Tk
  windows iconic1x1 even without GX-TXT. Earlier MSAA/mapping/harness failures are
  retained. After resuming the active user session, the same Auto/High4x hardware
  test and genuine navigation pass. No permanent lock/preferences change was made.
- CAD overlays intentionally draw on top of solids. They are editing feedback,
  not depth-tested surfaces. Native Navigation Cube chrome stays above CAD.
- Horizon-crossing, behind-camera and edge-on mappings reject explicitly. Projected
  native snap candidate search remains bounded; extreme-perspective limits are
  documented in the public projected Host contract.
- Use Space-drag for camera navigation. Desktop window managers can intercept
  Alt-drag; P021 does not change global OS shortcuts.
- Explicit legacy `world_scene` sampling can still be expensive when a consumer
  asks for it. Normal Sketch updates do not use it.
- Performance figures describe scoped Software X11 tests with documented view
  and layout differences, not network latency or universal speed guarantees.
- No claim is made for a new exhaustive scientific/publication/history campaign;
  unchanged accepted services are protected and focused affected paths tested.
- Named saved Histories, new Workspace architecture, large-History persistence
  redesign, Scientific Libraries and P022 are outside this patch.

P020 user acceptance remains withheld. P021 is NOT INSTALLED; user VNC acceptance
remains OPEN. Consult generated release verification for cumulative application
and rollback results; internal tests do not constitute human acceptance.
