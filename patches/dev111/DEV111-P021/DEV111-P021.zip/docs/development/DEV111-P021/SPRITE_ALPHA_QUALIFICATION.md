# Retained sprite alpha qualification

SPDX-License-Identifier: GPL-3.0-or-later

## Narrow implementation

Only the existing manual color parser in
`core/native2d/gx2d_sprite_scene_v1.cpp` gains additive UI Field descriptors:
`{rgb TK_COLOR alpha NUMBER}`. Existing named/hex Tk colors, including names with
spaces, retain their meaning. Alpha must be finite within 0..1. RGB cache entries
remain opaque base colors; returned copies receive the requested alpha.

The existing `Color.a`, `cairo_set_source_rgba`, transparent retained ARGB raster
and Cairo OVER composition are reused without changes. No scientific C geometry,
constraint, coordinate, Native3D engine/ABI/renderer or History implementation
changes. The projected CAD adapter passes the existing public UI Field descriptor
instead of flattening it against a nominal background. Alpha-zero colors neither
paint nor contribute a hit; other enabled colors on the primitive still apply.

No CMake/header change is required: the existing gx2dtcl target already compiles
this source. The matching Linux x86-64 binary is supplied.

## Build identity

Existing CMake Release target, BUILD_TESTING=OFF, parallelism 2. On this machine,
system Cairo development headers are absent; the authorized read-only P013 Cairo
header prefix supplies the normal CMake override, with all header hashes recorded.
The existing system `libcairo.so.2` remains unchanged.

`/srv/gxtxt/agents/scratch/DEV111-P021-CAD-PROJECTION/build-alpha02/BUILD.json`
contains exact C/C++/include/CMake/public Numeric header hashes, compiler version,
commands, output logs and unchanged-source validation. Configure took 0.993 s;
compilation/link took 17.204 s. These are build times, not interaction benchmarks.

| Artifact | SHA-256 |
| --- | --- |
| P020 sprite source preimage | `bfc86c856e3de455ab7168bf9159642f94069421934e75286535f9734b07a610` |
| P021 sprite source | `0432efaf77ad9050828fce9ed8e884ed0d287ab7075a9ee78f77b18a3f3ec52e` |
| P020 gx2dtcl.so preimage | `77bc65dac820aecbdfacc1427aa25735f860c657170a1db343eab6366c1e66ab` |
| P021 gx2dtcl.so, 1,397,848 bytes | `ee1e919c276534c05112eecad313e87a818abdb417ed40fdc5765388045528c6` |

## Actual GUI pixels

`alpha-gui03` uses actual Linux X11/Tk and the unchanged Native3D renderer. A real
opaque red display mesh covers the left half of a native frame; its right half
uses the declared blue then white viewport background. Native PNG background
pixels are transparent, so the containing Canvas is configured to the same
background, matching the existing host composition model. The Cairo sprite is
one retained Canvas item over this real Native3D frame. Both screenshots were
visually inspected.

| Native displayed pixel | Overlay | Actual result | Expected |
| --- | --- | --- | --- |
| Red solid, both backgrounds | Green fill, alpha .5 | 127,128,0 | 127,128,0 |
| Red solid | Blue stroke, alpha .25 | 191,0,64 | 191,0,64 |
| Blue background | Green fill, alpha .5 | 0,128,127 | 0,128,127 |
| White background | Green fill, alpha .5 | 127,255,127 | 127,255,127 |
| White background | Blue stroke, alpha .25 | 191,191,255 | 191,191,255 |
| Any underlying pixels | Legacy `light blue` | 173,216,230 | 173,216,230 |

This proves composition over actual solid pixels, rather than against the
nominal blue/white background. Changing the underlying native image/background
without resubmitting sprites correctly recomposes the retained alpha raster.

18 recorded assertions plus the final successful disposal assertion cover actual
pixel composition, alpha-zero hit/paint exclusion, nonzero-alpha hits, six invalid
descriptor atomic rejections, legacy-color cache integrity, one retained native
item, no background exceptions and preservation of Canvas/frame after disposal.
Screenshots, all sampled RGB values and exact native/source hashes are in
`/srv/gxtxt/agents/scratch/DEV111-P021-CAD-PROJECTION/alpha-gui03/`.

`alpha-projected-smoke` repeats the already qualified actual X11 projected
construction/control/translation/rotation/cancellation/invalid-plane workflow
with the matching new binary and final native mapper. All 26 scoped checks and
five unchanged-source pins pass. This is a focused component rerun, not a claim
that the complete authored Viewer has passed MAIN2's live-camera validation.

Preserved failed fixture evidence: alpha-gui01 exposed transparent native PNG
backgrounds; alpha-gui02 omitted the required layer_order in the synthetic mesh.
Neither was a product failure or justification to alter the Native3D engine.
No user data, installed framework or historical release was changed.
