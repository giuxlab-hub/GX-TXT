# DEV111-P032: extensible Acquisition Builder and native clients

Exact accepted predecessor source `c998fe69626834550164534e22131e9cb8810448`, DEV111-P031 ZIP SHA256 `40886aa9b4ae88dab262e0a7ee8019b33023ed8ac3a36e4dfc14adfb0a3db827`.
Candidate source `fc672ead2755c316025711b9915fdcd6beef4909`. Full predecessor BASELINE plus FILES postimages
supply exact bytes and physical modes. User extras and previous notes remain.
This preparation is not acceptance; consult independent A/B source/artifact
receipts and final handoff. MAIN alone freezes, accepts and deposits.

P032 extends the existing Acquisition project/profile/typed helper toolchain,
managed source/buffer/publication owners and separately installable compiled
numeric Preview generation. Four ordinary companion Modules are bundled;
MODULE_VERSION_MATRIX.json is authoritative. Module framework_min=dev111 cannot
express patch compatibility: native P032 clients require matching P032 CORE and
explicit grants. Existing CSV/Acquisition and native Viewer ABI remain qualified
by their actual independent coverage, never by a version label alone.

Accepted P031 Curve, UML/Markdown containers and original Preview014 input remain
inherited unchanged; this delivery adds no supplemental input archive. Inherited
Curve Viewer qualification is OWNER_SUPPLIED_UNMODIFIED;
NOT_TESTED_BY_OWNER_REQUEST. Packaging performs no Module/Curve operation and
rebuilds no supplied/native binary. Preserve the original accepted archives.

Keep ZIP and sidecar, retain a full backup, stop GX-TXT and all workers. Helpers
have no process detector: --stopped is operator acknowledgement. Extract only
patch_notes/DEV111-P032/ into a separate review directory, then:

    python3 review/patch_notes/DEV111-P032/apply.py FRAMEWORK DEV111-P032.zip --check
    python3 review/patch_notes/DEV111-P032/apply.py FRAMEWORK DEV111-P032.zip --apply --stopped

Default check writes nothing. Verified rollback notes precede product writes.
POSIX directory locking and atomic per-file replacements do not form a whole-root
transaction. Interrupted recovery accepts only exact known before/after states;
unknown edits/modes/collisions refuse. Plain unzip cannot implement deletions.

    python3 FRAMEWORK/patch_notes/DEV111-P032/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P032/rollback.py FRAMEWORK --rollback --stopped

Rollback restores exact P031 bytes/modes, removes only declared P032 additions,
and retains notes/extras. Reverse later patches first; deliberate reapply needs
operator handling of retained notes. No Session/RAW/configuration/user data,
previous release, activation or installation cleanup is authorized.

The overlay already bundles the four ordinary Modules. companion_preflight.py
checks exact postimages; no forced reinstall is necessary. Separate normal ZIPs
are alternative delivery for a compatible host and legitimate Plugin Manager
state. Never fabricate Registry entries or remove bundled Modules for admission.
Canonical deposit and live activation are separate MAIN-only actions.
