# DEV111-P026 incremental overlay

Requires exact P025-r2 source `f8c0996f25cc75cbc18036688e9221b793749d46` and official r2 ZIP SHA256 `6c5de23f2a0440cf2333b3c501dc1939dce281e28ff4f87e6af99c7a94e81dbc`. Original P025-r1 and mixed installations are refused by the bundled full essential-runtime baseline closure, including the unchanged Plugin Install sentinel. Extra user files are allowed; existing files at added payload paths are never overwritten. Source commit: `12bafa70ed76456a05263cff34d486313bff240b`. Paths app/, core/, plugins/ and docs/ overlay the framework root directly; there is no framework/ wrapper.

Stop the target GX-TXT and all its workers before changing any file. Helpers do not detect or enforce stopped processes; --stopped explicitly acknowledges this instruction. Do not install over an unknown active root. Keep original Sessions/scientific data and prior patch notes intact.

Extract only patch_notes/DEV111-P026/ to a separate review directory. Keep DEV111-P026.zip and its .sha256 together, verify the published checksum, then run:

    python3 review/patch_notes/DEV111-P026/apply.py FRAMEWORK DEV111-P026.zip --check
    python3 review/patch_notes/DEV111-P026/apply.py FRAMEWORK DEV111-P026.zip --apply --stopped

Default is read-only. CRC, complete checksums, paths, regular files, modes, full baseline and added-path absence are checked before writes. A verified baseline with no deletion entries also supports the established `unzip -o DEV111-P026.zip -d FRAMEWORK` overlay. If DELETIONS.json is nonempty, use guarded apply; unzip alone cannot remove files.

Rollback is read-only unless explicitly requested:

    python3 FRAMEWORK/patch_notes/DEV111-P026/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P026/rollback.py FRAMEWORK --rollback --stopped

Interrupted overlay/rollback: use --recover-partial with --check, then with --rollback --stopped. Only exact known before/after hashes and modes are accepted; unknown files are refused. If interruption happened while publishing notes, restore complete verified notes from the exact ZIP first (no product overwrite), then inspect. Reverse later patches first. Rollback restores exact r2 bytes/modes and removes only P026-added product files. Notes/directories remain as evidence and extras are preserved. Move retained P026 notes to a separate evidence directory before a later reapply; helpers never overwrite that notes directory. Guarded writes serialize helpers with a crash-released POSIX directory lock; this does not stop GX-TXT or other writers. The engineering AUTHORITY_CATALOG.yaml is delivered outside this ZIP in operator_records; its f8 source preimage was not distributed by the prior patch chain and is not imposed as an installed guard. No Session/preferences/scientific cleanup or activation occurs. MAIN1 independent acceptance/deposit remains separate from preparation.
