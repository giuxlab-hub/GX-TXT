# GX-TXT DEV111 — Unfinished work

This file lists capability work still unaccepted in the dev111 source scope.
Source and release identities do not establish the owner's installed runtime.
The P026 read-only forensic audit could not identify the historically executed
root; both inspected server candidates differ from the verified P025-r2 source.
The owner's clarified incident used original P024 and an older Session, followed
by working P025. No P025 regression or installed revision is inferred from it.
Preserve the official P022/P023/corrected-P024/P025-r1/P025-r2 artifacts and all
original Sessions. P026 develops against exact P025-r2 source, independently of
any later owner decision to install or activate it.

The earlier final-dev111 activation work is a separate recorded epoch: official
dev110 deposition, dev111 revision2 deposition and its restore-point archive copy
were verified. Preserve revision1/revision2 archives and both stages. FINAL03
refused before exchange on protected process metadata; FINAL04 exposed a duplicate
UTC keyword in the deployment journal before exchange. The minimally corrected
owner and focused offline journal regression are accepted. Any still-unaccepted
revision3 packaging, deposition, matching stage, activation and normal installed
CLI/first+cold GUI must be reconciled against their actual delivery receipts before
that separate activation work resumes. See
[the exact correction](docs/development/task210/release111_r3/MAIN_ACTIVATION_JOURNAL_UTC_FIX_ACCEPTANCE.json).

Delivery, installation, activation, installed CLI/GUI and rollback status are
recorded separately in `/srv/gxtxt/releases/dev111/final_delivery/`. Only actual
results and MAIN_RELEASE_ACCEPTANCE.json there can establish final completion;
a source/version marker, this snapshot or a staging receipt cannot. MAIN1 alone
accepts releases. Restore-point archives do not imply installation or activation.

Use the current per-item fields in INTEGRATION_BACKLOG.json and newer named MAIN
receipts; allocation/pending statements below describe their recorded epochs.
Preserve official109/110, original Digitizer, all Sessions/profiles/identities and
rollback. Normal quiescence/no-launch coordination and real installed CLI/GUI
verification are mandatory under the existing activation owner. No redundant110
activation or replay of accepted campaigns is required. This list preserves all
remaining authorized capabilities and genuine limitations.

- **Framework Maintenance verification limit — MAIN1:** qualify the live User-scope
  Reset all commit in an owner-approved environment with private factory HOME
  paths. Current private GUI evidence covers its real preview/Cancel, positive
  Session reset-all, User section reset and whole-User JSON roundtrip; it does
  not establish the live User reset-all commit. Do not change HOME, bind paths,
  rewrite factories or touch owner data merely to obtain that missing result.
- **Remaining foundation GUI — MAIN1 / routed validators:** finish the unaccepted
  ordinary Session/dirty Save–Discard–Cancel and Generate initial-interaction
  details, and the remaining official Builder/Development Workspace workflows.
  The NEW numeric-template initializer now requests only the HOST value_set/
  text_set operations its source uses (b7e1b2f6); existing profile/PCB guards remain
  strict. One fresh public CLI init and Validate passed at06:35:35Z with no code
  generation/build. The original GUI project and CAPABILITY_DENIED refusal remain
  preserved, not retroactively repaired. Same-project GUI Validate/Build/Export/
  install/reopen and full parity/performance still need actual evidence.
  Print still lacks complete image/graph/PDF, copied-signature and comparable
  performance/installed proof; preserve its accepted14 scopes plus two token/
  Session-reconciliation checks. Accepted Modules/Configuration/generator-owner
  checks and real-Tk20 geometry checks are not to be repeated as fresh work.
  Optional finite original-Tcl maintenance GUI qualification remains partial;
  its accepted62 backend requests and geometry repair do not prove GUI authoring.
  It is not an unchanged-Digitizer/Workbench port requirement.
  [Print remainder](docs/development/task210/print/MAIN_SESSION_TOKEN_RECONCILIATION_ACCEPTANCE.json).
- **Preview provider and remaining Preview GUI — CORE1 / MAIN1:** wire and qualify
  the public installable provider/controlled factory, actual-byte worker/cache/
  lifecycle admission, official embedded Builder composition and Configuration
  management; diagnostic ABI/discovery/storage-guard source remains unwired/default
  OFF. Finish only the remaining real load/visibility/navigation/resize/cancel/
  Session-lifetime and comparative responsiveness obligations. Initial automatic
  Current, one Hide and Save/root-close from006 are scoped accepted; cold007's
  corrected original-deadline/relocated-copy route completed963 and is scoped
  accepted: initial saved Hidden, automatic new preparation, Show/Fit/Zoom and
  normal Save/root close. Its precise latency/full parity/science remain unverified. Preserve initial Hidden, allow only existing automatic preparation
  after legitimate copy inode/ctime invalidation, and require settled Current/new
  CORE context before Show. No Render/Hide rescue or same-path cache-reuse claim.
  Generic calibrated curve-to-raster binding remains unsupported without an adopted
  producer-neutral contract. [Provider boundary](docs/development/task210/preview_provider/D1_SOURCE_ACCEPTANCE.json),
  [metadata scope](docs/development/task210/preview_presentation_metadata/MAIN_ACTUAL02_SCOPED_ACCEPTANCE.json).
- **HTML/Guides — CORE1 / GUIDE:** finish actual original/candidate embedding and
  full control/workflow/keyboard/mouse/visual parity and measured responsiveness.
  Remaining CSS/JavaScript/assets/focus/copy/scroll/navigation/reload/zoom,
  Manual–Tutorial switching, stale-source and renderer-drain coverage must be
  judged from real native-host evidence. Genuine YouTube/external navigation/codec
  behavior remains unverified. Official1.2.3 export, native integration and corrected
  source links/clock admission are already source/admission work. Actual912/935
  opened four tutorial pages, all blank/FAIL; four GUIDE entries remain NOT TESTED.
  Initiating cause is unknown. The shared stale status also labels runtime/protocol
  failures; the bounded first-cause diagnostic correction is adopted in frozen11.
  Actual1060's one new diagnostic attempt stopped in the necessary User Guide
  constructor: blank content and public `RUNTIME_EXITED`, generation0 with empty
  document identity. T01 was never selected and remains NOT TESTED. The underlying
  stop/cancel origin and its relationship to912/935 remain unknown. A finite
  six-token/unknown transport-reason suffix is integrated. Actual226 again
  showed blank content and captured the managed category `output_limit`; native
  producer/cause remains unknown. The operator did not establish every required
  per-input proof, and an obsolete XID caused a no-input BadWindow during closure.
  Preserve these limitations; normal exit0 does not establish HTML success.
  ScriptJob owner9426 is source-adopted ca458930/e8ef6c51; one actual1242 real-pipe
  packet passed eight cases/53checks, one callback each, preserving reported
  source/full modes. Do not reopen that packet or claim it fixes HTML paint or
  identifies the native producer. Actual230 then reached public ready, generation1
  and the manual content identity, but the visible content remained blank gray: a
  paint FAIL, not HTML success. Five rejected-or-I/O observations leave the closed
  reason unknown. Normal close was blocked by the native active/focus guard; the
  original manual timeout ended the case, with no postfailure input or renewal.
  Remaining native HTML/control/media/parity/performance obligations stay open.
- **Unchanged Digitizer2.0.9 — VIEWER1 / MAIN1 / TUTORIAL1:** finish remaining
  genuine calibration/publication/Preview persistence/full workflow and measured
  GUI-quality obligations, reusing accepted shell and partial four-row/UUID/
  source/native observations. Direct unchanged vendor Quality still uses registered
  digest semantics; independent CORE current-byte proof is a preparation-time
  observation, not continuous verification or physical accuracy/uncertainty.
  Keep full vendor GUI/source/manual/archive AS IS; no patch, repack or port.
  [Host qualification](docs/development/task210/digitizer_asis/HOST_SOURCE_DIAGNOSTIC_ACCEPTANCE.json).
- **CHW/AIA — VIEWER2:** finish ordinary installed acquisition GUI and representative
  source-grounded scientific/visual comparison. AIA vendor-reference comparison is
  unavailable; synthetic format checks cannot establish vendor parity. Preserve
  actual units/metadata and unsupported records rather than repeat accepted package/
  precompiled/importer admission as unfinished work.
- **Scientific Library — remaining source-specific integration:** genuine public/
  commercial remote authentication and specialized external/remote IR/NMR source
  integration remain unavailable or unverified. P025 completed the bounded
  protected-profile encryption/CAS/privacy/lifetime/rate contract, real registered
  Python/Octave access, independent composition/readback and actual credential GUI,
  including the independently reproduced and corrected admin-drain control race.
  Its new independent neutral JSON provider passed actual external and verified
  TLS transport, explicit operation/cache policy, conditional revalidation,
  unavailable-source refusal and private public-Plugin-Manager admission. Managed
  IR/NMR normalized consultation passed exact independent Cambridge24/IR SQLite
  gold and large explicit ranges; original scientific functions are unchanged.
  Those verified tasks are removed from the queue. Neutral JSON transport does
  not establish a particular remote login protocol or external spectroscopy
  Viewer. General hostile-provider/zeroization, full-reader RSS scalability and
  universal synchronous DNS/header timing remain outside the verified contract;
  use existing managed asynchronous request lifetime ownership for remote work.
  Preserve all historical failed/UNKNOWN evidence; P025 does not rewrite it.
  [Step5 acceptance](docs/development/DEV111-P025/evidence/independent-step5-identity/STEP5_ACCEPTANCE_MATRIX.md),
  [independent source/domain report](docs/development/DEV111-P025/evidence/independent-sources/REPORT.json),
  [current contracts](docs/api/SCIENTIFIC_LIBRARY_P025_SOURCES_v1.md).
- **Curve Workbench — VIEWER1:** finish the remaining paired original versus latest
  authorized candidate GUI controls/workflows/latency/redraw/canvas/icon proof.
  Use current2.21.20 source/package lineage; old2.21.5/2.21.6 preparation is historical.
  Independent P026 real-Tk acceptance covers named draft Save/native binding,
  populated Workspace History Save, immediate and same-ID reopened Clear with
  backup Yes/No/Cancel, dirty Save/Discard/Cancel, retained scientific content,
  exact cold native state and the consolidated shared Workspace menu. These
  scoped functional checks are completed; they do not establish the remaining
  paired full-interface or comparative performance obligations.
  Preserve the almost-stable interface; no rewrite or compulsory port. Completed
  official source maintenance, upper-control/history corrections and export are
  not substitutes for actual functional/performance qualification. Actual990
  stopped because the operator did not open Workbench within discovery admission;
  candidate, pixel samples and comparative performance were not run. Correct the
  normal-input route before a separately authorized paired attempt, retaining
  both first failures and unchanged lifetime limits.
  Recipe04's exact highlighted Open command and actual intended field/caret
  requirements are independently reviewed; fresh complete fixture03 copies are
  prepared and their minimal binding update was adopted. Actual pair03 stopped
  before Search typing because exact field focus was not established; Workbench,
  candidate and timing remained untested. A post-click ordinary dispatch yield
  is an accepted operator clarification, without another run being implied.
- **Manual and three Digitizer tutorials — GUIDE / TUTORIAL1:** complete the English
  manual/three tutorial final-quality obligations, remaining T02/T03 workflows,
  actual native HTML host and full applicability-aware Plots/scientific/GUI/
  responsiveness evidence. Source-quality/link/count/persistence clarifications
  already accepted are not new work. Three admitted partial archives are drafts;
  finalize genuine separate manifests/versions/checksums/ZIPs only against evidence.
  T01 scoped007 supplementary source/content review and separate partial ZIP05
  are accepted; full T01/scientific quality and native HTML remain unaccepted.
  Preserve ZIP04 and unchanged T02/T03, without repeating completed scopes.
- **Four Session Generator tutorials — TUTORIAL1:** finish the independently
  packaged Audio, Thermal, Ticino and Manchester tutorials and their own complete
  applicability-aware actual Plots/provenance/GUI/performance evidence. Audio002
  has a scoped normal Decode PASS; its waveform terminal outcome after unknown
  SIGTERM, FFT and normal Save/close/reopen remain unproved. Tiny real Audio/CLOSE
  transport qualification does not close that user-file workflow. Thermal remaining
  native variant/label/GUI quality is separate from accepted alias metadata checks;
  Manchester's partial source/package is not actual workflow completion. Ticino225
  displayed four canonical tables with5440/443/573/560 rows; these GUI row counts
  do not validate topology. Normal metadata imports and unit Save/readback were
  observed. One hydraulic Render failed with Workerexit1/causeUNKNOWN; normal
  Save/close was observed, not cold reopen. No demo Run or nine-graph/full Plots,
  scientific or performance acceptance follows. Its public diagnostic closed
  STOP on multiple hydraulic failures/two durable IDs and absent public names;
  no JobInspect or Render occurred. Resolve through existing owners without
  guessing an automatic request's identity or silently retrying the workflow.
  R3 source439347 and independent partial Ticino ZIP02 admission90cd166e retain
  this exact evidence/limitations; other six partial archives are unchanged.
  Seven current partial tutorial archives across both families are admitted, with
  zero scientific-complete/final-quality tutorial claims. Preserve originals,
  failures and unknown causes; no completed campaign replay or fabricated plots.
  [Audio/Preview scope](docs/development/task210/tutorial1/MAIN_PARTIAL_AUDIO002_PREVIEW006_ADOPTION.json).
- **Replicate/Consensus — VIEWER1:** finish point-UUID readback, source/row/filter/
  calibration and six-association qualification, actual Analyse/Job/publication,
  full GUI/scientific/performance and installed evidence through existing science
  owners. Official1.2.1 package, pure decoder and normal public Open/three-operations/
  nine-step source preparation are scoped accepted. Association labels do not
  establish common frame, statistical independence or uncertainty; unavailable
  shared-factor covariance estimators remain explicit.
  [Accepted consumer boundary](docs/development/task210/replicate_three_ops/MAIN_ACTUAL03_SCOPED_ACCEPTANCE.json).
- **Unified document extraction — VIEWER2:** finish the complete PDF/OCR/document-
  table functional-union comparison, remaining missing capabilities and actual
  original/candidate GUI/parity/performance evidence through official owners.
  Existing0.1.1 source/package admission does not complete the union workflow.
- **IC Viewer — VIEWER2:** finish complete original/candidate control/workflow parity,
  Help/Inspect/alternate axes/scales, cancellation/lifetime and measured latency/
  redraw/canvas behavior. Existing0.1.2 official source/native admission, one actual
  AsLS baseline commit and scoped full10800-row binary64/row-identity readback do
  not establish full30-control GUI quality, chemistry/calibration/uncertainty or
  all model choices. Resolve remaining scientific claims from genuine source
  feasibility; do not repeat the accepted estimator/readback campaign.
  [GUI subset at its epoch](docs/development/task210/ic_baseline/MAIN_GUI780_SCOPED_ACCEPTANCE.json);
  [full-row consistency scope](docs/development/task210/ic_baseline/MAIN_FULLROW_ACTUAL02_SCOPED_ACCEPTANCE.json).
- **PCB Workbench/G3 — MAIN1 / CORE1 / VIEWER1:** finish remaining source/Session/
  grant/host/lifetime qualification and native consumer/selection/inspector/
  persistence required for a meaningful one-window
  schematic/3D/signal slice. Preserve the implemented canonical Document/Resource
  parent and serialized completion. Fixed EAGLE worker staging and native
  source-capture136 checks are scoped accepted, not unfinished parser/build work
  or full G3. General mirror/
  rotation/composition, artwork/copper/pour, physical3D/stackup/material/solver/
  manufacturing/EM/SI remain unsupported/unverified; no decorative/fake geometry.
  Official0.1.0 package admission and current discovered-root precompiled ABI
  are accepted. Preserve GUI224/227 operator STOPs. Actual228 reported in1211
  completed normal Create, genuine paired import, Save/Open, same completed
  source reconsultation and normal closure, accepted in MAIN6b5d215f. This closes
  that scoped GUI path only: the inspector checks ten descriptors but only three
  Tcl mirrors through EOF. Separate public readback1235 now passed ten streams/
  1797880bytes through checked EOF, same Document generation/rev2/SHA and source
  preserved; it is not unfinished stream work. Independent GUI1233 confirms the
  observed workflow with every-input identity/Tk-focus serialization-proof
  limitations, not a full guard guarantee. Cold restart, wider native consumer,
  full G3/science/performance/installed coverage remain unfinished.
  [Staged worker](docs/development/task210/pcb_paired_source/MAIN_WORKER_ACTUAL01_SCOPED_ACCEPTANCE.json),
  [native boundary](docs/development/task210/pcb_paired_source/MAIN_NATIVE_CAPTURE_ACTUAL01_SCOPED_ACCEPTANCE.json),
  [GUI import/reconsultation](docs/development/task210/pcb_paired_source/MAIN_GUI1191_SCOPED_OBSERVATION.json).
- **Stock icons — MAIN1:** finish unexercised category/search/state/theme/size and
  command/menu bindings, full original/candidate controls/workflows and measured
  responsiveness, then normal Build/Export/install/reopen of the SAME GUI-authored
  icon-bearing design and installed counts. Actual231 candidate04 observed100
  unique catalog IDs, Save search/preview and Cancel retaining zero icons, one
  20-row category and All, Play preview/Add of one icon, assignment/removal and
  Undo/Redo/Undo, followed by normal Save/Open retaining the embedded SVG/PNG.
  Four original controls/layout/nonicon properties and handlers/project metadata
  stayed unchanged. These scoped observations are retained; do not call them
  unfinished or replay them as a matched original baseline. Full labels/all five
  categories/state variants and measured paint/latency/parity remain unverified,
  with pixel N=0. Public100 assets/five20-entry families,100 canonical plus400 size
  PNGs and original30 source/mode evidence remain accepted separately.
  Preserve original pair02 manual FAIL, candidate03 QA STOP and their evidence.
  Candidate04's conditional normal Validate refused the default numeric project's
  copied document-only HOST request; Build/Export/install were not run. The shared
  NEW-template initializer correction and one separate public CLI init/Validate
  PASS do not rewrite that saved project or confer its missing GUI/build scope.
  Complete only genuinely unreached obligations; no port or grant broadening.
- **Scientific video — CORE1:** finish real interactive animation/control/GUI-player
  playback and responsiveness/installed evidence. Actual source-linked three-frame
  MP4/native/decoded image review, bounded cancellation/source-change/caption/
  existing-destination refusals and real-commit read-only reconciliation are scoped
  accepted. Retain synthetic-source/nonuniform scientific-time versus presentation-
  FPS, unmeasured exit91/arbitrary kernel-crash, wider-codec/multisource and
  all-descendant limits; do not recreate accepted export/fault campaigns. MP4 remains
  a rendered derivative, never canonical scientific data.
  [Positive](docs/development/task210/scientific_video/MAIN_POSITIVE_EXPORT_ACCEPTANCE.json),
  [negative/reconciliation boundary](docs/development/task210/scientific_video/MAIN_NEGATIVES_RECONCILIATION_ACCEPTANCE.json).
- **Circuit additions — MAIN1:** finish actual original/candidate GUI first-click,
  explicit pins/Properties/save/reopen/control preservation and comparable
  responsiveness. Four-kind educational NMOS/PMOS/static SPST/SPDT source/catalog/
  provider, official1.10.0 export and six bounded numerical Jobs are accepted
  scopes, not pending implementation. Preserve original203 controls/C++/old-model
  semantics and stated fixed-model/finite Ron–Roff limitations; no measured body-
  effect/commercial-device/dynamic-switch physics claim. Uncertain automatic/manual
  Fuse behavior remains explicitly unsupported/unverified, not renamed resistor
  physics. [Package boundary](docs/development/task210/circuit/MAIN_CANDIDATE_SOURCE_ADOPTION.json).

## Historical debts retained outside the completed dev109 mandate

The final dev109 release acceptance closes its15 required workstreams and accounts
for459 original records at documented evidence epochs; it does not mean459 executable
tests or universal platform/combination coverage. Its obsolete CAD/EM final-delivery
and dev109 release-sealing tasks are therefore removed, not reopened as TASK210 work.
The genuine historical limitations below remain. Deferred/optional/future-platform
items do not become new Debian release gates or an additional execution queue.

### dev109 residual verification limits

- Native source coloring is conservative lexical presentation; advanced f-string interiors, full fixed-form Fortran and dialect-specific constructs remain approximate. Background bounded rescans are implemented; an incremental parser cache is not.
- The complete 201-case combined acceptance matrix was not executed: every unexecuted named combination remains NOT TESTED in mandate-case-matrix.json. Successful narrower checks are not relabeled universal acceptance.
- Automatic breakpoint relocation across edited source remains unimplemented: edits deliberately invalidate old positions. Exact-revision persistence, tested gutter/context/key operations and bounded stale/dirty/close/encoding cases are verified. Other permission/encoding/runtime combinations remain unverified. GNU Octave asynchronous Pause is explicitly unsupported; its GUI button is disabled and the API refuses it. Real breakpoint stepping/Continue/Stop work. No fake Pause or stepping is used.
- The separate minimal HTML/document viewer intentionally omits images, CSS layout, scripts, forms and external assets. General XPath/XSLT/XML Schema are outside the implemented XML object/query contract.

- The dev109 restricted compiled-Viewer authoring route was C++ only. TASK210 finite original-Tcl maintenance does not enable restricted Python authoring. Python authoring remains disabled; no enforceable restricted-Python runtime or hostile-code/account-wide security guarantee is claimed. The tested kernel tool grant confines only its author process tree.
- Advanced scientific Native2D editing beyond the supported canonical diagram contracts (B5 follow-up), direct navigation-cube-face interaction and scientific mesh editing remain unfinished.

All inherited unfinished work below is preserved. No historical manual user acceptance is inferred from this engineering release.

### Earlier inherited unfinished work

#### Dev104 remaining verification limits

- The reported transient default-empty Viewer failure stopped reproducing; its
  original trigger remains unverified. The separately reproduced stale-Session
  presentation failure is repaired and tested.
- Nine legacy/structured/external Help paths retain NOT TESTED entries in the
  explicit consumer matrix; no broad shared-Help coverage claim is made.
- Physical printer completion and non-Debian/platform acceptance remain untested.

The delivered P0/A/B/C features are removed only against the dev104 acceptance
ledger and final installed/delivery receipts. The parked fourth workstream is
excluded. All unrelated unfinished obligations below remain retained.

#### Other unfinished activities retained

- **RLC tutorial and fifth scientific guide — DEFERRED — USER DECISION (2026-10-17).** The eleven original waveform inputs are unavailable. Scientific reproduction and the corresponding guide remain unfinished and untested; neither is PASS. This is explicitly non-blocking for accepted dev097. Revisit only with the required inputs and a later assignment.
- **Optional Bayesian MCMC:** no bundled sampler/posterior provider; feature remains NOT IMPLEMENTED — OPTIONAL. Do not claim credible-interval or sampler verification. A separately scoped implementation would require an explicit provider, public contracts and scientific validation.

#### Inherited unresolved work outside this integrated feature assignment

These unfinished historical obligations remain preserved. The continuous dev098–dev101 directive does not authorize unrelated repairs. Existing user acceptance decisions take precedence.

- Manual acceptance of dev090 Appearance settings, startup theme/fonts and configurable popup recovery.
- Remaining manual acceptance of dev089 canonical selectors, orientation indicator, notebook order, Acquisition ALWAYS policy and categorized import workflow; its native popup remedy was accepted in the dev090 task.
- Broader investigation of the historical documentation-navigator rectangular mask if it recurs; its trigger and equivalence to the demonstrated combobox repaint defect are unproven.
- Manual acceptance of dev088 integrated Native3D numerical geometry, modern Viewer working planes, calibrated Curve Workbench round trip, scientific provenance and portable DEMO.
- Manual acceptance of dev087 controlled cleanup and shared Plots/numerical XYZ interactive preview.
- Native3D nonlinear log/reversed-axis transfer contract, renderer-specific advanced annotations/layout, transparent scientific backgrounds and compact support on other compiled transports.
- Optional filtered/separate-family numerical XYZ preview and prepared-scene contracts for other graph providers.
- Manual acceptance of dev086 tab order, Modules selection/runtime/Plugin Manager and Plots menus.
- Manual acceptance of dev085 direct Project Home and whole-Project portable transfer.
- Manual acceptance of corrective dev084 Storage catalog/effective scope, independent private copies, readable errors, Projects selection/Info/transport and persistent identity/provenance. This includes the previously unaccepted dev082–083 workflows; engineering/operator checks do not constitute user acceptance.
- Manual acceptance of dev082 Storage Profiles, navigation and installation identity, reviewed through corrective dev084.
- Manual acceptance of dev083 Projects/Default/transport/provenance, reviewed through corrective dev084; dev083 was NOT accepted.
- Manual acceptance of dev081 Session Instrumentation, embedded Library, Instruments/Tools menus and unsaved instrument-edit decisions.
- Manual acceptance of dev080 policy authoring, Builder 1.2.0 advanced editor and Python/Octave generated modules; legacy modules retain normal functionality with clean duplicate defaults.
- Locate the presumed apparently-unused-API ledger; the Phase 1 cycle found no authoritative register. Preserved command contracts are explicit in the existing Project API manual and dev077 technical report.
- Broader Configuration redesign and any Project / Session reorganization beyond the delivered dev085 scope, under a separate assignment.
- Separately scoped Analysis / Dataset-selector work.
- Profile follow-up: optional numeric accumulation during publication, distributed same-identity property merge, provider null-mask semantics and measured multidimensional summaries.
- Geometry follow-up beyond dev088 bounded resource transport: unbounded/incremental streaming, inter-Session live geometry exchange and owner-normalized expression/constraint frame conversion; mixed bulk/Dataset-backed Workbench source adapters beyond the retained snapshot.
- Multiview follow-up: asynchronous owner regeneration and explicit external Dataset invalidation adapters when a consumer needs them; current model updates require the supplied owner procedure.
- CORE Transform planning: cancellable/asynchronous filtered-plan preparation for strict end-to-end large-family responsiveness.
- Native3D: dark navigation-cube labels on this server's explicit Hardware backend and unchanged full Viewer; embedded hosts use the existing Software policy.
- Native3D/OCCT: expose reliable imported/normalized STEP units through the public result.
- Broader per-codec/provider validation beyond direct fixtures in the existing contract matrix.
- Previously scoped dev066 remote X11 user review.
- Solver capabilities beyond existing supported relationships.
- Final Curve Workbench demo/screenshots/multi-page HTML guide after acceptance.
- Physical printer integration.
- Separately scoped Native3D and Scientific Libraries capabilities beyond documented bounds.
- Complete the framework-wide authority catalog beyond the reviewed Project/Session Portable owners.
- Separately remediate retained Tcl wrapper chains after tracing all CORE/GUI/bridge/generator and installed module consumers; dev085/dev086 add no wrappers.
- Deferred dev092 Curve Workbench background-on-canvas limitation; outside dev093.

Windows-only historical entries remain reserved for the separate future Windows project; they are not release gates for this Debian sequence.

#### Missing authorized scientific source

- **Original independently developed Replicate package — historical unavailable source.** That original package remains unavailable. The commissioned dev102 task implemented and verified public orchestration over the actually deposited CORE Numeric/Statistics/CurveSource owners and the always-available Viewer; it did not fabricate the missing package. Preserve the source-specific interoperability gap and advanced estimator follow-up below.

#### Other unfinished original master-plan scope

- Preserve historical Electromagnetics requirements beyond the verified linear planar static 2D service, CFD and solver/transport requirements beyond the delivered bounded local registered providers, plus explicitly documented residual Worksheet/native Plot requirements. These remain unfinished until a later exact assignment and genuine verification close them; this list does not authorize additional work.
- Unrelated Native2D/Native3D capabilities and additional scientific Viewers beyond the verified bounded image-local ROI/layer/mask/composition and managed appearance/profile workflows remain unfinished.
- Other unresolved requirements of the preserved original large dev098 master task remain historical unfinished work. Preserve that document unchanged; do not use it as an additional execution queue.

#### dev102 defect-resolution backlog — do not execute in this assignment

- **Native Worksheet regional painting — noncritical optimization residual, dev100.** The native grid correctly coalesces queued work and repaints the bounded whole visible viewport to one Cairo backing pixmap; it does not implement dirty-tile/rectangle-only invalidation. Actual rapid navigation, signed bounds, source identities and lifetime tests passed. The final 20K benchmark measured 46.304/46.500 ms p50/p95 per 30-event burst; this is whole-viewport behavior, not proof of regional painting. A later owner-scoped optimization remains unfinished. Evidence: `finalgrid-acceptance.json`, `grid-benchmark100-03`, `grid-benchmark-summary.json`, `docs/reports/DEV100_INTEGRATION_AND_EVIDENCE.md`. Scientific impact: no demonstrated data, identity or range error; no memory-improvement claim. Do not begin this correction in dev101.

- **Inspector publication modal GUI confirmation — residual verification limitation, dev098.** The real installed 0.4.1 GUI passed image selection, ROI gesture/context action, ImageMagick edit, Accept preview, annotation/History and Workspace/Session reopening. Its public `figurePublish` producer published the restored GUI recipe as a canonical derived Image Dataset, which the real GUI reopened. The automated confirmation-dialog click did not obtain a PASS; retain the failed attempts and perform a focused human or corrected automation replay in dev102 rather than claiming complete modal coverage. Evidence: `_evidence_official_dev098/gui-inspector-01` through `gui-inspector-09`, especially `gui-inspector-09.log`; `docs/reports/DEV098_INTEGRATION_AND_EVIDENCE.md`. Scientific impact: no demonstrated source-data corruption or publication-contract failure; uncertainty is confined to confirmation interaction coverage.
- **Locate the separate cited signed Digitalizer source for source-specific replay — evidence gap, dev098.** The located `guida_digitalizer` combined Dataset has actual X `0.02004552627012056..4.968627360303313` V and Y `0.020994681085760206..3.717917911127186` mA; it is not the source cited with X `-0.45968..5.4478` V and Y `-0.35007..4.0785` mA. The missing source-specific signed replay remains unfinished. Distinct canonical signed fixtures passed real Fit, extrema visibility, zoom/pan/refit and independent tick/grid checks. Preserve both evidence classes and all original data. Evidence: `probe-02`, `gui-axes-02`, `gui-axes-03`, `independent-axes-01.json` and `docs/reports/DEV098_INTEGRATION_AND_EVIDENCE.md`. Scientific impact: no demonstrated signed-axis clipping in the implemented path; the exact cited historical source could not be independently replayed.

- **Session-open scale design — unfinished after bounded dev099 investigation.** Two genuine private GUI openings did not establish a safe standalone deduplication; existing identity/transaction/authority checks remain intact. No speed gain is claimed and no cache/index redesign was performed. A later separately scoped scale design remains deferred; do not execute it in this release sequence. Evidence: `projects-open-trace-01`, `projects-final.json`, `docs/reports/DEV099_PROJECTS.md`.


#### dev102 remaining verification and scientific follow-up

The implemented A–I Debian work is removed only against the receipt allowlist in
`release_evidence/official_dev102/acceptance-ledger.json`. Existing earlier debts
above and all future-release requirements below remain unfinished.

- **Shared-factor covariance-aware Replicate estimator and unavailable original service package — unfinished.** Dev102 exposes legitimate descriptive/conditional-independent and identifiable hierarchical Numeric results. Shared-factor covariance-aware estimation and confidence/prediction intervals remain explicitly unavailable; no fabricated source package or Gaussian bands. Exact interoperability with the unavailable original independently developed package remains untested.
- **Shared Viewer selector platform acceptance — unverified beyond local Debian X11.** Worksheet and Curve Fitter passed actual in-Viewer bounds, resize, upward/short scroll fallback, focus/keyboard and cleanup. Windows, remote X11 and alternate DPI/theme acceptance require their genuine environments; no cross-platform PASS is claimed.


#### Remaining portability and acceptance scope

- The separately scoped Windows compute/client backend and its genuine end-to-end environment remain future work. Shared scientific/GUI/Job/Dataset contracts keep replaceable platform adapters; no Windows test or port is required for the Debian release.
- The original ordinary-interaction trigger for the reported Replicate window-grab failure was not observed on the local Debian desktop. The exact native-popdown error was reproduced with a controlled unmap and repaired through shared mapped lifecycle/contained controls; original-environment trigger-specific reproduction remains unverified.

Scientific Library future milestones are consolidated in the current TASK210
Library item above: completed Step3/base-binding scopes are not restored as
unfinished historical work. Original dev109/dev108 documents and all failed or
UNKNOWN evidence remain preserved at their original paths.
