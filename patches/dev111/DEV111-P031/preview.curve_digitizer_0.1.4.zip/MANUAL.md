# Curve Digitalizer Dataset Preview

Open the published Curve Digitalizer Dataset in the ordinary Dataset
Preview. The module contributes three additional tabs:

1. Curves — Click Load curves to discover curve/calibration pairs from
   the published Curve Dataset Schema, then display their filtered canonical
   X/Y points using Plot Dataset API v4. Select a curve and Show/Hide;
   Show all resets presentation visibility only. Use Fit/Zoom on native Plot.
2. Calibration & Quality — Read-only canonical publication metadata
   and Quality Report v2. Missing values are explicitly marked.
3. Canonical Data — Original published rows with Curve and Calibration IDs,
   point order, scientific X/Y and original raster pixel coordinates,
   using the CORE Dataset Preview table.

The chart groups by (curve_key, calibration_key) for Combined publication
and curve_key for Separate publication. Labels are presentation only.
This version scans at most 20,000 canonical rows for display-group
discovery; larger datasets receive a clear refusal, not partial analysis.
Full data remains registered in CORE.

Limit: The CORE table tab is unfiltered. Curve visibility in the Plot does
not change canonical table rows. The current public table-page contract
offers ranges and variable projection but no filtered subset keyed by
curve and calibration. No private CSV/HDF5 parser is introduced.

No local C++ library is needed: Plot API v4 uses GX-TXT's existing C++
renderer. The Builder Preview-target handlers are Tcl host integration,
not an unrelated compiled Viewer process or standalone window.

## Diagnostic and implementation (0.1.4)

The module reads bounded, immutable canonical pages through the installed
DATASET_PREVIEW_API_v1, resolves curve and calibration Variable IDs using
the published Curve Dataset Schema v1, then passes a disposable nine-series
model to PLOT_DATASET_API_v4 with prepared_model=1.
No separate renderer, data writer, Dataset Transform, CSV reader or
private Session path is involved. The Plot is destroyed with the Preview
host, and every source read checks the current Session and canonical identity.

A maximum of 20,000 original Dataset rows, 256 groups and 4,096 points per
individual curve/calibration group is supported in this version for a
complete, non-reduced graphical preview. Out-of-bounds data refuses
rather than silently dropping points; the full canonical Dataset is unchanged.


### GUI responsiveness (0.1.4)

Select **Load curves** once. The button returns immediately; the status line
reports how many canonical rows have been read. Every bounded page yields
to the Tk event loop before proceeding. A second Load cancels the prior
request; closing the Preview cancels unfinished work and releases the
module-owned Plot. Plot v4's native C++ renderer owns the actual drawing.

This is *cooperative* source preparation, not an independently threaded
C++ viewer. It cannot eliminate a slow individual CORE Dataset page call
or change the framework's own periodic Preview observer; those remain
subject to the standard owner and the work-copy performance correction.

### 0.1.4 — Controls

Open Curves and press **Load curves**. The previously empty white list
fills with the available curve/calibration groups. Select one item and
use Show/Hide, or Show all. Native Plot v4 renders the source data.
The initial list is empty until Load curves has completed.

### 0.1.4 — Visible Curves list

The Curves tab initially displays a single non-data instruction:
"Select here or press Load curves to display the available curves".
Selecting that row or clicking **Load curves** starts the identical
bounded cooperative read. Successful loading replaces the instruction
with the actual curve/calibration groups. The module does not fetch
scientific data while the parent GUI mounts.

### Persistent cache limitations

The framework **already caches its standard prepared Dataset Preview** in
the Session via DATASET_PREVIEW_API_v1, and exposes
datasetPreviewCacheRequest/Subscribe/Read. This module does not create a
private cache or modify the standard CORE cache's serializer.

A cached **300-row** representation with a single selected calibration
must not be reused as the **900-row** nine-group presentation: that would
silently omit two physical calibration realizations. Any future reuse
must request its own exact unfiltered scientific selection, validate the
source/renderer identity and prove the resulting cached model includes
every requested (curve, calibration) group before rendering.
