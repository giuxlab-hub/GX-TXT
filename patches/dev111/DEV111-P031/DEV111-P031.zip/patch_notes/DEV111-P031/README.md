# DEV111-P031: UML, Plot axes, Preview and shared Markdown navigation

This incremental direct-root overlay requires the complete accepted P030 framework.
Exact predecessor source `b61349890ff684510625bfc60d394c50fca1da43`, ZIP SHA256 `71929d3999c2ede5b3d0a85b7fbc0de31cc6773a9834fa8cd6d280a2a3390850`. Candidate source
`c998fe69626834550164534e22131e9cb8810448`. Its BASELINE plus FILES postimages define the exact physical predecessor
closure; unrelated files stay outside that guard. Preparation is not acceptance.
Consult the separate independent A/B reports and final handoff before use.

P031 extends shared CORE UML class/sequence document semantics and native authoring,
custom X position/caption pairs through the existing Plot v2/v3/v4 owners, normal
Acquisition Select/Help/About and the illustrated Rigol guide. It also corrects
framework-wide Preview activation persistence, rebases the owner's final cumulative
r2 optimization, and completes shared Markdown anchors and authenticated relative
links. The supplied Preview0.1.4 original is retained; a separately versioned0.1.5
presentation correction uses its unchanged scientific runtime. No design-only new
cache API is implemented. Exact support and acceptance limitations belong in the
release handoff, not inferred from this packaging description.

Inherited owner Curve Digitizer2.0.20 remains unchanged: original filename
viewer.curve_digitizer_2.0.20_publication_classification.zip, SHA256
acbc81a77ed1625bde3030e871ec88513a28f08b1317780f8e95b3e2b10ff152.
Qualification OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST. No functional,
numerical, GUI, installation, regression or compatibility acceptance is claimed
for that Viewer. Necessary public read-only schema use by the separate Preview
is qualified as Preview testing only. Packaging rebuilds no supplied/native binary.

Keep the ZIP and adjacent checksum. Apply only to a stopped, complete compatible
P030 framework with a retained full backup. Helpers do not stop or detect workers;
--stopped is operator acknowledgement. Extract only patch_notes/DEV111-P031/ to a
separate review directory, then run:

    python3 review/patch_notes/DEV111-P031/apply.py FRAMEWORK DEV111-P031.zip --check
    python3 review/patch_notes/DEV111-P031/apply.py FRAMEWORK DEV111-P031.zip --apply --stopped

Default is read-only. Writes use the existing POSIX directory lock and atomic
per-file replacement, not a whole-root transaction. Verified rollback notes are
published before product writes. Interruption recovery admits only exact known
before/after bytes and modes. Unknown edits or collisions refuse. Plain unzip
cannot implement declared deletions. Prior notes and user extras are retained.

    python3 FRAMEWORK/patch_notes/DEV111-P031/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P031/rollback.py FRAMEWORK --rollback --stopped

Rollback restores P030 bytes and physical modes and removes only P031 additions.
Reverse later patches first. Retained P031 notes can be moved separately by the
operator after a verified rollback before deliberate reapply; helpers never
silently overwrite existing notes. No Session, Configuration, RAW, scientific
payload, previous archive, installation or activation cleanup is authorized.

The overlay already bundles the modules in MODULE_VERSION_MATRIX.json. Run
companion_preflight.py against the exact postimages to inspect compatibility;
already bundled modules need no forced reinstall. Separate normal module ZIPs
are alternative delivery for a compatible stopped/prepared host with absent or
legitimately managed targets. framework_min=dev111 does not distinguish patch
numbers and is not a P029/P030 compatibility claim.
For UML Editor1.0.0 and UML Preview1.0.0, the generated descriptors have no
patch-level expression: both require the matching P031 CORE UML owners and
their explicitly admitted native Document grants. The original genuine containers
are unchanged; a generic framework version alone does not prove compatibility.
Normal Plugin Manager lifecycle can change overlay/rollback identity; do not fabricate Registry entries or remove
bundled modules to force admission. Canonical deposit and live activation remain
separate from these helpers.
