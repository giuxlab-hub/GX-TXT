# SPDX-License-Identifier: GPL-3.0-or-later
"""P031 finite file-overlay guards. No runtime, Session or configuration owner."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, stat, tempfile, zipfile
from contextlib import contextmanager

PATCH = 'DEV111-P031'
ARCHIVE = PATCH + '.zip'
RELEASE_REVISION = 1
BASE = 'b61349890ff684510625bfc60d394c50fca1da43'
BASE_SHA = '71929d3999c2ede5b3d0a85b7fbc0de31cc6773a9834fa8cd6d280a2a3390850'
NOTES = 'patch_notes/' + PATCH
MAX_FILE = 128 * 1024 * 1024
MAX_ZIP = 512 * 1024 * 1024

class GuardError(RuntimeError):
    pass

def require(test, message):
    if not test:
        raise GuardError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def relative(name):
    require(isinstance(name, str) and name and len(name) <= 4096 and '\\' not in name and ':' not in name and not any(ord(c) < 32 for c in name), 'Unsafe relative path')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(part not in ('', '.', '..') for part in name.split('/')), 'Unsafe relative path: ' + name)
    return p

SPECIAL = {'gxtxt_pipeline.tcl', 'VERSION.txt', 'PATCH_LEVEL.txt', 'GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'LICENSE'}
SKIP = {'tests', 'validation', 'evidence', 'review', 'archives', 'archive', '__pycache__', '.git', 'node_modules', 'scratch'}

def runtime_path(name):
    p = relative(name)
    # Exact owner-supplied module includes inert tests/documentation unchanged.
    if name.startswith(('plugins/modules/viewer.curve_digitizer/', 'plugins/modules/preview.curve_digitizer/')):
        return True
    # These are installed Native Viewer admission/source receipts, not campaign
    # evidence. Omitting them would pair a new binary with an old build identity.
    if len(p.parts) == 5 and p.parts[:2] == ('plugins', 'modules') and p.parts[3] == 'review' and p.parts[4] in ('build.json', 'validation.json'):
        return True
    if any(x.lower() in SKIP for x in p.parts) or name.lower().endswith(('.zip', '.tar', '.gz', '.xz', '.bz2', '.7z', '.pyc', '.log')):
        return False
    return name in SPECIAL or name.startswith(('app/', 'core/', 'plugins/', 'docs/api/', 'services/'))

MODULES = {'acq.text_document': '1.2.0', 'acq.rigol_csv': '2.3.1',
           'plot.dataset': '4.3.0', 'viewer.interface_builder': '1.2.10',
           'viewer.uml_editor': '1.0.0', 'preview.uml_document': '1.0.0',
           'preview.curve_digitizer': '0.1.5'}
# These are exact prepared container inputs, not all owner-supplied packages.
# Unchanged P030 native Markdown and Curve packages remain in the guarded base;
# do not duplicate accepted archives already deposited on SSD.
ORIGINAL_MODULES = {'viewer.uml_editor', 'preview.uml_document', 'preview.curve_digitizer'}
OWNER_MODULE = 'viewer.curve_digitizer'
OWNER_FILENAME = 'viewer.curve_digitizer_2.0.20_publication_classification.zip'
OWNER_SHA = 'acbc81a77ed1625bde3030e871ec88513a28f08b1317780f8e95b3e2b10ff152'
OWNER_QUALIFICATION = 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST'
OWNER_QUALIFICATIONS = {OWNER_MODULE: OWNER_QUALIFICATION}
SUPPLIED_PREVIEW_KEY = 'preview.curve_digitizer@0.1.4'
SUPPLIED_PREVIEW_FILENAME = 'preview.curve_digitizer_0.1.4.zip'
SUPPLIED_PREVIEW_SHA = 'c07ae52b27dd81737eb2f95acaf842eb56e6c48f6eccdc6722b41d854335cfac'
SUPPLIED_PREVIEW_PATH = 'validation/dev111_p031_owner_preview_014/original/' + SUPPLIED_PREVIEW_FILENAME
SUPPLIED_INPUT_ARCHIVES = {SUPPLIED_PREVIEW_KEY: SUPPLIED_PREVIEW_SHA}
ORIGINAL_PACKAGE_SHA = {
    'viewer.uml_editor': '3a3e8bc7988dea6c4cb0d3efaa6abb153d7d54f6a75e9f859eea4e2ce2bd6061',
    'preview.uml_document': '537999bc4a0c269d0a215b0e5db4568dc440f79fbe5063da27c5971db00d5557',
    'preview.curve_digitizer': '1e57baf0ee7b3cd6c0368c1b77c79290caed22cd641342390a6ee59ba0a4be07',
}

def module_archive_name(module, version):
    return OWNER_FILENAME if module == OWNER_MODULE else module + '_' + version + '.zip'

BASE_ZIP = Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV111-P030.zip')
NOTE_FILES = {'FILES.json', 'BASELINE.json', 'BUILD_IDENTITY.json', 'MODULE_VERSION_MATRIX.json',
              'DELETIONS.json', 'README.md', 'apply.py', 'rollback.py', 'release_common.py',
              'companion_preflight.py', 'PAYLOAD_SHA256SUMS', 'SUPPLIED_INPUTS.json'}

# Exact reviewed P031 product paths; extend explicitly after coherent source review.
PAYLOAD_SCOPE = frozenset(['GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'PATCH_LEVEL.txt', 'app/configuration_manifest.tcl', 'app/graph_browser.tcl', 'app/graph_dialogs.tcl', 'app/graph_toolbar_tips.tcl', 'app/gui/acquisition_page.tcl', 'app/gui/configuration_modules.tcl', 'app/gui/configuration_page.tcl', 'app/gui/configuration_preview_components.tcl', 'app/gui/dataset_preview_live.tcl', 'app/gui/documentation_browser.tcl', 'app/gui/documentation_module_window.tcl', 'app/module_catalog.tcl', 'app/session_controller.tcl', 'core/api_catalog/catalog.sqlite', 'core/api_catalog/source_manifest.json', 'core/development/policy_v1.json', 'core/native2d/CMakeLists.txt', 'core/native2d/bin/BUILD_RECEIPT_P031.json', 'core/native2d/bin/gx2dtcl.so', 'core/native2d/gx2d_plot_caption_layout.inc', 'core/native2d/gx2d_plot_v4.cpp', 'core/native2d/gx2d_surface.cpp', 'core/nativegui/document/gxtxt_html_runtime', 'core/nativegui/document/gxtxt_html_runtime.info', 'core/nativegui/document/html_runtime.cpp', 'core/octave/graphics/gxtxt_plot_write_metadata.m', 'core/octave/graphics/gxtxt_png_density.py', 'core/octave/graphics/gxtxt_print_png_atomic.m', 'core/python/gxtxt_viewer_development.py', 'core/tcl/configuration_api_v1.tcl', 'core/tcl/configuration_modules_v1.tcl', 'core/tcl/dataset_file_publication_api_v1.tcl', 'core/tcl/dataset_notes_api_v1.tcl', 'core/tcl/dataset_preview_provider_v1.tcl', 'core/tcl/dataset_private_metadata_api_v1.tcl', 'core/tcl/document_edit_v1.tcl', 'core/tcl/document_source_api_v1.tcl', 'core/tcl/documentation_browser_api_v1.tcl', 'core/tcl/graph_renderer_dispatch_v1.tcl', 'core/tcl/graph_workflow_api_v1.tcl', 'core/tcl/markdown_navigation_v1.tcl', 'core/tcl/module_api_v1.tcl', 'core/tcl/native3d_compact_preview_v1.tcl', 'core/tcl/plot_layout_controls_v1.tcl', 'core/tcl/scientific_dataset_filter_configuration_v1.tcl', 'core/tcl/scientific_dataset_preview_v1.tcl', 'core/tcl/scientific_plot_axis_ticks_v1.tcl', 'core/tcl/scientific_plot_framework_api_v1.tcl', 'core/tcl/session_file_explorer_api_v1.tcl', 'core/tcl/source_surface_api_v1.tcl', 'core/tcl/ui_field_api_v1.tcl', 'core/tcl/ui_field_viewer_regions_v1.tcl', 'core/tcl/uml_diagram_host_v1.tcl', 'core/tcl/uml_document_api_v1.tcl', 'core/tcl/uml_editor_v1.tcl', 'core/tcl/uml_layout_v1.tcl', 'core/tcl/viewer_development_api_v1.tcl', 'core/tcl/viewer_development_preview_v1.tcl', 'core/tcl/viewer_development_project_workspace_v1.tcl', 'core/tcl/viewer_gui_catalog_v1.tcl', 'core/tcl/viewer_gui_design_v1.tcl', 'core/tcl/viewer_gui_document_v1.tcl', 'core/tcl/viewer_workspace_native_v1.tcl', 'core/tcl/workbench_extension_api_v1.tcl', 'core/tcl/workspace_scientific_codecs_v1.tcl', 'docs/api/CONFIGURATION_API_v1.md', 'docs/api/CPP_SUPPORT_CATALOG.md', 'docs/api/DATASET_PREVIEW_API_v1.md', 'docs/api/DOCUMENTATION_BROWSER_API_v1.md', 'docs/api/DOCUMENT_SOURCE_API_v1.md', 'docs/api/MARKDOWN_NAVIGATION_v1.md', 'docs/api/MODULE_API_v1.md', 'docs/api/NATIVE2D_TEXT_ENGINE_v1.md', 'docs/api/NATIVE_WORKSPACE_API_v1.md', 'docs/api/SCIENTIFIC_PLOT_FRAMEWORK_API_v1.md', 'docs/api/SCRIPT_BRIDGE_COVERAGE_v1.json', 'docs/api/UML_DOCUMENT_API_v1.md', 'docs/api/VIEWER_DEVELOPMENT_API_v1.md', 'plugins/modules/acq.rigol_csv/CHANGELOG.md', 'plugins/modules/acq.rigol_csv/MANUAL.html', 'plugins/modules/acq.rigol_csv/MANUAL.md', 'plugins/modules/acq.rigol_csv/SHA256SUMS.txt', 'plugins/modules/acq.rigol_csv/TUTORIAL.html', 'plugins/modules/acq.rigol_csv/manual-images/rigol_canonical_metadata.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_canonical_preview_group.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_canonical_provenance.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_managed_progress.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_native_hdf5_options.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_pending_preview.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_pending_variables.png', 'plugins/modules/acq.rigol_csv/manual-images/rigol_source_queued.png', 'plugins/modules/acq.rigol_csv/module.ini', 'plugins/modules/acq.rigol_csv/plugin-package.ini', 'plugins/modules/acq.text_document/CHANGELOG.md', 'plugins/modules/acq.text_document/MANUAL.html', 'plugins/modules/acq.text_document/README.md', 'plugins/modules/acq.text_document/SHA256SUMS.txt', 'plugins/modules/acq.text_document/module.ini', 'plugins/modules/acq.text_document/plugin-package.ini', 'plugins/modules/acq.text_document/runtime/acquisition_handler.tcl', 'plugins/modules/plot.dataset/CHANGELOG.md', 'plugins/modules/plot.dataset/MANUAL.md', 'plugins/modules/plot.dataset/PLOT_DATASET_API_v2.md', 'plugins/modules/plot.dataset/README.md', 'plugins/modules/plot.dataset/SHA256SUMS', 'plugins/modules/plot.dataset/SHA256SUMS.txt', 'plugins/modules/plot.dataset/api/plot_dataset_api_v2.tcl', 'plugins/modules/plot.dataset/api/plot_dataset_api_v4.tcl', 'plugins/modules/plot.dataset/api/plot_dataset_v4_snapshots.tcl', 'plugins/modules/plot.dataset/api/script_bridge_binding.py', 'plugins/modules/plot.dataset/docs/images/p031-x-tick-pairs.png', 'plugins/modules/plot.dataset/module.ini', 'plugins/modules/plot.dataset/plugin-package.ini', 'plugins/modules/plot.dataset/runtime/native_v4_snapshot.tcl', 'plugins/modules/plot.dataset/runtime/pd_plotspec_v2.m', 'plugins/modules/plot.dataset/runtime/pd_project_x_tick_units.m', 'plugins/modules/plot.dataset/runtime/pd_render_2d.m', 'plugins/modules/plot.dataset/ui/plot_dataset_editor_v2.tcl', 'plugins/modules/preview.curve_digitizer/CHANGELOG.md', 'plugins/modules/preview.curve_digitizer/CORE_GAPS.md', 'plugins/modules/preview.curve_digitizer/MANUAL.md', 'plugins/modules/preview.curve_digitizer/README.md', 'plugins/modules/preview.curve_digitizer/RELEASE_VALIDATION.md', 'plugins/modules/preview.curve_digitizer/SHA256SUMS.txt', 'plugins/modules/preview.curve_digitizer/api/preview.tcl', 'plugins/modules/preview.curve_digitizer/gui/design.tcldict', 'plugins/modules/preview.curve_digitizer/module.ini', 'plugins/modules/preview.curve_digitizer/plugin-package.ini', 'plugins/modules/preview.curve_digitizer/tests/test_builder_design_012.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_preview_async_012.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_preview_dispatch_014.tcl', 'plugins/modules/preview.uml_document/LICENSE', 'plugins/modules/preview.uml_document/MANUAL.md', 'plugins/modules/preview.uml_document/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/preview.uml_document/SHA256SUMS.txt', 'plugins/modules/preview.uml_document/api/viewer.tcl', 'plugins/modules/preview.uml_document/gui/design.tcldict', 'plugins/modules/preview.uml_document/handlers.tcl', 'plugins/modules/preview.uml_document/module.ini', 'plugins/modules/preview.uml_document/native/SDK_CONTRACT.json', 'plugins/modules/preview.uml_document/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/preview.uml_document/native/trusted_adapter_v1.cpp', 'plugins/modules/preview.uml_document/native/viewer.so', 'plugins/modules/preview.uml_document/plugin-package.ini', 'plugins/modules/preview.uml_document/review/build.json', 'plugins/modules/preview.uml_document/review/validation.json', 'plugins/modules/preview.uml_document/source/MANUAL.md', 'plugins/modules/preview.uml_document/source/SOURCE_MANIFEST.json', 'plugins/modules/preview.uml_document/source/design.gxtxt-viewer', 'plugins/modules/preview.uml_document/source/handlers.cpp', 'plugins/modules/preview.uml_document/source/project.json', 'plugins/modules/viewer.interface_builder/CHANGELOG.md', 'plugins/modules/viewer.interface_builder/MANUAL.md', 'plugins/modules/viewer.interface_builder/SHA256SUMS.txt', 'plugins/modules/viewer.interface_builder/api/builder.tcl', 'plugins/modules/viewer.interface_builder/module.ini', 'plugins/modules/viewer.interface_builder/plugin-package.ini', 'plugins/modules/viewer.uml_editor/LICENSE', 'plugins/modules/viewer.uml_editor/MANUAL.md', 'plugins/modules/viewer.uml_editor/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/viewer.uml_editor/SHA256SUMS.txt', 'plugins/modules/viewer.uml_editor/api/viewer.tcl', 'plugins/modules/viewer.uml_editor/gui/design.tcldict', 'plugins/modules/viewer.uml_editor/handlers.tcl', 'plugins/modules/viewer.uml_editor/module.ini', 'plugins/modules/viewer.uml_editor/native/SDK_CONTRACT.json', 'plugins/modules/viewer.uml_editor/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/viewer.uml_editor/native/trusted_adapter_v1.cpp', 'plugins/modules/viewer.uml_editor/native/viewer.so', 'plugins/modules/viewer.uml_editor/plugin-package.ini', 'plugins/modules/viewer.uml_editor/review/build.json', 'plugins/modules/viewer.uml_editor/review/validation.json', 'plugins/modules/viewer.uml_editor/source/MANUAL.md', 'plugins/modules/viewer.uml_editor/source/SOURCE_MANIFEST.json', 'plugins/modules/viewer.uml_editor/source/design.gxtxt-viewer', 'plugins/modules/viewer.uml_editor/source/handlers.cpp', 'plugins/modules/viewer.uml_editor/source/project.json'])

def payload_path(name):
    relative(name)
    return name in PAYLOAD_SCOPE

def root_path(root):
    root = Path(os.path.abspath(root))
    for p in [*reversed(root.parents), root]:
        require(not p.is_symlink(), 'Linked framework root/ancestor: ' + str(p))
    require(root.is_dir(), 'Existing canonical framework directory required')
    return root

def member(root, name):
    current = root
    parts = relative(name).parts
    for index, part in enumerate(parts):
        current = current / part
        require(not current.is_symlink(), 'Linked target/ancestor: ' + str(current))
        if current.exists() and index < len(parts)-1:
            require(current.is_dir(), 'Non-directory ancestor: ' + str(current))
    return current

def identity(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return None
    require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1, 'Nonregular/linked target: ' + str(path))
    return {'sha256': sha(path), 'mode': stat.S_IMODE(st.st_mode), 'size': st.st_size}

def matches(actual, expected):
    return actual == expected

def zip_index(z):
    entries = {}
    directories = set()
    for item in z.infolist():
        require(not item.flag_bits & 1, 'Encrypted ZIP unsupported')
        name = item.filename.rstrip('/') if item.is_dir() else item.filename
        relative(name)
        require(name not in entries and name not in directories, 'Duplicate ZIP member: ' + name)
        mode = item.external_attr >> 16
        if item.is_dir():
            require(stat.S_IFMT(mode) in (0, stat.S_IFDIR), 'Invalid ZIP directory')
            directories.add(name)
            continue
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG) and not stat.S_ISLNK(mode), 'Nonregular ZIP member: ' + name)
        require(item.file_size <= MAX_FILE, 'Oversized ZIP member: ' + name)
        entries[name] = item
    require(sum(x.file_size for x in entries.values()) <= MAX_ZIP, 'ZIP exceeds patch bound')
    for name in set(entries) | directories:
        require(all(str(p) not in entries for p in PurePosixPath(name).parents if str(p) != '.'), 'ZIP file/directory collision')
    require(z.testzip() is None, 'ZIP CRC failure')
    return entries

def file_record(value, nullable=False):
    if value is None:
        require(nullable, 'Required file identity is absent')
        return
    require(isinstance(value, dict) and set(value) == {'sha256', 'mode', 'size'}, 'Invalid file identity fields')
    require(isinstance(value['sha256'], str) and len(value['sha256']) == 64 and all(c in '0123456789abcdef' for c in value['sha256']), 'Invalid SHA256')
    require(type(value['mode']) is int and 0 <= value['mode'] <= 0o777, 'Invalid file mode')
    require(type(value['size']) is int and 0 <= value['size'] <= MAX_FILE, 'Invalid file size')

def validate(manifest, closure):
    require(isinstance(manifest, dict) and isinstance(closure, dict), 'Manifest/closure must be objects')
    require(manifest.get('schema') == 'gxtxt.dev111.p031.overlay.v1' and manifest.get('patch') == PATCH and manifest.get('baseline_patch') == 'DEV111-P030' and manifest.get('baseline_commit') == BASE and manifest.get('baseline_archive_sha256') == BASE_SHA, 'Wrong patch or exact P030 predecessor identity')
    require(isinstance(manifest.get('source_commit'), str) and len(manifest['source_commit']) == 40 and all(c in '0123456789abcdef' for c in manifest['source_commit']), 'Invalid source commit')
    require(closure.get('schema') == 'gxtxt.dev111.p031.baseline.v1' and closure.get('source_commit') == BASE and closure.get('archive_sha256') == BASE_SHA and isinstance(closure.get('files'), dict) and closure['files'], 'Invalid predecessor closure')
    require('core/tcl/plugin_install_api_v1.tcl' in closure['files'], 'Missing baseline sentinel')
    require(digest(json_bytes(closure)) == manifest.get('baseline_closure_sha256'), 'Baseline closure checksum differs')
    for name, expected in closure['files'].items():
        require(runtime_path(name), 'Non-runtime predecessor path: ' + name); file_record(expected)
    rows = manifest.get('changed_files')
    require(isinstance(rows, list) and rows, 'Nonempty change manifest required')
    seen = set()
    for row in rows:
        require(set(row) == {'path', 'action', 'before', 'after'}, 'Invalid change fields')
        name = row['path'];relative(name)
        require(payload_path(name), 'Protected/non-runtime payload path: ' + name)
        require(name not in seen and not name.startswith('patch_notes/'), 'Duplicate/reserved product path')
        seen.add(name);file_record(row['before'], True);file_record(row['after'], True)
        expected_action = 'add' if row['before'] is None else 'delete' if row['after'] is None else 'replace'
        require(row['action'] == expected_action and row['before'] != row['after'], 'Invalid or unchanged change action')
        require(closure['files'].get(name) == row['before'], 'Change preimage differs from exact baseline closure: ' + name)
    require(manifest.get('deleted_files') == [r['path'] for r in rows if r['after'] is None], 'Deletion list differs')
    return rows

def sums(text):
    result = {}
    for line in text.decode('utf-8').splitlines():
        value, name = line.split('  ', 1);relative(name)
        require(name not in result and len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'Invalid checksum entry')
        result[name] = value
    return result

def archive_data(path, expected_sha=None):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), 'Regular patch ZIP required')
    if expected_sha is None:
        sidecar = Path(str(path) + '.sha256')
        require(not sidecar.is_symlink() and sidecar.is_file(), 'Provide adjacent ZIP.sha256 or --sha256')
        words = sidecar.read_text().split()
        require(len(words) == 2 and words[1] == path.name, 'Invalid archive checksum sidecar')
        expected_sha = words[0]
    require(sha(path) == expected_sha, 'Patch ZIP SHA256 differs')
    with zipfile.ZipFile(path) as z:
        entries = zip_index(z)
        require(NOTES + '/FILES.json' in entries and NOTES + '/BASELINE.json' in entries, 'Missing P031 notes/closure')
        data = {name: z.read(name) for name in entries}
        manifest = json.loads(data[NOTES + '/FILES.json']);closure = json.loads(data[NOTES + '/BASELINE.json'])
        rows = validate(manifest, closure)
        required_notes = {NOTES + '/' + n for n in NOTE_FILES} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
        require({n for n in data if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected P031 notes')
        for name in required_notes:
            if not name.startswith(NOTES + '/rollback-preimages/'):
                require(((entries[name].external_attr >> 16) & 0o777) == 0o644, 'Wrong notes/helper mode: ' + name)
        build = json.loads(data[NOTES + '/BUILD_IDENTITY.json'])
        require(build.get('original_input_archives') == SUPPLIED_INPUT_ARCHIVES,
                'Original supplied Preview container identity missing')
        supplied = json.loads(data[NOTES + '/SUPPLIED_INPUTS.json'])
        require(set(supplied) == {SUPPLIED_PREVIEW_KEY}
                and supplied[SUPPLIED_PREVIEW_KEY]['sha256'] == SUPPLIED_PREVIEW_SHA
                and supplied[SUPPLIED_PREVIEW_KEY]['filename'] == SUPPLIED_PREVIEW_FILENAME,
                'Original supplied Preview notes differ')
        require(build.get('patch') == PATCH and build.get('source_commit') == manifest['source_commit']
                and build.get('packaging_helpers_commit') == manifest['source_commit']
                and build.get('baseline_commit') == BASE and build.get('baseline_archive_sha256') == BASE_SHA
                and build.get('native_changes') is True and build.get('packaging_rebuilt_binaries') is False
                and build.get('owner_supplied_qualifications') == OWNER_QUALIFICATIONS,
                'Build/source/helper identity differs')
        for leaf in ('apply.py', 'rollback.py', 'release_common.py', 'companion_preflight.py'):
            expected = build['helper_source_files']['validation/dev111_p031_release/' + leaf]
            file_record(expected)
            raw = data[NOTES + '/' + leaf]
            require(digest(raw) == expected['sha256'] and len(raw) == expected['size'], 'Bundled helper source identity differs: ' + leaf)
        matrix = json.loads(data[NOTES + '/MODULE_VERSION_MATRIX.json'])
        require(matrix.get('patch') == PATCH and len(matrix['modules']) == len(MODULES)
                and {m['module']: m['distribution_version'] for m in matrix['modules']} == MODULES,
                'P031 companion module matrix differs')
        require(json.loads(data[NOTES + '/DELETIONS.json']) == manifest['deleted_files'], 'Deletion notes differ')
        listed = sums(data[NOTES + '/PAYLOAD_SHA256SUMS'])
        require(set(listed) == set(data) - {NOTES + '/PAYLOAD_SHA256SUMS'}, 'Incomplete archive checksums')
        for name, expected in listed.items():
            require(digest(data[name]) == expected, 'Archive checksum differs: ' + name)
        products = {r['path'] for r in rows if r['after'] is not None}
        require(set(data) == products | {n for n in data if n.startswith(NOTES + '/')}, 'Unexpected product member')
        for row in rows:
            for key, name in [('after', row['path']), ('before', NOTES + '/rollback-preimages/' + row['path'])]:
                record = row[key]
                if record is None:
                    continue
                require(name in data and digest(data[name]) == record['sha256'] and len(data[name]) == record['size'] and ((entries[name].external_attr >> 16) & 0o777) == record['mode'], 'Invalid ' + key + ': ' + row['path'])
        return manifest, closure, rows, data, entries

def guard_baseline(root, closure, rows, rollback=False, partial=False):
    changed = {r['path']: r for r in rows}
    for name, expected in closure['files'].items():
        actual = identity(member(root, name));row = changed.get(name)
        if row is None or not rollback:
            require(matches(actual, expected), 'Divergent P030 baseline: ' + name)
    for row in rows:
        actual = identity(member(root, row['path']))
        wanted = row['after'] if rollback else row['before']
        permitted = [wanted, row['before']] if rollback and partial else [wanted]
        require(any(matches(actual, p) for p in permitted), 'Unknown/divergent ' + ('postimage' if rollback else 'preimage') + ': ' + row['path'])

def atomic(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.p031-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data);f.flush();os.fchmod(f.fileno(), mode);os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):os.unlink(temp)

def _apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    manifest, closure, rows, data, entries = archive_data(archive, expected_sha)
    require(not member(root, NOTES).exists(), 'P031 notes already exist; use rollback/recover-partial first')
    guard_baseline(root, closure, rows)
    for name in data:member(root, name)
    if mutate:
        # Publish complete verified rollback information before any product write.
        for name in sorted(data):
            if name.startswith(NOTES + '/'):
                atomic(member(root, name), data[name], (entries[name].external_attr >> 16) & 0o777)
        for row in rows:
            p = member(root, row['path'])
            require(identity(p) == row['before'], 'Preimage changed during apply: ' + row['path'])
            if row['after'] is None:p.unlink()
            else:atomic(p, data[row['path']], row['after']['mode'])
        guard_baseline(root, closure, rows, rollback=True)
    return manifest

def _rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root);notes = member(root, NOTES)
    require(notes.is_dir(), 'Installed P031 notes required')
    manifest_path = member(root, NOTES + '/FILES.json');closure_path = member(root, NOTES + '/BASELINE.json')
    require(identity(manifest_path) is not None and identity(closure_path) is not None, 'Incomplete notes; recover verified notes from the exact archive first')
    manifest = json.loads(manifest_path.read_bytes());closure = json.loads(closure_path.read_bytes());rows = validate(manifest, closure)
    checksum_path = member(root, NOTES + '/PAYLOAD_SHA256SUMS')
    checksum_identity = identity(checksum_path)
    require(checksum_identity is not None and checksum_identity['mode'] == 0o644,
            'Installed checksum manifest must be an unlinked regular0644 file')
    listed = sums(checksum_path.read_bytes())
    required_notes = {NOTES + '/' + n for n in NOTE_FILES - {'PAYLOAD_SHA256SUMS'}} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
    require({n for n in listed if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected installed notes inventory')
    for name, expected in listed.items():
        if name.startswith(NOTES + '/'):
            p = member(root, name)
            require(identity(p) is not None and sha(p) == expected, 'Incomplete/divergent installed notes: ' + name)
            expected_mode = 0o644
            if name.startswith(NOTES + '/rollback-preimages/'):
                product = name[len(NOTES + '/rollback-preimages/'):]
                expected_mode = next(r['before']['mode'] for r in rows if r['path'] == product and r['before'] is not None)
            require(identity(p)['mode'] == expected_mode, 'Installed notes mode differs: ' + name)
    require(NOTES + '/FILES.json' in listed and NOTES + '/BASELINE.json' in listed, 'Unbound installed manifest')
    guard_baseline(root, closure, rows, rollback=True, partial=partial)
    for row in rows:
        if row['before'] is not None:
            p = member(root, NOTES + '/rollback-preimages/' + row['path'])
            require(identity(p) == row['before'], 'Rollback preimage/mode differs: ' + row['path'])
    if mutate:
        for row in reversed(rows):
            p = member(root, row['path']);actual = identity(p)
            require(actual == row['after'] or partial and actual == row['before'], 'Target changed during rollback: ' + row['path'])
            if actual == row['before']:continue
            if row['before'] is None:p.unlink()
            else:
                backup = member(root, NOTES + '/rollback-preimages/' + row['path'])
                atomic(p, backup.read_bytes(), row['before']['mode'])
        guard_baseline(root, closure, rows)
    return manifest

@contextmanager
def operation_lock(root, enabled):
    if not enabled:
        yield
        return
    try:
        import fcntl
    except ImportError as error:
        raise GuardError('Guarded writes require POSIX directory locking; --check remains available') from error
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        try:fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:raise GuardError('Another release helper owns this framework directory') from error
        yield
    finally:os.close(fd)

def apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    with operation_lock(root, mutate):return _apply_overlay(root, archive, mutate, expected_sha)

def rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root)
    with operation_lock(root, mutate):return _rollback_overlay(root, mutate, partial)
