# DEV111-P023 installable incremental overlay

Requires exact DEV111-P022 (c92f9f90caa1d4196fd23023873171c9d9094c6a). Release source: f0f6d0ed969bf218ae069888411c9f0c9c07b555. Accepted implementation: f0f6d0ed969bf218ae069888411c9f0c9c07b555.
ZIP SHA256 is supplied beside the archive. Product paths overlay the framework root directly; no framework/ wrapper. No runtime deletion is required. No driver/system dependency installation. Stop the target application first.

Extract notes to a review directory, then run:

```sh
python3 review/patch_notes/DEV111-P023/apply.py FRAMEWORK DEV111-P023.zip
python3 review/patch_notes/DEV111-P023/apply.py FRAMEWORK DEV111-P023.zip --apply
```

Default is read-only exact-preimage/checksum preflight. Direct overlay after a verified baseline is also supported: `unzip -o DEV111-P023.zip -d FRAMEWORK`.

Rollback after stopping GX-TXT:

```sh
python3 FRAMEWORK/patch_notes/DEV111-P023/rollback.py FRAMEWORK --check
python3 FRAMEWORK/patch_notes/DEV111-P023/rollback.py FRAMEWORK
```

Rollback verifies postimages and restores exact prior bytes/modes, removing only added product files. Notes remain as evidence. Do not roll back across a later patch: reverse the chain first. No Sessions, preferences or scientific data are modified.

This delivery assigns official installable package identity to the accepted implementation and native binaries; separately declared release metadata changes identify updated modules. The manifest distinguishes accepted implementation and release source commits; experimental names retained within that source are provenance, not a renamed experimental archive. Historical experimental and P024 cumulative archives and external evidence remain preserved. Independent qualification receipts are outside this ZIP. Package preparation does not install or activate an owner framework, or confer user GUI acceptance.
