# MAIN1 experimental handoff

SPDX-License-Identifier: GPL-3.0-or-later

**STOP FOR OWNER REVIEW — NOT INSTALLED / NOT ACCEPTED / NO PROMOTION.**

P022 was completed and deposited first:
`/srv/gxtxt/releases/dev111/patches/0022-real-gui-native3d-stabilization/DEV111-P022.zip`
SHA256450d59e503b8e5c49551e97233fa0a3bcf778b13679290b05ce260930b72bc66,
12,793,622 bytes, source c92f9f90caa1d4196fd23023873171c9d9094c6a.
It remains immutable, uninstalled and awaiting owner acceptance.

The complete latest post-P022 directive was read afterward (SHA256
823d38d8c2bc5d30ffa31114ca736d457f64bcb0712202387caf27ff794b3d25).
The architecture evaluation/source research was completed before implementation;
EVALUATION_GATE.json pins that ordering. All four mandatory references were read
at exact commits, with source-path citations. No external code or GUI was copied.

DEV111-P023-EXP01 implements the recommended retained-native display direction,
checked RAM working set, atomic disposable quick-open descriptors, batched native
admission and actual Workbench/shared-component adoption. Existing Native2D,
Native3D, P017, Document, Units, GUI Host and authored Viewer owners are retained.
The scientific kernel, optimized native engine and public C ABI are unchanged.
Two existing native libraries have matching new sources/build receipts. Public
Tcl contracts and limitations are documented; no arbitrary SDK Tcl/file reader
was added. GX-TXT's UI and colorful Navigation Cube are preserved.

The result is **reviewable architectural evidence**, not a claim that production
CAD stabilization is finished. Read EXPERIMENT_RESULT_AND_DECISION.md for the
explicit remaining gaps and PERFORMANCE_REPORT.md for attributed costs. Initial
GUI opening and mass saved admission improve; a universal movement speedup and
elimination of every stall are not demonstrated. Existing overlays intentionally
preserve styles/accuracy where native bounded preview cannot do so.

VALIDATION_REPORT.md distinguishes actual input, API checks, source-identity
preservation, fixed failures and NOT VERIFIED cases. Independent consumer means
no private Workbench runtime; it does not mean an independent agent approved it.
The registered TEST CAD1/2 remain ordinary public Builder/Development C++ packages.
Full new Software and Hardware GUI paths were checked in the supported desktop.
The original user's remote GX-TXT process and scientific Sessions were untouched.

Review-only artifact destination:
`/srv/gxtxt/releases/dev111/experiments/0023-native-sketch-residency-exp01/DEV111-P023-EXP01.zip`
Exact final source commit, archive size/SHA, source/binary identity, full overlay
and guarded rollback proof are in FILES.json and the external VERIFICATION.json.
Matching archive/expanded experiment mirrors are maintained separately from
production patches. The helpers permit writes only in an explicitly marked
agents scratch review sandbox and perform no activation.

No TODO task has been removed. No production P023, next CAD phase, Scientific
Libraries work, installation or accepted merge has begun. The owner decides the
next step after reviewing this experiment and testing through VNC.
