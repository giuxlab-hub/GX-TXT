# Untruncated trace recovery

SPDX-License-Identifier: GPL-3.0-or-later

The original P022 scratch `cad-baseline01/objects50/DRAG.tsv` contains exactly
30,000 rows and25,629 scalar `Native2D::core world` calls. Its source is the P021
algorithm comparison, not the final deposited P022 implementation. Lost rows
cannot be recovered retrospectively from that capped file.

A fresh actual50-object GUI control drag/Undo repeated the same controlled
scientific fixture in the properly detached measurement variant4885fb8a. Its
only startup prerequisite and passive renderer-receipt instrumentation are
recorded by the P022 comparable-baseline manifest. The original Native2D library
and scalar projection implementation are retained. This is a bounded targeted
reproduction, not a claim to reconstruct the exact historical X11 event stream.

`profile-old-full02/objects50/DRAG_COUNTER.tcldict` counts all48,394 native command
entries, including42,319 scalar world conversions. Open counted18,645 entries,
including14,286 scalar world calls. The native adapter was loaded before tracing
so the trace could attach; this is not a cold-library load benchmark. There is
no30,000-row cap. First attempt lacked the still-unloaded command and failed in
the instrumentation before entering the GUI operation; evidence is preserved.

Exact legacy source paths in native2d_cad_projection_v1.tcl:

- nativePoints line66: one scalar conversion per input point.
- snapshot line137: one per sampled path point.
- segments line176: one per sampled segment hit primitive on every redraw.
- grid line189: one per grid endpoint.
- selected segment highlight line282: one per sampled selected segment point.

The stored caller stack confirms grid→Adapter.render→Host.render→scheduler dispatch.
The other paths were inspected directly at the same pinned source. Per-path
percentage attribution was not collected; do not infer percentages from the
single stored caller sample.

Exact deposited P022 `profile-cold02/objects50/DRAG_COUNTER.tcldict` instead counts
5147 native calls,1260 world_points batches and no scalar world calls. Its
committed edit and exact GUI Undo passed. Native sample quality and exact science
were not reduced. Counts depend on the accepted number of redraw callbacks and
are not FPS or a speedup ratio. Caller tracing overhead is separately measured in
counter-overhead01: count mode adds about2.315us per scalar native call in that
microbenchmark. The same20,000-call counter test has no truncation.
