# Measured architecture experiment performance

SPDX-License-Identifier: GPL-3.0-or-later

Review only. Same Debian13 / Linux6.12.101 server, local XFCE X11 :0,
GeForce GT610 / NVIDIA390.157, no test-only graphics overrides in the parent GUI.
This server GPU is not the owner's RTX3050 client. Software transport contracts
used an explicitly identified separate Mesa/llvmpipe child. OS page cache was
not flushed. Measurements are focused samples, not statistical guarantees.

## What the P022 trace actually meant

The old30,000-row trace was capped and came from a P021-algorithm variant, not
exact final P022. The complete recovered50-object drag for that variant recorded
48,394 Native2D calls /42,319 scalar `world` calls; exact P022 recorded5,147 calls,
1,260 batched `world_points` and zero scalar `world` calls. Do not attribute the
already accepted P022 batching gain to this experiment. See TRACE_RECOVERY.md.
The20,000-call instrumentation benchmark measured count-trace overhead separately
(~2.315us/call in its measured setup); totals are not truncated. Inclusive nested
spans must not be summed as disjoint CPU stages.

## Open/interaction in the complete framework

Actual GUI Open, exact defining-control mouse drag, release and GUI Undo were
used on1/10/50 fixtures (11 controls/object; representative splines). Script
open_ms includes GUI input/query/layout/worker delay; it is not isolated disk or
solver cost. Motion includes intentional input pauses and observation roundtrips.
Native factory spans and registry spans are separately retained in raw evidence.

| Scope | Exact P022 | EXP01 representative final-path run |
|---|---:|---:|
| First1-object scripted Open | 9074ms | 4107.58ms |
|10-object scripted Open | see raw P022 samples |739.54ms |
|50-object scripted Open |3805.67ms |861.90ms |
|Warm50-object scripted Open |3824.84ms | not a cold-OS comparison |
|Native factory1 /10 /50 |79 /87 /167ms | about63 /62 /144ms in profile-final01 |
|Registry calls per Open |4382 | about730–785 |
|Registry inclusive Open cost |about3500ms | about56–60ms |
|50-object measured drag total |see raw sample, input pacing applies |577.13ms |
|50-object post-release settle |see raw sample |318.61ms |

An earlier same-code experiment run measured50 Open767.84ms / post-release358.96ms;
variation and different readiness checks are retained, not cherry-picked away.
The resident path waits for an additional acknowledged native resource frame.
The data establish an opening/admission improvement, **not a universal object
movement or complete-redraw speedup**. Full mutation still derives a Sketch
preview and adds native rendering; its cost is explicitly retained.

Dominant proven Open bottleneck was O(N²) command-menu refresh/admission plus
repeated registry parsing. Scoped synchronous menu/state batching and a checked
registry working set remove redundant work without changing execution admission.
Cold icon preparation was then measured:23 Catalog processes1826.8ms,23 Import
processes1593.4ms, Photo preparation1936.3ms (nested/overlapping spans). One bounded
existing-owner batch reduced menu build from3501.1ms to990.6ms. Existing early
Canvas icon requests and native worker/frame startup still contribute to the
initial multi-second tail. Five representative icon assets at20/24 pixels were
byte-identical to the previous admission/raster path. No visual quality reduction.

## New-process saved-Sketch admission (not editor or GPU time)

Same100-Document synthetic fixture: one exact11-control polyline per Document,
three different valid planes, independent canonical identities. Old P022 display
reconstruction sampled up to129 points; new public Native2D LOD preserves actual
polyline corners. This is not reduction of canonical geometry or scientific data.

|Documents|P022 full saved display preparation|EXP metadata batch|EXP ready asset retrieval|per-Doc p50 /p95|
|---:|---:|---:|---:|---:|
|10|1171.635ms|95.001ms|10.824ms|1.083 /1.277ms|
|50|5389.854ms|112.212ms|51.702ms|1.007 /1.171ms|
|100|10765.071ms|163.159ms|112.927ms|1.098 /1.239ms|

These stages have different responsibilities: the new descriptor path consumes
already published disposable assets, whereas old preparation reconstructs them.
They do not include equivalent GPU rendering or full scientific edit admission.
Fresh process startup was425–440ms and ordinary public Session opening1014–1268ms,
reported separately. No scientific3D worker was started during descriptor-only
retrieval. Warm metadata batches were1.894 /6.879 /12.864ms. Read-process RSS was
about49–50MiB; this is whole-process RSS, not claimed incremental cache memory.

Creating all100 canonical Documents **and** publishing their derived descriptors
cost7061.690ms (per-Doc p5068.253ms, p9584.123ms). Index plus3 deduplicated assets
used155,104 bytes. It is a save/create-time tradeoff, not free work. Native display
admission was measured separately through an actual GUI Admit100 button:321.134ms
to all100 bindings ready in one completed native batch,1,100 points,100 actors.
The fixture intentionally overlaps three repeated placements; it is a bounded
resource/admission stress case, not100 visually distinct complex assemblies.

## Residency and remaining costs

Native unchanged-revision update:4us in the supplemental software contract,
without geometry reparse; actor removal25us. One actor's first frame98.729ms
includes software rendering/PNG, not just map insertion. Three-plane real GUI
initial native admission37.907ms at33 points in the earlier qualified consumer.
The resident resource receipt counts updates/reuses/replays; camera changes do
not advance that geometry revision or reconstruct scientific objects/constraints.

Camera-only editing still performs grid, controls, segments, marker projection
and bounded overlay sampling where required. The recorded counter includes
explicit test model assertions, whose capture calls must not be misattributed
to camera rebuild. It records no `sketch_create`/constraint hydration in that
camera sequence. Generic overlay/hit-data optimization remains future work.

Molecular navigation is a separate pipeline: P022's measured GPU/PNG/worker/Tk
results are preserved; this experiment does not modify or claim a new molecular
rotation gain. It retains the optimized native engine binary exactly. Initial
icon/layout cost, History capture, whole-Sketch derived mutation work, software
render tails and the known large-History Save cost remain limitations. No claim
is made that every previously observed3–4s stall has been eliminated.

Native admission/readiness is not an end-to-end painted-pixel timing. The final
edge check observed stale overlay pixels in an early1-second screenshot despite
a clean native PNG and invalid projection; a later settled screenshot was correct.
Exact paint-settlement latency was not measured. This remains an explicit review
limitation and prevents a claim of universally bounded visual feedback.
