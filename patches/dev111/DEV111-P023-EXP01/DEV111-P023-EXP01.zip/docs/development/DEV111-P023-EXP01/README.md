# DEV111-P023-EXP01 — isolated architectural review

SPDX-License-Identifier: GPL-3.0-or-later

**NOT FOR INSTALLATION. NOT ACCEPTED. NOT PRODUCTION P023.**

Base: exact deposited DEV111-P022 source c92f9f90caa1d4196fd23023873171c9d9094c6a,
ZIP SHA256450d59e503b8e5c49551e97233fa0a3bcf778b13679290b05ce260930b72bc66.
Apply sequence for a disposable review copy only: cumulative P022 → EXP01.
P022 and all historical releases remain unchanged. Nothing is activated.

Read NATIVE3D_SKETCH_ARCHITECTURE_EVALUATION.md first, then
EXPERIMENT_RESULT_AND_DECISION.md, PERFORMANCE_REPORT.md, VALIDATION_REPORT.md,
and docs/api/NATIVE_CAD_SKETCH_RESIDENCY_EXP01.md. FILES.json in the archive's
patch_notes/DEV111-P023-EXP01 contains exact source commit, product pre/postimage
SHA256s, modes and protected authority pins. Matching Linux x86-64 NativeDocument
and Native3D Tcl bridge binaries and their complete sources/build records are
included. Native3D engine, Native2D kernel and P017 History are not rebuilt.

## Guarded sandbox application and rollback

Close applications using the **review copy**. Create a separate copy of the exact
P022 framework under /srv/gxtxt/agents/scratch, excluding its .git pointer.
Never copy a linked-worktree .git file into another development tree.
Manually create `.gxtxt-experiment-review-sandbox` in that copy containing exactly
`DEV111-P023-EXP01`. This marker is not included in product payloads.

Using helpers extracted to a temporary scratch folder from the archive's notes:

```
python3 -B apply.py /srv/gxtxt/agents/scratch/YOUR_REVIEW_COPY DEV111-P023-EXP01.zip
python3 -B apply.py /srv/gxtxt/agents/scratch/YOUR_REVIEW_COPY DEV111-P023-EXP01.zip --apply
python3 -B rollback.py /srv/gxtxt/agents/scratch/YOUR_REVIEW_COPY --check
python3 -B rollback.py /srv/gxtxt/agents/scratch/YOUR_REVIEW_COPY
```

First command only checks; the second changes the explicitly marked scratch copy.
The helpers refuse divergent preimages/postimages and non-scratch installation
paths. Rollback restores exact P022 bytes/modes and removes added product files;
review notes/backups are retained. Sessions/preferences/caches are never rolled
back, deleted or relocated. The package's full tracked-tree application/rollback
proof and fresh public startup result are supplied beside the ZIP.

Launch only with isolated HOME/XDG, Session, resource, job and cache paths. The
cataloged launch/fixture helpers demonstrate this without changing GL settings
in the parent GUI. Reuse no original user Session for destructive review tests.

## Suggested bounded owner review

Use the included independent resident_consumer.tcl through its launcher: inspect
three planes, pick/Open picked, move a defining control, Undo/Redo, Save, Close,
reopen, native occlusion against the mesh, edge-on recovery and styled fallback.
Then use the ordinary 3D CAD Workbench on a synthetic1/10/50 fixture. Inspect the
saved native body after close and retain the colorful Navigation Cube. The mass
consumer admits100 synthetic Documents through the same public binding.

No next patch or production promotion is authorized by running these helpers.
Stop for owner review. P022 and this experiment remain uninstalled/unaccepted.
