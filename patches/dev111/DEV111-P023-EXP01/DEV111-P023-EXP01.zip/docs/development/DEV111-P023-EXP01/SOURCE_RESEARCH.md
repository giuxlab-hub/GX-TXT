# Comparative source research — no third-party implementation imported

SPDX-License-Identifier: GPL-3.0-or-later

Read-only official repositories, pinned before inspection. Full downloaded source
and per-file hashes remain in private research01, outside the deliverable. Remote
AGENTS files were treated as architecture descriptions, not GX-TXT instructions.
This study concerns responsibility boundaries; no code, artwork, GUI design,
solver or kernel from these projects is copied or linked into GX-TXT.

| Project / pinned revision | Source inspected | Supported lesson and limitation |
|---|---|---|
|FreeCAD19fe63614aaa5f3303349e70826256e3a610b8e6|Sketcher/App/SketchObject.h/.cpp; Sketcher/Gui/ViewProviderSketch.h/.cpp; Gui/ViewProvider.h, Gui/Document.cpp|Geometry/constraints belong to an application Document object. ViewProvider maintains Coin representation/picking; updateData reacts to shape/property changes. setEdit backs up the object, validates constraints and installs editing managers; unsetEdit clears edit managers and restores visibility/selection without deleting the Sketch. Placement is explicit. This does not establish GX-TXT needs Coin3D or FreeCAD's transaction model.|
|SolveSpace30e1c3ac0beb77fe3e098315b1bb662840ddc99a|src/group.cpp, sketch.h, request.cpp, graphicswin.cpp, draw.cpp, drawentity.cpp, system.cpp|DRAWING_WORKPLANE and DRAWING_3D are distinct group types. Entities/requests carry a workplane identity; group generation establishes origin/normal/quaternion. Camera scale/right/up remain view state. DrawPersistent separates cached entities from view-dependent drawing; Invalidate optionally marks persistent geometry dirty. Some view-dependent sampling remains; not a blanket zero-work-on-camera claim. Existing GX-TXT math/solver must stay.|
|OCCT53706f78a8640c4407bdcc6752df13a270b159f2|AIS_InteractiveObject, AIS_InteractiveContext, PrsMgr_PresentableObject, SelectMgr_SelectableObject source/headers|Application-specific owner identity connects selectable scene objects to geometry. Presentation recompute and ComputeSelection are distinct; selection modes/owners represent whole objects or parts. Redisplay marks recompute and updates selection through the manager. Highlighting has its own immediate presentation. Adopt the distinction and revision-bound ownership, not AIS itself or another renderer dependency.|
|SolidCraft0870d6474a87a2cc03707080f848cfd81017f943|engine/src/lib.rs/cmd/sketch_drag.rs and live tests; doc/document.rs/frame.rs/feature_refs.rs/model_cache.rs; sketch/model.rs; ui-egui/viewport.rs/sketch_display.rs/navigation.rs/gpu.rs/open_meshing.rs; render/scene.rs/camera.rs|Stable string point/curve IDs and feature/plane/occurrence references differ from display samples. Session keeps Document/model/selection/revision and routes commands; live edits can refresh a Sketch while downstream features remain stale, with full-refresh fallback. Display has separate bounds/mesh/picking caches and view-dependent sampling. GPU meshing has capability/safe-mode paths; offscreen captures have CPU fallback. These are code/test-supported mechanisms, not proof of maturity, feature parity or performance on GX-TXT's hardware.|

## Pinned primary references

- [FreeCAD SketchObject](https://github.com/FreeCAD/FreeCAD/blob/19fe63614aaa5f3303349e70826256e3a610b8e6/src/Mod/Sketcher/App/SketchObject.h),
  [ViewProviderSketch](https://github.com/FreeCAD/FreeCAD/blob/19fe63614aaa5f3303349e70826256e3a610b8e6/src/Mod/Sketcher/Gui/ViewProviderSketch.cpp),
  [GUI Document](https://github.com/FreeCAD/FreeCAD/blob/19fe63614aaa5f3303349e70826256e3a610b8e6/src/Gui/Document.cpp).
- [SolveSpace workplane groups](https://github.com/solvespace/solvespace/blob/30e1c3ac0beb77fe3e098315b1bb662840ddc99a/src/group.cpp),
  [persistent drawing](https://github.com/solvespace/solvespace/blob/30e1c3ac0beb77fe3e098315b1bb662840ddc99a/src/draw.cpp).
- [OCCT interactive object](https://github.com/Open-Cascade-SAS/OCCT/blob/53706f78a8640c4407bdcc6752df13a270b159f2/src/Visualization/TKV3d/AIS/AIS_InteractiveObject.hxx),
  [interactive context](https://github.com/Open-Cascade-SAS/OCCT/blob/53706f78a8640c4407bdcc6752df13a270b159f2/src/Visualization/TKV3d/AIS/AIS_InteractiveContext.cxx),
  [selection contract](https://github.com/Open-Cascade-SAS/OCCT/blob/53706f78a8640c4407bdcc6752df13a270b159f2/src/Visualization/TKV3d/SelectMgr/SelectMgr_SelectableObject.hxx).
- [SolidCraft command/Session owner](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/engine/src/lib.rs),
  [scientific Sketch identities](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/sketch/src/model.rs),
  [Document placement/references](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/doc/src/document.rs),
  [live-drag tests](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/engine/src/cmd/sketch_drag_live_tests.rs),
  [viewport cache keys](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/ui-egui/src/viewport.rs),
  [display sampling](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/ui-egui/src/sketch_display.rs),
  [GPU/fallback](https://github.com/tangency-labs/solidcraft/blob/0870d6474a87a2cc03707080f848cfd81017f943/crates/ui-egui/src/gpu.rs).

## SolidCraft applicability details

Session::execute selects a single registry entry, validates enablement, captures
rollback state and distinguishes live, render-only, display-only and ordinary
refresh paths. refresh_live uses show_live_sketch and can fall back to a full
refresh; it is incorrect to claim that all interactive operations defer all
model work until commit. The live-drag tests compare evaluation counts and
solved geometry, including determined-geometry rejection. They are source
assertions, not tests executed by GX-TXT here.

The Sketch display sampler derives curves from exact segments, with finite
vertex/node budgets and an explicit quality result. viewport::scene_key includes
revision and world-state identity; sketch_scene_key also includes the projection.
Therefore retained model identity does not mean every display primitive is
camera-independent. SceneLine::on_top explicitly controls an editing depth
policy. GX-TXT's experiment will instead keep base Sketch curves in its existing
Native3D depth buffer and retain only editing chrome/preview as an overlay.

Model references include explicit face/plane attachment and occurrence paths;
new certified face references report lost sources rather than silently guessing
another face. This supports GX-TXT's existing provenance/stale-reference guards.
It is not authorization to migrate its units (millimetres/radians conventions),
solver, Rust stack, UI, or component model into GX-TXT. No commercial CAD was
scripted or inspected for hidden implementation details.
