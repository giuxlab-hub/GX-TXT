# Native Sketch residency experiment — result and review decision

SPDX-License-Identifier: GPL-3.0-or-later

**DEV111-P023-EXP01: EXPERIMENTAL, NOT FOR INSTALLATION, NOT ACCEPTED.**
P022 was deposited first and remains immutable and uninstalled. Its user VNC
acceptance remains OPEN. This is a separately authorized cumulative experiment,
not production P023, a merged branch, or authority to begin another CAD cycle.

## Evaluation gate and implemented direction

The evaluation was committed as edc68aa5d11f25f7d9dbbf658d1ae13bb3d0a040 before
any product implementation. Its report and source-pinned comparison of FreeCAD,
SolveSpace, OCCT AIS and SolidCraft are preserved. No third-party implementation,
artwork, dependency, solver, GUI layout or scientific kernel was imported.

The recommendation was B: retain derived selectable curves in the existing
Native3D scene while keeping Native2D/P017/Interactive Document authoritative.
It is now implemented in the existing Tcl/native transport and existing C ABI.
A binding owns disposable native actors, not a scientific model. Native picking
resolves a closed preview to its Session/Document/owner/revision. Exact editing
opens that same Document, checks its source and attaches the existing controller.
Multiple scientific planes share one viewport and one batched display lease.
Camera navigation consumes retained actors; there is no camera-time second
scientific scene or controller. Native depth is genuine, as shown against the
ordinary nonplanar RAM mesh in the independent consumer.

The existing same-Canvas editor supplies grid, handles, annotations, arrows,
snapping, highlights and proposals. Invalid ray domains suspend editing without
deleting science. A confirmed native frame is required before removing the
matching editing overlay. Strokes or magnifications not faithfully supported by
the protected native style/preview contract use the existing editing overlay.
This is an explicit fidelity/depth tradeoff, not missing geometry hidden to make
measurements faster.

## RAM-first and cold admission

A bounded verified-byte cache and separately bounded parsed-registry cache reuse
the existing Document owner. Explicit Read still hashes every time. Warm cached
Read checks full no-follow file identity, including nanosecond ctime; cold Read
verifies actual captured bytes. Session/generation/revision/SHA remain distinct.
No raw solver IDs, active History writers or unscoped native handles are cached.
Editors still hydrate a transient validated Native2D scene lazily. This avoids
unsafe retention of solver/History state and is not a claim of zero hydration.

A disposable atomic quick-open descriptor/index carries plane, units, bounds,
counts, source identity, quality and asset hashes. It is generated after canonical
creation/save, not a second source of truth. New-process listing and native scene
admission need not hydrate every exact editor or replay History. Missing/stale/
corrupt index data rebuilds from verified science; cache failure cannot invalidate
an accepted canonical save. Capacity, publisher locking, interrupted publication,
eviction and recovery are documented and tested.

## Evidence and decision

See PERFORMANCE_REPORT.md, VALIDATION_REPORT.md, API documentation and the
source-attributed evidence inventory. Gains are principally menu/state batching,
checked registry reuse and fast derived admission. Whole construction/open time
is not falsely attributed to native geometry alone. Native curve residency adds
useful depth/picking semantics; it does not by itself establish a universal drag
speedup. The final 50-object motion remains a meaningful cost.

The experiment is suitable for **owner architectural review**, with the limits
below. It is not production acceptance or an invitation to install/promote it.
Review the native depth versus editing-overlay policy, same-Document behavior,
cache failure semantics and measured first-open tail before deciding a next step.

## Explicit remaining gaps

- Accepted edits still derive a bounded whole-Sketch preview using a temporary
  Native2D scene; per-object incremental native tessellation is not implemented.
- Camera-only editing still computes grid, controls, semantic segment hit data
  and sometimes overlay LOD. It does not rebuild Native2D objects/constraints or
  resubmit the resident scientific display collection on each camera frame.
- Unsupported dash/marker styles and extreme active magnification deliberately
  fall back to the existing faithful overlay, whose depth is always on top.
  Closed previews retain the previous solid-style fallback and bounded LOD.
- Closed previews do not add exact defining-control/constituent identities or
  complete independent arrow/annotation rendering. Picking returns a Document
  and display part, never a fabricated exact control/row identity.
- Explicit renderer/device rebind is required after failure. Automatic recovery
  of an unsaved live solver/History context across device restart is not supplied
  or claimed. Base-scene reset replay is a different, tested operation.
- New low-level multi-Sketch bindings are public trusted Tcl CORE facilities.
  Existing authored C++ Viewers benefit through their shared Sketch component;
  a new arbitrary Tcl evaluation or multi-document SDK bridge was not admitted.
- Edge-on scientific suspension/recovery is correct, but early Canvas captures
  can lag a clean native frame and corrected item state; only the later settled
  pixels were qualified. Immediate paint synchronization remains unqualified.
- The initial full GUI still has seconds of icon/layout/renderer startup work;
  this experiment does not prove all reported stalls eliminated.
- Linux x86-64 was tested. Other platforms, another GPU family, real remote X11
  and independent MAIN2 approval of this experiment are NOT VERIFIED.
- P017 large explicit Save (~6.2 s previously reported) and broad bootstrap costs
  are unchanged. No persistence architecture or scientific library work began.

Installation status: **NOT INSTALLED**. Owner review and VNC acceptance: **OPEN**.
