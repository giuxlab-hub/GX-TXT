# Native3D Sketch architecture evaluation

SPDX-License-Identifier: GPL-3.0-or-later

Status: evaluation before experimental product implementation. This document is
completed and checkpointed before the first CORE/Viewer implementation change.
The experiment is not an accepted P023 or a production promotion.

## Exact evaluated baseline

Deposited P022 source c92f9f90caa1d4196fd23023873171c9d9094c6a; ZIP
450d59e503b8e5c49551e97233fa0a3bcf778b13679290b05ce260930b72bc66,
12,793,622 bytes. P022 application,103-entry public API startup and complete-copy
rollback proof passed before this directive was read. Its source/release remains
immutable. The owner directive was read in full, sections1–9, SHA256
823d38d8c2bc5d30ffa31114ca736d457f64bcb0712202387caf27ff794b3d25.

Local Debian13/XFCE/X11 :0, GeForce GT610/NVIDIA390.157 and Mesa25.0.7 llvmpipe.
No OS/driver changes. Exact P022 binaries include gx2dtcl.so
961590a927e1064d694eb84be8d43cb1be799c3e04ceb4707871e46db8ac9ae0 and
libgx3de_viewer_tcl.so
27e12c56eea9ae42bd0465e05e34641bec7e07849a75a9f3e7a7716184532d91.
Protected engine libgx3de.so remains
ea25f6ec5cd885ff517a2301f56712840edb188cb1210ad4a94fb337b9282100.
The existing Native2D scientific kernel, Native3D C ABI/algorithms, P017 History,
P018 Host, P019 tools, Builder/Development and diagnostics remain authorities.

## Observed lifecycle and ownership

| Stage | Actual P022 implementation | Authority / derived state |
|---|---|---|
|Pointer/key admission|native3d_cad_surface_v1.tcl Surface.pointer/key, actual renderer Canvas bindtags|Transient input ownership; Navigation Cube/Space navigation precede CAD dispatch.|
|Camera and native picking|native3d_gui_host_v1/v2; renderer_worker.tcl; gx3de_viewport_pick and existing camera APIs|Native3D controls camera, scene depth/picking and rendering. PNG/PhotoImage are transport/display.|
|Screen/ray/plane conversion|P021 native projection snapshot, Native3DSurface.frame, Component.projectionChanged, Native2DCadProjection.Adapter|Native3D-derived frame/revision; bounded native mapper performs ray/plane conversion in RAM, no worker RPC per pointer.|
|Selection/manipulation/construction|native2d_cad_canvas_v1.tcl Host; shared advanced tools and C++ CAD controller|Native2D scientific references/constraints/gesture transactions, not Tcl sampled rendering points.|
|Preview/commit/cancel|Host/advanced begin/proposal/commit/cancel; Component callbacks, capture/restore|Exact Native2D definitions; staged feedback is separate. Rejected/cancelled proposals do not create scientific History.|
|History/persistence|Component.begin/committed/project; scientificHistoryViewerSubmitPatch/Flush; Interactive Document|P017 accepted/pending/durable History and the single authoritative saved Document. Native2D remains active scientific state while editing.|
|Active presentation|Native2DCadProjection.render/snapshot/segments/controls; retained Cairo sprite scene|Camera-dependent derived paths, selection hit primitives, controls, grid/axes/dimensions. All base curves are currently drawn in an always-on-top overlay.|
|Closed presentation|nativeCadSketchDocumentPresentation; Workbench.sketchPresentSaved; native3DGuiHostDocumentPresentationSet; Engine3D.preparedScene|Read-only derived memory_geometry layers; native depth. Exact model stays in Document, not the sampled polyline.|
|Reopen|nativeCadSketchCreate constructor reads Document, allocates new Native2D scene/3D scope, restore hydrates validation and active scenes, attaches new History context|Fresh editing resource lifetime with same Document/generation/revision. No current retained solver-scene working set.|

Component capture projects logical IDs to current native IDs and records retained
geometry, styles/direction and relationship references; sampled points never
become defining controls. restore appends/validates replacement geometry before
removing old objects, preserving monotonic raw IDs and rollback safety. It is not
safe to skip that validation merely to improve a benchmark.

The two GUI hosts differ. Legacy Engine3D uses guarded synchronous worker RPC
with event-loop waits and a camera queue. V2 uses fileevents/generation-checked
requests. Both use the same native bridge/engine. native3DGeometryCall has an
active organization wrapper that tailcalls native3DGeometryCall_organization_base;
profiling only the wrapper excludes the actual base work. Scene/source and worker
generations are distinct ownership boundaries and must remain distinct.

P022's current active presentation_scene intentionally returns no complete
mirrored 3D curve scene. Closing explicitly prepares native depth-tested saved
layers; reopening removes them and recreates the Cairo base curve overlay. This
solves disappearance, but the Sketch is not yet one consistently selectable,
scene-resident entity across edit-mode transitions. Changing camera invalidates
projected samples/references; it does not change scientific coordinates.

## Measurements and the truncated trace

The owner-cited30,000-row trace is
P022 scratch/cad-baseline01/objects50/DRAG.tsv:25,629 scalar `world` calls within
the captured subset. Source identity shows this is the older P021-algorithm
comparison trace produced during P022 development, not the final P022 runtime.
The cap does not establish its complete call count. The new counter keeps an
untruncated total/histogram, at most512 operation keys and one caller sample per
operation; it does not allocate one row per conversion.

Exact final P022 real-GUI cold profiles use1/10/50 objects, actual control drag and
GUI Undo. Native calls during Open:158/795/3324; during drag285/1366/5147.
The50-object drag has1260 `world_points` batches and zero scalar `world` calls.
The earlier lightweight P022 trace's zero scalar count meant untraced; the new
full counter actually observes all operations. Geometry/Undo assertions pass.
A supplemental uncapped replay of the old algorithm is recorded separately in
TRACE_RECOVERY.md; it is diagnostic, not the P022 latency benchmark.

Three20,000-call microbenchmark samples per mode measured median0.61045us per
untraced scalar call versus2.9254us with the enter counter: approximately2.315us
extra per call. Span-only mode does not trace scalar calls and measured0.61815us.
Thus counters are bounded, not free. Do not subtract these microbenchmarks as an
exact universal correction or compare per-call-traced versus untraced GUI totals.

| Objects | Cold measured factory ms | Cold registry reads / inclusive ms | Warm factory ms | Warm registry inclusive ms |
|---|---:|---:|---:|---:|
|1|78.986|4382 /3490.846|103.539|3538.638|
|10|86.846|4382 /3478.330|129.015|3571.654|
|50|166.874|4382 /3515.083|184.078|3514.834|

These factory spans are not complete first-photon times. Actual scripted50-object
Open was3805.67ms cold and3824.84ms warm, including input, layout/action refresh
and observation overhead. First1-object Open was9074ms under colder GUI/setup
conditions. The factory already followed Workbench worker startup; its small RPC
spans are not a claim that a new process/GPU initializes in a few milliseconds.
Nine file-SHA calls in each Open phase consumed approximately19ms combined;
History attach was2.6..5.4ms cold and26..47ms in these warm History-bearing scenes.
Native2D presentation sampling totals were7.8ms for50 cold objects. Renderer,
layout and first-edit-ready milestones must remain separate in prototype reports.

A bounded caller diagnostic observed4908 registry calls across an actual
Close/Open/edit/Undo sequence. Dominant paths include1467 via Component.guard→
_native2DCadActionStatesCollect→ActionPredicate→viewerCommandEnabled;940 from menu
refresh through the same predicate,820 direct guard calls from MenuTrack/MenuAdd,
and440 through checked-widget state. The64-group histogram has an `other` bucket;
its total is not truncated. Source confirms an O(N²) construction pattern:
viewerCommandMenuTrack refreshes every previously registered entry on each add.
The existing synchronous action-state scope covers later refresh, not menu
creation. MenusRefresh also updates toolbars/widgets, while its CAD caller repeats
those calls. Batch registration and scoped presentation state are justified;
scientific invocation guards must still run at actual invocation.

Independent public API mass fixture:100 saved exact Sketches on three planes,
one11-control retained polyline each. Full saved-display reconstruction for
10/50/100 took1171.635/5389.854/10765.071ms; medians107.722/107.594/107.4665ms per
Document. Public metadata listing of all100 took11.299..11.428ms. Source models
remained exact. This is API preparation, not a real-GUI admission benchmark.
It demonstrates a real quick-open gap, not that an index already exists.

Molecular navigation is independent. P022's matched Hardware burst applied12/12
accepted operations,343.43ms observed gesture; Software11/11,283.26ms. Native
render/framebuffer medians34.11/20.72ms; PNG5.03/4.96ms; PhotoImage approximately
12ms with a39ms outlier. Other output-tail spans reached418/449ms. No Sketch
cache can fix those native/image costs. Native3D itself must not be rewritten
because of menu/Document or PNG preparation costs.

## Grounded comparison with established designs

Exact pinned source paths and links are detailed in SOURCE_RESEARCH.md.

| Reference | Scientific identity / edit state | Plane/placement | Rendered representation, occlusion/picking | Invalidation and applicable GX-TXT boundary |
|---|---|---|---|---|
|FreeCAD Sketcher|Application SketchObject stores Geometry/Constraints; GUI Document maps objects to ViewProviders; edit managers/backups are transient|Explicit global/edit placement and attachment|Coin view provider retains scene nodes and selection naming; edit cleanup does not delete application Sketch|Property/solver updates feed presentation; copy the ownership separation, not Coin, UI or transaction code.|
|SolveSpace|Requests/entities/groups have handles and workplane references; DRAWING_WORKPLANE differs from DRAWING_3D|Origin/normal/orientation are model context, camera right/up/scale are view state|Persistent and view-dependent drawing paths are distinct; entity picking is geometry-aware|Invalidate can retain persistent drawing. Learn source-vs-view invalidation; keep GX-TXT's own C solver.|
|OCCT AIS|Application owner distinct from interactive entity and sub-element owner|Object transformation/presentation managed independently of scientific application data|Compute and ComputeSelection are separate; selection modes, depth and highlight ownership explicit|Redisplay/selection recompute are modification-driven; adopt contracts, not another kernel or renderer.|
|SolidCraft|Stable point/curve IDs; Document/feature IDs, Session/model/revision, active_sketch, rollback/undo; single command registry|Plane and certified face references, component occurrence transforms|Retained mesh/bounds/pick caches; display-only adaptive sampling; explicit on_top policy; GPU capability and CPU fallback|Live Sketch update may defer downstream evaluation, but can fall back to full refresh. Projection-dependent sketch_scene_key means not all camera work disappears. Do not transplant Rust, solver, fixed unit conventions or its GUI.|

GX-TXT already supplies exact planar science, constraints, opaque native refs,
plane transforms, camera snapshots, geometry/polydata creation, depth/picking,
retained camera commands, History, scientific Documents, resource accounting,
reusable CAD actions, icons and controllers. Proven gaps are coherent resident
Sketch binding/selection/lifecycle across both hosts, incremental native display
resource update, quick-open descriptors, guarded bounded verified working set,
and efficient menu construction. These are integration/resource contracts;
they do not justify a new geometry engine, selection algorithm, History store,
visual theme, Navigation Cube or commercial-style UI.

## Alternatives and recommendation

| Criterion | A: current projected overlay + closed snapshots | B: resident native Sketch + transient editing chrome | C: deeper native 3D editing/picking integration |
|---|---|---|---|
|Scientific authority|Already correct in Native2D/Document/History|Same owners; native scene holds only derived display|Must remain same, but greater cross-controller coupling|
|Depth|Active base curves always on top; closed curves native-depth|Base curves native-depth both open/closed; handles/labels/proposal use explicit overlay policy|Potentially unified per-element depth, much larger work|
|Selection|Exact active Native2D refs; closed saved layer lacks coherent public Sketch identity|Native object pick resolves revision-bound Sketch/constituent identity; exact sub-control editing stays Native2D|Could unify deep picking, but risks duplicate selection science|
|Camera|Rebuilds camera-dependent samples/chrome|Camera renders retained native base; only transient screen-space chrome remaps|Potential further gains require invasive scope|
|Persistence / multiple planes|Canonical owners correct; lifecycle-specific display swap|Same Documents, distinct scene bindings/plane/unit scopes; no merged scientific ownership|More feature/reference state to validate|
|Performance|Measured overlay and metadata churn; no new risk|Removes repeated base reconstruction and O(N²) menu churn; preview index/RAM separate from GPU state|Unproven benefits relative to complexity and protected-engine risk|
|Compatibility|Lowest change, insufficient semantic target|Additive public contracts and transport commands; legacy methods retained|Likely broader ABI/controller evolution|
|Migration risk|Low but does not meet requested end state|Moderate, bounded at adapters/resource lifetimes; independent GUI proof required|High; reject for this experiment|

Recommend **B**, with narrowly scoped reuse of existing Native3D public geometry
and picking. Its benefit is semantic consistency and fewer redundant preparations,
not an assumed renderer speedup. Fix measured menu-construction multiplication
alongside it; merely moving curves does not resolve3.5 seconds of registry work.
Reject A as the target because active scientific curves remain an unrelated
always-on-top picture and closed Sketch identity is not fully reusable. Reject C
for this experiment because GX-TXT already has the exact planar controller and
mature3D renderer/picker; deeper engine changes are not demonstrated necessary.
No protected Native3D algorithm/ABI change is authorized or planned.

## Public contract and retained resources

Extend the current Native2D Sketch/Native3D surface families, not a second Canvas.
A consumer binds a saved Sketch Document to an existing native viewport, chooses
visibility and an edit-request callback, inspects bounded binding status, selects
it, and releases the binding. It owns placement of ordinary menus/toolbars and
resource frames. The public result carries Document ID, owner/generation,
persisted revision/content SHA, source unit/plane and presentation generation;
no raw native pointer, private Canvas path or mutable sampled geometry is a
third-party scientific contract.

Native derived objects live in the existing renderer scene/State ownership.
Additive upsert/remove/status operations use existing polydata/plane APIs.
Camera/pan/zoom operate on retained native objects and never resubmit full exact
Sketch definitions. Base-source replacement or worker restart rebuilds renderer
resources from already validated bounded descriptors; it does not invent a new
scientific registry. Geometry changes invalidate only the matching binding.
Preview/accepted in-memory History revision is distinct from persisted Document
revision; invalidation must include both while editing. Save/commit publication
updates the durable descriptor only after the authoritative owner succeeds.

Closed native picks may identify the Sketch/constituent at its bound revision.
Entering edit revalidates the exact Document and uses current Native2D semantic
references. A sampled polyline cell is never silently promoted to an exact
segment/control or Dataset row. Existing native picking/depth is reused.
Selection feedback and dimension/control overlays remain transient. The grid is
an editing guide with an explicit depth policy; do not change snapping or invent
another grid algorithm to move it. Any prototype limitation in guide/annotation
depth must be disclosed separately from native base-curve occlusion.

Camera-only frames must not cause Document reads/hashes, native hydration or
whole scientific capture. Scope events and Session/source/worker generations
invalidate resources; actual scientific edit admission/commit remains strict.
Edge/horizon/behind rays suspend only inadmissible pointer editing and preserve
staged state, while camera controls remain unrestricted. P022's successful
safety gate and its colorful Navigation Cube remain unchanged in appearance.

## RAM working set and safe quick-open descriptors

The current constructor rebuilds both validation and active scenes. The measured
factory cost does not justify retaining raw solver scenes and History writers
across destroyed GUI owners as the first optimization. Start with a bounded
verified payload/model working set and independent derived native display;
lazily hydrate an editor through the existing validated restore route. Never
cache unscoped raw IDs or attach a second active History writer.

The existing CORE NativeDocument source_capture.cpp already implements bounded
no-follow ancestry walks, descriptor/name checks and nanosecond identities. Reuse
that owner for additive checked file identity/verified snapshot caching rather
than introducing another Document engine. Preserve its existing4MiB source-capture
contract. An additional cache path may use its own documented bounded budget.
A native cached load must compare owner/session/generation/revision/expected SHA
and full file identity (device/inode/size/mode/owner/link count/mtime_ns/ctime_ns).
Cold reads verify actual captured bytes against the authoritative SHA. Same-size
external writes with restored mtime must invalidate via ctime; replacement and
ancestry changes must not reuse stale bytes. Explicit interactiveDocumentRead
continues hashing on every call. No seconds-only Tcl mtime shortcut.

Cache policy should be process-local byte/object-bounded LRU, initially8MiB,
with inspectable hits/misses/evictions and explicit disposal. A payload too large
for retention is not a reason to weaken integrity. Session transitions, deletion,
owner change, revision change and failed reads invalidate matching entries.
Native GPU resource generations are separate; device restart does not make stale
science valid. Positive and negative tests are mandatory before claiming benefit.

Every saved Sketch needs a **new**, non-authoritative Quick-Open Descriptor:
source Document/owner/generation/revision/content SHA/schema; normalized plane,
working unit, local/world bounds, object/constituent/constraint counts; bounded
preview asset identity/hash/format/budget and source file identity. Do not embed
a second exact model or History in the index. Existing Document registry metadata
can supply the batch authoritative identity list, supplemented by these derived
records through public CORE cache/resource owners. No Viewer-defined filesystem
layout or parallel authoritative database.

After create/save establishes authority, atomically publish or invalidate the
matching derived descriptor/preview. Partial cache publication must never report
a failed scientific Save as rolled back when it actually committed. Missing,
stale or corrupt cache falls back to authoritative verification/rebuild; it must
not erase the Document. Preview is not admission for a new exact edit. Multiple
planes/units remain distinct and every rendered binding retains source identity.
Metadata listing/scene admission must be batched, not one worker/Document parse
per Sketch. Camera uses resident derived primitives. Subsequent edit verifies
source and attaches real native geometry/History lazily.

Prototype tests must cover revisions, interrupted publication, external content
corruption/replacement, stale Session/owner, Undo/Redo/restore, concurrent binding
requests, worker/device restart, schema mismatch, eviction, memory/disk budgets,
100-Sketch cold listing/admission and positive warm reopen. Report p50/p95 and
actual source-attributed calls; do not equate a cache entry with a speedup.

## Implementation gate and decision boundary

The evaluation and pinned source comparison precede product code. Experimental
work follows on a separate branch/worktree based on exact P022, not an accepted
line. Required proof: one active and multiple closed differently oriented
Sketches, ordinary nonplanar mesh depth/picking, camera travel in both projections,
actual1/10/50 GUI editing/Undo/Redo/Save/reopen/cancel, unchanged scientific source,
public independent consumer, bounded cache/index negative tests and comparable
performance. Source/binary/manifest/apply/rollback evidence must match.

No installed framework, user Session, historical release or TODO changes. No
external code/artwork imported. No automatic production P023 or Native3D rewrite.
Record regressions and incomplete capabilities in EXPERIMENT_RESULT_AND_DECISION.md.
Stop after the isolated experimental handoff for owner review; internal success
is not user acceptance.
