# Focused GUI, integrity and lifecycle validation

SPDX-License-Identifier: GPL-3.0-or-later

**EXPERIMENTAL REVIEW ONLY. Internal PASS is not owner acceptance.**
Linux Tk on the actual Debian XFCE X11 desktop (:0), same server as P022.
Inputs are actual xdotool mouse/keyboard events against PID-verified owned GUIs.
Public/API observations assert science; they do not substitute for interaction.
Screenshots were visually inspected. No original user Session was used.
No independent MAIN2 approval of this experiment is claimed.

## Qualified workflows

|Case|Result|Evidence / actual scope|
|---|---|---|
|Normal application1/10/50 editable fixtures|PASS|profile-final03: actual Open, defining-control mouse edit, release, exact GUI Undo; retained models and History receipts.|
|50-object Redo and active Escape|PASS|normal-lifecycle04: Host active1 and native mutation preview before Escape; exact model and History preserved.|
|Normal Save / Close / same-Document Reopen|PASS|normal-lifecycle04, closed image02 inspected: all50 saved native curves remain visible; exact restored definition.|
|Normal real construction / Finish / Undo|PASS|normal-lifecycle04: two accepted mouse points create an exact line, Finish exits tool; Undo restores prior exact model.|
|Three resident differently oriented Documents|PASS|consumer-scenarios08 and consumer-final01: one active editor plus closed native curves against ordinary RAM mesh; no Workbench private procedures loaded.|
|Closed native picking / same-Document Open|PASS|Actual native Canvas click, typed Document receipt, Open picked; no sampled cell claimed as defining-control identity.|
|Native depth and editing chrome|PASS|Inspected closed-native-depth and edited screenshots; underlying curves occlude against mesh, handles/grid are deliberate overlays.|
|Edge-on suspension / recovery|PASS science/recovery; paint limitation|Actual camera control, readable warning and stale overlay removal; science/History unchanged, automatic valid-view editing recovery.|
|Navigation / projection modes|PASS|Independent real perspective/orthographic buttons, space-drag orbit and wheel; colorful Navigation Cube retained.|
|Style fallback|PASS|Actual active dashed third Document: native body suppressed, correct existing dashed overlay; explicit closed solid fallback remains a limitation.|
|100 saved Sketch native admission|PASS|mass-gui02: real Admit100 button, one shared native batch,100 actors/1100 points; source identities unchanged; inspected screenshot.|
|TEST CAD1 authored consumer|PASS|authored1-final03 on7f382728: normal registered C++ Viewer, real line/Finish/Undo/Redo/Save, exact native definitions, window disposal.|
|TEST CAD2 authored consumer|PASS|authored2-final01: same shared tools through Canvas-owned controls; actual line/Finish/Undo/Redo/Save and disposal.|
|Software full framework workflow|PASS|software-profile01 and software-lifecycle01: Configuration GUI selects Software, normal Workbench input and exact lifecycle; not environment-only probes.|
|Whole Workbench closure|PASS|final-window-close01 after saved science: stale Destroy callback eliminated, bindings/leases released; no background exception.|
|Kernel / engine / P017 preservation|PASS source identity|Protected engine/kernel/History/public ABI anchors unchanged; exact package guards enforce identity. Not a new exhaustive scientific campaign.|
|STDERR subsystem preservation|PASS source identity / reused P022 evidence|Collector, Viewer and configuration sources/binaries unchanged. No new diagnostics redesign or load campaign.|

## Supplemental contracts (not real-GUI acceptance)

- cache-contract03:8 checks including verified warm read, corruption with restored
  mtime, explicit Read integrity, revision/Session identity, LRU/cleanup, legacy
  sourceCapture4MiB bound, and valid oversized-Document fallback.
- quick-contract08:15 checks covering cold/warm metadata/assets, atomic publication,
  corruption/missing/stale source rejection/rebuild, canonical SHA protection,
  eviction, Session aliasing, interrupted/locked publication, read-only cache,
  unit defaults, descriptor checksum and style preservation policy.
- native-contract03: actual Software native rendering, unchanged revision avoids
  reparse, malformed replacement retains previous actor, visibility, removal,
  base-scene replay, unchanged projection frame during resource admission.
- icon-batch01: five representative stock icons,20/24px PNG byte identity against
  old pipeline, duplicate/unknown/invalid-size rejection.
- mass-final10/50/100: new-process API timings, canonical source identity unchanged,
  no editor/solver hydration or scientific3D worker during descriptor reads.
- Package verification: full exact P022 tracked overlay, matching native source
  hashes, public startup/catalog, all-file/mode rollback. See VERIFICATION.json
  beside the final archive; it is not a substitute for the GUI cases above.

## Failures found, preserved and corrected

1. Source publication notification during an active editor suppressed its native
   body by changing requested visibility. Explicit checked Save refreshed the
   source but retained the hidden flag. Error suppression is now separate from
   user visibility. Matching frame readiness and actual painted screenshots are
   both required. A successful receipt alone previously yielded a blank early
   screenshot and was not accepted as visual PASS.
2. Tk snapshots Destroy bindtag scripts before execution. A first handler retired
   a shared display lease; a later snapshotted callback invoked its dead OO name.
   A bounded live-owner event trampoline now rejects only already retired owners;
   it does not catch errors from live handlers. Whole-window disposal was rerun.
3. An owned viewport validates a Sketch source during Bind, before its constructor
   has acquired the viewport's display lease. The new cheap presentation identity
   incorrectly required that lease early and marked TEST CAD1 stale_source.
   Only the bounded construction phase may omit that not-yet-created lease;
   checked Document/session and later lifetime guards remain. Both authored
   Viewers were rerun through real construction and closure.

Harness/infrastructure failures remain in scratch: wrong relative path, private
versus public state key assumptions, startup/layout races, an unhandled genuine
History-branch modal, combined pointer/Escape timing and failed IBus XIM startup.
They are not GUI PASS. Readiness and genuine active-drag assertions were added;
existing History branching was confirmed through its actual dialog. Two isolated
XIM daemon recoveries changed no desktop preference, driver or scientific data.

## NOT VERIFIED / deliberate limitations

Automatic unsaved-editor recovery across graphics worker/device replacement,
new exact sub-element identities from approximate previews, closed full dash/
annotation fidelity, every GPU/platform, remote X11, and an exhaustive historical
CAD/constraint/publication campaign were not verified or implemented. Base-scene
reset replay is not mislabeled as graphics-worker restart recovery. The exact
current kernels/controllers/publication authorities and accepted P022 evidence
are preserved. Final owner VNC acceptance remains OPEN; nothing is installed.

### Final painted-frame caveat

A final dedicated edge-on check found an early screenshot still containing the
previous editing overlay although the native PNG was clean, the projection was
invalid and the Canvas contained only native frame, warning and chrome. A later
settled capture correctly showed no stale axes/controls and the readable warning.
The invalid-domain path now explicitly retires its disposable overlay raster;
valid recovery recreates presentation only. `consumer-edge-final02` includes raw
native PNG, Canvas state, early and late actual screenshots, and unchanged science/
History on recovery. First-transition painted latency is **not qualified**; an
initial1-second capture was stale and exact settlement time was not measured.
This is a declared review limitation, not an engine-color failure or proof of
immediate visual synchronization. Internal callback readiness is not paint proof.
