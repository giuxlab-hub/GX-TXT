# Preserved failure evidence (synthetic tests only)

SPDX-License-Identifier: GPL-3.0-or-later

The actual whole-Workbench close failure before c1246c62 was:

```text
invalid command name "::oo::Obj65"
    while executing
"::oo::Obj65 ownerDestroyed .gxViewerDevPreview1.body.canvas.scene_pending.geometry_viewport.native3d.canvas"
    (command bound to event)
```

The owned TEST CAD1 constructor before7f382728 produced `stale_source` before
starting its worker, despite matching Document/generation/Session metadata.
Source Bind called the new presentationIdentity before the constructor acquired
its surface; the now-bounded early construction case was corrected and both
ordinary authored consumers reran successfully.

Early edge screenshots and the clean raw native PNG are retained in
evidence/consumer-edge-final02. Late settled pixels and scientific recovery
pass, while first-transition painted latency remains unqualified. This is not
misreported as an immediate-paint PASS or a protected engine defect.

Harmful original-data tests were never attempted. Full failed harness/startup
logs remain in the isolated EXP scratch area; no private Session is packaged.
