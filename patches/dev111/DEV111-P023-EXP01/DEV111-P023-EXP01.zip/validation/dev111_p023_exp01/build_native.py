#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import argparse,subprocess,json,hashlib,shutil,os,time
p=argparse.ArgumentParser();p.add_argument('framework',type=Path);p.add_argument('output',type=Path);p.add_argument('--document',action='store_true');p.add_argument('--stage',action='store_true');a=p.parse_args();f=a.framework.resolve();o=a.output.resolve();assert f==Path('/srv/gxtxt/agents/scratch/DEV111-P023-EXP01-MAIN/framework') and o.is_relative_to(f.parent) and not o.exists();o.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert a.document,'Select an existing native target'
s=f/'core/nativegui/document';b=o/'document';b.mkdir();names=['Makefile','model.cpp','render.c','render.h','source_capture.cpp','source_capture.h','source_snapshot_cache_v1.inc']
for n in names:shutil.copy2(s/n,b/n)
command=['make','-j2','CXXFLAGS=-O2 -g -std=c++17 -fPIC -Wall -Wextra -Werror -MMD -MP','CFLAGS=-O2 -g -fPIC -Wall -Wextra -Werror -MMD -MP','libgxtxt_document.so'];start=time.monotonic()
with (o/'BUILD.log').open('w') as out:subprocess.run(command,cwd=b,stdout=out,stderr=subprocess.STDOUT,check=True)
so=b/'libgxtxt_document.so';dependencies={}
for dep in b.glob('*.d'):
 for name in dep.read_text().replace('\\\n',' ').split(':',1)[1].split():
  path=Path(name);path=path if path.is_absolute() else b/path
  if path.is_file():dependencies[str(path)]=sha(path)
result=dict(command=command,compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],source_commit=subprocess.check_output(['git','-C',str(f),'rev-parse','HEAD'],text=True).strip(),source_pins={str((s/n).relative_to(f)):sha(s/n) for n in names},binary_sha256=sha(so),seconds=time.monotonic()-start,dependencies=dependencies,elf=subprocess.check_output(['readelf','-h','-d',str(so)],text=True),staged=a.stage)
if a.stage:
 dest=s/so.name;tmp=dest.with_suffix('.exp-stage');assert not tmp.exists();shutil.copy2(so,tmp);os.replace(tmp,dest)
(o/'BUILD_IDENTITY.json').write_text(json.dumps(result,indent=2)+'\n');print('Built',so,sha(so))
