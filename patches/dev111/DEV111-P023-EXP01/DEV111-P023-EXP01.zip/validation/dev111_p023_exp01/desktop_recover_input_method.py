#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import os,subprocess,sys,json
out=Path(sys.argv[1]);assert not out.exists();out.mkdir()
proc=Path('/proc/3186');assert proc.stat().st_uid==os.getuid() and (proc/'comm').read_text().strip()=='xfce4-session'
env=dict(os.fsdecode(x).split('=',1) for x in (proc/'environ').read_bytes().split(b'\0') if b'=' in x)
assert env['DISPLAY'] in (':0',':0.0')
cmd=['ibus-daemon','--daemonize','--xim','--replace']
with (out/'SERVICE.log').open('wb') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=8)
(out/'RECOVERY.json').write_text(json.dumps(dict(command=cmd,returncode=r.returncode,desktop_pid=3186,display=env['DISPLAY']),indent=2)+'\n')
print(r.returncode)
