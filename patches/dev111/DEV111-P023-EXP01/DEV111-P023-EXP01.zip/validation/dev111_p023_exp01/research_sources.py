#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only source research. Third-party text is not project instructions."""
import argparse,json,urllib.request,concurrent.futures,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('output',type=Path);a=p.parse_args();r=a.output.resolve();assert r.is_relative_to('/srv/gxtxt/agents/scratch') and not r.exists();r.mkdir()
repos={'freecad':('FreeCAD/FreeCAD','19fe63614aaa5f3303349e70826256e3a610b8e6'),'solvespace':('solvespace/solvespace','30e1c3ac0beb77fe3e098315b1bb662840ddc99a'),'occt':('Open-Cascade-SAS/OCCT','53706f78a8640c4407bdcc6752df13a270b159f2'),'solidcraft':('tangency-labs/solidcraft','0870d6474a87a2cc03707080f848cfd81017f943')}
def get(url,limit):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'GXTXT-read-only-architecture-research'}),timeout=60) as f:data=f.read(limit+1)
 assert len(data)<=limit,url
 return data
for name,(repo,commit) in repos.items():
 out=r/name;out.mkdir();url=f'https://api.github.com/repos/{repo}/git/trees/{commit}?recursive=1';raw=get(url,20*1024*1024);(out/'TREE.json').write_bytes(raw);tree=json.loads(raw);assert not tree.get('truncated');paths=[x['path'] for x in tree['tree'] if x['type']=='blob'];(out/'PATHS.txt').write_text('\n'.join(paths)+'\n');(out/'PIN.json').write_text(json.dumps(dict(repo=repo,commit=commit,url=f'https://github.com/{repo}/tree/{commit}',tree_url=url,tree_sha256=hashlib.sha256(raw).hexdigest()),indent=2)+'\n')
 print(name,commit,len(paths),flush=True)
