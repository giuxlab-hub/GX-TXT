#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse,json,urllib.request,hashlib,concurrent.futures
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('root',type=Path);a=p.parse_args();r=a.root.resolve();assert r.is_relative_to('/srv/gxtxt/agents/scratch')
files={
'freecad':['src/Gui/ViewProvider.h','src/Gui/Document.cpp','src/Mod/Sketcher/App/SketchObject.h','src/Mod/Sketcher/App/SketchObject.cpp','src/Mod/Sketcher/Gui/ViewProviderSketch.h','src/Mod/Sketcher/Gui/ViewProviderSketch.cpp'],
'solvespace':['src/group.cpp','src/sketch.h','src/graphicswin.cpp','src/draw.cpp','src/drawentity.cpp','src/request.cpp','src/system.cpp'],
'occt':['src/Visualization/TKV3d/AIS/AIS_InteractiveObject.hxx','src/Visualization/TKV3d/AIS/AIS_InteractiveObject.cxx','src/Visualization/TKV3d/AIS/AIS_InteractiveContext.hxx','src/Visualization/TKV3d/AIS/AIS_InteractiveContext.cxx','src/Visualization/TKV3d/PrsMgr/PrsMgr_PresentableObject.hxx','src/Visualization/TKV3d/SelectMgr/SelectMgr_SelectableObject.hxx'],
'solidcraft':['AGENTS.md','CONTRIBUTING.md','ROADMAP.md','docs/control-protocol.md','crates/engine/src/lib.rs','crates/engine/src/cmd/sketch_create.rs','crates/engine/src/cmd/sketch_drag.rs','crates/engine/src/cmd/sketch_drag_live_tests.rs','crates/engine/src/product_scene.rs','crates/engine/src/cmd/view_navigation.rs','crates/doc/src/lib.rs','crates/sketch/src/lib.rs','crates/render/src/scene.rs','crates/render/src/camera.rs','crates/ui-egui/src/sketch_display.rs','crates/ui-egui/src/viewport.rs','crates/ui-egui/src/navigation.rs','crates/ui-egui/src/sketch3d.rs','crates/ui-egui/src/sketch_edit_tests.rs','crates/sketch/src/model.rs','crates/doc/src/document.rs','crates/doc/src/frame.rs','crates/doc/src/feature_refs.rs','crates/doc/src/model_cache.rs','crates/ui-egui/src/gpu.rs','crates/ui-egui/src/open_meshing.rs','crates/geom/src/plane.rs']}
def acquire(item):
 name,path=item;pin=json.loads((r/name/'PIN.json').read_text());known=set((r/name/'PATHS.txt').read_text().splitlines());assert path in known,(name,path)
 url=f"https://raw.githubusercontent.com/{pin['repo']}/{pin['commit']}/{path}";dest=r/name/'source'/path
 if dest.exists():raw=dest.read_bytes()
 else:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'GXTXT-architecture-study'}),timeout=60) as f:raw=f.read(4*1024*1024+1)
  assert len(raw)<=4*1024*1024;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
 return dict(project=name,path=path,url=f"https://github.com/{pin['repo']}/blob/{pin['commit']}/{path}",sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw))
rows=[];failures=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 futs={pool.submit(acquire,(name,path)):(name,path) for name,paths in files.items() for path in paths}
 for future in concurrent.futures.as_completed(futs):
  try:rows.append(future.result())
  except Exception as e:failures.append(dict(source=futs[future],error=str(e)))
(r/'FILES.json').write_text(json.dumps(dict(files=sorted(rows,key=lambda x:(x['project'],x['path'])),failures=failures),indent=2)+'\n');print('source files',len(rows),'failures',failures)
