#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Review-only EXP01 overlay; no installation, promotion or user Session writes."""
import sys,json,shutil,subprocess,stat,zipfile,datetime,struct
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from release_common import *
def tracked(root):return [p.decode() for p in subprocess.check_output(['git','-C',str(root),'ls-files','-z']).split(b'\0') if p]
def main():
 if len(sys.argv)!=4:raise SystemExit('BASELINE SOURCE NEW_STAGE required')
 base,source=map(lambda x:Path(x).resolve(),sys.argv[1:3]);stage=fresh_scratch(sys.argv[3])
 require(git(base,'rev-parse','HEAD')==BASE_COMMIT and not git(base,'status','--porcelain'),'Clean exact deposited P022 required')
 require(git(source,'branch','--show-current')=='experiment/dev111-p023-exp01' and not git(source,'status','--porcelain'),'Clean isolated committed EXP01 required')
 require(git(base,'rev-parse','--absolute-git-dir')!=git(source,'rev-parse','--absolute-git-dir'),'Separate Git administrative ownership required')
 subprocess.run(['git','-C',str(source),'merge-base','--is-ancestor',BASE_COMMIT,'HEAD'],check=True)
 commit=git(source,'rev-parse','HEAD');archive=Path('/srv/gxtxt/releases/dev111/patches/0022-real-gui-native3d-stabilization/DEV111-P022.zip')
 require(sha(archive)==BASE_ZIP_SHA and archive.stat().st_size==BASE_ZIP_BYTES,'P022 archive changed')
 before={n:sha(base/n) for n in tracked(base)};after={n:sha(source/n) for n in tracked(source)}
 require(set(before)<=set(after),'Product deletions require separate review')
 changed=sorted(n for n in after if before.get(n)!=after[n])
 allowed=('core/','docs/api/','docs/development/DEV111-P023-EXP01/','validation/dev111_p023_exp01/','plugins/modules/viewer.3d_workbench/')
 for n in changed:
  require(n.startswith(allowed) or n in ('SCRIPT_CATALOG.md','SCRIPT_CATALOG.md.sha256','SHA256SUMS'),'Out of experiment scope: '+n)
  require(not any(p in Path(n).parts for p in ('Sessions','.git','__pycache__')) and 'TODO' not in n.upper(),'Private/protected payload: '+n)
 with zipfile.ZipFile(archive) as prior:
  old=json.loads(prior.read('patch_notes/DEV111-P022/FILES.json'));require(old['source_commit']==BASE_COMMIT,'P022 manifest commit differs')
  for row in old['changed_files']:require(before[row['path']]==row['after_sha256'] and digest(prior.read(row['path']))==row['after_sha256'],'P022 archive/source differs')
 protected={n:v for n,v in old['protected_files'].items() if n not in changed}
 for n in ('core/native3d/lib/libgx3de.so','core/native2d/gx2d.c','core/native2d/bin/gx2dtcl.so'):
  require(before[n]==after[n],'Protected native authority changed: '+n);protected[n]=before[n]
 require(len(protected)>=90,'Insufficient protected anchors')
 for binary,receiptname in [('core/nativegui/document/libgxtxt_document.so','BUILD_DOCUMENT.json'),('core/native3d/bin/libgx3de_viewer_tcl.so','BUILD_TRANSPORT.json')]:
  record=read_json(source/'docs/development/DEV111-P023-EXP01'/receiptname)
  require(sha(source/binary)==record['binary_sha256'],'Native binary/build identity differs')
  pins=record.get('inputs',record.get('source_pins',{}));require(pins,'Build inputs required')
  for name,value in pins.items():
   path=Path(name)
   if path.is_relative_to(source):require(sha(path)==value,'Built source changed: '+name)
   elif name.startswith('core/'):require(sha(source/name)==value,'Built source changed: '+name)
  raw=(source/binary).read_bytes();require(raw[:6]==b'\x7fELF\x02\x01' and struct.unpack('<H',raw[18:20])[0]==62,'Linux x86-64 binary required')
 module=source/'plugins/modules/viewer.3d_workbench'
 for leaf in ['SHA256SUMS','SHA256SUMS.txt']:
  for line in (module/leaf).read_text().splitlines():
   if line.strip():v,n=line.split(None,1);require(sha(module/n.lstrip('* '))==v,'Module checksum differs')
 stage.mkdir();payload=stage/'payload';payload.mkdir();notes=payload/NOTES;notes.mkdir(parents=True)
 rows=[]
 for n in changed:
  target=payload/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/n,target)
  if n in before:
   backup=notes/'rollback-preimages'/n;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/n,backup)
  rows.append(dict(path=n,action='replace' if n in before else 'add',before_sha256=before.get(n),after_sha256=after[n],before_mode=stat.S_IMODE((base/n).stat().st_mode) if n in before else None,after_mode=stat.S_IMODE((source/n).stat().st_mode)))
 manifest=dict(patch=PATCH,baseline_commit=BASE_COMMIT,baseline_archive_sha256=BASE_ZIP_SHA,source_commit=commit,changed_files=rows,protected_files=protected,status='EXPERIMENTAL_REVIEW_ONLY',installed=False,accepted=False)
 write_json(notes/'FILES.json',manifest)
 for name in ['apply.py','rollback.py','release_common.py']:shutil.copy2(source/'validation/dev111_p023_exp01'/name,notes/name)
 for p in (source/'docs/development/DEV111-P023-EXP01').iterdir():
  if p.is_file():shutil.copy2(p,notes/p.name)
 leaves=sorted(p for p in payload.rglob('*') if p.is_file());(notes/'PAYLOAD_SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(payload).as_posix()}\n' for p in leaves))
 date=datetime.datetime.fromtimestamp(int(git(source,'show','-s','--format=%ct','HEAD')),datetime.timezone.utc);dest=stage/(PATCH+'.zip')
 with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(p for p in payload.rglob('*') if p.is_file()):
   info=zipfile.ZipInfo(p.relative_to(payload).as_posix(),(date.year,date.month,date.day,date.hour,date.minute,date.second));info.create_system=3;info.external_attr=(stat.S_IFREG|stat.S_IMODE(p.stat().st_mode))<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,p.read_bytes(),compresslevel=9)
 apply_overlay(base,dest,False)
 proof=stage/'review-sandbox';proof.mkdir();(proof/'.gxtxt-experiment-review-sandbox').write_text(PATCH+'\n')
 for n in before:
  p=proof/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/n,p)
 apply_overlay(proof,dest,True);require(all(sha(proof/n)==v for n,v in after.items()),'Full cumulative postimage differs')
 subprocess.run([sys.executable,'-B',str(source/'validation/dev111_p023_exp01/fresh_startup.py'),str(proof),str(stage/'fresh-startup')],check=True)
 rollback_overlay(proof,False);rollback_overlay(proof,True)
 require(all(sha(proof/n)==v and stat.S_IMODE((proof/n).stat().st_mode)==stat.S_IMODE((base/n).stat().st_mode) for n,v in before.items()),'Exact P022 rollback differs')
 require(all(not (proof/n).exists() for n in set(after)-set(before)),'Added experiment files survived rollback')
 require(sha(archive)==BASE_ZIP_SHA and not git(base,'status','--porcelain'),'Protected P022 changed')
 result=dict(status='PASS',purpose='EXPERIMENTAL_REVIEW_ONLY_NOT_FOR_INSTALLATION',patch=PATCH,source_commit=commit,archive=str(dest),archive_bytes=dest.stat().st_size,archive_sha256=sha(dest),changed_files=len(rows),all_base_tracked_files=len(before),protected_anchors=len(protected),cumulative_application='exact P022 plus all EXP01 postimages',rollback='all P022 bytes and modes restored; added product files removed',fresh_public_startup='PASS',installed=False,accepted=False)
 write_json(stage/'VERIFICATION.json',result);(stage/(PATCH+'.zip.sha256')).write_text(sha(dest)+'  '+dest.name+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
 try:main()
 except (GuardError,OSError,ValueError,KeyError,subprocess.SubprocessError) as error:raise SystemExit('REFUSED: '+str(error))
