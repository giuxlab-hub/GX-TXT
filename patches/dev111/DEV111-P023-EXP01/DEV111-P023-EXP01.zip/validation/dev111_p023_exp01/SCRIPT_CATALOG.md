# DEV111-P023-EXP01 research and isolated experiment

Scope: exact deposited P022 c92f9f90caa1d4196fd23023873171c9d9094c6a,
ZIP450d59e503b8e5c49551e97233fa0a3bcf778b13679290b05ce260930b72bc66.
Owner directive SHA823d38d8c2bc5d30ffa31114ca736d457f64bcb0712202387caf27ff794b3d25
read in full only after P022 deposit. Evaluate BEFORE product implementation.
No P022 edits/install/promotion/OS changes/production Sessions/TODO writes.

`research_sources.py NEW_SCRATCH_DIRECTORY`: read-only HTTPS acquisition of
commit-pinned official FreeCAD/SolveSpace/OCCT/SolidCraft Git trees and selected
source files for architecture study. Source/URL/SHA evidence remains outside the
framework/distributed experiment; no third-party code/build/assets are imported.
Remote AGENTS/README files are research data, not applicable GX-TXT instructions.
Does not clone/fetch/push any GX-TXT repository. Bounded metadata/files/timeouts.
`research_files.py RESEARCH_DIRECTORY`: downloads only the explicit source/doc
allowlist at each already-pinned commit, validates tree membership and file-size
bounds, writes per-file URL/SHA evidence to that private research tree. Network
is read-only external design research expressly requested by owner; no GX-TXT
remote Git or third-party code import. Future files require catalog/review change.

Baseline preparation uses the reviewed P022 `fixtures.tcl` and `launch.py` only
against their exact deposited c92f9f90 P022 framework (version-pin checked), never
unchanged against a newer product. Fresh EXP scratch profiles/Session paths only.
Exact same public1/10/50 synthetic science and ATP fixture; no original Session.
`counter.tcl` and `profile_baseline.py` (below) are temporary research observers
loaded into the owned normal GUI; no product source edit, no retained trace rows
per-native-call. Histogram/stack samples are bounded; full total counters do not
truncate at30,000. Scripted and method-only timings must be kept distinct.
`counter_overhead.tcl FRAMEWORK NEW_OUTPUT`: supplemental isolated public
Native2D coordinate-call microbenchmark, three untraced/count/span/combined
samples of20,000 accepted identical scalar conversions. Explicit private profile,
no GUI acceptance or scientific source mutation; measures callback overhead
separately. Retains all totals/counter receipts and verifies no truncation.
`mass_baseline.tcl P022_FRAMEWORK NEW_OUTPUT EXACT_MODELS_FILE`: independent
public Document/Sketch display API benchmark, not GUI acceptance. Creates100
private exact Sketch Documents with three valid scientific planes, one11-control
retained polyline each. Measures existing public metadata batching and explicit
full display reconstruction for10/50/100, records per-Document durations, points,
source SHA, and exact model invariance. Bounded300s total; no user source/Session
or product writes. Does not claim an index already exists. Same fixture will be
reused for the experimental descriptor comparison.
`registry_callers.tcl`: temporary owned-GUI enter trace for the canonical registry
reader; at most64 caller groups and one bounded stack/group, complete call total.
Actual GUI Open/Close inputs provide call paths. No product callback setters,
scientific mutation or per-call event-log growth. Diagnostic overhead is not used
as untraced latency. `profile_baseline.py --counter off` can drive that sequence.

`build_native.py FRAMEWORK NEW_OUTPUT --document [--stage]`: compile the existing
NativeDocument Makefile target in a fresh private directory with its matching
sources, unchanged XML/render/source-capture surfaces, additive checked snapshot
cache and libcrypto. Records commands/source/dependency/compiler/ELF hashes.
Atomic stage only into the isolated EXP framework; never P022 or installed paths.
No package installation, engine rewrite, History/library replacement or Qt browser
build. Later Native3D transport additions use the existing transport build target.
`cache_contract.tcl EXP_FRAMEWORK NEW_OUTPUT`: public Document cached-read,
metadata batch, revision/Session isolation, configure/evict/clear and corruption
checks in a fresh synthetic Session. Private backing-path access is used ONLY for
explicit fault injection; it is not advertised as a consumer API. Same-size
mutation restores nanosecond mtime, expects SHA rejection through ctime identity.
Also verifies explicit Read continues to reject corruption and existing private
sourceCapture retains its4MiB bound. No original files/Session or GUI acceptance.
`fixture.tcl FRAMEWORK NEW_OUTPUT` and `launch.py FRAMEWORK NEW_OUTPUT --fixture X`:
EXP-version adaptations of reviewed P022 helpers. Create private public1/10/50
retained science and ATP, then launch complete normal application from actual
XFCE desktop environment with only profile/storage isolation. Actual GUI inputs
use the existing observer/input helper; no graphics overrides or private user data.
First batch GUI qualification before further critical rendering changes uses
profile_baseline.py --light-timing --counter span --counts1 50, exact edit/Undo.
`build_transport.py EXP_FRAMEWORK NEW_OUTPUT [--stage]`: build only the additive
Native3D Tcl transport against the exact protected existing engine. Records full
source/header/dependency/compiler/ELF identities; atomic stage only EXP binary.
No Native3D engine or Native2D kernel rebuild, install, activation or OS change.
`desktop_recover_input_method.py NEW_OUTPUT`: bounded recovery of a failed local
IBus XIM daemon using the existing XFCE3186 environment, with no preference,
package, X-server, driver, original GX-TXT process or scientific data changes.
Writes the service command/environment identity/log only in EXP scratch. GUI
scripts hung inside XCreateIC are infrastructure failures, never CAD PASS.
`quick_open_contract.tcl EXP_FRAMEWORK NEW_OUTPUT EXACT_MODELS`: independent
public Document/Sketch descriptor contract in a fresh private synthetic Session.
Checks publication on create/save, cold/warm reads, plane/unit metadata, exact
payload invariance, revision invalidation, missing/corrupt index/asset recovery,
canonical corruption rejection, eviction and Session identity. Private paths are
used solely for deliberate test fault injection. No GUI PASS claim, user data,
install, original release edits or scientific-kernel changes.
`resident_consumer.tcl EXP_FRAMEWORK NEW_OUTPUT`: independently executable real
Tk consumer of public Native3D viewport, Sketch scene bindings and existing CAD
Canvas/advanced/History APIs; imports no Workbench runtime. Fresh synthetic
Session, three differently oriented11-control Sketches and the ordinary RAM
cube mesh. External toolbar controls editing/picking/show/hide, explicit save,
close/reopen, projection and native resource disposal. User/automation clicks
exercise actual shared tools; no callback invocation counts as GUI acceptance.
`launch_consumer.py FRAMEWORK NEW_OUTPUT --fixture PRIVATE_OUTPUT`: uses the same
existing XFCE desktop environment as normal GX-TXT; starts the above consumer,
records exact commit/input profile/PID/environment. All files remain EXP scratch;
no scientific original, OS preference, installed framework or production Viewer.
`resident_scenarios.py LAUNCH NEW_OUTPUT FRAMEWORK`: actual xdotool input against
an owned independent consumer PID, public mapping used only to locate controls
and assert scientific results. Exercises native closed-Sketch pick/open, exact
control drag/Undo/Redo/cancel/save/close/reopen, multiple planes, visibility,
projection/navigation and invalid-view recovery. Complete bounded counters,
receipts, screenshots and native frame-readiness checks; no private science
mutations or callback-only GUI claims. Stops on first failure and preserves it.
`mass_descriptor.tcl EXP_FRAMEWORK NEW_OUTPUT prepare EXACT_MODELS` creates100
synthetic one-curve Documents on three planes through canonical public creation,
measuring new derived-publication cost and source hashes. `... read FIXTURE COUNT`
runs in a NEW process, opens that owned synthetic Session through public APIs,
uses its existing private cache/profile, times batch descriptors and per-Document
ready-preview retrieval for10/50/100, records p50/p95, bytes/points, native cache,
RSS and whether a scientific3D worker was started. OS page cache is not flushed.
No GUI acceptance, scientific solver hydration or GPU timing claimed from this
API benchmark; real GUI editable readiness is measured separately. No user data.
`icon_batch_contract.py FRAMEWORK NEW_OUTPUT`: independent fixed-CORE icon batch
contract, compares admitted asset and display PNG hashes byte-for-byte with the
existing individual validation/raster path, checks unknown IDs/duplicate IDs and
invalid sizes. Writes private JSON only; no GUI acceptance or icon/style change.
`resident_native_contract.tcl FRAMEWORK NEW_OUTPUT`: supplemental low-level Tcl
transport/unchanged Native3D C ABI test, not GUI acceptance. Creates an empty
software-rendered scene, derived resident resources, tests unchanged revisions,
visibility/removal, rejected batch rollback, projection frame identity and base
scene reset replay. Uses isolated output and explicitly recorded local Mesa
child environment; no installed files, scientific Session or native engine edit.
`normal_lifecycle.py LAUNCH NEW_OUTPUT FRAMEWORK`: actual mouse/keyboard final
normal-application shared Sketch GUI qualification after the profile run. Redo,
Escape rollback, explicit Save/Close/Reopen of the same Document, real line
construction/Finish/Undo, and visibility of resident geometry after close.
Reads exact public models/History for assertions; does not invoke edit callbacks
as tests. Uses only the assigned synthetic Session and owned GUI PID.
`mass_scene_consumer.tcl FRAMEWORK NEW_OUTPUT MASS_FIXTURE`: independent real Tk
consumer of the public resident binding, one native viewport, external Admit100 /
Detach buttons. Reads only the private synthetic mass Session/cache; measures
actual completed native batch/resource counts and preserves canonical hashes.
`launch_consumer.py --mass-fixture FIXTURE` selects this cataloged consumer; no
new production Viewer. Existing desktop environment, no GL override.
`package.py BASELINE SOURCE NEW_STAGE`: EXP01-only incremental source/binary
packaging, exact clean P022 commit/archive preimages, protected anchors, matching
native dependency hashes and full tracked overlay/rollback verification in a
fresh scratch tree. Fresh public startup is headless, not GUI acceptance.
`apply.py REVIEW_SANDBOX ARCHIVE --apply` and `rollback.py REVIEW_SANDBOX --check`
are version-pinned EXP helpers: mutations REQUIRE an explicit ordinary
`.gxtxt-experiment-review-sandbox` marker containing DEV111-P023-EXP01. They refuse
production paths/installed framework and never activate a framework, modify a
Session, promote production P023 or mark acceptance. MAIN alone deposits a new
review-only archive and matching experiments archive/expanded mirrors.
`authored_smoke.py LAUNCH NEW_OUTPUT WINDOW`: actual normal registered TEST CAD1/2
Viewer startup, shared line input/Finish/Undo/Redo/Save, exact native-definition
assertions and whole-window closure. Exercises the unchanged authored C++ Viewer
through real controls; no direct edit callback. Only the assigned private Session.
`finalize_evidence.py FRAMEWORK SCRATCH`: explicit allowlist of generated synthetic
receipts/screenshots/input traces/build identities, excludes all Session/config/
resource/cache trees and external research source code. Copies only reviewed
technical evidence into this experiment's docs, generates file hashes and scoped
metadata checksums. No original scientific data, installed files or prior release
edits. MAIN reviews actual images separately; collection is not automatic PASS.
