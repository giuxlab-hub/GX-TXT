# DEV111-P033: scientific Acquisition, native Previews and Script Projects

Exact accepted predecessor source `fc672ead2755c316025711b9915fdcd6beef4909`, DEV111-P032 ZIP SHA256 `96ad229a771a519c8e45026dd70770581942ec2a3531915098d31c7f00d5f31b`.
Candidate source `c46767878984f04c4b2fc00fc223f1852a0aad53`. Full predecessor BASELINE plus FILES postimages
supply exact bytes and physical modes. User extras and previous notes remain.
This preparation is not acceptance; consult independent A/B source/artifact
receipts and final handoff. MAIN alone freezes, accepts and deposits.

P033 delivers the universal scientific Acquisition and three compiled native
Preview modules, optional in-editor Script Projects, a genuine C++ Script Library,
source-declared callable public APIs and the bounded Dataset Browser toolbar fix.
Ten normal companion Modules are bundled; six original containers stay unchanged;
MODULE_VERSION_MATRIX.json is authoritative. Module framework_min=dev111 cannot
express patch compatibility: native P033 clients require matching P033 CORE and
explicit grants. Existing CSV/Acquisition and native Viewer ABI remain qualified
by their actual independent coverage, never by a version label alone.

Accepted Curve, UML/Markdown containers and original Preview014 input remain
inherited unchanged; this delivery adds no supplemental input archive. Inherited
Curve Viewer qualification is OWNER_SUPPLIED_UNMODIFIED;
NOT_TESTED_BY_OWNER_REQUEST. Packaging performs no Module/Curve operation and
rebuilds no supplied/native binary. Preserve the original accepted archives.

Keep ZIP and sidecar, retain a full backup, stop GX-TXT and all workers. Helpers
have no process detector: --stopped is operator acknowledgement. Extract only
patch_notes/DEV111-P033/ into a separate review directory, then:

    python3 review/patch_notes/DEV111-P033/apply.py FRAMEWORK DEV111-P033.zip --check
    python3 review/patch_notes/DEV111-P033/apply.py FRAMEWORK DEV111-P033.zip --apply --stopped

Default check writes nothing. Verified rollback notes precede product writes.
POSIX directory locking and atomic per-file replacements do not form a whole-root
transaction. Interrupted recovery accepts only exact known before/after states;
unknown edits/modes/collisions refuse. Plain unzip cannot implement deletions.

    python3 FRAMEWORK/patch_notes/DEV111-P033/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P033/rollback.py FRAMEWORK --rollback --stopped

Rollback restores exact P032 bytes/modes, removes only declared P033 additions,
and retains notes/extras. Reverse later patches first; deliberate reapply needs
operator handling of retained notes. No Session/RAW/configuration/user data,
previous release, activation or installation cleanup is authorized.

The overlay already bundles all ten companion Modules. companion_preflight.py
checks exact postimages; no forced reinstall is necessary. Separate normal ZIPs
are alternative delivery for a compatible host and legitimate Plugin Manager
state. Never fabricate Registry entries or remove bundled Modules for admission.
Canonical deposit and live activation are separate MAIN-only actions.
