# Current C/C++ Viewer support catalog

Generated from the installed Development policy, SDK and runtime owners. Open this catalog from **Develop → C/C++ support catalog** in the Viewer Development Workspace. The existing rendered Markdown manual window provides find, links and scrolling.

## Language and ownership

C++17 including C facilities.

functions, pointers/references, classes/structs/enums/unions, inheritance/virtual dispatch/RTTI, overloads/templates, recursion, callbacks/lambdas, malloc/free/new/delete/RAII, containers/algorithms, preprocessing/macros/assert, exceptions, threads/synchronization, fork/wait.

Debian system libc/libstdc++/libm/pthread; extra libraries and compiler options require purpose-specific review

Local project logic/data/concurrency are allowed. Canonical Dataset/Schema/Publication/Session/Workspace/History/Job/scientific Plot remain public CORE responsibilities. Language admission does not approve an architectural bypass.

The compiler performs real Clang parsing and checks the fixed public on_event ABI and typed Host calls. Ordinary local C/C++ functions and standard library facilities supplied by the admitted headers are available, subject to their actual Debian implementation. Headers below are the exact direct-include admission list; transitive system dependencies are supplied by those headers. A new direct header, dependency or compiler/link option requires a concrete purpose and MAIN architectural review. Language availability does not grant a competing canonical store, scheduler or scientific renderer.

## Project source closure

One existing Viewer project contains handlers.cpp plus declared src/**/*.cpp translation units and include/**/*.hpp local headers. source_files is ordered with the unique handlers.cpp entrypoint first, at most32 files/64KiB each/1MiB total. The same official lexer/AST admits every translation unit and local header against an immutable complete source snapshot; fixed SDK linking includes every admitted unit. Source manifests retain path/role/size/SHA plus complete source/project digests. Any declared source/header edit invalidates stale runtime/build/package/debug identities. Literal reviewed includes use # or %: directives with phase2 splices; macro/external/escaped includes, numeric source remapping, trigraph/embed and header-existence queries require review. Ordinary/raw string content is inert. No authored compiler/build hook is available.

Independent Source Surface tabs retain per-file dirty state and Save All preimages; file add/rename/move/remove and checked editable package reimport delegate to the same Development owner. Original GDB/MI frames retain authentic full source names and normalized project_file identities across helper translation units and executable headers. External/native frames stay external; pending breakpoints do not establish an executable stop.

## Admitted headers and review decisions

Exactly 46 explicitly admitted header identities. Each row records facilities and the architectural decision for local project logic; CORE ownership remains authoritative. Admission is not exhaustive functional or platform acceptance.

| Exact header | Facilities, purpose and architectural review |
| --- | --- |
| `vector` | Reviewed local application containers; canonical Dataset access stays in public CORE |
| `array` | Reviewed local fixed-size application containers |
| `list` | Reviewed local application sequences |
| `deque` | Reviewed local application queues |
| `map` | Reviewed local application key/value state, not a canonical store |
| `unordered_map` | Reviewed local application indexes, not a canonical store |
| `set` | Reviewed local application sets |
| `unordered_set` | Reviewed local application sets |
| `queue` | Reviewed local application traversal/queues, not a CORE Job scheduler |
| `stack` | Reviewed local algorithm/application stacks |
| `memory` | Reviewed RAII and smart pointers for project memory |
| `utility` | Reviewed move/forward/pair facilities |
| `algorithm` | Reviewed local application algorithms; no replacement scientific service |
| `functional` | Reviewed callable wrappers/callbacks |
| `string` | Reviewed project strings; SDK transport remains bounded |
| `string_view` | Reviewed non-owning strings; respect lifetime and SDK transport |
| `tuple` | Reviewed local typed values |
| `type_traits` | Reviewed templates/type introspection |
| `typeinfo` | Reviewed ordinary RTTI/polymorphism |
| `exception` | Reviewed C++ exception lifecycle |
| `stdexcept` | Reviewed project error handling |
| `new` | Reviewed allocation/placement/lifetime |
| `limits` | Reviewed type bounds |
| `thread` | Reviewed local application threads; managed CORE Jobs remain authoritative |
| `mutex` | Reviewed local synchronization |
| `condition_variable` | Reviewed local synchronization |
| `atomic` | Reviewed local synchronization |
| `chrono` | Reviewed local time/duration measurement |
| `cassert` | Reviewed genuine native assertions |
| `assert.h` | Reviewed genuine native assertions |
| `cstddef` | Reviewed size/pointer types |
| `stddef.h` | Reviewed size/pointer types |
| `cstdint` | Reviewed exact-width local types |
| `stdint.h` | Reviewed exact-width local types |
| `cstdlib` | Reviewed allocation/conversion; inspect actual process/file use for CORE ownership |
| `stdlib.h` | Reviewed allocation/conversion; inspect actual process/file use for CORE ownership |
| `cstring` | Reviewed bounded project memory/string handling |
| `string.h` | Reviewed bounded project memory/string handling |
| `cstdio` | Reviewed project-scoped I/O; never private canonical Dataset/Workspace access |
| `stdio.h` | Reviewed project-scoped I/O; never private canonical Dataset/Workspace access |
| `cerrno` | Reviewed native operation diagnostics |
| `errno.h` | Reviewed native operation diagnostics |
| `unistd.h` | Reviewed fork/_exit local process workflow; not a replacement CORE execution service or canonical file bypass |
| `sys/types.h` | Reviewed native pid/type declarations |
| `sys/wait.h` | Reviewed wait/waitpid for own forked child lifecycle |
| `pthread.h` | Reviewed ordinary local thread/synchronization facilities |

## Supported public Host functions

Only these currently compiled SDK methods integrate the C++ author with GX-TXT. Each still requires its explicit compatible project capability, component/form and version. Discovery of another public Tcl/Script API does not admit an arbitrary C++ call.

```cpp
void text(unsigned component, const char* value) const;
void number(unsigned component, double value) const;
void flag(unsigned component, bool value) const;
double numeric_add(double left, double right) const;
double numeric_sqrt(double value) const;
double numeric_exp(double value) const;
void diagram_open(unsigned component) const;
void diagram_tool(unsigned component, const char* tool) const;
void diagram_command(unsigned component, const char* command) const;
void scientific_discover(unsigned form) const;
void scientific_prepare(unsigned diagram, unsigned form) const;
void scientific_submit(unsigned form) const;
void scientific_status(unsigned form) const;
void scientific_cancel(unsigned form) const;
void scientific_reconnect(unsigned form) const;
void scientific_log(unsigned form) const;
void scientific_import(unsigned form, unsigned dataset_selector) const;
void plot_discover(unsigned form) const;
void plot_bind(unsigned plot, unsigned form) const;
void document_bind(unsigned document, unsigned dataset_selector) const;
void document_command(unsigned document, const char* operation) const;
void raster_bind(unsigned viewport, unsigned dataset_selector) const;
void raster_tool(unsigned viewport, const char* tool) const;
void raster_command(unsigned viewport, const char* command) const;
void tex_command(unsigned form, const char* operation) const;
void em_command(unsigned form, const char* operation) const;
void workbench_command(unsigned form, const char* operation) const;
const char* input(unsigned component) const;
const char* data() const;
void cad_command(unsigned component, const char* action) const;
void diagnostics_command(unsigned form, const char* operation, const char* request = "{}") const;
void text_runs(unsigned component, const char* runs_json) const;
void table(unsigned component, const char* rows_json) const;
void catalog_refresh(unsigned form) const;
void catalog_inspect(unsigned form) const;
void catalog_action(unsigned form, const char* action) const;
void numeric_discover(unsigned form) const;
void numeric_evaluate(unsigned form) const;
void numeric_statistics(unsigned form) const;
void numeric_compare(unsigned form) const;
void numeric_publish(unsigned form, unsigned dataset_selector) const;
void dataset_group_review(const WorkspaceValue& dataset_ids) const;
void dataset_group_create(const WorkspaceValue& definition, const WorkspaceValue& review) const;
void dataset_publish_batch(const WorkspaceValue& request) const;
WorkspaceValue dataset_producer_result() const;
void demo(unsigned component, unsigned fixture) const;
Workspace workspace() const;
```

Presentation operations run through the shared GUI Host. Numerical methods use Numeric; canonical diagrams use Native2D/Interactive Document; scientific forms use Scientific Execution/Jobs; scientific graphs use Plot v4. document_bind uses existing HTML/PDF/Source Surface/paged Dataset consultation. catalog_refresh/inspect/action use a declared GUI Host section and the existing Scientific Library Manager, with exact per-action grants; they do not expose a generic invoke or scientific library parser. demo is explicitly a RAM demonstration and cannot establish scientific acceptance.

tex_command uses a complete declared TeX form and finite GUI Host operations. Source Surface, canonical TeX Workspace/Resource, managed native TeX builds, PDF consultation and File Publication retain their existing ownership. Build saves the guarded draft before running the typesetter; installed C++ execution still uses the packaged binary. The additive nonvirtual method/opcode30 preserves old Event/State/Host storage and operations1–29. See VIEWER_GUI_HOST_API_v1 for exact form and lifecycle contracts; source admission is not installed Viewer acceptance.

New Viewer scientific 2D and 3D graphs require PLOT_DATASET_API_v4. PLOT_DATASET_API_v3 is deprecated and denied for new restricted declarations/source/build/export/runtime admission; preserved historical consumers keep their existing compatibility API.

## ABI, compiler and runtime

```text
--no-default-config
-std=c++17
-x
c++
-Werror
-fno-color-diagnostics
-pthread
-isystem
/usr/lib/gcc/x86_64-linux-gnu/14/include
```

The trusted adapter links a shared library with system libstdc++, libm and pthread (-shared -pthread -Wl,-z,defs -lstdc++ -lm). The SDK is automatically supplied. The event handler is void on_event(gx::Host&, gx::State&, const gx::Event&). State has sixteen double slots and one unsigned counter; these are bounded public event transport, not a restriction on ordinary local C++ types or project memory. Host callbacks use bounded finite values/text and enumerated operations.

Development validates and builds once per actual source/build dependency version. Preview, Test and Export reuse the retained binary; closing and reopening an unchanged project does not rebuild it. Installed packages distribute native/viewer.so. Plugin admission verifies that artifact and SDK compatibility; normal installed startup/events load it directly without compiler/linker invocation or a silent rebuild fallback. Missing/incompatible artifacts require a precise error and a compatible package. No development compiler is needed to execute a compatible installed Viewer. Local compiled events use the existing managed persistent worker and apply their public GUI plan before the next queued pointer action; scientific Jobs remain asynchronous.

Current admission/build budgets: source 65536 bytes; compile 30 seconds; active event wall budget 12 seconds. The native worker currently applies CPU3s, address-space256MiB, output-file1MiB and no core dumps. These are actual execution budgets, not a claim of hostile-code security or a general language prohibition. Purpose-specific legitimate workload changes need owner review.

## Scalar Numeric transport

Persistent native author limits remain CPU3s/address-space256MiB/file-size1MiB and wall12s. Explicit scalar add/sqrt/exp grants use a conditional pre-limit trusted transport to the exact original broker_message/core Numeric owner, matching the nonpersistent broker boundary. It is not a numerical implementation, scheduler, registry, compiler or new SDK permission. Bounded typed framing/frozen hashes/exact grants and existing supervisor identities/subreaping drain broker plus CORE groups on normal close, failure, cancellation and parent death. A Viewer without scalar grants starts no child. Domain failure discards event UI/state and permits a later valid event in the same native library. Cancellation cannot unwind through ctypes as an uninitialized success.

## Producer-scoped Dataset Groups

Producer-scoped Dataset Group clients add `Host::dataset_group_review`,
`Host::dataset_group_create`, `Host::dataset_publish_batch` and
`Host::dataset_producer_result` under existing Group v1/Publication v2 explicit
capabilities. They use finite typed requests to the existing owning-thread
producer service, with no Numeric form or hidden component. Requests are at most
48 KiB; Review accepts 0..64 IDs and batches 1..64 outputs. Full revisions remain
opaque UTF-8 strings. Native typed numbers remain finite double/int64; Script
Bridge numeric arrays retain the existing writer's NaN/missing-value policy.
Receipts arrive for the next event and identify operation, status, increasing
sequence and event generation. Failures replace old success with a fresh failed
receipt and null result. Grouped batches require explicit Group Create as well
as Review and Publication; ungrouped batches need no Group Create. Original ABI 1
package binaries remain compatible without rebuild. Full flow and limits are in
[VIEWER_DEVELOPMENT_API_v1](VIEWER_DEVELOPMENT_API_v1.md).

## Integrated debugger

GDB/MI supports breakpoints, Continue, Step Into/Over/Out, Pause/Stop and stack-frame selection through the managed Development owner. Read-only opaque variable identities provide real struct/array children: all aggregates initially collapsed; click to expand vertical fields/elements, click again to collapse. Children load only on request, in pages of at most64; maximum depth8 and512 displayed nodes per stop/frame. A further page is explicit. Each new stop/frame/continuation invalidates old child identities. Unavailable or optimized-out values retain actual debugger diagnostics. No arbitrary GDB console/expression injection is exposed.

Threads and fork/wait are admitted ordinary project logic. This catalog does not promise additional debugger thread-switch or follow-fork controls: the present enumerated control contract remains authoritative. Authors are encouraged to use the integrated debugger for actual development problems and report reproducible CPP_DEBUGGER_BUGs.

## Synchronization fingerprints

Synchronized by validation/dev111_p032_main/prepare_cpp_support.py from the current explicit inputs below. Its --check mode verifies these generated facts before packaging while retaining the reviewed explanatory sections. This is source/SDK declaration inventory; independent scientific, functional, original-ABI and installed-package acceptance remains in the release evidence.

| Input | SHA256 |
| --- | --- |
| `core/development/policy_v1.json` | `7d4c76df5af7e396efcac869cb41697e787fe1ea96cc5f675aef34f59381e0fe` |
| `core/development/sdk/gxtxt_viewer_sdk_v1.hpp` | `02d764696cdaf67db10ea46c6f85138723d4a1d8a16f2d450f9357b25c613893` |
| `core/python/gxtxt_cpp_policy.py` | `0822274b6e3e98ce890eb42be85d916463ff25fbb3bba42a3fb09d4b94f5e5bf` |
| `core/python/gxtxt_viewer_development.py` | `b237bfc9dfecae93762211f520deefe72f76bb6c8d2eb7d5d6b09d23333e26ea` |
| `core/development/sdk/trusted_adapter_v1.cpp` | `37dadd00d75ed67f72de30b6c5f84a71db55059805c65b0e7d4fe9a93264c125` |
| `core/python/gxtxt_viewer_native_worker.py` | `8e31532cca763603dfd61c397e946bb20489c1ccd817372071f6ed3739b369f9` |
| `core/python/gxtxt_viewer_scalar_broker.py` | `007748202c53ad9240df5128662f1a8be12969ced73faec35dd22b1181c87324` |
| `core/python/gxtxt_viewer_cpp_debug.py` | `f74968107fbb00830cded8f51b2b233fbb475008f5ae605117ccfcf566ac4931` |
| `plugins/modules/viewer.development_workspace/api/debugger.tcl` | `6e972051776cde4029f120c2b92a48225d318994f3511536c8393f56cbc2ff9d` |
| `plugins/modules/viewer.development_workspace/api/workspace.tcl` | `90c5eac55c4698d29de77c9125fd761374ef6b8865a50a18ec7a65689a9395e3` |
| `plugins/modules/viewer.development_workspace/api/project_files.tcl` | `f21339f2ffe2d3645fce736df02880c7642947962e43c043dd87007bebf8cf55` |
| `core/tcl/viewer_development_api_v1.tcl` | `b4371f9b4e95db57d2d16d6d2fc0f67f31ef824f8b35d950513db46c60c6520e` |
| `core/tcl/viewer_development_api_browser_v1.tcl` | `3fc519c0d4bf4092f3e631eeaa08246616daed5504c1687d4821054436a55c15` |
| `core/tcl/viewer_development_project_workspace_v1.tcl` | `310b6d9eaa2aee3638ff0b61b436ba8f014f8b7dfc852ffaad86373eddd002a6` |
| `core/tcl/viewer_gui_catalog_v1.tcl` | `a7bad7ea6d9158d7b58632b63991920e361f323b076e9f97c0dd4b8bab3809a4` |
| `core/tcl/viewer_gui_design_v1.tcl` | `036e78ea7347db079c2fdcfac6a447791dd14f1118502eb6bda336017a129c86` |
| `core/tcl/viewer_gui_document_v1.tcl` | `ecc51d4bbd02ee00b2ec26c84be48ac6a568c2389412816c67b3c009685a0d9c` |
| `core/tcl/viewer_workspace_native_v1.tcl` | `106de5006ebede66f69eb3261ac1f3979dc6bbc434320e7d9c8433b0e16f589c` |
| `core/tcl/workspace_scientific_codecs_v1.tcl` | `8c7c40e9314fdaf5f112c894df47a8674c76aaf6359f745f7d8eff5ef5f35144` |
| `core/tcl/ui_field_api_v1.tcl` | `35f103058d8640cd317b4471da660670cf53eb2d60810e79aeb62e43e2585a07` |
| `core/tcl/ui_field_viewer_regions_v1.tcl` | `c08985b0fa542c9772eee3c7e643b677c1b108a76661d860a7b6f774918fb15c` |
| `core/tcl/viewer_development_request.tcl` | `96d0c8b2f7c72d79ba7553302cba460814ecdc23aea8a760233cefcb553d0c58` |
| `core/tcl/script_job_api_v1.tcl` | `d829077d0473ad5c3606a4dc6e01378aaf6f22c955713cc93835e47a92bb478e` |
| `core/tcl/plugin_install_api_v1.tcl` | `a2f0bfc7bcc310fe6fa799afea7133c7ab57830a3a266228b39149c2c873792f` |
| `core/tcl/viewer_dataset_producer_v1.tcl` | `08e9c1811e3c694b0d4bfe32797ca26fc014c5bd4e52cf004c8333f0a1981e9e` |
| `core/tcl/dataset_group_api_v1.tcl` | `9157fa531dc85d0e52d663f90886e89e62c59d1374bb79461ffd4dff862ed05f` |
| `core/tcl/dataset_publication_api_v2.tcl` | `3b9c0d81fc116e9880345b3a5de08cbb28726536160d86053021db5a16b18e03` |
| `core/python/gxtxt_script_bridge_server.py` | `49159939ec80d4ac775bd3d7cf3e530289c1efcddd7fe8d105901fc716326ac7` |
| `core/tcl/workbench_extension_api_v1.tcl` | `c72d0a47e92042c6e520ed62d4647be44b1599f5c37fd91590808c80978dfede` |
| `core/tcl/uml_document_api_v1.tcl` | `dc8647a8e9591675ca300ad30f24e94aea351152c37a6a5767b33983bbfe323a` |
| `core/tcl/uml_editor_v1.tcl` | `a79d34c59c7098f823545ace8c86da058d31da816966c3e72e258ffef1b999a4` |
| `core/tcl/document_edit_v1.tcl` | `5591ab755eb37b0ca25fb92c73b4a7f16dc3659f3861bb00b425e6c9ec6801fa` |
| `core/tcl/markdown_navigation_v1.tcl` | `546fdc04abc4e0b56f3f751ee384e4d5f035ec6474d632d0d0b7386a303b5505` |
| `core/tcl/dataset_notes_api_v1.tcl` | `00df9699ca4ed5da7c53667c0a89edef1877b2fbec36477a5cc882bc81b19330` |
| `core/tcl/viewer_development_preview_v1.tcl` | `5b6d6f0fa2ed6fa9aa2df796fbdf30b77f29b4827995a4ca1532806c97a333e1` |
| `app/gui/dataset_preview_live.tcl` | `e34bd8af4b34e9984101d1ebd04e9af7c939260f4c8442abbce29b70ac2864a2` |
| `core/tcl/dataset_preview_provider_v1.tcl` | `a8e9cf77c88479d419496311f13721bc39e97a62fd32498a2040e5c08662916e` |
| `core/development/sdk/gxtxt_acquisition_sdk_v1.hpp` | `fddbc88d8b9885e88bde6ee225c6b0b039a150be6fbd381c5802f7a8c3258152` |
| `core/development/sdk/trusted_acquisition_adapter_v1.cpp` | `e746d25d628c929e321fc403c4937a14d6d0c587caab5327c2f2e90d47b2aa71` |
| `core/development/acquisition_policy_v1.json` | `7f50f308ba02f1efad783945edaf51ba1a8805c2a92eaa62feecbb894e1dc390` |
| `core/python/gxtxt_acquisition_project_v1.py` | `adce5f43b515df084088f7522d96c306c754925deb447baf8e82524527f4ba37` |
| `core/python/gxtxt_acquisition_cpp_v1.py` | `90455714bd62372f36053c53f2e8287f1d07a7a72739b35cfe1fc3ae7fc39947` |
| `core/python/gxtxt_acquisition_development_v1.py` | `638a0e78fd1aff6c0a14ef2919bef215026d956ec7278d5d341ee3040097906d` |
| `core/python/gxtxt_acquisition_source_v1.py` | `b095454a30e916ebe97c08984d81fc6314d6d67e22ed081ac35a9498815fe58f` |
| `core/python/gxtxt_acquisition_output_v1.py` | `5c84e6aa6d616e83c5db8645b6fea9f99b32e963e251e24099c149745505f59f` |
| `core/python/gxtxt_acquisition_broker_v1.py` | `9134b667257d8df0b8dc32ccf4a411d3a638818dc5e2bc93a6889d905e163247` |
| `core/python/gxtxt_acquisition_native_worker_v1.py` | `9a6f1afaaa6e1d94266ac6d5328b303e0ecb47328182e082c8eac40603f49580` |
| `core/python/gxtxt_acquisition_host_service_v1.py` | `e84d38209121d7c0f6b70b18234bd7e8de5830bf708640774a209e7b60fcd5c6` |
| `core/python/gxtxt_acquisition_helper_broker_v1.py` | `d76c7a886b1f659a378382040d7751066d92429719a7181514a9ff7bd89bca36` |
| `core/python/gxtxt_acquisition_helper_worker_v1.py` | `36aa3eb7aedde00f2ea13c6932b23f3332447d5256a20e67b78c9458e08b875b` |
| `core/python/gxtxt_acquisition_project_test_v1.py` | `56d3d9436db9f9bcf0872cfeeb6c839ce2ff3c53a489b1fca5d8209f41452957` |
| `core/python/gxtxt_preview_generation_v1.py` | `4605667fe7578b12df087907540bc9888156eb7844e499a2afb115fda3cd638c` |
| `core/python/gxtxt_native_read_policy_v1.py` | `5d440c9bc178e0953b5cf7fa9609c777bfbfbd2062e33e0bcd21f7555ba01be3` |
| `core/tcl/acquisition_native_v1.tcl` | `9c65a90cee76c5da9b3f1d2f7e3009d0be27ee2ac2175f91ac4c8e6fe5e12c9b` |
| `core/tcl/acquisition_publication_v1.tcl` | `6d46e091c0f3712ddbc01b48cf7285012661f9a992c802aa37204d3948be9003` |
| `core/tcl/viewer_development_acquisition_test_v1.tcl` | `0588e29d9e49601164ba2fa71779e0d8ba37a5d2fa51ae98d9ca1397167ffdf3` |
| `core/tcl/viewer_development_preview_numeric_v1.tcl` | `2cd790263d8bf6db91d177c85f61a56e5e54c76268eab042b6090033f16ba648` |
| `core/tcl/viewer_gui_numeric_preview_authoring_v1.tcl` | `d7022e1d1a4e3df3819c9ab18db3e6e1d0b9ca58e662f7e191c35dba3c822e3f` |
| `core/tcl/configuration_modules_v1.tcl` | `e1b182aa1c8079cc5b78d369223f1bac05943f5d1eff3c80ee9b7187ffd2e39d` |
| `plugins/modules/viewer.development_workspace/api/acquisition_project.tcl` | `2f8509aed452410624fe512f95121bfada356e00c1d6831b544b93a67c3e502d` |
| `app/gui/acquisition_plugin_builder_dialog.tcl` | `f31def6b6bda2307f68e6735bd71c00ec0a2892af89e57f8a3ebbcbe3e093deb` |
| `plugins/modules/viewer.interface_builder/api/builder.tcl` | `3d317e618198eff44ff927509a04692c1874beb5be3bd86caf42a9976b56d903` |
| `core/tcl/dataset_preview_gui_v1.tcl` | `17c405ec57d11891232bddb6a718f91f5b6b8a9d47f4e64abeb1883dd57108b3` |

## UML Document client

ABI-v1 `Host.document_bind`/`Host.document_command` (operations26/41) add declared
`kind=uml`, with `mode=read_only|editable` and readonly `pane=diagram|source|metadata`.
The current `document_view_v1` policy admits explicit `UML_DOCUMENT_API_v1` grants:
`umlDocumentRead`, `umlDocumentParse`, `umlDocumentLayout`, `umlDocumentEdit`,
`umlDocumentWrite`, `umlDocumentExport`. Read/Parse/Layout are the minimum; edits,
canonical saves and exports require their corresponding extra operation. A kind
or SDK call-list declaration never supplies a grant. Actual design admission and
each finite native intent enforce them. Same-ID save also retains original
Document producer/grant/Session/full-revision/source-SHA/namespace checks.

C++ routes primary actions; shared CORE owns literal SourceSurface, semantic
parser/editor, Native2D shaped painter, File Publication and typed UML draft
Workspace/History. No source body, Tcl, renderer path or new native ABI is added.
New finite action names and exact bounded subset are documented in
[UML Document API](UML_DOCUMENT_API_v1.md). Existing native Markdown packages and
old ABI signatures remain unchanged; actual old-package smoke and genuine
Builder-authored UML modules are separate acceptance gates.

## Acquisition target (P032 additive)

The genuine `acquisition_v1` target uses a separate
`gxtxt_acquisition_sdk_v1.hpp` and finite compiler-checked free callback factory;
it does not change this catalog's original Viewer SDK or ABI. Module/profile
capabilities name exact operations of `ACQUISITION_HANDLER_PLUGIN_API_v1`:
source_info, source_read, progress, cancelled, prepare_output, output_write,
output_finish, helper_call. Actual CORE admission intersects profile/module/
phase grants. The metadata browser exposes only this target's actual typed
methods and current saved closure, without compiling or activating a grant.

Selected source bytes use a separate live CORE broker; native actors receive no
source paths/FDs. Typed numeric chunks remain local in CORE-created write-only
buffers, with provisional references and existing Publication/RAW/Group owners.
The new target alone requires pre-CDLL Landlock and seccomp process restrictions;
ordinary same-process threads remain supported, fork/process descendants do not.
See [Native Acquisition SDK](NATIVE_ACQUISITION_SDK_v1.md) for exact signatures,
limits, staged-output handshake and actual registered Python/Tcl helper
dispatcher under the same Acquisition Job. Module/profile capabilities and
live roster/source/lease admission remain mandatory; helper presence alone
grants nothing. Source Note and independent runtime qualification stay separate.
Discovery is not functional acceptance or proof of normal installation.
