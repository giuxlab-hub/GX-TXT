# Script Module Builder 1.1.0

Official GX-TXT Modules-page tool for packaging exact GNU Octave `.m` and Python `.py` research scripts as ordinary Analysis modules.

The Builder reads `GX-TXT-ANALYSIS-SOURCES-V1` comments statically, displays the declared sources, and emits the normal Analysis Source Map descriptor. Conflicting manual source settings require an explicit choice.

Open **Modules → Script Module Builder…**, or run `python3 tools/gxtxt_module_builder.py gui` from the framework root. The command-line `validate` and `build` actions use the same builder implementation.

See [MANUAL.md](MANUAL.md) and [the researcher guide](../../../docs/help/script_module_builder.md).

Version 1.2.0 adds optional public Experiment Duplication Policy authoring. See MANUAL.md. Requires policy v1 capability (earliest known dev079); legacy modules do not require adoption.
