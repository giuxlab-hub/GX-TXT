# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only exact P033 overlay verification; bundled Modules need no reinstall."""
from pathlib import Path
import argparse,json,sys,zipfile
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from release_common import GuardError,NOTES,archive_data,guard_baseline,root_path,sha

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('framework',type=Path)
    parser.add_argument('archive',type=Path)
    parser.add_argument('--sha256',help='Externally verified P033 ZIP SHA256; otherwise adjacent sidecar required')
    args=parser.parse_args()
    root=root_path(args.framework)
    manifest,closure,rows,data,entries=archive_data(args.archive,args.sha256)
    # framework_min=dev111 cannot distinguish P032 from P033. Reuse the exact
    # finite overlay authority rather than guessing from a version or API name.
    guard_baseline(root,closure,rows,rollback=True)
    matrix=json.loads(data[NOTES + '/MODULE_VERSION_MATRIX.json'])
    print(json.dumps(dict(status='PASS',source_commit=manifest['source_commit'],archive_sha256=sha(args.archive),exact_host_postimages=True,companion_modules=matrix['modules'],module_action='already_bundled_install_not_required',authorizes_companion_reinstall=False,installed=False,activated=False),indent=2))

if __name__=='__main__':
    try:main()
    except (GuardError,OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as error:
        raise SystemExit('REFUSED: '+str(error))
