# SPDX-License-Identifier: GPL-3.0-or-later
"""P033 finite file-overlay guards. No runtime, Session or configuration owner."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, stat, tempfile, zipfile
from contextlib import contextmanager

PATCH = 'DEV111-P033'
ARCHIVE = PATCH + '.zip'
RELEASE_REVISION = 1
BASE = 'fc672ead2755c316025711b9915fdcd6beef4909'
BASE_SHA = '96ad229a771a519c8e45026dd70770581942ec2a3531915098d31c7f00d5f31b'
NOTES = 'patch_notes/' + PATCH
MAX_FILE = 128 * 1024 * 1024
MAX_ZIP = 512 * 1024 * 1024

class GuardError(RuntimeError):
    pass

def require(test, message):
    if not test:
        raise GuardError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def relative(name):
    require(isinstance(name, str) and name and len(name) <= 4096 and '\\' not in name and ':' not in name and not any(ord(c) < 32 for c in name), 'Unsafe relative path')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(part not in ('', '.', '..') for part in name.split('/')), 'Unsafe relative path: ' + name)
    return p

SPECIAL = {'gxtxt_pipeline.tcl', 'VERSION.txt', 'PATCH_LEVEL.txt', 'GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'LICENSE'}
SKIP = {'tests', 'validation', 'evidence', 'review', 'archives', 'archive', '__pycache__', '.git', 'node_modules', 'scratch'}

def runtime_path(name):
    p = relative(name)
    # Exact owner-supplied module includes inert tests/documentation unchanged.
    if name.startswith(('plugins/modules/viewer.curve_digitizer/', 'plugins/modules/preview.curve_digitizer/')):
        return True
    # These are installed Native Viewer admission/source receipts, not campaign
    # evidence. Omitting them would pair a new binary with an old build identity.
    if len(p.parts) == 5 and p.parts[:2] == ('plugins', 'modules') and p.parts[3] == 'review' and p.parts[4] in ('build.json', 'validation.json'):
        return True
    if any(x.lower() in SKIP for x in p.parts) or name.lower().endswith(('.zip', '.tar', '.gz', '.xz', '.bz2', '.7z', '.pyc', '.log')):
        return False
    return name in SPECIAL or name.startswith(('app/', 'core/', 'plugins/', 'docs/api/', 'services/', 'docs/development/dev111_p033/'))

MODULES = {
    'analysis.python_script': '1.6.3', 'analysis.octave_script': '1.8.3',
    'tool.script_module_builder': '1.4.7', 'contract.scientific_measurement': '1.0.0',
    'acq.scientific_measurement': '1.0.2', 'viewer.script_library': '1.0.4',
    'preview.scientific_spectrum': '1.0.1', 'preview.scientific_trace': '1.0.1',
    'preview.scientific_frame': '1.0.1', 'domain.scientific_spectra': '1.1.0',
}
ORIGINAL_MODULES = {'acq.scientific_measurement', 'viewer.script_library',
    'preview.scientific_spectrum', 'preview.scientific_trace',
    'preview.scientific_frame', 'domain.scientific_spectra'}

# Inherited unchanged; this metadata grants no functional test acceptance.
OWNER_MODULE = 'viewer.curve_digitizer'
OWNER_QUALIFICATION = 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST'
OWNER_QUALIFICATIONS = {OWNER_MODULE: OWNER_QUALIFICATION}
# P032 original inputs are inherited through its exact closure, never delivered again.
SUPPLIED_INPUT_ARCHIVES = {}
ORIGINAL_PACKAGE_SHA = {'acq.scientific_measurement': '438fb8c474bfba8eccf88399d716e3906979a5e51a6bf0f7441ed011cc788cb3', 'viewer.script_library': '4320405e468bfb5ab93018c22f7e910d03a485da1983fd27b98141090a277320', 'preview.scientific_spectrum': '8e95ebf19645563e120c51cc1af9108f8eba870eba523cbfc176a6a5c4c56b35', 'preview.scientific_trace': 'e7d781ff40c74399fdad28a3a9fb86211b62271b216e97213c2c5a9833ffd781', 'preview.scientific_frame': '70c6521ca9f342987845aa2b0d07ece8d9d1c1371a1b1ae7ff60a6406edd26f3', 'domain.scientific_spectra': 'aae6c6670b89e4c6b5c85fc8e816fa556421cf9e3bcaca48e574d02ca6f152e0'}

def module_archive_name(module, version):
    return module + '_' + version + '.zip'

BASE_ZIP = Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV111-P032.zip')
NOTE_FILES = {'FILES.json', 'BASELINE.json', 'BUILD_IDENTITY.json', 'MODULE_VERSION_MATRIX.json',
              'DELETIONS.json', 'README.md', 'apply.py', 'rollback.py', 'release_common.py',
              'companion_preflight.py', 'PAYLOAD_SHA256SUMS', 'SUPPLIED_INPUTS.json'}

# Exact reviewed P033 product paths; extend explicitly after coherent source review.
PAYLOAD_SCOPE = frozenset(['GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'PATCH_LEVEL.txt', 'app/dataset_page_actions.tcl', 'app/gui/acquisition_page.tcl', 'app/gui/dataset_browser.tcl', 'app/gui/dataset_preview_live.tcl', 'app/gui/script_library_dialog.tcl', 'app/script_project_canvas.tcl', 'app/script_provided_inventory_request.tcl', 'app/script_source_notes.tcl', 'app/script_source_tabs.tcl', 'app/script_workspace_surface.tcl', 'app/session_menus_dev065.tcl', 'core/api_catalog/catalog.sqlite', 'core/api_catalog/source_manifest.json', 'core/development/acquisition_policy_v1.json', 'core/development/policy_v1.json', 'core/development/sdk/gxtxt_acquisition_sdk_v1.hpp', 'core/development/sdk/gxtxt_viewer_sdk_v1.hpp', 'core/development/sdk/trusted_acquisition_adapter_v1.cpp', 'core/development/sdk/trusted_adapter_v1.cpp', 'core/native2d/bin/BUILD_RECEIPT_P033.json', 'core/native2d/bin/gx2dtcl.so', 'core/native2d/gx2d_plot_v4.cpp', 'core/octave/analysis_octave_script_main.m', 'core/octave/gxtxt_script_provided_execute.m', 'core/octave/util/gxtxt_api_export.m', 'core/octave/util/gxtxt_api_require.m', 'core/octave/util/gxtxt_script_bridge_internal.m', 'core/python/gxtxt/__init__.py', 'core/python/gxtxt_acquisition_broker_v1.py', 'core/python/gxtxt_acquisition_development_v1.py', 'core/python/gxtxt_acquisition_host_service_v1.py', 'core/python/gxtxt_acquisition_native_worker_v1.py', 'core/python/gxtxt_acquisition_output_v1.py', 'core/python/gxtxt_acquisition_project_test_v1.py', 'core/python/gxtxt_acquisition_sdk_compat_v1.py', 'core/python/gxtxt_acquisition_spectrum_v1.py', 'core/python/gxtxt_python_script_execution.py', 'core/python/gxtxt_script_inspection.py', 'core/python/gxtxt_script_provided_runtime.py', 'core/python/gxtxt_source_structure.py', 'core/python/gxtxt_viewer_development.py', 'core/python/gxtxt_viewer_native_worker.py', 'core/python/scientific_library_graph.py', 'core/python/scientific_spectrum_import.py', 'core/python/script_api_exports.py', 'core/python/script_project.py', 'core/script_bindings/script_execution.py', 'core/tcl/acquisition_handler_api_v1.tcl', 'core/tcl/acquisition_managed_v1.tcl', 'core/tcl/acquisition_native_v1.tcl', 'core/tcl/acquisition_publication_v1.tcl', 'core/tcl/acquisition_spectrum_validation_v1.tcl', 'core/tcl/dataset_preview_api_v1.tcl', 'core/tcl/dataset_preview_cache.tcl', 'core/tcl/dataset_preview_gui_v1.tcl', 'core/tcl/dataset_preview_numeric_gui_v1.tcl', 'core/tcl/dataset_preview_paging_v1.tcl', 'core/tcl/dataset_publication_api_v2.tcl', 'core/tcl/document_editor_ui_v1.tcl', 'core/tcl/interactive_document_resource_api_v1.tcl', 'core/tcl/module_api_v1.tcl', 'core/tcl/plugin_install_api_v1.tcl', 'core/tcl/resource_lifecycle_api_v1.tcl', 'core/tcl/scientific_dataset_preview_v1.tcl', 'core/tcl/scientific_history_native.tcl', 'core/tcl/scientific_library_manager_api_v1.tcl', 'core/tcl/scientific_recipe_history.tcl', 'core/tcl/scientific_spectrum_api_v1.tcl', 'core/tcl/scientific_spectrum_import_api_v1.tcl', 'core/tcl/script_execution_api_v1.tcl', 'core/tcl/script_job_request.tcl', 'core/tcl/script_library_history_v1.tcl', 'core/tcl/script_library_host_v1.tcl', 'core/tcl/script_library_launch_v1.tcl', 'core/tcl/script_module_runner_v1.tcl', 'core/tcl/script_project_v1.tcl', 'core/tcl/script_provided_api_v1.tcl', 'core/tcl/script_provided_runtime_v1.tcl', 'core/tcl/script_registry_identity_v1.tcl', 'core/tcl/script_registry_transactions_v1.tcl', 'core/tcl/script_source_authoring_v1.tcl', 'core/tcl/session_file_explorer_api_v1.tcl', 'core/tcl/source_surface_api_v1.tcl', 'core/tcl/ui_field_api_v1.tcl', 'core/tcl/ui_field_table_original_v1.tcl', 'core/tcl/ui_field_viewer_regions_v1.tcl', 'core/tcl/viewer_development_api_v1.tcl', 'core/tcl/viewer_development_preview_numeric_v1.tcl', 'core/tcl/viewer_development_request.tcl', 'core/tcl/viewer_gui_catalog_v1.tcl', 'core/tcl/viewer_gui_design_v1.tcl', 'core/tcl/viewer_gui_numeric_preview_authoring_v1.tcl', 'core/tcl/viewer_gui_role_maps_v1.tcl', 'core/tcl/viewer_native_clients_v1.tcl', 'core/tcl/viewer_scientific_frame_v1.tcl', 'core/tcl/viewer_scientific_preview_v1.tcl', 'core/tcl/viewer_script_library_workspace_v1.tcl', 'core/tcl/workbench_extension_api_v1.tcl', 'docs/api/ACQUISITION_HANDLER_PLUGIN_API_v1.md', 'docs/api/ACQUISITION_PUBLICATION_API_v1.md', 'docs/api/CPP_SUPPORT_CATALOG.md', 'docs/api/PLOT_DATASET_API_v4.md', 'docs/api/PREVIEW_COMPONENT_GUI_API_v1.md', 'docs/api/SCIENTIFIC_LIBRARY_DOMAINS_API_v1.md', 'docs/api/SCIENTIFIC_PREVIEW_NATIVE_CLIENT_v1.md', 'docs/api/SCIENTIFIC_RECIPE_API_v1.md', 'docs/api/SCIENTIFIC_SPECTRUM_IMPORT_API_v1.md', 'docs/api/SCIENTIFIC_SPECTRUM_PAGED_VALIDATION_v1.md', 'docs/api/SCRIPT_BRIDGE_COVERAGE_v1.json', 'docs/api/SCRIPT_EXECUTION_API_v1.md', 'docs/api/SCRIPT_LIBRARY_API_v1.md', 'docs/api/SCRIPT_PROJECTS_v1.md', 'docs/api/SCRIPT_PROVIDED_API_INVENTORY_v1.md', 'docs/api/SCRIPT_PROVIDED_API_RUNTIME_v1.md', 'docs/api/SCRIPT_REGISTRY_IDENTITY_v1.md', 'docs/api/SOURCE_SURFACE_API_v1.md', 'docs/api/UI_FIELD_API_v1.md', 'docs/api/VIEWER_DEVELOPMENT_API_v1.md', 'docs/api/VIEWER_GUI_CLIENT_ROLE_MAPS_v1.md', 'docs/development/dev111_p033/CONTRACT_FAMILY_AUDIT_P033.md', 'docs/development/dev111_p033/OWNER_REQUIREMENTS_CROSSWALK_P033.md', 'docs/development/dev111_p033/SCIENTIFIC_ACQUISITION_ORIGINAL_PACKAGE.md', 'gxtxt_pipeline.tcl', 'plugins/modules/acq.scientific_measurement/CHANGELOG.md', 'plugins/modules/acq.scientific_measurement/LICENSE', 'plugins/modules/acq.scientific_measurement/MANUAL.md', 'plugins/modules/acq.scientific_measurement/RESTRICTED_ACQUISITION_PROVENANCE.json', 'plugins/modules/acq.scientific_measurement/SHA256SUMS.txt', 'plugins/modules/acq.scientific_measurement/module.ini', 'plugins/modules/acq.scientific_measurement/native/ACQUISITION_SDK_CONTRACT.json', 'plugins/modules/acq.scientific_measurement/native/acquisition-factory.cpp', 'plugins/modules/acq.scientific_measurement/native/acquisition.so', 'plugins/modules/acq.scientific_measurement/native/gxtxt_acquisition_sdk_v1.hpp', 'plugins/modules/acq.scientific_measurement/native/trusted_acquisition_adapter_v1.cpp', 'plugins/modules/acq.scientific_measurement/plugin-package.ini', 'plugins/modules/acq.scientific_measurement/review/build.json', 'plugins/modules/acq.scientific_measurement/review/validation.json', 'plugins/modules/acq.scientific_measurement/source/SOURCE_MANIFEST.json', 'plugins/modules/acq.scientific_measurement/source/handlers.cpp', 'plugins/modules/acq.scientific_measurement/source/include/measurement.hpp', 'plugins/modules/acq.scientific_measurement/source/include/prf_decoder.hpp', 'plugins/modules/acq.scientific_measurement/source/include/sif_decoder.hpp', 'plugins/modules/acq.scientific_measurement/source/include/source_metadata.hpp', 'plugins/modules/acq.scientific_measurement/source/include/sp_decoder.hpp', 'plugins/modules/acq.scientific_measurement/source/project.json', 'plugins/modules/acq.scientific_measurement/source/src/prf.cpp', 'plugins/modules/acq.scientific_measurement/source/src/prf_container.cpp', 'plugins/modules/acq.scientific_measurement/source/src/sif.cpp', 'plugins/modules/acq.scientific_measurement/source/src/sp.cpp', 'plugins/modules/analysis.octave_script/CHANGELOG.md', 'plugins/modules/analysis.octave_script/MANUAL.md', 'plugins/modules/analysis.octave_script/SHA256SUMS.txt', 'plugins/modules/analysis.octave_script/module.ini', 'plugins/modules/analysis.octave_script/plugin-package.ini', 'plugins/modules/analysis.octave_script/ui/octave_script_editor_ui.tcl', 'plugins/modules/analysis.python_script/CHANGELOG.md', 'plugins/modules/analysis.python_script/MANUAL.md', 'plugins/modules/analysis.python_script/SHA256SUMS.txt', 'plugins/modules/analysis.python_script/module.ini', 'plugins/modules/analysis.python_script/plugin-package.ini', 'plugins/modules/analysis.python_script/ui/python_script_editor_ui.tcl', 'plugins/modules/contract.scientific_measurement/LICENSE', 'plugins/modules/contract.scientific_measurement/README.md', 'plugins/modules/contract.scientific_measurement/SHA256SUMS.txt', 'plugins/modules/contract.scientific_measurement/module.ini', 'plugins/modules/contract.scientific_measurement/plugin-package.ini', 'plugins/modules/domain.scientific_spectra/CHANGELOG.md', 'plugins/modules/domain.scientific_spectra/LICENSE', 'plugins/modules/domain.scientific_spectra/README.md', 'plugins/modules/domain.scientific_spectra/SHA256SUMS.txt', 'plugins/modules/domain.scientific_spectra/api/measurement_description.py', 'plugins/modules/domain.scientific_spectra/api/spectrum_validation.py', 'plugins/modules/domain.scientific_spectra/module.ini', 'plugins/modules/domain.scientific_spectra/plugin-package.ini', 'plugins/modules/domain.scientific_spectra/schema.json', 'plugins/modules/preview.scientific_frame/LICENSE', 'plugins/modules/preview.scientific_frame/MANUAL.md', 'plugins/modules/preview.scientific_frame/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/preview.scientific_frame/SHA256SUMS.txt', 'plugins/modules/preview.scientific_frame/api/viewer.tcl', 'plugins/modules/preview.scientific_frame/gui/design.tcldict', 'plugins/modules/preview.scientific_frame/handlers.tcl', 'plugins/modules/preview.scientific_frame/module.ini', 'plugins/modules/preview.scientific_frame/native/SDK_CONTRACT.json', 'plugins/modules/preview.scientific_frame/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/preview.scientific_frame/native/trusted_adapter_v1.cpp', 'plugins/modules/preview.scientific_frame/native/viewer.so', 'plugins/modules/preview.scientific_frame/plugin-package.ini', 'plugins/modules/preview.scientific_frame/review/build.json', 'plugins/modules/preview.scientific_frame/review/validation.json', 'plugins/modules/preview.scientific_frame/source/MANUAL.md', 'plugins/modules/preview.scientific_frame/source/SOURCE_MANIFEST.json', 'plugins/modules/preview.scientific_frame/source/design.gxtxt-viewer', 'plugins/modules/preview.scientific_frame/source/handlers.cpp', 'plugins/modules/preview.scientific_frame/source/include/scientific_preview_routing.hpp', 'plugins/modules/preview.scientific_frame/source/project.json', 'plugins/modules/preview.scientific_spectrum/LICENSE', 'plugins/modules/preview.scientific_spectrum/MANUAL.md', 'plugins/modules/preview.scientific_spectrum/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/preview.scientific_spectrum/SHA256SUMS.txt', 'plugins/modules/preview.scientific_spectrum/api/viewer.tcl', 'plugins/modules/preview.scientific_spectrum/gui/design.tcldict', 'plugins/modules/preview.scientific_spectrum/handlers.tcl', 'plugins/modules/preview.scientific_spectrum/module.ini', 'plugins/modules/preview.scientific_spectrum/native/SDK_CONTRACT.json', 'plugins/modules/preview.scientific_spectrum/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/preview.scientific_spectrum/native/trusted_adapter_v1.cpp', 'plugins/modules/preview.scientific_spectrum/native/viewer.so', 'plugins/modules/preview.scientific_spectrum/plugin-package.ini', 'plugins/modules/preview.scientific_spectrum/review/build.json', 'plugins/modules/preview.scientific_spectrum/review/validation.json', 'plugins/modules/preview.scientific_spectrum/source/MANUAL.md', 'plugins/modules/preview.scientific_spectrum/source/SOURCE_MANIFEST.json', 'plugins/modules/preview.scientific_spectrum/source/design.gxtxt-viewer', 'plugins/modules/preview.scientific_spectrum/source/handlers.cpp', 'plugins/modules/preview.scientific_spectrum/source/include/scientific_preview_routing.hpp', 'plugins/modules/preview.scientific_spectrum/source/project.json', 'plugins/modules/preview.scientific_trace/LICENSE', 'plugins/modules/preview.scientific_trace/MANUAL.md', 'plugins/modules/preview.scientific_trace/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/preview.scientific_trace/SHA256SUMS.txt', 'plugins/modules/preview.scientific_trace/api/viewer.tcl', 'plugins/modules/preview.scientific_trace/gui/design.tcldict', 'plugins/modules/preview.scientific_trace/handlers.tcl', 'plugins/modules/preview.scientific_trace/module.ini', 'plugins/modules/preview.scientific_trace/native/SDK_CONTRACT.json', 'plugins/modules/preview.scientific_trace/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/preview.scientific_trace/native/trusted_adapter_v1.cpp', 'plugins/modules/preview.scientific_trace/native/viewer.so', 'plugins/modules/preview.scientific_trace/plugin-package.ini', 'plugins/modules/preview.scientific_trace/review/build.json', 'plugins/modules/preview.scientific_trace/review/validation.json', 'plugins/modules/preview.scientific_trace/source/MANUAL.md', 'plugins/modules/preview.scientific_trace/source/SOURCE_MANIFEST.json', 'plugins/modules/preview.scientific_trace/source/design.gxtxt-viewer', 'plugins/modules/preview.scientific_trace/source/handlers.cpp', 'plugins/modules/preview.scientific_trace/source/include/scientific_preview_routing.hpp', 'plugins/modules/preview.scientific_trace/source/project.json', 'plugins/modules/tool.script_module_builder/CHANGELOG.md', 'plugins/modules/tool.script_module_builder/MANUAL.md', 'plugins/modules/tool.script_module_builder/README.md', 'plugins/modules/tool.script_module_builder/SHA256SUMS', 'plugins/modules/tool.script_module_builder/SHA256SUMS.txt', 'plugins/modules/tool.script_module_builder/module.ini', 'plugins/modules/tool.script_module_builder/plugin-package.ini', 'plugins/modules/tool.script_module_builder/runtime/builder.py', 'plugins/modules/viewer.script_library/LICENSE', 'plugins/modules/viewer.script_library/MANUAL.md', 'plugins/modules/viewer.script_library/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/viewer.script_library/SHA256SUMS.txt', 'plugins/modules/viewer.script_library/api/viewer.tcl', 'plugins/modules/viewer.script_library/gui/design.tcldict', 'plugins/modules/viewer.script_library/handlers.tcl', 'plugins/modules/viewer.script_library/module.ini', 'plugins/modules/viewer.script_library/native/SDK_CONTRACT.json', 'plugins/modules/viewer.script_library/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/viewer.script_library/native/trusted_adapter_v1.cpp', 'plugins/modules/viewer.script_library/native/viewer.so', 'plugins/modules/viewer.script_library/plugin-package.ini', 'plugins/modules/viewer.script_library/review/build.json', 'plugins/modules/viewer.script_library/review/validation.json', 'plugins/modules/viewer.script_library/source/MANUAL.md', 'plugins/modules/viewer.script_library/source/SOURCE_MANIFEST.json', 'plugins/modules/viewer.script_library/source/design.gxtxt-viewer', 'plugins/modules/viewer.script_library/source/handlers.cpp', 'plugins/modules/viewer.script_library/source/project.json'])

def payload_path(name):
    relative(name)
    return name in PAYLOAD_SCOPE

def root_path(root):
    root = Path(os.path.abspath(root))
    for p in [*reversed(root.parents), root]:
        require(not p.is_symlink(), 'Linked framework root/ancestor: ' + str(p))
    require(root.is_dir(), 'Existing canonical framework directory required')
    return root

def member(root, name):
    current = root
    parts = relative(name).parts
    for index, part in enumerate(parts):
        current = current / part
        require(not current.is_symlink(), 'Linked target/ancestor: ' + str(current))
        if current.exists() and index < len(parts)-1:
            require(current.is_dir(), 'Non-directory ancestor: ' + str(current))
    return current

def identity(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return None
    require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1, 'Nonregular/linked target: ' + str(path))
    return {'sha256': sha(path), 'mode': stat.S_IMODE(st.st_mode), 'size': st.st_size}

def matches(actual, expected):
    return actual == expected

def zip_index(z):
    entries = {}
    directories = set()
    for item in z.infolist():
        require(not item.flag_bits & 1, 'Encrypted ZIP unsupported')
        name = item.filename.rstrip('/') if item.is_dir() else item.filename
        relative(name)
        require(name not in entries and name not in directories, 'Duplicate ZIP member: ' + name)
        mode = item.external_attr >> 16
        if item.is_dir():
            require(stat.S_IFMT(mode) in (0, stat.S_IFDIR), 'Invalid ZIP directory')
            directories.add(name)
            continue
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG) and not stat.S_ISLNK(mode), 'Nonregular ZIP member: ' + name)
        require(item.file_size <= MAX_FILE, 'Oversized ZIP member: ' + name)
        entries[name] = item
    require(sum(x.file_size for x in entries.values()) <= MAX_ZIP, 'ZIP exceeds patch bound')
    for name in set(entries) | directories:
        require(all(str(p) not in entries for p in PurePosixPath(name).parents if str(p) != '.'), 'ZIP file/directory collision')
    require(z.testzip() is None, 'ZIP CRC failure')
    return entries

def file_record(value, nullable=False):
    if value is None:
        require(nullable, 'Required file identity is absent')
        return
    require(isinstance(value, dict) and set(value) == {'sha256', 'mode', 'size'}, 'Invalid file identity fields')
    require(isinstance(value['sha256'], str) and len(value['sha256']) == 64 and all(c in '0123456789abcdef' for c in value['sha256']), 'Invalid SHA256')
    require(type(value['mode']) is int and 0 <= value['mode'] <= 0o777, 'Invalid file mode')
    require(type(value['size']) is int and 0 <= value['size'] <= MAX_FILE, 'Invalid file size')

def validate(manifest, closure):
    require(isinstance(manifest, dict) and isinstance(closure, dict), 'Manifest/closure must be objects')
    require(manifest.get('schema') == 'gxtxt.dev111.p033.overlay.v1' and manifest.get('patch') == PATCH and manifest.get('baseline_patch') == 'DEV111-P032' and manifest.get('baseline_commit') == BASE and manifest.get('baseline_archive_sha256') == BASE_SHA, 'Wrong patch or exact P032 predecessor identity')
    require(isinstance(manifest.get('source_commit'), str) and len(manifest['source_commit']) == 40 and all(c in '0123456789abcdef' for c in manifest['source_commit']), 'Invalid source commit')
    require(closure.get('schema') == 'gxtxt.dev111.p033.baseline.v1' and closure.get('source_commit') == BASE and closure.get('archive_sha256') == BASE_SHA and isinstance(closure.get('files'), dict) and closure['files'], 'Invalid predecessor closure')
    require('core/tcl/plugin_install_api_v1.tcl' in closure['files'], 'Missing baseline sentinel')
    require(digest(json_bytes(closure)) == manifest.get('baseline_closure_sha256'), 'Baseline closure checksum differs')
    for name, expected in closure['files'].items():
        require(runtime_path(name), 'Non-runtime predecessor path: ' + name); file_record(expected)
    rows = manifest.get('changed_files')
    require(isinstance(rows, list) and rows, 'Nonempty change manifest required')
    seen = set()
    for row in rows:
        require(set(row) == {'path', 'action', 'before', 'after'}, 'Invalid change fields')
        name = row['path'];relative(name)
        require(payload_path(name), 'Protected/non-runtime payload path: ' + name)
        require(name not in seen and not name.startswith('patch_notes/'), 'Duplicate/reserved product path')
        seen.add(name);file_record(row['before'], True);file_record(row['after'], True)
        expected_action = 'add' if row['before'] is None else 'delete' if row['after'] is None else 'replace'
        require(row['action'] == expected_action and row['before'] != row['after'], 'Invalid or unchanged change action')
        require(closure['files'].get(name) == row['before'], 'Change preimage differs from exact baseline closure: ' + name)
    require(manifest.get('deleted_files') == [r['path'] for r in rows if r['after'] is None], 'Deletion list differs')
    return rows

def sums(text):
    result = {}
    for line in text.decode('utf-8').splitlines():
        value, name = line.split('  ', 1);relative(name)
        require(name not in result and len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'Invalid checksum entry')
        result[name] = value
    return result

def archive_data(path, expected_sha=None):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), 'Regular patch ZIP required')
    if expected_sha is None:
        sidecar = Path(str(path) + '.sha256')
        require(not sidecar.is_symlink() and sidecar.is_file(), 'Provide adjacent ZIP.sha256 or --sha256')
        words = sidecar.read_text().split()
        require(len(words) == 2 and words[1] == path.name, 'Invalid archive checksum sidecar')
        expected_sha = words[0]
    require(sha(path) == expected_sha, 'Patch ZIP SHA256 differs')
    with zipfile.ZipFile(path) as z:
        entries = zip_index(z)
        require(NOTES + '/FILES.json' in entries and NOTES + '/BASELINE.json' in entries, 'Missing P033 notes/closure')
        data = {name: z.read(name) for name in entries}
        manifest = json.loads(data[NOTES + '/FILES.json']);closure = json.loads(data[NOTES + '/BASELINE.json'])
        rows = validate(manifest, closure)
        required_notes = {NOTES + '/' + n for n in NOTE_FILES} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
        require({n for n in data if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected P033 notes')
        for name in required_notes:
            if not name.startswith(NOTES + '/rollback-preimages/'):
                require(((entries[name].external_attr >> 16) & 0o777) == 0o644, 'Wrong notes/helper mode: ' + name)
        build = json.loads(data[NOTES + '/BUILD_IDENTITY.json'])
        require(build.get('original_input_archives') == SUPPLIED_INPUT_ARCHIVES,
                'P033 must not introduce original-input archives')
        supplied = json.loads(data[NOTES + '/SUPPLIED_INPUTS.json'])
        require(supplied == {}, 'P033 must not duplicate inherited supplemental inputs')
        require(build.get('patch') == PATCH and build.get('source_commit') == manifest['source_commit']
                and build.get('packaging_helpers_commit') == manifest['source_commit']
                and build.get('baseline_commit') == BASE and build.get('baseline_archive_sha256') == BASE_SHA
                and build.get('native_changes') is True and build.get('packaging_rebuilt_binaries') is False
                and build.get('owner_supplied_qualifications') == OWNER_QUALIFICATIONS,
                'Build/source/helper identity differs')
        for leaf in ('apply.py', 'rollback.py', 'release_common.py', 'companion_preflight.py'):
            expected = build['helper_source_files']['validation/dev111_p033_release/' + leaf]
            file_record(expected)
            raw = data[NOTES + '/' + leaf]
            require(digest(raw) == expected['sha256'] and len(raw) == expected['size'], 'Bundled helper source identity differs: ' + leaf)
        matrix = json.loads(data[NOTES + '/MODULE_VERSION_MATRIX.json'])
        require(matrix.get('patch') == PATCH and len(matrix['modules']) == len(MODULES)
                and {m['module']: m['distribution_version'] for m in matrix['modules']} == MODULES,
                'P033 companion module matrix differs')
        require(json.loads(data[NOTES + '/DELETIONS.json']) == manifest['deleted_files'], 'Deletion notes differ')
        listed = sums(data[NOTES + '/PAYLOAD_SHA256SUMS'])
        require(set(listed) == set(data) - {NOTES + '/PAYLOAD_SHA256SUMS'}, 'Incomplete archive checksums')
        for name, expected in listed.items():
            require(digest(data[name]) == expected, 'Archive checksum differs: ' + name)
        products = {r['path'] for r in rows if r['after'] is not None}
        require(set(data) == products | {n for n in data if n.startswith(NOTES + '/')}, 'Unexpected product member')
        for row in rows:
            for key, name in [('after', row['path']), ('before', NOTES + '/rollback-preimages/' + row['path'])]:
                record = row[key]
                if record is None:
                    continue
                require(name in data and digest(data[name]) == record['sha256'] and len(data[name]) == record['size'] and ((entries[name].external_attr >> 16) & 0o777) == record['mode'], 'Invalid ' + key + ': ' + row['path'])
        return manifest, closure, rows, data, entries

def guard_baseline(root, closure, rows, rollback=False, partial=False):
    changed = {r['path']: r for r in rows}
    for name, expected in closure['files'].items():
        actual = identity(member(root, name));row = changed.get(name)
        if row is None or not rollback:
            require(matches(actual, expected), 'Divergent P032 baseline: ' + name)
    for row in rows:
        actual = identity(member(root, row['path']))
        wanted = row['after'] if rollback else row['before']
        permitted = [wanted, row['before']] if rollback and partial else [wanted]
        require(any(matches(actual, p) for p in permitted), 'Unknown/divergent ' + ('postimage' if rollback else 'preimage') + ': ' + row['path'])

def atomic(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.p033-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data);f.flush();os.fchmod(f.fileno(), mode);os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):os.unlink(temp)

def _apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    manifest, closure, rows, data, entries = archive_data(archive, expected_sha)
    require(not member(root, NOTES).exists(), 'P033 notes already exist; use rollback/recover-partial first')
    guard_baseline(root, closure, rows)
    for name in data:member(root, name)
    if mutate:
        # Publish complete verified rollback information before any product write.
        for name in sorted(data):
            if name.startswith(NOTES + '/'):
                atomic(member(root, name), data[name], (entries[name].external_attr >> 16) & 0o777)
        for row in rows:
            p = member(root, row['path'])
            require(identity(p) == row['before'], 'Preimage changed during apply: ' + row['path'])
            if row['after'] is None:p.unlink()
            else:atomic(p, data[row['path']], row['after']['mode'])
        guard_baseline(root, closure, rows, rollback=True)
    return manifest

def _rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root);notes = member(root, NOTES)
    require(notes.is_dir(), 'Installed P033 notes required')
    manifest_path = member(root, NOTES + '/FILES.json');closure_path = member(root, NOTES + '/BASELINE.json')
    require(identity(manifest_path) is not None and identity(closure_path) is not None, 'Incomplete notes; recover verified notes from the exact archive first')
    manifest = json.loads(manifest_path.read_bytes());closure = json.loads(closure_path.read_bytes());rows = validate(manifest, closure)
    checksum_path = member(root, NOTES + '/PAYLOAD_SHA256SUMS')
    checksum_identity = identity(checksum_path)
    require(checksum_identity is not None and checksum_identity['mode'] == 0o644,
            'Installed checksum manifest must be an unlinked regular0644 file')
    listed = sums(checksum_path.read_bytes())
    required_notes = {NOTES + '/' + n for n in NOTE_FILES - {'PAYLOAD_SHA256SUMS'}} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
    require({n for n in listed if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected installed notes inventory')
    for name, expected in listed.items():
        if name.startswith(NOTES + '/'):
            p = member(root, name)
            require(identity(p) is not None and sha(p) == expected, 'Incomplete/divergent installed notes: ' + name)
            expected_mode = 0o644
            if name.startswith(NOTES + '/rollback-preimages/'):
                product = name[len(NOTES + '/rollback-preimages/'):]
                expected_mode = next(r['before']['mode'] for r in rows if r['path'] == product and r['before'] is not None)
            require(identity(p)['mode'] == expected_mode, 'Installed notes mode differs: ' + name)
    require(NOTES + '/FILES.json' in listed and NOTES + '/BASELINE.json' in listed, 'Unbound installed manifest')
    guard_baseline(root, closure, rows, rollback=True, partial=partial)
    for row in rows:
        if row['before'] is not None:
            p = member(root, NOTES + '/rollback-preimages/' + row['path'])
            require(identity(p) == row['before'], 'Rollback preimage/mode differs: ' + row['path'])
    if mutate:
        for row in reversed(rows):
            p = member(root, row['path']);actual = identity(p)
            require(actual == row['after'] or partial and actual == row['before'], 'Target changed during rollback: ' + row['path'])
            if actual == row['before']:continue
            if row['before'] is None:p.unlink()
            else:
                backup = member(root, NOTES + '/rollback-preimages/' + row['path'])
                atomic(p, backup.read_bytes(), row['before']['mode'])
        guard_baseline(root, closure, rows)
    return manifest

@contextmanager
def operation_lock(root, enabled):
    if not enabled:
        yield
        return
    try:
        import fcntl
    except ImportError as error:
        raise GuardError('Guarded writes require POSIX directory locking; --check remains available') from error
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        try:fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:raise GuardError('Another release helper owns this framework directory') from error
        yield
    finally:os.close(fd)

def apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    with operation_lock(root, mutate):return _apply_overlay(root, archive, mutate, expected_sha)

def rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root)
    with operation_lock(root, mutate):return _rollback_overlay(root, mutate, partial)
