# P033 owner-requirements reconciliation — active implementation crosswalk

This working crosswalk follows accepted/deposited P032 `fc672ead2755c316025711b9915fdcd6beef4909`. P033 remains OPEN/unfrozen after private RC01 source `24176036` (unaccepted), with native Spectrum/Trace and lifecycle corrective acceptance in progress; this document is not final acceptance. The earlier read-ahead draft is retained separately. Before freeze, reconcile the final exact source/packages against every binding original and owner amendment, with A/B receipts and honest retained limits. No TODO item is removed by this crosswalk.

The seven-patch allocation and current intake control the original cascade.
The owner recovery mandate SHA
8719bfdc080d15383e6ed90d686e67af855deed6c48d868b563b9cfa25670e31
supersedes assistant-created post-P035 scheduling for GAP-001/002/003 only.
The Browser mandate SHA
74f4b91febdcb0dc5dc7e9430d7c02b34ddeb717c657ca4ce30e211003143a8b
adds a separate P033 gate. Neither reopens P032 or an accepted release.

## Original cascade and owner amendments

| Stable scope | Status / required disposition | Source and evidence to retain |
| --- | --- | --- |
| EDITOR-MENUS-TABS | Already independently accepted P029, within its actual menu/tab scope. Does not close new-project canvas. | Editor UX specification section5; canonical0029 ACCEPTANCE_A/B.json and handoff; source3673ccc9. |
| R1 SOURCE-NOTES | Already independently accepted P030; exact source-file associations remain distinct from Dataset Groups. Preserve per-file canonical/local notes, assets and portable association. | Per-file notes + canonical association specifications; canonical0030 ACCEPTANCE_A/B.json, sourceb6134989. |
| R2 MARKDOWN-PREVIEW-SCRIPT-IO | Already independently accepted P030; preserve shared renderer, selectable text, exact associated source and public Python/Octave IO. | Markdown Preview/script IO + association specification; same P030 final receipts. |
| R3 DOCUMENTS-EDITOR | Already independently accepted P030; preserve genuine C++ module, Save Existing versus Publish New, assets, Workspace/History. | Documents Editor specification; same P030 final receipts. |
| R4 MARKDOWN-COMPATIBILITY | P030 limitations were not completion of anchors/relative links. Their later actual implementation was independently accepted in P031. | CORE Markdown quality specification + owner P031 anchors/relative-links amendment; canonical0031 ACCEPTANCE_A/B.json and handoff, sourcec998fe69. |
| CONTRACT-VISUALIZERS | Already independently accepted P030; keep owner/compatible Open/Preview selection, Runtime Contracts and distinct Modules category, lifecycle and C++ authoring. | Contract Visualizer specification and P030 final receipts. No extra production module solely for this category. |
| UNIVERSAL-PRODUCER-GROUPS | Already independently accepted P030's owner architectural correction; do not equate Acquisition-only grouping with universal delivery. Preserve all9 public/native/Script/GUI transaction gates and SourceNote distinction. | Owner binding correction; P030 final receipts and universal_groups scoped evidence. |
| HIDDEN-ROLLBACK-BRIDGE | Already independently accepted P030 focused correction. Preserve visible declaration ownership/version checks and Installer backups. | Owner report/candidate/instructions; P030 hidden_bridge receipts and final acceptance. |
| R5 ACQUISITION-HELP | Already independently accepted P031, always-available Acquisition unchanged. | Acquisition Select/Help/About + Rigol illustrated HTML specification; P031 final receipts. |
| R6 PLOT-X-CAPTIONS | Already independently accepted P031, including preserved Plots controls and explicit v2→v3/v4 delegates. | Plot custom X tick specification; P031 final receipts. |
| R7 UML | Already independently accepted P031 in documented delivered notation/family scope, not an invented claim of arbitrary Mermaid/PlantUML/XMI support. | UML specification; P031 final receipts and actual module source. |
| P031-PREVIEW-PERSISTENCE | Already independently accepted P031; preserve distinct Configuration and Session scopes, multiple providers/update/dependencies. | Corrected owner persistence document; P031 final receipts. |
| P031-PREVIEW-R2 | Already independently accepted P031 with retained original0.1.4 and separately versioned corrected0.1.5. Preserve CORE composition/cache/provenance/lifecycle and managed C++; cache proposal stays design-only. | Owner Preview0.1.4/r2 specification and original inputs; P031 final receipts. |
| R8 GENERIC-BUILDER | Independently ACCEPTED/DEPOSITED P032 fc672ead. Preserve its original P032 actual compiled Acquisition/typed configuration/profile/contracts/helpers/Test and Preview authoring evidence. This does not close the P033 scientific modules or recovered script Builder scope. | Canonical0032 independent acceptance/archives/checksums; inherited source fc672ead. |
| R8 UNIVERSAL-SPECTRAL | INCLUDED P033, OPEN. Actual Builder-authored universal Acquisition profiles CSV/fluorescence, NIST JCAMP-DX, Andor SIF, authentic-limited SP/PRF; source/units/all numeric samples/dimensions/fullRAW SHA. | Universal plan plus fluorescence, PerkinElmer, spectral-contract/Library-boundary specifications. Missing authentic pairs remain REAL_UNVERIFIED; no invented source truth. |
| R8 NATIVE-PREVIEWS | INCLUDED P033, OPEN. Normal separately installable Builder-authored compiled C++ spectral/frame/time-series presentations using shared public owners and scientific contract compatibility. | Same4 Req8 specifications; no importer-version coupling, flattened SIF or Tcl substitutes. |
| R8 LIBRARY-COMPATIBILITY | INCLUDED P033, OPEN. Audit/version domain schemas so every admitted scientific type is representable/identifiable/linkable, without new ingestion workflow or automatic population. | Spectral contracts/Library compatibility boundary specification. |
| R9 GENERIC-COMPARISON | OPEN, owner-assigned P034. Actual5 modes and second non-IR compiled consumer, not an assistant deferral. | Seven-patch allocation + Comparison Plot specification. |
| R9 IR-VIEWER | OPEN, owner-assigned P035. Genuine C++ Viewer + IR-scoped3page public Browser, numeric/provenance/Plot/Workspace/History. Old Tcl UI compatibility explicitly waived, scientific integrity never waived. | Seven-patch allocation + native IR Viewer specification/waiver. |
| R9 GENERATORS-MIGRATION | OPEN, owner-assigned P035. THREE new teaching/regression generators plus TWO updated faculty generators, full actual Sessions/DEMO/HTML/export and real dependency audit. | Generator dependency migration specification + IR complex regression audit + seven-patch allocation. |

## Mandatory P033 recovery additions

| ID | Status | Exact acceptance boundary |
| --- | --- | --- |
| GAP-001 | INCLUDED P033, OPEN | Both language editors: primary Project→New Project, same-window temporary Create/Manage canvas, actual Registry identity/User+Session scopes/entrypoint, exact Cancel/error/dirty/Undo/scroll/focus restoration. Standalone New Script remains equally valid. Open/import/manage and Public APIs inventory reuse the same editor owner. |
| GAP-002 | INCLUDED P033, OPEN | One genuine Builder/C++ Script Library Viewer with actual old operations and launch routes, narrow typed host grants, normal package/install/cold/uninstall/recovery; no Tcl dialog renamed or parallel Registry/Runner. |
| GAP-003 | INCLUDED P033, OPEN | Whole-project static PROVIDED declarations in any Python/Octave source, distinct CONSUMED APIs; deterministic typed source/function/line/SHA inventory in canvas and existing Builder; saved-source normal manifests/docs/Bridge; real invoked functions return declared structured values under managed Jobs. Legacy manual public_api and ordinary Analysis preserved. |
| DATASET-BROWSER-ICON | INCLUDED P033, OPEN | Exactly one icon inside existing browser.tools row; remove sessionbar Dataset control and duplicate Current popup; reuse single actionsMenu/original callbacks, semantic toolbar dedup, unchanged right-click. Independent native4sizes/font10/18/installedthemes/cold/focus/actions and screenshot evidence. |

Original detailed recovery references are pinned/read in
READ_AHEAD_SCRIPT_RECOVERY_BINDINGS_20261030.json. The source-owner map is
SOURCE_OWNER_READ_AHEAD_20261030.json and is an unaccepted P032 observation only.
All four additions require separate nonauthor functional and real-GUI evidence
on the final P033 revision. Do not move them to P034/P035/P036 due to workload.

## Inherited limits and genuine owner deferrals

The transferred Scientific Libraries consolidation is already delivered in
accepted P028-r2, not new P033 work. Its canonical README and
INDEPENDENT_ACCEPTANCE.json were reread: genuine integrated Viewer/threepage
Browser/source filtering accepted with stated limits. Its ordinary Workspace
companion-installer case remains explicitly NOT_VERIFIED_OWNER_DEFERRED and must
not be retried or called passed by this cascade. Protected authenticated
LCSC/Mouser live availability remains NOT_VERIFIED, not implied by synthetic
connector proof. Preserve the372ms versus250ms latency qualification and actual
four Debian themes/platform limits.

Further general Scientific Libraries cosmetic simplification is explicitly
owner-deferred in the current intake. An unconfirmed Notes split-view preference
is not a new approved requirement. Do not confuse either with the three confirmed
recovery gaps.

Curve Digitizer2.0.20 is inherited unchanged from P030, SHA
acbc81a77ed1625bde3030e871ec88513a28f08b1317780f8e95b3e2b10ff152,
OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST. No package modification,
recompilation, functional/GUI/install/regression test is authorized. Generic
producer APIs use independent test-only producers; the owner decides Digitizer
adoption. Earlier supplied versions remain superseded preserved originals.

## Required prefreeze follow-through

This draft is not an exhaustive closed audit. Compare each detailed original
NEXT/P027 requirement and the accepted P028–P032 actual source/handoffs with the
P033 final implementation. Attach source/package hashes and exact A/B evidence,
preserve historical failures and qualified reused scope, and identify additional
source-proven omissions explicitly. Restore genuinely missing OPEN TODO items;
remove only independently accepted completed work after normal SSD deposition.
No assistant-created future label is owner authorization.

## Current scoped evidence and still-open gates

These are scoped receipts, not complete patch gates. Final candidate applicability and independent real-GUI acceptance remain mandatory.

| Gate | Completed scoped evidence | Required before freeze |
| --- | --- | --- |
| Genuine scientific Acquisition | Final original 1.0.2 ZIP438fb8c4, all26 members adopted unchanged; independent A29 68443808 canonical JCAMP/CSV source units, late rollback, cold restoration and unchanged original P032 binary compatibility. Earlier full6309/3301/SIF528/PRF520+mini8 receipts retained with authentic limits. | Independent actual CSV/SIF menu/Options/About/Help/import/RAW functional B02 a8c85135 passed scoped. Independent B01 5e539f3d seals48 unique configurations at fonts10/14/18 plus16 corrective-width retakes; exact final source applicability remains open; no invented verification of missing authentic formats. Historical37e unit override leak and early readiness-fixture failures retained. |
| Native Spectrum/Trace/Frame | Original normal Builder b8a/333/70c packages, followed by genuine normal Spectrum/Trace1.0.1 originals8e95/e7d7 (all42 member bytes/modes exact); independent A27 94beffa6 genuine1025-value paging/full Plot, rank3 uint64 exact plane/coordinates/palette/transpose; A28 7ec76231 typed broker/CORE/SDK refusals, source change and actual post-command48KiB refusal. HIGH-B actual genuine cold31 Fit/source author evidence. | RC01 remains unaccepted; original633×619 clipping and subsequent classic initial-blank failures are retained. Genuine Builder1.0.1 successors and MAIN65f compact composition/adaptive caption fix await actual overview/controls/layout/lifetime48 and final source applicability. Frame1.0.1/scientific values retained; no synthetic-admission substitution. |
| Library scientific descriptions | Domain1.1.0 originalaae6; independentA26 7e7c3e normal update/uninstall/reinstall/cold/currentDatasetFollow and oldCORE refusal. No scientific ingestion. | Final normal package/source applicability and affected physical Manager/Browser representation GUI. |
| Script Registry and Library | IndependentA24 b6c06b atomic Copy/Assign/Delete/fullCAS/notes; B367 f268c56 dirtyYes save/target correctness and Project62ef73 native guarded CRUD/root/fullrecord. Genuine Library1.0.4 original4320405e normally Builder-compiled/updated by HIGH-B and adopted20 exact members. Independent A30 cached/uncached read positives and A31 five root/full-record/revision/file-SHA refusal controls; Independent A32 b58220b9 final1.0.4 combined cold/source-read/owner-review/Save/modal-root refusals passed scoped; native portability and final package qualification remain open. | A32 closes bounded functional combined reader/History/cold/review/Save/modal-root race. Native warm866f6402, cold/SaveAs/portablef5df24a6, ownSave4159889b and current UserRun e58ed2e9 pass their exact scopes. Final lifecycle/routes/wholeLibrary applicability remain open. No source authority from portable snapshots. |
| Existing standard Library History | Root7f source capture/readonly/latest/UndoRedo author; Root3b semantic projection independently B5a06c785 no unrequested branch after Undo/focus-only. BSource32 8a0d2ef2 actual7f32 conditions, source matrix qualified by startup/theme execution. | Final Library1.0.4 independent uncached-file navigation/native and Workspace saved-presentation acceptance. HIGH-B actual bd7 cold failure retained; two-file recovery adopted e999, actual author cold/warm43 exact views plus9 focused checks, no-Library fast guard4ce. Older Source32 evidence requires final exact applicability. No new History engine. |
| GAP001 Project canvas | Implemented both language owners/shared identity; prior affected editor matrix, current partial3b Octave canvas/Notes915537e6 and corrected5e Python10b06d59 actual Source/Undo/full Details/keyboard/Notes. | A37 current functional Run/Debug/Stop/portableProject is independently scoped PASS. Independent exact1dfa initial-fit32 conditions/64 both-language views now pass B2e3a3a35. Representative SessionSavedAPI/stale/pending/lifetime and final applicability remain open, both languages. Python3.13 None executable-line/status defect d6d4741d retained; correctedc3ee genuine beta retake passed scoped. |
| GAP003 callable multifile Builder | IndependentA23 324305 both consumers/providers8 actual managed children; A25 d3b5fd legacy/Analysis+automatic exports; Bf2e506 actual normal both-language chooser/3file intake/ValidateBuild/manifest/source parity and normal close; same Public APIs/Notes partials above. | Final normal1.4.7 package/install and explicit metadata applicability, generated docs/manifest/catalog, negative/admission/disabled cases and ordinary legacy semantics. API availability is distinct from capability admission. |
| Browser toolbar icon | Prior independent Browser32 B5d4f51 and full GroupZIP cold; original right-click unchanged. Exact mandate SHA74f4b91f reverified MAIN2026-10-31. | Final placement/menu/callback/nonduplication native retake and source applicability after top Acquisition menu changes. One icon in existing browser.tools only, no top Dataset launcher or second menu. |

No recovered requirement has been moved to P034/P035/future. P034 comparison and P035 IR/generators remain owner-assigned subsequent patches, with separate full acceptance and SSD delivery. Accepted P029–P032 remain immutable. Curve Digitizer2.0.20 remains inherited unchanged/NOT_TESTED_BY_OWNER_REQUEST.

## Original R8 acceptance audit correction before freeze

The universal-spectral plan section5 and original fluorescence specification
section6 explicitly require fonts10/14/18 or equivalent. An earlier MAIN message
incorrectly treated independent14 as optional; this was corrected before freeze.
LOW-B retains the completed10/18 evidence and adds bounded14 coverage, without
replaying source imports or numeric campaigns. Author14 is not independent proof.

The contract/Library boundary separately requires existing frequency and NMR2D/3D
compatibility. A26 Library descriptions alone do not prove those Dataset/Viewer
regressions. LOW-A found the missing scoped proof and delegates bounded controls
with exact current original packages, tiny explicitly SYNTHETIC NMRPipe2D/3D,
canonical/RAW/ppm/nuclei/cold/specialized Viewer and existing frequency owner.
Independent A186/187 receipt5c71ee63 now passes bounded synthetic NMR2D12/3D24 cells with exact current packages, canonical/RAW/ppm/nuclei/cold/specialized Viewer and frequency-owner control. Frequency receipt is not an FFT numerical qualification; no authentic NMR instrument claim or new decoder/producer. Final candidate applicability remains mandatory.

Scientific qualification stays per actual format. Authentic NIST6309 and SP3301
source comparisons are independent scoped proof. PRF is synthetic-container
qualified and REAL_UNVERIFIED for authentic pairs; genuine Fluorophores exports
and unqualified physical SIF calibration/2D variants remain explicitly unverified.
The owner's allocation permits honest REAL_UNVERIFIED for missing real pairs;
never rename those format gates PASS or remove their genuinely unfinished TODO.

## Final reconciliation and newly exposed scoped correction

Independent A35 original-requirements audit447997ea records13 scope rows and no newly source-proven unauthorized deferral in that bounded review. Its older operational crosswalk index has an explicit correction pointing here; the current source table already records A32/NMR completion and both native overview failures. Independent A37 92513741 now supplies actual current Python/Octave Run23, helper physicalfile/line2 Debug/Continue, separate Stop/CANCELLED, portableProject allfiles/compositeSHA and separate-process cold readback in Session execution scope. Native User-reference Run42/43 and final affected GUI/source applicability remain separately cited; no blanket DebuggerGUI proof. Do not infer acceptance from a declaration or an untested inherited route.

Independent B Library warm866f6402 shows actual No/Yes review, readonly browse, Undo/Redo, branch Cancel/OK and separate Save; cold/portable native precision remains OPEN. It exposed a new own-Save→uncaptured-file read refusal: Save advanced baseline to2 while transient read admission remained1. MAIN actual compiled baseline01 reproduces it without History. The narrow CORE correction updates admission only from the exact successful Save return; author03 checks the helper read and refuses a later metadata-only revision3 with unchanged source SHA. Independent A36 a9faf5f0 now passes that bounded actual compiled correction, including exclusion of authority from capture and exact original432 package modes. Native corrective/final artifact acceptance remains required; no extra write authority or serialized admission is introduced.

## Current corrective implementation and independent scope ledger

The original RC01 remains immutable/unaccepted. Genuine original Spectrum/Trace1.0.1 ZIPs8e95/e7d7 are adopted42 exact member bytes/modes; all handwritten C++/hpp/SDK/native binary remain unchanged. Independent actual2434 Spectrum now has full187px widget/render parity and unrelated-producer selection, but its long rotated Ycaption and disabled-native CORETable font rows exposed separate release-blocking UI defects. MAIN A792 rebuilds the existing Native2D Plot owner with exact Cairo ink centering, same67 source/header map except one Plot file and same compiler/-O2/Cairo. Independent A38 62adb689 verifies newloadedc1af versus accepted predecessor: all66 other sources/15headers exact,179px caption fits187, axis/tick/point/noncaption output unchanged, tall/manual/customX/log exact, reverse/Unicode/right axes and explicit oversize refusal. This is native painter/ABI proof, not final genuine Preview GUI acceptance.

MAIN B995 adopts the five-line CORETable body font-row fix through the existing helper, with widget-local Map/Configure/ThemeChanged bindings and unchanged column sizing/data/copy. Author122 scope is fonts10/14/18 ×fourthemes; independent integrated fallback retake remains required. MAIN1dfa adopts one shared initial ScriptWorkspace fit call after its creation guard. Original B ea481689 proves natural1180×760 exceeds physical1280×720 before Canvas. Author84 and first independent exact1dfa1280/font10/fourthemes/bothlanguages pass scoped; remaining native matrix remains OPEN. No maximizing workaround or new timer/global owner is introduced.

Independent B Library1.0.4 warm866f6402, cold/SaveAs/portablef5df24a6 and native ownSave→uncaptured-read4159889b are scoped PASS alongside A32/A36. The earlier portable no-result inference is withdrawn: the ordinary form remained obscured and correctly refused conflicting managed-resource owner generation BEFORE capsule_import. The actual capsule importer commits synchronously; no flush/persistence change was made. A fresh collision-free Session with no open document normally imports/opens/cold-restores exact captured sources/parameters/views and refuses canonical Save against its empty User Registry. Existing owner authority remains strict. Final complete Library/frontend callback/source/artifact applicability and distinct GAP001/002/003 A+B acceptance remain OPEN.


## Adaptive caption, initial feedback and current editor retakes

MAIN65f56d2d corrects the fixed4px margin refusal when179px caption ink fits
the native180px minimum: the margin is min(4, half available spare ink space).
Independent A39 9d6ac365 loads matching a602d7d8 CORE binary and verifies complete
ink at180/186/187, exact eight successful predecessor models (fixture196), plus oversize refusal, unchanged noncaption primitives,
all66 other source identities and15 Cairo headers. Requests178/179 clamp to180;
no below-minimum viewport claim. Default toolbar/footer vertical gaps compact
only in the existing sole-weighted-notebook composition without authored padding.
No genuine module ZIP, scientific sample or owner Curve package is changed.

Independent B2e3a3a35 seals32 affected editor configurations and64 Python/Octave
views: natural initial geometry/full Return allocation/native hit, Details
Copy/End/Home/Return, normal closes and exact source. Eight selected fullsize
frames were personally reviewed, not every pixel of128 captures. The pending
Session addon remains separate. Current actual User Run Python42/Octave43
B e58ed2e9 closes the prior current-ELF execution gap, distinct from A37 Session
Run/Debug/Stop scope.

Cancel investigation did not prove an unrequested resubmission: a later Job ID
can belong to the original pending asynchronous submit. The cache task can remain
preparing while cancellation drains. MAINe3debc5d fixes only the proven stale
initial Details placeholder by projecting the existing lifecycle text to both
initial placeholders; author11 presentation checks retain adopted source/view.
No scheduler/cache policy is changed. Independent functional feedback and actual
native submission/terminal trace remain pending; no false terminal Job result.

## Session Project API corrective gate

Independent B245 opened real registered Session Projects in both languages, then
Saved Public APIs refused because the canvas supplied an opaque lifetime token
where the Registry expects a Session directory. RC03 remains unaccepted; A41
mechanical/full4424-file readback, cold Catalog and normal10-package proofs are
scoped preserved evidence, not acceptance of this newly exposed path.
MAIN separates captured session_path from its existing snapshot token and checks
both for Session sources; callback adoption/navigation additionally compare the
token and all existing expected source/record/root fields. User inventory retains
its independent Registry scope. Author02 actual editors/asynchronous Saved+Draft
inventory passes19 bounded checks across both languages, unchanged canonical
records, retained source and changed-Session refusal. Original author01 omitted
required fixture declaration metadata and is retained as a harness failure.
Independent functional/native stale/pending/lifetime and final artifact retarget
remain mandatory. No guard, Registry owner or Script execution API is weakened.
