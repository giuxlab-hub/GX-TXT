# P033 scientific contract admission audit

Status: implementation plan; acceptance remains OPEN. Read against accepted
P032 and current P033 source, before adding a new contract ID. Owner authority:
Req8 four binding specifications, particularly
`GXTXT_NEXT_TASK_REQ8_SPECTRAL_CONTRACTS_LIBRARY_COMPATIBILITY_BOUNDARY_20261028.md`.

| Existing owner | Observed meaning and decision |
| --- | --- |
| `spectrum.table` | Frequency-domain table. Preserve its meaning and compatibility graph. |
| `spectrum.scientific` / `SpectrumAPIv1` | Genuine finite, strictly monotonic unit-qualified 1D XY. Reuse common CSV/JCAMP decoding and existing value/publication authority; no vendor/importer-specific contract. |
| `spectrum.family` | Genuine multiple 1D spectra and explicit family parameter. Reuse only when the actual data meet that owner. |
| `timeseries.table` | Genuine temporal trace, including a verified PRF time/intensity interpretation; never infer from extension. |
| `spectrum.nmr_multidimensional` | Actual NMRPipe 2D/3D semantics. Preserve and verify compatibility; do not label detector frames as NMR. |
| `image.raster` / `acq.image_binary` | Original opaque binary raster container, not a typed floating-point detector array. Its Native2D raster binding explicitly requires that contract; do not fabricate a PNG Dataset to present scientific values. |
| Variable Schema v3 / Publication v2 / canonical access | Already support explicit dimensions, rank, dtype, coordinates and multidimensional binary arrays. Extend only the existing Acquisition prepared-output adapter, which currently restricts every Variable to one common row dimension. |
| `datasetPreviewNativePlane` | Existing bounded canonical-array plane presentation and shared Native2D implementation. Reuse this owner for frame Preview; retain exact starts/counts, coordinates, range, nonfinite policy and source verification. |

One minimal new installable, versioned service provider is justified:
`contract.scientific_measurement`, providing `measurement.numeric_array` for
genuine rank >= 2 scientific numeric arrays with Variable Schema dimensions,
coordinate declarations, observed modality/quantity/units, frame/ROI/calibration
metadata when actually present, and pinned original source provenance. It has
no artificial parent `table.generic`, `image.raster` or NMR contract. The existing
Contract Registry discovers declarations; CORE does not hardcode producer IDs.
Missing provider keeps saved identities truthful and refuses unsupported work.
This document does not itself advertise or implement that provider/API.

Native Previews remain independent of importer ID/version. Spectrum/trace reuse
their real existing contracts; frame Preview admits the new numeric-array
contract and validates the actual rank/schema. The genuine Builder may author
an ordinary panel filled by the maintained CORE plane owner, with explicit
Variable and plane selection, numeric Values, Metadata and Source inspection.
No new renderer, flattened image stack, implicit extraction or canonical payload
conversion is authorized. An optional scientifically justified extraction is a
separately identified derived publication with explicit transformation history.

The existing `domain.scientific_spectra` 1D record and validator stay intact.
Additive public domain record declarations must describe distinct numeric-array,
frame/sequence and temporal/complex measurement identities where meaningful,
including rank/shape/coordinates, observed units, source SHA and optional pinned
`canonical_dataset` relationships through the existing generic graph owner.
Library representation/discovery is independent of Dataset publication. There
will be no new Library source importer, auto-population, storage engine, browser
or scientific payload decoder under this requirement.

Independent gates include existing frequency/1D/NMR regressions, a true
multidimensional synthetic control explicitly labelled synthetic, source-grounded
authentic fixtures where available, exact dtype/order/shape/coordinate values,
Source/RAW SHA, failure rollback/cancellation, optional Preview dispatch/fallback,
normal module installation/cold restoration and Library schema discovery/link
identity only. Unavailable authentic SP/PRF/frame evidence remains explicitly
unverified; it cannot be replaced by a synthetic-authentic claim.
