# API Catalog Service v1

The catalog is a derived C++/SQLite index of shipped public declarations. It is
metadata, never execution permission. The P025 incremental distribution includes
`core/api_catalog/catalog.sqlite`, its portable `source_manifest.json`, complete
native source/build files and the matching Linux binary. Ordinary first use
validates and opens that prebuilt snapshot; it does not launch Python/Tcl CORE
metadata discovery. Indexed reload/search never spawns a process.

| Public Tcl operation | Contract |
| --- | --- |
| `apiCatalogRequest CALLBACK` | Asynchronously initialize/read the process snapshot; returns a consumer ticket. Callback: `ok`, `result` status or `error`. |
| `apiCatalogQuery FILTERS` | Bounded page with rows/total/offset/limit/generation/fingerprint/freshness/error. |
| `apiCatalogGet RECORD_ID` | Exact API/provider/operation record; missing identity is an explicit error. |
| `apiCatalogStatus` | Snapshot identity/count/generation, freshness, progress, request_active, target_fingerprint, pending_metadata and last error. |
| `apiCatalogRefresh CALLBACK` | Public, manually callable validation/reconciliation API. Same consumer-ticket/callback contract; preserves the running immutable snapshot. |
| `apiCatalogCancel TICKET` | Detach this consumer. Other consumers and the shared reconciliation continue. |
| `apiCatalogInvalidate` | Existing trusted Plugin Manager lifecycle invalidation; coalesces automatic reconciliation. |
| `apiCatalogProviderState PROVIDER` | Current installed/enabled/active/pending projection from existing module/lifecycle owners. It grants no execution access. |

Commands are qualified with `::GX::`. Queries accept exact `api_id`/`provider_id`,
exact `source_ref`/`source_sha256` (indexed declaring-source membership),
`surface` (host/script_bridge/cpp_sdk), `language` (Python/Octave/Cpp), literal
`query`, `offset` and `limit` (1–1000). `family:API_ID` is the API detail identity;
query results provide exact provider/operation record IDs. For example,
`apiCatalogQuery {source_ref core/tcl/workbench_recovery_api_v1.tcl limit 100}`
performs exact source lookup, including aggregate family membership. Provider/source
provenance, parameters, results, deprecation, documentation status and independent
Python/Octave visibility are also stored in normalized indexed native relations.
No full-catalog transfer is needed for a Browser page.

At startup, a manifest-driven native content identity check reads the exact
shipped source/documentation identities and current plugin declaration roots.
It performs no CORE metadata discovery. Missing/corrupt/old-schema packaged
indexes fail explicitly. Packaged seeds use DELETE journal mode and create no read-only sidecars.
The read-only installation is never a cache target:
private snapshots and stages use `$XDG_CACHE_HOME/gxtxt/api-catalog-v2/`, falling
back to `~/.cache`, bound to executed framework and configuration identities.
Native contention waits are bounded to100ms.

Packaging alone runs the trusted existing CORE contracts, registered Bridge
metadata discovery and exact SDK/policy projection. `gxtxt_api_catalog.py build`
creates the reproducible shipped index in a fresh stage. It validates complete
source identity, SQLite integrity and provenance; packaging regenerates after
final source/module-manifest updates. Root SHA manifests and generated catalog
files are excluded from input identity to prevent circular hashes.

Normal plugin reconciliation uses strict inert descriptor/Tcl-data parsing and
literal Python AST data. It never imports plugin code, executes installers,
constructs a scientific Host, invokes scientific operations, or validates/builds
authored C++. Unchanged exact binding source retains its trusted registered
inventory with updated provenance. A changed pure literal registration can be
indexed safely. Dynamic changed metadata that cannot be proven by inert parsing
is explicitly `pending_metadata`; its exports are omitted from the staged
snapshot until trusted packaging supplies them. Invalid explicit contracts fail
refresh and preserve the previous good snapshot. Duplicate conflicting Script
Bridge providers fail; public provider/version conflicts are visible per owner.

A process keeps one definition snapshot. A successful runtime update stages a
complete next-process database (`pending_restart`), while current providers keep
their existing module/lifecycle behavior. First initialization can admit a valid
matching staged snapshot before any Browser sees it. Failed/interrupted staging
leaves the old snapshot and its diagnostic evidence intact. Referenced missing
or invalid documentation has explicit status and manual navigation errors.
`progress` distinguishes validation, metadata staging, completion and failure;
consumer cancellation never discards another consumer's work.

There is **no new graphical refresh/rebuild control**. The existing editor
Browser refresh button only reloads its indexed view. Public programmatic
refresh and automatic startup/plugin reconciliation remain available.

Viewer Interface Builder exposes `api_catalog` with `title`, `language`
(Public/Python/Octave/Cpp), `surface`, `query`, exact `api_filter`/`provider_filter`,
`presentation` (full/compact) and `enabled`. It supports normal containers/grid/
pack/splitters/tabs, native Treeview keyboard and scroll behavior, selection,
manual navigation, bounded paging, empty/error/status views and clean disposal.
Selection/manual events are `selection_changed`/`manual_opened`; presentation
state capture/restore retains query, surface, page and selected record. No native
handles or project grants are persisted in Viewer state. A useful full view is
at least320x360px; smaller panes retain scrollbars and resizable list/detail sash.

Octave/Python editor consumers silently use only their registered Script Bridge
operations. C++ defaults to public documentation plus exact finite SDK methods;
saved-project admission is computed separately from static catalog facts and
never treated as a global grant. The generic component may show a source-neutral
full public reference with explicitly labeled surfaces. The regenerable private
example is `examples/api_catalog_navigation/`; no main Help code is integrated.
A future authorized Help integration can declare this same component and API
requirement without adding a metadata collector.
