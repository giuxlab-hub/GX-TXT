# SPDX-License-Identifier: GPL-3.0-or-later
# Derived installed reference only. Public owners retain execution/admission.
namespace eval ::GX::ApiCatalog {
    variable handle {};variable request {};variable waiters {};variable serial 0
    variable retries 0
    variable target {};variable freshness unavailable;variable error {};variable pending {}
    variable directory {};variable snapshot {};variable initialized 0;variable manifest {};variable adopt 0
    variable progress idle;variable pendingMetadata {};variable exitHook 0;variable shippedManifest {};variable closed 0
}
proc ::GX::apiCatalogApiInfo {} {
    return [dict create api_id API_CATALOG_SERVICE_API_v1 api_version 1 authority native_cpp_sqlite operations {request query get status refresh cancel invalidate provider_state} execution metadata_only session_required 0]
}
proc ::GX::_apiCatalogRequire {} {
    variable ::GX::ApiCatalog::handle
    if {$::GX::ApiCatalog::closed} {return -code error -errorcode {GX API_CATALOG CLOSED} {API catalog service is closed until interpreter restart}}
    if {![llength [info commands ::GX::apiCatalogNative]]} {load [file join $::GX::scriptDir core api_catalog libgxtxt_api_catalog[info sharedlibextension]] Gxtxt_api_catalog}
    if {$handle ne {}} {return $handle}
    set identity [list [file normalize $::GX::scriptDir] [file normalize [configurationPath]]]
    if {[info exists ::env(XDG_CACHE_HOME)] && [file pathtype $::env(XDG_CACHE_HOME)] eq {absolute}} {set cache $::env(XDG_CACHE_HOME)} else {set cache [file join ~ .cache]}
    set directory [file join $cache gxtxt api-catalog-v2 [apiCatalogNative digest $identity]]
    file mkdir $directory;catch {file attributes $directory -permissions 0700}
    set ::GX::ApiCatalog::directory $directory
    set packaged [file join $::GX::scriptDir core api_catalog]
    set manifest [_apiCatalogJsonRead [file join $packaged source_manifest.json]]
    if {[dict get $manifest schema] ne {gxtxt.api_catalog.sources.v2} || [apiCatalogNative file_digest [file join $packaged catalog.sqlite]] ne [dict get $manifest database_sha256]} {error {Packaged API catalog is missing, corrupt or incompatible; previous user cache preserved}}
    set ::GX::ApiCatalog::manifest $manifest;set ::GX::ApiCatalog::shippedManifest $manifest
    set snapshot [file join $directory snapshot.[pid].[clock clicks].sqlite]
    file copy [file join $packaged catalog.sqlite] $snapshot
    _apiCatalogSnapshotWritable $snapshot
    set ::GX::ApiCatalog::snapshot $snapshot
    set handle [apiCatalogNative open $snapshot gxtxt.api_catalog.distribution.v2]
    if {[dict get [apiCatalogNative status $handle] fingerprint] ne [dict get $manifest fingerprint]} {apiCatalogNative close $handle;set handle {};error {Packaged API catalog source identity differs}}
    set ::GX::ApiCatalog::freshness packaged
    if {!$::GX::ApiCatalog::exitHook} {trace add execution ::exit enter ::GX::_apiCatalogExit;set ::GX::ApiCatalog::exitHook 1}
    return $handle
}
proc ::GX::_apiCatalogSnapshotWritable {path} {
    # Only a newly owned per-user snapshot is writable. Seed permissions and
    # the read-only installation are never changed.
    if {$::tcl_platform(platform) eq {unix}} {file attributes $path -permissions 0600} else {file attributes $path -readonly 0}
}
proc ::GX::_apiCatalogAdopt {database manifest} {
    set snapshot [file join $::GX::ApiCatalog::directory snapshot.[pid].[clock clicks].sqlite]
    set next {}
    try {
        file copy $database $snapshot
        _apiCatalogSnapshotWritable $snapshot
        set next [apiCatalogNative open $snapshot gxtxt.api_catalog.distribution.v2]
        set status [apiCatalogNative validate $next]
        if {[dict get $status fingerprint] ne [dict get $manifest fingerprint] || [dict get $status count]<1 || [dict get $status count]!=[dict get $manifest counts records]} {error {Staged API catalog identity/count differs}}
    } on error {message options} {
        if {$next ne {}} {catch {apiCatalogNative close $next}}
        foreach suffix {{} -wal -shm} {catch {file delete -- $snapshot$suffix}}
        return -options $options $message
    }
    set prior $::GX::ApiCatalog::handle;set oldPath $::GX::ApiCatalog::snapshot
    set ::GX::ApiCatalog::handle $next;set ::GX::ApiCatalog::snapshot $snapshot;set ::GX::ApiCatalog::manifest $manifest
    if {$prior ne {}} {catch {apiCatalogNative close $prior}}
    if {$oldPath ne {}} {foreach suffix {{} -wal -shm} {catch {file delete -- $oldPath$suffix}}}
}
proc ::GX::_apiCatalogExit {args} {apiCatalogClose}
proc ::GX::apiCatalogClose {} {
    if {$::GX::ApiCatalog::closed} return
    set ::GX::ApiCatalog::closed 1
    if {$::GX::ApiCatalog::pending ne {}} {after cancel $::GX::ApiCatalog::pending;set ::GX::ApiCatalog::pending {}}
    if {$::GX::ApiCatalog::request ne {}} {set request $::GX::ApiCatalog::request;set ::GX::ApiCatalog::request {};catch {scriptJobRequestCancel $request}}
    set ::GX::ApiCatalog::progress closed;set ::GX::ApiCatalog::freshness closed
    _apiCatalogNotify {ok 0 error {API catalog service is closed until interpreter restart} code {GX API_CATALOG CLOSED}}
    if {$::GX::ApiCatalog::handle ne {}} {catch {apiCatalogNative close $::GX::ApiCatalog::handle};set ::GX::ApiCatalog::handle {}}
    if {$::GX::ApiCatalog::snapshot ne {}} {foreach suffix {{} -wal -shm} {catch {file delete -- $::GX::ApiCatalog::snapshot$suffix}};set ::GX::ApiCatalog::snapshot {}}
}
proc ::GX::_apiCatalogSourceFiles {directory depth} {
    if {$depth>8} {error {API catalog source inventory exceeds depth bound}}
    set files {}
    foreach path [lsort [glob -nocomplain -directory $directory *]] {
        if {[file type $path] eq {link}} continue
        if {[file isdirectory $path]} {if {[file tail $path] ni {__pycache__ images resources native review}} {lappend files {*}[_apiCatalogSourceFiles $path [expr {$depth+1}]]}} elseif {[file extension $path] in {.tcl .py .json .hpp .h .ini}} {lappend files $path}
    }
    return $files
}
proc ::GX::_apiCatalogFingerprint {{manifest {}}} {
    _apiCatalogRequire
    if {$manifest eq {}} {set manifest $::GX::ApiCatalog::manifest}
    set root [file normalize $::GX::scriptDir];set files {}
    # Shipped identities are manifest-driven: no recursive CORE discovery on
    # ordinary startup. Enumerate current plugin declaration roots for lifecycle
    # additions/removals; read exact referenced documents only.
    dict for {relative entry} [dict get $manifest files] {
        if {[file pathtype $relative] ne {relative} || {..} in [file split $relative]} {error {Invalid packaged API source identity}}
        if {[string match plugins/modules/* $relative] && $relative ni [dict get $manifest documentation]} continue
        lappend files [file join $root $relative]
    }
    foreach directory [lsort [glob -nocomplain -types d -directory [file join $root plugins modules] *]] {
        if {[file type $directory] eq {link}} continue
        set descriptor [file join $directory module.ini]
        lappend files $descriptor [file join $directory SHA256SUMS.txt] [file join $directory SHA256SUMS]
        if {[file isdirectory [file join $directory api]]} {lappend files {*}[_apiCatalogSourceFiles [file join $directory api] 0]}
        if {![file isfile $descriptor]} continue
        if {[file type $descriptor] eq {link} || [file size $descriptor]>16777216} {error {Module API descriptor exceeds its regular-file bound}}
        set d [parseIni $descriptor]
        foreach api [splitList [descriptorValue $d public_apis ids {}]] {
            set reference [descriptorValue $d public_api.$api documentation docs/api/$api.md]
            if {[file pathtype $reference] ne {relative} || {..} in [file split $reference]} {error {Invalid module API documentation identity}}
            set candidates [list [file join $root $reference] [file join $directory $reference] [file join $directory docs $reference]]
            set selected [lindex $candidates 0]
            foreach candidate $candidates {if {[file isfile $candidate] && [file type $candidate] ne {link}} {set selected $candidate;break}}
            lappend files $selected
        }
    }
    return [apiCatalogNative fingerprint [lsort -unique $files] $root]
}
proc ::GX::apiCatalogStatus {} {
    variable ::GX::ApiCatalog::freshness;variable ::GX::ApiCatalog::error
    set status [apiCatalogNative status [_apiCatalogRequire]]
    set identity [dict create version $::GX::version patch {} display_version $::GX::version framework_root [file normalize $::GX::scriptDir]]
    if {[llength [info commands ::GX::frameworkInstalledIdentity]]} {
        if {[catch {set identity [frameworkInstalledIdentity]} reason]} {dict set identity metadata_error $reason}
    }
    return [dict merge $status [dict create freshness $freshness error $error progress $::GX::ApiCatalog::progress request_active [expr {$::GX::ApiCatalog::request ne {}}] target_fingerprint $::GX::ApiCatalog::target pending_metadata $::GX::ApiCatalog::pendingMetadata framework_root [file normalize $::GX::scriptDir] framework_identity $identity source_manifest_schema [dict get $::GX::ApiCatalog::manifest schema] source_manifest_fingerprint [dict get $::GX::ApiCatalog::manifest fingerprint] loaded_packaged_database_sha256 [dict get $::GX::ApiCatalog::shippedManifest database_sha256]]]
}
proc ::GX::_apiCatalogDefinitionRequire {} {
    if {$::GX::ApiCatalog::closed} {return -code error -errorcode {GX API_CATALOG CLOSED} {API catalog service is closed until interpreter restart}}
    if {!$::GX::ApiCatalog::initialized || ($::GX::ApiCatalog::adopt && $::GX::ApiCatalog::progress eq {staging_metadata})} {
        return -code error -errorcode {GX API_CATALOG INITIALIZING} {Request the API catalog and wait for its initial definition snapshot}
    }
}
proc ::GX::apiCatalogQuery {{filters {}}} {
    _apiCatalogDefinitionRequire
    set result [apiCatalogNative query [_apiCatalogRequire] $filters]
    set rows {};set owners {}
    foreach row [dict get $result rows] {
        set owner [dict get $row provider_id]
        set core [expr {$owner eq {CORE} || [string match core/* [datasetPublicationV2DictDefault [dict get $row payload catalog_meta] declaration_ref {}]]}]
        if {![dict exists $owners $owner]} {dict set owners $owner [apiCatalogProviderState $owner $core]}
        dict set row runtime_state [dict get $owners $owner];lappend rows $row
    }
    dict set result rows $rows
    return [dict merge $result [dict create freshness $::GX::ApiCatalog::freshness error $::GX::ApiCatalog::error]]
}
proc ::GX::apiCatalogProviderState {owner {core 0}} {
    if {$owner eq {CORE}} {set core 1}
    if {$owner ni $::GX::moduleOrder} {
        return [dict create installed $core enabled $core active [expr {$owner eq {CORE}}] pending 0 admission reference_only]
    }
    set runtimeError {}
    if {[catch {set active [pluginRuntimeModuleLoaded $owner]} reason]} {set active 0;set runtimeError [string range $reason 0 2047]}
    set pending [dict exists $::GX::pluginRuntimePending $owner]
    return [dict create installed 1 installed_version [moduleField $owner version {}] enabled [moduleIsEnabled $owner] active $active active_status [expr {$runtimeError eq {}?{known}:{unknown}}] runtime_error $runtimeError pending $pending admission reference_only]
}
proc ::GX::apiCatalogGet {id} {
    _apiCatalogDefinitionRequire
    set record [apiCatalogNative get [_apiCatalogRequire] $id]
    set payload [dict get $record payload]
    if {[dict get $record surface] eq {family}} {
        set providers {};set installed 0;set enabled 0;set active 0;set pending 0
        foreach provider [datasetPublicationV2DictDefault $payload providers {}] {
            set owner [dict get $provider provider]
            set core [expr {$owner eq {CORE}}]
            foreach source [datasetPublicationV2DictDefault [dict get $payload catalog_meta] source_members {}] {
                if {[dict get $source provider_id] eq $owner && [string match core/* [dict get $source declaration_ref]]} {set core 1}
            }
            set state [apiCatalogProviderState $owner $core]
            dict set providers $owner $state
            foreach key {installed enabled active pending} {if {[dict get $state $key]} {set $key 1}}
        }
        if {![dict size $providers] && [dict exists $payload script_descriptor]} {
            set owner [dict get $payload script_descriptor provider_id]
            set state [apiCatalogProviderState $owner [string match core/* [dict get $payload catalog_meta declaration_ref]]]
            dict set providers $owner $state
            foreach key {installed enabled active pending} {set $key [dict get $state $key]}
        }
        dict set record runtime_state [dict create providers $providers installed $installed enabled $enabled active $active pending $pending admission reference_only]
    } else {
        set core [expr {[dict get $record provider_id] eq {CORE} || [string match core/* [dict get $payload catalog_meta declaration_ref]]}]
        dict set record runtime_state [apiCatalogProviderState [dict get $record provider_id] $core]
    }
    return $record
}
proc ::GX::_apiCatalogJsonRead {path {typedVariable {}}} {
    if {![file isfile $path] || [file type $path] eq {link} || [file size $path]>4194304} {error {Saved project metadata is unavailable or exceeds its bound}}
    set channel [open $path rb];try {set json [read $channel]} finally {close $channel}
    set typed [nativeWorkspaceJsonDecode $json]
    if {$typedVariable ne {}} {upvar 1 $typedVariable target;set target $typed}
    return [nativeWorkspaceDecode $typed]
}
proc ::GX::apiCatalogProjectContext {project} {
    set result [dict create status NO_PROJECT source_validation not_checked_by_metadata_browser runtime_grants not_activated_by_metadata_browser requests {}]
    if {$project eq {}} {return $result}
    if {[catch {
        set paths {};foreach name {project.json handlers.cpp design.gxtxt-viewer} {
            set path [file join $project $name]
            if {![file isfile $path] || [file type $path] eq {link} || [file size $path]>4194304} {error {Saved project requires ordinary bounded source files}}
            file stat $path st;if {$st(nlink)!=1} {error {Saved project source hardlinks are unavailable for reference admission}}
            lappend paths $path
        }
        set before [apiCatalogNative fingerprint $paths]
        set meta [_apiCatalogJsonRead [lindex $paths 0] typedProject]
        set expected {schema module_id version profile language source design capabilities provenance tests}
        if {[lindex $typedProject 0] ne {object} || [lsort [dict keys $meta]] ne [lsort $expected]} {error {Saved project metadata schema fields differ}}
        set fields [lindex $typedProject 1]
        foreach name {schema profile language source design} {if {[lindex [dict get $fields $name] 0] ne {text}} {error {Saved project metadata requires explicit JSON strings}}}
        if {[dict get $meta source] ne {handlers.cpp} || [dict get $meta design] ne {design.gxtxt-viewer} || [lindex [dict get $fields provenance] 0] ne {object} || [string bytelength [dict get $meta provenance]]>8192} {error {Saved project source/design/provenance differs}}
        set capabilities [dict get $fields capabilities]
        if {[lindex $capabilities 0] ne {array} || [llength [lindex $capabilities 1]]>16} {error {Saved capability requests require a bounded JSON array}}
        foreach request [lindex $capabilities 1] {
            if {[lindex $request 0] ne {object}} {error {Saved capability request must be a JSON object}}
            set request [lindex $request 1]
            if {[lsort [dict keys $request]] ne [lsort {api_id version operations}] || [lindex [dict get $request api_id] 0] ne {text} || [lindex [dict get $request version] 0] ne {int} || [lindex [dict get $request operations] 0] ne {array}} {error {Saved capability request has invalid typed fields}}
            foreach operation [lindex [dict get $request operations] 1] {if {[lindex $operation 0] ne {text}} {error {Saved capability operations require explicit JSON strings}}}
        }
        set policy [_apiCatalogJsonRead [file join $::GX::scriptDir core development policy_v1.json]]
        set profile [dict get $meta profile]
        if {[dict get $meta schema] ne {gxtxt.viewer_development_project.v1} || [dict get $meta language] ne {cpp} || ![dict exists $policy profiles $profile]} {error {Saved project schema/profile is unavailable}}
        set requests {}
        foreach request [dict get $meta capabilities] {
            set api [dict get $request api_id]
            set state CAPABILITY_DENIED
            if {[dict exists $requests $api]} {error {Duplicate saved capability request}}
            if {[dict exists $policy capabilities $api] && $api in [dict get $policy profiles $profile]} {
                set allowed [dict get $policy capabilities $api]
                if {[dict get $request version]==[dict get $allowed version]} {
                    set state ADMITTED_REQUEST
                    foreach operation [dict get $request operations] {if {$operation ni [dict get $allowed operations]} {set state CAPABILITY_DENIED}}
                }
            }
            if {[catch {set familyRecord [apiCatalogGet family:$api];set family [dict get $familyRecord payload]}] || [datasetPublicationV2DictDefault $family version_conflict 0] || ![dict get $familyRecord runtime_state installed] || ![dict get $familyRecord runtime_state enabled] || [dict get $familyRecord runtime_state pending] || [datasetPublicationV2DictDefault $family version {}] ne [dict get $request version]} {set state CORE_API_GAP}
            if {$state eq {ADMITTED_REQUEST} && $api eq {VIEWER_GUI_HOST_API_v1} && {pcb_source_form} in [dict get $request operations] && $profile ne {document_view_v1}} {set state CAPABILITY_DENIED}
            if {$api eq {PLOT_DATASET_API_v3} || ([string match PLOT_DATASET* $api] && [dict get $request version]==3)} {set state DEPRECATED_PLOT_API}
            dict set requests $api [dict create status $state request $request]
        }
        if {$before ne [apiCatalogNative fingerprint $paths]} {error {Project changed during reference discovery}}
        dict set result status SAVED_PROJECT_METADATA;dict set result profile $profile;dict set result project $project;dict set result requests $requests
    } reason]} {dict set result status PROJECT_UNAVAILABLE;dict set result reason $reason}
    return $result
}
proc ::GX::apiCatalogProjectMethod {contract context} {
    set missing {}
    foreach grant [dict get $contract required_capabilities] {
        lassign [split $grant /] api operation
        if {![dict exists $context requests $api] || [dict get $context requests $api status] ne {ADMITTED_REQUEST} || $operation ni [dict get $context requests $api request operations]} {lappend missing $grant}
    }
    dict set contract missing_capabilities $missing
    dict set contract project_status [expr {[dict get $context status] eq {SAVED_PROJECT_METADATA}?([llength $missing]?{NOT_ADMITTED}:{ADMITTED_REQUEST}):[dict get $context status]}]
    return $contract
}
proc ::GX::apiCatalogInvalidate {} {
    set ::GX::ApiCatalog::freshness stale
    if {$::GX::ApiCatalog::initialized && $::GX::ApiCatalog::pending eq {}} {set ::GX::ApiCatalog::pending [after idle ::GX::_apiCatalogStart]}
}
proc ::GX::apiCatalogRefresh {callback} {
    set ticket catalog[incr ::GX::ApiCatalog::serial]
    dict set ::GX::ApiCatalog::waiters $ticket $callback
    if {$::GX::ApiCatalog::pending eq {}} {set ::GX::ApiCatalog::pending [after idle ::GX::_apiCatalogStart]}
    return $ticket
}
proc ::GX::apiCatalogCancel {ticket} {catch {dict unset ::GX::ApiCatalog::waiters $ticket}}
proc ::GX::apiCatalogRequest {callback} {
    if {$::GX::ApiCatalog::closed} {return [apiCatalogRefresh $callback]}
    set ticket catalog[incr ::GX::ApiCatalog::serial]
    dict set ::GX::ApiCatalog::waiters $ticket $callback
    if {$::GX::ApiCatalog::initialized && !($::GX::ApiCatalog::adopt && $::GX::ApiCatalog::progress eq {staging_metadata})} {
        after idle [list ::GX::_apiCatalogReply $ticket [dict create ok 1 result [apiCatalogStatus]]]
    } elseif {$::GX::ApiCatalog::pending eq {}} {set ::GX::ApiCatalog::pending [after idle ::GX::_apiCatalogStart]}
    return $ticket
}
proc ::GX::_apiCatalogReply {ticket response} {
    if {![dict exists $::GX::ApiCatalog::waiters $ticket]} return
    set callback [dict get $::GX::ApiCatalog::waiters $ticket];dict unset ::GX::ApiCatalog::waiters $ticket
    catch {{*}$callback $response}
}
proc ::GX::_apiCatalogNotify {response} {
    set callbacks $::GX::ApiCatalog::waiters;set ::GX::ApiCatalog::waiters {}
    dict for {ticket callback} $callbacks {catch {{*}$callback $response}}
    if {[llength [info commands ::GX::apiBrowserCatalogStatusChanged]]} {apiBrowserCatalogStatusChanged}
}
proc ::GX::_apiCatalogStart {} {
    set ::GX::ApiCatalog::pending {}
    if {$::GX::ApiCatalog::closed} {_apiCatalogNotify {ok 0 error {API catalog service is closed until interpreter restart} code {GX API_CATALOG CLOSED}};return}
    if {$::GX::ApiCatalog::request ne {}} return
    set ::GX::ApiCatalog::progress validating_identity
    if {[catch {
        set fingerprint [_apiCatalogFingerprint];set status [apiCatalogNative validate [_apiCatalogRequire]]
        set packaged [file join $::GX::scriptDir core api_catalog]
        set shipped [_apiCatalogJsonRead [file join $packaged source_manifest.json]]
        if {[apiCatalogNative file_digest [file join $packaged catalog.sqlite]] ne [dict get $shipped database_sha256]} {error {Packaged API catalog integrity changed; previous snapshot preserved}}
    } reason]} {
        set ::GX::ApiCatalog::freshness [expr {$::GX::ApiCatalog::handle eq {}?{unavailable}:{stale}}];set ::GX::ApiCatalog::error $reason;set ::GX::ApiCatalog::progress failed
        _apiCatalogNotify [dict create ok 0 error $reason];return
    }
    if {[dict get $status fingerprint] eq $fingerprint} {
        set ::GX::ApiCatalog::initialized 1
        set ::GX::ApiCatalog::freshness current;set ::GX::ApiCatalog::error {};set ::GX::ApiCatalog::progress complete
        _apiCatalogNotify [dict create ok 1 result [apiCatalogStatus]];return
    }
    # A process retains one definition snapshot. A matching prior staged index
    # may be admitted only at this first initialization, before Browser use.
    set staged [file join $::GX::ApiCatalog::directory pending]
    if {!$::GX::ApiCatalog::initialized && [file isfile [file join $staged source_manifest.json]]} {
        if {![catch {set m [_apiCatalogJsonRead [file join $staged source_manifest.json]];set valid [expr {[dict get $m fingerprint] eq [_apiCatalogFingerprint $m] && [apiCatalogNative file_digest [file join $staged catalog.sqlite]] eq [dict get $m database_sha256]}]}] && $valid} {
            if {[catch {_apiCatalogAdopt [file join $staged catalog.sqlite] $m} reason]} {
                set ::GX::ApiCatalog::initialized 1;set ::GX::ApiCatalog::freshness stale;set ::GX::ApiCatalog::error $reason;set ::GX::ApiCatalog::progress failed
                _apiCatalogNotify [dict create ok 0 error $reason];return
            }
            set ::GX::ApiCatalog::initialized 1;set ::GX::ApiCatalog::freshness current;set ::GX::ApiCatalog::progress complete
            _apiCatalogNotify [dict create ok 1 result [apiCatalogStatus]];return
        }
    }
    set ::GX::ApiCatalog::adopt [expr {!$::GX::ApiCatalog::initialized}]
    set ::GX::ApiCatalog::initialized 1
    set ::GX::ApiCatalog::target $fingerprint;set ::GX::ApiCatalog::freshness stale;set ::GX::ApiCatalog::progress staging_metadata
    set output [file join $::GX::ApiCatalog::directory stage.[pid].[clock clicks]]
    set command [list [runtimeToolRequired python] -I -B [file join $::GX::scriptDir core python gxtxt_api_catalog.py] stage [file normalize $::GX::scriptDir] $output]
    if {[catch {set ::GX::ApiCatalog::request [scriptJobAsync $command {} [list ::GX::_apiCatalogReceived $fingerprint $output] {timeout_ms 25000 max_bytes 1048576 process_group 1 ui_lifetime 1 label {API catalog metadata reconciliation}}]} reason]} {
        set ::GX::ApiCatalog::error $reason;set ::GX::ApiCatalog::progress failed;_apiCatalogNotify [dict create ok 0 error $reason]
    }
}
proc ::GX::_apiCatalogReceived {fingerprint output response} {
    if {$::GX::ApiCatalog::closed} return
    set ::GX::ApiCatalog::request {}
    if {[catch {
        if {![dict get $response ok]} {
            set reason [dict get $response error]
            if {[string trim $reason] eq {}} {
                set reason {API catalog metadata reconciliation worker exited without a diagnostic; previous snapshot preserved}
            }
            error $reason
        }
        set result [dict get $response result]
        set m [_apiCatalogJsonRead [file join $output source_manifest.json]]
        # The inert worker may discover binding-owned manuals absent from the
        # previous definition snapshot. Verify both inventories: the originally
        # scheduled installed sources must remain unchanged, and the completed
        # manifest (including those manuals) must still match the worker's
        # before/after identity. A newly referenced manual is not a source race.
        if {[_apiCatalogFingerprint] ne $fingerprint || [dict get $result fingerprint] ne [dict get $m fingerprint] || [_apiCatalogFingerprint $m] ne [dict get $m fingerprint]} {error {Installed sources changed during reconciliation; previous snapshot preserved}}
        if {[apiCatalogNative file_digest [file join $output catalog.sqlite]] ne [dict get $m database_sha256]} {error {Staged catalog integrity differs}}
        set pending [file join $::GX::ApiCatalog::directory pending]
        if {[file exists $pending]} {file rename $pending [file join $::GX::ApiCatalog::directory retained.[clock clicks]]}
        file rename $output $pending
    } reason]} {
        set ::GX::ApiCatalog::freshness stale;set ::GX::ApiCatalog::error $reason;set ::GX::ApiCatalog::progress failed
        _apiCatalogNotify [dict create ok 0 error $reason];return
    }
    if {$::GX::ApiCatalog::adopt} {
        if {[catch {_apiCatalogAdopt [file join $pending catalog.sqlite] $m} reason]} {
            set ::GX::ApiCatalog::freshness stale;set ::GX::ApiCatalog::error $reason;set ::GX::ApiCatalog::progress failed
            _apiCatalogNotify [dict create ok 0 error $reason];return
        }
        set ::GX::ApiCatalog::freshness current
    } else {set ::GX::ApiCatalog::freshness pending_restart}
    set ::GX::ApiCatalog::error {};set ::GX::ApiCatalog::progress complete
    set ::GX::ApiCatalog::target [dict get $m fingerprint]
    set ::GX::ApiCatalog::pendingMetadata [datasetPublicationV2DictDefault $m pending_metadata {}]
    _apiCatalogNotify [dict create ok 1 result [apiCatalogStatus]]
}

proc ::GX::apiCatalogStartup {} {
    if {![info exists ::GX::moduleOrder] || $::GX::ApiCatalog::initialized} return
    apiCatalogRefresh [list ::GX::_apiCatalogStartupResult]
}
proc ::GX::_apiCatalogStartupResult {response} {
    # Diagnostics remain public status; browsing can retain a marked old snapshot.
    return $response
}
after idle ::GX::apiCatalogStartup
