# IR Reference Library Type Provider

SPDX-License-Identifier: GPL-3.0-or-later

This independently installable GX-TXT module registers the
`spectroscopy.ir.reference` Scientific Library type. CORE owns package
integrity, managed storage, the registry and install/update/remove lifecycle.
This provider validates IR spectral meaning, checks stable spectrum IDs, and
exposes reference spectra. It contains no bundled library data.

Install the provider through Plugin Install API v1. Install compatible data
packages separately through Scientific Library Manager API v1 or the
Scientific Spectral Library Viewer **Install library...** action.


Version1.1.0 targets the complete DEV111-P025 framework, including its shared
normalized-content adapter. The base-version package constraint alone does not
establish patch compatibility; do not overlay this package on an older dev111
root that lacks the P025 adapter.

P025 version1.1.0 adds normalized managed consultation through Scientific Library
Manager `libraryEntriesPage`, `getLibraryEntryInfo`, `searchLibraryEntries` and
`readLibraryEntry`. The original scientific validator and spectrum reader retain
all numerical/units/metadata/provenance semantics. Pages are bounded and sorted
by stable spectrum ID, with continuation bound to content hash and exact query.
Search is literal case-insensitive SQLite substring search over IDs/compact
metadata, not scientific ranking. The `read_entry.payload` is the complete legacy
`read_spectrum` result (tuple arrays become JSON lists in the existing CORE wire).
The shared adapter resolves true managed storage through the existing manager,
uses read-only SQLite and creates no aliases, conversion or source cache.

The source remains immutable; external/remote specialized spectroscopy access is
not added by this adapter. Explicit policy permits consultation; free-text license
metadata never creates export/redistribution permission. Normalized export and
mutation stay unavailable. Existing specialized Viewers, managed package admission,
activation and legacy spectrum access remain unchanged.

Normalized reads are bounded by the existing CORE transport. Full reads through
32768 samples retain the complete legacy payload. Larger spectra require explicit
provider options `start` and `count` (zero-based, count0..32768, within the source).
The returned outer `metadata.read_range` records start/count/total; original
scientific fields including source sample_count stay unchanged, and X/Y contain
exact requested source samples. No default read silently truncates a spectrum.
Reassemble adjacent explicit ranges when full large-array consultation is needed;
no general Table Stream, canonical Dataset or scientific engine policy changes.
