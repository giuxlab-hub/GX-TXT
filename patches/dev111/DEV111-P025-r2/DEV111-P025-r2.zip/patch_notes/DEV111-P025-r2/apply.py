#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit P024-to-P025 preflight/apply; default is read-only."""
from pathlib import Path
import argparse, sys
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import GuardError, apply_overlay

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('framework', type=Path)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--apply', action='store_true', help='Explicitly write validated overlay; close GX-TXT first')
    args = parser.parse_args()
    manifest = apply_overlay(args.framework, args.archive, mutate=args.apply)
    print(('APPLIED' if args.apply else 'PREFLIGHT PASS (no writes)') +
          ': exact P024 preimages and all P025 payloads verified; source ' + manifest['source_commit'])
    if args.apply:
        print('Not activated by this helper. Restart and perform user VNC acceptance; acceptance remains OPEN.')

if __name__ == '__main__':
    try:
        main()
    except (GuardError, OSError, ValueError, KeyError) as error:
        raise SystemExit('REFUSED: ' + str(error))
