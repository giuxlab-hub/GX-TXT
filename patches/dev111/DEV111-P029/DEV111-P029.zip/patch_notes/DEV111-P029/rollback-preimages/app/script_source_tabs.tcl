# SPDX-License-Identifier: GPL-3.0-or-later
# One file-aware controller for Python/Octave; source editing stays in Source Surface.
namespace eval ::GX::ScriptSourceTabs {variable state;variable serial 0}
proc ::GX::scriptSourceTabsCreate {p editor language} {
    variable ::GX::ScriptSourceTabs::state
    ttk::frame $p
    ttk::frame $p.tools
    ttk::menubutton $p.tools.project -text Project -menu $p.tools.project.menu
    menu $p.tools.project.menu -tearoff 0
    foreach {label action} {{Open project file…} files {New file…} new {Rename/move file…} rename {Remove file} remove {Set entrypoint} entry} {
        $p.tools.project.menu add command -label $label -command [list ::GX::scriptSourceTabsAction $p $action]
    }
    pack $p.tools.project -side left -padx 2 -pady 2
    foreach {id label command} {save {Save All} save close {Close tab} close} {
        ttk::button $p.tools.$id -text $label -command [list ::GX::scriptSourceTabsAction $p $command]
        pack $p.tools.$id -side left -padx 2 -pady 2
    }
    pack $p.tools -side top -fill x
    ttk::combobox $p.chooser -state readonly -textvariable ::GX::ScriptSourceTabs::state($p,choice) -width 25
    pack $p.chooser -side top -fill x
    bind $p.chooser <<ComboboxSelected>> [list ::GX::scriptSourceTabsChoose $p]
    ttk::panedwindow $p.body -orient horizontal
    ttk::frame $p.body.tree -width 135
    pack propagate $p.body.tree 0
    ttk::treeview $p.body.tree.files -show tree -selectmode browse -height 6
    $p.body.tree.files column #0 -width 135 -minwidth 70 -stretch 0
    ttk::scrollbar $p.body.tree.scroll -command [list $p.body.tree.files yview]
    ttk::scrollbar $p.body.tree.horizontal -orient horizontal -command [list $p.body.tree.files xview]
    $p.body.tree.files configure -yscrollcommand [list $p.body.tree.scroll set] -xscrollcommand [list $p.body.tree.horizontal set]
    pack $p.body.tree.horizontal -side bottom -fill x
    pack $p.body.tree.scroll -side right -fill y
    pack $p.body.tree.files -side left -fill both -expand 1
    ttk::frame $p.body.source
    $p.body add $p.body.source -weight 4
    ttk::notebook $p.book -height 280
    pack $p.book -in $p.body.source -side top -fill both -expand 1
    pack $p.body -side top -fill both -expand 1
    set state($p,editor) $editor;set state($p,language) $language;set state($p,active) {};set state($p,switching) 0
    bind $p.book <<NotebookTabChanged>> [list ::GX::scriptSourceTabsSelected $p]
    bind $p.body.tree.files <<TreeviewSelect>> [list ::GX::scriptSourceTabsTreeSelected $p]
    bind $p.body <Configure> [list ::GX::scriptSourceTabsTreeWidth $p]
    bind $p <Destroy> [list ::GX::scriptSourceTabsDestroy $p %W]
    bind [winfo toplevel $p] <Control-Tab> "[list ::GX::scriptSourceTabsCycle $p 1];break"
    bind [winfo toplevel $p] <Control-Shift-Tab> "[list ::GX::scriptSourceTabsCycle $p -1];break"
    bind [winfo toplevel $p] <Control-ISO_Left_Tab> "[list ::GX::scriptSourceTabsCycle $p -1];break"
    return $p
}
proc ::GX::scriptSourceTabsDestroy {p actual} {
    if {$p ne $actual} return
    variable ::GX::ScriptSourceTabs::state
    foreach key [array names state "$p,*"] {unset state($key)}
}
proc ::GX::scriptSourceTabsCapture {p} {
    variable ::GX::ScriptSourceTabs::state
    if {$state($p,switching) || $state($p,active) eq {}} return
    set tab $state($p,active)
    upvar #0 $state($p,editor)::ui ui
    set fields {}
    foreach key {currentId currentSha revision scope scriptId name version requiredApis description arguments parameterDefinitions sessionToken baseline modified importDraft find} {
        if {[info exists ui($key)]} {dict set fields $key $ui($key)}
    }
    dict set fields parameterText [$ui(parameters) get 1.0 end-1c]
    set state($p,$tab,fields) $fields
    scriptSourceTabsLabels $p
}
proc ::GX::scriptSourceTabsOpen {p reference document {relative {}}} {
    variable ::GX::ScriptSourceTabs::state
    variable ::GX::ScriptSourceTabs::serial
    scriptSourceTabsCapture $p
    upvar #0 $state($p,editor)::ui ui
    if {$reference ne {} && [info exists ui(initialDraftTab)] && $state($p,active) eq $ui(initialDraftTab)} {
        $state($p,editor)::_recomputeDirty
        if {!$ui(modified)} {
            set old $state($p,active);set state($p,active) {};destroy $old
            foreach key [array names state "$p,$old,*"] {unset state($key)}
        }
        unset ui(initialDraftTab)
    }
    set kind [dict get $document kind]
    if {$relative eq {}} {set relative [expr {$kind eq {project} ? [dict get $document entrypoint] : [file tail [dict get $document source_path]]}]}
    foreach tab [$p.book tabs] {
        if {$reference ne {} && $state($p,$tab,reference) eq $reference && $state($p,$tab,path) eq $relative} {
            $p.book select $tab;scriptSourceTabsSelected $p;return $state($p,$tab,text)
        }
    }
    set tab $p.book.f[incr serial]
    ttk::frame $tab
    set mode [datasetPublicationV2DictDefault $document mode editable]
    set text [sourceSurfaceCreate $tab.surface [dict create mode $mode language [string tolower $state($p,language)] change_command [list ::GX::scriptSourceTabsChanged $p $tab]]]
    pack $tab.surface -fill both -expand 1
    if {$kind eq {project}} {
        if {![dict exists $document project_files $relative]} {error {File is absent from admitted project manifest}}
        set code [dict get [scriptRegistryProjectFiles $document] $relative]
    } else {set code [dict get $document code]}
    if {$mode eq {read_only}} {$text configure -state normal}
    $text insert 1.0 $code;$text edit reset;$text edit modified 0
    if {$mode eq {read_only}} {$text configure -state disabled}
    set state($p,$tab,text) $text;set state($p,$tab,reference) [expr {$reference eq {} ? "draft:$serial" : $reference}];set state($p,$tab,path) $relative
    set state($p,$tab,document) $document;set state($p,$tab,baseline) $code
    set fields [dict create currentId $reference currentSha [dict get $document sha256] revision [dict get $document revision] scope [dict get $document scope] scriptId [dict get $document id] name [dict get $document name] version [dict get $document version] requiredApis [dict get $document explicit_apis] description [dict get $document description] arguments [dict get $document default_arguments] parameterDefinitions [dict get $document parameters] parameterText [scriptParameterDefinitionsFormat [dict get $document parameters]] sessionToken [scriptWorkspaceSessionToken] modified 0 importDraft 0 find {}]
    set state($p,$tab,fields) $fields
    $p.book add $tab -text $relative
    $p.book select $tab
    scriptSourceTabsSelected $p
    return $text
}
proc ::GX::scriptSourceTabsSelected {p} {
    variable ::GX::ScriptSourceTabs::state
    if {![winfo exists $p] || $state($p,switching)} return
    set next [$p.book select]
    if {$next eq {} || $next eq $state($p,active)} return
    set previous $state($p,active)
    scriptSourceTabsCapture $p
    set fields $state($p,$next,fields)
    # A project's files share metadata, while keeping independent source buffers.
    if {$previous ne {} && $state($p,$previous,reference) ne {} && $state($p,$previous,reference) eq $state($p,$next,reference)} {
        foreach key {name version requiredApis description arguments parameterDefinitions parameterText scope scriptId sessionToken} {dict set fields $key [dict get $state($p,$previous,fields) $key]}
    }
    set state($p,switching) 1
    upvar #0 $state($p,editor)::ui ui
    dict for {key value} $fields {if {$key ne {parameterText}} {set ui($key) $value}}
    set ui(text) $state($p,$next,text)
    set ui(lines) [winfo parent $ui(text)].lines
    set ui(vscroll) [winfo parent $ui(text)].v
    set ui(activeFile) $state($p,$next,path)
    $ui(parameters) configure -state normal
    $ui(parameters) delete 1.0 end;$ui(parameters) insert 1.0 [dict get $fields parameterText]
    $ui(parameters) edit reset;$ui(parameters) edit modified 0
    set state($p,active) $next
    set state($p,switching) 0
    if {![dict exists $fields baseline]} {
        $state($p,editor)::_acceptBaseline
        scriptSourceTabsCapture $p
    }
    sourceSurfaceDocumentIdentity $ui(text) [list $ui(currentId) $ui(currentSha) $ui(activeFile)]
    set readonly [expr {[datasetPublicationV2DictDefault $state($p,$next,document) mode editable] eq {read_only}}]
    $p.tools.save state [expr {$readonly ? {disabled} : {!disabled}}]
    for {set i 1} {$i<=4} {incr i} {$p.tools.project.menu entryconfigure $i -state [expr {$readonly ? {disabled} : {normal}}]}
    set queue {}
    foreach name {props version requiredApis desc params args} {set widget $ui(window).p.center.$name;if {[winfo exists $widget]} {lappend queue $widget}}
    while {[llength $queue]} {
        set widget [lindex $queue 0];set queue [lrange $queue 1 end]
        lappend queue {*}[winfo children $widget]
        if {[winfo class $widget] in {TEntry TCombobox TCheckbutton}} {$widget state [expr {$readonly ? {disabled} : {!disabled}}]}
        if {[winfo class $widget] eq {Text}} {$widget configure -state [expr {$readonly ? {disabled} : {normal}}]}
    }
    $state($p,editor)::_watchProperties
    $state($p,editor)::_recomputeDirty
    $state($p,editor)::_refreshEditor
    scriptSourceTabsLabels $p
    scriptSourceTabsTree $p
    focus $ui(text)
}
proc ::GX::scriptSourceTabsTree {p} {
    variable ::GX::ScriptSourceTabs::state
    set doc [scriptSourceTabsCurrent $p]
    if {[dict get $doc kind] ne {project}} {
        if {"$p.body.tree" in [$p.body panes]} {$p.body forget $p.body.tree}
        return
    }
    if {"$p.body.tree" ni [$p.body panes]} {$p.body insert 0 $p.body.tree -weight 1;after idle [list ::GX::scriptSourceTabsTreeWidth $p]}
    set tree $p.body.tree.files
    $tree delete [$tree children {}]
    foreach path [lsort -dictionary [dict keys [dict get $doc project_files]]] {
        set parent {};set prefix {}
        foreach part [file split [file dirname $path]] {
            if {$part eq {.}} continue
            set prefix [expr {$prefix eq {} ? $part : "$prefix/$part"}]
            set id folder:$prefix
            if {![$tree exists $id]} {$tree insert $parent end -id $id -text $part -open 1}
            set parent $id
        }
        set label [file tail $path]
        if {$path eq [dict get $doc entrypoint]} {append label { (main)}}
        $tree insert $parent end -id file:$path -text $label -values [list $path]
    }
    set selected file:$state($p,$state($p,active),path)
    if {[$tree exists $selected]} {$tree selection set $selected;$tree see $selected}
    uiFieldInspectionColumnsSchedule $tree {recursive 1}
}
proc ::GX::scriptSourceTabsTreeWidth {p} {
    variable ::GX::ScriptSourceTabs::state
    if {[winfo exists $p.body] && [llength [$p.body panes]]==2 && [winfo width $p.body]>240 && [$p.body sashpos 0]<110} {$p.body sashpos 0 [expr {min(170,max(120,[winfo width $p.body]/3))}]}
    set tree $p.body.tree.files
    if {![winfo exists $tree]} return
    set key [list [font actual TkDefaultFont] [font actual TkHeadingFont] [ttk::style theme use] [winfo width $tree]]
    if {![info exists state($p,treeLayoutKey)] || $state($p,treeLayoutKey) ne $key} {
        set state($p,treeLayoutKey) $key
        uiFieldInspectionColumnsSchedule $tree {recursive 1}
    }
}
proc ::GX::scriptSourceTabsTreeSelected {p} {
    variable ::GX::ScriptSourceTabs::state
    if {![winfo exists $p] || $state($p,switching)} return
    set selection [$p.body.tree.files selection]
    if {[llength $selection]!=1 || ![string match file:* [lindex $selection 0]]} return
    set path [string range [lindex $selection 0] 5 end]
    if {$path eq $state($p,$state($p,active),path)} return
    scriptSourceTabsOpen $p $state($p,$state($p,active),reference) [scriptSourceTabsCurrent $p] $path
}
proc ::GX::scriptSourceTabsChanged {p tab} {
    variable ::GX::ScriptSourceTabs::state
    if {![info exists state($p,$tab,text)] || $state($p,switching)} return
    scriptSourceTabsLabels $p
    if {$state($p,active) eq $tab} {$state($p,editor)::_sourceChanged}
}
proc ::GX::scriptSourceTabsLabels {p} {
    variable ::GX::ScriptSourceTabs::state
    set choices {}
    foreach tab [$p.book tabs] {
        set dirty [expr {[$state($p,$tab,text) get 1.0 end-1c] ne $state($p,$tab,baseline)}]
        if {[info exists state($p,$tab,fields)] && [dict exists $state($p,$tab,fields) modified] && [dict get $state($p,$tab,fields) modified]} {set dirty 1}
        $p.book tab $tab -text "$state($p,$tab,path)[expr {$dirty ? { *} : {}}]"
        lappend choices "$state($p,$tab,reference) / $state($p,$tab,path)[expr {$dirty ? { *} : {}}]"
        if {$state($p,active) eq $tab} {set state($p,choice) [lindex $choices end]}
    }
    $p.chooser configure -values $choices
}
proc ::GX::scriptSourceTabsChoose {p} {
    variable ::GX::ScriptSourceTabs::state
    set index [lsearch -exact [$p.chooser cget -values] $state($p,choice)]
    if {$index>=0} {$p.book select [lindex [$p.book tabs] $index];scriptSourceTabsSelected $p}
}
proc ::GX::scriptSourceTabsCurrent {p} {variable ::GX::ScriptSourceTabs::state;return $state($p,$state($p,active),document)}
proc ::GX::scriptSourceTabsIdentity {p} {
    variable ::GX::ScriptSourceTabs::state
    if {![winfo exists $p] || $state($p,active) eq {}} {error {No active source tab}}
    upvar #0 $state($p,editor)::ui ui
    return [dict create reference $ui(currentId) sha256 $ui(currentSha) revision $ui(revision) relative_file $state($p,$state($p,active),path) source_widget $ui(text) source_widget_id [winfo id $ui(text)] session_token $ui(sessionToken) scope $ui(scope)]
}
proc ::GX::scriptSourceTabsWritable {p} {return [expr {[datasetPublicationV2DictDefault [scriptSourceTabsCurrent $p] mode editable] eq {editable}}]}
proc ::GX::scriptSourceTabsOpenSnapshot {p inspected {relative {}}} {
    variable ::GX::ScriptSourceTabs::state
    if {[dict get $inspected snapshot_validation] ne {verified} || [dict get $inspected language] ne $state($p,language)} {error {Open sources requires a verified matching-language Job snapshot}}
    set doc [dict merge [scriptRegistryDefaults] [dict create scope snapshot id [dict get $inspected id] name [dict get $inspected script_name] language [dict get $inspected language] version [dict get $inspected script_version] revision [dict get $inspected script_revision] sha256 [dict get $inspected source_sha256] mode read_only]]
    if {[dict exists $inspected project_manifest]} {
        set verified [scriptProjectVerify [file dirname [dict get $inspected project_manifest]]]
        if {[dict get $verified project_sha256] ne [dict get $doc sha256]} {error {Historical project source changed}}
        set doc [dict merge $doc $verified [dict create kind project]]
    } else {
        set source [dict get $inspected snapshot]
        if {[scriptRegistryHash $source] ne [dict get $doc sha256]} {error {Historical source changed}}
        set ch [::open $source rb];try {set code [scriptWorkspaceDecodeUtf8 [read $ch]]} finally {close $ch}
        dict set doc source_path $source;dict set doc code $code
    }
    return [scriptSourceTabsOpen $p snapshot:[dict get $inspected id] $doc $relative]
}
proc ::GX::scriptSourceTabsDirty {p} {
    variable ::GX::ScriptSourceTabs::state
    if {$state($p,active) eq {}} {return 0}
    set ref $state($p,$state($p,active),reference)
    foreach tab [$p.book tabs] {
        if {$state($p,$tab,reference) eq $ref && [$state($p,$tab,text) get 1.0 end-1c] ne $state($p,$tab,baseline)} {return 1}
    }
    return 0
}
proc ::GX::scriptSourceTabsFiles {p} {
    variable ::GX::ScriptSourceTabs::state
    set doc [scriptSourceTabsCurrent $p]
    set files [scriptRegistryProjectFiles $doc]
    set ref $state($p,$state($p,active),reference)
    foreach tab [$p.book tabs] {if {$state($p,$tab,reference) eq $ref} {dict set files $state($p,$tab,path) [$state($p,$tab,text) get 1.0 end-1c]}}
    return $files
}
proc ::GX::scriptSourceTabsSaved {p result} {
    variable ::GX::ScriptSourceTabs::state
    upvar #0 $state($p,editor)::ui ui
    set ref $state($p,$state($p,active),reference)
    set newRef "[dict get $result scope]:[dict get $result id]"
    foreach tab [$p.book tabs] {
        if {$state($p,$tab,reference) ne $ref} continue
        set state($p,$tab,reference) $newRef;set state($p,$tab,document) $result
        set state($p,$tab,baseline) [$state($p,$tab,text) get 1.0 end-1c]
        set f $state($p,$tab,fields)
        foreach {key value} [list currentId $newRef currentSha [dict get $result sha256] revision [dict get $result revision] scriptId [dict get $result id] name [dict get $result name] version [dict get $result version] description [dict get $result description] requiredApis [dict get $result explicit_apis] arguments [dict get $result default_arguments] parameterDefinitions [dict get $result parameters] parameterText [scriptParameterDefinitionsFormat [dict get $result parameters]] modified 0] {dict set f $key $value}
        dict unset f baseline
        set state($p,$tab,fields) $f
        sourceSurfaceDocumentIdentity $state($p,$tab,text) [list $newRef [dict get $result sha256] $state($p,$tab,path)]
    }
    set ui(parameterDefinitions) [dict get $result parameters]
    foreach {key value} [list currentId $newRef currentSha [dict get $result sha256] revision [dict get $result revision] scriptId [dict get $result id] name [dict get $result name]] {set ui($key) $value}
    $ui(parameters) delete 1.0 end;$ui(parameters) insert 1.0 [scriptParameterDefinitionsFormat $ui(parameterDefinitions)]
    $ui(parameters) edit modified 0
    scriptSourceTabsLabels $p
    scriptSourceTabsTree $p
}
proc ::GX::scriptSourceTabsCycle {p delta} {
    set tabs [$p.book tabs];if {![llength $tabs]} return
    set i [lsearch -exact $tabs [$p.book select]]
    $p.book select [lindex $tabs [expr {($i+$delta+[llength $tabs])%[llength $tabs]}]]
}
proc ::GX::scriptSourceTabsClose {p {all 0}} {
    variable ::GX::ScriptSourceTabs::state
    scriptSourceTabsCapture $p
    set tabs [expr {$all ? [$p.book tabs] : [list [$p.book select]]}]
    set reviewed {}
    foreach tab $tabs {
        if {![winfo exists $tab]} continue
        $p.book select $tab;scriptSourceTabsSelected $p
        upvar #0 $state($p,editor)::ui ui
        $state($p,editor)::_recomputeDirty
        set identity $state($p,$tab,reference)
        if {$ui(modified) && $identity ni $reviewed} {
            set choice [tk_messageBox -parent [winfo toplevel $p] -type yesnocancel -default cancel -title {Unsaved source} -message "Save changes for $state($p,$tab,path)?"]
            if {$choice eq {cancel}} {return 0}
            if {$choice eq {yes} && ![$state($p,editor)::_save]} {return 0}
        }
        lappend reviewed $identity
    }
    foreach tab $tabs {
        if {![winfo exists $tab]} continue
        set state($p,active) {};destroy $tab
        foreach key [array names state "$p,$tab,*"] {unset state($key)}
    }
    if {!$all} {
        if {[llength [$p.book tabs]]} {scriptSourceTabsSelected $p} else {$state($p,editor)::_new}
    }
    return 1
}
proc ::GX::scriptSourceTabsAction {p action} {
    variable ::GX::ScriptSourceTabs::state
    if {$action eq {close}} {scriptSourceTabsClose $p;return}
    if {$action eq {save}} {
        set original [$p.book select]
        set saved {}
        foreach tab [$p.book tabs] {
            $p.book select $tab;scriptSourceTabsSelected $p
            if {![scriptSourceTabsWritable $p]} continue
            upvar #0 $state($p,editor)::ui ui
            $state($p,editor)::_recomputeDirty
            set identity $state($p,$tab,reference)
            if {$identity in $saved || !$ui(modified)} continue
            if {![$state($p,editor)::_save]} {return 0}
            lappend saved $identity
        }
        if {[winfo exists $original]} {$p.book select $original};return
    }
    set doc [scriptSourceTabsCurrent $p]
    if {[dict get $doc kind] ne {project}} {tk_messageBox -parent [winfo toplevel $p] -message {Project file operations require a registered Script Project. Create or import one in Script Library.};return}
    if {$action eq {files}} {
        set menu $p.filemenu;catch {destroy $menu};menu $menu -tearoff 0
        foreach path [dict keys [dict get $doc project_files]] {$menu add command -label $path -command [list ::GX::scriptSourceTabsOpen $p $state($p,$state($p,active),reference) $doc $path]}
        tk_popup $menu [winfo pointerx $p] [winfo pointery $p];return
    }
    if {![scriptSourceTabsWritable $p]} {error {Historical source tabs are read-only}}
    # Changes are committed in ONE Registry Save All transaction, including all
    # dirty source tabs; a stale revision never partially renames the tree.
    set tab $state($p,active);set path $state($p,$tab,path)
    if {$action in {new rename}} {
        set w [winfo toplevel $p].projectPath;catch {destroy $w};toplevel $w;wm transient $w [winfo toplevel $p]
        set state($p,pathInput) [expr {$action eq {rename} ? $path : {}}]
        ttk::label $w.hint -text {Normalized relative source path (subfolders allowed):}
        ttk::entry $w.value -textvariable ::GX::ScriptSourceTabs::state($p,pathInput) -width 45
        ttk::button $w.ok -text Apply -command [list ::GX::scriptSourceTabsFileCommit $p $action $w]
        ttk::button $w.cancel -text Cancel -command [list destroy $w]
        pack $w.hint $w.value $w.ok $w.cancel -fill x -padx 8 -pady 5
        bind $w.value <Return> [list ::GX::scriptSourceTabsFileCommit $p $action $w]
        bind $w <Escape> [list destroy $w];focus $w.value;return
    }
    scriptSourceTabsFileCommit $p $action {}
}
proc ::GX::scriptSourceTabsFileCommit {p action dialog} {
    variable ::GX::ScriptSourceTabs::state
    upvar #0 $state($p,editor)::ui ui
    if {![scriptWorkspaceEditorSessionValid [winfo toplevel $p] $ui(sessionToken) $ui(scope)]} return
    if {[catch {
        set doc [scriptSourceTabsCurrent $p];set files [scriptSourceTabsFiles $p]
        set entry [dict get $doc entrypoint];set tab $state($p,active);set path $state($p,$tab,path)
        switch -- $action {
            new {set target $state($p,pathInput);if {[dict exists $files $target]} {error {File already exists}};dict set files $target {}}
            rename {set target $state($p,pathInput);if {[dict exists $files $target]} {error {File already exists}};dict set files $target [dict get $files $path];dict unset files $path;if {$entry eq $path} {set entry $target}}
            remove {if {$entry eq $path} {error {Select another entrypoint before removing this file}};if {[tk_messageBox -parent [winfo toplevel $p] -type okcancel -default cancel -message "Remove $path from the project and save all edited files?"] ne {ok}} return;dict unset files $path}
            entry {set entry $path}
        }
        set result [scriptRegistryProjectUpdate $ui(scope) $ui(scriptId) $ui(currentSha) [dict create parameters [$state($p,editor)::_parametersFromEditor] expected_revision $ui(revision)] $entry $files]
        if {$action eq {rename}} {set state($p,$tab,path) $target;set ui(activeFile) $target}
        scriptSourceTabsSaved $p $result
        set ui(currentSha) [dict get $result sha256];set ui(revision) [dict get $result revision]
        $state($p,editor)::_acceptBaseline
        if {$dialog ne {}} {destroy $dialog}
        if {$action eq {new}} {scriptSourceTabsOpen $p $ui(currentId) $result $target}
        if {$action eq {remove}} {set state($p,active) {};destroy $tab;scriptSourceTabsOpen $p $ui(currentId) $result $entry}
    } reason]} {tk_messageBox -parent [winfo toplevel $p] -icon error -title {Project change refused} -message $reason}
}
proc ::GX::scriptSourceTabsBreakpoints {p} {
    variable ::GX::ScriptSourceTabs::state
    set out {};set reference $state($p,$state($p,active),reference)
    foreach tab [$p.book tabs] {
        if {$state($p,$tab,reference) ne $reference} continue
        set lines [sourceSurfaceBreakpoints $state($p,$tab,text)]
        if {$lines ne {}} {dict set out $state($p,$tab,path) $lines}
    }
    return $out
}
proc ::GX::scriptSourceTabsDebugFile {p path sha} {
    variable ::GX::ScriptSourceTabs::state
    set doc [scriptSourceTabsCurrent $p]
    if {[dict get $doc kind] ne {project} || [dict get $doc sha256] ne $sha} {return {}}
    # Frozen file suffix is compared to the admitted manifest, never an arbitrary
    # filesystem path. Navigation opens the corresponding saved source buffer.
    foreach name [dict keys [dict get $doc project_files]] {
        if {[string match "*/project/files/$name" [string map {\\ /} $path]]} {
            return [scriptSourceTabsOpen $p $state($p,$state($p,active),reference) $doc $name]
        }
    }
    return {}
}
