# DEV111-P029: Python and GNU Octave editor menus and source tabs

This direct-root incremental overlay changes only the Python/Octave editor primary menus, Save All and per-tab close/navigation presentation, with the shared source-tab/workspace controller and release metadata. It removes the redundant toolbar and source chooser, preserving the project tree. Python is1.6.1 and GNU Octave is1.8.1. No native component is changed or rebuilt. Independent functional and native GUI acceptance remains a separate release gate; preparation alone is not acceptance.

Exact predecessor: DEV111-P028-r2 source `71f737502d6abcde4d386e6d0955e61ecf02f2c5`, archive SHA256 `21e17dbab2173824ba90c04b1558cc83b256d80b3a0f8d77b09940ebc8b5f750`. Source: `3673ccc941fad9965d461c8b16ee1380a3e69173`. The full essential predecessor runtime closure is derived from that exact archive's BASELINE plus FILES postimages, including physical modes. Prior notes and extra user files are retained; unknown/mixed/partial roots and collisions at added paths refuse. Paths overlay the framework root directly, without a wrapper directory. Check DELETIONS.json; plain unzip cannot implement deletions.

Keep the ZIP and adjacent .sha256. Stop the target GX-TXT and all its workers and keep a full backup before any change. Helpers do not detect/stop processes; --stopped is operator acknowledgement. Extract only patch_notes/DEV111-P029/ to a separate review directory, then:

    python3 review/patch_notes/DEV111-P029/apply.py FRAMEWORK DEV111-P029.zip --check
    python3 review/patch_notes/DEV111-P029/apply.py FRAMEWORK DEV111-P029.zip --apply --stopped

Default is read-only. Guarded writes use a POSIX directory lock and atomic per-file replacement, not a whole-root transaction. Complete verified rollback notes are published before product writes. After interruption, inspect with rollback --check --recover-partial; only exact known before/after bytes and modes qualify. If notes publication itself was interrupted, recover the complete verified notes from this exact ZIP first without overwriting product files. Unknown edits refuse.

    python3 FRAMEWORK/patch_notes/DEV111-P029/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P029/rollback.py FRAMEWORK --rollback --stopped

Rollback restores P028-r2 bytes/modes, removes only P029-added product files and retains notes/directories/extras. Reverse later patches first. For a deliberate reapply, move retained P029 notes to separate evidence only after successful rollback; helpers never overwrite existing notes. No Session, preference, RAW, original data or prior archive cleanup is performed.

The complete overlay already bundles both modules in MODULE_VERSION_MATRIX.json. `companion_preflight.py FRAMEWORK DEV111-P029.zip` checks exact P029 host postimages and reports already_bundled_install_not_required. Separate standard Module ZIPs are an alternative delivery, installable through the normal Plugin Manager on a separately prepared compatible host with absent or legitimately managed target. framework_min=dev111 cannot distinguish P028-r2/P029. Do not fabricate plugin registry entries or remove bundled targets to force admission. Normal plugin lifecycle transactions may invalidate exact overlay/rollback identity; retain a stopped full backup before them. No reinstall, active installation, activation or canonical deposit is authorized by these helpers.
