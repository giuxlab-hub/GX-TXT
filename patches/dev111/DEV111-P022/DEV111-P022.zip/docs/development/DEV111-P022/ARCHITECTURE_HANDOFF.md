# P022 architecture handoff

SPDX-License-Identifier: GPL-3.0-or-later

The accepted Native3D engine library, source, public C headers and algorithms are
unchanged. Its camera, projection, picking, Navigation Cube and renderer remain
authoritative. Native2D C geometry/constraints, P017 History, scientific Dataset
and publication owners, P012 scheduling and P020 diagnostics remain unchanged.

The existing Tcl transport C++ target gains ordered camera batching, bounded
wall-clock span receipts and opt-in lossless intermediate PNG encoding. The
existing GUI owners select that transport; there is no second renderer or event
loop. Renderer failures retain explicit configuration/device/log diagnostics;
failed components require deliberate rebind/reopen rather than pointer-triggered
restart storms. Auto's existing one-initial-frame recovery remains bounded.

The existing Native2D presentation batch gains world_points/device_points. They
call the existing scientific C conversion functions for every finite XY row.
Projected CAD uses them and reuses segment presentation within its current cache.
Scientific topology, references, selection and geometry remain in their owners.

nativeCadSketchDocumentPresentation reads saved exact Sketch definitions, samples
only a bounded visual representation and uses native plane-frame/Unit Registry
services. native3DGuiHostDocumentPresentationSet/Remove/Inspect manage those
current-owner renderer resources. Workbench calls these services on explicit
Open/Close/refresh. Source Document identity and History remain canonical; there
is no continuous duplicate editor/scene mirror or new persistent format.

Editing a borrowed viewport requires the existing scientific source/world unit
scale to agree. Closed display snapshots may explicitly convert compatible
length units. The source declaration is never silently changed.

See ../../api/NATIVE3D_GUI_STABILIZATION_P022.md for contracts, limits, ownership,
error handling and the distinction between an always-on-top active editing
overlay and normal native depth/occlusion of closed saved display geometry.
