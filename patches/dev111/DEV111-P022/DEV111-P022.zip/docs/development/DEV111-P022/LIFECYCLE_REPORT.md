# P022 Sketch lifecycle

SPDX-License-Identifier: GPL-3.0-or-later

Actual normal3D CAD Workbench controls/input, private fixture03, local X11:

1. Line→two points→Finish→new Line→one point→Escape: committed first geometry
   retained; cancelled proposal adds no committed geometry or History step.
2. Active editor Close: saved exact Document remains and visible closed geometry
   is rendered through Native3D. Actual closed orbit does not need a second editor.
3. Reopen associated Sketch: same scientific Document/model and History, static
   display removed while editing; close restores it. No duplicate live mirror.
4. Working Plane form sets origin(5,2,1), normalized normal(1,1,1), U(1,-1,0).
   Create/Line/Finish/Save/Close/Reopen preserves Doc15, frame, model and History.
   Close/Create Again allocates independent Doc16 without deleting Doc15.
5. Close with unfinished proposal: Cancel leaves proposal/committed model/History
   intact; No discards only uncommitted proposal; Yes finishes variable-length
   Polyline and saves. Exact retained three controls, count2 durable History,
   Undo/Redo-compatible definitions are observed, not inferred from pixels.
6. Actual rapid camera input followed immediately by Close finishes safely and
   leaves saved display. The close-handler trace saw busy0; true forced overlap
   with a native RPC is NOT VERIFIED and is not claimed by that test.
7. Save Workbench association, close parent Viewer, answer normal Workspace Save,
   close the complete application. Fresh normal application launch, actual Open
   Session chooser, ordinary3D CAD Workbench tile, select idoc_0006/Open and Open
   associated Sketch: idoc_0016 model exactly equals saved close-yes02 model;
   History count2, pending0; plane and units remain mm/origin5,2,1/inclined normal.
   Close again displays saved geometry. Evidence restore02; screenshots inspected.
8. Both perspective/orthographic actual camera controls move through edge-on,
   horizon and behind cases. The staged Line remains staged; model and History
   remain unchanged. Camera is unrestricted, Fit/Escape recover editing. Temporary
   unmappability does not destroy the Sketch or silently commit/cancel it.

No user Session was opened for mutation. No Document/History format or native
solver change was made. Closed snapshots are bounded visual sampling; exact
scientific definitions and canonical History remain in existing authorities.
