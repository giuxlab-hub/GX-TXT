# P022 verified causes and corrections

SPDX-License-Identifier: GPL-3.0-or-later

## Explicit Hardware startup

The normal full application, launched from the existing XFCE desktop environment
on DISPLAY=:0, failed twice after actual Configuration selection of Hardware.
The renderer child exited before its first frame. The parent remained running.
Auto retried that initial read-only frame once using Mesa Software.

The failed GUI request was retained and replayed under bounded diagnostics. The
crash stack entered libnvidia-tls.so.390.157's pthread_create interposition and
called address zero through TBB/VTK. Removing the address-space budget did not
fix it. Debugger execution changed its behavior and was not counted as GUI
acceptance. Eager symbol binding and creating a native thread after interpreter
startup did not fix the replay. Preloading the system libpthread SONAME before
loading the graphics dependency graph did.

The installed NVIDIA manual, knownissues.html, section “Interaction with
pthreads”, documents this initialization-order remedy. CORE now applies it only
to Linux renderer-child commands. Existing preload entries are retained; the
GUI and scientific Job environments are not changed. Software retains explicit
Mesa vendor selection. Fresh full-application GUI tests then rendered correctly
in explicit Hardware: GeForce GT610, NVIDIA390.157, OpenGL4.5. This is evidence
for this supported local configuration, not a guarantee for every GPU or display.

## Preview navigation and image transport

The old Preview kept one pending request and overwrote it while its worker was
busy. Relative camera operations therefore disappeared. P022 keeps a bounded
ordered queue and batches adjacent relative requests through the same native C
camera functions. It does not add noncommuting rotations together. Absolute
pending presentation requests may supersede their obsolete equivalents. Queue
saturation is explicit, not silently reported as applied input.

Original intermediate PNG encoding consumed approximately26ms in initial real-GUI
Hardware samples. A same-frame API comparison separately verifies the original
encoder against the new lossless intermediate encoder, without changing pixels,
sampling or geometry. The existing public RGBA buffer is encoded with libpng
compression1/no filters. Explicit scientific export/capture keeps the original
encoder. Native rendering and its framebuffer capture are unchanged.

Some later normal runs contained approximately418/449ms PNG-output outliers.
That span includes buffer copying, encoding and file operations. A single bounded
syscall diagnostic did not reproduce them; file syscalls in that run were below
0.2ms. The outliers are retained and their deeper cause is not established.
P022 does not claim to eliminate every latency spike or replace the PNG/IPC path.

## Projected CAD preparation

Detailed baseline tracing found tens of thousands of scalar Tcl/native coordinate
calls and repeated segment-hit primitive preparation during a50-object edit.
The presenter now batches coordinate conversions through the existing C engine
and retains unchanged projected segment primitives in its existing invalidated
object/frame cache. Epoch-checked scientific references are refreshed each pass.
No selection, snapping, spline or coordinate algorithm was duplicated.

## Sketch lifecycle and temporarily invalid views

Previously closing the editor destroyed the only visible representation. The
saved exact Document remained, but no renderer presentation survived. An explicit
read-only CORE snapshot now supplies bounded visual geometry when the editor is
closed. Workbench owns its Document associations; CORE owns the derived renderer
resources and rejects stale revisions, generations, Sessions and owners.
Snapshots are prepared on explicit lifecycle transitions, never continuously
mirrored from pointer motion. Reopening removes the matching static presentation
and restores the same exact Document and P017 History.

An edge/horizon/behind-camera pointer could reach the CAD rejection/cancellation
route despite being a temporary camera condition. The surface now stops unmappable
CAD pointer input before that route, while retaining navigation and explicit
Finish/Cancel. Six real-GUI projection cases preserved the staged proposal, model
and History and recovered through normal Fit/Escape.

## Desktop input method observation

One application close hung after its renderer had exited. The actual parent stack
was Xlib XDestroyIC waiting for the existing desktop XIM/IBus server. The existing
IBus service was restarted and only the hung isolated test application terminated.
Subsequent fresh application closes passed. No speculative Tk/Native3D change was
made for that external observation. No X-server restart or GPU/OS installation
was performed during P022.
