# DEV111-P022 — real-GUI Native3D stabilization

SPDX-License-Identifier: GPL-3.0-or-later

Incremental overlay after the exact deposited P021
b30bc478125dc8ea742094478d17b844eeb2d789. P021 ZIP SHA256:
6930a0f06b4fcea9b8b4f7d77cd6af234c1c588d87549ec08018c5dd479f074a.
Apply the existing cumulative DEV111 chain through P021 first. P022 does not
install drivers or require restarting the X server. Stop the target application
before applying or rolling back. Do not apply into a running installation.

This patch fixes the reproduced explicit-Hardware NVIDIA390 pthread-startup
failure, preserves queued Preview camera input, reduces intermediate image and
projected CAD preparation costs, preserves staged geometry in unmappable camera
views and retains saved Sketch display after closing its editor. Scientific
engines, solver, History, export encoder and existing public APIs are preserved.
Linux x86-64 Tcl native binaries and matching sources/build integration included.

## Guarded installation

Extract only the notes to an empty review directory first:

```sh
unzip /path/DEV111-P022.zip 'patch_notes/DEV111-P022/*' -d /path/review-p022
python3 /path/review-p022/patch_notes/DEV111-P022/apply.py /path/framework /path/DEV111-P022.zip
python3 /path/review-p022/patch_notes/DEV111-P022/apply.py /path/framework /path/DEV111-P022.zip --apply
```

The first command is read-only preflight. The explicit `--apply` command verifies
all changed preimages, protected authorities, payload checksums and path/mode
safety before mutation. It refuses partial/divergent baselines and overwriting
existing P022 notes. Restart normally afterward. Workbench module is0.3.4.
Application verification does not mean P020/P021 or P022 user acceptance.

## Guarded rollback

```sh
python3 /path/framework/patch_notes/DEV111-P022/rollback.py /path/framework --check
python3 /path/framework/patch_notes/DEV111-P022/rollback.py /path/framework
```

Verify the postimages/backups before restoration. Rollback restores exact P021
product bytes/modes and removes only added P022 product files; notes remain as
evidence. It does not modify scientific Sessions, preferences or user data.
Do not force a rollback over subsequent changes; preserve/reconcile those first.

## VNC acceptance

On the supported local Debian desktop, use Configuration to test Software, Auto
and explicit Hardware independently. Open Builder Preview, C++ Native3D and
TEST CAD1/2 normally; inspect colored geometry/Navigation Cube and orbit/pan/zoom.
In3D CAD Workbench, draw/Finish another line, cancel a proposal, edit/Undo/Redo,
Save, Close and reopen the same Sketch. Verify saved geometry remains visible
while closed, including an inclined plane. Rotate across edge/horizon/behind
views and recover without losing committed or staged scientific state. Exercise
molecule Dataset Preview rotation. Read known limits and all performance samples.

NOT INSTALLED. User VNC acceptance remains OPEN. The independent architecture
experiment is a separate post-deposit review artifact, not P022 installation.
