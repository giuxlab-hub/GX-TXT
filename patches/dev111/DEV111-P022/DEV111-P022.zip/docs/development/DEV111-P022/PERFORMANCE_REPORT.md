# P022 real-application performance

SPDX-License-Identifier: GPL-3.0-or-later

## Conditions and comparability

All GUI input used the normal complete `wish gxtxt_pipeline.tcl` application on
Debian13/XFCE, local X11 DISPLAY=:0, NVIDIA390.157/GT610 or Mesa25.0.7 llvmpipe.
The parent inherited the actual desktop environment, without test-only graphics
variables. Configuration changes used the actual GUI. These are GUI-local
measurements, not VNC/network latency or GPU timer queries.

The protected P021 original crashes in explicit Hardware. For the comparable
baseline, detached commit4885fb8a contains P021 plus only the necessary renderer
child pthread-startup prerequisite. The final native Tcl bridge provides passive
stage timings; old Tcl retains the old PNG encoder and overwrite queue. Its only
extra Tcl instrumentation records last-request/receipt timestamps. The precise
variant and differences are in evidence/COMPARABLE_BASELINE.json and
BASELINE_SPAN_INSTRUMENTATION.json. The scientific engine remains unchanged.

Fresh private fixtures06/07 have byte-identical exact retained models for1/10/50
objects (11 controls each, every fifth a spline), units and planes. The same
current lightweight timing helper and mouse sequence drive baseline/candidate.
No per-native-primitive traces were enabled for this comparison. Earlier detailed
profiles establish call-path costs but are not used for headline speedup ratios.
Nested presenter/Host spans are not added together. CPU observations have10ms
clock-tick resolution; observer/input/trace overhead remains in stated timings.

## CAD defining-control edit

The actual GUI selects each Workbench Document, opens its associated Sketch,
moves one real defining control18,-12 device pixels in four pointer steps,
releases and performs GUI Undo. Exact committed-model change and exact Undo
restoration passed in both. Viewport527x609 and selected control are identical.

| Objects | Median whole Host redraw P021 / P022 ms | Observed gesture P021 / P022 ms | Post-release P021 / P022 ms | Open P021 / P022 ms |
|---|---:|---:|---:|---:|
|1|5.819 /4.747|318.39 /324.93|75.27 /72.60|8931 /8807|
|10|23.5545 /14.351|331.58 /360.23|66.69 /94.29|3565 /3428|
|50|107.493 /71.058|496.51 /423.57|208.81 /153.64|3663 /3538|

Whole Host spans for50 objects: P02193.752,111.220,107.493ms;
P02271.058,33.354,71.396ms. The median reduces33.9%, observed post-release26.4%.
This does not establish a universal gesture speedup: the10-object end-to-end
sample regressed despite lower presentation cost. Open remains multi-second,
with a much colder first case. Setup costs are not claimed fixed.

Detailed diagnostic profiles identified scalar coordinate Tcl/native crossings
and repeated segment-hit primitive construction. P022 uses existing native
coordinate rules in bounded batches and the existing frame/object invalidation
cache. It preserves exact geometry, projection and native selection references.

## Molecular Preview orbit

Same canonical ATP SDF, same48,24 total pointer displacement,12 generated moves,
12ms intended cadence. X11 may combine moves: accepted application callbacks are
counted separately. Old recursive queue dispatch is not counted as new input.

| Mode / implementation | Accepted / applied native operations | Completed frames | Gesture / post-release ms | Median native render / PNG / PhotoImage ms |
|---|---:|---:|---:|---:|
|Hardware P021 variant|12 /3|3|578.82 /384.70|34.14 /26.08 /18.329|
|Hardware P022|12 /12|5|343.43 /140.65|34.11 /5.03 /11.979|
|Software P021 variant|12 /4|4|300.97 /97.34|21.41 /27.13 /18.501|
|Software P022|11 /11|6|283.26 /74.63|20.72 /4.96 /12.300|

P022 applied every accepted delta; each candidate accepted sum is48,24. Existing
ordered native camera operations are applied individually, never replaced by a
sum of noncommuting rotations. The old queue discarded relative operations.
Frame counts differ because the candidate preserves more work. Accordingly,
whole elapsed figures compare user journeys, not identical native work counts.

Per-frame native preparation is0.01ms in these orbit samples. Native rendering
includes existing framebuffer capture, not just GPU draw submission. Candidate
Hardware native30.06..44.24ms, Software20.31..23.15ms: this old GT610 is not faster
than llvmpipe for every small scene. Candidate PNG4.90..6.31ms Hardware and
4.95..5.17ms Software. Hardware PhotoImage includes one39.34ms outlier; other
samples11.85..12.00ms. The readable/presentation callback includes decoding:
Hardware16.73..49.25ms; Software16.98..19.18ms. Do not add nested timings twice.

CPU GUI/worker totals over those bursts: Hardware baseline110/190ms,
candidate150/230ms; Software baseline130/840ms, candidate170/1140ms. More native
operations/frames are actually performed; reduced image cost is not a claim of
lower total scientific-worker CPU in this input-preserving comparison.

## Outliers and attribution limits

All named samples are retained in evidence/METRICS.json. Additional candidate
Hardware bursts259..672ms, Software284..665ms include PNG-output spans418.23ms
and448.84ms. A baseline comparable Hardware span was341.87ms. These include
copy/encoding/file work; their deeper cause is not established. A single bounded
worker syscall trace did not reproduce a spike (file syscalls<0.2ms), so there is
no supported claim that disk latency caused them. The diagnostic trace is not
mixed into the matched normal timing pair. The original user multi-second
interaction stall was not reproduced as an individual steady orbit redraw;
opening Sketches still demonstrably takes seconds.

A complementary same-native-frame API experiment writes both lossless encoders
three times at640x480 in each camera projection: old11.55..12.45ms,
fast2.12..2.16ms. All12 decoded outputs are RGBA-byte-identical. This verifies
encoder cost/pixel equivalence independently; it is not GUI acceptance evidence.

## Remaining costs

Native rendering/framebuffer capture, PNG encoding/IPC/PhotoImage and Tk Canvas
presentation remain. There is no renderer rewrite, no lower sampling quality,
no approximate science and no claim of eliminating all stalls. Interaction and
setup findings are supplied for user evaluation and the separately authorized
post-deposit architecture evaluation. That work is not folded into P022.
