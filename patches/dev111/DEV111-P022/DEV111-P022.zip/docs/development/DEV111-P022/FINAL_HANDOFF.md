# DEV111-P022 handoff

SPDX-License-Identifier: GPL-3.0-or-later

P022 is an incremental corrective overlay after deposited P021. The archive's
FILES.json and VERIFICATION.json identify the final source commit and pre/post
hashes. Runtime GUI qualification used8bc9fbaede1a316e82ab921d9775413c7164f2a5;
final changes after that commit are only validation/evidence/reports/checksums.
No historical release, installed framework, original Session or TODO is modified.

Delivered corrections:

- Reproduced explicit local Hardware driver/thread initialization failure; narrow
  renderer-child system pthread preload, actual normal Software/Auto/Hardware GUI
  verification and truthful device/error receipts.
- Ordered bounded native camera batching preserves accepted Preview input. Lower
  cost lossless intermediate PNG is active in normal shared GUI paths, with the
  scientific export encoder and optimized Native3D engine unchanged.
- Native coordinate batching and existing-cache segment reuse reduce measured
  projected CAD preparation. Native2D science, native hit/selection algorithms,
  spline definitions, snapping and P017 History remain authoritative.
- Temporarily unmappable camera views stop invalid CAD pointer dispatch while
  allowing camera navigation, preserving staged/committed scientific state.
- Saved Sketch display survives editor Close using bounded read-only presentation
  resources; reopen restores same Document/History. Workbench0.3.4 integrates it
  through explicit lifecycle transitions rather than continuous scene mirroring.

Matched50-object median whole Host redraw107.493→71.058ms; observed post-release
208.81→153.64ms.10-object observed gesture did not improve. Matched molecular
Hardware burst578.82→343.43ms while applied operations3→12; Software300.97→283.26ms,
4→11. These are small controlled GUI-local samples, not universal guarantees.
Native engine rendering/framebuffer, PhotoImage and multi-second Sketch startup
remain; unexplained341..449ms output-tail samples are disclosed. See all samples
in PERFORMANCE_REPORT.md/evidence, including regressions/outliers.

GUI: normal authored C++ Native3D, example/gallery, Builder Preview modes,
TEST CAD1/2,1/10/50 edits/Undo, tilted/invalid views, Finish/Cancel/Close choices,
Save and full app reopen verified. Supplementary independent API checks cover
batch equivalence, rejected mutation rollback, saved-source invariance, units,
stale resource rejection/disposal and lossless image pixels. Real remote X11 and
other GPU/platform combinations are not qualified. Forced close overlapping a
still-running native RPC remains unverified; ordinary immediate-input close passed.
An external XIM/IBus close hang is documented separately, without speculative fix.

Matching Linux x86-64 binaries/sources and CMake integration included. Native3D
libgx3de.so, C ABI/headers/algorithms, gx2d.c, History/diagnostics and authored
Viewer packages remain protected. No MAIN2 P022 certification is implied.

Read README.md for guarded preflight/application/rollback and VNC checks. Final
package proof uses a full isolated P021 copy, all cumulative postimages, fresh
public API startup and exact rollback bytes/modes. User acceptance is OPEN;
installation status is NOT INSTALLED. Depositing this patch does not accept the
P020/P021 cumulative CAD design on the user's behalf.

Only after deposit: read the entire latest owner-provided architecture directive,
complete its evaluation/source research first, then implement a separate isolated
review experiment. That work is not part of P022 and must not be promoted/installed.
