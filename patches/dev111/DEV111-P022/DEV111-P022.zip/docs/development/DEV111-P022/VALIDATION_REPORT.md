# P022 focused real-GUI qualification

SPDX-License-Identifier: GPL-3.0-or-later

## Source and method

Runtime under test:8bc9fbaede1a316e82ab921d9775413c7164f2a5. Subsequent final
source changes are validation scripts, reports, evidence and checksums only;
final manifest/qualification verifies identical tested runtime bytes. Proper
separate Git worktree based on exact deposited P021. P021 archive/files and the
Native3D engine, Native2D scientific kernel, History, diagnostic collector and
Viewer Development/Builder packages are protected by SHA256 anchors.

All acceptance-labelled GUI actions use xdotool mouse/keyboard/menu inputs on
owned windows of the complete normal application. `send` is used for observation
and bounded execution traces only, never as a substitute for a user operation.
Screenshots are cropped to owned windows and inspected. Profiles, Documents,
Datasets, History and generated output are private synthetic fixtures. Local
XFCE/X11 :0, Debian13, kernel6.12.101+deb13-amd64, NVIDIA390.157 GT610 and
Mesa25.0.7 llvmpipe. No test-only graphics overrides were injected into the parent.
Real normal Configuration controls set Software, Auto or explicit Hardware.

## Real-GUI results

| Workflow | Result | Evidence / scope |
|---|---|---|
|Original explicit Hardware full application|FAIL reproduced|normal01 actual Configuration; two worker exits before first frame; parent survived. Captured request and driver stack retained.|
|Corrected C++ Native3D startup/orbit/wheel|PASS|Fresh normal02/03/04; actual ordinary Viewer tile; Software, Auto and explicit Hardware. One normal03 Hardware close hit external XIM hang, separately recorded below; later close passed.|
|Builder native3d Preview|PASS|builder-modes01 actual palette Add, Preview, orbit, Close/Reopen in all three modes; colored native scene and Navigation Cube.|
|Native3D example and Builder gallery|PASS|normal04 ordinary example/gallery entry points; actual orbit and colored native frame; normal close.|
|TEST CAD1/2 Hardware|PASS|testcad1-03/testcad2-01 actual Line, Finish, exact GUI Undo/Redo, Escape, Save and Navigation Cube camera change.|
|TEST CAD1/2 Software/Auto|PASS|testcad-software05/testcad-auto01 actual normal tiles, Top/Navigation Cube controls and camera receipts; close. Construction correctness is not claimed retested for every mode.|
|Scientific Workbench1/10/50|PASS|cad-comparable-candidate01 actual Document/OpenSketch, defining-control pointer movement, exact model change and exact GUI Undo restoration. Baseline matched workflow also passed.|
|Molecule Dataset Preview modes|PASS|Actual Dataset context Preview and pointer rotation in Software/Auto/Hardware; all accepted candidate input reaches native camera; source SHA preserved.|
|Saved Sketch stays visible closed|PASS|lifecycle02 editor Close, visible saved3D native drawing and closed orbit; reopen same Document and exact model/History.|
|Finish/new construction/Cancel|PASS|lifecycle02 Line/Finish then another construction/Escape; cad-edges01 Close Cancel preserves proposal; Close No discards only the pending proposal.|
|Close unfinished construction with Yes|PASS|close-yes02 actual Create/Polyline3points; Yes finishes/saves; reopen exact three-control polyline and count2 History.|
|Inclined plane / Create Again|PASS|tilted02 real Working Plane origin5,2,1 normal1,1,1 and U1,-1,0; Line/Finish/Save/Close/Reopen sameDoc15/History; Close/Create differentDoc16. Native frame roundtrip supplement.|
|Edge/horizon/behind both camera modes|PASS|projection04 six actual camera-field cases. Temporarily unmappable CAD input preserves staged proposal, exact model and History; unrestricted camera recovered via actual Fit/Escape.|
|Closed orthographic zoom / active Space navigation|PASS|cad-edges01 real pointer/key input, native camera and pixel changes; exact saved model invariant. No speculative camera-engine fix.|
|Full app Save/Close/Reopen|PASS|restore02 validates associated Doc16 after restarting complete application, not merely reopening an editor.|
|Rapid camera input then Close|PASS bounded workflow|pending-close04 closes cleanly and retains saved display. Handler observes workerBusy0; forced overlap with a still-running native RPC is NOT VERIFIED. No unsafe worker kill is inferred.|

Renderer receipt, child environment and loaded-vendor evidence distinguish
requested policy from actual device. Explicit Hardware uses GT610/NVIDIA390,
Software llvmpipe. Auto Preview may select Software according to its existing
quality policy; Auto component may use Hardware. Do not infer backend from the
Configuration label. Initial failed Auto read-only render retains its bounded
single Software retry; explicit Hardware is not silently converted to Software.

## Supplementary API checks (not GUI acceptance)

- native-contract04: finite batch/scalar coordinate equivalence, malformed-input
  nonmutation, ordered mixed native camera batch/scalar equivalence in both
  projections (1e-12 tolerance), rejected-batch camera invariance.
- All12 same-frame original/fast PNG outputs decode to identical RGBA bytes.
- snapshot-contract02: saved display for1/10/50, unit conversion mm→cm, unchanged
  exact source, stale owner/generation rejection and disposal.
- Release selftests exercise16 all-before-mutation application/rollback guards.
  Final full-copy application/rollback and public API startup are recorded by
  VERIFICATION.json at packaging; they are not implied by this draft report.

## Scientific integrity and preserved owners

Canonical ATP source SHA256 remains
49771f22888401cca960f46ba8fede47afa71ead3b9643efe5385d78e94c8d81.
Matched exact-model fixture SHA256:
e7e8e9a22bd511066ed61bae2e231d58a4105b140e406bca7b115596ecd6119d.
Committed point editing and Undo use authoritative Native2D; staged preview is
not a scientific replacement. Saved display is read-only, bounded visual
sampling, never canonical geometry/measurement/export. P017 accepted/pending/
durable History remains its existing owner. Harmless repaint does not acquire a
new History manager. Source unit/frame rules and stale Session guards remain.

## Failures, unsupported claims and scope

Failed harness attempts are retained in scratch rather than relabelled PASS:
wrong demo label case, an incorrect observation key, input before asynchronous
layout completion, and a navigation input without verified Canvas focus. Relevant
corrected checks passed with actual visible controls and native camera receipts.
One normal03 close hung in Xlib XDestroyIC waiting for desktop XIM/IBus after
renderer retirement. Stack retained; existing IBus restarted and only the own
hung test application terminated. Fresh normal closes then passed. No speculative
renderer/input-method replacement or X-server/driver modification was made.

Separate remote X11, client RTX3050, other platforms and a complete historic CAD
scientific matrix are NOT TESTED. Unchanged History/diagnostic/Builder ownership
is hash-preserved; this is not a repeat of the P019/P020 campaigns. Timing tails
and multi-second setup are known limitations, reported without suppression.
No independent MAIN2 P022 certification is claimed. MAIN1 reviewed actual receipts
and screenshots. User VNC acceptance remains OPEN; candidate is NOT INSTALLED.
