# P022 known limitations

SPDX-License-Identifier: GPL-3.0-or-later

- Internal verification is not user acceptance. Installation remains manual.
- Ready binaries target Linux x86-64 on the supported Debian environment. Other
  native platforms require matching builds and were not GUI-qualified here.
- Hardware was verified on this server's GT610/NVIDIA390.157 local X11 desktop.
  Other GPUs, RTX3050 client hardware and separate remote X11 were not tested.
  Hardware still requires a valid supported OpenGL implementation; select Auto
  or Software when the actual display/driver cannot provide one.
- Native OpenGL rendering/framebuffer capture and Tk PhotoImage decoding still
  cost time. Opening a Sketch also retains measurable multi-second setup costs.
  This is not a new rendering backend or a promise of zero interaction latency.
- Later normal samples included418/449ms PNG-output spans. A bounded syscall
  trace did not reproduce them; no unsupported disk/driver root cause is claimed.
  See all benchmark samples rather than only the best run.
- One desktop XIM/IBus close hang was recorded separately. Its stack, recovery
  and subsequent checks are documented; P022 does not replace the input method.
- Active editing overlays remain always on top of the scene. Closed display
  geometry uses normal Native3D depth. A closed snapshot is bounded visual
  sampling, not scientific measurement/export geometry; exact definitions remain
  in the Document. Active control/dimension UI is restored by reopening its editor.
- P017's known large-History explicit Save cost is not redesigned or claimed
  improved. Named Histories and Workspace modernization remain out of scope.
- The withdrawn Show Dimensions report was not investigated or treated as a defect.
