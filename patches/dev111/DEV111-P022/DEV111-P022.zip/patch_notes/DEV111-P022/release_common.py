# SPDX-License-Identifier: GPL-3.0-or-later
"""Finite P022 release-file guards; no product runtime or scientific ownership."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, shutil, stat, subprocess, tempfile, zipfile

PATCH = 'DEV111-P022'
BASE_COMMIT = 'b30bc478125dc8ea742094478d17b844eeb2d789'
P019_COMMIT = '248cd71edaaae1b76810528de69f6eed23fb482c'
BASE_ZIP_SHA = '6930a0f06b4fcea9b8b4f7d77cd6af234c1c588d87549ec08018c5dd479f074a'
BASE_ZIP_BYTES = 9022276
NOTES = 'patch_notes/' + PATCH
MODULES = ('viewer.3d_workbench', 'viewer.test_cad_1', 'viewer.test_cad_2')
BINARIES = ('core/native2d/bin/gx2dtcl.so', 'core/native3d/bin/libgx3de_viewer_tcl.so')

class GuardError(RuntimeError):
    pass

def require(condition, message):
    if not condition:
        raise GuardError(str(message))

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def read_json(path):
    with Path(path).open(encoding='utf-8') as stream:
        return json.load(stream)

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def relpath(value):
    require(isinstance(value, str) and value and '\\' not in value and ':' not in value,
            'Unsafe relative path: ' + repr(value))
    p = PurePosixPath(value)
    require(not p.is_absolute() and all(x not in ('', '.', '..') for x in value.split('/')),
            'Unsafe relative path: ' + repr(value))
    return p

def member_path(root, name):
    relative = relpath(name)
    root = Path(root).resolve()
    current = root
    for index, part in enumerate(relative.parts):
        current = current / part
        require(index == len(relative.parts)-1 or not current.exists() or current.is_dir(),
                'Non-directory path ancestor: ' + str(current))
        require(not current.is_symlink(), 'Refusing symlink: ' + str(current))
    require(current.resolve().is_relative_to(root), 'Path escaped root: ' + name)
    return current

def inventory(root):
    root = Path(root).resolve()
    result = {}
    for parent, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(x for x in dirs if x not in ('.git', '__pycache__'))
        for name in dirs:
            require(not (Path(parent) / name).is_symlink(), 'Symlink directory in source')
        for name in sorted(files):
            p = Path(parent) / name
            if name == '.git' or '__pycache__' in p.parts:
                continue
            require(not p.is_symlink() and p.is_file(), 'Nonregular source: ' + str(p))
            result[p.relative_to(root).as_posix()] = sha(p)
    return result

def git(root, *arguments):
    return subprocess.check_output(['git', '-C', str(root), *arguments], text=True,
                                   timeout=120).strip()

def fresh_scratch(path):
    path = Path(path).resolve()
    require(path.is_relative_to('/srv/gxtxt/agents/scratch') and not path.exists(),
            'Fresh agents scratch destination required: ' + str(path))
    return path

def zip_members(archive):
    """Validate the complete archive index before extracting any member."""
    entries = {}
    for entry in archive.infolist():
        name = entry.filename
        if entry.is_dir():
            relpath(name.rstrip('/'))
            continue
        relpath(name)
        require(name not in entries, 'Duplicate ZIP member: ' + name)
        mode = entry.external_attr >> 16
        require(not stat.S_ISLNK(mode), 'Symlink ZIP member: ' + name)
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG), 'Nonregular ZIP member: ' + name)
        require(entry.file_size <= 128 * 1024 * 1024, 'Oversized patch member: ' + name)
        entries[name] = entry
    for name in entries:
        require(all(str(parent) not in entries for parent in PurePosixPath(name).parents if str(parent) != '.'),
                'File/directory prefix collision: ' + name)
    require(sum(x.file_size for x in entries.values()) <= 512 * 1024 * 1024,
            'Patch payload exceeds bounded size')
    require(archive.testzip() is None, 'Corrupt ZIP member')
    return entries

def validate_rows(manifest):
    require(manifest.get('patch') == PATCH and manifest.get('baseline_commit') == BASE_COMMIT,
            'Wrong patch/baseline manifest')
    rows = manifest.get('changed_files')
    require(isinstance(rows, list) and rows, 'Nonempty changed-file manifest required')
    seen = set()
    for row in rows:
        name = relpath(row['path']).as_posix()
        require(name not in seen and not name.startswith('patch_notes/'), 'Duplicate/reserved product path')
        seen.add(name)
        require('TODO' not in name.upper() and '.git' not in PurePosixPath(name).parts,
                'Protected path in overlay: ' + name)
        for key in ('before_sha256', 'after_sha256'):
            value = row.get(key)
            require((value is None and key == 'before_sha256') or
                    (isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)),
                    'Invalid ' + key + ': ' + name)
        require(row.get('action') == ('add' if row['before_sha256'] is None else 'replace'), 'Invalid file action')
        for key in ('before_mode', 'after_mode'):
            mode = row.get(key)
            require((mode is None and key == 'before_mode' and row['before_sha256'] is None) or
                    (isinstance(mode, int) and 0 <= mode <= 0o777), 'Invalid mode: ' + name)
    protected = manifest.get('protected_files')
    require(isinstance(protected, dict) and protected, 'Protected scientific/native anchor pins required')
    for name, expected in protected.items():
        relpath(name)
        require(name not in seen and isinstance(expected, str) and len(expected) == 64 and all(c in '0123456789abcdef' for c in expected),
                'Invalid protected anchor')
    return rows

def verify_protected(root, manifest):
    for name, expected in manifest['protected_files'].items():
        p = member_path(root, name)
        require(p.is_file() and sha(p) == expected, 'Protected scientific/native anchor differs: ' + name)

def atomic_bytes(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.p022-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(data)
            stream.flush()
            os.fchmod(stream.fileno(), mode)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

def apply_overlay(root, archive_path, mutate=False):
    root = Path(root).resolve()
    require(root.is_dir(), 'Framework directory required')
    with zipfile.ZipFile(archive_path) as archive:
        entries = zip_members(archive)
        require(NOTES + '/FILES.json' in entries, 'Missing P022 manifest')
        manifest = json.loads(archive.read(NOTES + '/FILES.json'))
        rows = validate_rows(manifest)
        verify_protected(root, manifest)
        expected = {r['path'] for r in rows}
        require(all(n in expected or n.startswith(NOTES + '/') for n in entries),
                'Unexpected archive product member')
        require(not (root / NOTES).exists(), 'P022 notes already exist; refusing overwrite')
        sums = archive.read(NOTES + '/PAYLOAD_SHA256SUMS').decode('utf-8').splitlines()
        listed = {}
        for line in sums:
            value, name = line.split('  ', 1)
            relpath(name)
            require(name not in listed and name in entries, 'Invalid payload checksum entry')
            require(digest(archive.read(name)) == value, 'Payload checksum mismatch: ' + name)
            listed[name] = value
        require(set(listed) == set(entries) - {NOTES + '/PAYLOAD_SHA256SUMS'}, 'Incomplete payload checksums')
        for row in rows:
            name = row['path']; target = member_path(root, name)
            require(name in entries and digest(archive.read(name)) == row['after_sha256'], 'Invalid postimage: ' + name)
            if row['before_sha256'] is None:
                require(not target.exists(), 'Added path already exists: ' + name)
            else:
                require(target.is_file() and sha(target) == row['before_sha256'], 'Divergent P021 preimage: ' + name)
                prior = NOTES + '/rollback-preimages/' + name
                require(prior in entries and digest(archive.read(prior)) == row['before_sha256'], 'Invalid backup: ' + name)
        for name in entries:
            member_path(root, name)
        for row in rows:
            require(((entries[row['path']].external_attr >> 16) & 0o777) == row['after_mode'],
                    'Postimage mode differs from manifest: ' + row['path'])
        if mutate:
            # Retain verified backups/notes before replacing any product file.
            order = sorted(entries, key=lambda name: (not name.startswith(NOTES + '/'), name))
            for name in order:
                entry = entries[name]
                mode = (entry.external_attr >> 16) & 0o777 or 0o644
                atomic_bytes(member_path(root, name), archive.read(name), mode)
    return manifest

def rollback_overlay(root, mutate=False):
    root = Path(root).resolve()
    manifest = read_json(member_path(root, NOTES + '/FILES.json'))
    rows = validate_rows(manifest)
    verify_protected(root, manifest)
    for row in rows:
        p = member_path(root, row['path'])
        require(p.is_file() and sha(p) == row['after_sha256'] and stat.S_IMODE(p.stat().st_mode) == row['after_mode'], 'Divergent P022 postimage: ' + row['path'])
        if row['before_sha256'] is not None:
            prior = member_path(root, NOTES + '/rollback-preimages/' + row['path'])
            require(prior.is_file() and sha(prior) == row['before_sha256'], 'Invalid rollback preimage: ' + row['path'])
    if mutate:
        for row in rows:
            p = member_path(root, row['path'])
            if row['before_sha256'] is None:
                p.unlink()
            else:
                prior = member_path(root, NOTES + '/rollback-preimages/' + row['path'])
                atomic_bytes(p, prior.read_bytes(), row['before_mode'])
    return manifest

def check_qualification(value, commit, files, changed):
    require(value.get('schema') == 'gxtxt.dev111.p022.qualification.v1', 'Wrong qualification schema')
    require(value.get('source_commit') == commit, 'Qualification source commit differs')
    require(value.get('reviewed_by') == 'MAIN1' and value.get('package_authorized') is True,
            'Explicit MAIN1 package authorization required')
    require(value.get('installed') is False and value.get('user_vnc_acceptance') == 'OPEN', 'Invalid acceptance/install claim')
    gates = value.get('gates');require(isinstance(gates, list) and gates, 'Qualification gates required')
    identities = set()
    blocked = []
    for gate in gates:
        require(gate.get('id') and gate['id'] not in identities, 'Duplicate/missing gate identity')
        identities.add(gate['id'])
        require(gate.get('status') in ('PASS', 'FAIL', 'NOT_VERIFIED', 'KNOWN_LIMITATION'), 'Invalid gate status')
        require(isinstance(gate.get('required_for_release'), bool), 'Explicit gate requirement needed')
        require(gate.get('note'), 'Explicit gate observation needed')
        require(gate.get('evidence'), 'Every gate needs reviewed evidence')
        for evidence in gate['evidence']:
            p = Path(evidence['path']).resolve()
            require(p.is_file() and not Path(evidence['path']).is_symlink() and sha(p) == evidence['sha256'], 'Gate evidence changed')
        if gate['required_for_release'] and gate['status'] != 'PASS':
            blocked.append(gate['id'])
    candidate = value.get('incomplete_candidate_authorized') is True
    require(not blocked or candidate, 'Required gates unresolved: ' + ', '.join(blocked))
    require(value.get('ready_for_user_acceptance') is (not blocked and not candidate), 'Qualification readiness is inconsistent')
    pins = value.get('final_runtime_pins', {})
    required_pins = {p for p in changed if p.startswith(('core/', 'app/', 'plugins/')) or p == 'gxtxt_pipeline.tcl'}
    require(required_pins <= set(pins), 'Missing final runtime source pins')
    for name, expected in pins.items():
        require(files.get(name) == expected, 'Qualified source changed: ' + name)
    builds = value.get('native_builds', [])
    require({row.get('binary') for row in builds} == set(BINARIES), 'Matching changed native build records required')
    for row in builds:
        require(files.get(row['binary']) == row['binary_sha256'], 'Native binary identity differs')
        require(row.get('source_pins'), 'Native build source pins required')
        for name, expected in row['source_pins'].items():
            require(files.get(name) == expected, 'Native build source identity differs: ' + name)
        receipt = Path(row['receipt']).resolve()
        require(receipt.is_file() and sha(receipt) == row['receipt_sha256'], 'Native build receipt differs')
    required_native_sources = {p for p in changed if p.startswith(('core/native2d/', 'core/native3d/')) and Path(p).suffix in ('.cpp', '.c', '.h')}
    require(required_native_sources <= set().union(*(set(row['source_pins']) for row in builds)),
            'Changed native sources missing from reviewed build identities')
    return blocked
