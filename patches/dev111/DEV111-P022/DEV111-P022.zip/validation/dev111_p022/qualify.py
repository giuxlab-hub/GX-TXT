#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import argparse,json,subprocess,hashlib
from release_common import sha,git,require,write_json,BINARIES
p=argparse.ArgumentParser();p.add_argument('framework',type=Path);p.add_argument('workspace',type=Path);p.add_argument('output',type=Path);a=p.parse_args();f=a.framework.resolve();w=a.workspace.resolve();require(not a.output.exists(),'Fresh qualification receipt required');require(not git(f,'status','--porcelain'),'Clean final source required')
base='b30bc478125dc8ea742094478d17b844eeb2d789';runtime='8bc9fbaede1a316e82ab921d9775413c7164f2a5';changed=git(f,'diff','--name-only',base).splitlines();pins={}
for name in changed:
 if name.startswith(('core/','plugins/')):
  expected=subprocess.check_output(['git','-C',str(f),'show',runtime+':'+name]);require(hashlib.sha256(expected).hexdigest()==sha(f/name),'Runtime no longer matches GUI qualification: '+name);pins[name]=sha(f/name)
gates=[]
def gate(id,status,note,paths,required=True):
 evidence=[]
 for path in paths:
  p=(f/'docs/development/DEV111-P022'/path).resolve();require(p.is_file(),'Missing reviewed evidence '+str(p));evidence.append(dict(path=str(p),sha256=sha(p)))
 gates.append(dict(id=id,status=status,required_for_release=required,note=note,evidence=evidence))
gate('local-real-configuration-modes','PASS','Normal full GUI and actual Configuration; explicit Hardware startup corrected, actual backend receipts; XIM-close failure kept distinct.',['VALIDATION_REPORT.md','evidence/normal03/hardware-cpp/AFTER.tcldict','evidence/normal03/software-cpp/AFTER.tcldict','evidence/normal03/auto-cpp/AFTER.tcldict','evidence/builder-modes01/RESULT.json'])
gate('authored-cad-viewers','PASS','Normal authored TEST CAD1/2; Hardware construction/Finish/UndoRedo/Cancel/Save plus Software/Auto startup/navigation.',['evidence/testcad1-03/RESULT.json','evidence/testcad2-01/RESULT.json','evidence/testcad-software05/RESULT.json','evidence/testcad-auto01/RESULT.json'])
gate('cad-1-10-50-edit-undo','PASS','Actual control mouse edits and exact GUI Undo, shared projection active.',['evidence/cad-comparable-candidate01/objects1/RESULT.json','evidence/cad-comparable-candidate01/objects10/RESULT.json','evidence/cad-comparable-candidate01/objects50/RESULT.json'])
gate('lifecycle-saved-visibility','PASS','Actual Finish/Cancel/Close decisions, tilted plane, full app Save/Close/Reopen, same scientific Document and History.',['LIFECYCLE_REPORT.md','evidence/lifecycle02/RESULT.json','evidence/tilted02/RESULT.json','evidence/close-yes02/RESULT.json','evidence/restore02/RESULT.json'])
gate('unrestricted-camera-invalid-view-safety','PASS','Six actual perspective/orthographic edge/horizon/behind cases preserve model, History and staged proposal; actual Fit recovery.',['evidence/projection04/RESULT.json','evidence/cad-edges01/SCIENTIFIC_AND_ZOOM.json'])
gate('actual-performance-and-input-preservation','PASS','Matched baseline variant and candidate, actual molecule input/native counts, CAD1/10/50; negative/outlier cases retained.',['PERFORMANCE_REPORT.md','evidence/METRICS.json','evidence/COMPARABLE_BASELINE.json','evidence/COMPARABLE_FIXTURES.json'])
gate('native-api-pixel-equivalence','PASS','Supplementary API checks not GUI; scalar/batch coords and native camera, invalid mutation rollback, decoded lossless pixels.',['evidence/native-contract04/CONTRACT.tcldict','evidence/native-contract04/PIXEL_EQUIVALENCE.json'])
gate('protected-authorities','PASS','Native3D engine, Native2D kernel, History, diagnostics, Builder/Development and prior release identities preserved; package rechecks actual anchors.',['BUILD_IDENTITY.json','evidence/PROTECTED_BASELINE.json','ARCHITECTURE_HANDOFF.md'])
gate('remaining-latency','KNOWN_LIMITATION','Multi-second setup remains; PNG-output spikes341..449ms retained, not attributed to disk or claimed fixed.',['PERFORMANCE_REPORT.md','KNOWN_LIMITATIONS.md'],False)
gate('forced-close-worker-overlap','NOT_VERIFIED','Immediate input/Close passes; observed close handler is busy0, not proof of forced in-flight RPC overlap.',['evidence/pending-close04/RESULT.json','LIFECYCLE_REPORT.md'],False)
gate('external-platforms','NOT_VERIFIED','Other GPUs/platforms and separate remote X11 not qualified; local supported desktop is primary.',['KNOWN_LIMITATIONS.md'],False)
builds=[]
for binary,receipt,nested in [(BINARIES[0],w/'build03/BUILD_IDENTITY.json',True),(BINARIES[1],w/'build04/BUILD_IDENTITY.json',False)]:
 raw=json.loads(receipt.read_text());build=raw['native2d'] if nested else raw;require(sha(f/binary)==build['binary_sha256'],'Binary differs from reviewed build');source={}
 inputs=dict(build['inputs'])
 if nested:inputs.update(json.loads((w/'build03/COMPILER_DEPENDENCY_PINS.json').read_text()))
 for name,value in inputs.items():
  path=Path(name);path=path if path.is_absolute() else f/path
  require(path.is_file() and sha(path)==value,'Build dependency changed: '+str(path))
  if path.resolve().is_relative_to(f):source[path.resolve().relative_to(f).as_posix()]=value
 builds.append(dict(binary=binary,binary_sha256=sha(f/binary),source_pins=source,receipt=str(receipt),receipt_sha256=sha(receipt)))
result=dict(schema='gxtxt.dev111.p022.qualification.v1',source_commit=git(f,'rev-parse','HEAD'),tested_runtime_commit=runtime,reviewed_by='MAIN1',package_authorized=True,installed=False,user_vnc_acceptance='OPEN',ready_for_user_acceptance=True,gates=gates,final_runtime_pins=pins,native_builds=builds)
write_json(a.output,result);print('MAIN1 qualification recorded; optional known limits/unverified cases retained')
