# DEV111-P022 real-application stabilization validation

Scope: exact deposited P021 b30bc478125dc8ea742094478d17b844eeb2d789;
ZIP SHA6930a0f06b4fcea9b8b4f7d77cd6af234c1c588d87549ec08018c5dd479f074a.
All outputs below /srv/gxtxt/agents/scratch/DEV111-P022-MAIN. No installed GX-TXT,
original Session, historical release, project TODO or GPU driver modification.

`baseline.py BASE_FRAMEWORK NEW_JSON`: read-only complete baseline identities,
tracked source hashes/modes and deposited archive/manifest verification; records
proper distinct Git administrative ownership and protected native/History APIs.
Writes only NEW_JSON, refuses overwrite or mismatched authoritative source.

Planned real-application launcher: normal `wish gxtxt_pipeline.tcl` in a coherent
private P022 source; exact existing local XFCE session environment, no graphics
force flags. Only HOME/XDG and GX-TXT storage/profile roots are isolated. Private
preferences may copy user graphics values read-only; actual changes use native
Configuration GUI. All menu/tool input uses actual X11 pointer/keyboard events.
Read-only Tk `send` observations and timing traces may supplement GUI screenshots,
never substitute for actual user actions. No original application input.

Native build, timing, fixtures and packaging helpers will be registered here
before execution. Historical version-pinned scripts are not run unchanged.

`fixtures.tcl FRAMEWORK NEW_OUTPUT`: prepare one isolated Project/Session using
public CORE APIs, publish the repository's ATP SDF as a canonical molecular
Dataset, create exact Native2D-based Sketch Documents for1/10/50-object fixtures
and a normal Workbench Workspace associated with them. No GUI operation is
claimed by fixture creation. Original payload SHA and exact retained definitions
are recorded; all profile, Dataset, Document, History and resource writes remain
inside NEW_OUTPUT. Does not execute an older campaign or user data.
Private profile directories use mode0700, as required by the existing resource
authority. This also avoids inheriting the agent scratch tree's group-write umask.

`launch.py FRAMEWORK NEW_OUTPUT [--fixture OUTPUT]`: launch the complete normal
`wish gxtxt_pipeline.tcl` entrypoint in the real local XFCE session environment.
No test-only GL/Mesa/Gallium/vendor/loader overrides; only HOME/XDG/GX-TXT storage
roots are private. Preserve exact source identity, graphics-env whitelist and PID;
stdout/stderr bounded by the validation owner. Uses a prepared private fixture
profile when supplied. No user application input or original configuration write.

`gui.py LAUNCH_JSON OUTPUT command ...`: bounded actual X11 GUI driver for the
owned normal application PID, discovered via Tk send PID identity. Observer send
is used only for widget/config/model inspection and registered timing traces;
all Session opening, Configuration choices, Save, Viewer opening and scientific
GUI operations use xdotool mouse/keyboard input. Observer root is withdrawn.
Screenshots target only owned windows; inputs/checks are recorded incrementally.
Commands: inspect, config MODE, open-session PATH, widgets [TOP], tree PATH,
read TCL_OBSERVATION, click PATH, tab NOTEBOOK CHILD, key KEYS, shot TOP LABEL.
`close TOP` activates the owned window frame and sends the normal Alt+F4 close;
`activate TOP` resolves the owned Tk client's X11 WM wrapper and sends a normal
window-manager activation request. It does not invoke GX-TXT callbacks.
`choose` uses the posted native combobox list and actual pointer input.
`row TREE ITEM` clicks the actual visible Treeview row (no programmatic selection).
`drag CANVAS DX DY STEPS` sends an actual left-drag with25ms between pointer
positions, recording each input's monotonic timestamp. No synthetic Tk events.
`point CANVAS X Y [BUTTON]` clicks a verified in-bounds device position.
`reveal WIDGET SCROLL_CANVAS` uses native wheel input until the widget is actually
uncovered. It never programmatically scrolls or invokes a hidden control.
`read` is an explicit trusted validation observation, never a GUI acceptance
shortcut; callers must not use it to trigger actions or change scientific state.
No foreign application input or original Session/profile/config writes.

`process_watch.py LAUNCH_JSON NEW_OUTPUT --seconds N`: bounded read-only /proc
sampling of the owned application's descendants, recording worker command,
graphics environment, loaded GL vendors, memory/CPU and resource limits. No
signals, process launch settings, source or user data changes. Polling overhead
is kept outside benchmark samples and recorded; short-lived children may escape.

`replay.py FRAMEWORK REQUEST OUTPUT --desktop-pid PID [--address-mib N] [--gdb]`:
supplementary diagnostic replay of the exact captured failed GUI worker request,
desktop environment and actual launch's LIBGL_ALWAYS_INDIRECT=0. Changes only
private request PNG/output; does not count as real-GUI validation. Optional gdb
records a crash stack; optional address-space limit tests the actual worker limit.
The replay child alone may write a bounded256MiB core file in its output directory;
no global OS core setting or running application resource limit is modified.
`--bind-now` tests eager dynamic-symbol resolution for the observed legacy-NVIDIA
pthread interposition crash; supplemental replay only, explicitly recorded.
`--thread-bootstrap` builds a minimal private Tcl extension and starts/joins one
empty native thread before loading the renderer dependency graph. This tests the
locally documented NVIDIA library/thread initialization-order defect. Source and
binary remain in that diagnostic output; no framework library is replaced.
`--pthread-preload` tests the installed NVIDIA manual's pthread preload workaround
in the isolated replay process only; it is not a GUI acceptance test.

`timing.tcl`: transient in-memory execution traces in the owned GUI interpreter.
`::P022Timing::start` records only selected existing controller/presentation/API
durations and bounded command summaries; `stop OUTPUT` removes every trace and
writes TSV. No scientific callbacks invoked, rendering/input state changed or
ongoing polling. Use actual pointer sequences while traces are active. Trace
overhead and nested spans must be distinguished from end-to-end latency.

`build_native.py FRAMEWORK NEW_OUTPUT [--stage]`: rebuild only the changed Tcl
transport C++ target against the unchanged authoritative Native3D shared library,
using the existing CMake target's C++17/Tcl/include/link/RPATH contract. Records
compiler, exact command, dependency/source/library hashes, ELF/ldd and output SHA.
No geometry engine recompilation. `--stage` copies the verified result only into
the isolated P022 candidate tree; never the installed or older framework.
`--native2d` additionally builds the existing gx2dtcl CMake target with two compile
jobs and the unchanged C kernel sources, plus the additive presentation batch.
Stages use atomic replacement so a still-running baseline process retains its
original loaded inode safely. Fresh GUI launches use the rebuilt matching binary.
`--cairo-include DIRECTORY` uses an existing local development-header directory
when system Cairo headers are absent; hashes every used header. No installation,
download or modification of the protected dependency directory.

`cad_workflow.py LAUNCH OUTPUT FRAMEWORK --window W`: actual authored Scientific
3D Workbench GUI1/10/50-object fixture workflow. Normal Document selectors,
Open/Close Sketch controls and pointer-driven defining-control edit, then GUI
Undo. Captures exact scientific models, native History receipts, displayed
screenshots, timings and source/loaded-controller identity. Uses only private
synthetic fixtures; creates History/Save changes there. Observations/diagnostic
traces supplement actual input. Stops on failures; does not relabel API checks
as GUI interactions or mutate original Sessions.
Optional `--counts 50` limits a targeted rerun; `--light-timing` omits per-native-
primitive traces while retaining bounded Host/presenter whole-redraw timings.

`snapshot_contract.tcl FRAMEWORK NEW_OUTPUT`: fresh isolated fixture preparation
followed by saved-Sketch display API checks for1/10/50 objects, public unit
conversion, exact source preservation, bounded retained resource registration and
stale-generation rejection. API test only; never claimed as real-GUI validation.
Writes only the fresh synthetic Session/profile and technical receipts.

`native_contract.tcl FRAMEWORK CAPTURED_REQUEST NEW_OUTPUT`: complementary native
API checks, not real-GUI acceptance. Checks batch/scalar coordinate equivalence
and malformed-input rollback; ordered native camera-batch equivalence in both
projection modes; rejected camera batches; standard/fast PNG of the same native
RGBA frame. Run with an explicitly recorded Software GL environment for this
isolated API test only. Compare decoded PNG RGBA bytes independently afterward.
No user Session, installed framework, scientific export contract or OS changes.

`mode_workflow.py LAUNCH NEW_OUTPUT MODE [--keep]`: actual normal Configuration
Save followed by authored C++ Native3D opening, real orbit/wheel inputs and owned
window screenshots/worker receipts. Closes the tested Viewer through normal GUI,
answering only its own ordinary Workspace Save question. No product callbacks
invoked as GUI input, no graphics overrides or original profile mutations.

`molecule_workflow.py LAUNCH NEW_OUTPUT FRAMEWORK MODE`: normal Configuration
and Dataset context Preview, actual12-motion orbit, bounded per-stage traces,
worker receipts and owned screenshots. Waits for completed pending camera work;
compares accepted input/worker operation counts and retains original source SHA.
No API call substitutes for pointer motion. Private synthetic ATP Dataset only.

`lifecycle_workflow.py LAUNCH NEW_OUTPUT --window W`: actual Workbench Sketch
Close/retained3D display/orbit/Reopen of same Document and History, Line/Finish,
new construction/Escape, Save and pending-construction Close decisions. Native
model/History assertions and screenshots supplement real controls/input. Uses
only the prepared private fixture; never changes an original Session.

P022-specific release guards adapted from reviewed P021 infrastructure; never run
historical deployment helpers unchanged. `selftest_release.py NEW_SCRATCH` checks
synthetic all-before-mutation apply/rollback, traversal/divergence/mode guards.
`apply.py FRAMEWORK P022_ZIP [--apply]` is read-only preflight by default; explicit
apply validates all exact P021 preimages, protected anchors and payloads first.
`rollback.py FRAMEWORK [--check]` verifies P022 product postimages/backups before
restoring P021; preserves Notes, scientific Sessions and user preferences.
`fresh_startup.py FRAMEWORK NEW_OUTPUT` runs the public API catalog in a private
profile; supplementary startup contract only, never GUI acceptance.
These helpers are only run on fresh scratch proof copies during development.

`projection_workflow.py LAUNCH NEW_OUTPUT --window W`: staged actual Line input,
normal camera controls for edge-on/horizon/behind-camera cases in perspective
and orthographic modes; real hover/click while unmappable, exact proposal/model/
History preservation, unrestricted camera recovery through normal Fit and Escape.
No camera or geometry setter is invoked as a GUI substitute. Private fixture only.
`gui.py reveal` additionally uses an existing Native3D sidebar's actual scrollbar
thumb when its covered Canvas cannot receive wheel events. Geometry/scrollregion
are observed only; scrolling is genuine mouse press/move/release, never yview
assignment. Refuses a scrollbar whose command does not match the owned viewport.

`test_cad_workflow.py LAUNCH NEW_OUTPUT --window W`: already normally opened
TEST CAD1/2 authored Viewer; actual shared Line, Finish, Undo/Redo, Escape, Save,
Navigation Cube click and native camera receipts. Queries only public component
state/owned widget mapping. Exact model comparisons distinguish GUI from API use.

`builder_modes.py LAUNCH NEW_OUTPUT`: normally opened public Interface Builder
with one Native3D component added through its palette. Actual Configuration
Software/Auto/Hardware saves and Preview Close/Reopen controls; captures public
native renderer receipts, real orbit input and colored-window screenshots. Uses
only its isolated design/Session; no generated private Viewer substitute.

`pending_close_workflow.py LAUNCH NEW_OUTPUT --window W`: actual Workbench
Open Sketch, Space-orbit then immediate Close button in one real X11 input
sequence. A temporary enter trace records true worker ownership at Close;
scientific model/History and resulting saved display are observed. Refuses to
claim overlap unless receipt says workerBusy1. No API action calls or user data.

`package.py P021_FRAMEWORK P022_SOURCE NEW_STAGE BASELINE_JSON QUALIFICATION_JSON`:
requires exact clean P021/P022 local Git identities, reviewed explicit MAIN1 gates,
matching compiled-source pins and protected native/History/diagnostic anchors.
Creates only a new scratch incremental ZIP, complete isolated P021 overlay proof,
fresh public API startup and all-file guarded rollback proof. Does not install,
fetch, activate, overwrite historical packages or collect original Session data.
`deposit.py STAGE NEW_RELEASE GXTXT_MIRROR_ROOT`: MAIN1-only new destination
release plus paired framework archives/patches and expanded/patches copies. All
payloads/hashes/proofs checked first. No product activation or old-release writes.

`tilted_workflow.py LAUNCH NEW_OUTPUT --window W`: existing private Workbench
Document, real Working Plane form (origin5,2,1; normal1,1,1; U1,-1,0), Create
Sketch, actualLine/Finish/Save/Close/Reopen sameDoc/History, native public frame
roundtrip assertions, then Close/Create another independentSketch. Retains all
savedDocs, never deletes science or modifies an original Session. Screenshots and
exact model/Document receipts accompany GUI input.
Molecule timing additionally records two read-only GUI/renderer /proc stat samples
around actual input (CPU ticks, RSS, threads), with tick-resolution limits; no
profiling poller. Timing traces retain bounded actual accepted camera deltas so
X11 motion compression is distinguished from Viewer input loss.

`cad_edges_workflow.py LAUNCH NEW_OUTPUT --window W`: actual staged-construction
Close→Cancel/No/Yes choices, exact model/History preservation, Space-orbit/pan,
Save and closed orthographic wheel behavior. Query-only frame receipts establish
camera effect. No hidden action callbacks; only private synthetic Documents.

`close_yes_workflow.py LAUNCH NEW_OUTPUT --window W`: actual shared menu Create
Polyline, three pointer places, Close→Yes (Finish/save) and Reopen same Document.
Checks exact retained family/control count and History increment through public
read-only receipts. Private fixture only; no automatic callback invocation.

`report_metrics.py WORKSPACE NEW_JSON`: read-only analysis of the explicitly named
controlled P022 baseline/candidate receipts, trace spans and CPU samples; writes
one new bounded JSON. Reports all named samples including outliers and accepted
input/native-operation counts; no scientific work, GUI input or source mutation.
Optional `molecule_workflow.py --trace-io` attaches one strace only to the verified
owned renderer for the single input burst. Records bounded file/IPC syscall
wall times (strings length0), detaches tracer afterward without killing worker.
Diagnostic timing overhead is explicitly separate from normal benchmarks; no
original process, Driver, OS configuration or scientific data changes.

Focused comparable performance rerun: proper detached local Git measurement tree
`/srv/gxtxt/agents/scratch/DEV111-P022-MAIN/measure-p021` at4885fb8a (P021 GUI/
queue/selection/sampling plus necessary renderer-child pthread startup fix).
Its only additional native-library overlay is the pinned build04 transport for
passive bounded span receipts; old GUI never opts into fast_png/navigate_batch.
Native3D engine and Native2D library remain P021 originals. Fresh fixture06 and
fixture07 reproduce identical1/10/50 science; the exact same current lightweight
cad_workflow.py/timing.tcl drive both normal full applications. Register source,
binary, fixture and command hashes in COMPARABLE_BASELINE.json. Isolated trees/
profiles/outputs only; no P021 authoritative modification or historical script
execution. This replaces trace-overhead-confounded speedup claims, not existing
functional GUI evidence.
Native contract additionally measures3 original/fast lossless PNG writes of the
same already-rendered frame in each projection, with independent decoded-pixel
comparison. Small API encoder comparison, not a substitute for real GUI timing.

`instrument_baseline.py MEASURE_FRAMEWORK SOURCE_FRAMEWORK NEW_JSON`: strictly
scoped to the proper detached4885fb8a measurement tree, requiring exact old Tcl
preimage and the reviewed pinned build04 transport. Adds only last-request/time/
receipt variables for passive profiling; preserves the old overwrite queue and
old PNG protocol. No authoritative P021 source or archive changes. Records full
instrumentation diff and source identities; normal application restart required.

`remaining_modes.py LAUNCH NEW_OUTPUT MODE`: normal Configuration Save, ordinary
Test CAD 1/2 Viewer tiles, actual Top and Navigation Cube input, native worker and
camera receipts, screenshots and ordinary Close/Save. Bounded startup/navigation
coverage complements the full Hardware construction workflows; it does not claim
to repeat every scientific operation in each mode. Private fixtures only.

`restore_workflow.py LAUNCH NEW_OUTPUT EXPECTED_MODEL --window W`: actual
Workbench Document selector/Open and associated Sketch Open after a full app
restart. Checks exact private idoc_0016 saved model, tilted plane and History;
captures visible reopened geometry then closes through the actual controls. No
scientific setters or original Session writes. Expected fixture is private03.

`collect_evidence.py WORKSPACE FRAMEWORK`: MAIN1-only review collection of an
explicit allowlist of P022 synthetic receipts/traces/screenshots, source/compiled
pins and benchmark JSON into docs/development/DEV111-P022/evidence. Refuses
symlinks/large files, never scans or copies scientific Sessions, cores, private
user content or arbitrary scratch trees. Optional `--supplement` adds newly
reviewed allowlisted evidence only when existing copied bytes still agree.
Writes a SHA256 evidence index. Retained
failed harness runs remain in scratch; collection does not turn them into PASS.

`finalize_metadata.py FRAMEWORK`: review-only P022 staging-tree metadata update.
Requires the P022 branch, refreshes only P022 changed-file checksum entries and
new P022 paths, verifies both Workbench checksum lists, writes build/source
identity and changed-file inventory before the final commit. Does not regenerate
unrelated historical hashes or mutate installed/authoritative old sources.
`qualify.py FRAMEWORK WORKSPACE NEW_JSON`: MAIN1 final explicit package gates,
matching reviewed native build/source pins and tested-runtime equality against
8bc9fbaede1a316e82ab921d9775413c7164f2a5. Requires a clean final commit; preserves
known limits and unverified forced-worker-close overlap as such. No GUI claim
from this read-only identity aggregation. Writes only a fresh scratch receipt.
