#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('framework',type=Path);p.add_argument('output',type=Path);p.add_argument('--stage',action='store_true');p.add_argument('--native2d',action='store_true');p.add_argument('--cairo-include',type=Path);a=p.parse_args()
root=a.framework.resolve();out=a.output.resolve();out.mkdir(exist_ok=False)
assert root==Path('/srv/gxtxt/agents/scratch/DEV111-P022-MAIN/framework')
native=root/'core/native3d';binary=out/'libgx3de_viewer_tcl.so';deps=out/'dependencies.d'
cmd=['g++','-std=c++17','-O2','-DNDEBUG','-shared','-fPIC','-I/usr/include/tcl8.6',f'-I{native}',f'-I{native}/include','-MMD','-MF',str(deps),str(native/'gx3de_viewer_tcl.cpp'),f'-L{native}/lib','-lgx3de','-ltcl8.6','-lpng16','-Wl,-rpath,$ORIGIN/../lib','-o',str(binary)]
start=time.monotonic()
with (out/'BUILD.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
inputs={str(Path(x).resolve()):sha(x) for x in deps.read_text().replace('\\\n',' ').split(':',1)[1].split()}
inputs[str(native/'CMakeLists.txt')]=sha(native/'CMakeLists.txt');inputs[str(native/'lib/libgx3de.so')]=sha(native/'lib/libgx3de.so')
inputs['/usr/include/png.h']=sha('/usr/include/png.h');inputs['/usr/lib/x86_64-linux-gnu/libpng16.so.16']=sha('/usr/lib/x86_64-linux-gnu/libpng16.so.16')
result=dict(command=cmd,seconds=time.monotonic()-start,compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],inputs=inputs,binary_sha256=sha(binary))
result['elf']=subprocess.check_output(['readelf','-h','-d',str(binary)],text=True)
if a.stage:
 destination=native/'bin'/binary.name;staged=destination.with_suffix('.p022-stage')
 assert not staged.exists();shutil.copy2(binary,staged);os.replace(staged,destination)
result['staged']=a.stage
if a.native2d:
 source=root/'core/native2d';build=out/'native2d'
 commands=[['cmake','-S',str(source),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_FLAGS_RELEASE=-O2 -DNDEBUG','-DCMAKE_CXX_FLAGS_RELEASE=-O2 -DNDEBUG','-DBUILD_TESTING=OFF'],['cmake','--build',str(build),'--target','gx2dtcl','--parallel','2']]
 if a.cairo_include:
  assert (a.cairo_include/'cairo.h').is_file();commands[0].append(f'-DGXTXT_CAIRO_INCLUDE={a.cairo_include.resolve()}')
 with (out/'NATIVE2D_BUILD.log').open('w') as log:
  for command in commands:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 product=build/'gx2dtcl.so'
 inputs2={str(f.relative_to(root)):sha(f) for f in source.iterdir() if f.is_file() and f.suffix in ('.h','.inc','.c','.cpp','.txt')}
 if a.cairo_include:
  inputs2.update({str(f.resolve()):sha(f) for f in a.cairo_include.glob('*.h')})
 result['native2d']=dict(commands=commands,inputs=inputs2,binary_sha256=sha(product),compile_commands=str(build/'CMakeFiles/gx2dtcl.dir/flags.make'))
 if a.stage:
  destination=source/'bin/gx2dtcl.so';staged=destination.with_suffix('.p022-stage')
  assert not staged.exists();shutil.copy2(product,staged);os.replace(staged,destination)
(out/'BUILD_IDENTITY.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('elf','inputs')},indent=2))
