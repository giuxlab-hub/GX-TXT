#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""MAIN1-only new P022 release and matching archive/expanded mirrors."""
from pathlib import Path
import argparse,json,shutil,sys,zipfile
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from release_common import *
p=argparse.ArgumentParser(description=__doc__);p.add_argument('stage',type=Path);p.add_argument('release',type=Path);p.add_argument('mirror',type=Path);a=p.parse_args()
stage=a.stage.resolve();release=a.release.resolve();mirror=a.mirror.resolve();proof=read_json(stage/'VERIFICATION.json');archive=stage/(PATCH+'.zip');payload=stage/'payload';notes=payload/NOTES
require(proof['status']=='PASS' and proof['archive_sha256']==sha(archive) and proof['archive_bytes']==archive.stat().st_size,'Verified archive required')
require(release.is_relative_to('/srv/gxtxt/releases/dev111/patches') and release.name=='0022-real-gui-native3d-stabilization' and not release.exists(),'New numbered P022 release required')
require(mirror==Path('/home/giu/electronics-server/scripts/GXTXT').resolve(),'Exact existing GXTXT mirror required')
for section in ['framework','external_plugins','session_generators']:
 require(all((mirror/section/k).is_dir() for k in ['archives','expanded']),'Existing three-section mirror required')
arc=mirror/'framework/archives/patches'/archive.name;expanded=mirror/'framework/expanded/patches'/PATCH
require(not arc.exists() and not arc.with_suffix(arc.suffix+'.sha256').exists() and not expanded.exists(),'Refusing mirror overwrite')
with zipfile.ZipFile(archive) as z:
 entries=zip_members(z)
 for name in entries:require((payload/name).is_file() and sha(payload/name)==digest(z.read(name)),'Stage payload changed: '+name)
release.mkdir()
for f in [archive,stage/(PATCH+'.zip.sha256'),stage/'VERIFICATION.json']:shutil.copy2(f,release/f.name)
for f in notes.iterdir():
 if f.is_file():shutil.copy2(f,release/f.name)
shutil.copy2(archive,arc);shutil.copy2(stage/(PATCH+'.zip.sha256'),arc.with_suffix(arc.suffix+'.sha256'));shutil.copytree(payload,expanded)
with zipfile.ZipFile(archive) as z:
 for name in zip_members(z):require(sha(expanded/name)==digest(z.read(name)),'Expanded mirror differs: '+name)
require(sha(release/archive.name)==sha(arc)==proof['archive_sha256'],'Release/archive mirror differs')
result=dict(patch=PATCH,source_commit=proof['source_commit'],archive=str(release/archive.name),sha256=proof['archive_sha256'],bytes=proof['archive_bytes'],archive_mirror=str(arc),expanded_mirror=str(expanded),installed=False,user_vnc_acceptance='OPEN')
write_json(release/'DEPOSIT.json',result);print(json.dumps(result,indent=2))
