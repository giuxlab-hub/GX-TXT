#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import argparse,subprocess,hashlib,json
p=argparse.ArgumentParser();p.add_argument('measure',type=Path);p.add_argument('source',type=Path);p.add_argument('output',type=Path);a=p.parse_args();b=a.measure.resolve();s=a.source.resolve()
assert b==Path('/srv/gxtxt/agents/scratch/DEV111-P022-MAIN/measure-p021') and not a.output.exists()
commit='4885fb8a0a723b4a91ca489fd6b0e8edf5007b5f';assert subprocess.check_output(['git','-C',str(b),'rev-parse','HEAD'],text=True).strip()==commit
name='core/tcl/mesh_dataset_viewer_v1.tcl';f=b/name;old=subprocess.check_output(['git','-C',str(b),'show',commit+':'+name]);assert f.read_bytes()==old
text=old.decode();needle='    puts $state($w,worker) $request;flush $state($w,worker)';assert text.count(needle)==1
text=text.replace(needle,'    set state($w,lastRequest) [lindex $request 0];set state($w,requestStarted) [clock milliseconds]\n'+needle)
needle='    set path [file join $state($w,temp) render.png]';assert text.count(needle)==1
text=text.replace(needle,'    set state($w,lastReceipt) $result;set state($w,lastResponseMs) [expr {[clock milliseconds]-$state($w,requestStarted)}]\n'+needle)
f.write_text(text)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(b/'core/native3d/bin/libgx3de_viewer_tcl.so')==sha(s/'core/native3d/bin/libgx3de_viewer_tcl.so')
a.output.write_text(json.dumps(dict(source_commit=commit,original_mesh_sha256=hashlib.sha256(old).hexdigest(),instrumented_mesh_sha256=sha(f),native_bridge_sha256=sha(b/'core/native3d/bin/libgx3de_viewer_tcl.so'),diff=subprocess.check_output(['git','-C',str(b),'diff','--',name],text=True),scope='passive only; original pending overwrite and standard PNG remain'),indent=2)+'\n')
