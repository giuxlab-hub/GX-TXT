#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json,stat,subprocess,sys,zipfile
base=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();assert not out.exists()
commit='b30bc478125dc8ea742094478d17b844eeb2d789'
archive=Path('/srv/gxtxt/releases/dev111/patches/0021-native3d-cad-integration/DEV111-P021.zip')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
assert git(base,'rev-parse','HEAD')==commit and not git(base,'status','--porcelain')
assert archive.stat().st_size==9022276 and sha(archive)=='6930a0f06b4fcea9b8b4f7d77cd6af234c1c588d87549ec08018c5dd479f074a'
files={}
for raw in subprocess.check_output(['git','-C',str(base),'ls-files','-z']).split(b'\0'):
 if not raw:continue
 n=raw.decode();p=base/n;assert p.is_file() and not p.is_symlink(),n
 files[n]=dict(sha256=sha(p),bytes=p.stat().st_size,mode=stat.S_IMODE(p.stat().st_mode))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 manifest=json.loads(z.read('patch_notes/DEV111-P021/FILES.json'))
 assert manifest['source_commit']==commit
 for row in manifest['changed_files']:
  assert files[row['path']]['sha256']==row['after_sha256'],row['path']
  assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['after_sha256']
protected={}
for name,row in files.items():
 if name.startswith(('core/native3d/src/','core/native3d/include/','core/native3d/lib/','core/history/','core/diagnostics/','core/development/sdk/')) or (name.startswith('core/') and 'history' in name.lower()) or name=='core/tcl/gui_update_scheduler_v1.tcl' or name.startswith('core/native2d/') and Path(name).suffix in ['.c','.h'] or 'REMAINING_WORK_TODO' in name:
  protected[name]=row
value=dict(baseline_commit=commit,archive=str(archive),archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,baseline_git_admin=git(base,'rev-parse','--absolute-git-dir'),files=files,protected=protected,verified_archive_postimages=len(manifest['changed_files']),installed=False)
out.write_text(json.dumps(value,indent=2)+'\n');print(json.dumps(dict(status='PASS',files=len(files),protected=len(protected),archive_postimages=len(manifest['changed_files']))))
