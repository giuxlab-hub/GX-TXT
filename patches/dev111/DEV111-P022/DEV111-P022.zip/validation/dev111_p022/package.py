#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""P022-only incremental packaging and isolated application/rollback proof."""
from pathlib import Path
import argparse,datetime,json,os,shutil,stat,struct,subprocess,sys,zipfile
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from release_common import *
def tracked(root):
 return [p.decode() for p in subprocess.check_output(['git','-C',str(root),'ls-files','-z']).split(b'\0') if p]
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['baseline','source','stage','pins','qualification']:p.add_argument(name,type=Path)
 a=p.parse_args();base=a.baseline.resolve();source=a.source.resolve();stage=fresh_scratch(a.stage);pins=read_json(a.pins)
 require(pins['baseline_commit']==BASE_COMMIT and git(base,'rev-parse','HEAD')==BASE_COMMIT and not git(base,'status','--porcelain'),'Exact clean P021 source required')
 require(not git(source,'status','--porcelain') and source!=base,'Clean separate committed P022 source required')
 require(git(source,'rev-parse','--absolute-git-dir')!=git(base,'rev-parse','--absolute-git-dir'),'Independent Git admin ownership required')
 commit=git(source,'rev-parse','HEAD');subprocess.run(['git','-C',str(source),'merge-base','--is-ancestor',BASE_COMMIT,commit],check=True)
 archive=Path(pins['archive']);require(sha(archive)==BASE_ZIP_SHA and archive.stat().st_size==BASE_ZIP_BYTES,'Protected P021 ZIP differs')
 before={};modes={}
 for name,row in pins['files'].items():
  f=member_path(base,name);require(f.is_file() and sha(f)==row['sha256'] and stat.S_IMODE(f.stat().st_mode)==row['mode'],'P021 source preimage differs: '+name)
  before[name]=row['sha256'];modes[name]=row['mode']
 require(set(tracked(base))==set(before),'P021 tracked membership differs')
 after={name:sha(member_path(source,name)) for name in tracked(source)}
 require(set(before)<=set(after),'Product deletion requires separate review')
 changed=sorted(n for n in after if before.get(n)!=after[n]);require(changed,'No changed files')
 for name in changed:
  relpath(name)
  require(name.startswith(('core/','docs/api/','docs/development/DEV111-P022/','validation/dev111_p022/','plugins/modules/viewer.3d_workbench/')) or name in ('SCRIPT_CATALOG.md','SCRIPT_CATALOG.md.sha256','SHA256SUMS'),'Out-of-scope path: '+name)
  require('TODO' not in name.upper() and not any(x in Path(name).parts for x in ('Sessions','.git','__pycache__')),'Protected/private path: '+name)
 allowed_protected={'core/native2d/gx2d_tcl.c','core/native2d/gx2d_presentation_batch.h'}
 protected={n:r['sha256'] for n,r in pins['protected'].items() if n not in allowed_protected}
 for name,value in protected.items():require(after[name]==value,'Protected authority changed: '+name)
 with zipfile.ZipFile(archive) as z:
  prior=json.loads(z.read('patch_notes/DEV111-P021/FILES.json'));require(prior['source_commit']==BASE_COMMIT,'P021 manifest commit differs')
  for row in prior['changed_files']:require(before[row['path']]==row['after_sha256'] and digest(z.read(row['path']))==row['after_sha256'],'P021 archive/source postimage differs')
 qualification=read_json(a.qualification);require(not check_qualification(qualification,commit,after,changed),'Incomplete release gate')
 for name in BINARIES:
  raw=(source/name).read_bytes();require(raw[:6]==b'\x7fELF\x02\x01' and struct.unpack('<H',raw[18:20])[0]==62,'Linux x86-64 ELF required')
 for leaf in ['SHA256SUMS','SHA256SUMS.txt']:
  module=source/'plugins/modules/viewer.3d_workbench'
  for line in (module/leaf).read_text().splitlines():
   if not line.strip():continue
   value,name=line.split(None,1);name=name.lstrip('* ');require(sha(module/name)==value,'Workbench checksum differs: '+name)
 stage.mkdir();payload=stage/'payload';payload.mkdir();notes=payload/NOTES;notes.mkdir(parents=True)
 rows=[]
 for name in changed:
  target=payload/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,target)
  old=before.get(name)
  if old:
   target=notes/'rollback-preimages'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/name,target)
  rows.append(dict(path=name,action='replace' if old else 'add',before_sha256=old,after_sha256=after[name],before_mode=modes.get(name),after_mode=stat.S_IMODE((source/name).stat().st_mode)))
 manifest=dict(patch=PATCH,baseline_commit=BASE_COMMIT,baseline_archive_sha256=BASE_ZIP_SHA,source_commit=commit,changed_files=rows,protected_files=protected,installed=False,user_vnc_acceptance='OPEN')
 write_json(notes/'FILES.json',manifest);write_json(notes/'QUALIFICATION.json',qualification)
 for path in (source/'docs/development/DEV111-P022').iterdir():
  if path.is_file():shutil.copy2(path,notes/path.name)
 for name in ['apply.py','rollback.py','release_common.py']:shutil.copy2(source/'validation/dev111_p022'/name,notes/name)
 leaves=sorted(p for p in payload.rglob('*') if p.is_file());(notes/'PAYLOAD_SHA256SUMS').write_text(''.join(f'{sha(f)}  {f.relative_to(payload).as_posix()}\n' for f in leaves))
 epoch=int(git(source,'show','-s','--format=%ct','HEAD'));date=datetime.datetime.fromtimestamp(epoch,datetime.timezone.utc);dest=stage/(PATCH+'.zip')
 with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for f in sorted(p for p in payload.rglob('*') if p.is_file()):
   i=zipfile.ZipInfo(f.relative_to(payload).as_posix(),(date.year,date.month,date.day,date.hour,date.minute,date.second));i.create_system=3;i.external_attr=(stat.S_IFREG|stat.S_IMODE(f.stat().st_mode))<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,f.read_bytes(),compresslevel=9)
 apply_overlay(base,dest,False)
 proof=stage/'application-proof';proof.mkdir()
 for name in before:
  target=proof/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/name,target)
 apply_overlay(proof,dest,True)
 require(all(sha(proof/n)==v for n,v in after.items()),'Cumulative postimage mismatch')
 subprocess.run([sys.executable,'-B',str(source/'validation/dev111_p022/fresh_startup.py'),str(proof),str(stage/'fresh-startup')],check=True)
 rollback_overlay(proof,False);rollback_overlay(proof,True)
 require(all(sha(proof/n)==v and stat.S_IMODE((proof/n).stat().st_mode)==modes[n] for n,v in before.items()),'Rollback preimage mismatch')
 require(all(not (proof/n).exists() for n in set(after)-set(before)),'Rollback retained added product files')
 require(sha(archive)==BASE_ZIP_SHA and not git(base,'status','--porcelain'),'Protected P021 changed')
 result=dict(patch=PATCH,status='PASS',source_commit=commit,archive=str(dest),archive_sha256=sha(dest),archive_bytes=dest.stat().st_size,changed_files=len(rows),protected_anchors=len(protected),cumulative_application='all tracked P021 plus P022 postimages verified',rollback='all P021 bytes/modes restored; added product files removed',fresh_startup='PASS public API catalog',installed=False,user_vnc_acceptance='OPEN')
 write_json(stage/'VERIFICATION.json',result);(stage/(PATCH+'.zip.sha256')).write_text(sha(dest)+'  '+dest.name+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':
 try:main()
 except(GuardError,OSError,ValueError,KeyError,subprocess.SubprocessError)as e:raise SystemExit('REFUSED: '+str(e))
