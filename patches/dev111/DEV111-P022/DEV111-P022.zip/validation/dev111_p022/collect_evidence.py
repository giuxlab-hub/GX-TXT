#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import argparse,json,hashlib,shutil,subprocess
p=argparse.ArgumentParser();p.add_argument('workspace',type=Path);p.add_argument('framework',type=Path);p.add_argument('--supplement',action='store_true');a=p.parse_args();r=a.workspace.resolve();f=a.framework.resolve();out=f/'docs/development/DEV111-P022/evidence';out.mkdir(exist_ok=a.supplement)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(name,target=None):
 src=r/name;assert src.is_file() and not src.is_symlink() and src.stat().st_size<8*1024*1024,name
 dst=out/(target or name);dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists():assert a.supplement and sha(dst)==sha(src),('Evidence changed',name)
 else:shutil.copy2(src,dst)
for name in ['COMPARABLE_BASELINE.json','BASELINE_SPAN_INSTRUMENTATION.json','COMPARABLE_FIXTURES.json','native-contract04/PIXEL_EQUIVALENCE.json','native-contract04/CONTRACT.tcldict','build04/BUILD_IDENTITY.json','build03/COMPILER_DEPENDENCY_PINS.json','normal03/CLOSE_HANG_BACKTRACE.txt','normal03/XIM_RESTART.json','release-selftest01/RESULT.json']:
 if (r/name).exists():copy(name)
copy('METRICS05.json','METRICS.json')
build=json.loads((r/'build03/BUILD_IDENTITY.json').read_text());(out/'build03/NATIVE2D_BUILD.json').write_text(json.dumps(build['native2d'],indent=2)+'\n')
for case in ['cad-comparable-baseline01','cad-comparable-candidate01','molecule-comparable-baseline-hw01','molecule-comparable-baseline-sw01','molecule-comparable-candidate-hw01','molecule-comparable-candidate-sw01','lifecycle02','projection04','tilted02','cad-edges01','close-yes02','restore02','testcad1-03','testcad2-01','testcad-software05','testcad-auto01','builder-modes01','pending-close04']:
 root=r/case
 if not root.exists():continue
 for src in sorted(root.rglob('*')):
  if not src.is_file():continue
  relative=src.relative_to(root)
  if src.suffix in ('.json','.jsonl','.tsv','.receipts','.png') or src.name in ['BEFORE.tcldict','AFTER.tcldict','UNDO.tcldict','SAVED_MODEL.tcldict','REOPENED.tcldict','RESTORED_STATE.tcldict','RETAINED_TOPOLOGY.tcllist'] or src.name.endswith('RENDERER.tcldict'):
   copy(str(Path(case)/relative))
# Only bounded renderer and parent launch metadata, never profile or Session files.
for name in ['normal01/LAUNCH.json','normal02/LAUNCH.json','normal04/LAUNCH.json','normal-candidate-perf01/LAUNCH.json','normal-restore01/LAUNCH.json','normal04/preview-hardware-process/PROCESSES.json','normal04/preview-software-process/PROCESSES.json','replay05/BACKTRACE.log','replay09/RESULT.json']:
 if (r/name).exists():copy(name)
for case in ['normal03/software-cpp','normal03/auto-cpp','normal03/hardware-cpp','normal02/hardware01']:
 for src in sorted((r/case).glob('*')):
  if src.suffix in ('.png','.tcldict','.jsonl','.json'):copy(str(src.relative_to(r)))
# The preserved failure identifies the old driver interposition stack; no core dump.
base=json.loads((r/'BASELINE.json').read_text());(out/'PROTECTED_BASELINE.json').write_text(json.dumps(dict(baseline_commit=base['baseline_commit'],archive=base['archive'],protected=base['protected']),indent=2)+'\n')
index={x.relative_to(out).as_posix():sha(x) for x in sorted(out.rglob('*')) if x.is_file() and x.name!='INDEX.json'};(out/'INDEX.json').write_text(json.dumps(dict(runtime_commit='8bc9fbaede1a316e82ab921d9775413c7164f2a5',files=index,original_user_content_included=False),indent=2)+'\n');print(len(index),'evidence files')
