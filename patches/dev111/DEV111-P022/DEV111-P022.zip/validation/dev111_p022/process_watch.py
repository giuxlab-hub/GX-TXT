#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only bounded descendant observations; not a rendering probe."""
import argparse,json,os,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('launch',type=Path);p.add_argument('output',type=Path);p.add_argument('--seconds',type=float,default=15);a=p.parse_args()
root=json.loads(a.launch.read_text());parent=int(root['pid']);out=a.output;out.mkdir(exist_ok=False)
assert Path(f'/proc/{parent}').stat().st_uid==os.getuid()
end=time.monotonic()+a.seconds;seen={};samples=[]
while time.monotonic()<end:
 todo=[parent];children=[]
 while todo:
  current=todo.pop()
  try:
   ids=[int(x) for x in Path(f'/proc/{current}/task/{current}/children').read_text().split()]
   children+=ids;todo+=ids
  except OSError:pass
 for pid in children:
  d=Path('/proc')/str(pid)
  try:
   if d.stat().st_uid!=os.getuid():continue
   stat=(d/'stat').read_text();key=f'{pid}:{stat[stat.rfind(")")+2:].split()[19]}'
   if key not in seen:
    env={}
    for s in (d/'environ').read_bytes().split(b'\0'):
     if b'=' not in s:continue
     k,v=map(os.fsdecode,s.split(b'=',1))
     if k.startswith(('LIBGL_','MESA_','GALLIUM_','__GLX_')) or k in ('DISPLAY','XAUTHORITY','LD_LIBRARY_PATH','LD_PRELOAD'):env[k]=v
    seen[key]=dict(pid=pid,first_ns=time.monotonic_ns(),command=os.fsdecode((d/'cmdline').read_bytes()).split('\0'),environment=env,limits=(d/'limits').read_text(),gl_libraries=[])
   item=seen[key];item['last_ns']=time.monotonic_ns()
   paths=set()
   for line in (d/'maps').read_text().splitlines():
    if any(x in line for x in ('libGL','nvidia','swrast','libLLVM','libEGL','libglapi')):paths.add(line.split()[-1])
   item['gl_libraries']=sorted(set(item['gl_libraries'])|paths)
   samples.append(dict(ns=time.monotonic_ns(),pid=pid,stat=stat))
  except (OSError,IndexError,ValueError):pass
 time.sleep(.01)
(out/'PROCESSES.json').write_text(json.dumps(list(seen.values()),indent=2)+'\n')
with (out/'SAMPLES.jsonl').open('w') as f:
 for row in samples:f.write(json.dumps(row)+'\n')
print(json.dumps(dict(processes=len(seen),samples=len(samples),seconds=a.seconds)))
