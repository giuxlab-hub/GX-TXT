#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import json,subprocess,hashlib,sys
f=Path(sys.argv[1]).resolve();assert subprocess.check_output(['git','-C',str(f),'branch','--show-current'],text=True).strip()=='patch/dev111-p022'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def output(name,data): (f/name).write_text(json.dumps(data,indent=2)+'\n')
base='b30bc478125dc8ea742094478d17b844eeb2d789';runtime='8bc9fbaede1a316e82ab921d9775413c7164f2a5'
changed=set(subprocess.check_output(['git','-C',str(f),'diff','--name-only',base],text=True).splitlines());changed.update(subprocess.check_output(['git','-C',str(f),'ls-files','--others','--exclude-standard'],text=True).splitlines());assert not any('__pycache__' in x for x in changed)
for n in changed:
 if n.startswith(('core/','plugins/')):
  expected=subprocess.check_output(['git','-C',str(f),'show',runtime+':'+n]);assert hashlib.sha256(expected).hexdigest()==sha(f/n),('Runtime changed after GUI qualification',n)
for name in ['SHA256SUMS','SHA256SUMS.txt']:
 root=f/'plugins/modules/viewer.3d_workbench'
 for line in (root/name).read_text().splitlines():
  if line.strip(): value,path=line.split(None,1);assert sha(root/path.lstrip('* '))==value
output('docs/development/DEV111-P022/BUILD_IDENTITY.json',dict(tested_runtime_commit=runtime,native3d_engine_unchanged='ea25f6ec5cd885ff517a2301f56712840edb188cb1210ad4a94fb337b9282100',native2d_scientific_kernel_unchanged='f91c96ad540d9e1822d99c2726d4b62334bbe6d3aba4abaa02a89f2eb66f37fe',binaries={n:sha(f/n) for n in ['core/native2d/bin/gx2dtcl.so','core/native3d/bin/libgx3de_viewer_tcl.so']},build_records=['evidence/build03/NATIVE2D_BUILD.json','evidence/build03/COMPILER_DEPENDENCY_PINS.json','evidence/build04/BUILD_IDENTITY.json'],compiler='g++ (Debian14.2.0-19)14.2.0; C++17; O2',native2d_build='existing CMake gx2dtcl target, two compile jobs; existing local Cairo headers; no download/install',native3d_build='existing Tcl target contract, unchanged native engine; libpng16 additive transport dependency',native3d_rpath='$ORIGIN/../lib',installed=False))
# Inventory is path/role only; the external final manifest supplies exact hashes.
changed.add('docs/development/DEV111-P022/BUILD_IDENTITY.json');changed.add('docs/development/DEV111-P022/CHANGED_FILES.json');changed.update(['SHA256SUMS','SCRIPT_CATALOG.md.sha256'])
output('docs/development/DEV111-P022/CHANGED_FILES.json',dict(baseline=base,paths=sorted(changed),role_notes={'core/native2d/':'additive coordinate batching and matching adapter binary; C scientific kernel unchanged','core/native3d/':'Tcl transport, receipts, batching and PNG dependency only; engine unchanged','core/tcl/':'renderer launch, queue ownership, shared projection and explicit saved display lifecycle','plugins/modules/viewer.3d_workbench/':'consumer lifecycle integration,0.3.4/manual/checksums','docs/':'public contracts, measured reports and synthetic evidence','validation/':'bounded reproducible inputs/contracts/build/release tools','root metadata':'only changed/new P022 checksum entries refreshed'}))
(f/'SCRIPT_CATALOG.md.sha256').write_text(sha(f/'SCRIPT_CATALOG.md')+'  SCRIPT_CATALOG.md\n')
old={}
for line in (f/'SHA256SUMS').read_text().splitlines():
 if not line.strip():continue
 value,name=line.split(None,1);old[name.lstrip('* ')]=value
for name in sorted(changed):
 if name!='SHA256SUMS':old[name]=sha(f/name)
(f/'SHA256SUMS').write_text(''.join(value+'  '+name+'\n' for name,value in sorted(old.items())))
print('Runtime matches tested commit;',len(changed),'changed paths indexed; scoped checksums refreshed')
