# SPDX-License-Identifier: GPL-3.0-or-later
# CORE local durable Job API. UI callbacks use nonblocking fileevents only.
namespace eval ::GX {variable scriptJobRequests {};variable scriptJobCounter 0;variable scriptJobShutdownHook 0}
proc ::GX::scriptJobApiInfo {} {
    return [dict create api_name SCRIPT_JOB_API_v1 api_version 1 scope {local remote_references} authority core operations {submit wait list describe inspect log_read inspect_run run_log_read run_summaries cancel recover configure debug_submit debug_read debug_control debug_capabilities stream_read stream_publish view_list history_hide history_restore history_candidates workspace_save workspace_open workspace_rename workspace_delete view_remember} persistence durable gui_lifetime independent presentation_scope user_configuration auxiliary_operations {scriptJobAsync scriptJobRequestCancel scriptJobRequestExchange scriptJobRequestSend scriptJobRequestDrain} auxiliary_limits {timeout_ms max_bytes process_group ui_lifetime label duplex separate_stderr send_pending_bytes} auxiliary_exchange_timeout_ms {default 12000 min 1 max 120000} auxiliary_send_pending_bytes {default 65536 min 1024 max 2097152} auxiliary_drain_maximum {default 16 min 1 max 16}]
}
proc ::GX::scriptJobRoot {} {
    if {[info exists ::env(GXTXT_JOB_ROOT)]} {return [file normalize $::env(GXTXT_JOB_ROOT)]}
    return [file join [file dirname [configurationPath]] script-jobs-v1]
}
proc ::GX::scriptJobCommand {operation args} {
    return [list [runtimeToolResolve python] -B [file join $::GX::scriptDir core python gxtxt_job_supervisor.py] --root [scriptJobRoot] $operation {*}$args]
}
proc ::GX::scriptJobCall {operation args} {
    if {[llength [info commands ::GX::stderrDiagnosticsProducerEnvironment]]} {stderrDiagnosticsProducerEnvironment}
    set rc [catch {exec {*}[scriptJobCommand $operation {*}$args]} response]
    if {[catch {dict get $response ok} ok]} {error $response}
    if {!$ok} {error [dict get $response error]}
    return [dict get $response result]
}
proc ::GX::scriptJobAsync {command payload callback {options {}}} {
    variable scriptJobRequests;variable scriptJobCounter
    if {[llength [info commands ::GX::stderrDiagnosticsProducerEnvironment]]} {stderrDiagnosticsProducerEnvironment}
    foreach key [dict keys $options] {if {$key ni {timeout_ms max_bytes process_group ui_lifetime label duplex separate_stderr send_pending_bytes}} {error {Unknown managed request option.}}}
    set options [dict merge {timeout_ms 0 max_bytes 0 process_group 0 ui_lifetime 0 label {Managed request} duplex 0 separate_stderr 0 send_pending_bytes 65536} $options]
    if {![string is entier -strict [dict get $options send_pending_bytes]] || [dict get $options send_pending_bytes]<1024 || [dict get $options send_pending_bytes]>2097152} {error {Managed request send budget must be1024..2097152 bytes}}
    foreach key {timeout_ms max_bytes} {if {![string is integer -strict [dict get $options $key]] || [dict get $options $key]<0} {error {Managed request limits must be nonnegative integers.}}}
    foreach key {process_group ui_lifetime duplex separate_stderr} {if {![string is boolean -strict [dict get $options $key]]} {error {Managed request lifetime options must be boolean.}}}
    if {[dict get $options process_group] && [auto_execok kill] eq {}} {error {Owned process-group cancellation is unavailable on this host.}}
    if {[dict get $options separate_stderr] && [dict get $options duplex]} {error {Separate diagnostics require a non-duplex managed request}}
    set request job-request-[incr scriptJobCounter]
    set pipe {};set diagnostics {};set diagnosticWrite {}
    try {
        if {[dict get $options separate_stderr]} {
            lassign [chan pipe] diagnostics diagnosticWrite
            fconfigure $diagnostics -blocking 0 -buffering none -encoding utf-8 -translation lf
            set pipe [open [list | {*}$command 2>@ $diagnosticWrite] r+]
            close $diagnosticWrite;set diagnosticWrite {}
        } else {set pipe [open [list | {*}$command 2>@1] r+]}
        fconfigure $pipe -blocking 0 -buffering none -encoding utf-8 -translation lf
        puts -nonewline $pipe $payload
        if {![dict get $options duplex]} {chan close $pipe write}
    } on error {message context} {foreach channel [list $pipe $diagnostics $diagnosticWrite] {if {$channel ne {}} {catch {close $channel}}};return -options $context $message}
    dict set scriptJobRequests $request [dict create pipe $pipe callback $callback data {} options $options pids [pid $pipe] started_ms [clock milliseconds] timer {} kill_timer {} cancelled {} stderr_pipe $diagnostics stderr_eof [expr {$diagnostics eq {}}] stderr_bytes 0 stderr_data {}]
    set timeout [dict get $options timeout_ms]
    if {$timeout>0} {dict set scriptJobRequests $request timer [after $timeout [list ::GX::scriptJobRequestCancel $request timeout]]}
    if {[dict get $options ui_lifetime] && !$::GX::scriptJobShutdownHook && [llength [info commands winfo]] && [winfo exists .]} {
        bind . <Destroy> +[list ::GX::scriptJobRequestsShutdown %W]
        set ::GX::scriptJobShutdownHook 1
    }
    fileevent $pipe readable [list ::GX::scriptJobReadable $request]
    if {$diagnostics ne {}} {fileevent $diagnostics readable [list ::GX::_scriptJobStderrReadable $request]}
    return $request
}
proc ::GX::_scriptJobRequestReadResume {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request receive_paused]} return
    # Clear before touching the channel: a failed rearm uses ordinary Cancel,
    # which must not recursively try the same failed rearm.
    dict unset scriptJobRequests $request receive_paused
    set pipe [dict get $scriptJobRequests $request pipe]
    if {[catch {fileevent $pipe readable [list ::GX::scriptJobReadable $request]}]} {
        dict set scriptJobRequests $request eof 1
        scriptJobRequestCancel $request read_error
    }
}
proc ::GX::_scriptJobRequestReadPause {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request] || [dict get $scriptJobRequests $request cancelled] ne {}} return
    dict set scriptJobRequests $request receive_paused 1
    if {[catch {fileevent [dict get $scriptJobRequests $request pipe] readable {}}]} {
        dict set scriptJobRequests $request eof 1
        scriptJobRequestCancel $request read_error
    }
}
proc ::GX::_scriptJobRequestFrame {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request]} {return 0}
    set entry [dict get $scriptJobRequests $request]
    set data [dict get $entry data];set maximum [dict get $entry options max_bytes]
    if {$maximum>0} {
        # Read only after complete staged lines are consumed. The old bounded
        # prefix plus ONE existing 65536-character read bounds parked staging;
        # this is a character bound, not an assertion about UTF-8 byte width.
        set invalid [expr {[string length $data]>$maximum+65536}]
        if {!$invalid} {
            foreach line [split $data \n] {
                if {[string bytelength $line]>$maximum} {set invalid 1;break}
            }
        }
        if {$invalid} {
            dict set entry data [string range $data 0 [expr {max(0,$maximum/8-1)}]]
            dict set scriptJobRequests $request $entry
            scriptJobRequestCancel $request output_limit
            return 0
        }
    }
    # Do not consume the next frame without a slot. The exact suffix (including
    # empty frames) remains with this same owner until its consumer frees space.
    while {[llength [datasetPublicationV2DictDefault $entry messages {}]]<16 && [set newline [string first \n $data]]>=0} {
        dict lappend entry messages [string range $data 0 [expr {$newline-1}]]
        set data [string range $data [expr {$newline+1}] end]
    }
    dict set entry data $data
    dict set scriptJobRequests $request $entry
    return 1
}
# The same managed request owns both channels and their combined byte budget.
proc ::GX::_scriptJobStderrReadable {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request]} return
    set entry [dict get $scriptJobRequests $request]
    if {[dict get $entry stderr_eof]} return
    set pipe [dict get $entry stderr_pipe]
    set failed [catch {read $pipe 8192} chunk]
    if {$failed} {
        catch {fileevent $pipe readable {}}
        dict set entry stderr_eof 1
    } else {
        dict incr entry stderr_bytes [string bytelength $chunk]
        if {$chunk ne {} && [llength [info commands ::GX::stderrDiagnostics]] && $::GX::StderrDiagnostics::desired} {
            set children [dict get $entry pids]
            catch {stderrDiagnostics emit [dict create source managed_auxiliary component ScriptJob api_id SCRIPT_JOB_API_v1 operation request_stderr process_id [expr {[llength $children]==1?[lindex $children 0]:{unknown}}] stream stderr] [encoding convertto utf-8 $chunk]}
        }
        if {[dict get $entry cancelled] eq {}} {
            dict append entry stderr_data $chunk
            if {[string bytelength [dict get $entry stderr_data]]>8192} {dict set entry stderr_data [string range [dict get $entry stderr_data] end-2047 end]}
        }
        if {[eof $pipe]} {fileevent $pipe readable {};dict set entry stderr_eof 1}
    }
    dict set scriptJobRequests $request $entry
    set maximum [dict get $entry options max_bytes]
    if {$failed} {scriptJobRequestCancel $request read_error
    } elseif {$maximum>0 && [dict get $entry stderr_bytes]+[string bytelength [dict get $entry data]]>$maximum} {scriptJobRequestCancel $request output_limit}
    if {[dict exists $entry eof]} {after idle [list ::GX::scriptJobReadable $request]}
}
proc ::GX::scriptJobReadable {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request]} return
    set entry [dict get $scriptJobRequests $request];set pipe [dict get $entry pipe]
    set ended [dict exists $entry eof]
    set deferred 0
    if {!$ended && [dict get $entry options duplex] && [dict get $entry cancelled] eq {}} {
        if {![_scriptJobRequestFrame $request]} return
        set entry [dict get $scriptJobRequests $request]
        set deferred [expr {[llength [datasetPublicationV2DictDefault $entry messages {}]]>=16}]
        if {!$deferred} {
            _scriptJobRequestReadResume $request
            if {![dict exists $scriptJobRequests $request]} return
            set entry [dict get $scriptJobRequests $request];set ended [dict exists $entry eof]
        }
    }
    if {!$ended && !$deferred} {
        if {[catch {read $pipe 65536} chunk]} {
            # A failed/closed channel must still use the existing cancellation,
            # escalation and terminal callback owner, even without another EOF.
            catch {fileevent $pipe readable {}}
            scriptJobRequestCancel $request read_error
            dict set scriptJobRequests $request eof 1
            set entry [dict get $scriptJobRequests $request]
            set ended 1
        } else {dict append entry data $chunk}
    }
    set maximum [dict get $entry options max_bytes]
    if {[dict get $entry options duplex]} {
        if {[dict get $entry cancelled] ne {}} {
            # Drain the owned channel during normal cancellation without
            # retaining additional unsolicited native output.
            dict set entry data {}
        } else {
        dict set scriptJobRequests $request $entry
        if {![_scriptJobRequestFrame $request]} return
        set entry [dict get $scriptJobRequests $request]
        }
    }
    if {![dict get $entry options duplex] && $maximum>0 && [string bytelength [dict get $entry data]]+[dict get $entry stderr_bytes]>$maximum} {
        dict set entry data [string range [dict get $entry data] 0 [expr {max(0,$maximum/8-1)}]]
        dict set scriptJobRequests $request $entry
        scriptJobRequestCancel $request output_limit
        set entry [dict get $scriptJobRequests $request]
    }
    dict set scriptJobRequests $request $entry
    if {!$ended} {
        if {[catch {eof $pipe} atEOF]} {
            scriptJobRequestCancel $request read_error
            dict set scriptJobRequests $request eof 1
            set entry [dict get $scriptJobRequests $request]
        } elseif {!$atEOF} {
            if {[dict get $entry options duplex] && [dict get $entry cancelled] eq {} && [llength [datasetPublicationV2DictDefault $entry messages {}]]>=16} {
                _scriptJobRequestReadPause $request
            }
            return
        }
    }
    if {![dict get $entry stderr_eof]} {
        catch {fileevent $pipe readable {}}
        dict set scriptJobRequests $request eof 1
        return
    }
    if {[dict get $entry options duplex] && [dict get $entry cancelled] eq {}} {
        # A persistent native leader can crash after fork while a descendant
        # redirects stdout. Retain ownership until the whole group is reaped.
        scriptJobRequestCancel $request closed
        set entry [dict get $scriptJobRequests $request]
    }
    # A worker can exit before a descendant that redirected its stdout. Keep
    # the group identity until the escalation has run, even after pipe EOF.
    if {[dict get $entry cancelled] ne {} && ![dict exists $entry escalated]} {
        catch {fileevent $pipe readable {}}
        dict set scriptJobRequests $request eof 1
        return
    }
    catch {fileevent $pipe readable {}};catch {close $pipe}
    if {[dict get $entry stderr_pipe] ne {}} {catch {fileevent [dict get $entry stderr_pipe] readable {}};catch {close [dict get $entry stderr_pipe]}}
    foreach key {timer kill_timer} {if {[dict get $entry $key] ne {}} {after cancel [dict get $entry $key]}}
    dict unset scriptJobRequests $request
    set response [string trim [dict get $entry data]]
    if {[dict get $entry cancelled] ne {}} {set response [dict create ok 0 error "[dict get $entry options label]: [dict get $entry cancelled]" error_type [dict get $entry cancelled]]}
    if {[catch {dict get $response ok}]} {set response [dict create ok 0 error $response]}
    if {[dict get $entry stderr_data] ne {}} {
        set tail [datasetPublicationV2DictDefault $response diagnostic_tail {}]
        append tail \n [dict get $entry stderr_data]
        if {[string bytelength $tail]>8192} {set tail [string range $tail end-2047 end]}
        dict set response diagnostic_tail $tail
    }
    if {[dict get $entry callback] ne {}} {uplevel #0 [list {*}[dict get $entry callback] $response]}
}
proc ::GX::scriptJobRequestExchange {request payload {timeout_ms 12000}} {
    # Short native RPCs share the existing managed request/pipe/process-group
    # owner. Do not enter a nested Tk event loop: queued Canvas input must see
    # the completed local tool selection, never the previous tool.
    if {![string is integer -strict $timeout_ms] || $timeout_ms<1 || $timeout_ms>120000} {error {Managed exchange timeout is outside1..120000ms}}
    if {![dict exists $::GX::scriptJobRequests $request] || ![dict get $::GX::scriptJobRequests $request options duplex]} {error {Managed duplex request is no longer active}}
    set pipe [dict get $::GX::scriptJobRequests $request pipe]
    if {$payload ne {}} {puts $pipe $payload;flush $pipe}
    set deadline [expr {[clock milliseconds]+$timeout_ms}]
    while {[dict exists $::GX::scriptJobRequests $request]} {
        scriptJobReadable $request
        if {![dict exists $::GX::scriptJobRequests $request]} break
        set entry [dict get $::GX::scriptJobRequests $request]
        if {[dict get $entry cancelled] ne {}} {error {Managed compiled request was cancelled}}
        set messages [datasetPublicationV2DictDefault $entry messages {}]
        if {[llength $messages]} {
            dict set ::GX::scriptJobRequests $request messages [lrange $messages 1 end]
            _scriptJobRequestReadResume $request
            if {![dict exists $::GX::scriptJobRequests $request] || [dict get $::GX::scriptJobRequests $request cancelled] ne {}} {error {Managed compiled request was cancelled}}
            return [lindex $messages 0]
        }
        if {[clock milliseconds]>=$deadline} {scriptJobRequestCancel $request timeout;error {Compiled local event exceeded its bounded response time}}
        after 1
    }
    error {Compiled Viewer worker ended before responding}
}
proc ::GX::scriptJobRequestSend {request payload} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request] || ![dict get $scriptJobRequests $request options duplex] || [dict get $scriptJobRequests $request cancelled] ne {}} {
        return -code error -errorcode {GXTXT SCRIPT_JOB INACTIVE} {Managed duplex request is no longer active}
    }
    if {[string first \x00 $payload]>=0 || [string first \r $payload]>=0 || [string first \n $payload]>=0} {
        return -code error -errorcode {GXTXT SCRIPT_JOB FRAME} {Managed duplex payload must not contain NUL, CR or LF}
    }
    # Count the actual Tcl channel encoding, including the single appended LF.
    # No write/flush is attempted until the entire pending-output budget fits.
    set bytes [string length [encoding convertto utf-8 $payload]]
    set pipe [dict get $scriptJobRequests $request pipe]
    if {[catch {chan pending output $pipe} pending]} {
        scriptJobRequestCancel $request write_error
        return -code error -errorcode {GXTXT SCRIPT_JOB WRITE_FAILED} {Managed duplex request write failed}
    }
    if {$bytes+1+$pending>[dict get $scriptJobRequests $request options send_pending_bytes]} {
        return -code error -errorcode {GXTXT SCRIPT_JOB BUSY} {Managed duplex pending-output budget exceeded}
    }
    if {[catch {puts $pipe $payload;flush $pipe}]} {
        # A partly written frame is never retried. The same owner retains the
        # pipe and child/group through its ordinary terminal escalation.
        scriptJobRequestCancel $request write_error
        return -code error -errorcode {GXTXT SCRIPT_JOB WRITE_FAILED} {Managed duplex request write failed}
    }
    return [dict create request_id $request accepted 1 payload_bytes $bytes]
}
proc ::GX::scriptJobRequestDrain {request {maximum 16}} {
    variable scriptJobRequests
    if {![string is integer -strict $maximum] || $maximum<1 || $maximum>16} {
        return -code error -errorcode {GXTXT SCRIPT_JOB MAXIMUM} {Managed duplex drain maximum is outside1..16}
    }
    set inactive [dict create request_id $request active 0 cancelled {} messages {}]
    if {![dict exists $scriptJobRequests $request]} {return $inactive}
    if {![dict get $scriptJobRequests $request options duplex]} {
        return -code error -errorcode {GXTXT SCRIPT_JOB INACTIVE} {Managed duplex request is no longer active}
    }
    # Blocking Exchange/Bridge callers do not pump the ordinary after timer.
    # Service only this already-cancelled request's captured escalation deadline.
    set entry [dict get $scriptJobRequests $request]
    if {[dict get $entry cancelled] ne {} && ![dict exists $entry escalated] && [dict exists $entry kill_deadline_ms] && [clock milliseconds]>=[dict get $entry kill_deadline_ms]} {
        _scriptJobRequestEscalate $request
        if {![dict exists $scriptJobRequests $request]} {return $inactive}
    }
    # Free existing FIFO capacity before ONE readable service. Held frames are
    # still subordinate to terminal/cancellation authority from that service.
    set entry [dict get $scriptJobRequests $request]
    set messages {}
    if {[dict get $entry cancelled] eq {}} {
        set queued [datasetPublicationV2DictDefault $entry messages {}]
        set messages [lrange $queued 0 [expr {$maximum-1}]]
        dict set scriptJobRequests $request messages [lrange $queued $maximum end]
        _scriptJobRequestReadResume $request
    }
    scriptJobReadable $request
    # Readable can terminalize and invoke arbitrary trusted host cleanup. Only
    # the actual surviving entry may supply messages or receive the residuals.
    if {![dict exists $scriptJobRequests $request]} {return $inactive}
    set entry [dict get $scriptJobRequests $request]
    set cancelled [dict get $entry cancelled]
    if {$cancelled eq {}} {
        set queued [datasetPublicationV2DictDefault $entry messages {}]
        set remaining [expr {$maximum-[llength $messages]}]
        if {$remaining>0} {
            lappend messages {*}[lrange $queued 0 [expr {$remaining-1}]]
            dict set scriptJobRequests $request messages [lrange $queued $remaining end]
            _scriptJobRequestReadResume $request
        }
        if {![dict exists $scriptJobRequests $request]} {return $inactive}
        set cancelled [dict get $scriptJobRequests $request cancelled]
    }
    if {$cancelled ne {}} {set messages {}}
    return [dict create request_id $request active 1 cancelled $cancelled messages $messages]
}
proc ::GX::_scriptJobRequestSignal {request signal} {
    if {![dict exists $::GX::scriptJobRequests $request]} return
    set entry [dict get $::GX::scriptJobRequests $request]
    set kill [auto_execok kill];if {$kill eq {}} return
    foreach child [dict get $entry pids] {
        if {![string is integer -strict $child] || $child<=1} continue
        set delivered 0
        if {[dict get $entry options process_group]} {set delivered [expr {![catch {exec {*}$kill -$signal -- -$child 2>/dev/null}]}]}
        # A successful group signal already includes its leader. Sending it
        # again to that PID can interrupt the worker's terminal cleanup handler.
        if {!$delivered} {catch {exec {*}$kill -$signal -- $child 2>/dev/null}}
    }
}
proc ::GX::scriptJobRequestCancel {request {reason cancelled}} {
    variable scriptJobRequests
    if {$reason ni {cancelled timeout output_limit closed read_error write_error}} {error {Unknown managed request cancellation reason.}}
    if {![dict exists $scriptJobRequests $request] || [dict get $scriptJobRequests $request cancelled] ne {}} {return 0}
    dict set scriptJobRequests $request cancelled $reason
    dict set scriptJobRequests $request kill_deadline_ms [expr {[clock milliseconds]+500}]
    _scriptJobRequestSignal $request TERM
    dict set scriptJobRequests $request kill_timer [after 500 [list ::GX::_scriptJobRequestEscalate $request]]
    # A full receive window may have paused fileevents before EOF was known.
    # Cancellation must resume discard-reading or escalation cannot retire it.
    _scriptJobRequestReadResume $request
    return 1
}
proc ::GX::_scriptJobRequestEscalate {request} {
    if {![dict exists $::GX::scriptJobRequests $request] || [dict exists $::GX::scriptJobRequests $request escalated]} return
    dict set ::GX::scriptJobRequests $request escalated 1
    set timer [dict get $::GX::scriptJobRequests $request kill_timer]
    if {$timer ne {}} {after cancel $timer;dict set ::GX::scriptJobRequests $request kill_timer {}}
    _scriptJobRequestSignal $request KILL
    if {[dict exists $::GX::scriptJobRequests $request eof]} {scriptJobReadable $request}
}
proc ::GX::scriptJobRequestsShutdown {actual} {
    if {$actual ne {.}} return
    dict for {request entry} $::GX::scriptJobRequests {
        if {[dict get $entry options ui_lifetime]} {
            _scriptJobRequestSignal $request KILL
            # A rearmed full queue must discard, rather than pause again.
            # Enter the same Cancel/EOF/escalation owner; first reason wins.
            if {[dict get $entry options duplex]} {
                scriptJobRequestCancel $request closed
                _scriptJobRequestReadResume $request
            }
        }
    }
}
proc ::GX::scriptJobSubmit {reference parameters {options {}} {callback {}}} {
    if {[string match core-service:* $reference] || [dict exists $options core_service]} {error {Private CORE services cannot be submitted through user Script Job APIs}}
    tailcall ::GX::_scriptJobSubmit $reference $parameters $options $callback
}
proc ::GX::_scriptJobSubmitCore {service parameters {options {}} {callback {}}} {
    _scriptCoreServiceMetadata $service
    dict set options core_service $service
    tailcall ::GX::_scriptJobSubmit core-service:$service $parameters $options $callback
}
proc ::GX::_scriptJobSubmit {reference parameters options callback} {
    if {[llength [info commands ::GX::stderrDiagnosticsProducerEnvironment]]} {stderrDiagnosticsProducerEnvironment}
    set session [dict get [dict merge [dict create session $::GX::currentSession] $options] session]
    if {$session eq {} || ![file isdirectory $session]} {error {Open a Session before submitting a script.}}
    set moduleConfig {}
    if {$::GX::currentSession ne {} && [file normalize $::GX::currentSession] eq [file normalize $session]} {
        foreach module {analysis.python_script analysis.octave_script} {
            foreach key [array names ::GX::moduleCfg "$module,*"] {dict set moduleConfig $key $::GX::moduleCfg($key)}
        }
    }
    set request [dict merge [dict create module_config $moduleConfig inputs {} output {} runtime_template {} module_output {}] $options [dict create session [file normalize $session] reference $reference parameters $parameters root [scriptJobRoot]]]
    # The GUI may run under wish: its executable would keep a hidden Tk event
    # loop alive after preparation, preventing the asynchronous pipe from EOF.
    set interpreter [auto_execok tclsh]
    if {$interpreter eq {}} {error {A local Tcl interpreter is required for job preparation.}}
    set command [list {*}$interpreter [file join $::GX::scriptDir core tcl script_job_request.tcl] $::GX::scriptDir]
    if {$callback ne {}} {return [scriptJobAsync $command $request $callback]}
    set response [exec {*}$command << $request]
    if {![dict get $response ok]} {error [dict get $response error]}
    return [dict get $response result]
}
proc ::GX::scriptJobList {} {scriptJobCall list}
proc ::GX::scriptJobDescribe {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJobRecord $id describe]};scriptJobCall describe $id}
proc ::GX::scriptJobInspect {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJobRecord $id inspect]};scriptJobCall inspect $id}
proc ::GX::scriptJobLogRead {id {offset 0} {count 65536} {tail 0}} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJobRecord $id log_read $offset $count $tail]};scriptJobCall log_read $id $offset $count $tail}
proc ::GX::scriptExecutionInspectRun {session runId} {scriptJobCall inspect_run $session $runId}
proc ::GX::scriptExecutionRunSummaries {session} {scriptJobCall run_summaries $session}
proc ::GX::scriptJobCancel {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJob $id cancel]};scriptJobCall cancel $id}
proc ::GX::scriptJobWait {id {timeoutSeconds 60} {cancelCommand {}}} {
    if {![string is integer -strict $timeoutSeconds]||$timeoutSeconds<1||$timeoutSeconds>86400} {error {Job wait timeout must be an integer from 1 to 86400 seconds}}
    set lease {};if {![scientificExecutionRemoteId $id]} {set lease [scriptJobCall wait_begin $id]};set started [clock milliseconds];set cancelled 0
    try {
        while {1} {
            set info [scriptJobDescribe $id]
            if {[dict get $info state] in {COMPLETED FAILED CANCELLED INTERRUPTED}} break
            set requested [expr {[clock milliseconds]-$started>=1000*$timeoutSeconds}]
            if {$cancelCommand ne {}&&[{*}$cancelCommand]} {set requested 1}
            if {$requested&&!$cancelled} {scriptJobCancel $id;set cancelled 1}
            # Keep host events/cancellation responsive while CORE alone owns
            # admission, descendant lifetimes and terminal resource recovery.
            after 100;update
        }
        dict set info wait_cancel_requested $cancelled
        return $info
    } on error {message options} {
        catch {scriptJobCancel $id}
        return -options $options $message
    } finally {
        # On process/transport failure the supervisor reaps the caller lease,
        # cancels the owned child and restores capacity without caller cleanup.
        if {$lease ne {}} {catch {scriptJobCall wait_end [dict get $lease token]}}
    }
}
proc ::GX::scriptJobRecover {} {scriptJobCall recover}
source [file join [file dirname [info script]] script_job_presentation_v1.tcl]
# FUTURE WINDOWS PORTING REQUIREMENT: GUI close only detaches this client.
# Use the same LOCAL CORE Job API with an independent Windows supervisor/tray:
# reopen GUI, inspect jobs, cancel selected/all (confirm all), safe supervisor exit.
# No remote dispatch or mandatory service; native Job Objects own child lifetime.

proc ::GX::scriptJobStreamRead {id role {offset 0} {count 65536} {tail 0}} {scriptJobCall stream_read $id $role $offset $count $tail}
proc ::GX::scriptJobStreamPublish {id role datasetId {session {}}} {
    if {$session eq {}} {set record [scriptJobInspect $id]} else {set record [scriptExecutionInspectRun $session $id]}
    if {[dict get $record origin] eq {core_service}} {error {Private CORE service streams cannot be published as user results}}
    if {$::GX::currentSession eq {} || [file normalize [dict get $record session]] ne [file normalize $::GX::currentSession]} {error {Activate the source Job Session before publication}}
    set page [expr {$session eq {} ? [scriptJobStreamRead $id $role 0 65536 0] : [scriptJobCall run_stream_read $session $id $role 0 65536 0]}]
    if {![dict get $page available]} {error [dict get $page diagnostic]}
    if {![dict get $page complete]} {error {Wait for a terminal Job before publishing an immutable complete stream}}
    set path [dict get $page path];set before [sha256File $path]
    set producer [scriptAnalysisModule [dict get $record language]]
    set request [dict create dataset_id $datasetId contract document.text format txt source_file $path storage_kind text media_type text/plain provenance "Script Job $id; stream $role; source SHA [dict get $record source_sha256]" structured_metadata [dict create script.job_id $id script.stream_role $role script.source_sha256 [dict get $record source_sha256] script.stream_sha256 $before script.complete 1 text.encoding UTF-8]]
    set receipt [datasetFilePublicationPublish $::GX::currentSession $producer $request]
    if {[sha256File $path] ne $before} {error {Retained stream changed unexpectedly during publication}}
    return $receipt
}

proc ::GX::scriptJobDebugSubmit {reference parameters {options {}} {callback {}}} {dict set options debug 1;tailcall ::GX::scriptJobSubmit $reference $parameters $options $callback}
proc ::GX::scriptJobDebugRead {id} {scriptJobCall debug_read $id}
proc ::GX::scriptJobDebugCapabilities {language} {scriptJobCall debug_capabilities $language}
proc ::GX::scriptJobDebugControl {id operation sourceSha {frame 0}} {
    if {$operation eq {stop}} {return [scriptJobCancel $id]}
    scriptJobCall debug_control $id $operation $sourceSha $frame
}
