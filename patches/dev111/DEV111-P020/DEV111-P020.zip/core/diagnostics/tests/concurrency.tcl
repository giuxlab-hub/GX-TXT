# SPDX-License-Identifier: GPL-3.0-or-later
set root [file normalize [lindex $argv 0]]
source [file join $root core tcl stderr_diagnostics_v1.tcl]
set fixture [file normalize [file join $root .. fixture-concurrency-[pid]]]
proc assert {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc waitFor {expression {milliseconds 5000}} {
    set until [expr {[clock milliseconds]+$milliseconds}]
    while {![uplevel 1 [list expr $expression]]} {
        if {[clock milliseconds]>$until} {error "Timed out: $expression; status=[::GX::stderrDiagnostics status]"}
        after 1
        update
    }
}
set produced 0
set seen 0
set lastSequence 0
set cursor {}
set pending {}
set done 0
set fault {}
set feedTimer {}
set readTimer {}
set heartbeats 0
proc heartbeat {} {incr ::heartbeats;if {!$::done} {set ::heartbeatTimer [after 1 heartbeat]}}
proc feed {} {
    if {$::produced>=400} {return}
    incr ::produced
    set emitted [::GX::stderrDiagnostics emit [dict create source concurrent-fixture process_id [pid] operation stream] "event-$::produced [string repeat x 100]"]
    if {![dict get $emitted accepted]} {set ::fault "Unexpected producer loss: $emitted";set ::done 1;return}
    set ::feedTimer [after 1 feed]
}
proc collect {} {
    if {$::done} {return}
    if {$::pending eq {}} {
        if {[catch {set ::pending [::GX::stderrDiagnostics read $::cursor 8 8192]} error]} {set ::fault $error;set ::done 1;return}
    } else {
        set receipt [::GX::stderrDiagnostics request $::pending]
        if {[dict get $receipt state] eq {done}} {
            foreach record [dict get $receipt result records] {
                set sequence [dict get $record sequence]
                if {$sequence!=$::lastSequence+1} {set ::fault "Reader skipped/duplicated arrival: expected[expr {$::lastSequence+1}] got$sequence";set ::done 1;return}
                set ::lastSequence $sequence
                incr ::seen
            }
            set ::cursor [dict get $receipt result cursor]
            set ::pending {}
            if {$::seen==400} {set ::done 1;return}
        } elseif {[dict get $receipt state] ne {pending}} {set ::fault "Unexpected reader result: $receipt";set ::done 1;return}
    }
    set ::readTimer [after 1 collect]
}
try {
    file mkdir $fixture
    file attributes $fixture -permissions 0755
    ::GX::stderrDiagnostics start [dict create log_directory $fixture max_file_bytes 4096 max_files 5 ring_bytes 65536]
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    # Independent host/process must fail its flock before changing managed logs.
    set probe [file join $fixture probe.tcl]
    set f [open $probe w]
    puts $f [list source [file join $root core tcl stderr_diagnostics_v1.tcl]]
    puts $f [list ::GX::stderrDiagnostics start [dict create log_directory $fixture]]
    puts $f {for {set n 0} {$n<1000} {incr n} {set status [::GX::stderrDiagnostics status];if {[dict get $status state] eq {error}} {puts [dict get $status last_error];break};after 1;update}}
    puts $f {::GX::stderrDiagnostics stop}
    close $f
    set probeResult [exec [info nameofexecutable] $probe]
    assert {[string match {*Lock diagnostics directory*} $probeResult]} "Independent collector lock failed: $probeResult"
    file delete $probe
    assert {[dict get [::GX::stderrDiagnostics status] state] eq {running}} {Lock probe disturbed active collector}

    set timeout [after 10000 {set ::fault {Live reader timed out};set ::done 1}]
    set heartbeatTimer [after 1 heartbeat]
    feed
    collect
    vwait done
    after cancel $timeout
    after cancel $heartbeatTimer
    assert {$fault eq {}} $fault
    assert {$produced==400 && $seen==400} {Live reader lost records}
    assert {$heartbeats>=100} {Reader blocked the Tcl event loop}
    set status [::GX::stderrDiagnostics status]
    assert {[dict get $status dropped_records]==0} {Unexpected pressure during paced reader fixture}

    # Immediate stop/start must queue a restart rather than block/wait/fail.
    for {set n 0} {$n<10} {incr n} {
        ::GX::stderrDiagnostics stop
        ::GX::stderrDiagnostics start
        waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    }
    set prior $fixture
    ::GX::stderrDiagnostics configure [dict create log_directory ${fixture}-next]
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    assert {[dict get [::GX::stderrDiagnostics status] log_directory] eq "${fixture}-next"} {ON reconfiguration did not select the new directory}
    assert {[file isfile [file join $prior stderr-diagnostics.current.jsonl]]} {ON directory change removed old logs}
    ::GX::stderrDiagnostics stop
    waitFor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
    after 20
    update
    set before [after info]
    set subscription [::GX::stderrDiagnostics subscribe {apply {{status} {error {OFF callback must not poll}}}}]
    after 30
    update
    assert {[after info] eq $before} {OFF subscription installed a timer}
    assert {$::GX::StderrDiagnostics::timer eq {} && $::GX::StderrDiagnostics::transition eq {}} {OFF retained a capture/transition timer}
    ::GX::stderrDiagnostics unsubscribe $subscription
    puts "PASS diagnostics concurrency:400 ordered records during live rotation, ${heartbeats}event-loop heartbeats, exclusive directory flock,10rapid restarts, ON directory change, OFF subscriber idle"
} finally {
    foreach timer [list $feedTimer $readTimer [expr {[info exists heartbeatTimer]?$heartbeatTimer:{}}]] {if {$timer ne {}} {after cancel $timer}}
    catch {::GX::stderrDiagnostics stop}
    after 10
    catch {::GX::stderrDiagnostics status}
    file delete -force $fixture ${fixture}-next
}
