# SPDX-License-Identifier: GPL-3.0-or-later
# Private fixtures only. Argument: framework root, optional alternate library.
set root [file normalize [lindex $argv 0]]
source [file join $root core tcl stderr_diagnostics_v1.tcl]
if {[llength $argv]>1} {load [file normalize [lindex $argv 1]] Gxdiagnostics}
set fixture [file normalize [file join $root .. fixture-smoke-[pid]]]
proc assert {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc waitFor {expression {milliseconds 3000}} {
    set until [expr {[clock milliseconds]+$milliseconds}]
    while {![uplevel 1 [list expr $expression]]} {
        if {[clock milliseconds]>$until} {error "Timed out: $expression; status=[::GX::stderrDiagnostics status]"}
        after 2
        update
    }
}
proc completed {token} {
    set until [expr {[clock milliseconds]+5000}]
    while {1} {
        set result [::GX::stderrDiagnostics request $token]
        if {[dict get $result state] ne {pending}} {return $result}
        if {[clock milliseconds]>$until} {error {Reader timed out}}
        after 2
        update
    }
}
try {
    assert {[dict get [::GX::stderrDiagnostics status] state] eq {off}} {Default must be OFF}
    assert {![llength [info commands ::GX::StderrDiagnostics::_native]] || [llength $argv]>1} {Sourcing must not load native backend}
    ::GX::stderrDiagnostics configure [dict create log_directory $fixture max_file_bytes 4096 max_files 3 ring_bytes 65536]
    assert {![file exists $fixture]} {OFF configuration must not create directory}
    set absent [completed [::GX::stderrDiagnostics meta]]
    assert {[dict get $absent state] eq {done} && ![llength [dict get $absent result files]]} {Missing OFF directory must be empty metadata}
    ::GX::stderrDiagnostics emit {source off} ignored
    assert {![file exists $fixture]} {OFF emission must not write}
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    set bytes [binary format H* 000afffe7b227d5c0d0a]
    set origin [dict create source fixture module_id test.module viewer_id test.viewer job_id job-1 api_id fixture.v1 operation emit process_id 12345 stream stderr severity error]
    dict set origin source "fixture \u03b1 \u2603 \"quoted\"\\slash\nline"
    assert {[dict get [::GX::stderrDiagnostics emit $origin $bytes] accepted]} {Binary event must be accepted}
    waitFor {[dict get [::GX::stderrDiagnostics status] written_records]>=1}
    set page [completed [::GX::stderrDiagnostics read {} 100 1048576]]
    assert {[dict get $page state] eq {done}} "Reader error: $page"
    set record [lindex [dict get $page result records] 0]
    assert {[dict get $record payload] eq $bytes} {Binary payload must roundtrip exactly}
    assert {[dict get $record origin source] eq [dict get $origin source]} {UTF-8/escaped metadata must roundtrip exactly}
    assert {[dict get $record origin process_id] eq {12345}} {Original process identity lost}
    assert {[dict get $record capture_pid]==[pid]} {Capture process identity incorrect}
    set id [dict get $record record_id]
    file mkdir ${fixture}-exports
    file attributes ${fixture}-exports -permissions 0700
    set exportPath [file join ${fixture}-exports incident.jsonl]
    set exported [completed [::GX::stderrDiagnostics export [dict create record_ids [list $id]] $exportPath]]
    assert {[dict get $exported state] eq {done}} "Export error: $exported"
    assert {[dict get $exported result record_count]==1} {Export record_count incorrect}
    set f [open $exportPath rb];set exportedBytes [read $f];close $f
    assert {$exportedBytes eq [encoding convertto utf-8 "[dict get $record raw_json]\n"]} {Export changed serialized record}
    set collision [completed [::GX::stderrDiagnostics export [dict create record_ids [list $id]] $exportPath]]
    assert {[dict get $collision state] eq {error}} {Export must refuse an existing destination}
    file delete $exportPath
    set cursor [dict get $page result cursor]
    for {set i 0} {$i<60} {incr i} {
        ::GX::stderrDiagnostics emit $origin "record-$i [string repeat x 100]"
        after 1
        update
    }
    waitFor {[dict get [::GX::stderrDiagnostics status] pending_records]==0}
    set metadata [completed [::GX::stderrDiagnostics meta]]
    assert {[dict get $metadata state] eq {done}} "Metadata error: $metadata"
    assert {[llength [dict get $metadata result files]]<=3} {Retention exceeded configured count}
    foreach file [dict get $metadata result files] {assert {[dict get $file bytes]<=4096} {File exceeded configured bound}}
    set expired [completed [::GX::stderrDiagnostics read $cursor]]
    assert {[dict get $expired state] eq {error} && [dict get $expired error_code] eq {CURSOR_EXPIRED}} {Evicted cursor must explicitly expire}
    ::GX::stderrDiagnostics stop
    waitFor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
    set stopped [::GX::stderrDiagnostics status]
    assert {[dict get $stopped capture_ipc]==0 && [dict get $stopped queue_bytes]==0 && [dict get $stopped writer]==0} {OFF retains capture infrastructure}
    set before [glob -nocomplain -directory $fixture *]
    set retained [completed [::GX::stderrDiagnostics read {} 2 1024]]
    assert {[dict get $retained state] eq {done}} {OFF retained reading failed}
    assert {[llength [dict get $retained result records]]<=2} {Reader exceeded requested record budget}
    assert {[glob -nocomplain -directory $fixture *] eq $before} {OFF reader modified files}
    set current [file join $fixture stderr-diagnostics.current.jsonl]
    set f [open $current rb];set original [read $f];close $f
    set corrupt [string replace $original 2 2 X]
    set f [open $current wb];puts -nonewline $f $corrupt;close $f
    set damaged [completed [::GX::stderrDiagnostics read]]
    assert {[dict get $damaged state] eq {error}} {Corrupt retained data must be reported}
    set f [open $current wb];puts -nonewline $f $original;close $f
    set other ${fixture}-other
    ::GX::stderrDiagnostics configure [dict create log_directory $other]
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    assert {[file exists $fixture]} {Directory change removed old logs}
    set helper [dict get [::GX::stderrDiagnostics status] helper_pid]
    exec kill -KILL $helper
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
    assert {[dict get [::GX::stderrDiagnostics status] last_error] ne {}} {Crash must expose an error}
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    ::GX::stderrDiagnostics stop
    waitFor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
    puts {PASS diagnostics smoke: OFF isolation, lifecycle, binary/meta, selective export, bounded readers, rotation, cursor eviction, directory change, crash/restart}
} finally {
    catch {::GX::stderrDiagnostics stop}
    after 10
    catch {::GX::stderrDiagnostics status}
    file delete -force $fixture ${fixture}-other ${fixture}-exports
}
