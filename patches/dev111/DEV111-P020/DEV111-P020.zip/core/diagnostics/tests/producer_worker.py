# SPDX-License-Identifier: GPL-3.0-or-later
import ctypes
import importlib.util
import os
from pathlib import Path
import signal
import socket
import struct
import subprocess
import sys
import time
sys.dont_write_bytecode = True

example = Path(__file__).resolve().parents[1] / "producer_v1.py"
spec = importlib.util.spec_from_file_location("gxdiag_example", example)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
mode, library, descriptor = sys.argv[1:4]


def attach(library, descriptor):
    expected = example.parent / "bin" / "gxdiagnostics.so"
    if Path(library).resolve() == expected:
        return module.Producer(library, descriptor)
    # This is a private test-only fixture loader. Production Producer refuses
    # alternate libraries; no environment override exists in that binding.
    assert mode in ("pause", "throw"), "Alternate library is allowed only in the explicit private overlap fixture"
    producer = module.Producer(expected, descriptor)
    producer.close()
    fixture = ctypes.CDLL(library)
    for name in ("gxdiag_producer_attach_v1", "gxdiag_producer_emit_v1", "gxdiag_producer_close_v1"):
        old = getattr(producer.lib, name)
        new = getattr(fixture, name)
        new.argtypes, new.restype = old.argtypes, old.restype
    producer.lib = fixture
    error = ctypes.create_string_buffer(512)
    producer.attach_result = fixture.gxdiag_producer_attach_v1(descriptor.encode("ascii"), ctypes.byref(producer.handle), error, len(error))
    producer.attach_error = error.value.decode("utf-8", "replace")
    return producer

if mode == "death":
    root, directory = sys.argv[4:6]
    # Own/reap this fixture's orphaned helper even when the container's PID1
    # does not reap children like Debian init normally does.
    assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0
    host = subprocess.Popen(["tclsh", str(Path(__file__).with_name("producer_host.tcl")), root, directory], stdout=subprocess.PIPE, text=True)
    helper = None
    try:
        line = host.stdout.readline().strip().split()
        assert len(line) == 2, line
        helper, descriptor = int(line[0]), line[1]
        producer = attach(library, descriptor)
        assert producer.attach_result == 0, producer.attach_error
        host.kill()
        host.wait(timeout=3)
        page = Path("/dev/shm") / descriptor.split(":")[2].lstrip("/")
        deadline = time.monotonic() + 3
        gone = False
        while time.monotonic() < deadline:
            try:
                reaped, _ = os.waitpid(helper, os.WNOHANG)
                if reaped == helper:
                    gone = True
            except ChildProcessError:
                pass
            try:
                state = Path(f"/proc/{helper}/stat").read_text().split(")", 1)[1].split()[0]
                gone = state == "Z"
            except FileNotFoundError:
                gone = True
            if gone and not page.exists():
                break
            time.sleep(0.005)
        result = producer.emit(b"late", source="parent-death", process_id="unknown")
        producer.close()
        print(f"gone {int(gone)} shm_unlinked {int(not page.exists())} late_emit {result}", flush=True)
    finally:
        if host.poll() is None:
            host.kill()
            host.wait(timeout=3)
        if helper is not None:
            try:
                os.kill(helper, signal.SIGKILL)
            except ProcessLookupError:
                pass
            try:
                os.waitpid(helper, 0)
            except ChildProcessError:
                pass
    raise SystemExit(0)

if mode == "forge":
    endpoint = descriptor.split(":")[1]
    route = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    route.setblocking(False)
    route.connect("\0" + endpoint)
    route.send(struct.pack("=II", 0x47584431, 3) + b'"capture_pid":0,"pid":0')
    route.close()
    print("forged 1", flush=True)
    raise SystemExit(0)

producer = attach(library, descriptor)
if mode == "stale":
    print(f"attach {producer.attach_result}", flush=True)
    producer.close()
    raise SystemExit(0)
assert producer.attach_result == 0, producer.attach_error
origin = dict(source="external.fixture", module_id="fixture.module", viewer_id="fixture.viewer", job_id="fixture.job", api_id="fixture.api.v1", operation="child.stderr", process_id="unknown", stream="stderr", severity="error")
if mode == "binary":
    child = subprocess.Popen([sys.executable, "-c", "import os;os.write(1,b'stdout-unchanged');os.write(2,b'\\x00\\xff\\nUTF8\\xe2\\x98\\x83\\r\\n')"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    normal_stdout, stderr_bytes = child.communicate(timeout=3)
    assert normal_stdout == b"stdout-unchanged"
    origin["process_id"] = str(child.pid)
    code = producer.emit(stderr_bytes, **origin)
    print(f"attach {producer.attach_result} capture_pid {os.getpid()} source_pid {child.pid} result {code}", flush=True)
elif mode == "burst":
    accepted = dropped = 0
    start = time.monotonic()
    for _ in range(2000):
        code = producer.emit(b"x" * 32768, **origin)
        accepted += code == 0
        dropped += code == 2
        assert code in (0, 2), code
    print(f"accepted {accepted} dropped {dropped} elapsed_ms {int((time.monotonic()-start)*1000)}", flush=True)
elif mode == "hold":
    print("ready 1", flush=True)
    assert sys.stdin.readline().strip() == "emit"
    print(f"late_emit {producer.emit(b'late', **origin)}", flush=True)
elif mode == "throw":
    os.environ["GXTXT_DIAG_FIXTURE_EMIT_THROW"] = "1"
    print(f"failed_emit {producer.emit(b'fault', **origin)}", flush=True)
elif mode == "pause":
    os.environ["GXTXT_DIAG_FIXTURE_EMIT_PAUSE"] = "1"
    print(f"ready {os.getpid()}", flush=True)
    print(f"late_emit {producer.emit(b'late', **origin)}", flush=True)
else:
    raise AssertionError(mode)
producer.close()
