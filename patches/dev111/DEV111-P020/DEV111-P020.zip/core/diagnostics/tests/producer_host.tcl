# SPDX-License-Identifier: GPL-3.0-or-later
# Private subprocess lifetime fixture, never a production launcher.
lassign $argv root directory
source [file join $root core tcl stderr_diagnostics_v1.tcl]
::GX::stderrDiagnostics start [dict create log_directory $directory]
for {set n 0} {$n<2000} {incr n} {
    set status [::GX::stderrDiagnostics status]
    if {[dict get $status state] eq {running}} {break}
    if {[dict get $status state] eq {error}} {error [dict get $status last_error]}
    after 1
    update
}
puts "[dict get $status helper_pid] [dict get [::GX::StderrDiagnostics::producerDescriptor] descriptor]"
flush stdout
vwait forever
