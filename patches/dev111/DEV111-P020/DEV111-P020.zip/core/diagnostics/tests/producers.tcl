# SPDX-License-Identifier: GPL-3.0-or-later
set root [file normalize [lindex $argv 0]]
source [file join $root core tcl stderr_diagnostics_v1.tcl]
set worker [file join $root core diagnostics tests producer_worker.py]
set fixture [file normalize [file join $root .. fixture-producers-[pid]]]
proc assert {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc waitFor {expression {milliseconds 5000}} {
    set until [expr {[clock milliseconds]+$milliseconds}]
    while {![uplevel 1 [list expr $expression]]} {
        if {[clock milliseconds]>$until} {error "Timed out: $expression; status=[::GX::stderrDiagnostics status]"}
        after 2
        update
    }
}
try {
    assert {[dict get [::GX::StderrDiagnostics::producerDescriptor] descriptor] eq {}} {OFF must not expose a route}
    assert {![llength [info commands ::GX::StderrDiagnostics::_native]]} {OFF route query loaded native code}
    ::GX::stderrDiagnostics start [dict create log_directory $fixture ring_bytes 65536]
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    set capability [::GX::StderrDiagnostics::producerDescriptor]
    set descriptor [dict get $capability descriptor]
    set library [dict get $capability library]
    set binary [exec python3 $worker binary $library $descriptor]
    assert {[dict get $binary attach]==0 && [dict get $binary result]==0} "External attach/emit failed: $binary"
    waitFor {[dict get [::GX::stderrDiagnostics status] written_records]==1}
    set token [::GX::stderrDiagnostics read]
    set receipt [::GX::stderrDiagnostics request $token]
    while {[dict get $receipt state] eq {pending}} {after 2;update;set receipt [::GX::stderrDiagnostics request $token]}
    assert {[dict get $receipt state] eq {done}} "External reader error: $receipt"
    set record [lindex [dict get $receipt result records] 0]
    assert {[dict get $record capture_pid]==[dict get $binary capture_pid] && [dict get $record capture_pid]!=[pid]} {External capture attributed to GUI PID}
    assert {[dict get $record origin process_id] eq [dict get $binary source_pid]} {Captured child PID was replaced with capture PID}
    assert {[binary encode hex [dict get $record payload]] eq {00ff0a55544638e298830d0a}} {External binary bytes corrupted}
    assert {[dict get [::GX::stderrDiagnostics status] producer_attachments]==1} {Shared external attachment count missing}

    exec python3 $worker forge $library $descriptor
    waitFor {[dict get [::GX::stderrDiagnostics status] ipc_rejected_records]==1}
    assert {[dict get [::GX::stderrDiagnostics status] state] eq {running}} {Invalid producer packet stopped collector}

    set helper [dict get [::GX::stderrDiagnostics status] helper_pid]
    exec kill -STOP $helper
    set burst [exec python3 $worker burst $library $descriptor]
    assert {[dict get $burst dropped]>0 && [dict get $burst elapsed_ms]<3000} "External transport blocked: $burst"
    assert {[dict get [::GX::stderrDiagnostics status] transport_dropped_records]==[dict get $burst dropped]} {External drops were not globally shared}
    assert {[dict get [::GX::stderrDiagnostics status] transport_dropped_bytes]==32768*[dict get $burst dropped]} {External dropped-byte count incorrect}
    exec kill -CONT $helper
    waitFor {[dict get [::GX::stderrDiagnostics status] pending_records]==0}

    set hold [open |[list python3 $worker hold $library $descriptor] r+]
    fconfigure $hold -buffering line
    assert {[gets $hold] eq {ready 1}} {Persistent producer did not attach}
    ::GX::stderrDiagnostics stop
    waitFor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
    puts $hold emit
    assert {[gets $hold] eq {late_emit 1}} {Existing external handle did not become OFF}
    close $hold
    assert {[dict get [::GX::StderrDiagnostics::producerDescriptor] descriptor] eq {}} {OFF retained producer route}
    set stale [exec python3 $worker stale $library $descriptor]
    assert {[dict get $stale attach]==1} {Stale descriptor attached after stop}
    set malformed [exec python3 $worker stale $library {gxdiag1:wrong:/../../unsafe:123}]
    assert {[dict get $malformed attach]==5} {Malformed capability was not refused}

    set death [exec python3 $worker death $library unused $root ${fixture}-death]
    assert {[dict get $death gone] && [dict get $death shm_unlinked] && [dict get $death late_emit]==1} "GUI-death cleanup failed: $death"
    puts "PASS diagnostics external producers: exact binary/PID metadata, global counters, credential rejection,2000 saturated emits/[dict get $burst elapsed_ms]ms, stale route OFF, GUI-death helper/shm cleanup"
} finally {
    catch {::GX::stderrDiagnostics stop}
    after 10
    catch {::GX::stderrDiagnostics status}
    file delete -force $fixture ${fixture}-death
}
