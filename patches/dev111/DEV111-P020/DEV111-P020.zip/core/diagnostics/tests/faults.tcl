# SPDX-License-Identifier: GPL-3.0-or-later
set root [file normalize [lindex $argv 0]]
source [file join $root core tcl stderr_diagnostics_v1.tcl]
load [file normalize [lindex $argv 1]] Gxdiagnostics
if {![dict get [::GX::StderrDiagnostics::_native info] private_fixture_build]} {error {Fault tests require an explicitly compiled private fixture build}}
set fixture [file normalize [file join $root .. fixture-faults-[pid]]]
proc assert {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc waitFor {expression {milliseconds 5000}} {
    set until [expr {[clock milliseconds]+$milliseconds}]
    while {![uplevel 1 [list expr $expression]]} {
        if {[clock milliseconds]>$until} {error "Timed out: $expression; status=[::GX::stderrDiagnostics status]"}
        after 2
        update
    }
}
proc startFixture {name} {
    global fixture
    ::GX::stderrDiagnostics configure [dict create log_directory ${fixture}-$name max_file_bytes 10485760 max_files 3 ring_bytes 65536]
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
}
proc stopFixture {} {
    ::GX::stderrDiagnostics stop
    waitFor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
    assert {[dict get [::GX::stderrDiagnostics status] state] eq {off}} {Explicit stop must return OFF after failure}
}
try {
    startFixture transport
    set helper [dict get [::GX::stderrDiagnostics status] helper_pid]
    exec kill -STOP $helper
    set payload [string repeat x 32768]
    set started [clock milliseconds]
    for {set n 0} {$n<2000} {incr n} {::GX::stderrDiagnostics emit {source transport-fixture} $payload}
    set elapsed [expr {[clock milliseconds]-$started}]
    assert {$elapsed<3000} "Saturated producer blocked (${elapsed}ms)"
    assert {[dict get [::GX::stderrDiagnostics status] transport_dropped_records]>0} {Saturated UNIX transport did not count drops}
    assert {[dict get [::GX::stderrDiagnostics status] transport_dropped_bytes]>0} {Transport byte loss missing}
    exec kill -CONT $helper
    waitFor {[dict get [::GX::stderrDiagnostics status] pending_records]==0}
    stopFixture

    set ::env(GXTXT_DIAG_FIXTURE_WRITER_DELAY_MS) 150
    startFixture ring
    unset ::env(GXTXT_DIAG_FIXTURE_WRITER_DELAY_MS)
    set payload [string repeat y 8192]
    for {set n 0} {$n<150} {incr n} {::GX::stderrDiagnostics emit {source slow-disk-fixture} $payload;after 1;update}
    waitFor {[dict get [::GX::stderrDiagnostics status] ring_dropped_records]>0}
    assert {[dict get [::GX::stderrDiagnostics status] queue_bytes]<=65536} {Ring exceeded configured RAM bound}
    set stopStart [clock milliseconds]
    stopFixture
    assert {[clock milliseconds]-$stopStart<250} {Shutdown waited for slow disk}
    assert {[dict get [::GX::stderrDiagnostics status] interrupted_records]>0} {Shutdown pending loss was not counted}

    set ::env(GXTXT_DIAG_FIXTURE_FAIL_AFTER_RECORDS) 0
    startFixture full
    unset ::env(GXTXT_DIAG_FIXTURE_FAIL_AFTER_RECORDS)
    ::GX::stderrDiagnostics emit {source full-disk-fixture} data
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
    assert {[dict get [::GX::stderrDiagnostics status] disk_dropped_records]>0} {Disk failure record loss missing}
    assert {[string match *No*space* [dict get [::GX::stderrDiagnostics status] last_error]]} {Disk failure message not preserved}
    stopFixture

    set ::env(GXTXT_DIAG_FIXTURE_BROKEN_IPC) 1
    startFixture ipc
    unset ::env(GXTXT_DIAG_FIXTURE_BROKEN_IPC)
    set result [::GX::stderrDiagnostics emit {source broken-ipc-fixture} bytes]
    assert {[dict get $result reason] eq {broken_ipc}} {Broken IPC did not report failure}
    assert {[dict get [::GX::stderrDiagnostics status] last_error] ne {}} {Broken IPC error not exposed}
    stopFixture

    startFixture overlap
    set descriptor [dict get [::GX::StderrDiagnostics::producerDescriptor] descriptor]
    set worker [file join $root core diagnostics tests producer_worker.py]
    set overlap [open |[list python3 $worker pause [file normalize [lindex $argv 1]] $descriptor] r+]
    fconfigure $overlap -buffering line
    lassign [gets $overlap] ready producerPid
    assert {$ready eq {ready}} {Paused fixture producer did not attach}
    waitFor {[string match T* [string trim [exec ps -o stat= -p $producerPid]]]}
    set beforeOverlapDrops [dict get [::GX::stderrDiagnostics status] transport_dropped_records]
    stopFixture
    assert {[dict get [::GX::stderrDiagnostics status] retired_status_pages]==1} {Overlapping producer status was finalized before call completion}
    assert {[dict get [::GX::stderrDiagnostics status] queue_bytes]==0 && [dict get [::GX::stderrDiagnostics status] capture_ipc]==0} {Overlap retained a capture queue or route}
    exec kill -CONT $producerPid
    assert {[gets $overlap] eq {late_emit 4}} {Overlapping stopped-generation send was not reported broken}
    close $overlap
    waitFor {[dict get [::GX::stderrDiagnostics status] retired_status_pages]==0}
    assert {[dict get [::GX::stderrDiagnostics status] transport_dropped_records]==$beforeOverlapDrops+1} {Late producer loss missing from global lifetime counters}

    startFixture native-exception
    set descriptor [dict get [::GX::StderrDiagnostics::producerDescriptor] descriptor]
    set beforeExceptionDrops [dict get [::GX::stderrDiagnostics status] transport_dropped_records]
    set thrown [exec python3 $worker throw [file normalize [lindex $argv 1]] $descriptor]
    assert {[dict get $thrown failed_emit]==5} {Native producer exception escaped the C ABI}
    set failed [::GX::stderrDiagnostics status]
    assert {[dict get $failed producer_failed_records]==1 && [dict get $failed producer_failed_bytes]==5} {Native exception failed to count event/payload loss}
    assert {[dict get $failed transport_dropped_records]==$beforeExceptionDrops+1} {Native exception omitted its global transport drop}
    assert {[dict get $failed state] eq {running}} {Native producer exception stopped healthy collector}
    stopFixture

    file mkdir ${fixture}-insecure
    file attributes ${fixture}-insecure -permissions 0777
    ::GX::stderrDiagnostics configure [dict create log_directory ${fixture}-insecure]
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
    assert {![llength [glob -nocomplain -directory ${fixture}-insecure *]]} {Insecure directory was written}
    ::GX::stderrDiagnostics configure [dict create log_directory ${fixture}-corrected]
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    stopFixture

    file mkdir ${fixture}-symlink
    file attributes ${fixture}-symlink -permissions 0700
    set sentinel [open ${fixture}-sentinel w];puts -nonewline $sentinel do-not-change;close $sentinel
    file link -symbolic [file join ${fixture}-symlink stderr-diagnostics.current.jsonl] ${fixture}-sentinel
    ::GX::stderrDiagnostics configure [dict create log_directory ${fixture}-symlink]
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
    set sentinel [open ${fixture}-sentinel r];set bytes [read $sentinel];close $sentinel
    assert {$bytes eq {do-not-change}} {Symlink target was modified}
    stopFixture

    startFixture recovery
    ::GX::stderrDiagnostics emit {source recovery-fixture} complete-record
    waitFor {[dict get [::GX::stderrDiagnostics status] pending_records]==0}
    stopFixture
    set tail [open [file join ${fixture}-recovery stderr-diagnostics.current.jsonl] a];puts -nonewline $tail partial-crash-record;close $tail
    ::GX::stderrDiagnostics start
    waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
    assert {[dict get [::GX::stderrDiagnostics status] recovered_tail_bytes]==20} {Crash-tail recovery did not report exact truncation}
    stopFixture
    puts "PASS diagnostics private faults: saturated IPC ${elapsed}ms/2000events, bounded ring/slow disk, stop loss, ENOSPC, broken IPC, external overlap/native exception counts, insecure permissions, symlink safety, crash-tail recovery"
} finally {
    catch {stopFixture}
    foreach key {GXTXT_DIAG_FIXTURE_WRITER_DELAY_MS GXTXT_DIAG_FIXTURE_FAIL_AFTER_RECORDS GXTXT_DIAG_FIXTURE_BROKEN_IPC} {unset -nocomplain ::env($key)}
    foreach path [glob -nocomplain ${fixture}-*] {file delete -force $path}
}
