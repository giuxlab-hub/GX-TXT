#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Explicit guarded P020 rollback. No Session/preferences/log cleanup."""
from pathlib import Path
import hashlib,json,shutil,sys
root=Path(sys.argv[1]).resolve()
notes=root/'patch_notes/DEV111-P020'
rows=json.loads((notes/'FILES.json').read_text())['changed_files']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for row in rows:
    p=root/row['path']
    if not p.resolve().is_relative_to(root) or p.is_symlink() or not p.is_file() or sha(p)!=row['after_sha256']:
        raise SystemExit('Refusing divergent postimage: '+row['path'])
    if row['before_sha256'] is not None:
        prior=notes/'rollback-preimages'/row['path']
        if not prior.is_file() or prior.is_symlink() or sha(prior)!=row['before_sha256']:
            raise SystemExit('Invalid rollback preimage: '+row['path'])
for row in rows:
    p=root/row['path']
    if row['before_sha256'] is None:p.unlink()
    else:shutil.copy2(notes/'rollback-preimages'/row['path'],p)
print('Exact P019 product preimages restored; evidence retained. Restart required.')
