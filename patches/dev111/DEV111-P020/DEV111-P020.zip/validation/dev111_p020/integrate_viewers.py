#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import hashlib,json,pathlib,stat,sys,zipfile,subprocess
root=pathlib.Path(sys.argv[1]).resolve();report=json.loads(pathlib.Path(sys.argv[2]).read_text())
assert str(root).startswith('/srv/gxtxt/agents/scratch/DEV111-P020-')
allowed={'viewer.test_cad_1','viewer.test_cad_2','viewer.stderr_diagnostics'}
for module in report['modules']:
 name=module['module_id'];assert name in allowed
 archive=pathlib.Path(module['package']);assert hashlib.sha256(archive.read_bytes()).hexdigest()==module['package_sha256']
 dest=root/'plugins/modules'/name
 if dest.exists():
  assert len(sys.argv)==4 and sys.argv[3]=='--replace-p020',dest
  baseline=subprocess.run(['git','-C',str(root),'cat-file','-e','248cd71edaaae1b76810528de69f6eed23fb482c:plugins/modules/'+name+'/module.ini'],capture_output=True)
  assert baseline.returncode!=0,'Replacement is limited to newly introduced P020 modules'
  for line in (dest/'SHA256SUMS.txt').read_text().splitlines():
   sha,member=line.split(None,1);member=member.lstrip('* ')
   assert hashlib.sha256((dest/member).read_bytes()).hexdigest()==sha,('Preserve modified candidate file',member)
 with zipfile.ZipFile(archive) as z:
  names=z.namelist();assert len(names)==len(set(names))
  for entry in z.infolist():
   rel=pathlib.PurePosixPath(entry.filename)
   assert not rel.is_absolute() and '..' not in rel.parts and not stat.S_ISLNK(entry.external_attr>>16),entry.filename
  for line in z.read('SHA256SUMS.txt').decode().splitlines():
   sha,member=line.split(None,1);member=member.lstrip('* ');assert hashlib.sha256(z.read(member)).hexdigest()==sha,(name,member)
  dest.mkdir(exist_ok=True);z.extractall(dest)
 print('Integrated new ordinary module',name,archive.stat().st_size,module['package_sha256'])
