#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""New-only P020 release and archive/expanded mirrors. Never activate."""
from pathlib import Path
import hashlib,json,shutil,sys,zipfile
stage,release,mirrors=map(lambda p:Path(p).resolve(),sys.argv[1:])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=stage/'DEV111-P020.zip'
proof=json.loads((stage/'VERIFICATION.json').read_text())
assert proof['status']=='PASS' and proof['zip_sha256']==sha(archive)
assert not proof['installed']
packages=json.loads((stage/'VIEWER_PACKAGES.json').read_text())['modules']
ma=mirrors/'framework/archives/patches'/archive.name
expanded=mirrors/'framework/expanded/patches/DEV111-P020'
targets=[release,ma,Path(str(ma)+'.sha256'),expanded]
for row in packages:
    package=Path(row['package']);assert sha(package)==row['package_sha256']
    name=package.stem+'_dev111_p020'
    targets.extend([mirrors/'external_plugins/archives'/(name+'.zip'),mirrors/'external_plugins/archives'/(name+'.zip.sha256'),mirrors/'external_plugins/expanded'/name])
assert all(not p.exists() for p in targets),'Refusing existing deposit/mirror output'
def unpack(zpath,dest):
    with zipfile.ZipFile(zpath) as z:
        assert z.testzip() is None
        for entry in z.infolist():
            rel=Path(entry.filename)
            assert not rel.is_absolute() and '..' not in rel.parts
        dest.mkdir(parents=True)
        z.extractall(dest)
        for entry in z.infolist():
            if not entry.is_dir():
                p=dest/entry.filename
                assert hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256(z.read(entry.filename)).hexdigest()
                p.chmod((entry.external_attr>>16)&0o777 or 0o644)
release.mkdir(parents=True)
for name in ['DEV111-P020.zip','DEV111-P020.zip.sha256','VERIFICATION.json','VIEWER_PACKAGES.json']:
    shutil.copy2(stage/name,release/name)
with zipfile.ZipFile(archive) as z:
    for name in ['README.md','FINAL_HANDOFF.md','VALIDATION_REPORT.md','PERFORMANCE_REPORT.md','KNOWN_LIMITATIONS.md','FILES.json','SOURCE.json']:
        (release/name).write_bytes(z.read('patch_notes/DEV111-P020/'+name))
ma.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(archive,ma);shutil.copy2(stage/'DEV111-P020.zip.sha256',Path(str(ma)+'.sha256'))
unpack(archive,expanded)
delivered=[]
for row in packages:
    package=Path(row['package']);name=package.stem+'_dev111_p020'
    out=release/'viewer_packages'/package.name;out.parent.mkdir(exist_ok=True);shutil.copy2(package,out)
    out.with_name(out.name+'.sha256').write_text(f'{sha(out)}  {out.name}\n')
    mirror=mirrors/'external_plugins/archives'/(name+'.zip')
    mirror.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(package,mirror)
    mirror.with_name(mirror.name+'.sha256').write_text(f'{sha(mirror)}  {mirror.name}\n')
    unpack(package,mirrors/'external_plugins/expanded'/name)
    assert sha(out)==row['package_sha256']==sha(mirror)
    delivered.append(dict(module_id=row['module_id'],package=str(out),sha256=sha(out),mirror=str(mirror)))
assert sha(ma)==proof['zip_sha256']==sha(release/archive.name)
result=dict(status='PASS',release=str(release),archive=str(release/archive.name),sha256=sha(archive),bytes=archive.stat().st_size,source_commit=proof['source_commit'],framework_archive=str(ma),framework_expanded=str(expanded),viewer_packages=delivered,installed=False,user_vnc_acceptance='OPEN')
(release/'DEPOSIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
