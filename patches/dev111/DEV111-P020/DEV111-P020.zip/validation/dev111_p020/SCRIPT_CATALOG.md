# DEV111-P020 MAIN1 preparation and delivery helpers

`prepare.py P019_FRAMEWORK NEW_P020_MAIN NEW_MAIN2_ROOT`: verify exact delivered
P019 ZIP/hash/size, all425 manifest source postimages, native pins and local commit;
record full source inventory and protected Git/TODO identity; create a proper
isolated local Git worktree at the exact verified commit with a new P020 branch.
Verify separate per-worktree HEAD/admin and original P019 HEAD/status unchanged.
Create MAIN2 assigned scratch root and frozen P019 source snapshot under it, without
copying .git pointers. New destinations only; no remote access, install, scientific
Session/Project mutation or TODO edits. Does not run GUI or modify old artifacts.

`build_native3d.py FRAMEWORK OUTPUT`: P020 targeted C++17 Native3D Tcl adapter build against that framework's existing gx3de library and installed Tcl headers. Writes only the explicit OUTPUT file/directory and its .build.json command/source/binary hashes; no install, full VTK rebuild, test Session, or old archive mutation. Caller explicitly copies reviewed output into isolated candidate.

`core_catalog_smoke.py FRAMEWORK NEW_OUTPUT`: P020 headless Tcl load/public API catalog smoke, private XDG config/data/cache/state and HOME-independent GX-TXT paths; captures stdout/stderr/exit code and parsed metadata. Writes only NEW_OUTPUT. No GUI qualification, live Session or installation.

`sdk_contract.py FRAMEWORK NEW_OUTPUT [REFERENCE_FRAMEWORK]`: P020 additive SDK C++ compile and exact reference artifact ABI admission, Python syntax and typed broker positive/negative checks. Supply verified P019 as REFERENCE_FRAMEWORK for old-artifact compatibility. Uses no Curve Workbench or Tk display. Writes compiler output and JSON receipts only under NEW_OUTPUT. Not real GUI evidence.

`cpp_support_catalog.py FRAMEWORK [--check]`: adapted P020 generator from the historical version-pinned integrated-next generator; validates a scratch-only explicit framework, regenerates/checks docs/api/CPP_SUPPORT_CATALOG.md from exact current SDK/policy/build/runtime sources. Writes that documentation only (no builds, deployment, Session or historical source writes). Never run the original dev109-pinned helper unchanged.

`integrate_viewers.py FRAMEWORK AUTHOR_DELIVERY_JSON`: verify package hashes/member paths/internal checksums and extract only the three new P020 ordinary Viewer modules into the isolated P020 framework. New module destinations only; does not install/activate plugins, change old modules, or write release/user data.

`bridge_contract.tcl FRAMEWORK NEW_OUTPUT`: isolated Tk/Core integration contract check for the real asynchronous Tcl background-error observer/restoration and bounded status coalescing while GUI work is occupied. Requires xvfb-run; writes only NEW_OUTPUT and a private collector directory, stops service/cleans widgets. This is not Viewer real-GUI acceptance.

`integrate_viewers.py ... --replace-p020`: permits reviewed corrections only for module IDs absent from authoritative P019, after verifying every current payload checksum. Refuses replacement of P019 modules or unreviewed edited candidate files. Still private candidate-only, no activation.
`package.py P019_FRAMEWORK P020_FRAMEWORK NEW_STAGE TASK_ROOT`: final-only incremental overlay. Requires independent qualification receipt and clean committed source; rechecks protected baseline/archive/Git/TODO, all changed module inventories, source/binary pins, exact ZIP postimages, fresh full-P019 unzip/Core catalog/old SDK admission and guarded rollback. Creates new stage only; no installation or historical mutation. Adapted explicitly for P020; never run old version-pinned package helpers unchanged.
`rollback.py FRAMEWORK`: explicitly requested P020 product rollback only, with global postimage/preimage guards before any mutation. Packaging invokes it only in its new private apply-verification copy. Never automatically run against an installation.
`deposit.py STAGE NEW_RELEASE GXTXT_MIRROR_ROOT`: final verified P020 new-only deposit plus matching framework archive/expanded mirrors, four ordinary Viewer package archive/expanded pairs. Refuses any existing output and validates bytes/member paths. Does not change CURRENT activation or prior releases, Sessions or TODO.
`reconcile_workbench_package.py FRAMEWORK AUTHOR_ZIP NEW_OUTPUT`: preserve the one P019 historical original-build receipt in the updated 3D module instead of deleting it. Verify all authored members against the candidate, use the existing standard Builder package writer to include the exact preserved receipt, and copy only the resulting complete checksum inventory back into the isolated candidate. Native/design/source/build bytes stay unchanged. Produces a new normal package and reconciliation receipt; no installation or prior-package mutation.
`collect_evidence.py WHITELIST_JSON NEW_OUTPUT`: copy only explicitly reviewed, hash-pinned synthetic MAIN2 evidence files from the whitelist's directory, at most64MiB total. Reject symlinks, traversal, Session/cache/framework/private/withdrawn support paths. New output only; never recursively harvest test data or write back to validator/source/user trees. Not a test execution or GUI acceptance claim.
`directory_contract.tcl FRAMEWORK NEW_OUTPUT [expect_error]`: focused P020 default-directory regression. Uses the public standalone diagnostics API, verifies OFF creates no nested paths and ON creates the missing private hierarchy; checks permissions and cleanup. Optional expect_error records the original missing-parent failure. Writes only NEW_OUTPUT, its private helper/logs; no GUI acceptance claim or installed/user/release change.
`build_diagnostics.py FRAMEWORK NEW_OUTPUT`: targeted production C++17 adapter/helper CMake Release build, private fixtures explicitly OFF, matching source/binary/command receipt. Writes only NEW_OUTPUT; caller reviews/copies artifacts into isolated candidate. No installed/previous release or scientific data mutation.
