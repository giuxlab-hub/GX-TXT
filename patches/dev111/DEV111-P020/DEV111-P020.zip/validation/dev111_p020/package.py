#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Verified P019-to-P020 incremental overlay and private fresh-apply proof."""
from pathlib import Path
import configparser,hashlib,json,os,shutil,subprocess,sys,zipfile
base,source,stage,task=map(lambda p:Path(p).resolve(),sys.argv[1:])
assert not stage.exists() and base!=source
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
def inventory(root):
    return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts and '__pycache__' not in p.parts}
pins=json.loads((task/'BASELINE.json').read_text())
assert git(source,'status','--porcelain')=='','Commit reviewed source before packaging'
assert not git(source,'remote')
assert git(source,'rev-parse','--absolute-git-dir')==pins['own_git_dir']
assert git(source,'rev-parse','--path-format=absolute','--git-common-dir')==pins['common_git_dir']
before=inventory(base);after=inventory(source)
assert before==pins['files'],'Protected P019 filesystem changed'
archive=Path(pins['archive'])
assert sha(archive)==pins['archive_sha256'] and archive.stat().st_size==pins['archive_bytes']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    old_rows=json.loads(z.read('patch_notes/DEV111-P019/FILES.json'))['changed_files']
    for row in old_rows:assert before[row['path']]==row['after_sha256']
    for name in z.namelist():
        if name in before:assert z.read(name)==(base/name).read_bytes(),name
for name,expected in pins['protected'].items():
    tree=Path('/srv/gxtxt/agents/scratch/DEV111-'+name+'-MAIN/framework')
    for key,args in [('head',('rev-parse','HEAD')),('status',('status','--porcelain')),('git_dir',('rev-parse','--absolute-git-dir'))]:
        assert git(tree,*args)==expected[key],(name,key)
for path,expected in pins['todo_pins'].items():assert sha(Path(path))==expected['sha256'],path
assert not(set(before)-set(after)),'Unexpected product deletions'
changes=sorted(p for p in after if before.get(p)!=after[p])
assert changes
allowed=('core/','app/','docs/api/','docs/development/DEV111-P020/','validation/dev111_p020/','validation/p020_cad/','plugins/modules/')
for name in changes:
    assert name in {'gxtxt_pipeline.tcl','SCRIPT_CATALOG.md'} or name.startswith(allowed),name
    assert 'TODO' not in name.upper() and not(source/name).is_symlink(),name
    assert not any(p in Path(name).parts for p in ['Sessions','__pycache__','.git','REAL-FIXTURE','support-diagnostics-withdrawn']),name
docs=source/'docs/development/DEV111-P020'
qualified=json.loads((docs/'FINAL_QUALIFICATION.json').read_text())
assert qualified['status']=='QUALIFIED_FOR_USER_ACCEPTANCE'
for path,digest in qualified['final_runtime_pins'].items():assert after[path]==digest,('Qualification source changed',path)
for name,digest in before.items():
    if name.startswith(('core/native2d/','core/history/','plugins/modules/viewer.curve_workbench/')):
        assert after[name]==digest,('Protected accepted implementation changed',name)
for path,digest in json.loads((docs/'BUILD_IDENTITY.json').read_text())['files'].items():assert after[path]==digest,path
modules=['viewer.test_cad_1','viewer.test_cad_2','viewer.stderr_diagnostics','viewer.scientific_3d_workbench','viewer.3d_workbench']
for ident in modules:
    root=source/'plugins/modules'/ident
    listed={}
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        digest,name=line.split('  ',1)
        assert not name.startswith('/') and '..' not in Path(name).parts
        assert sha(root/name)==digest,(ident,name)
        listed[name]=digest
    expected={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name not in {'SHA256SUMS','SHA256SUMS.txt'}}
    assert set(listed)==expected,('Module inventory',ident)
    if(root/'SHA256SUMS').exists():assert(root/'SHA256SUMS').read_bytes()==(root/'SHA256SUMS.txt').read_bytes()
exports=json.loads((task/'VIEWER_PACKAGES.json').read_text())
assert {row['module_id'] for row in exports['modules']}==set(modules)-{'viewer.3d_workbench'}
for row in exports['modules']:
    package=Path(row['package']);assert sha(package)==row['package_sha256']
    root=source/'plugins/modules'/row['module_id']
    with zipfile.ZipFile(package) as z:
        assert z.testzip() is None
        names=set(z.namelist())
        assert names=={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
        for name in names:assert z.read(name)==(root/name).read_bytes(),(row['module_id'],name)
stage.mkdir();payload=stage/'payload';payload.mkdir();notes=payload/'patch_notes/DEV111-P020';notes.mkdir(parents=True)
shutil.copy2(task/'VIEWER_PACKAGES.json',stage/'VIEWER_PACKAGES.json')
rows=[]
for name in changes:
    target=payload/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source/name,target)
    prior=before.get(name)
    rows.append(dict(path=name,action='replace' if prior else 'add',before_sha256=prior,after_sha256=after[name],bytes=(source/name).stat().st_size,mode=oct((source/name).stat().st_mode&0o777)))
    if prior:
        backup=notes/'rollback-preimages'/name;backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/name,backup)
commit=git(source,'rev-parse','HEAD')
manifest=dict(patch='DEV111-P020',baseline_commit=pins['baseline_commit'],baseline_archive_sha256=pins['archive_sha256'],source_commit=commit,changed_files=rows)
(notes/'FILES.json').write_text(json.dumps(manifest,indent=2)+'\n')
(notes/'CHANGED_FILES.txt').write_text('\n'.join(changes)+'\n')
(notes/'SOURCE.json').write_text(json.dumps({'commit':commit,'baseline_commit':pins['baseline_commit'],'installed':False,'user_vnc_acceptance':'OPEN'},indent=2)+'\n')
shutil.copy2(source/'validation/dev111_p020/rollback.py',notes/'rollback.py')
for name in ['README.md','FINAL_HANDOFF.md','VALIDATION_REPORT.md','PERFORMANCE_REPORT.md','KNOWN_LIMITATIONS.md']:
    shutil.copy2(docs/name,notes/name)
(notes/'PAYLOAD_SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(payload).as_posix()}\n' for p in sorted(payload.rglob('*')) if p.is_file()))
zpath=stage/'DEV111-P020.zip'
with zipfile.ZipFile(zpath,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(payload.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(payload).as_posix())
(stage/'DEV111-P020.zip.sha256').write_text(f'{sha(zpath)}  {zpath.name}\n')
# Real unzip preserves executable modes like the documented installation command.
apply=stage/'fresh-p019-apply'
shutil.copytree(base,apply,ignore=shutil.ignore_patterns('.git','__pycache__'))
subprocess.run(['unzip','-oq',str(zpath),'-d',str(apply)],check=True)
with zipfile.ZipFile(zpath) as z:
    assert z.testzip() is None
    for member in z.infolist():assert not member.filename.startswith('/') and '..' not in Path(member.filename).parts
for row in rows:assert sha(apply/row['path'])==row['after_sha256'],row['path']
assert os.access(apply/'core/diagnostics/bin/gxtxt-diagnostics-helper',os.X_OK)
observed=inventory(apply)
for name,digest in after.items():assert observed[name]==digest,('Unzip divergence',name)
subprocess.run([sys.executable,str(apply/'validation/dev111_p020/core_catalog_smoke.py'),str(apply),str(stage/'fresh-startup')],check=True)
subprocess.run([sys.executable,str(apply/'validation/dev111_p020/sdk_contract.py'),str(apply),str(stage/'fresh-sdk'),str(base)],check=True)
subprocess.run([sys.executable,str(apply/'patch_notes/DEV111-P020/rollback.py'),str(apply)],check=True)
for row in rows:
    p=apply/row['path']
    assert (sha(p)==row['before_sha256']) if row['before_sha256'] else not p.exists(),row['path']
for name,digest in before.items():assert sha(apply/name)==digest,('Rollback divergence',name)
result=dict(status='PASS',patch='DEV111-P020',source_commit=commit,zip_sha256=sha(zpath),zip_bytes=zpath.stat().st_size,changed_files=len(rows),unchanged_files=len(after)-len(rows),baseline_files_verified=len(before),p019_manifest_postimages_verified=len(old_rows),protected_git_filesystems_todo_unchanged=True,fresh_full_p019_unzip_postimages='PASS',fresh_core_catalog='PASS',old_artifact_sdk_admission='PASS',guarded_full_rollback='PASS',module_checksum_inventories=modules,native_source_binary_identity='BUILD_IDENTITY.json',installed=False,user_vnc_acceptance='OPEN')
(stage/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
