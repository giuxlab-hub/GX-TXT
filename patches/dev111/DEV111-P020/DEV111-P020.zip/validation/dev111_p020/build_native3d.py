#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]).resolve(); out=pathlib.Path(sys.argv[2]).resolve()
out.parent.mkdir(parents=True,exist_ok=True)
src=root/'core/native3d/gx3de_viewer_tcl.cpp'
cmd=['c++','-std=c++17','-O2','-fPIC','-shared','-I/usr/include/tcl8.6','-I'+str(root/'core/native3d/include'),str(src),'-L'+str(root/'core/native3d/lib'),'-lgx3de','-ltcl8.6','-Wl,-rpath,$ORIGIN/../lib','-o',str(out)]
subprocess.run(cmd,check=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out.with_suffix(out.suffix+'.build.json').write_text(json.dumps({'command':cmd,'source':sha(src),'binary':sha(out)},indent=2)+'\n')
print(out,sha(out))
