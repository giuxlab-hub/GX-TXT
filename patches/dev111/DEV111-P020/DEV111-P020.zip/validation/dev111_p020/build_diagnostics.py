#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib,json,subprocess,sys
root,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
assert not out.exists() and out.is_relative_to('/srv/gxtxt/agents/scratch/DEV111-P020-MAIN')
out.mkdir(parents=True)
commands=[['cmake','-S',str(root/'core/diagnostics'),'-B',str(out/'build'),'-DCMAKE_BUILD_TYPE=Release','-DGXDIAG_PRIVATE_FIXTURES=OFF'],['cmake','--build',str(out/'build'),'-j2'],['cmake','--install',str(out/'build'),'--prefix',str(out/'install')]]
for i,command in enumerate(commands):
    result=subprocess.run(command,capture_output=True)
    (out/f'{i}.stdout').write_bytes(result.stdout);(out/f'{i}.stderr').write_bytes(result.stderr)
    if result.returncode:raise SystemExit(f'Build failed: {command}; see {out}')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources={p.relative_to(root).as_posix():sha(p) for p in(root/'core/diagnostics').iterdir() if p.is_file() and p.suffix in {'.cpp','.h','.txt'}}
bins={p.name:sha(p) for p in(out/'install/core/diagnostics/bin').iterdir()}
(out/'BUILD.json').write_text(json.dumps({'commands':commands,'sources':sources,'binaries':bins,'private_fixtures':False},indent=2)+'\n')
print(json.dumps(bins,indent=2))
