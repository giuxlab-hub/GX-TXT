#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Preserve the existing historical review receipt in the ordinary overlay."""
from pathlib import Path
import hashlib,importlib.util,json,sys,zipfile
framework,original,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
assert not out.exists() and str(framework).startswith('/srv/gxtxt/agents/scratch/DEV111-P020-MAIN/')
module=framework/'plugins/modules/viewer.scientific_3d_workbench'
sha=lambda b:hashlib.sha256(b).hexdigest()
with zipfile.ZipFile(original) as z:
    payload={name:z.read(name) for name in z.namelist()}
for name,raw in payload.items():assert (module/name).read_bytes()==raw,name
extra='review/original-build.json'
prior=Path('/srv/gxtxt/agents/scratch/DEV111-P019-MAIN/framework/plugins/modules/viewer.scientific_3d_workbench')/extra
assert extra not in payload and (module/extra).read_bytes()==prior.read_bytes()
payload[extra]=prior.read_bytes()
owner=framework/'plugins/modules/tool.script_module_builder/runtime/builder.py'
spec=importlib.util.spec_from_file_location('p020_standard_package_owner',owner)
builder=importlib.util.module_from_spec(spec);sys.modules[spec.name]=builder;spec.loader.exec_module(builder)
package,digest=builder.write_module_zip(payload,'viewer.scientific_3d_workbench','0.1.8',out)
with zipfile.ZipFile(package) as z:
    updated=z.read('SHA256SUMS.txt');(module/'SHA256SUMS.txt').write_bytes(updated)
    for name in z.namelist():assert (module/name).read_bytes()==z.read(name),name
receipt=dict(module_id='viewer.scientific_3d_workbench',package=str(package),package_sha256=digest,author_export=str(original),author_export_sha256=sha(original.read_bytes()),preserved_receipt_sha256=sha(prior.read_bytes()),changed_runtime_members=[],method='Existing standard Builder package owner; preserve historical P019 review receipt and regenerate complete checksum inventory')
(out/'RECONCILIATION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
