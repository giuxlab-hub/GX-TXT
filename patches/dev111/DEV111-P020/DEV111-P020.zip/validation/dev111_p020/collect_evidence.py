#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Copy only reviewed exact synthetic evidence, never a test Session tree."""
from pathlib import Path
import hashlib,json,shutil,sys
manifest,out=map(lambda p:Path(p).resolve(),sys.argv[1:])
root=manifest.parent
assert root.is_relative_to('/srv/gxtxt/agents/scratch/DEV111-P020-VALIDATION-MAIN2')
assert not out.exists()
rows=json.loads(manifest.read_text())['files'];total=0
for name,row in rows.items():
    rel=Path(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    assert not any(p.lower() in {'sessions','cache','framework','real-fixture','real_fixture','private','support-diagnostics-withdrawn'} or 'visibility' in p.lower() for p in rel.parts),name
    p=root/rel
    assert p.resolve().is_relative_to(root) and p.is_file() and not p.is_symlink(),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],name
    total+=p.stat().st_size
assert total<=64*1024*1024,'Use a smaller explicit evidence selection'
out.mkdir(parents=True)
for name in rows:
    target=out/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
shutil.copy2(manifest,out/'WHITELIST.json')
print(json.dumps({'status':'PASS','reviewed_files':len(rows),'bytes':total,'output':str(out)}))
