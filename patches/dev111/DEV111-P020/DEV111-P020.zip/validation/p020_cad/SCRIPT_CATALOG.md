# P020 CAD component checks

`component_smoke.tcl FRAMEWORK NEW_OUTPUT`: source the accepted P019 framework
plus P020 component files, create an isolated synthetic Session and actual Tk
component, and validate exact Native2D construction, oriented Native3D mapping,
bounded world projection, CORE History Undo/Redo and save/close/reopen. Requires
`xvfb-run -a tclsh`. Side effects are restricted to NEW_OUTPUT configuration,
cache, Session and native worker processes. No installed data or release writes.
Scope: P019 248cd71e plus these P020 component files and MAIN1's coherent
Native3D typed Sketch source/point/line adapter checkpoint. Also verifies actual
rendered frames, camera retention, control/dimension patches, all retained
topology families, preview cancellation, stale controls and invalid owner scopes.
NEW_OUTPUT must be absent. Evidence includes native3d_frame.tcldict and, when
ImageMagick import is available, component.png. Also checks active render close
and isolated worker retirement. All screenshots remain in NEW_OUTPUT.
The script normalizes both paths, applies cache/software configuration after
Session creation, and asserts Session/config/cache and actual rendered-frame
paths remain within NEW_OUTPUT. Earlier pre-Session cache configuration was
reset by current Session initialization; smoke14 and later are the corrected
isolation runs. Earlier receipts are preserved as qualified failure evidence.

`legacy_bridge_smoke.tcl FRAMEWORK NEW_OUTPUT`: one strict-private actual legacy
Workbench3D open/create/edit/close/reopen flow using its public Viewer loader,
guiCommand bridge, canonical parent History association and the same CORE
Sketch object. Copies the Workbench working plane/unit and verifies managed
child identity and exact definition persistence. Xvfb/Tcl, accepted P019 plus
P020 CORE/legacy source and MAIN1 native checkpoint. Side effects are limited to
NEW_OUTPUT Session/config/cache/logs and isolated renderer worker processes.
