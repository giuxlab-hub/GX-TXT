# SPDX-License-Identifier: GPL-3.0-or-later
import sys,os,time,json
from pathlib import Path
root,descriptor,out,label=sys.argv[1:]
sys.path.insert(0,str(Path(root)/"core/diagnostics"))
from producer_v1 import Producer
p=Producer(str(Path(root)/"core/diagnostics/bin/gxdiagnostics.so"),descriptor)
results=[];durations=[]
for i in range(128):
 payload=(label+"|"+str(i)+"\nline\0☃").encode()
 t=time.monotonic_ns();results.append(p.emit(payload,source=label,process_id=os.getpid(),operation=str(i),stream="stderr",severity="error"));durations.append(time.monotonic_ns()-t)
 time.sleep(.001)
p.close()
Path(out).write_text(json.dumps(dict(pid=os.getpid(),results=results,durations_ns=durations)))
