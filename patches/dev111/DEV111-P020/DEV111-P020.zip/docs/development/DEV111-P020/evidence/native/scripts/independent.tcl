# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv root out
if {[file exists $out]} {error {fresh output required}}
file mkdir $out
source [file join $root core tcl stderr_diagnostics_v1.tcl]
update
proc save {name value} {set f [open [file join $::out $name] w];puts $f $value;close $f}
proc ck {test label} {if {![uplevel 1 [list expr $test]]} {error "FAIL $label"};lappend ::checks $label;save checks.tcllist $::checks}
proc waitfor {test {ms 10000}} {set end [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]]} {if {[clock milliseconds]>$end} {error "timeout $test;[::GX::stderrDiagnostics status]"};after 2;update}}
proc done {token} {waitfor {[dict get [set result [::GX::stderrDiagnostics request $token]] state] ne {pending}};return $result}
proc resources {} {
 set fds {};foreach path [glob /proc/[pid]/fd/*] {if {![catch {file readlink $path} target]} {lappend fds [list [file tail $path] $target]}}
 set f [open /proc/[pid]/task/[pid]/children r];set children [read $f];close $f
 return [dict create tasks [glob /proc/[pid]/task/*] fds $fds timers [after info] children $children]
}
set checks {};set signals {}
try {
 set before [resources];set initial [::GX::stderrDiagnostics status]
 ck {[dict get $initial state] eq {off} && [dict get $initial capture_ipc]==0 && [dict get $initial writer]==0 && [dict get $initial queue_bytes]==0} default_off
 set defaults [dict get [::GX::stderrDiagnostics info] config_defaults]
 ck {$defaults eq {max_file_bytes 10485760 max_files 5 ring_bytes 8388608}} exact_defaults
 set logs [file join $out logs]
 ::GX::stderrDiagnostics configure [dict create log_directory $logs]
 for {set i 0} {$i<100} {incr i} {::GX::stderrDiagnostics status;::GX::stderrDiagnostics emit {} off}
 after 100;update
 set afterOff [resources];save off-resources.tcldict [dict create before $before after $afterOff status [::GX::stderrDiagnostics status]]
 ck {![file exists $logs] && ![llength [info commands ::GX::StderrDiagnostics::_native]]} off_unloaded_unwritten
 ck {[dict get $before tasks] eq [dict get $afterOff tasks] && [dict get $before timers] eq [dict get $afterOff timers] && [dict get $before children] eq [dict get $afterOff children]} off_no_tasks_timers_children
 foreach {key invalids} {max_file_bytes {4095 1073741825} max_files {0 101} ring_bytes {65535 67108865}} {
  foreach value $invalids {ck {[catch {::GX::stderrDiagnostics configure [dict create $key $value]}]} "reject_${key}_$value"}
 }
 ck {[dict get [::GX::stderrDiagnostics status] config max_files]==5} invalid_config_atomic
 ::GX::stderrDiagnostics start
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
 set result [::GX::stderrDiagnostics emit {} [binary format H* 000a0dfffe]]
 ck {[dict get $result accepted]} binary_accept
 ck {![dict get [::GX::stderrDiagnostics emit {} [string repeat z 32769]] accepted]} oversize_reject
 waitfor {[dict get [::GX::stderrDiagnostics status] written_records]>=1}
 set page [done [::GX::stderrDiagnostics read {} 1 1048576]]
 set rec [lindex [dict get $page result records] 0];save first-record.tcldict $rec
 ck {[binary encode hex [dict get $rec payload]] eq {000a0dfffe}} binary_exact
 dict for {k v} [dict get $rec origin] {ck {$v eq {unknown}} "unknown_$k"}
 foreach limit {0 257} {ck {[catch {::GX::stderrDiagnostics read {} $limit 1048576}]} "reject_read_$limit"}
 ck {[catch {::GX::stderrDiagnostics read {} 256 1048577}]} reject_read_bytes
 set cancelled [::GX::stderrDiagnostics read {} 256 1048576];::GX::stderrDiagnostics cancel $cancelled
 set cancelledResult [done $cancelled];save cancelled.tcldict $cancelledResult
 ck {[dict get $cancelledResult state] in {done cancelled}} cancel_terminates_race_honestly

 # Finite default-retention stimulus: 49MiB payload; serialized JSONL ~66MiB.
 set payload [string repeat x 32768];set samples {};set submitted 0;set rejected 0
 for {set n 0} {$n<1500} {incr n} {
  set t [clock microseconds];set result [::GX::stderrDiagnostics emit [dict create source independent-default-rotation operation $n] $payload]
  lappend samples [expr {[clock microseconds]-$t}];incr submitted
  if {![dict get $result accepted]} {incr rejected}
  if {$n%8==7} {after 2;update}
 }
 waitfor {[dict get [::GX::stderrDiagnostics status] pending_records]==0} 20000
 save default-rotation-status.tcldict [::GX::stderrDiagnostics status]
 set metadata [done [::GX::stderrDiagnostics meta]];save default-rotation-meta.tcldict $metadata
 set files [dict get $metadata result files]
 ck {[llength $files]<=5} default_file_count
 foreach file $files {ck {[dict get $file bytes]<=10485760} default_file_bound}
 ck {[dict get [::GX::stderrDiagnostics status] queue_high_water_bytes]<=8388608} default_ring_bound
 save emit-latency-us.tcllist $samples
 save submitted.tcldict [dict create submitted $submitted rejected $rejected]

 set helper [dict get [::GX::stderrDiagnostics status] helper_pid]
 save helper-identity.tcldict [dict create pid $helper exe [file readlink /proc/$helper/exe] stat [exec cat /proc/$helper/stat]]
 exec kill -STOP $helper;lappend signals [list STOP $helper]
 set pressureStart [clock microseconds];set pressureRejected 0
 for {set n 0} {$n<2000} {incr n} {if {![dict get [::GX::stderrDiagnostics emit {source independent-stalled-consumer} $payload] accepted]} {incr pressureRejected}}
 set elapsed [expr {[clock microseconds]-$pressureStart}]
 save pressure.tcldict [dict create emits 2000 elapsed_us $elapsed rejected $pressureRejected status [::GX::stderrDiagnostics status]]
 ck {$pressureRejected>0} pressure_truthful_drops
 exec kill -CONT $helper;lappend signals [list CONT $helper]
 waitfor {[dict get [::GX::stderrDiagnostics status] pending_records]==0} 20000
 ::GX::stderrDiagnostics stop;waitfor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
 set off [::GX::stderrDiagnostics status];save stopped.tcldict $off
 ck {[dict get $off capture_ipc]==0 && [dict get $off queue_bytes]==0 && [dict get $off writer]==0} stopped_no_capture_resources
 set retained [done [::GX::stderrDiagnostics read {} 1 1048576]]
 ck {[dict get $retained state] eq {done}} off_retained_reader
 set denied [file join $out denied];file mkdir $denied;file attributes $denied -permissions 0500
 ck {[catch {open [file join $denied probe] w}]} actual_eacces_precondition
 ::GX::stderrDiagnostics configure [dict create log_directory $denied]
 ::GX::stderrDiagnostics start;waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
 save permission-error.tcldict [::GX::stderrDiagnostics status]
 ::GX::stderrDiagnostics stop;waitfor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}
 file attributes $denied -permissions 0700
 puts {PASS independent production diagnostics boundaries/OFF/resources/default retention/bytes/reader/cancel/pressure/permission}
} on error {message options} {
 save failure.tcldict [dict create message $message options $options status [::GX::stderrDiagnostics status]]
 puts stderr [dict get $options -errorinfo];set failed 1
} finally {
 if {[info exists helper]} {catch {exec kill -CONT $helper}}
 catch {::GX::stderrDiagnostics stop};save signals.tcllist $signals
}
if {[info exists failed]} {exit 1}
