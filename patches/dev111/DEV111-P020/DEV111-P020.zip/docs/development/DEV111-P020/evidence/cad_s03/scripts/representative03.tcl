# P019 focused mapped Native2D/Curve Workbench verification; private data only.
lassign $argv framework output
if {[file exists $output]} {error {Fresh output required}}
set framework [file normalize $framework];file mkdir $output;set output [file normalize $output];file attributes $output -permissions 0700
foreach {key dir} {XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p019_stress__
set catalog [file join $output framework];file mkdir [file join $catalog plugins modules]
foreach name {core app docs services gxtxt_pipeline.tcl} {file copy [file join $framework $name] [file join $catalog $name]}
foreach name {math.numeric plot.dataset viewer.curve_workbench viewer.test_cad_1 viewer.test_cad_2 viewer.scientific_3d_workbench viewer.3d_workbench} {file copy [file join $framework plugins modules $name] [file join $catalog plugins modules $name]}
source [file join $catalog gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {path text} {set f [open $path w];puts -nonewline $f $text;close $f}
proc pause {{ms 120}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {test label} {
 if {![uplevel 1 [list expr $test]]} {error "FAIL: $label"}
 lappend ::checks [dict create name $label status PASS];write [file join $::output checks.tcllist] $::checks
 puts "PASS: $label";flush stdout
}
set checks {};set inputTrace {};set errors {};set evaluations {};set publications 0;set nativeEvents {};set modalEvents {};set inTrace 0
proc bgerror {message} {lappend ::errors $message;puts stderr "BACKGROUND: $message"}
proc traceEvaluate {command op} {lappend ::evaluations [lindex $command 2]}
proc tracePublish {command op} {incr ::publications}
proc traceInput {cmd op} {
 if {[lindex $cmd 1] eq {xdotool}} {lappend ::inputTrace [list [clock milliseconds] {*}[lrange $cmd 1 end]];write [file join $::output input.tcllist] $::inputTrace}
}
trace add execution exec enter traceInput
proc stockChoice {widget value} {
 click $widget;set i [lsearch -exact [$widget cget -values] $value]
 if {$i<0} {error "Missing actual choice $value in $widget"}
 exec xdotool key Home
 for {set n 0} {$n<$i} {incr n} {exec xdotool key Down}
 exec xdotool key Return;pause 100
 check {[$widget get] eq $value} "actual keyboard choice $value"
}
proc branchWatch {} {
 if {[winfo exists .]} {
  foreach top [guiWidgets .] {
   if {![winfo exists $top]} continue
   if {[winfo toplevel $top] ne $top || [wm title $top] ne {Branch Workspace History}} continue
   foreach button [guiWidgets $top] {
    if {[winfo class $button] in {Button TButton} && [winfo viewable $button] && [$button cget -text] eq {OK}} {
     lappend ::modalEvents [list branch_confirmation [clock milliseconds]]
     exec xdotool mousemove [expr {[winfo rootx $button]+[winfo width $button]/2}] [expr {[winfo rooty $button]+[winfo height $button]/2}] click 1
     break
    }
   }
  }
  set ::branchWatcher [after 70 branchWatch]
 }
}
proc guiWidgets {w} {set all [list $w];foreach c [winfo children $w] {lappend all {*}[guiWidgets $c]};return $all}
proc see {widget} {::GX::native2DViewportSeeWidget $::canvas $widget;pause 60}
proc click {widget} {
    see $widget
    check {[winfo ismapped $widget]} "mapped control $widget"
    exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1
    pause
}
proc combo {widget pattern} {
    click $widget
    set popup [::GX::_uiFieldSelectorPanel $widget [winfo toplevel $widget]];set list $popup.options
    check {[winfo ismapped $popup]} {public Viewer-bounded selector opens}
    set wanted -1;set i 0;foreach label [$list get 0 end] {if {[string match $pattern $label]} {set wanted $i;break};incr i}
    check {$wanted>=0} "choice exists: $pattern"
    $list see $wanted;pause 50
    lassign [$list bbox $wanted] x y width height
    exec xdotool mousemove [expr {[winfo rootx $list]+$x+20}] [expr {[winfo rooty $list]+$y+$height/2}] click 1
    pause
}
proc typeInto {widget text} {click $widget;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $text;pause 80}
proc shot {name} {::GX::native2DViewportTooltipHide;pause 80;exec timeout 8s import -silent -window root [file join $::output $name.png]}
proc menuIndex {menu pattern} {for {set i 0} {$i<=[$menu index end]} {incr i} {if {[$menu type $i] ne {separator} && [string match $pattern [$menu entrycget $i -label]]} {return $i}};error "Missing menu $pattern"}
proc menuChoose {button pattern} {
    click $button;set m [$button cget -menu];set i [menuIndex $m $pattern]
    set height [expr {[font metrics [$m cget -font] -linespace]+6}]
    if {$i<[$m index end]} {set height [expr {[$m yposition [expr {$i+1}]]-[$m yposition $i]}]}
    exec xdotool mousemove [expr {[winfo rootx $m]+40}] [expr {[winfo rooty $m]+[$m yposition $i]+$height/2}] click 1
    pause
}
proc selectCurve {id} {
    set tree $::w.leftScroll.viewport.content.curves
    $tree see $id;pause 50;lassign [$tree bbox $id name] x y width height
    exec xdotool mousemove [expr {[winfo rootx $tree]+$x+25}] [expr {[winfo rooty $tree]+$y+$height/2}] click 1
    pause
}


proc points {} {::GX::Native2D::core points $::scene [dict get $::GX::CurveWorkbench::st($::w,curves) $::a native]}
proc movePointer {xy} {lassign $xy x y;exec xdotool mousemove [expr {[winfo rootx $::canvas]+int(round($x))}] [expr {[winfo rooty $::canvas]+int(round($y))}]}
proc gizmoDrag {mode {finish release}} {
    menuChoose $::w.sketchbar.modify [string totitle $mode]
    set items [::GX::Native2D::core render_gizmo $::scene]
    set start {};set end {}
    foreach item $items {
        if {$mode eq {translate} && [dict get $item handle] eq {x} && [dict get $item kind] eq {line}} {
            lassign [dict get $item a] ax ay;lassign [dict get $item b] bx by
            set start [list [expr {($ax+$bx)/2.0}] [expr {($ay+$by)/2.0}]]
            set end [list [expr {[lindex $start 0]+$::translationPixels}] [lindex $start 1]];break
        }
        if {$mode eq {rotate} && [dict get $item handle] eq {rotate}} {
            set start [dict get $item a]
            set pivot [dict get [::GX::Native2D::core pivot $::scene] point]
            lassign [::GX::Native2D::core device $::scene $pivot] cx cy
            set radius [expr {[lindex $start 0]-$cx}]
            set end [list $cx [expr {$cy-$radius}]];break
        }
    }
    check {$start ne {} && $end ne {}} "existing $mode gizmo geometry available"
    set expectedHandle [expr {$mode eq {translate}?{x}:{rotate}}]
    check {[::GX::Native2D::core gizmo_hit $::scene $start 5] eq $expectedHandle} "actual $mode handle hit"
    set before [points]
    if {$finish eq {reject}} {set end [::GX::Native2D::core device $::scene [dict get [::GX::Native2D::core pivot $::scene] point]]}
    movePointer $start;exec xdotool mousedown 1;pause 70
    set activeBegin [::GX::Native2D::core drag_active $::scene]
    movePointer $end;pause 120
    set preview [points];set activePreview [::GX::Native2D::core drag_active $::scene]
    if {$finish eq {escape}} {exec xdotool key Escape;pause 80}
    exec xdotool mouseup 1;pause 150
    set after [points];set activeAfter [::GX::Native2D::core drag_active $::scene]
    set record [dict create mode $mode finish $finish before $before preview $preview after $after start $start end $end active_begin $activeBegin active_preview $activePreview active_after $activeAfter]
    lappend ::gestures $record
    write [file join $::output gestures.tcllist] $::gestures
    shot $mode-$finish-[llength $::gestures]
    puts "GESTURE: $record";flush stdout
    return $record
}

::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p019_perf {} 0]
::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
if {[::GX::configurationGet preview.cache_enabled] != 0} {error {Private preview cache guard failed}}
if {![string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {error {Cache root escaped output}}
package require Tk;wm geometry . 500x120+0+0;wm title . {P020 validation owned root}

set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 300
set windows {};set exitStatus 0
proc component {w id} {return [dict get $::GX::ViewerGui::instances $w widgets $id]}
proc inputClick {widget} {
 check {[winfo viewable $widget]} "native visible $widget"
 exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1;pause 250
}
proc sketchSnapshot {sketch label} {
 write [file join $::output $label-state.tcldict] [$sketch state]
 write [file join $::output $label-model.tcldict] [$sketch capture]
 write [file join $::output $label-world.tcldict] [$sketch world_scene]
 shot $label
}
proc canvasPoint {sketch point {phase click}} {
 set c [[$sketch get host] canvas];set xy [dict get [$sketch transform local_to_device [list $point]] points]
 # transform contract points is a list of pairs.
 lassign [lindex $xy 0] x y
 exec xdotool mousemove [expr {[winfo rootx $c]+int(round($x))}] [expr {[winfo rooty $c]+int(round($y))}]
 if {$phase eq {click}} {exec xdotool click 1} elseif {$phase eq {press}} {exec xdotool mousedown 1} elseif {$phase eq {release}} {exec xdotool mouseup 1}
 pause 180
}

proc awaitOpen {w} {
 set deadline [expr {[clock milliseconds]+45000}]
 while {![dict exists $::GX::ViewerGui::instances $w] && [clock milliseconds]<$deadline} {pause 100}
 check {[dict exists $::GX::ViewerGui::instances $w]} {ordinary provider mounted}
 pause 500
 set deadline [expr {[clock milliseconds]+10000}]
 while {[dict get $::GX::ViewerDevelopment::windows $w busy] ne {} && [clock milliseconds]<$deadline} {pause 100}
 write [file join $::output runtime-[file tail $w].tcldict] [dict get $::GX::ViewerDevelopment::windows $w]
 check {[dict get $::GX::ViewerDevelopment::windows $w status] eq {COMPLETED}} {actual native opening event completed}
 exec xdotool windowfocus --sync [winfo id $w];pause 150
}
proc nativeMenu {w label item} {
 set main [$w cget -menu];set target -1
 for {set i 0} {$i<=[$main index end]} {incr i} {if {[$main entrycget $i -label] eq $label} {set target $i;break}}
 check {$target>=0} "native menu $label exists"
 exec xdotool windowfocus --sync [winfo id $w];exec xdotool key Escape Escape F10;pause 120
 for {set i 0} {$i<$target} {incr i} {exec xdotool key Right;pause 35}
 pause 150
 set sub {};set mapped {}
 foreach q [guiWidgets .] {if {[winfo class $q] eq {Menu} && [winfo ismapped $q]} {lappend mapped $q;if {![catch {menuIndex $q $item} index]} {set sub $q}}}
 write [file join $::output native-menu-[string map {{ } _} $label].tcllist] $mapped
 check {$sub ne {}} "actual $label popup mapped"
 set i [menuIndex $sub $item];set h [expr {[font metrics [$sub cget -font] -linespace]+6}]
 if {$i<[$sub index end]} {set h [expr {[$sub yposition [expr {$i+1}]]-[$sub yposition $i]}]}
 exec xdotool mousemove [expr {[winfo rootx $sub]+40}] [expr {[winfo rooty $sub]+[$sub yposition $i]+$h/2}] click 1;pause 350
}
proc cadButton {sketch action} {
 set owner [$sketch widget]
 if {[dict exists $::GX::ViewerCommands::windows $owner toolbar buttons $action]} {return [dict get $::GX::ViewerCommands::windows $owner toolbar buttons $action]}
 error "No actual Canvas action $action"
}
proc action {w sketch action} {
 if {[dict exists $::GX::ViewerCommands::windows $w toolbar buttons cad_$action]} {set b [dict get $::GX::ViewerCommands::windows $w toolbar buttons cad_$action]} else {set b [cadButton $sketch $action]}
 inputClick $b
 set deadline [expr {[clock milliseconds]+10000}]
 while {[dict exists $::GX::ViewerDevelopment::windows $w] && [dict get $::GX::ViewerDevelopment::windows $w busy] ne {} && [clock milliseconds]<$deadline} {pause 80}
 pause 250
}
proc objectCount {sketch} {return [llength [lsearch -all -inline [dict keys [$sketch capture]] object/*]]}
proc contextFit {sketch} {
 set widget [$sketch widget].context
 foreach q [guiWidgets $widget] {if {[winfo class $q] in {Button TButton} && [winfo viewable $q] && ![catch {$q cget -text} text] && $text eq {Fit}} {inputClick $q;break}}
 pause 700
 write [file join $::output viewport-[file tail [$sketch widget]].tcldict] [::GX::native3DViewportInspect [$sketch get viewport]]
}
proc cadChoose {sketch group label {right 0}} {
 set button {};foreach q [guiWidgets [$sketch widget]] {if {[winfo class $q] eq {TMenubutton} && [winfo viewable $q] && [string match {All CAD actions*} [$q cget -text]]} {set button $q;break}}
 check {$button ne {}} {Canvasfullcatalog actualbuttonvisible}
 if {$right} {set c [[$sketch get host] canvas];canvasPoint $sketch {0.65 0.0} move;exec xdotool click 3;pause 180} else {inputClick $button}
 set menu [$button cget -menu];check {[winfo ismapped $menu]} {actualfullCanvasmenu mapped}
 set i [menuIndex $menu $group];set sub [$menu entrycget $i -menu]
 exec xdotool mousemove [expr {[winfo rootx $menu]+50}] [expr {[winfo rooty $menu]+[$menu yposition $i]+10}];pause 220
 check {[winfo ismapped $sub]} "actualCanvasgroup $group mapped"
 shot menu-[string map {{ } _} $group]-[string map {{ } _} $label]
 set i [menuIndex $sub $label];set h [expr {[font metrics [$sub cget -font] -linespace]+6}]
 if {$i<[$sub index end]} {set h [expr {[$sub yposition [expr {$i+1}]]-[$sub yposition $i]}]}
 exec xdotool mousemove [expr {[winfo rootx $sub]+45}] [expr {[winfo rooty $sub]+[$sub yposition $i]+$h/2}] click 1;pause 250
}
proc midpoint {sketch logical} {lassign [dict get [$sketch capture] object/$logical definition controls] a b;return [list [expr {([lindex $a 0]+[lindex $b 0])/2.0}] [expr {([lindex $a 1]+[lindex $b 1])/2.0}]]}
proc selectLine {w sketch logical} {action $w $sketch select;canvasPoint $sketch [midpoint $sketch $logical]}
proc dimensionEditor {sketch at} {
 canvasPoint $sketch $at
 set editor [[$sketch get host] canvas].dimensionEditor
 if {![winfo exists $editor]} {canvasPoint $sketch $at}
 check {[winfo exists $editor.value]} {actualinlineDimensioneditoropens}
 return $editor
}
proc numericEdit {editor value} {inputClick $editor.value;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $value;pause 80;check {[$editor.value get] eq $value} {actualdimensionnumerictext};inputClick $editor.commit}
try {
 set module viewer.test_cad_2;set provider test_cad_2
 set w [::GX::viewerOpen $module $provider [dict create workspace_id new workspace_name {S03 representativeCADfixture}]];lappend windows $w;awaitOpen $w
 set sketch [dict get $::GX::ViewerGui::instances $w cad_sketches sketch]
 write [file join $output disabled-undo.tcldict] [dict create action [$sketch actionState undo] widget [[cadButton $sketch undo] state]]
 check {![dict get [$sketch actionState undo] enabled] && {[cadButton $sketch undo]} ne {}} {emptyDocumentUndoDisabled}
 cadChoose $sketch Create Line 1
 write [file join $output checked-line.tcldict] [dict create action [$sketch actionState line] widget [[cadButton $sketch line] state] style [[cadButton $sketch line] cget -style]]
 check {[dict get [$sketch actionState line] checked]} {sameCanvasLineIconChecked}
 canvasPoint $sketch {0.2 0.2};canvasPoint $sketch {0.75 0.23};action $w $sketch cancel
 cadChoose $sketch Create Line
 canvasPoint $sketch {0.8 0.2};canvasPoint $sketch {0.83 0.8};action $w $sketch cancel
 check {[objectCount $sketch]==2} {twoactualLineobjects}
 selectLine $w $sketch s1;cadChoose $sketch Relations Horizontal;action $w $sketch cancel
 selectLine $w $sketch s2;cadChoose $sketch Relations Vertical;action $w $sketch cancel
 sketchSnapshot $sketch constraintsHV
 set ctr [dict get [$sketch capture] object/s1 definition controls]
 check {abs([lindex $ctr 0 1]-[lindex $ctr 1 1])<1e-8} {nativeHorizontalgeomvalid}
 set ctr [dict get [$sketch capture] object/s2 definition controls]
 check {abs([lindex $ctr 0 0]-[lindex $ctr 1 0])<1e-8} {nativeVerticalgeomvalid}
 selectLine $w $sketch s1;cadChoose $sketch Relations Dimension
 set editor [dimensionEditor $sketch {0.35 0.45}];numericEdit $editor 0.7;exec xdotool key Escape;pause 150
 sketchSnapshot $sketch drivingDimension
 set controls [dict get [$sketch capture] object/s1 definition controls]
 check {abs(abs([lindex $controls 1 0]-[lindex $controls 0 0])-0.7)<1e-7} {drivingLength0.7authoritative}
 selectLine $w $sketch s1;cadChoose $sketch Relations Fixed;action $w $sketch cancel
 set referenceBefore [$sketch capture];set historyBefore [dict get [$sketch state] history count]
 selectLine $w $sketch s1;cadChoose $sketch Relations Dimension
 set editor [dimensionEditor $sketch {0.55 0.6}];numericEdit $editor 0.9
 check {[winfo exists $editor.reference] && [winfo viewable $editor.reference]} {actualconflictreferencefallbackvisible}
 shot reference-offer;inputClick $editor.reference;exec xdotool key Escape;pause 150
 sketchSnapshot $sketch referenceDimension
 check {[dict get [$sketch capture] object/s1 definition] eq [dict get $referenceBefore object/s1 definition]} {referencepreservesexactgeometry}
 check {[dict get [$sketch state] history count]==$historyBefore+1} {referenceacceptedexactlyoneHistorystep}
 cadChoose $sketch Create {Quadratic Bezier}
 canvasPoint $sketch {0.1 0.05};canvasPoint $sketch {0.4 0.65};canvasPoint $sketch {0.75 0.05};action $w $sketch cancel
 check {[objectCount $sketch]==3} {actualBeziercommitted}
 set bezierKey {};dict for {key value} [$sketch capture] {if {[string match object/* $key] && [dict get $value definition family] eq {quadratic_bezier}} {set bezierKey $key}}
 check {$bezierKey ne {}} {publiccaptureidentifiesactualBezierlogicalkey}
 sketchSnapshot $sketch bezier-before-edit
 action $w $sketch select;canvasPoint $sketch {0.4125 0.35};pause 150
 set before [$sketch capture]
 canvasPoint $sketch {0.4 0.65} press;canvasPoint $sketch {0.45 0.75} move;canvasPoint $sketch {0.45 0.75} release
 check {[dict get [$sketch capture] $bezierKey definition controls] ne [dict get $before $bezierKey definition controls]} {actualBezierdefiningcontroledit}
 contextFit $sketch;sketchSnapshot $sketch bezier-edited
 # OrdinaryViewer menu andiconstate subset on independentTestCAD1.
 set w1 [::GX::viewerOpen viewer.test_cad_1 test_cad_1 [dict create workspace_id new workspace_name {S03ViewerMenus}]];lappend windows $w1;awaitOpen $w1
 set sk1 [dict get $::GX::ViewerGui::instances $w1 cad_sketches sketch]
 nativeMenu $w1 Create Line;pause 250
 write [file join $output viewer-icon-facts.tcldict] [dict create line [$sk1 actionState line] undo [$sk1 actionState undo] line_widget [[dict get $::GX::ViewerCommands::windows $w1 toolbar buttons cad_line] state] undo_widget [[dict get $::GX::ViewerCommands::windows $w1 toolbar buttons cad_undo] state]]
 check {[dict get [$sk1 actionState line] checked] && ![dict get [$sk1 actionState undo] enabled]} {actualViewerMenuandiconfactsagree}
 shot viewer-line-checked;exec xdotool key Escape
 write [file join $output RESULT.txt] {Representative nativeCanvasHVDimensionReferenceBezier andViewerMenu states executed; inspectpixels/science beforequalification.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {shot failure};set exitStatus 1} finally {
 write [file join $output errors.tcllist] $errors
 foreach w $windows {catch {destroy $w}}
 catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
exit $exitStatus
