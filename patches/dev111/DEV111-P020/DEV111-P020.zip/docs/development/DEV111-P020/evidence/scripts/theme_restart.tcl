# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv framework output profileFile
if {[file exists $output]} {error {fresh output required}}
file mkdir $output;file attributes $output -permissions 0700
set f [open $profileFile r];set profile [read $f];close $f
foreach {key dir} {GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp XDG_CACHE_HOME cache} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
foreach {key field} {HOME home XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_STATE_HOME state} {set ::env($key) [dict get $profile $field]}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __theme_restart__
source [file join $framework gxtxt_pipeline.tcl];::GX::defaults;::GX::loadModuleCatalog
proc write {p s} {set f [open $p w];puts -nonewline $f $s;close $f}
proc pause {{ms 100}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {test name} {if {![uplevel 1 [list expr $test]]} {error "FAIL:$name"};puts "PASS:$name";flush stdout}
proc waitFor {test name {ms 15000}} {set end [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]] && [clock milliseconds]<$end} {pause 50};check [uplevel 1 [list expr $test]] $name}
proc shot {label} {pause 100;exec import -silent -window root [file join $::output $label.png]}
set errors {};proc bgerror msg {lappend ::errors $msg;puts stderr $msg}
package require Tk
set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 200
set w {}
try {
 ::GX::launchGui;pause 500
 check {[ttk::style theme use] eq [dict get $profile theme]} {documented restart applies saved native ttk theme}
 check {![dict get [::GX::stderrDiagnostics status] enabled]} {restart savedOFF has no active capture}
 set w [::GX::viewerOpen viewer.stderr_diagnostics stderr_diagnostics {}]
 waitFor {[dict exists $::GX::ViewerGui::instances $w]} {ordinary Diagnostics Viewer mounts under selectedtheme} 45000
 set inspect [::GX::viewerGuiRuntimeInspect $w]
 set table [::GX::uiFieldComponentTableWidget [dict get $inspect components records widget]]
 waitFor {[llength [$table children {}]]>=1} {explicit OFF reader loads retained callback record}
 set item [lindex [$table children {}] 0];lassign [$table bbox $item] x y width height
 exec xdotool mousemove [expr {[winfo rootx $table]+$x+30}] [expr {[winfo rooty $table]+$y+$height/2}] click 1;pause 500
 set log [dict get $inspect components log widget]
 waitFor {[string first TCL_CALLBACK_SENTINEL [$log get 1.0 end]]>=0} {native selected error row displays original multiline callback payload}
 set tags {};foreach tag [$log tag names] {dict set tags $tag [list [$log tag ranges $tag] [$log tag cget $tag -foreground]]}
 write [file join $output themed-inspect.tcldict] [dict create theme [ttk::style theme use] log [$log get 1.0 end] tags $tags viewer [::GX::viewerGuiRuntimeInspect $w] collector [::GX::stderrDiagnostics status]]
 shot selected-theme-error
 check {![dict get [::GX::stderrDiagnostics status] enabled]} {OFF consultation does not start capture}
 write [file join $output RESULT.txt] {PASS native theme restart and OFF retained multiline error consultation; inspect pixels.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {shot failure};set exitStatus 1} finally {
 write [file join $output errors.tcllist] $errors;catch {::GX::stderrDiagnostics stop};catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
if {[info exists exitStatus]} {exit $exitStatus};exit 0
