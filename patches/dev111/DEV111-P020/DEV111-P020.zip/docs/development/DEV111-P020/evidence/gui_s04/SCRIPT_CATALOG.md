# P020 S04 affected validation catalog

SPDX-License-Identifier: GPL-3.0-or-later

`scripts/s04_diagnostics.tcl FRAMEWORK NEW_OUTPUT`: frozenS04 ordinaryDiagnostics native selected/unselected pause/follow/Next/Latest/exportmodal/closecleanup;420s privateXvfb. TrustedpublicConfigSaveafterTk start, synthetic8recordfixture. Creates fresh private runtime/profile/Session/log/export/evidence only, no installed/original data writes. Heartbeat50ms/one-sample publiccommandtimings are observations, not benchmark.

`scripts/s04_context.tcl FRAMEWORK NEW_OUTPUT`: frozenS04 oneordinaryCAD1 ViewerownedSketch rightclick/customTEST/sharedLine checked+Undo disabled sample;180s privateXvfb. No scientificedit/matrixrepeat. Same fresh private runtime/profile/Session/evidence boundary.

Invoke with privateHOME/TMPDIR/XDG under authorized validationtree, umask0077, explicit timeout/xvfb-run recorded in S04_GUI_RECEIPT.json. Both refuse existing output. Scripts are exact executed bytes and GPL-3.0-or-later under this catalog. Only whitelistlisted helper/catalog/receipts/syntheticPNGs comprise handoff; Sessions, runtimecopies, rawlogarchives and unrelated private material excluded.
