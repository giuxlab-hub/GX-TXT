# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv framework output
if {[file exists $output]} {error {fresh output required}}
file mkdir $output;set output [file normalize $output]
foreach {key dir} {HOME home XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p020_diag_gui__
set catalog [file join $output framework];file mkdir $catalog
foreach name {core app services plugins gxtxt_pipeline.tcl} {file copy [file join $framework $name] [file join $catalog $name]}
file mkdir [file join $catalog docs];file copy [file join $framework docs help] [file join $catalog docs help]
source [file join $catalog gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {path value} {set f [open $path w];puts -nonewline $f $value;close $f}
proc pause {{ms 100}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {value name} {if {![uplevel 1 [list expr $value]]} {error "FAIL: $name"};lappend ::checks [list PASS $name];write [file join $::output checks.tcllist] $::checks;puts "PASS: $name";flush stdout}
set checks {};set errors {};set inputTrace {}
proc bgerror {msg} {lappend ::errors $msg;puts stderr "ORIGINAL-BGERROR:$msg"}
proc traceInput {cmd args} {if {[lindex $cmd 1] eq {xdotool}} {lappend ::inputTrace $cmd;write [file join $::output input.tcllist] $::inputTrace}}
trace add execution exec enter traceInput
proc widgets {w} {set all [list $w];foreach c [winfo children $w] {lappend all {*}[widgets $c]};return $all}
proc click {widget} {
 set top [winfo toplevel $widget];set scroll $top.body.inspector.scroll
 if {[winfo exists $scroll] && [string first "$scroll.content." $widget]==0} {
  for {set n 0} {$n<25} {incr n} {
   set cy [expr {[winfo rooty $widget]+[winfo height $widget]/2}];set lo [winfo rooty $scroll];set hi [expr {$lo+[winfo height $scroll]}]
   if {$cy>$lo+10 && $cy<$hi-10} break
   exec xdotool mousemove [expr {[winfo rootx $scroll]+5}] [expr {$lo+40}] click [expr {$cy<$lo?4:5}];pause 50
  }
 }
 check {[winfo viewable $widget]} "viewable $widget"
 exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1;pause 200
}
proc waitFor {test name {ms 15000}} {set until [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]] && [clock milliseconds]<$until} {pause 50};check [uplevel 1 [list expr $test]] $name}
proc observe {test name} {set ok [uplevel 1 [list expr $test]];lappend ::observations [list [expr {$ok?{PASS}:{FAIL}}] $name];write [file join $::output observations.tcllist] $::observations;puts "OBSERVE:[expr {$ok?{PASS}:{FAIL}}]:$name";flush stdout;return $ok}
set observations {}
proc dialogActor {kind target} {
 set found {};foreach top [widgets .] {if {[winfo toplevel $top] eq $top && [string match [expr {$kind eq {directory}?{*Global STDERR*}:{*Export selected STDERR*}}] [wm title $top]]} {set found $top;break}}
 if {$found eq {}} {error "Native $kind dialog not observed"}
 write [file join $::output dialog-$kind-widgets.tcllist] [widgets $found];shot dialog-$kind
 if {$target eq {CANCEL}} {exec xdotool key Escape;return}
 set entry $found.contents.f2.ent;check {[winfo viewable $entry]} "native $kind entry observed"
 exec xdotool mousemove [expr {[winfo rootx $entry]+60}] [expr {[winfo rooty $entry]+10}] click 1
 exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $target;after 300 [list dialogOK $found]
}

proc dialogOK {found {remaining 1}} {
 if {![winfo exists $found] || ![winfo viewable $found]} return
 set ok $found.contents.f2.ok;check {[winfo viewable $ok]} {native dialog OK button observed}
 write [file join $::output dialog-ok-position.tcllist] [list [winfo rootx $ok] [winfo rooty $ok] [winfo width $ok] [winfo height $ok]]
 exec xdotool mousemove [expr {[winfo rootx $ok]+[winfo width $ok]/2}] [expr {[winfo rooty $ok]+[winfo height $ok]/2}] click 1
 if {$remaining>0} {after 400 [list dialogOK $found 0]}
}

proc typeInto {widget text} {click $widget;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $text;exec xdotool key Tab;pause 180}
proc shot {label} {pause 100;exec timeout 8s import -silent -window root [file join $::output $label.png]}
proc component {id} {
 set row [dict get [::GX::viewerGuiRuntimeInspect $::w] components $id];set widget [dict get $row widget]
 if {[dict get $row type] in {field choice toggle}} {return $widget.entry}
 if {[dict get $row type] eq {table}} {return [::GX::uiFieldComponentTableWidget $widget]}
 return $widget
}
proc dump {label} {
 set log [component log];set tags {};foreach tag [$log tag names] {dict set tags $tag [list [$log tag ranges $tag] [$log tag cget $tag -foreground]]}
 write [file join $::output $label.tcldict] [dict create collector [::GX::stderrDiagnostics status] viewer [::GX::viewerGuiRuntimeInspect $::w] table [::GX::uiFieldComponentTableRead [component records]] log [$log get 1.0 end] tags $tags]
 shot $label
}

::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p020_diagnostics {} 0]
::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
check {[::GX::configurationGet preview.cache_enabled]==0 && [string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {private postSession cache guard}
package require Tk
set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 250
set w {}
try {
 ::GX::launchGui;wm geometry . 1850x1330+0+0;pause 700
 check {![dict get [::GX::stderrDiagnostics status] enabled]} {normal GUI startup capture defaultOFF}
 ::GX::configurationOpenPage runtime;pause 200
 set runtime .top.nb.configuration.sections.runtime
 set dir $runtime.value_diagnostics_stderr_log_directory
 set originalHandler [interp bgerror {}]
 file mkdir [file join $output stderr_logs];file attributes [file join $output stderr_logs] -permissions 0700
 after 500 [list dialogActor directory [file join $output stderr_logs]]
 click $runtime.browse_diagnostics_stderr_log_directory
 check {[$dir get] eq [file join $output stderr_logs]} {native directory Browse selects private directory}
 set enable $runtime.value_diagnostics_stderr_capture_enabled
 click $enable.entry
 set save .top.nb.configuration.actions.save
 check {$save ne {}} {actual Configuration Save control located}
 click $save;pause 250
 write [file join $output config-on.tcldict] [::GX::stderrDiagnostics status];shot config-on
 waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}} {native Configuration enables running capture}
 toplevel .errorfixture;ttk::button .errorfixture.trigger -text {Emit ordinary callback error} -command {error TCL_CALLBACK_SENTINEL};pack .errorfixture.trigger;wm geometry .errorfixture +50+50;pause 100
 click .errorfixture.trigger;waitFor {[lsearch -exact $::errors TCL_CALLBACK_SENTINEL]>=0} {original background error handler preserved}
 exec xdotool windowfocus --sync [winfo id .errorfixture] key alt+F4;pause 100

 waitFor {[dict get [::GX::stderrDiagnostics status] written_records]>=1} {actual callback error persisted}
 raise .;::GX::configurationOpenPage runtime;pause 100;click $enable.entry;click $save
 waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {off}} {native Runtime checkboxOFF Save stops collector}
 check {[interp bgerror {}] eq $originalHandler} {actual ConfigurationOFF restores original error handler}
 shot config-off
 set hashes {};foreach f [glob [file join $output stderr_logs *.jsonl]] {dict set hashes $f [::GX::sha256File $f]}
 toplevel .erroroff;ttk::button .erroroff.trigger -text {Ordinary callback whileOFF} -command {error TCL_OFF_CALLBACK_SENTINEL};pack .erroroff.trigger;pause 100;click .erroroff.trigger
 waitFor {[lsearch -exact $::errors TCL_OFF_CALLBACK_SENTINEL]>=0} {OFF original callback handling preserved}
 exec xdotool windowfocus --sync [winfo id .erroroff] key alt+F4;pause 100
 set hashesAfter {};foreach f [dict keys $hashes] {dict set hashesAfter $f [::GX::sha256File $f]}
 check {$hashes eq $hashesAfter} {OFF callback adds no diagnostic archive writes}
 ::GX::configurationOpenPage appearance;pause 150
 set themeWidget .top.nb.configuration.sections.appearance.canvas.content.theme.value_ui_theme
 set targetTheme [expr {[ttk::style theme use] eq {clam}?{alt}:{clam}}]
 set i [lsearch -exact [$themeWidget cget -values] $targetTheme];check {$i>=0} {native theme choice exists}
 click $themeWidget;exec xdotool key Home;for {set n 0} {$n<$i} {incr n} {exec xdotool key Down};exec xdotool key Return;pause 120
 check {[$themeWidget get] eq $targetTheme} {actual Appearance combo selects theme}
 click $save;pause 120
 check {[::GX::configurationGet ui.theme] eq $targetTheme} {actual Save persists theme for restart}
 shot theme-saved-restart-required
 write [file join $output profile.tcldict] [dict create home $::env(HOME) config $::env(XDG_CONFIG_HOME) data $::env(XDG_DATA_HOME) state $::env(XDG_STATE_HOME) log_directory [file join $output stderr_logs] theme $targetTheme current_theme [ttk::style theme use] configuration_path [::GX::configurationPath]]
 write [file join $output final-status.tcldict] [::GX::stderrDiagnostics status]
 write [file join $output RESULT.txt] {PASS actual RuntimeON/OFF callback routing and native themeSave; restart application separately.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {shot failure};set exitStatus 1} finally {
 write [file join $output errors.tcllist] $errors
 catch {::GX::stderrDiagnostics stop};catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
if {[info exists exitStatus]} {exit $exitStatus};exit 0
