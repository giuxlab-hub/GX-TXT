# P020 independent qualification

SPDX-License-Identifier: GPL-3.0-or-later

Frozen S04 `f4c968ba02a562507423329dd0d3239b76414f14` passed the assigned representative runtime gates. Matching source/binary hashes, exact commands, expected/observed results and reproduction are in the structured receipts. First failures remain preserved outside this sanitized handoff.

TestCAD1/2 and the normal 3D Workbench passed actual native editing, scientific coordinates, History, cancel and save/reopen. Oriented-plane gold error was0. Representative H/V, driving/reference dimensions, Bezier defining controls, shared menu/icon state and the added Viewer-owned context/custom action passed. The 172-file reuse ledger establishes unchanged scientific owners; S04 affected context/worker paths were tested separately.

Diagnostics passed native filters/search, selection/copy, exact original export/cancellation, selected and unselected pause/backlog, Next/Latest, asynchronous modal-tail delivery and close cleanup. Configuration Runtime Browse/ON/OFF, genuine callback error/original-handler restoration, saved theme restart and OFF retained consultation passed with inspected pixels. Selection intentionally preserves current details while following caches new pages; Next exposes that tail. Without selection, follow activates the newest page.

Development Preview genuine native stderr now reaches the one collector with correct source/module/Viewer/process metadata. ON-to-OFF restored fd2 and retired its reader (two threads to one) without restarting the worker; the next real GUI event completed, appended original stderr and made no capture write. Cold OFF had no descriptor, native collector library, pipe, reader, capture log directory or diagnostics control packets. Managed Job original stdout/stderr/diagnostic streams and exact archive duplication also passed.

Native production API/CABI, bounded readers, concurrent producers, default10MiB*5 rotation, actual8MiB ring pressure, permission failures and crash/restart checks passed. Actual EFBIG was distinct from separately compiled injected ENOSPC/delay tests. True full-filesystem ENOSPC and physical slow storage remain unverified.

Measured facts: native emit p50 252µs/p95 325µs/max491µs; 2000 stalled-consumer attempts completed in536212µs with1995 transport rejections. Rotation-pressure high-water8361374B stayed below8388608B, with57 truthful ring drops. GUI279 heartbeat samples had median50.09ms and max719.95ms including startup/screenshots; selected/unselected unpause samples were387/397ms, Latest310ms. Managed Job launch-to-terminal samples were4.8111s OFF and5.1821s ON, including worker startup/drain. These observations are not a causal overhead estimate or a zero-overhead promise.

Only the explicit whitelist is suitable for distribution: public helper code/catalogs, structured receipts and selected synthetic PNGs. No Session trees, runtime copies, raw data archives or unrelated support material are included. MAIN1 alone owns final source pinning, acceptance and release; its later demo-only/checksum/documentation delta has separate contract evidence.
