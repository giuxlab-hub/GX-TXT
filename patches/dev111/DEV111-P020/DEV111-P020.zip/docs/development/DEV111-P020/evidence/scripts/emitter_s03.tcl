# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv framework output emitterProject
if {[file exists $output]} {error {fresh output required}}
file mkdir $output;set output [file normalize $output]
foreach {key dir} {HOME home XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p020_diag_gui__
set catalog [file join $output framework];file mkdir $catalog
foreach name {core app services plugins gxtxt_pipeline.tcl} {file copy [file join $framework $name] [file join $catalog $name]}
file mkdir [file join $catalog docs];file copy [file join $framework docs help] [file join $catalog docs help]
source [file join $catalog gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {path value} {set f [open $path w];puts -nonewline $f $value;close $f}
proc pause {{ms 100}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {value name} {if {![uplevel 1 [list expr $value]]} {error "FAIL: $name"};lappend ::checks [list PASS $name];write [file join $::output checks.tcllist] $::checks;puts "PASS: $name";flush stdout}
set checks {};set errors {};set inputTrace {}
proc bgerror {msg} {lappend ::errors $msg;puts stderr "ORIGINAL-BGERROR:$msg"}
proc traceInput {cmd args} {if {[lindex $cmd 1] eq {xdotool}} {lappend ::inputTrace $cmd;write [file join $::output input.tcllist] $::inputTrace}}
trace add execution exec enter traceInput
proc widgets {w} {set all [list $w];foreach c [winfo children $w] {lappend all {*}[widgets $c]};return $all}
proc click {widget} {check {[winfo viewable $widget]} "viewable $widget";exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1;pause 150}
proc typeInto {widget text} {click $widget;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $text;exec xdotool key Tab;pause 180}
proc shot {label} {pause 100;exec timeout 8s import -silent -window root [file join $::output $label.png]}
proc component {id} {return [dict get [::GX::viewerGuiRuntimeInspect $::w] components $id widget]}
proc dump {label} {write [file join $::output $label.tcldict] [dict create collector [::GX::stderrDiagnostics status] viewer [::GX::viewerGuiRuntimeInspect $::w]];shot $label}
::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p020_diagnostics {} 0]
::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
check {[::GX::configurationGet preview.cache_enabled]==0 && [string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {private postSession cache guard}
package require Tk
set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 250
set w {}

proc waitFor {test name {ms 15000}} {set until [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]] && [clock milliseconds]<$until} {pause 50};check [uplevel 1 [list expr $test]] $name}
proc workerState {label worker} {
 write [file join $::output $label.tcldict] [dict create worker_pid $worker fd2 [file readlink /proc/$worker/fd/2] tasks [glob /proc/$worker/task/*] runtime [dict get $::GX::ViewerDevelopment::windows $::w] collector [::GX::stderrDiagnostics status]]
 shot $label
}
try {
 wm withdraw .;file mkdir [file join $output stderr_logs];file attributes [file join $output stderr_logs] -permissions 0700
 ::GX::configurationSet diagnostics.stderr_log_directory [file join $output stderr_logs]
 ::GX::configurationSet diagnostics.stderr_capture_enabled 1
 ::GX::configurationSave {diagnostics.stderr_log_directory diagnostics.stderr_capture_enabled}
 waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}} {public Configuration API starts running capture}
 ::GX::stderrDiagnosticsProducerEnvironment
 check {[info exists ::env(GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR)] && $::env(GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR) ne {}} {parent producerdescriptor exists beforeworkerlaunch}
 set parentDescriptor $::env(GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR);set parentLibrary $::env(GXTXT_STDERR_DIAGNOSTICS_LIBRARY)
 write [file join $output prelaunch.tcldict] [dict create collector [::GX::stderrDiagnostics status] descriptor_length [string length $parentDescriptor] library $parentLibrary capture_preference [::GX::configurationGet diagnostics.stderr_capture_enabled]]
 set w [::GX::viewerDevelopmentPreview $emitterProject]
 wm geometry $w 1400x950+40+20;raise $w
 waitFor {[dict exists $::GX::ViewerGui::instances $w] && [dict exists $::GX::ViewerDevelopment::windows $w compiled_service_receipt]} {ordinary emitter C++ Viewer mounted} 60000
 set worker [dict get $::GX::ViewerDevelopment::windows $w compiled_service_receipt pid]
 set f [open /proc/$worker/environ rb];set rawEnv [read $f];close $f;set workerDescriptor {};set workerLibrary {}
 foreach pair [split $rawEnv \0] {if {[string match GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR=* $pair]} {set workerDescriptor [string range $pair 36 end]};if {[string match GXTXT_STDERR_DIAGNOSTICS_LIBRARY=* $pair]} {set workerLibrary [string range $pair 33 end]}}
 # Parse at the first equals rather than relying on prefix lengths.
 foreach pair [split $rawEnv \0] {set equal [string first = $pair];set key [string range $pair 0 [expr {$equal-1}]];set value [string range $pair [expr {$equal+1}] end];if {$key eq {GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR}} {set workerDescriptor $value};if {$key eq {GXTXT_STDERR_DIAGNOSTICS_LIBRARY}} {set workerLibrary $value}}
 write [file join $output worker-env-redacted.tcldict] [dict create worker_pid $worker descriptor_length [string length $workerDescriptor] descriptor_matches_parent [expr {$workerDescriptor eq $parentDescriptor}] library $workerLibrary library_matches_parent [expr {$workerLibrary eq $parentLibrary}] expected_sibling_library [file normalize [file join $catalog core diagnostics bin gxdiagnostics.so]] fd2 [file readlink /proc/$worker/fd/2] task_count [llength [glob /proc/$worker/task/*]] collector [::GX::stderrDiagnostics status]]
 set action [dict get [::GX::viewerGuiRuntimeInspect $w] components advance widget]
 waitFor {[dict get $::GX::ViewerDevelopment::windows $w status] eq {COMPLETED}} {emitter opening callback completes}
 click $action
 waitFor {[dict get $::GX::ViewerDevelopment::windows $w state counter]==1} {native emitter action completes whileON}
 workerState after-on-action $worker
 waitFor {[dict get [::GX::stderrDiagnostics status] written_records]>=2} {real native stderr reaches collector}
 workerState on $worker
 set tasksOn [llength [glob /proc/$worker/task/*]]
 check {[string match {pipe:*} [file readlink /proc/$worker/fd/2]]} {ON worker stderr uses optionalpipe}
 ::GX::configurationSet diagnostics.stderr_capture_enabled 0
 ::GX::configurationSave {diagnostics.stderr_capture_enabled}
 waitFor {![dict get [::GX::stderrDiagnostics status] enabled]} {public ConfigurationOFF stops globalcapture}
 waitFor {![string match {pipe:*} [file readlink /proc/$worker/fd/2]] && [llength [glob /proc/$worker/task/*]]<$tasksOn} {ConfigOFF restoresfd2 and retires optionaldrainthread}
 set log [file join $emitterProject derived native-output.log]
 set beforeSize [file size $log]
 set files [glob [file join $output stderr_logs *.jsonl]];set beforeHashes {};foreach file $files {dict set beforeHashes $file [::GX::sha256File $file]}
 workerState off-before-action $worker
 click $action
 waitFor {[dict get $::GX::ViewerDevelopment::windows $w state counter]==2} {next native event afterOFF has intact protocol}
 check {[dict get $::GX::ViewerDevelopment::windows $w compiled_service_receipt pid]==$worker} {same native worker survivesOFF}
 check {[file size $log]>$beforeSize} {OFF original native stderr stillappends}
 pause 300;set afterHashes {};foreach file $files {dict set afterHashes $file [::GX::sha256File $file]}
 check {$beforeHashes eq $afterHashes} {OFF next nativeevent creates no capture logwrite}
 workerState off-after-action $worker
 set f [open $log rb];set original [read $f];close $f;write [file join $output original-native-output.log] $original
 set token [::GX::stderrDiagnostics read {} 256 1048576]
 for {set i 0} {$i<100} {incr i} {set page [::GX::stderrDiagnostics request $token];if {[dict get $page state] ne {pending}} break;pause 30}
 write [file join $output archive.tcldict] $page
 write [file join $output RESULT.txt] {PASS focused nativeEmitterON/OFF actualGUI callback and route cleanup; inspect receipts/pixels.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {write [file join $output failure-runtime.tcldict] [dict get $::GX::ViewerDevelopment::windows $w]};catch {shot failure};set exitStatus 1} finally {
 write [file join $output errors.tcllist] $errors
 catch {::GX::stderrDiagnostics stop};catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
if {[info exists exitStatus]} {exit $exitStatus};exit 0
