# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv framework output phases
if {$phases eq {}} {set phases {off on}}
if {[file exists $output]} {error {fresh output required}}
file mkdir $output;set output [file normalize $output]
foreach {key dir} {HOME home XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p020_job_diagnostics__
source [file join $framework gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {p s} {set f [open $p w];puts -nonewline $f $s;close $f}
proc check {test name} {if {![uplevel 1 [list expr $test]]} {error "FAIL:$name"};puts "PASS:$name"}
proc waitJob {id} {set until [expr {[clock seconds]+60}];while {[clock seconds]<$until} {set j [::GX::scriptJobDescribe $id];if {[dict get $j state] in {COMPLETED FAILED CANCELLED INTERRUPTED}} {return $j};after 150};error "timeout$id"}
::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p020_job {} 0];::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
check {[::GX::configurationGet preview.cache_enabled]==0 && [string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {private cache postSession}
::GX::scriptRegistrySave session diagnostics_route {Diagnostics routing fixture} {import os,sys
os.write(1,b'SCIENCE=55\nSTDOUT_ORIGINAL_SENTINEL\n')
os.write(2,('STDERR_ORIGINAL_SENTINEL PID='+str(os.getpid())+'\nSTACK second line Ω\n').encode('utf-8'))
} [dict create language Python]
set results {}
try {
 foreach phase $phases {
  if {$phase eq {on}} {file mkdir [file join $output stderr_logs];file attributes [file join $output stderr_logs] -permissions 0700;::GX::stderrDiagnostics start [dict create log_directory [file join $output stderr_logs]];set until [expr {[clock milliseconds]+5000}];while {[dict get [::GX::stderrDiagnostics status] state] ne {running} && [clock milliseconds]<$until} {after 10;update};::GX::stderrDiagnosticsProducerEnvironment;check {[info exists ::env(GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR)]} {ON producer descriptor ready before submission}}
  set before [::GX::stderrDiagnostics status]
  set submitted [::GX::scriptJobSubmit session:diagnostics_route {}];set job [waitJob [dict get $submitted id]]
  write [file join $output $phase-job.tcldict] $job
  check {[dict get $job state] eq {COMPLETED}} "$phase ordinary registeredJob completes"
  dict set results $phase [dict create before $before after [::GX::stderrDiagnostics status] job $job]
 }
 set token [::GX::stderrDiagnostics read {} 256 1048576]
 for {set i 0} {$i<100} {incr i} {set page [::GX::stderrDiagnostics request $token];if {[dict get $page state] ne {pending}} break;after 30;update}
 write [file join $output archive.tcldict] $page
 write [file join $output results.tcldict] $results
} finally {::GX::stderrDiagnostics stop}
