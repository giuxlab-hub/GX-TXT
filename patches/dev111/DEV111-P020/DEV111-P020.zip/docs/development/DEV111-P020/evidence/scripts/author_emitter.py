# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import sys,subprocess,os,json,hashlib,time
framework=Path(sys.argv[1]).resolve();root=Path(sys.argv[2]).resolve();root.mkdir(mode=0o700);project=root/'project';evidence=root/'evidence';evidence.mkdir();env=dict(os.environ)
for key in ['HOME','TMPDIR','XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME']:
 p=root/key.lower();p.mkdir(mode=0o700);env[key]=str(p)
env['PYTHONDONTWRITEBYTECODE']='1';cli=framework/'core/python/gxtxt_viewer_development.py'
def call(op,payload=b'',extra=()):
 cmd=['/usr/bin/python3','-I','-B',str(cli),op,str(project),*extra];now=time.monotonic();p=subprocess.run(cmd,input=payload,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=100)
 (evidence/(op+('-'+extra[-1] if op=='save' else '')+'.stdout')).write_bytes(p.stdout);(evidence/(op+('-'+extra[-1] if op=='save' else '')+'.stderr')).write_bytes(p.stderr);(evidence/(op+('-'+extra[-1] if op=='save' else '')+'.request')).write_bytes(payload);(evidence/(op+('-'+extra[-1] if op=='save' else '')+'.json')).write_text(json.dumps(dict(command=cmd,code=p.returncode,seconds=time.monotonic()-now,input_sha256=hashlib.sha256(payload).hexdigest()),indent=2)+'\n')
 if p.returncode:raise RuntimeError(p.stdout.decode(errors='replace')+p.stderr.decode(errors='replace'))
 return json.loads(p.stdout) if p.stdout else {}
call('init',extra=('--module-id','viewer.validation_stderr_emitter'))
call('grant',extra=('--','/usr/bin/true'))
s='// SPDX-License-Identifier: GPL-3.0-or-later\n#include <cstdio>\n#include <unistd.h>\nvoid on_event(gx::Host& host, gx::State& state, const gx::Event& event) {\n if (event.kind==gx::EventKind::open || event.kind==gx::EventKind::invoke) {\n  std::fprintf(stderr,"NATIVE_VIEWER_STDERR_SENTINEL PID=%ld\\nSTACK native second line\\n",(long)getpid());std::fflush(stderr);\n }\n if (event.kind==gx::EventKind::open) {host.demo(3,0);host.text(2,"Bounded actual native stderr fixture; no scientific operation.");}\n if (event.kind==gx::EventKind::invoke) {++state.counter;host.text(1,"Native event completed");host.text(2,"Native original stderr and typed callback remain live.");}\n}\n'
call('save',s.encode(),('--file','handlers.cpp'))
meta=json.loads((project/'project.json').read_text());meta['tests']['expected_values']={}
call('save',(json.dumps(meta)+'\n').encode(),('--file','project.json'))
result=call('build');(root/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
