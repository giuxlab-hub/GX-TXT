# S02 independent native Diagnostics qualification

SPDX-License-Identifier: GPL-3.0-or-later

Frozen source `4f9af368e8fdf57f418dadf84902bafd23d0175c`; all160 product manifest hashes and copied runtime files match (`SOURCE_PARITY.json`). No product changes.

| ID | Result | Observation |
| --- | --- | --- |
| D01 | PASS focused public API | No defaultOFF nativebackend load/logdir/tasks/timers/children; stable warm Tcl observer; statusIPC/writer/queue0 |
| D02 | NOTVERIFIED here | Actual Configuration GUI integration owned by MAIN2; public start/stop/reconfigure/rapidrestart exercised independently |
| D03 | PASS focused API | Exact rawbinary and explicit unknown metadata; bounded256records/1MiB, invalidbounds rejected; cursor-expiration; cancel race terminates done/cancelled |
| D04 | PASS | 2actualexternalCABIproducers+Tcl384events,128each; exactmultiline/NUL/UTF8bytes/perproducerorder/uniquegeneration:seq/PIDs,0drops |
| D05 | NOTVERIFIED here | Ordinary Builder/Development C++ DiagnosticsViewer GUI owned MAIN2; noGUIclaim from nativechild |
| D06 | NOTVERIFIED here | Viewerfilter/search/theme/pause actualGUI owned MAIN2 |
| D07 | PASS public API portion | Selective ID export exactserializedbytes; destinationcollisionrefused; OFF retainedboundedreader leavesarchiveunchanged; GUIchosenpath ownedMAIN2 |
| D08 | PASS | Scaled4096B*3 and defaults10485760B*5 includingcurrent; default1500*32768payload49152000bytes(46.875MiB),actualretentionevicted2files; eachfilebounded |
| D09 | PASS observed production pressure | Actualdefault8MiBring highwater8361374<=8388608,57ringdrop records;accepted1501=written1444+ringdrop57; helperSTOP transport2000emits536212us,1995rejects; no invented timingbudget |
| D10 | PASS | Actualnonrootmode0500EACCES precondition; collectortruthfulerror, nohang; insecurepermissions/symlinktests additionallypass privatefixturebinary |
| D11 | PARTIAL:productionEFBIG PASS;actualENOSPC/slowstorage NOTVERIFIED | Processlocal64KiBRLIMIT_FSIZE+ignoredSIGXFSZ causesrealproductionwriterFileTooLarge/diskdrop; separate matching-sourceprivatefixtureENOSPC/150mswriterdelayPASS. InjectedENOSPC is not actualfullfilesystem; delayfixture is not measuredphysicalslowstorage |
| D12 | PASS focused lifecycle | ActualownedhelperSIGKILL->error->restart;GUIdeathhelper/statuscleanup; constructed20bytepartialtailrecovery truthfullycounted. Noassertionrealappcrashcreatedthat20bytetrail |
| D13 | MEASURED native subset | 1500emitlatencydistribution plus2000saturatedcompletion; noabsoluteperformancepromise. RepresentativeCAD/Joboutputidentity ownedMAIN2/childCAD |

Production suites smoke/concurrency/producers and independent API/concurrent-native/EFBIG cases exited0. Matching-source private-fixture build/fault suite also exited0, kept separate from shipped binaries. Exact commands, environment, evidence, source/binary/script identities and reproduction are in `REPORT.json` and receipt JSONs.

Actual default rotation stimulus was49,152,000payloadbytes (46.875MiB), with JSONL/base64 overhead crossing retention boundaries. Default8MiB ring produced57 truthful ring drops and highwater8,361,374bytes. API accepted1501=written1444+ringdrop57. Oversize input separately counted one transport loss.

1500 measured emit samples: p50 252us, p95 325us, p99 375us, max491us. Stalled-helper2000attempts536,212us/1995rejects. These are measured facts, no absolute-budget or zero-overhead promise.

True production ENOSPC and physical slow-storage remain unverified. Real production EFBIG was generated using process-local64KiB RLIMIT_FSIZE with ignored SIGXFSZ; it is not ENOSPC. Separate private fixture compiled from identical source injects ENOSPC/150mswriter delay and passed; fixture controls are absent from production binary strings.

First independent01 observer failure retained: exec-cat counted itself and first Tcl update initialized notifier. Corrected independent02 warm observer/source audit shows no defaultOFF backend, helper, tasks/timers/children/logwrites. This was a harness correction, not a product change.

GUI/Config/managedJob original-stream qualification belongs to parent MAIN2. No GUI PASS is claimed by this child. No extra tests after Tcl-onlyS03 unless source changes justify them.
