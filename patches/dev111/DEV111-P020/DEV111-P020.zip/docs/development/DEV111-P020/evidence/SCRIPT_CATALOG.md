# Sanitized P020 validation helper catalog

SPDX-License-Identifier: GPL-3.0-or-later

Use a fresh private copied FRAMEWORK/runtime, NEW_OUTPUT and HOME/XDG/TMPDIR beneath an authorized validation root; umask0077. Never run fixtures against an installed or immutable framework: native scripts create sibling fixtures beside their runtime argument. No deployment, official installation, remote access or original user data is involved.

`gui_s04/scripts/s04_diagnostics.tcl FRAMEWORK NEW_OUTPUT` (420s/privateXvfb) and `s04_context.tcl FRAMEWORK NEW_OUTPUT` (180s) are exact executed S04 ordinary-provider native GUI actors; see their local catalog. They create only private runtime/profile/Session/log/export/evidence.

`cad_s03/scripts/s03_gui.tcl`, `workbench03.tcl`, `representative03.tcl FRAMEWORK NEW_OUTPUT` are version-scoped P020 S03 representative CAD GUI actors reused for unchanged S04 scientific owners; privateXvfb, explicit bounded outer timeout, all private synthetic outputs. They cover standard providers, oriented plane/save/reopen and constraints/Bezier respectively.

`scripts/author_emitter.py FRAMEWORK NEW_ROOT` uses public Development init/grant/save/build to create one ordinary private C++ fixture. `scripts/emitter_s03.tcl FRAMEWORK NEW_OUTPUT OWN_EMITTER_PROJECT` (360s/privateXvfb; S04 qualified) checks native capture ON→OFF via public Configuration Save and actual GUI events, fd/thread/original-stream/capture state. `emitter_off_s04.tcl` has identical arguments/bounds and checks coldOFF no optional route/control traffic.

`scripts/config_theme_s03.tcl FRAMEWORK NEW_OUTPUT` (420s/privateXvfb) checks native main Configuration Runtime controls/Tk callback routing and saves Appearance preference. `theme_restart.tcl FROZEN_RUNTIME NEW_OUTPUT OWN_PROFILE_DICT` (240s) performs documented normal restart and ordinary Diagnostics OFF consultation. All profiles/data are synthetic private outputs.

`scripts/jobs.tcl FROZEN_RUNTIME NEW_OUTPUT ?off|on|{off on}?` (180s) registers a tiny deterministic ordinary Python stdout/stderr fixture through public APIs, preserving source streams and archive bytes. ON waits for the collector to run before submitting. It is a transport/output-identity fixture, not a numerical-kernel benchmark.

`native/scripts/{smoke,concurrency,producers}.tcl RUNTIME` are production native public API/CABI suites (45/90s outer bounds per receipts). `independent.tcl RUNTIME NEW_OUTPUT` (120s), `concurrent_native.tcl RUNTIME NEW_OUTPUT` (45s) and `efbig.tcl RUNTIME NEW_OUTPUT` (30s) cover boundaries/rotation/pressure, concurrent exact-byte producers and real process-local EFBIG. `native_worker.py` is their fixed synthetic producer companion. `faults.tcl RUNTIME FIXTURE_LIBRARY` exercises matching-source private fault controls only; build via CMake GXDIAG_PRIVATE_FIXTURES=ON into a new private tree. Never claim injected ENOSPC/delay as physical production filesystem evidence. Production binaries contain no fixture controls.

Exact argv, source versions, side effects, environments, statuses and hashes are in the adjacent receipts. Each helper refuses existing outputs or uses unique owned fixture names. Cleanup affects only its own verified processes/private files; first failures are retained.
