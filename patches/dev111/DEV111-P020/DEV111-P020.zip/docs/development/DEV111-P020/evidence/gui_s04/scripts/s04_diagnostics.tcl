# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv framework output
if {[file exists $output]} {error {fresh output required}}
file mkdir $output;set output [file normalize $output]
foreach {key dir} {HOME home XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p020_diag_gui__
set catalog [file join $output framework];file mkdir $catalog
foreach name {core app services plugins gxtxt_pipeline.tcl} {file copy [file join $framework $name] [file join $catalog $name]}
file mkdir [file join $catalog docs];file copy [file join $framework docs help] [file join $catalog docs help]
source [file join $catalog gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {path value} {set f [open $path w];puts -nonewline $f $value;close $f}
proc pause {{ms 100}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {value name} {if {![uplevel 1 [list expr $value]]} {error "FAIL: $name"};lappend ::checks [list PASS $name];write [file join $::output checks.tcllist] $::checks;puts "PASS: $name";flush stdout}
set checks {};set errors {};set inputTrace {}
proc bgerror {msg} {lappend ::errors $msg;puts stderr "ORIGINAL-BGERROR:$msg"}
proc traceInput {cmd args} {if {[lindex $cmd 1] eq {xdotool}} {lappend ::inputTrace $cmd;write [file join $::output input.tcllist] $::inputTrace}}
trace add execution exec enter traceInput
proc widgets {w} {set all [list $w];foreach c [winfo children $w] {lappend all {*}[widgets $c]};return $all}
proc click {widget} {
 set top [winfo toplevel $widget];set scroll $top.body.inspector.scroll
 if {[winfo exists $scroll] && [string first "$scroll.content." $widget]==0} {
  for {set n 0} {$n<25} {incr n} {
   set cy [expr {[winfo rooty $widget]+[winfo height $widget]/2}];set lo [winfo rooty $scroll];set hi [expr {$lo+[winfo height $scroll]}]
   if {$cy>$lo+10 && $cy<$hi-10} break
   exec xdotool mousemove [expr {[winfo rootx $scroll]+5}] [expr {$lo+40}] click [expr {$cy<$lo?4:5}];pause 50
  }
 }
 check {[winfo viewable $widget]} "viewable $widget"
 exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1;pause 200
}
proc waitFor {test name {ms 15000}} {set until [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]] && [clock milliseconds]<$until} {pause 50};check [uplevel 1 [list expr $test]] $name}
proc observe {test name} {set ok [uplevel 1 [list expr $test]];lappend ::observations [list [expr {$ok?{PASS}:{FAIL}}] $name];write [file join $::output observations.tcllist] $::observations;puts "OBSERVE:[expr {$ok?{PASS}:{FAIL}}]:$name";flush stdout;return $ok}
set observations {}
proc dialogBegin {case target} {
 set ::dialogCase $case;set ::dialogTarget $target;set ::dialogDeadline [expr {[clock milliseconds]+20000}];set ::dialogState waiting
 after 50 dialogPoll
}
proc dialogPoll {} {
 if {$::dialogState ne {waiting}} return
 set found {}
 foreach top [widgets .] {if {[winfo toplevel $top] eq $top && [winfo viewable $top] && [string match {*Export selected STDERR*} [wm title $top]]} {set found $top;break}}
 if {$found ne {}} {
  set ::dialogState observed;set ::dialogObserved [clock milliseconds]
  write [file join $::output dialog-$::dialogCase-observed.tcldict] [dict create top $found title [wm title $found] widgets [widgets $found] observed $::dialogObserved]
  shot dialog-$::dialogCase
  after 700 [list dialogEmit $::dialogCase]
  after 2000 [list dialogAct $found $::dialogCase $::dialogTarget]
  return
 }
 if {[clock milliseconds]>$::dialogDeadline} {set ::dialogState timedout;lappend ::observations [list FAIL {nativeExportDialogNotObserved}];write [file join $::output observations.tcllist] $::observations;shot dialog-timeout;return}
 after 50 dialogPoll
}
proc dialogAct {top case target} {
 if {![winfo exists $top] || ![winfo viewable $top]} {set ::dialogState vanished;return}
 set ::dialogState acting
 write [file join $::output dialog-$case-hold.tcldict] [dict create observed $::dialogObserved action [clock milliseconds] held_ms [expr {[clock milliseconds]-$::dialogObserved}]]
 if {$target eq {CANCEL}} {
  set cancel $top.contents.f2.cancel
  if {[winfo exists $cancel] && [winfo viewable $cancel]} {click $cancel} else {exec xdotool key Escape}
  set ::dialogState cancelled;return
 }
 set entry $top.contents.f2.ent;check {[winfo viewable $entry]} {nativeSavefilenameentryvisible}
 click $entry;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $target;pause 100
 check {[$entry get] eq $target} {nativeSavefilenameexact}
 set ok $top.contents.f2.ok;check {[winfo viewable $ok]} {nativeSaveOKvisible};click $ok
 set ::dialogState saved
}
proc typeInto {widget text} {click $widget;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $text;exec xdotool key Tab;pause 180}
proc shot {label} {pause 100;exec timeout 8s import -silent -window root [file join $::output $label.png]}
proc component {id} {
 set row [dict get [::GX::viewerGuiRuntimeInspect $::w] components $id];set widget [dict get $row widget]
 if {[dict get $row type] in {field choice toggle}} {return $widget.entry}
 if {[dict get $row type] eq {table}} {return [::GX::uiFieldComponentTableWidget $widget]}
 return $widget
}
proc dump {label} {
 set log [component log];set tags {};foreach tag [$log tag names] {dict set tags $tag [list [$log tag ranges $tag] [$log tag cget $tag -foreground]]}
 write [file join $::output $label.tcldict] [dict create collector [::GX::stderrDiagnostics status] viewer [::GX::viewerGuiRuntimeInspect $::w] table [::GX::uiFieldComponentTableRead [component records]] log [$log get 1.0 end] tags $tags]
 shot $label
}

::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p020_diagnostics {} 0]
::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
check {[::GX::configurationGet preview.cache_enabled]==0 && [string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {private postSession cache guard}
package require Tk
set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 250
set w {}
proc emitMarker {marker} {
 ::GX::stderrDiagnostics emit [dict create source s04_gui_fixture module_id module.s04 api_id API_S04_v1 viewer_id viewer.s04 job_id job.synthetic process_id 41004 stream stderr severity info] [encoding convertto utf-8 $marker]
}
proc dialogEmit {case} {emitMarker "PENDING_MODAL_$case"}
set heartbeats {};set heartbeatAfter {};set latencies {}
proc heartbeat {} {lappend ::heartbeats [clock microseconds];set ::heartbeatAfter [after 50 heartbeat]}
proc markLatency {label started} {lappend ::latencies [dict create action $label elapsed_ms [expr {([clock microseconds]-$started)/1000.0}]];write [file join $::output latencies.tcllist] $::latencies}
proc tableText {} {return [::GX::uiFieldComponentTableRead [component records]]}
proc cacheText {} {return [[component cache_status] cget -text]}
proc rowSelect {index} {
 set records [component records];set item [lindex [$records children {}] $index];lassign [$records bbox $item] x y width height
 exec xdotool mousemove [expr {[winfo rootx $records]+$x+30}] [expr {[winfo rooty $records]+$y+$height/2}] click 1;pause 250
}
set heartbeatAfter [after 50 heartbeat]
try {
 wm title . {P020 S04 owned Diagnostics validation};wm geometry . 500x100+0+0
 file mkdir [file join $output stderr_logs];file attributes [file join $output stderr_logs] -permissions 0700
 ::GX::configurationSet diagnostics.stderr_log_directory [file join $output stderr_logs]
 ::GX::configurationSet diagnostics.stderr_capture_enabled 1
 ::GX::configurationSave {diagnostics.stderr_log_directory diagnostics.stderr_capture_enabled}
 waitFor {[dict get [::GX::stderrDiagnostics status] state] eq {running}} {trustedConfigSaveS04running}
 foreach marker {INITIAL_ALPHA INITIAL_BETA INITIAL_GAMMA} {emitMarker $marker}
 waitFor {[dict get [::GX::stderrDiagnostics status] written_records]>=3} {initial3captured}
 set w [::GX::viewerOpen viewer.stderr_diagnostics stderr_diagnostics {}]
 set until [expr {[clock milliseconds]+45000}];while {![dict exists $::GX::ViewerGui::instances $w] && [clock milliseconds]<$until} {pause 100}
 check {[dict exists $::GX::ViewerGui::instances $w]} {ordinaryS04DiagnosticsMounted};pause 500
 click [component refresh];set records [component records];waitFor {[llength [$records children {}]]==3} {initial3nativeRows}
 rowSelect 1;dump initial-selected
 set detailBefore [[component log] get 1.0 end]
 click [component pause];emitMarker PAUSED_SELECTED_4
 waitFor {[dict get [::GX::stderrDiagnostics status] written_records]>=4} {selectedPauseCapture4};pause 400
 check {[llength [$records children {}]]==3} {selectedPauseFreezes3rows}
 set started [clock microseconds];click [component pause]
 waitFor {[string first {Cached 4/} [cacheText]]>=0} {selectedUnpauseDrainsBacklogWithoutFutureNotification};markLatency selected-unpause $started
 check {[llength [$records children {}]]==3 && [[component log] get 1.0 end] eq $detailBefore} {selectedPageAndDetailsRetainedDuringFollow};dump selected-unpaused
 set started [clock microseconds];click [component next]
 waitFor {[string first PAUSED_SELECTED_4 [tableText]]>=0} {nativeNextExposesCapturedTail};markLatency next-tail $started;dump selected-next-tail
 # NativeNext navigates page2 and clears oldselection; withoutselection newestfollow becomesactive.
 check {[llength [$records selection]]==0} {nativePageNavigationClearedOldSelection}
 click [component pause];emitMarker PAUSED_UNSELECTED_5
 waitFor {[dict get [::GX::stderrDiagnostics status] written_records]>=5} {unselectedPauseCapture5}
 set started [clock microseconds];click [component pause]
 waitFor {[string first PAUSED_UNSELECTED_5 [tableText]]>=0} {unselectedUnpauseFollowsNewestPage};markLatency unselected-unpause $started;dump unselected-unpaused
 emitMarker LIVE_UNSELECTED_6
 waitFor {[string first LIVE_UNSELECTED_6 [tableText]]>=0} {liveAsyncTerminalDeliveryFollowsNewest};dump live-page4
 click [component previous];click [component previous];click [component previous]
 check {[string first {INITIAL_ALPHA} [tableText]]>=0} {nativePreviousReachesOldestOf4pages};dump oldest-page
 set started [clock microseconds];click [component latest]
 waitFor {[string first LIVE_UNSELECTED_6 [tableText]]>=0} {nativeLatestJumpsDirectlyToFinalOf4pages};markLatency latest-four-pages $started;dump latest-page
 rowSelect 0
 set selectedDetail [[component log] get 1.0 end]
 set target [file join $output selected.jsonl]
 dialogBegin successful $target;set started [clock microseconds];click [component export_selected]
 waitFor {[file exists $target]} {S04successfulNativeExport} 25000;markLatency modal-export $started
 waitFor {[string first PENDING_MODAL_successful [cacheText]]<0 && [dict get [::GX::stderrDiagnostics status] written_records]>=7} {captureDuringSuccessfulModal}
 # Selectedcurrentpage remainsvisible; Nextmustexposealreadycachedtail, not needanothernotification.
 pause 700;check {[[component log] get 1.0 end] eq $selectedDetail} {successfulModalFollowPreservesSelectionDetails};dump exported-selected
 set started [clock microseconds];click [component next]
 waitFor {[string first PENDING_MODAL_successful [tableText]]>=0} {successfulModalCompletionResumesBacklog};markLatency next-after-export $started;dump export-tail
 rowSelect 0
 dialogBegin cancelled CANCEL;click [component export_selected]
 waitFor {$::dialogState in {cancelled timedout vanished}} {S04nativeCancelDialogCompletes} 25000
 pause 700;dump cancelled-selected
 check {[string first {cancelled} [string tolower [cacheText]]]>=0 || [string first {End of retained snapshot} [cacheText]]>=0} {cancelTerminalNoticeTruthful}
 set started [clock microseconds];click [component next]
 waitFor {[string first PENDING_MODAL_cancelled [tableText]]>=0} {cancelledModalCompletionResumesBacklog};markLatency next-after-cancel $started;dump cancel-tail
 set runtime [dict get $::GX::ViewerDevelopment::windows $w]
 write [file join $output before-close-runtime.tcldict] $runtime
 set worker [dict get $runtime compiled_service_receipt pid]
 set ownedrequest [dict get $runtime compiled_service]
 write [file join $output before-close.tcldict] [dict create public [::GX::viewerGuiRuntimeInspect $w] diagnostics [::GX::stderrDiagnostics status] subscribers $::GX::StderrDiagnostics::subscribers timer $::GX::StderrDiagnostics::timer worker_pid $worker request $ownedrequest]
 exec xdotool windowfocus --sync [winfo id $w];exec xdotool key alt+F4
 waitFor {![winfo exists $w]} {normalWMClosesDiagnosticsViewer}
 pause 1500
 set alive [expr {![catch {exec kill -0 -- $worker}]}]
 write [file join $output after-close.tcldict] [dict create window_exists [winfo exists $w] instance_exists [dict exists $::GX::ViewerGui::instances $w] development_exists [dict exists $::GX::ViewerDevelopment::windows $w] subscribers $::GX::StderrDiagnostics::subscribers timer $::GX::StderrDiagnostics::timer worker_alive $alive request_exists [dict exists $::GX::scriptJobRequests $ownedrequest] diagnostics [::GX::stderrDiagnostics status]]
 check {![dict exists $::GX::ViewerGui::instances $w] && ![dict size $::GX::StderrDiagnostics::subscribers] && $::GX::StderrDiagnostics::timer eq {} && !$alive} {ViewerCloseReleasesSubscriptionTimerAndOwnedWorker}
 write [file join $output RESULT.txt] {AffectedS04nativeGUIcasesexecuted;inspectpixels/receiptsscopebeforequalification.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {dump failure};set exitStatus 1} finally {
 catch {after cancel $heartbeatAfter};write [file join $output heartbeat-us.tcllist] $heartbeats;write [file join $output latencies.tcllist] $latencies
 write [file join $output errors.tcllist] $errors
 catch {::GX::stderrDiagnostics stop};catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
if {[info exists exitStatus]} {exit $exitStatus};exit 0
