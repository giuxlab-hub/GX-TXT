# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv root out
file mkdir $out
source [file join $root core tcl stderr_diagnostics_v1.tcl]
proc waitfor {test} {set end [expr {[clock milliseconds]+10000}];while {![uplevel 1 [list expr $test]]} {if {[clock milliseconds]>$end} {error "timeout $test"};after 1;update}}
proc save {name value} {set f [open [file join $::out $name] w];puts $f $value;close $f}
proc ck {test label} {if {![uplevel 1 [list expr $test]]} {error $label}}
try {
 ::GX::stderrDiagnostics start [dict create log_directory [file join $out logs]]
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
 set cap [::GX::StderrDiagnostics::producerDescriptor]
 set worker [file join [file dirname [info script]] native_worker.py]
 foreach label {A B} {set pids($label) [exec python3 -B $worker $root [dict get $cap descriptor] [file join $out $label.json] $label >[file join $out $label.log] 2>@1 &]}
 set own {}
 for {set i 0} {$i<128} {incr i} {lappend own [::GX::stderrDiagnostics emit [dict create source T process_id [pid] operation $i] [encoding convertto utf-8 "T|$i\nline\0☃"]];after 1;update}
 waitfor {[file exists [file join $out A.json]] && [file exists [file join $out B.json]]}
 waitfor {[dict get [::GX::stderrDiagnostics status] pending_records]==0}
 set cursor {};set all {};set eof 0
 while {!$eof} {
  set token [::GX::stderrDiagnostics read $cursor 256 1048576]
  waitfor {[dict get [set page [::GX::stderrDiagnostics request $token]] state] ne {pending}}
  ck {[dict get $page state] eq {done}} {read failed}
  lappend all {*}[dict get $page result records];set cursor [dict get $page result cursor];set eof [dict get $page result eof]
 }
 set ids {};set indices {A 0 B 0 T 0}
 foreach rec $all {
  set source [dict get $rec origin source];set i [dict get $indices $source]
  ck {[dict get $rec payload] eq [encoding convertto utf-8 "$source|$i\nline\0☃"]} {payload/order mismatch}
  ck {[dict get $rec capture_pid] eq [dict get $rec origin process_id]} {capture/source PID mismatch}
  set id [dict get $rec record_id];ck {![dict exists $ids $id]} {duplicate stable ID};dict set ids $id 1
  dict incr indices $source
 }
 ck {$indices eq {A 128 B 128 T 128}} {lost producer events}
 ck {[dict get [::GX::stderrDiagnostics status] dropped_records]==0} {unexpected drops}
 save result.tcldict [dict create indices $indices status [::GX::stderrDiagnostics status] records $all]
 puts {PASS two concurrent actual CABI producers+Tcl384 exact ordered binary/multiline/PID records}
} on error {m opts} {save failure.tcldict [dict create message $m options $opts];puts stderr [dict get $opts -errorinfo];set failed 1} finally {catch {::GX::stderrDiagnostics stop}}
if {[info exists failed]} {exit 1}
