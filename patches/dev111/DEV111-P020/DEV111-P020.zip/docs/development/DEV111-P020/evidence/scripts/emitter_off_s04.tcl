# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv framework output emitterProject
if {[file exists $output]} {error {fresh output required}}
file mkdir $output;set output [file normalize $output]
foreach {key dir} {HOME home XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state GXTXT_INSTALLATION_ROOT installation GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE buffers GXTXT_JOB_ROOT jobs TMPDIR tmp} {set ::env($key) [file join $output $dir];file mkdir $::env($key);file attributes $::env($key) -permissions 0700}
set ::env(PYTHONDONTWRITEBYTECODE) 1;set argv0 __p020_diag_gui__
set catalog [file join $output framework];file mkdir $catalog
foreach name {core app services plugins gxtxt_pipeline.tcl} {file copy [file join $framework $name] [file join $catalog $name]}
file mkdir [file join $catalog docs];file copy [file join $framework docs help] [file join $catalog docs help]
source [file join $catalog gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
proc write {path value} {set f [open $path w];puts -nonewline $f $value;close $f}
proc pause {{ms 100}} {set ::waiting 1;after $ms {set ::waiting 0};vwait ::waiting;update idletasks}
proc check {value name} {if {![uplevel 1 [list expr $value]]} {error "FAIL: $name"};lappend ::checks [list PASS $name];write [file join $::output checks.tcllist] $::checks;puts "PASS: $name";flush stdout}
set checks {};set errors {};set inputTrace {}
proc bgerror {msg} {lappend ::errors $msg;puts stderr "ORIGINAL-BGERROR:$msg"}
proc traceInput {cmd args} {if {[lindex $cmd 1] eq {xdotool}} {lappend ::inputTrace $cmd;write [file join $::output input.tcllist] $::inputTrace}}
trace add execution exec enter traceInput
proc widgets {w} {set all [list $w];foreach c [winfo children $w] {lappend all {*}[widgets $c]};return $all}
proc click {widget} {check {[winfo viewable $widget]} "viewable $widget";exec xdotool mousemove [expr {[winfo rootx $widget]+[winfo width $widget]/2}] [expr {[winfo rooty $widget]+[winfo height $widget]/2}] click 1;pause 150}
proc typeInto {widget text} {click $widget;exec xdotool key Home shift+End BackSpace;exec xdotool type --clearmodifiers -- $text;exec xdotool key Tab;pause 180}
proc shot {label} {pause 100;exec timeout 8s import -silent -window root [file join $::output $label.png]}
proc component {id} {return [dict get [::GX::viewerGuiRuntimeInspect $::w] components $id widget]}
proc dump {label} {write [file join $::output $label.tcldict] [dict create collector [::GX::stderrDiagnostics status] viewer [::GX::viewerGuiRuntimeInspect $::w]];shot $label}
::GX::configurationSet storage.session_root [file join $output Sessions];::GX::configurationSet storage.temp_dir [file join $output tmp];::GX::configurationSave {storage.session_root storage.temp_dir}
set session [::GX::createNewSession p020_diagnostics {} 0]
::GX::datasetPreviewCacheInit;::GX::configurationSet preview.cache_enabled 0
check {[::GX::configurationGet preview.cache_enabled]==0 && [string match "${output}/*" [::GX::datasetPreviewCacheRoot $session]]} {private postSession cache guard}
package require Tk
set wmPids [exec xfwm4 --replace --compositor=off --sm-client-disable >[file join $output wm.log] 2>@1 &];pause 250
set w {}

proc waitFor {test name {ms 15000}} {set until [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]] && [clock milliseconds]<$until} {pause 50};check [uplevel 1 [list expr $test]] $name}
proc workerState {label worker} {
 write [file join $::output $label.tcldict] [dict create worker_pid $worker fd2 [file readlink /proc/$worker/fd/2] tasks [glob /proc/$worker/task/*] runtime [dict get $::GX::ViewerDevelopment::windows $::w] collector [::GX::stderrDiagnostics status]]
 shot $label
}

set controlPackets {}
proc controlTrace {command args} {if {[string first diagnostics_stop $command]>=0} {lappend ::controlPackets $command;write [file join $::output diagnostic-control-packets.tcllist] $::controlPackets}}
trace add execution ::GX::scriptJobRequestSend enter controlTrace
try {
 wm withdraw .
 check {[::GX::configurationGet diagnostics.stderr_capture_enabled]==0} {coldprofile capture defaultOFF}
 ::GX::configurationSave {diagnostics.stderr_capture_enabled}
 check {![llength [info commands ::GX::StderrDiagnostics::_native]]} {defaultOFF Tclcollectorbackend remainsunloaded}
 set w [::GX::viewerDevelopmentPreview $emitterProject];wm geometry $w 1400x950+40+20;raise $w
 waitFor {[dict exists $::GX::ViewerGui::instances $w] && [dict exists $::GX::ViewerDevelopment::windows $w compiled_service_receipt]} {defaultOFF ordinaryemitter mounts} 60000
 waitFor {[dict get $::GX::ViewerDevelopment::windows $w status] eq {COMPLETED}} {defaultOFF opening callback completes}
 set ready [dict get $::GX::ViewerDevelopment::windows $w compiled_service_receipt];set worker [dict get $ready pid]
 check {![dict get $ready stderr_diagnostics_active]} {defaultOFF workerREADY reports nocapture}
 set f [open /proc/$worker/environ rb];set envBytes [read $f];close $f
 check {[string first GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR= $envBytes]<0} {defaultOFF worker has no descriptor}
 set f [open /proc/$worker/maps r];set maps [read $f];close $f
 check {[string first gxdiagnostics.so $maps]<0} {defaultOFF worker has no nativecollectorlibrary}
 check {![string match {pipe:*} [file readlink /proc/$worker/fd/2]]} {defaultOFF stderr goesdirectlyoriginalfile}
 check {[llength [glob /proc/$worker/task/*]]==1} {defaultOFF worker has no extra readerthread}
 workerState default-off-ready $worker
 set action [dict get [::GX::viewerGuiRuntimeInspect $w] components advance widget]
 click $action;waitFor {[dict get $::GX::ViewerDevelopment::windows $w state counter]==1} {defaultOFF actualnativeevent completes}
 ::GX::configurationSave {diagnostics.stderr_capture_enabled}
 pause 500
 click $action;waitFor {[dict get $::GX::ViewerDevelopment::windows $w state counter]==2} {sameOFF worker remainsusable after idempotentSave}
 check {$controlPackets eq {}} {defaultOFF sends no diagnosticcontroltraffic}
 check {![file exists [::GX::configurationGet diagnostics.stderr_log_directory]]} {defaultOFF creates no diagnosticlogdirectory}
 check {![llength [info commands ::GX::StderrDiagnostics::_native]]} {normalOFF events leave Tclbackendunloaded}
 set f [open [file join $emitterProject derived native-output.log] rb];set original [read $f];close $f
 write [file join $output original-native-output.log] $original
 write [file join $output diagnostic-control-packets.tcllist] $controlPackets
 workerState default-off-final $worker
 write [file join $output RESULT.txt] {PASS focused cold-defaultOFF nativePreview ordinaryevents/no optional route or controltraffic.}
} on error {message options} {puts stderr [dict get $options -errorinfo];catch {write [file join $output failure-runtime.tcldict] [dict get $::GX::ViewerDevelopment::windows $w]};catch {shot failure};set exitStatus 1} finally {
 write [file join $output errors.tcllist] $errors
 catch {::GX::stderrDiagnostics stop};catch {destroy .};foreach pid $wmPids {catch {exec kill -TERM -- $pid}}
}
if {[info exists exitStatus]} {exit $exitStatus};exit 0
