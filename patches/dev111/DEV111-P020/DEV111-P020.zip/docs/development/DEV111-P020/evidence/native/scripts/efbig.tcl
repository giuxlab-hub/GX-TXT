# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv root out
file mkdir $out
source [file join $root core tcl stderr_diagnostics_v1.tcl]
proc waitfor {test} {set end [expr {[clock milliseconds]+10000}];while {![uplevel 1 [list expr $test]]} {if {[clock milliseconds]>$end} {error "timeout $test"};after 2;update}}
try {
 ::GX::stderrDiagnostics start [dict create log_directory [file join $out logs]]
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
 for {set n 0} {$n<16} {incr n} {::GX::stderrDiagnostics emit {source efbig} [string repeat x 32768];after 2;update}
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
 set status [::GX::stderrDiagnostics status];set f [open [file join $out status.tcldict] w];puts $f $status;close $f
 if {![string match {*File too large*} [dict get $status last_error]] || [dict get $status disk_dropped_records]==0} {error {EFBIG not truthfully reported}}
 puts {PASS production writer EFBIG error and disk-drop accounting (not ENOSPC)}
} finally {catch {::GX::stderrDiagnostics stop}}
