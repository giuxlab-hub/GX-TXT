# Native build and public authoring identity

SPDX-License-Identifier: GPL-3.0-or-later

The shipped Linux x86-64 components are ready to run; startup invokes no compiler.
The new diagnostics owner builds from its own small CMake project:

```sh
cmake -S core/diagnostics -B BUILD/diagnostics -DCMAKE_BUILD_TYPE=Release
cmake --build BUILD/diagnostics -j2
cmake --install BUILD/diagnostics --prefix FRAMEWORK
```

`GXDIAG_PRIVATE_FIXTURES` defaults OFF. Production adapter and helper share the
same protocol header and producer implementation. Native independent checks
also build explicit private fault binaries from these exact sources; those do
not replace or enter the distributed production bin directory.

The Native3D change extends the existing gx3de_viewer_tcl target with existing
scientific polydata point/polyline cells. It preserves triangles, the scientific
geometry library and the rendering backend. CMake already owns that source;
validation/dev111_p020/build_native3d.py records the targeted adapter compilation
against the existing packaged library and Tcl8.6, with source/binary hashes.
The P019 Native2D C/C++, grid, sprites, CAD controller and History binaries remain
byte-identical. No new geometry or rendering engine is introduced.

All four authored Viewer packages (three new consumers and updated Scientific
3D Workbench) retain public Builder design, Development C++ source, exact API
admission/grants, build/validation review and binary provenance. They were built
and exported through the existing public owners. The additive SDK preserves old
Event/State/Host storage and existing entries; its typed context entry and finite
new operations do not expose arbitrary Tcl evaluation, Tk pointers or file reads.
An unchanged P019 admitted artifact was checked for ABI compatibility.

BUILD_IDENTITY.json and the final pre/post change manifest bind the shipped bytes.
The final Git source commit is recorded in SOURCE.json at package construction;
archives carry their own SHA-256 sidecars without a self-referential source hash.
