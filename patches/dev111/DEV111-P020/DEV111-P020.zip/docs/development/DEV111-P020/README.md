# GX-TXT DEV111-P020

SPDX-License-Identifier: GPL-3.0-or-later

Incremental overlay for the accepted DEV111-P019 cumulative framework. Linux
x86-64 native binaries and matching sources are included. Restart GX-TXT after
applying. This delivery does not install or activate itself.

From the target framework root, with GX-TXT closed:

```sh
unzip -o /srv/gxtxt/releases/dev111/patches/0020-cad-sketch-stderr-diagnostics/DEV111-P020.zip
```

The patch adds exact managed Sketches with an oriented Native3D context, shared
CAD menus/icons and two ordinary TEST Viewers. The normal Scientific 3D Workbench
has a Sketch menu. The third new ordinary Viewer is STDERR Diagnostics.

Optional capture is **OFF by default**. Open Configuration → Runtime → Process
diagnostics to select its one global directory and limits, then Save. Opening a
Diagnostics Viewer never turns capture on. Existing mandatory Job logs remain.

Use the existing Modules/Plugin Manager and Viewer menu to open Test CAD 1,
Test CAD 2 and STDERR Diagnostics Viewer. Each package includes its manual,
Builder design, C++17 source, build/review provenance and admitted native binary.
These TEST CAD Viewers are permanent integration consumers, not production
scientific applications.

Guarded rollback (GX-TXT closed):

```sh
python3 patch_notes/DEV111-P020/rollback.py .
```

Rollback first verifies every exact P020 postimage and P019 preimage. It refuses
modified or later-patched files. It does not remove user-created Documents,
preferences or diagnostics. Existing 3D interface Workspaces have an intentional
source-identity compatibility boundary; see KNOWN_LIMITATIONS.md before replacing
an earlier generated Viewer. Never overwrite original scientific data to bypass
that boundary.

See FINAL_HANDOFF.md, VALIDATION_REPORT.md, PERFORMANCE_REPORT.md and
BUILD_IDENTITY.json. User VNC acceptance remains open; no TODO is marked complete.
