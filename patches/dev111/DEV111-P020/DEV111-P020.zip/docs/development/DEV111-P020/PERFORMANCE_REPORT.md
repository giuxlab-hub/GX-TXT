# P020 measured performance and overload

SPDX-License-Identifier: GPL-3.0-or-later

These are scoped observations, not zero-overhead or general performance claims.
Native production counters and exact source/binary identities accompany the
independent reports. The table below retains S02/S04 measurements of unchanged
ingestion/GUI paths; the final rebuilt S05 native measurements follow separately. GUI observations use ordinary admitted C++ Viewers and actual
X11 inputs; their timing includes the existing managed callback boundary.

| Observation | Actual result | Scope |
| --- | --- | --- |
| Registered numerical Job OFF | 4.8111059666s | launch→first terminal, one retained diagnostic.log sample |
| Same deterministic workload ON | 5.1820993423s | one ready-collector sample, exact stdout/stderr preserved |
| Native emit,1500 calls | p50 252µs, p95 325µs, p99 375µs, max491µs | measured raw production submission, not disk durability |
| Default rotation stimulus | 49,152,000 raw bytes /46.875MiB |1500×32768 plus terminal accounting event; JSON/base64 adds disk overhead |
| Default ring pressure | highwater8,361,374 ≤8,388,608bytes |1501 accepted=1444 written+57 ring drops; no hidden loss |
| Default retention |2 whole-file evictions |10MiB×5 global files including current; each bounded |
| Stopped-helper transport |2000 attempts in536,212µs,1995 rejects | real nonblocking transport saturation, optional loss counted |
| Concurrent source roundtrip |384 exact events,0drops |2external producers+Tcl, per-producer order and PID separation |
| GUI50ms heartbeat |279 samples; median50.0885ms, p95~304.324ms, max719.953ms | one affected S04 run including startup/screenshots/modal loops |
| GUI unpause observed | selected387.053ms, unselected396.652ms | single samples, includes input/actor settling |
| GUI Next/Latest observed |420.923/310.318ms | bounded cached/read navigation, single samples |
| GUI ordinary callback |~101–159ms in recorded controls | synchronous command scope, excludes later paint/async work |

The Job samples include process/startup differences; their difference is not a
causal overhead estimate. The GUI heartbeat/latency values are not proof of a
sub-100ms response guarantee. Native async disk work prevents rotation from
running in Tk, but the existing admitted C++ event bridge still incurs measurable
callback latency. Export callbacks include the intentionally held user dialog:
3.7415s successful and2.6582s cancelled; these are not disk-only measurements.

No diagnostic helper, queue, third channel or diagnostic poll exists for a fresh
OFF scientific launch. An explicit OFF retained reader/export is permitted and
has its own bounded native task. ON producers never retry a saturated optional
transport. Every normal stream keeps its original owner; disk/helper failure
becomes diagnostic state rather than a scientific Job failure.

Actual EACCES and EFBIG were exercised. Injected ENOSPC and150ms writer delay
verify error/queue policy in a separate same-source build. True ENOSPC and actual
slow physical storage remain NOT VERIFIED. Do not extrapolate the measured emit
latencies to arbitrary workloads or assume lossless capture during overload.

No new rendering-performance target is claimed for CAD. P019 Native2D/Cairo/grid/
scheduler/History are unchanged. The new oriented context is a bounded visual
projection and does not replace exact Sketch definitions or Dataset rows.


## Final S05 production-binary follow-up

After the fresh-directory correction and matching rebuild, one independently
measured1500×32768-byte burst submitted/wrote all1500 records (49,152,000bytes),
with0drops, ring highwater221,124bytes of8,388,608 and2retention evictions.
Emit p50=272µs,p95=347µs,p99=384µs,max513µs. This is a current-binary single run,
not evidence of an ingestion speedup or a lossless guarantee. Earlier deliberate
pressure/drop evidence is retained separately; queue occupancy depends on actual
producer/writer progress. The source change affects native directory creation,
not packet, ring, write, rotation or counter algorithms. Source/binary identity,
raw counters and scope are in evidence-s05/CURRENT_NATIVE_PERFORMANCE.json.
The actual normal Runtime GUI fresh-default ON/OFF check passes without manual
parent creation. OFF configure/meta remain noncreating. Current intermediate
symlink/insecure-final/EACCES rejection and external producer bytes/PIDs pass.
