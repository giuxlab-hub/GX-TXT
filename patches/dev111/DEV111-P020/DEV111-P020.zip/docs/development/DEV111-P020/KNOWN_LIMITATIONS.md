# P020 boundaries and remaining verification

SPDX-License-Identifier: GPL-3.0-or-later

- Scientific editing uses the exact local-plane surface in the managed Sketch;
  the adjacent oriented Native3D context supports camera navigation and live
  projected geometry. It does not claim direct picking of defining controls in
  the 3D context. Its bounded display sampling is not canonical geometry.
- Existing 0.1.7 Scientific 3D Workbench interface Workspaces cannot be silently
  upgraded across changed C++ source identity by the existing public authoring
  contract. Original canonical 3D Documents remain intact and can be opened in
  0.1.8; newly saved 0.1.8 interface Workspaces reopen through the normal owner.
- Builder synthetic demo shows a layout placeholder for a scientific Sketch;
  Preview/runtime in an isolated active Session supplies exact editable geometry.
- The finite shared action catalog exposes supported P019 native operations.
  Unsupported constraint/topology combinations are rejected by their native
  owner; no new solver or rigid constituent-editing semantics are invented.
- Diagnostics capture applies to subsequently launched managed processes after
  its service is ready. Already merged stdout/stderr cannot be separated
  retrospectively. No retroactive claim is made for older running processes.
  Disabling capture immediately revokes the global generation; an opted-in native
  worker retires its fd2 route after its current bounded event. Original streams
  and mandatory Job logs retain their existing owners.
- Origins are actual supplied metadata or `unknown`. A descendant sharing an
  inherited stderr descriptor cannot always be identified per message. The known
  stream owner PID and actual capture PID remain distinct. STDERR is not assumed
  to mean error; uncertain Viewer classifications are visibly inferred.
- The Diagnostics Viewer bounds its cache to four pages / 1024 records / 4MiB.
  Search and filters apply to its current cached page. Next and Latest navigate
  bounded pages; paused capture can continue, and resume follows the saved cursor.
  Rotation may expire a cursor, reported explicitly rather than silently skipping.
- Explicit export preserves original structured records and requires a new file
  name. An existing destination is refused. Copy is a UTF-8 presentation of the
  selected original payload. Retained files remain readable with capture OFF.
- Native production EACCES and EFBIG failure checks were exercised. Actual full
  filesystem ENOSPC and physical slow-storage behavior are NOT VERIFIED. Separate
  matching-source fault builds exercise injected ENOSPC and writer delay; those
  binaries and their switches are not distributed as production artifacts.
- Overload intentionally drops optional records with counters. Completed writes
  do not promise per-record fsync durability. Shutdown is bounded rather than a
  slow-disk drain; interrupted losses are reported.
- The user withdrew the intermittent Show dimensions investigation. P020 contains
  no speculative visibility correction and makes no claim that this issue is fixed.
- No Windows remote-X11 campaign or P019 historical regression campaign was run.
  P019 user acceptance is preserved. Final P020 visual acceptance remains the
  user's supported Linux/VNC test; this patch is NOT INSTALLED automatically.
