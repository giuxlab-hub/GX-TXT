# S05 native directory regression

PASS (exit0) on frozen 4b67d82db7fb50683ecdd145301f422ef05fd639.

- OFF configure and explicit bounded metadata read leave missing nested path absent.
- ON creates all missing components0700/currentUID.
- Intermediate symlink, insecure final directory and actual EACCES reject truthfully.
- Actual external C ABI bytes/sourcePID/capturePID are exact.
- Scaled4096B×3 and default10MiB×5 retention remain bounded.

All254 source manifest hashes and runtime hashes match; Within the copied native Diagnostics component, S04→S05 changes are exactly protocol.h and two binaries. Full snapshot has other owner final documentation/evidence and Viewer design changes outside this test scope.

One1500×32768B burst emit latencies: {'count': 1500, 'unit': 'microseconds', 'p50': 272.0, 'p95': 347, 'p99': 384, 'maximum': 513}. Measured facts only.

Structured source/test/counter receipts: RECEIPT.json and SOURCE_PARITY.json. Clean review whitelist: WHITELIST.json.
