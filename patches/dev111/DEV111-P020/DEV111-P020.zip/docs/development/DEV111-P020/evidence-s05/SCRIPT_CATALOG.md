# S05 scoped validation append catalog

SPDX-License-Identifier: GPL-3.0-or-later

`scripts/default_directory_s05.tcl FRAMEWORK NEW_OUTPUT`:420s privateXvfb actual main Runtime default-path OFF→ON→OFF test. Uses fresh private HOME/XDG/cache/resource/Session/runtime roots, asserts cacheOFF afterSession setup, never browses/customizes/precreates the capture path; verifies new0700/currentUID parents and genuine callback/handler/record/idleOFF state. Only NEW_OUTPUT synthetic files/processes are affected. Never point at an installed or original user framework.

`native/test.tcl COPIED_RUNTIME NEW_OUTPUT`:60s bounded native missing-nested-path/OFFread/noncreation and ONsecurecreation/rejections, one external fixedCABI byte/PID case, scaledrotation and one1500-event default-retention burst. Requires a fresh private S05 runtime copy with matching adapter/helper and shipped producer_worker.py. See native/SCRIPT_CATALOG.md and native/RECEIPT.json for exact arguments, hashes, environment and side effects. No broad fault/concurrency rerun, installation, deployment or external data.

Only WHITELIST.json entries are approved for export; S04 handoff is separate and immutable.
