# S05 narrow diagnostics directory regression

SPDX-License-Identifier: GPL-3.0-or-later

Frozen source4b67d82db7fb50683ecdd145301f422ef05fd639 only. All writes in s05.
`test.tcl RUNTIME NEW_OUTPUT`: production native dispatcher tests missing nested
default-shaped path OFF configure/explicitmeta noncreation, ON0700componentcreation,
symlink/insecurefinal/EACCES rejection; one actual external CABI byte/PID check,
scaled4096B*3rotation, then1500*32768B default10MiB*5burst with counters/timings.
Timeout60s, private logs/tmp/HOME only; no source edits, install or fault matrix.
Runtime copies core/diagnostics and stderr_diagnostics_v1.tcl; copied productworker
binary mode used for finite C ABI corpus. No GUI/Session/userdata fixture involved.
Evidence whitelist: SCRIPT_CATALOG.md,test.tcl,RECEIPT.json,SOURCE_PARITY.json,
SUMMARY.md,run.log,out/*.tcldict,out/latency-us.tcllist only. Raw log payload files
are synthetic and retained locally, optional review only; runtime/build trees are
not delivery artifacts. No material from other tasks is included.
