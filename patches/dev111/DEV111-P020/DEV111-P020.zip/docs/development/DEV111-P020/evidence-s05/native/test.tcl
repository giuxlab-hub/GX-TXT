# SPDX-License-Identifier: GPL-3.0-or-later
lassign $argv root out
if {[file exists $out]} {error {fresh output required}}
file mkdir $out;file attributes $out -permissions 0700
source [file join $root core tcl stderr_diagnostics_v1.tcl]
proc save {name value} {set f [open [file join $::out $name] w];puts $f $value;close $f}
proc ck {test name} {if {![uplevel 1 [list expr $test]]} {error "FAIL $name"};lappend ::checks $name;save checks.tcllist $::checks}
proc waitfor {test {ms 10000}} {set end [expr {[clock milliseconds]+$ms}];while {![uplevel 1 [list expr $test]]} {if {[clock milliseconds]>$end} {error "timeout $test;[::GX::stderrDiagnostics status]"};after 2;update}}
proc done {token} {waitfor {[dict get [set result [::GX::stderrDiagnostics request $token]] state] ne {pending}};return $result}
proc stop {} {::GX::stderrDiagnostics stop;waitfor {[dict get [::GX::stderrDiagnostics status] helper_pid]==0}}
set checks {}
try {
 set parent [file join $out missing_state]
 set path [file join $parent gxtxt_pipeline diagnostics stderr]
 ::GX::stderrDiagnostics configure [dict create log_directory $path]
 ck {![file exists $parent]} off_config_no_creation
 set meta [done [::GX::stderrDiagnostics meta]];save off-meta.tcldict $meta
 ck {[dict get $meta state] eq {done} && [llength [dict get $meta result files]]==0 && ![file exists $parent]} explicit_off_reader_no_creation
 ck {[dict get [::GX::stderrDiagnostics status] helper_pid]==0 && [dict get [::GX::stderrDiagnostics status] capture_ipc]==0} off_no_capture
 ::GX::stderrDiagnostics start
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
 set modes {};set p $parent
 foreach component {{} gxtxt_pipeline diagnostics stderr} {
  if {$component ne {}} {set p [file join $p $component]}
  lappend modes [list $p [file attributes $p -permissions] [file attributes $p -owner]]
  ck {([file attributes $p -permissions]&0777)==0700 && [file attributes $p -owner] eq $::tcl_platform(user)} new_component_private_mode_owner
 }
 save created-components.tcllist $modes
 set cap [::GX::StderrDiagnostics::producerDescriptor]
 set external [exec python3 -B [file join $root core diagnostics tests producer_worker.py] binary [dict get $cap library] [dict get $cap descriptor]]
 save external-cabi.tcldict $external
 ck {[dict get $external attach]==0 && [dict get $external result]==0} external_actual_cabi_emit
 waitfor {[dict get [::GX::stderrDiagnostics status] written_records]>=1}
 set page [done [::GX::stderrDiagnostics read {} 1 1048576]];save external-read.tcldict $page
 set rec [lindex [dict get $page result records] 0]
 ck {[binary encode hex [dict get $rec payload]] eq {00ff0a55544638e298830d0a}} exact_external_bytes
 ck {[dict get $rec capture_pid]==[dict get $external capture_pid] && [dict get $rec origin process_id]==[dict get $external source_pid] && [dict get $rec capture_pid]!=[pid]} truthful_external_pids
 stop

 # Brief scaled retention through the new creating path.
 set scaled [file join $out scaled missing logs]
 ::GX::stderrDiagnostics start [dict create log_directory $scaled max_file_bytes 4096 max_files 3]
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
 for {set i 0} {$i<60} {incr i} {::GX::stderrDiagnostics emit {source s05-scaled} "record$i [string repeat x 100]";after 1;update}
 waitfor {[dict get [::GX::stderrDiagnostics status] pending_records]==0}
 set meta [done [::GX::stderrDiagnostics meta]];save scaled-meta.tcldict $meta
 ck {[dict get $meta state] eq {done} && [llength [dict get $meta result files]]<=3} scaled_retention_count
 foreach f [dict get $meta result files] {ck {[dict get $f bytes]<=4096} scaled_file_bound}
 stop

 foreach mode {symlink insecure permission} {
  switch $mode {
   symlink {set target [file join $out symlink_target];file mkdir $target;set link [file join $out symlink_component];file link -symbolic $link $target;set bad [file join $link nested stderr]}
   insecure {set bad [file join $out insecure];file mkdir $bad;file attributes $bad -permissions 0777}
   permission {set denied [file join $out denied];file mkdir $denied;file attributes $denied -permissions 0500;ck {[catch {file mkdir [file join $denied probe]}]} eacces_precondition;set bad [file join $denied nested stderr]}
  }
  ::GX::stderrDiagnostics start [dict create log_directory $bad]
  waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {error}}
  save reject-$mode.tcldict [::GX::stderrDiagnostics status]
  ck {[dict get [::GX::stderrDiagnostics status] last_error] ne {}} "reject_${mode}_truthful_error"
  stop
 }
 ck {![file exists [file join $target nested]]} symlink_not_traversed
 file attributes $denied -permissions 0700

 # One finite current-production default burst, without a broad stress campaign.
 set default [file join $out default_burst logs]
 ::GX::stderrDiagnostics start [dict create log_directory $default max_file_bytes 10485760 max_files 5 ring_bytes 8388608]
 waitfor {[dict get [::GX::stderrDiagnostics status] state] eq {running}}
 set latencies {};set rejected 0;set payload [string repeat z 32768]
 for {set i 0} {$i<1500} {incr i} {
  set t [clock microseconds];set result [::GX::stderrDiagnostics emit [dict create source s05-default operation $i] $payload];lappend latencies [expr {[clock microseconds]-$t}]
  if {![dict get $result accepted]} {incr rejected}
  if {$i%8==7} {after 2;update}
 }
 waitfor {[dict get [::GX::stderrDiagnostics status] pending_records]==0} 20000
 save default-status.tcldict [::GX::stderrDiagnostics status];save latency-us.tcllist $latencies
 save submissions.tcldict [dict create attempted 1500 payload_bytes 49152000 rejected $rejected]
 set meta [done [::GX::stderrDiagnostics meta]];save default-meta.tcldict $meta
 ck {[dict get $meta state] eq {done} && [llength [dict get $meta result files]]<=5} default_retention_count
 foreach f [dict get $meta result files] {ck {[dict get $f bytes]<=10485760} default_file_bound}
 ck {[dict get [::GX::stderrDiagnostics status] queue_high_water_bytes]<=8388608} ring_stays_bounded
 stop;save final-status.tcldict [::GX::stderrDiagnostics status]
 puts {PASS S05 native nestedON creation/OFF noncreation/rejections/externalCABI/scaled+defaultrotation}
} on error {m opts} {save failure.tcldict [dict create message $m options $opts status [::GX::stderrDiagnostics status]];puts stderr [dict get $opts -errorinfo];set failed 1} finally {catch {stop}}
if {[info exists failed]} {exit 1}
