# S05 qualification append

SPDX-License-Identifier: GPL-3.0-or-later

Frozen `4b67d82db7fb50683ecdd145301f422ef05fd639`: the affected default-directory correction passed. S04 evidence remains separately preserved and is reused only within the explicit parity ledger.

The normal Runtime GUI, on a fresh profile with its unchanged builtin nested log path, starts OFF without a directory/helper/backend. Actual checkbox SaveON creates every missing application component as real0700/current-UID directories. A genuine callback error reaches the original handler and new log. Actual checkbox SaveOFF retires the writer/IPC, restores the handler and makes no idle archive writes. Both ON and OFF pixels were inspected, with the main interface still visible.

Native OFF configure and explicit bounded metadata reads are noncreating. ON nested creation, intermediate symlink/insecure-final/actual EACCES rejection, external C ABI exact bytes/source/capture PIDs and scaled/default rotation passed. Current production burst1500×32768B accepted and wrote all1500 records, zero drops; high-water221124B, retention evicted2files. Emit p50 272µs/p95 347µs/p99 384µs/max513µs are one-run facts, not an overhead estimate.

Within native Diagnostics only protocol.h and its two matching production binaries changed. The other final source differences are the separately owner-qualified demo-only Builder branch, inventory and documentation/evidence. Scientific CAD reuse compares171 identical files plus one explicitly changed checksum inventory; managing workers and Diagnostics adapters match S04 exactly. No CAD/Viewer/native fault matrix was repeated. Prior physical full-filesystem ENOSPC and physical slow-storage limitations remain explicit.

This append contains only whitelisted scoped code/catalogs, structured source/result/performance receipts and two selected synthetic GUI PNGs. No Session/runtime trees, raw data archives or unrelated material are included. MAIN1 alone owns final gate, acceptance and corrected candidate deposition.
