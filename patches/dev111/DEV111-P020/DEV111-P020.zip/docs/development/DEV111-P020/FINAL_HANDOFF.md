# GX-TXT DEV111-P020 final handoff

SPDX-License-Identifier: GPL-3.0-or-later

## 1. Source baseline verification

Delivered P019: commit248cd71edaaae1b76810528de69f6eed23fb482c,
8,972,405bytes, SHA-256
59e6579030c68548b3e76f750f048d356a5503fc4f5342960402c7f9f1679c55.
All425 manifest postimages and23,747 filesystem files were verified before the
proper isolated P020 Git worktree was created. P019 is user-installed, thoroughly
tested and accepted; its original release/history remain unchanged.

## 2. MAIN1 / MAIN2 / subagent work summary

MAIN1 implemented/integrated SDK/Builder/host/managed-process adapters, native3D
build, Configuration, docs and packaging, and reviewed actual evidence.
Specialists separately owned the managed CAD component, C++ diagnostics owner and
public-authored Viewer packages. MAIN2 ran the requested gpt-6.1-sol low with its
own children, immutable source copies and scratch-only writes; it independently
found genuine integration defects and qualified their focused corrections.
There was no shared-tree concurrent development or automatic validator approval.

## 3. CAD integration delivered

`nativeCadSketchCreate parent ?options?` embeds exact shared P019 CAD interaction
and an oriented live Native3D context. Its managed object owns native widget/
presentation resources; Native2D C owns exact geometry and constraints, Native3D
plane_frame owns local/world conversion, Interactive Documents and P017 own state
and History. Exact edits/constraints/dimensions/UndoRedo/Save/reopen are active.
Scientific 3D Workbench0.1.8 and legacy Workbench0.3.2 expose Create/Open/Close
Sketch on the actual working plane and retain Document associations.

## 4. Shared CAD contextual API changes

NATIVE2D_API_v1 gains the managed Sketch and `native2DCadActions`,
`native2DCadActionState`, `native2DCadActionInvoke`. Existing ViewerCommands,
shared icon catalog, UI Field and ViewportHost own menus/palettes/panels. A finite
40-action presentation catalog invokes the same advanced controller. Viewer
menus/context menus/toolbars and Canvas-owned controls are combinable, with
consistent enabled/checked facts. No separate controller or icon registry.

## 5. Test CAD 1 and Test CAD 2

Two permanent ordinary GPL-3.0-or-later TEST packages, public Builder designs,
admitted C++17 Development sources/binaries and normal providers. CAD1 owns its
menus/context popup/toolbar/palette and a custom TEST command. CAD2 delegates its
Sketch tools panel and full context catalog to the Canvas. Both are functional
and actual-GUI tested; neither imports Curve Workbench internals.

## 6. Diagnostic collector architecture

One opt-in C++ helper uses nonblocking credential-checked UNIX datagrams, a bounded
byte ring and a separate disk writer. One global rotation chain, status/counters
and generation identities serve all origins. No Job scheduler or scientific store
is added. Trusted managed owners duplicate only genuine separate stderr and
retain original mandatory logs. Binary/multiline payloads use reversible base64
in checksummed JSONL; unknown metadata remains unknown. Saturation drops optional
records visibly instead of waiting for diagnostic disk capacity.

## 7. Configuration and rotation defaults

Runtime → Process diagnostics: captureOFF; global directory under XDG_STATE_HOME
or ~/.local/state/gxtxt_pipeline/diagnostics/stderr;10MiB per file;5files including
current;8MiB ring. Editable directory/Browse and persistent Save use Configuration.
No executable Detect/Test entries. Changing directories never moves/deletes old
logs. Start readiness applies to new launches; OFF revokes generation acceptance
and cleans an opted-in native route without restarting its worker.

## 8. Diagnostic CORE public API

STDERR_DIAGNOSTICS_API_v1 exposes discovery/status, bounded asynchronous
read/meta/export, opaque request/cancel and subscription lifecycle. Trusted host
capture/configuration is separate from Viewer consultation. SDK adds immutable
input/data snapshots and finite cad_command/diagnostics_command/text_runs/table
operations. Explicit grants and declared components are checked; no raw Tk path,
arbitrary Tcl/file reader or producer capability is exposed to authored code.
Existing Event/State/Host ABI and original entries are preserved.

## 9. STDERR Diagnostics Viewer

Public Builder/Development C++17 normal Viewer with bounded live/retained pages,
actual metadata filters/search/order, multiline source-palette presentation,
selection/copy, explicit selected/interval export, pause/autoscroll, capture/drop/
error/status display. The class-based C++ client owns consultation and filtering;
CORE owns collection, reader lifetime, clipboard and native Save dialog. Opening
or closing the Viewer does not toggle capture. Its manual states cache/page limits.

## 10. Actual GUI validation results

PASS: both TEST Viewers, normal3DWorkbench working-plane Sketch, exact Line/
Point/control/Bezier edits, H/V and representative driving/reference dimensions,
UndoRedo/Escape, Save/close/reopen; Viewer-owned popup and Canvas panel states.
PASS: Runtime Browse/SaveON/OFF, genuine Tk errors/original-handler restoration,
OFF retained reader/theme restart, metadata filters/search/copy, multiline tags,
native export/cancel, pause-backlog/Latest/live-modal delivery and close cleanup.
PASS: genuine C++ Preview STDERR, preserved native-output log, finite OFF route
cleanup and cold-OFF isolation; registered numerical Job original stream identity.
See VALIDATION_REPORT.md and evidence receipts. MAIN1 inspected primary pixels. The fresh builtin diagnostics hierarchy also
passes actual S05 Runtime ON/OFF, created0700 onlyON; matching native bins rebuilt.

## 11. Performance and overload measurements

Final S05 production1500-emission burst: p50 272µs,p95 347µs,max513µs;
1500accepted=1500written,0drops, ring highwater221,124/8,388,608bytes and2evictions
for49,152,000rawbytes. Earlier intentional pressure separately reached8,361,374B
and57truthful drops;384concurrent exact events had0drops. One prior numerical
Job OFF/ON pair:4.8111/5.1821s launch→terminal, not a causal overhead estimate.
GUI50ms heartbeat median50.0885ms,max719.953ms including startup/screenshots/modal;
ordinary control callback samples~101–159ms. No zero-overhead claim. See scoped
PERFORMANCE_REPORT.md for real versus injected faults and timing boundaries.

## 12. Known defects and limitations

No unresolved observed P020 failure blocks the tested workflows. Exact editing
uses the local-plane surface, not direct 3D defining-control picking. Old0.1.7
interface Workspace source-upgrade is intentionally refused; canonical Documents
remain usable and new0.1.8Workspaces reopen. Search filters current cached pages.
Actual physical ENOSPC/slow-storage NOT VERIFIED; injected faults are separate.
User withdrew dimension-visibility investigation: no speculative fix or claim.
See KNOWN_LIMITATIONS.md for full supported boundaries.

## 13. Regression and preservation verification

Native2D C/C++, sprites/Cairo/grid, P012scheduler, P017History and the entire
Curve Workbench remain byte-identical to P019. Existing mandatory Job streams and
actual scientific output remain intact. New exact Sketch History uses existing
patch/context APIs, not full accumulated-history reconstruction. Original user
Sessions, previous releases, frozen mandates and TODO were not changed. No broad
historic/Windows-X11 campaign or next CAD phase was started.

## 14. Source commit and change manifest

`patch_notes/DEV111-P020/SOURCE.json` and release SOURCE.json contain the exact
final Git commit. FILES.json binds every P019 preimage/P020 postimage, mode/size and
base archive. BUILD_IDENTITY.json and ordinary module provenance bind native
sources, SDK, build receipts and binaries. The updated3D package also preserves
its existing historical original-build receipt; the standard Builder writer
regenerates the complete checksum inventory without changing runtime bytes.

## 15. ZIP location and SHA-256

`/srv/gxtxt/releases/dev111/patches/0020-cad-sketch-stderr-diagnostics/DEV111-P020.zip`.
The adjacent .sha256, VERIFICATION.json and DEPOSIT.json contain the measured
archive size/hash, full fresh-apply/rollback verification and mirror identities.
Four ordinary Viewer ZIPs accompany the incremental overlay. The first internal
candidate was preserved in scratch after a demonstrated fresh-directory startup
failure; only the corrected qualified candidate is the final delivery. The overlay itself
includes their actual framework-relative modules, matching native sources/bins,
public APIs, documentation and reviewed synthetic validation evidence.

## 16. Rollback and installation notes

Close GX-TXT, unzip -o the overlay from the cumulative P019 framework root, then
restart. No installer/automatic activation is run. Explicit guarded rollback
checks all postimages/preimages before restoring only this patch's product files;
it preserves user Documents/preferences/logs. Fresh private P019 extraction,
Core catalog/old-artifact SDK admission and full rollback are required package
checks. See README.md. **Installation status: NOT INSTALLED by agents.**

## 17. Remaining-work status

Authoritative TODO and historical task documents remain unchanged. No P020 task
is removed before user acceptance. Scientific Libraries, P021 and broader CORE
restructuring are not started. P019 user acceptance remains authoritative.

## 18. User VNC acceptance instructions

Use a private test Session. Open Test CAD1/2 through normal Viewers; construct/edit,
use shared menus/icons/Canvas controls, UndoRedo/cancel and Save/reopen. In Scientific
3D Workbench create a Document/set a tilted working plane, then create/edit/save/
reopen its Sketch. In Configuration Runtime choose diagnostics directory/limits,
SaveON and wait for running, launch an ordinary managed process, then open STDERR
Diagnostics and test filters, selected multiline payload, pause/resume and export.
SaveOFF and verify retained logs remain readable. User VNC acceptance is OPEN.
After deposit MAIN1 stops and awaits explicit acceptance; no further phase begins.
