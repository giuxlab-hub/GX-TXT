# P020 focused qualification

SPDX-License-Identifier: GPL-3.0-or-later

This report separates actual GUI input from supplementary API/native contracts.
P019 is user-installed and accepted. MAIN2 used Sol6.1-low and its own children,
only in its assigned scratch tree, against immutable S02/S03/S04 copies. MAIN1
reviewed receipts/source pins and the actual primary screenshots. This is internal
qualification for user acceptance, not a declaration of final VNC acceptance.

## CAD and ordinary authored Viewers

**PASS — real Linux X11/Tk, Xvfb/Xfwm4:** both ordinary TEST CAD C++17 providers,
actual menu/icon construction, Line creation, defining-control mouse movement,
exact coordinate checks, Undo/Redo, staged Escape cancellation, Workspace Save,
WM close and public same-source reopen. Exact restored models agree. Test CAD 1
uses Viewer-selected menus/toolbars/palette; its actual right-click menu combines
selected Line, disabled Undo/Redo and an independently invoked TEST action.
Test CAD 2 uses the common ViewportHost Sketch tools panel with ten icon controls
and its full All CAD actions menu. No Curve Workbench runtime is imported.

**PASS — representative shared advanced GUI:** Horizontal and Vertical
constraints; inline driving dimension0.7; inconsistent driving0.9 rejected and
reference fallback displays(0.7) without changing committed geometry; quadratic
Bezier construction and sole middle-control edit. History receipts distinguish
accepted edits from selection/cancel/rejected proposals. These are representative
cases, not a claim that all40 action combinations were rerun.

**PASS — actual ordinary Scientific 3D Workbench0.1.8:** New Document, working-plane
form, Sketch menu, Line+Point construction, Undo/Redo, Sketch Save/close/open,
interface Workspace Save, WM close, public reopen and associated Sketch reopen.
For O=(10,-20,30), U=(1,0,0), V=(0,.8,-.6), local(4,3) gives
world(14,-17.6,28.2); gold maximum mapping error0, inverse plane-normal
residual approximately1.55e-15. Live tilted Native3D line/point pixels are present.
Scientific editing is in the exact local surface, not a static projected image.

**PASS — supplementary public component contracts:** exact topology/control/
relationship state, logical/native identity hydration, P017 History patch capture,
Undo/Redo, unit/plane validation, staged restore, stale-reference refusal and
pending-close cleanup. Native3D point/polyline rendering uses its existing native
geometry owner. These component assertions do not replace the real GUI results.

## Diagnostics GUI and process integration

**PASS — real Configuration:** native Browse directory dialog, persistent SaveON,
ready collector, actual Tk callback failure plus unchanged original error handler,
SaveOFF/restoration and no new archive write from the OFF error. Native Appearance
Save/restart applies clam. The ordinary Viewer reads retained records OFF with
source-palette styles and multiline error text. Capture is not coupled to opening
or closing the Viewer.

**PASS — real Diagnostics controls:** Module/API/Viewer/Job/Process filters, text
search, table selection, original multiline payload/color tags, Copy, native Save
export and native Cancel. The exported record retains Unicode/base64/origin and
stable identity. Export modals remained open over2s without recursive native calls.
S04 resolves observed pause-backlog failure: capture advances while paused;
unpause follows the saved cursor, preserves a current selection/detail, and Next
shows the tail. Without a selection, the latest appended page becomes visible.
Four-page Latest navigation works. New records during an export/cancel dialog
are delivered afterwards. Closure retires subscriptions and pending work.

**PASS — native Development Preview:** actual C++ STDERR reaches the global
archive with known process/Viewer metadata, while the original native-output log
retains its bytes. CaptureOFF restores fd2 to the original file, tasks2→1, same
worker remains usable and callback counter1→2; OFF emits no new archive record.
A cold-OFF worker has no capability/library/optional pipe/thread/control traffic.
The trusted producer attaches before the unchanged Landlock project-write grant;
author code and drain thread execute after the grant. No permission waiver.

**PASS — registered numerical Job OFF/ON:** exact36-byte stdout and58-byte STDERR,
SCIENCE=55 and Unicode/multiline marker preserved; collector payload equals
program.stderr byte-for-byte. Mandatory program.stdout/program.stderr and
diagnostic.log launch/terminal entries survive. Known child PID is distinguished
from capture PID; the global helper remains the same.

## Independent native and failure qualification

**PASS:** defaultOFF no backend/helper/queue/polling/log writes; binary/NUL/UTF-8
roundtrip; bounded readers/cancellation/cursor expiry; retained OFF reads; exact
stable-ID export;400 ordered rotating records;384 concurrent events from two
external producers plus Tcl; default and scaled global file limits; actual8MiB
ring pressure with explicit drops; stopped-helper transport saturation; helper
crash/restart, broken IPC, application-death cleanup, safe tail recovery;
production EACCES and process-local EFBIG. Exact commands, pins and observations
are retained with the independent receipts.

**PASS, injected only:** matching-source private ENOSPC and150ms writer delay.
**NOT VERIFIED:** actual full filesystem ENOSPC and physical slow-storage hardware.
Private fault binaries are not shipped. No complete-capture claim under overload.

## Corrected integration failures and boundaries

S02 real failures (background-handler Tcl arity, missing requirement discovery,
missing provider identity and incomplete Canvas controls) were corrected and
qualified by S03. S03 unpause backlog and Preview producer attachment failed,
were corrected, and passed the affected S04 reruns. First failed evidence remains
in the isolated server area; it is never relabelled as PASS.

MAIN1's public Builder-demo contract verifies layout-only Sketch composition
creates no canonical Document/History; the runtime branch is unchanged. SDK
compile/admission of the actual protected P019 artifact and finite typed grant
positive/negative cases pass. Fresh package application/catalog/startup and
rollback are separately recorded in VERIFICATION.json at release deposit.

The user withdrew the Show dimensions investigation. No correction or acceptance
claim for it is included. No private Workspace evidence is distributed. Untouched
P019 scientific services and Curve Workbench are preserved byte-for-byte; no broad
historical regression campaign or Windows-X11 test was performed.


## Late fresh-directory startup correction

A final owner check reproduced ENOENT when the configured default application-state
hierarchy did not yet exist. The original helper created only its final component.
The native directory owner now creates missing components0700 only while ON,
reopens each with O_NOFOLLOW and validates newly created ownership/private mode.
Existing directories are never chmodded, and OFF reads create no hierarchy.
Matching production adapter/helper were rebuilt. MAIN1 before/after public API
contracts reproduce the original failure and pass the correction. Narrow S05
independent GUI/native qualification is recorded separately before final packaging.
The first unpublished package/deposit is preserved as candidate01 outside final
release delivery; no accepted/historical release or installation is overwritten.
