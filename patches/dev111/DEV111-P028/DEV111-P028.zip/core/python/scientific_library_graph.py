"""Provider-neutral typed entities, immutable Library transactions and graph index.

Registry authority is scientific_library_manager. SQLite below is disposable,
fingerprinted search/index data; immutable package entries own every assertion.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import base64
import configparser
import hashlib
import io
import json
import mimetypes
from pathlib import Path
import re
import sqlite3
import tempfile
import uuid
import zipfile
import scientific_library_manager as manager
from scientific_library_records import canonical, entry_hash, load

MAX_ENTRIES = 100
MAX_FILE = 32 * 1024 * 1024

def declarations(section):
    found = {}
    for descriptor in manager.provider_descriptors():
        parser = configparser.ConfigParser(interpolation=None, strict=True)
        parser.read(descriptor, encoding='utf-8')
        if not parser.has_section(section):
            continue
        identity = manager.safe_id(parser.get('meta','id'))
        if identity != descriptor.parent.name or parser.get(section,'api_version') != '1':
            raise ValueError('Invalid Library provider declaration')
        relative = Path(parser.get(section,'schema' if section == 'library_domain_provider' else 'entrypoint'))
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe Library provider declaration path')
        path = (descriptor.parent / relative).resolve()
        if not path.is_relative_to(descriptor.parent.resolve()) or not path.is_file():
            raise ValueError('Library provider declaration is absent')
        if identity in found:
            raise ValueError('Duplicate Library provider identity')
        found[identity] = dict(id=identity,version=parser.get('meta','version'),path=path,
            descriptor=descriptor, fields=dict(parser.items(section)))
    return found

def schemas():
    result = dict(schema='gxtxt.library_domain_catalog.v1', providers={}, record_types={}, relations={})
    for identity, declaration in declarations('library_domain_provider').items():
        raw = declaration['path'].read_bytes()
        value = json.loads(raw)
        if value.get('schema') != 'gxtxt.library_domain.v1' or value.get('provider_id') != identity:
            raise ValueError('Domain schema identity mismatch')
        result['providers'][identity] = dict(version=declaration['version'],sha256=hashlib.sha256(raw).hexdigest())
        for category in ('record_types','relations'):
            for name, schema in value.get(category,{}).items():
                manager.safe_id(name)
                if '.' not in name or name in result[category] or not isinstance(schema,dict):
                    raise ValueError('Invalid or duplicate qualified domain schema')
                result[category][name] = dict(schema,provider_id=identity,provider_version=declaration['version'],schema_sha256=hashlib.sha256(raw).hexdigest())
    return result

def _typed(value, definition):
    kind = definition.get('type','string')
    checks = dict(string=lambda:type(value) is str, number=lambda:type(value) in (float,int),
        integer=lambda:type(value) is int, boolean=lambda:type(value) is bool,
        object=lambda:type(value) is dict, array=lambda:type(value) is list,
        scalar=lambda:value is None or type(value) in (str,float,int,bool))
    if kind not in checks or not checks[kind]():
        raise ValueError('Domain field does not match declared type: '+kind)
    if 'enum' in definition and value not in definition['enum']:
        raise ValueError('Domain field is outside declared vocabulary')
    if kind=='array' and definition.get('editor')=='table':
        if len(value)>100:raise ValueError('Structured property table exceeds 100 rows')
        for row in value:
            if not isinstance(row,dict):raise ValueError('Structured property row must be an object')
            for key,column in definition['columns'].items():
                if column.get('required') and (key not in row or row[key]==''):
                    raise ValueError('Property row requires '+key)
                if key in row:_typed(row[key],column)

def validate_entry(entry, library_type, catalog=None):
    catalog = catalog or schemas()
    manager.safe_id(entry.get('entry_id',''))
    manager.safe_id(entry.get('revision',''))
    declaration = catalog['record_types'].get(entry.get('record_type'))
    if not declaration or library_type not in declaration.get('library_types',[declaration['library_type']]):
        raise ValueError('Unknown or incompatible Library record schema')
    pinned=entry.get('domain_schema')
    if pinned and (pinned.get('provider_id')!=declaration['provider_id'] or
            pinned.get('sha256') not in [declaration['schema_sha256'],*declaration.get('compatible_schema_sha256',[])]):
        raise ValueError('Saved domain schema version is unavailable; install a compatible provider or explicitly adapt a new Library version')
    fields = entry.get('fields')
    if not isinstance(fields,dict):
        raise ValueError('Library fields must be a typed dictionary')
    for key,definition in declaration.get('fields',{}).items():
        if definition.get('required') and key not in fields:
            raise ValueError('Missing required domain field: '+key)
        if key in fields:
            _typed(fields[key],definition)
    unknown = set(fields)-set(declaration.get('fields',{}))
    if unknown and not declaration.get('additional_fields',False):
        raise ValueError('Undeclared domain fields: '+', '.join(sorted(unknown)))
    provenance = entry.get('provenance',{})
    if not isinstance(provenance,dict) or not provenance.get('source_id') or not provenance.get('retrieved_at'):
        raise ValueError('Library entry requires source identity and retrieval provenance')
    for resource in entry.get('resources',[]):
        if not isinstance(resource,dict) or not resource.get('role'):
            raise ValueError('Invalid Library resource declaration')
        if 'data_base64' in resource:
            raw=base64.b64decode(resource['data_base64'],validate=True)
            if len(raw)>MAX_FILE or hashlib.sha256(raw).hexdigest()!=resource.get('sha256'):
                raise ValueError('Library resource bytes/hash mismatch')
        elif not resource.get('url') or resource.get('availability')!='external':
            raise ValueError('Library resource must be stored bytes or explicit external link')
    for relation in entry.get('relations',[]):
        definition=catalog['relations'].get(relation.get('relation_type'))
        if not definition or entry['record_type'] not in definition['from_types']:
            raise ValueError('Unknown relation or incompatible source type')
        target=relation.get('target',{})
        if target.get('kind') not in {'library_entry','canonical_dataset','external_source_entity'}:
            raise ValueError('Invalid relation anchor kind')
        if target.get('record_type') not in definition['to_types']:
            raise ValueError('Relation target violates domain type constraint')
        for required in ('source_id','evidence','assertion_kind','retrieved_at'):
            if not relation.get(required):
                raise ValueError('Relation requires attributed evidence: '+required)
        if relation['assertion_kind'] not in {'source','user','derived'}:
            raise ValueError('Unknown relation assertion kind')
        if target['kind']=='library_entry':
            for key in ('library_id','entry_id','revision','content_sha256'):
                if not target.get(key):raise ValueError('Library relation must pin exact target '+key)
        elif target['kind']=='canonical_dataset':
            for key in ('session_id','dataset_id','revision'):
                if not target.get(key):raise ValueError('Dataset relation must pin exact '+key)
        elif not target.get('source_id') or not target.get('external_id'):
            raise ValueError('External relation requires qualified source identity')
    validator=declaration.get('validator')
    if validator:
        import importlib.util
        owner=declarations('library_domain_provider')[declaration['provider_id']]
        relative=Path(validator)
        path=(owner['descriptor'].parent/relative).resolve()
        if relative.is_absolute() or '..' in relative.parts or path.suffix!='.py' or not path.is_relative_to(owner['descriptor'].parent.resolve()):
            raise ValueError('Unsafe domain scientific validator path')
        spec=importlib.util.spec_from_file_location('gxtxt_library_domain_validation',path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        module.validate_entry(entry,manager.FRAMEWORK)
    return declaration

def local_resource(path, role, source):
    path=Path(path).resolve()
    if not path.is_file() or path.stat().st_size>MAX_FILE:
        raise ValueError('Local Library resource is absent or exceeds 32 MiB')
    raw=path.read_bytes()
    if raw.startswith(b'%PDF-'):
        mime='application/pdf'
    elif raw.startswith(b'\x89PNG\r\n\x1a\n'):
        mime='image/png'
    elif raw.startswith(b'\xff\xd8\xff'):
        mime='image/jpeg'
    elif raw.startswith((b'GIF87a',b'GIF89a')):
        mime='image/gif'
    else:
        raise ValueError('Local attachment must be a genuine PDF, PNG, JPEG or GIF')
    return dict(role=role,original_filename=path.name,media_type=mime,source_id=source,
        availability='local',sha256=hashlib.sha256(raw).hexdigest(),size_bytes=len(raw),
        data_base64=base64.b64encode(raw).decode('ascii'))

def import_entries(library_id, library_type, entries, display_name='', expected_version=None):
    """Explicit Stage A transaction: data-only package -> existing install/update.

    Existing version is checked; concurrent commits fail via existing immutable
    version path, never silently overwrite. Previous package bytes are retained.
    """
    manager.safe_id(library_id)
    if not isinstance(entries,list) or not 1<=len(entries)<=MAX_ENTRIES:
        raise ValueError('Select between 1 and 100 entries for explicit Library import')
    if len({entry.get('entry_id') for entry in entries})!=len(entries):raise ValueError('Duplicate entry IDs in one Library selection')
    provider=manager.select_provider(library_type)
    catalog=schemas()
    registry=manager.load_registry(manager.managed_root())
    old=registry['libraries'].get(library_id)
    if old and (old['state']!='installed' or old['library_type']!=library_type):
        raise ValueError('Destination Library identity/type is unavailable')
    if expected_version is not None and (old or {}).get('version','')!=expected_version:
        raise ValueError('Destination Library version changed; review selection again')
    payload=load(manager.storage_path(manager.managed_root(),old)) if old else dict(
        schema='gxtxt.library_records.v1',library_type=library_type,entries={},history=[])
    receipt=[]
    for original in entries:
        entry=json.loads(canonical(original))
        entry.setdefault('revision','1')
        previous=payload['entries'].get(entry['entry_id'])
        # Same stable ID may only update after the caller pins old content hash.
        if previous and entry.get('content_sha256')==previous['content_sha256']:
            receipt.append(dict(entry_id=entry['entry_id'],status='unchanged',revision=previous['revision']))
            continue
        if previous:
            if entry.pop('expected_content_sha256',None)!=previous['content_sha256']:
                raise ValueError('Existing entry changed: explicit previous content SHA required')
            payload['history'].append(previous)
            entry['revision']=str(int(previous['revision'])+1)
        entry.pop('content_sha256',None)
        declaration=validate_entry(entry,library_type,catalog)
        entry['domain_schema']=dict(provider_id=declaration['provider_id'],provider_version=declaration['provider_version'],sha256=declaration['schema_sha256'])
        entry['content_sha256']=entry_hash(entry)
        payload['entries'][entry['entry_id']]=entry
        receipt.append(dict(entry_id=entry['entry_id'],status='updated' if previous else 'added',revision=entry['revision'],content_sha256=entry['content_sha256']))
    if old and all(row['status']=='unchanged' for row in receipt):
        return dict(schema='gxtxt.library_import_receipt.v1',library_id=library_id,version=old['version'],entries=receipt,
            transaction_id=uuid.uuid4().hex,session_datasets_created=0)
    version=str(int(old['version'].split('.')[0])+1)+'.0' if old else '1.0'
    manifest=dict(library_id=library_id,library_type=library_type,version=version,
        provider_id=provider['provider_id'],format_version='1',display_name=display_name or library_id,
        description='Explicit persistent typed Library records; independent of Sessions',
        license='Source-specific attribution retained per entry',origin='user-selected Library import')
    parser=configparser.ConfigParser(interpolation=None);parser['library']=manifest
    text=io.StringIO();parser.write(text)
    raw=canonical(payload)
    with tempfile.TemporaryDirectory(prefix='gxtxt-library-package-') as temporary:
        path=Path(temporary)/'library.zip'
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('library.ini',text.getvalue())
            archive.writestr('payload/library.gxsrl',raw)
            archive.writestr('SHA256SUMS.txt',hashlib.sha256(raw).hexdigest()+'  payload/library.gxsrl\n')
        info=manager.install_or_update('update' if old else 'install',path,library_id if old else None)
    return dict(schema='gxtxt.library_import_receipt.v1',library_id=library_id,version=info['version'],entries=receipt,
        transaction_id=uuid.uuid4().hex,session_datasets_created=0)

def read_pinned(reference):
    record=manager.require_installed(manager.load_registry(manager.managed_root()),reference['library_id'])
    provider=manager.select_provider(record['library_type'],record['provider_id'])
    manager._verify_managed_record(manager.managed_root(),record,provider)
    entry=load(manager.storage_path(manager.managed_root(),record))['entries'].get(reference['entry_id'])
    if not entry or entry.get('tombstone'):
        raise ValueError('Library entry is missing/tombstoned')
    if any(reference.get(key,entry[key])!=entry[key] for key in ('revision','content_sha256')):
        raise ValueError('Saved Library entry revision/hash is stale')
    validate_entry(entry,record['library_type'])
    if entry_hash(entry)!=entry['content_sha256']:raise ValueError('Library entry hash mismatch')
    return entry

def import_bundle(bundle, selected_ids, destinations):
    """Reviewed, nonrecursive subset; cross-Library batches report each commit."""
    if bundle.get('schema')!='gxtxt.library_source_bundle.v1' or not isinstance(selected_ids,list) or not 1<=len(selected_ids)<=MAX_ENTRIES or len(set(selected_ids))!=len(selected_ids):
        raise ValueError('Review 1 to 100 distinct source records before Library import')
    rows={row['entry']['entry_id']:json.loads(canonical(row)) for row in bundle['entries']}
    if set(selected_ids)-set(rows):raise ValueError('Source selection includes an absent entry')
    selected=[rows[key] for key in selected_ids]
    catalog=schemas();resolved={};receipts=[]
    # Leaves precede semantic parents. Relations to unselected resources stay
    # explicitly external; no graph traversal triggers an implicit import.
    selected.sort(key=lambda row:len(row['entry'].get('relations',[])))
    groups={};existing={}
    registry=manager.load_registry(manager.managed_root())
    for destination in set(destinations.values()):
        record=registry['libraries'].get(destination)
        if record and record.get('state')=='installed':
            existing[destination]=load(manager.storage_path(manager.managed_root(),record))['entries']
    def comparable(value):
        if isinstance(value,dict):return {k:comparable(v) for k,v in value.items() if k not in {'retrieved_at','revision','content_sha256','expected_content_sha256'}}
        if isinstance(value,list):return [comparable(v) for v in value]
        return value
    for row in selected:
        typ=row['library_type'];destination=destinations.get(typ)
        if not destination:raise ValueError('Choose a destination Library for '+typ)
        manager.safe_id(destination)
        entry=row['entry']
        for edge in entry.get('relations',[]):
            target=edge['target'];key=(target.get('source_id'),target.get('external_id'),target.get('record_type'))
            if key in resolved:edge['target']=resolved[key]
        definition=validate_entry(entry,typ,catalog)
        entry['domain_schema']=dict(provider_id=definition['provider_id'],provider_version=definition['provider_version'],sha256=definition['schema_sha256'])
        previous=existing.get(destination,{}).get(entry['entry_id'])
        if previous:
            if comparable(previous)==comparable(entry):entry=previous
            else:
                entry['revision']=str(int(previous['revision'])+1)
                entry['expected_content_sha256']=previous['content_sha256']
        entry['content_sha256']=entry_hash(entry)
        # expected_content_sha256 is an admission precondition, not scientific
        # content. import_entries consumes it before hashing the saved revision.
        if 'expected_content_sha256' in entry:
            entry['content_sha256']=entry_hash({k:v for k,v in entry.items() if k!='expected_content_sha256'})
        provenance=entry['provenance']
        resolved[(provenance['source_id'],provenance.get('external_id'),entry['record_type'])]=dict(kind='library_entry',
            library_id=destination,entry_id=entry['entry_id'],record_type=entry['record_type'],revision=entry['revision'],content_sha256=entry['content_sha256'])
        groups.setdefault((destination,typ),[]).append(entry)
    # Order batches by first dependent record; preceding leaf batch commits
    # remain visible if a later independent Library transaction fails.
    for (destination,typ),entries in groups.items():
        try:receipts.append(dict(status='completed',result=import_entries(destination,typ,entries)))
        except Exception as error:
            receipts.append(dict(status='failed',library_id=destination,error=str(error)))
            break
    return dict(schema='gxtxt.library_source_import.v1',batches=receipts,
        status='completed' if all(row['status']=='completed' for row in receipts) else 'partial' if len(receipts)>1 else 'failed',session_datasets_created=0)

def detail(reference):
    entry=json.loads(canonical(read_pinned(reference)))
    for resource in entry.get('resources',[]):resource.pop('data_base64',None)
    return entry

def stage(reference, resource_index, output_dir):
    """Copy pinned bytes into a host Resource Management allocation, no parser."""
    entry=read_pinned(reference)
    output=Path(output_dir).resolve()
    if not output.is_dir():raise ValueError('Owned Resource Management allocation is absent')
    contract=entry.get('content_contract','')
    if resource_index == -1:
        if not entry.get('content_contract'):raise ValueError('Entry has no declared acquisition representation')
        raw=canonical(entry);name='record.json';mime='application/json'
    else:
        if type(resource_index) is not int or resource_index<0 or resource_index>=len(entry.get('resources',[])):
            raise ValueError('Choose an actual local Library resource')
        resource=entry['resources'][resource_index]
        if resource.get('availability')!='local' or 'data_base64' not in resource:
            raise ValueError('External resource has no locally stored bytes')
        raw=base64.b64decode(resource['data_base64'],validate=True)
        name=Path(resource.get('original_filename','resource.bin')).name
        if hashlib.sha256(raw).hexdigest()!=resource['sha256']:raise ValueError('Pinned resource SHA changed')
        mime=resource['media_type']
        definition=schemas()['record_types'][entry['record_type']]
        contract=resource.get('content_contract',definition.get('resource_contracts',{}).get(mime,''))
    path=output/name
    if path.exists():raise ValueError('Staging destination already exists')
    with path.open('xb') as stream:stream.write(raw)
    result=dict(source_path=str(path),sha256=hashlib.sha256(raw).hexdigest(),media_type=mime,
        content_contract=contract,library_id=reference['library_id'],entry_id=entry['entry_id'],
        revision=entry['revision'],content_sha256=entry['content_sha256'],source_id=entry['provenance']['source_id'])
    definition=schemas()['record_types'][entry['record_type']]
    selected_fields=definition.get('acquisition_context_fields',[])
    if selected_fields:
        fields={key:entry['fields'][key] for key in selected_fields if key in entry['fields']}
        context=canonical(dict(schema='gxtxt.library_acquisition_context.v1',record_type=entry['record_type'],
            reference=dict(library_id=reference['library_id'],entry_id=entry['entry_id'],revision=entry['revision'],content_sha256=entry['content_sha256']),
            resource_sha256=result['sha256'],fields=fields))
        if len(context)>1048576:raise ValueError('Library acquisition context exceeds 1 MiB')
        context_path=output/'gxtxt-library-entry.json'
        with context_path.open('xb') as stream:stream.write(context)
        result.update(context_path=str(context_path),context_sha256=hashlib.sha256(context).hexdigest())
    return result

def manual_prepare(record_type, fields, source_id, label='', entry_id='', pasted_text='', attachments=None, previous=None, raw_fields=False):
    catalog=schemas();definition=catalog['record_types'].get(record_type)
    if not definition:raise ValueError('Choose an installed Library record schema')
    if not isinstance(source_id,str) or not source_id.strip() or len(source_id)>4096:raise ValueError('Enter source identity for the manual record')
    if not isinstance(pasted_text,str) or len(pasted_text)>262144:raise ValueError('Pasted specifications exceed 256 KiB')
    fields=json.loads(canonical(fields))
    if raw_fields:
        converted={}
        for key,value in fields.items():
            if value=='':continue
            kind=definition.get('fields',{}).get(key,{}).get('type')
            converted[key]=value if kind=='string' else json.loads(value)
        fields=converted
    paste=definition.get('paste')
    if pasted_text and paste:
        values=[]
        for line in pasted_text.splitlines():
            if not line.strip():continue
            name,separator,value=line.partition('\t')
            if not separator:name,separator,value=line.partition(':')
            if not separator:raise ValueError('Paste each specification as name TAB value or name: value')
            values.append({paste['name_key']:name.strip(),paste['value_key']:value.strip()})
        fields[paste['target_field']]=values
        if paste.get('original_field'):fields[paste['original_field']]=pasted_text
    entry=dict(entry_id=entry_id or 'manual-'+uuid.uuid4().hex,revision='1',record_type=record_type,label=label,
        fields=fields,resources=[],relations=[],provenance=dict(source_id=source_id,retrieved_at=manager.now(),
        method='clipboard' if pasted_text else 'manual',original_text_sha256=hashlib.sha256(pasted_text.encode()).hexdigest()))
    if definition.get('content_contract'):entry['content_contract']=definition['content_contract']
    if previous:
        entry['expected_content_sha256']=previous['content_sha256']
        entry['resources']=read_pinned(previous).get('resources',[])
        entry['relations']=read_pinned(previous).get('relations',[])
    for attachment in attachments or []:
        resource=local_resource(attachment['path'],attachment['role'],source_id)
        if attachment.get('expected_sha256') and attachment['expected_sha256']!=resource['sha256']:
            raise ValueError('Local attachment changed after selection')
        entry['resources'].append(resource)
    if sum(resource.get('size_bytes',0) for resource in entry['resources'])>64*1024*1024:
        raise ValueError('Manual Library attachments exceed the 64 MiB entry budget')
    validate_entry(entry,definition['library_type'],catalog)
    return dict(schema='gxtxt.library_manual_preview.v1',library_type=definition['library_type'],entry=entry)

def operation(name, parameters):
    if name=='schemas':return schemas()
    if name=='connectors':
        import scientific_library_sources as sources
        return dict(schema='gxtxt.library_connectors.v1',connectors=sources.connectors())
    if name=='search':return search(**parameters)
    if name=='resolve_external_id':return resolve_external_id(**parameters)
    if name=='related':return related(**parameters)
    if name=='detail':return detail(**parameters)
    if name=='import':return import_entries(**parameters)
    if name=='import_bundle':return import_bundle(**parameters)
    if name=='local_resource':return local_resource(**parameters)
    if name=='stage':return stage(**parameters)
    if name=='manual_prepare':return manual_prepare(**parameters)
    if name=='manual_import':
        parameters=dict(parameters)
        library_id=parameters.pop('library_id')
        preview=manual_prepare(**parameters)
        return import_entries(library_id,preview['library_type'],[preview['entry']])
    raise ValueError('Unknown Library domain operation')

def _index():
    root=manager.managed_root();root.mkdir(parents=True,exist_ok=True)
    registry,fingerprint=manager.registry_snapshot(root)
    catalog=schemas()
    fingerprint=hashlib.sha256(canonical([fingerprint,catalog['providers']])).hexdigest()
    connection=sqlite3.connect(root/'relations-index.sqlite',timeout=10)
    connection.row_factory=sqlite3.Row
    connection.executescript('CREATE TABLE IF NOT EXISTS state(fingerprint TEXT); CREATE TABLE IF NOT EXISTS diagnostics(library_id TEXT PRIMARY KEY,reason TEXT); CREATE TABLE IF NOT EXISTS entries(library_id TEXT,entry_id TEXT,revision TEXT,sha TEXT,record_type TEXT,label TEXT,body TEXT,PRIMARY KEY(library_id,entry_id)); CREATE TABLE IF NOT EXISTS edges(id TEXT PRIMARY KEY,from_library TEXT,from_entry TEXT,to_library TEXT,to_entry TEXT,relation_type TEXT,source_id TEXT,body TEXT); CREATE INDEX IF NOT EXISTS incoming ON edges(to_library,to_entry); CREATE INDEX IF NOT EXISTS outgoing ON edges(from_library,from_entry);')
    row=connection.execute('SELECT fingerprint FROM state').fetchone()
    if row and row[0]==fingerprint:return connection
    with connection:
        connection.execute('DELETE FROM entries');connection.execute('DELETE FROM edges');connection.execute('DELETE FROM state');connection.execute('DELETE FROM diagnostics')
        for library_id,record in sorted(registry['libraries'].items()):
            if record.get('state')!='installed' or record.get('mode','managed')!='managed':continue
            # Only declared generic record providers own this payload format.
            try:
                provider=manager.select_provider(record['library_type'],record['provider_id'])
            except ValueError:
                connection.execute('INSERT INTO diagnostics VALUES(?,?)',(library_id,'Library Type Provider is absent or disabled'))
                continue
            if not getattr(provider['module'],'TYPED_RECORDS',False):continue
            try:manager._verify_managed_record(root,record,provider)
            except (ValueError,OSError) as error:
                connection.execute('INSERT INTO diagnostics VALUES(?,?)',(library_id,str(error)))
                continue
            for entry_id,entry in load(manager.storage_path(root,record))['entries'].items():
                if entry.get('tombstone'):continue
                indexed=json.loads(canonical(entry))
                for resource in indexed.get('resources',[]):resource.pop('data_base64',None)
                connection.execute('INSERT INTO entries VALUES(?,?,?,?,?,?,?)',(library_id,entry_id,entry['revision'],entry['content_sha256'],entry['record_type'],entry.get('label',entry_id),canonical(indexed).decode()))
                for ordinal,edge in enumerate(entry.get('relations',[])):
                    target=edge['target'];identity=hashlib.sha256(canonical([library_id,entry_id,entry['revision'],ordinal,edge])).hexdigest()
                    saved=dict(edge,relation_id=identity,from_reference=dict(kind='library_entry',library_id=library_id,entry_id=entry_id,record_type=entry['record_type'],revision=entry['revision'],content_sha256=entry['content_sha256']))
                    connection.execute('INSERT INTO edges VALUES(?,?,?,?,?,?,?,?)',(identity,library_id,entry_id,target.get('library_id',''),target.get('entry_id',''),edge['relation_type'],edge['source_id'],canonical(saved).decode()))
        connection.execute('INSERT INTO state VALUES(?)',(fingerprint,))
    return connection

def related(reference, direction='both', relation_type='', source_id='', offset=0, limit=100):
    if direction not in {'incoming','outgoing','both'} or type(offset) is not int or offset<0 or type(limit) is not int or not 1<=limit<=100:
        raise ValueError('Invalid bounded relation query')
    read_pinned(reference)
    connection=_index()
    try:
        clauses=[];args=[]
        if direction in {'incoming','both'}:clauses.append('(to_library=? AND to_entry=?)');args.extend([reference['library_id'],reference['entry_id']])
        if direction in {'outgoing','both'}:clauses.append('(from_library=? AND from_entry=?)');args.extend([reference['library_id'],reference['entry_id']])
        where='('+' OR '.join(clauses)+')'
        for key,value in (('relation_type',relation_type),('source_id',source_id)):
            if value:where+=' AND '+key+'=?';args.append(value)
        total=connection.execute('SELECT COUNT(*) FROM edges WHERE '+where,args).fetchone()[0]
        rows=[]
        for row in connection.execute('SELECT body FROM edges WHERE '+where+' ORDER BY id LIMIT ? OFFSET ?',args+[limit,offset]):
            edge=json.loads(row[0]);target=edge['target'];edge['resolution_status']='unresolved'
            if target['kind']=='library_entry':
                found=connection.execute('SELECT revision,sha FROM entries WHERE library_id=? AND entry_id=?',(target['library_id'],target['entry_id'])).fetchone()
                edge['resolution_status']='resolved' if found and found['revision']==target['revision'] and found['sha']==target['content_sha256'] else 'stale' if found else 'unresolved'
            edge['why_related']=edge['evidence'];rows.append(edge)
        return dict(schema='gxtxt.library_relations_page.v1',records=rows,total=total,offset=offset,limit=limit,
            unavailable_libraries=[dict(row) for row in connection.execute('SELECT * FROM diagnostics ORDER BY library_id')])
    finally:connection.close()

def search(query='', record_type='', offset=0, limit=100):
    if not isinstance(query,str) or len(query)>4096 or type(offset) is not int or offset<0 or type(limit) is not int or not 1<=limit<=100:
        raise ValueError('Invalid bounded cross-Library search')
    connection=_index()
    try:
        where="(?='' OR record_type=?) AND instr(lower(body),lower(?))>0"
        args=[record_type,record_type,query]
        total=connection.execute('SELECT COUNT(*) FROM entries WHERE '+where,args).fetchone()[0]
        rows=[dict(row) for row in connection.execute('SELECT library_id,entry_id,revision,sha AS content_sha256,record_type,label FROM entries WHERE '+where+' ORDER BY library_id,entry_id LIMIT ? OFFSET ?',args+[limit,offset])]
        return dict(schema='gxtxt.library_search_page.v1',records=rows,total=total,offset=offset,limit=limit,
            unavailable_libraries=[dict(row) for row in connection.execute('SELECT * FROM diagnostics ORDER BY library_id')])
    finally:connection.close()

def resolve_external_id(source_id, external_id, record_type='', offset=0, limit=100):
    if any(not isinstance(value,str) or not value or len(value)>4096 for value in (source_id,external_id)) or type(offset) is not int or offset<0 or type(limit) is not int or not 1<=limit<=100:
        raise ValueError('Invalid bounded qualified external identity query')
    connection=_index()
    try:
        where="json_extract(body,'$.provenance.source_id')=? AND json_extract(body,'$.provenance.external_id')=? AND (?='' OR record_type=?)"
        args=[source_id,external_id,record_type,record_type]
        total=connection.execute('SELECT COUNT(*) FROM entries WHERE '+where,args).fetchone()[0]
        rows=[dict(row) for row in connection.execute('SELECT library_id,entry_id,revision,sha AS content_sha256,record_type,label FROM entries WHERE '+where+' ORDER BY library_id,entry_id LIMIT ? OFFSET ?',args+[limit,offset])]
        return dict(schema='gxtxt.library_external_identity_candidates.v1',records=rows,total=total,offset=offset,limit=limit)
    finally:connection.close()
