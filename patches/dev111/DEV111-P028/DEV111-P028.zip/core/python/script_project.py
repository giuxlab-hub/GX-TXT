"""Script Registry v1 whole-project manifest and integrity primitives.

No source execution, dependency installation or scientific data access.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import ast,hashlib,json,os,re,shutil,sys,zipfile,uuid
import importlib.abc,importlib.machinery
from pathlib import Path,PurePosixPath
from script_api_declarations import discover,discover_parameters,tcl
SCHEMA='gxtxt.script_project.v1'
MAX_FILES=256
MAX_BYTES=16*1024*1024
PORTABLE_FIELDS={'name','version','description','explicit_apis','required_apis','default_arguments','parameters','callables'}

def sha(data):return hashlib.sha256(data).hexdigest()
def relative(value,language):
    if not isinstance(value,str) or not value or len(value)>240 or '\\' in value or ':' in value or any(ord(c)<32 for c in value):raise ValueError('Invalid project relative path')
    path=PurePosixPath(value)
    if path.is_absolute() or str(path)!=value or any(p in {'.','..'} or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*',p) for p in path.parts):raise ValueError('Project paths must be normalized relative identifiers')
    if path.suffix != ('.py' if language=='Python' else '.m'):raise ValueError('Project admits only language source files')
    return value

def manifest(language,entrypoint,files):
    if language not in {'Python','Octave'}:raise ValueError('Project language must be Python or Octave')
    relative(entrypoint,language)
    if not 1<=len(files)<=MAX_FILES or entrypoint not in files:raise ValueError('Project requires admitted entrypoint and 1..256 files')
    records=[];seen=set();prefixes={};total=0;apis=set();parameters={}
    for name,data in sorted(files.items()):
        relative(name,language)
        if name.casefold() in seen:raise ValueError('Case-colliding project path')
        seen.add(name.casefold());total+=len(data)
        for n in range(1,len(PurePosixPath(name).parts)+1):
            prefix='/'.join(PurePosixPath(name).parts[:n]);fold=prefix.casefold()
            if fold in prefixes and prefixes[fold]!=prefix:raise ValueError('Case-colliding project directory')
            prefixes[fold]=prefix
        if len(data)>4*1024*1024 or total>MAX_BYTES:raise ValueError('Project source size exceeds bounds')
        source=data.decode('utf-8')
        if '\x00' in source:raise ValueError('Project source contains NUL')
        if PurePosixPath(name).stem.startswith('gxtxt_') or PurePosixPath(name).stem=='gxtxt':raise ValueError('Project source cannot shadow reserved GX-TXT runtime modules/functions')
        if language=='Python':
            for node in ast.walk(ast.parse(source,filename=name)):
                if not isinstance(node,ast.Call):continue
                call=ast.unparse(node.func)
                if call in {'sys.path.append','sys.path.insert','sys.path.extend','sys.path.remove','sys.path.clear','importlib.util.spec_from_file_location','importlib.machinery.SourceFileLoader','runpy.run_path'}:
                    raise ValueError(f'{name}:{node.lineno}: external source loaders/import-path mutation are outside the admitted project; add a manifest source or use the configured runtime packages')
        if language=='Octave':
            if PurePosixPath(name).stem in {'source','run','addpath','rmpath','path','cd','which','exist','fileparts','canonicalize_file_name','dbstop','jsondecode','fileread','sprintf'}:raise ValueError('Project file shadows a native execution/path owner')
            # Native Octave resolves the leading function by its real filename.
            code=re.sub(r'(?m)^\s*[%#].*$', '', source).lstrip()
            function=re.match(r'function\s+(?:(?:\[[^\]]*\]|[A-Za-z_]\w*)\s*=\s*)?([A-Za-z_]\w*)',code)
            if function and function.group(1)!=PurePosixPath(name).stem:raise ValueError(f'Octave function name must match {name}')
        try:apis.update(discover(source,language,name,project_policy=True))
        except ValueError as exc:raise ValueError(f'{name}: {exc}') from exc
        for key,value in discover_parameters(source,language,name).items():
            if key in parameters:raise ValueError(f'Duplicate project parameter {key} in {name}')
            value['source_file_sha256']=sha(data)
            parameters[key]=value
        records.append(dict(path=name,sha256=sha(data),size=len(data),role='entrypoint' if name==entrypoint else 'source'))
    result=dict(schema=SCHEMA,language=language,entrypoint=entrypoint,files=records)
    result['sha256']=sha(json.dumps(result,sort_keys=True,separators=(',',':')).encode())
    return result,sorted(apis),parameters

def safe_read(root,name):
    path=root
    if root.is_symlink() or not root.is_dir():raise ValueError('Project root must be a regular directory')
    for part in PurePosixPath(name).parts:
        path=path/part
        if path.is_symlink():raise ValueError('Project symlinks are forbidden')
    if not path.is_file():raise ValueError(f'Missing project file: {name}')
    if path.stat().st_size>4*1024*1024:raise ValueError('Source exceeds bounds')
    return path.read_bytes()

def verify(root):
    root=Path(root)
    if root.is_symlink() or root.parent.is_symlink() or not root.is_dir():raise ValueError('Unsafe project revision directory')
    path=root/'manifest.json'
    if path.is_symlink() or path.stat().st_size>262144:raise ValueError('Unsafe project manifest')
    declared=json.loads(path.read_text())
    if declared.get('schema')!=SCHEMA or not isinstance(declared.get('files'),list) or not 1<=len(declared['files'])<=MAX_FILES:raise ValueError('Unsupported/bounded project manifest required')
    files={};base=root/'files'
    for item in declared['files']:
        name=relative(item['path'],declared['language'])
        if name in files:raise ValueError('Duplicate manifest file')
        files[name]=safe_read(base,name)
    actual,apis,parameters=manifest(declared['language'],declared['entrypoint'],files)
    if actual!=declared:raise ValueError('Project manifest SHA/size/role closure differs')
    actual_paths=set()
    for parent,dirs,names in os.walk(base,followlinks=False):
        for name in dirs+names:
            p=Path(parent)/name
            if p.is_symlink():raise ValueError('Project contains symlink')
        actual_paths.update((Path(parent)/name).relative_to(base).as_posix() for name in names)
    if actual_paths!=set(files):raise ValueError('Project contains unadmitted files')
    if set(p.name for p in root.iterdir())!={'manifest.json','files'}:raise ValueError('Unexpected project revision content')
    return actual,apis,parameters

def projection(root):
    root=Path(root).resolve();m,apis,parameters=verify(root)
    records={x['path']:tcl(x) for x in m['files']}
    return dict(project_manifest=str(root/'manifest.json'),project_root=str(root/'files'),project_sha256=m['sha256'],entrypoint=m['entrypoint'],entrypoint_sha256=next(x['sha256'] for x in m['files'] if x['path']==m['entrypoint']),source_path=str(root/'files'/m['entrypoint']),admitted_sources=tcl([str(root/'files'/x['path']) for x in m['files']]),project_files=tcl(records),declared_apis=';'.join(apis),source_parameters=tcl({k:tcl(v) for k,v in parameters.items()}))

def write(root,language,entrypoint,files):
    root=Path(root);m,_,_=manifest(language,entrypoint,files)
    root.mkdir(parents=True,exist_ok=False)
    try:
        for name,data in files.items():
            p=root/'files'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);p.chmod(0o444)
        (root/'manifest.json').write_text(json.dumps(m,sort_keys=True,indent=2)+'\n')
        verify(root)
    except BaseException:
        shutil.rmtree(root);raise
    return m

class ProjectImportGuard:
    """Pin actual project imports to admitted bytes; not a language sandbox."""
    def __init__(self,root,manifest):
        self.root=Path(root).resolve();self.files={x['path']:x for x in manifest['files']}
        self.modules={PurePosixPath(x).parts[0].removesuffix('.py') for x in self.files}
    def find_spec(self,fullname,path=None,target=None):
        spec=importlib.machinery.PathFinder.find_spec(fullname,path)
        if spec is None:return None
        if spec.origin is None:
            locations=[p for p in spec.submodule_search_locations or [] if Path(p).resolve().is_relative_to(self.root)]
            if locations:spec.submodule_search_locations=locations;return spec
            return None
        origin=Path(spec.origin).resolve()
        if not origin.is_relative_to(self.root):return None
        relative=origin.relative_to(self.root).as_posix()
        if relative not in self.files:raise ImportError(f'Project import is not admitted: {relative}')
        data=safe_read(self.root,relative)
        if sha(data)!=self.files[relative]['sha256']:raise ImportError(f'Project import changed: {relative}')
        class Loader(importlib.abc.Loader):
            def create_module(self,spec):return None
            def exec_module(self,module):exec(compile(data,str(origin),'exec'),module.__dict__)
        spec.loader=Loader();return spec
    def __enter__(self):
        for name in self.modules:
            prior=sys.modules.get(name)
            if prior is not None and not str(getattr(prior,'__file__','')).startswith(str(self.root)+os.sep):raise ImportError(f'Admitted module {name} conflicts with an already-loaded runtime module; rename the project helper')
        sys.meta_path.insert(0,self);return self
    def __exit__(self,*args):
        if self in sys.meta_path:sys.meta_path.remove(self)

def main():
    op=sys.argv[1]
    if op=='publish_registry':
        # Debian/Linux owner primitive: one filesystem transaction publishes
        # source and schema together while retaining the legacy root layout.
        import ctypes
        pending,target=map(Path,sys.argv[2:4]);mode=sys.argv[4]
        def owned_record(path):
            if path.is_symlink() or not path.is_dir():raise ValueError('Unsafe Registry record directory')
            names={p.name for p in path.iterdir()}
            if names not in ({'script.ini','source.py'},{'script.ini','source.m'}) or any(p.is_symlink() or not p.is_file() for p in path.iterdir()):raise ValueError('Registry record contains unexpected content; preserve and review it')
        owned_record(pending)
        if mode=='update':owned_record(target)
        elif mode!='new':raise ValueError('Invalid Registry publication mode')
        libc=ctypes.CDLL(None,use_errno=True)
        primitive=getattr(libc,'renameat2',None)
        if not sys.platform.startswith('linux') or primitive is None:raise ValueError('Atomic Registry publication requires Linux renameat2; original source is unchanged')
        primitive.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint]
        primitive.restype=ctypes.c_int
        for path in pending.iterdir():
            with path.open('rb') as stream:os.fsync(stream.fileno())
        directory_fd=os.open(pending,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(directory_fd)
        finally:os.close(directory_fd)
        if primitive(-100,os.fsencode(pending),-100,os.fsencode(target),2 if mode=='update' else 1):
            error=ctypes.get_errno();raise OSError(error,'Atomic Registry publication refused; original source is unchanged')
        directory_fd=os.open(target.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(directory_fd)
        finally:os.close(directory_fd)
        if mode=='update':shutil.rmtree(pending)
    elif op=='write':
        root,language,entrypoint=sys.argv[2:5]
        maximum=MAX_BYTES*2+MAX_FILES*2048
        raw=sys.stdin.read(maximum+1)
        if len(raw)>maximum:raise ValueError('Project source transport exceeds bounds')
        payload=json.loads(raw)
        write(root,language,entrypoint,{k:bytes.fromhex(v) for k,v in payload.items()})
        print(tcl(projection(root)))
    elif op=='verify':print(tcl(projection(sys.argv[2])))
    elif op=='read':
        root=Path(sys.argv[2]);m,_,_=verify(root)
        if m['sha256']!=sys.argv[3]:raise ValueError('Project source revision changed')
        values={}
        for item in m['files']:
            data=safe_read(root/'files',item['path'])
            if sha(data)!=item['sha256']:raise ValueError('Project changed while reading sources')
            values[item['path']]=data.decode('utf-8')
        print(tcl(values))
    elif op=='copy':
        root,dest=map(Path,sys.argv[2:4]);m,_,_=verify(root)
        if dest.exists():raise ValueError('Snapshot destination exists')
        write(dest,m['language'],m['entrypoint'],{x['path']:safe_read(root/'files',x['path']) for x in m['files']})
        print(tcl(projection(dest)))
    elif op=='export':
        root,dest=map(Path,sys.argv[2:4]);m,_,_=verify(root)
        raw=sys.stdin.read(1048577)
        if len(raw.encode())>1048576:raise ValueError('Portable metadata exceeds bounds')
        import tkinter
        parts=tkinter.Tcl().splitlist(raw)
        if len(parts)%2:raise ValueError('Invalid portable Registry metadata')
        metadata={k:v for k,v in zip(parts[::2],parts[1::2]) if k in PORTABLE_FIELDS}
        package=dict(schema='gxtxt.script_project_package.v1',project_sha256=m['sha256'],metadata=metadata,metadata_sha256=sha(json.dumps(metadata,sort_keys=True,separators=(',',':')).encode()))
        with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
            z.writestr('manifest.json',(root/'manifest.json').read_bytes())
            z.writestr('registry.json',json.dumps(package,sort_keys=True,indent=2)+'\n')
            for item in m['files']:z.writestr('files/'+item['path'],safe_read(root/'files',item['path']))
    elif op=='import':
        src,dest=map(Path,sys.argv[2:4])
        if src.is_symlink() or not src.is_file():raise ValueError('Project import requires a regular archive')
        with zipfile.ZipFile(src) as z:
            entries=z.infolist()
            if len(entries)>MAX_FILES+2 or sum(x.file_size for x in entries)>MAX_BYTES+1048576:raise ValueError('Project archive exceeds bounds')
            if len(set(x.filename for x in entries))!=len(entries) or any(x.flag_bits&1 or (x.external_attr>>16)&0o170000==0o120000 for x in entries):raise ValueError('Unsafe ZIP entries')
            m=json.loads(z.read('manifest.json'))
            if m.get('schema')!=SCHEMA or not isinstance(m.get('files'),list) or not 1<=len(m['files'])<=MAX_FILES:raise ValueError('Unsupported/bounded project archive manifest required')
            expected={'manifest.json'}|{'files/'+relative(x['path'],m['language']) for x in m['files']}
            metadata={}
            if 'registry.json' in z.namelist():
                expected.add('registry.json')
                package=json.loads(z.read('registry.json'))
                metadata=package.get('metadata')
                if package.get('schema')!='gxtxt.script_project_package.v1' or package.get('project_sha256')!=m['sha256'] or not isinstance(metadata,dict) or set(metadata)-PORTABLE_FIELDS or not all(isinstance(k,str) and isinstance(v,str) for k,v in metadata.items()) or package.get('metadata_sha256')!=sha(json.dumps(metadata,sort_keys=True,separators=(',',':')).encode()):raise ValueError('Portable Registry metadata integrity differs')
            if {x.filename for x in entries}!=expected:raise ValueError('Archive has unadmitted content')
            files={x['path']:z.read('files/'+x['path']) for x in m['files']}
            actual,_,_=manifest(m['language'],m['entrypoint'],files)
            if m!=actual:raise ValueError('Archive manifest digest differs')
            write(dest,m['language'],m['entrypoint'],files)
        result=projection(dest);result['portable_metadata']=tcl(metadata)
        print(tcl(result))
    else:raise ValueError('Unknown project operation')
if __name__=='__main__':main()
