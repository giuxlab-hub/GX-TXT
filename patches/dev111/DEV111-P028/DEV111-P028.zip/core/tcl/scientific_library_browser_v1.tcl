# SPDX-License-Identifier: GPL-3.0-or-later
# Generic host Browser adjunct to the existing Scientific Libraries workspace.
# All semantics come from installed domain schemas; no vendor/domain switches.
namespace eval ::GX::LibraryBrowser {variable serial 0;variable states {}}
proc ::GX::LibraryBrowser::str {value} {return [::GX::viewerDevelopmentJsonString $value]}
proc ::GX::LibraryBrowser::object {fields} {return [::GX::LibraryEntryAcquisitionDispatchAPIv1::_strings $fields]}
proc ::GX::LibraryBrowser::array {values} {set result {};foreach value $values {lappend result [str $value]};return \[[join $result ,]\]}
proc ::GX::LibraryBrowser::status {w message} {if {[winfo exists $w]} {$w.status configure -text $message}}
proc ::GX::LibraryBrowser::run {w script} {if {[catch {uplevel 1 $script} message]} {status $w $message;return {}}}
proc ::GX::LibraryBrowser::table {parent columns} {
    ttk::frame $parent
    ttk::treeview $parent.tree -columns $columns -show headings -selectmode extended -height 9
    foreach column $columns {$parent.tree heading $column -text [string totitle [string map {_ { }} $column]];$parent.tree column $column -width 180 -minwidth 80}
    ttk::scrollbar $parent.y -orient vertical -command [list $parent.tree yview]
    ttk::scrollbar $parent.x -orient horizontal -command [list $parent.tree xview]
    $parent.tree configure -yscrollcommand [list $parent.y set] -xscrollcommand [list $parent.x set]
    grid $parent.tree -row 0 -column 0 -sticky nsew;grid $parent.y -row 0 -column 1 -sticky ns;grid $parent.x -row 1 -column 0 -sticky ew
    grid rowconfigure $parent 0 -weight 1;grid columnconfigure $parent 0 -weight 1
    return $parent.tree
}
proc ::GX::LibraryBrowser::open {{parent .}} {
    variable serial;variable states
    package require Tk
    set w .gxLibraryBrowser[incr serial]
    toplevel $w;wm title $w {Scientific Libraries — Records, sources and related entries};wm geometry $w 1160x820;wm minsize $w 680 480
    set schemas [::GX::ScientificLibraryManagerAPIv1::getDomainSchemas]
    dict set states $w [dict create schemas $schemas rows {} source_rows {} bundle {} request {} generation 0 history {} forward_history {} attachments {} allocations {} preview {}]
    ttk::label $w.title -text {Persistent Libraries • explicitly select what to save or import to a Session} -padding 8
    pack $w.title -fill x
    ttk::notebook $w.tabs;pack $w.tabs -fill both -expand 1
    foreach {tab label} {records {Library records} sources {Remote sources} manual {Manual entry and local files}} {ttk::frame $w.tabs.$tab -padding 8;$w.tabs add $w.tabs.$tab -text $label}
    ttk::button $w.receipt -text {View last operation receipt} -command [list ::GX::LibraryBrowser::showReceipt $w]
    pack $w.receipt -anchor w -padx 8
    ttk::label $w.status -text {Ready. Library operations do not require a Session.} -wraplength 1050 -padding 8;pack $w.status -fill x
    buildRecords $w;buildSources $w;buildManual $w
    bind $w <Destroy> [list ::GX::LibraryBrowser::closed $w %W]
    bind $w <Configure> [list ::GX::LibraryBrowser::layout $w %W %w]
    wm protocol $w WM_DELETE_WINDOW [list destroy $w]
    refresh $w
    return $w
}
proc ::GX::LibraryBrowser::closed {w actual} {
    variable states
    if {$actual ne $w || ![dict exists $states $w]} return
    set state [dict get $states $w]
    if {[dict get $state request] ne {}} {catch {::GX::scriptJobRequestCancel [dict get $state request]}}
    foreach allocation [dict get $state allocations] {catch {::GX::resourceManagementRelease [dict get $allocation id]};catch {::GX::resourceManagementCleanup [list [dict get $allocation id]]}}
    dict unset states $w
}
proc ::GX::LibraryBrowser::buildRecords {w} {
    set p $w.tabs.records
    ttk::frame $p.search
    ttk::label $p.search.label -text Search
    ttk::entry $p.search.query -width 36
    ttk::combobox $p.search.type -values [linsert [dict keys [dict get $::GX::LibraryBrowser::states $w schemas record_types]] 0 {All record types}] -state readonly -width 30
    $p.search.type set {All record types}
    ttk::button $p.search.go -text Search -command [list ::GX::LibraryBrowser::refresh $w]
    ttk::button $p.search.previous -text Previous -command [list ::GX::LibraryBrowser::page $w -100]
    ttk::button $p.search.next -text Next -command [list ::GX::LibraryBrowser::page $w 100]
    pack $p.search.label $p.search.query $p.search.type $p.search.go $p.search.previous $p.search.next -side left -padx 3
    pack $p.search -fill x
    bind $p.search.query <Return> [list ::GX::LibraryBrowser::refresh $w]
    table $p.list {library_id entry_id record_type label};pack $p.list -fill both -expand 1 -pady 5
    bind $p.list.tree <<TreeviewSelect>> [list ::GX::LibraryBrowser::inspect $w]
    ttk::notebook $p.detail;pack $p.detail -fill both -expand 1
    foreach {tab label} {properties {Typed properties and provenance} related {Incoming / outgoing relations} resources {Images and documents}} {ttk::frame $p.detail.$tab;$p.detail add $p.detail.$tab -text $label}
    table $p.detail.properties.values {field value};pack $p.detail.properties.values -fill both -expand 1
    ttk::frame $p.detail.related.actions
    ttk::button $p.detail.related.actions.open -text {Open selected related entry} -command [list ::GX::LibraryBrowser::follow $w]
    ttk::button $p.detail.related.actions.back -text Back -command [list ::GX::LibraryBrowser::back $w]
    ttk::button $p.detail.related.actions.forward -text Forward -command [list ::GX::LibraryBrowser::forward $w]
    pack $p.detail.related.actions.open $p.detail.related.actions.back $p.detail.related.actions.forward -side left -padx 3;pack $p.detail.related.actions -fill x
    ttk::frame $p.detail.related.filters
    ttk::combobox $p.detail.related.filters.direction -values {both outgoing incoming} -state readonly -width 10;$p.detail.related.filters.direction set both
    ttk::combobox $p.detail.related.filters.type -values [linsert [dict keys [dict get $::GX::LibraryBrowser::states $w schemas relations]] 0 {All relation types}] -state readonly -width 25;$p.detail.related.filters.type set {All relation types}
    ttk::entry $p.detail.related.filters.source -width 16
    ttk::button $p.detail.related.filters.query -text Filter -command [list ::GX::LibraryBrowser::relatedRefresh $w 0]
    ttk::button $p.detail.related.filters.previous -text Previous -command [list ::GX::LibraryBrowser::relatedPage $w -100]
    ttk::button $p.detail.related.filters.next -text Next -command [list ::GX::LibraryBrowser::relatedPage $w 100]
    ttk::label $p.detail.related.filters.sourceLabel -text Source
    grid $p.detail.related.filters.direction -row 0 -column 0 -sticky ew -padx 2 -pady 2
    grid $p.detail.related.filters.type -row 0 -column 1 -columnspan 4 -sticky ew -padx 2 -pady 2
    grid $p.detail.related.filters.sourceLabel -row 1 -column 0 -sticky w -padx 2
    foreach {control column} {source 1 query 2 previous 3 next 4} {grid $p.detail.related.filters.$control -row 1 -column $column -sticky ew -padx 2 -pady 2}
    grid columnconfigure $p.detail.related.filters 1 -weight 1
    pack $p.detail.related.filters -fill x
    table $p.detail.related.values {relation_type direction source_id resolution evidence};pack $p.detail.related.values -fill both -expand 1
    table $p.detail.resources.values {role availability media_type sha256};pack $p.detail.resources.values -fill both -expand 1
    ttk::button $p.detail.resources.open -text {Open selected original / image} -command [list ::GX::LibraryBrowser::openResource $w]
    pack $p.detail.resources.open -anchor w -pady 3
    ttk::frame $p.actions
    ttk::button $p.actions.acquire -text {Import selected to Session…} -command [list ::GX::LibraryBrowser::acquire $w]
    ttk::button $p.actions.edit -text {Edit selected record…} -command [list ::GX::LibraryBrowser::edit $w]
    pack $p.actions.acquire $p.actions.edit -side left -padx 3;pack $p.actions -fill x
}
proc ::GX::LibraryBrowser::refresh {w {offset 0}} {
    variable states
    run $w {
        set p $w.tabs.records;set type [$p.search.type get];if {$type eq {All record types}} {set type {}}
        set result [::GX::ScientificLibraryManagerAPIv1::searchAcrossLibraries [format {{"query":%s,"record_type":%s,"offset":%d,"limit":100}} [str [$p.search.query get]] [str $type] $offset]]
        dict set states $w rows [dict get $result records];dict set states $w offset $offset
        $p.list.tree delete [$p.list.tree children {}]
        set index 0;foreach row [dict get $result records] {$p.list.tree insert {} end -id [incr index] -values [list [dict get $row library_id] [dict get $row entry_id] [dict get $row record_type] [dict get $row label]]}
        set unavailable [::GX::datasetPublicationV2DictDefault $result unavailable_libraries {}]
        dict set states $w unavailable_libraries $unavailable
        status $w "[llength [dict get $result records]] / [dict get $result total] persistent records • [llength $unavailable] unavailable Libraries • offset $offset • no Session changes"
    }
}
proc ::GX::LibraryBrowser::page {w delta} {refresh $w [expr {max(0,[dict get $::GX::LibraryBrowser::states $w offset]+$delta)}]}
proc ::GX::LibraryBrowser::reference {w} {
    set ids [$w.tabs.records.list.tree selection]
    if {[llength $ids]!=1} {error {Select exactly one record to inspect}}
    return [dict remove [lindex [dict get $::GX::LibraryBrowser::states $w rows] [expr {[lindex $ids 0]-1}]] label]
}
proc ::GX::LibraryBrowser::inspect {w {reference {}}} {
    variable states
    run $w {
        if {$reference eq {}} {set reference [reference $w]}
        set json [object $reference]
        set entry [::GX::ScientificLibraryManagerAPIv1::domainRequest detail [format {{"reference":%s}} $json]]
        dict set states $w selected_reference $reference;dict set states $w selected_entry $entry
        set p $w.tabs.records.detail
        $p.properties.values.tree delete [$p.properties.values.tree children {}]
        dict for {key value} [dict get $entry fields] {$p.properties.values.tree insert {} end -values [list $key $value]}
        dict for {key value} [dict get $entry provenance] {$p.properties.values.tree insert {} end -values [list provenance.$key $value]}
        set related [::GX::ScientificLibraryManagerAPIv1::relatedEntries [format {{"reference":%s,"limit":100}} $json]]
        dict set states $w relations [dict get $related records]
        $p.related.values.tree delete [$p.related.values.tree children {}]
        set n 0;foreach edge [dict get $related records] {
            set direction [expr {[dict get $edge from_reference library_id] eq [dict get $reference library_id] && [dict get $edge from_reference entry_id] eq [dict get $reference entry_id]?{outgoing}:{incoming}}]
            $p.related.values.tree insert {} end -id [incr n] -values [list [dict get $edge relation_type] $direction [dict get $edge source_id] [dict get $edge resolution_status] [dict get $edge evidence]]
        }
        $p.resources.values.tree delete [$p.resources.values.tree children {}]
        set n 0;foreach resource [dict get $entry resources] {$p.resources.values.tree insert {} end -id [incr n] -values [list [dict get $resource role] [dict get $resource availability] [::GX::datasetPublicationV2DictDefault $resource media_type {}] [::GX::datasetPublicationV2DictDefault $resource sha256 {}]]}
        status $w "[dict get $entry label] • [dict get $entry record_type] • revision [dict get $entry revision] • [dict get $related total] related assertions (first 100 shown)"
    }
}
proc ::GX::LibraryBrowser::follow {w} {
    variable states
    run $w {
        set selected [$w.tabs.records.detail.related.values.tree selection]
        if {[llength $selected]!=1} {error {Select one relation}}
        set edge [lindex [dict get $states $w relations] [expr {[lindex $selected 0]-1}]]
        set reference [dict get $states $w selected_reference]
        set target [dict get $edge target]
        if {[dict get $edge from_reference library_id] ne [dict get $reference library_id] || [dict get $edge from_reference entry_id] ne [dict get $reference entry_id]} {set target [dict get $edge from_reference]}
        if {[dict get $target kind] eq {external_source_entity}} {
            set parameters [dict create source_id [dict get $target source_id] external_id [dict get $target external_id] record_type [dict get $target record_type]]
            set candidates [::GX::ScientificLibraryManagerAPIv1::resolveExternalId [object $parameters]]
            if {![llength [dict get $candidates records]]} {error {No exact local candidate for this external source identity. Its evidence remains unresolved; no implicit remote fetch or import.}}
            set labels {};set mapping {};foreach candidate [dict get $candidates records] {set label "[dict get $candidate library_id]/[dict get $candidate entry_id] revision [dict get $candidate revision]";lappend labels $label;dict set mapping $label $candidate}
            dict set states $w external_candidates $mapping
            ::GX::uiFieldFormCreate $w.externalCandidate {Review exact external identity candidate} [dict create candidate [dict create type choice values $labels label {Pinned local candidate}]] [dict create candidate [lindex $labels 0]] [list ::GX::LibraryBrowser::externalCandidate $w] $w
            return
        }
        if {[dict get $target kind] ne {library_entry}} {error {This is an exact canonical Dataset reference. Open its named Session and use its Dataset Browser; the semantic assertion does not copy or mutate the Dataset.}}
        set state [dict get $states $w];dict lappend state history $reference;dict set state forward_history {};dict set states $w $state
        inspect $w $target
    }
}
proc ::GX::LibraryBrowser::back {w} {
    variable states
    set history [dict get $states $w history]
    if {$history eq {}} return
    set state [dict get $states $w];dict lappend state forward_history [dict get $state selected_reference];dict set state history [lrange $history 0 end-1];dict set states $w $state
    inspect $w [lindex $history end]
}
proc ::GX::LibraryBrowser::buildSources {w} {
    variable states
    set p $w.tabs.sources
    ttk::frame $p.top
    ttk::label $p.top.label -text {Registered source}
    ttk::combobox $p.top.source -state readonly -width 32
    ttk::button $p.top.reload -text Refresh -command [list ::GX::LibraryBrowser::sourceList $w]
    ttk::button $p.top.register -text {Register installed connector…} -command [list ::GX::LibraryBrowser::register $w]
    ttk::button $p.top.credentials -text {Credentials…} -command [list ::GX::LibraryBrowser::credentials $w]
    pack $p.top.label $p.top.source $p.top.reload $p.top.register $p.top.credentials -side left -padx 3;pack $p.top -fill x
    ttk::frame $p.lookup
    ttk::label $p.lookup.label -text {Query / exact source identity}
    ttk::entry $p.lookup.query -width 40
    ttk::button $p.lookup.search -text {Look up (read only)} -command [list ::GX::LibraryBrowser::lookup $w]
    ttk::button $p.lookup.cancel -text {Cancel request} -command [list ::GX::LibraryBrowser::cancel $w]
    pack $p.lookup.label $p.lookup.query $p.lookup.search $p.lookup.cancel -side left -padx 3;pack $p.lookup -fill x -pady 4
    bind $p.lookup.query <Return> [list ::GX::LibraryBrowser::lookup $w]
    table $p.results {entry_id metadata};pack $p.results -fill both -expand 1
    ttk::button $p.preview -text {Preview selected exact record} -command [list ::GX::LibraryBrowser::sourcePreview $w]
    pack $p.preview -anchor w -pady 3
    table $p.selection {entry_id record_type label resources};pack $p.selection -fill both -expand 1
    bind $p.selection.tree <Double-1> [list ::GX::LibraryBrowser::sourceInspect $w]
    ttk::button $p.inspect -text {Inspect selected source fields / media / documents} -command [list ::GX::LibraryBrowser::sourceInspect $w]
    pack $p.inspect -anchor w -pady 3
    ttk::label $p.hint -text {Select any subset above. Source lookup and preview do not save Library entries or create Datasets.} -wraplength 1000
    pack $p.hint -fill x
    ttk::frame $p.options
    ttk::label $p.options.label -text {Destination Library ID prefix}
    ttk::entry $p.options.prefix -width 24;$p.options.prefix insert 0 personal
    ttk::checkbutton $p.options.files -text {Download selected linked files} -variable ::GX::LibraryBrowser::download($w)
    set ::GX::LibraryBrowser::download($w) 1
    ttk::checkbutton $p.options.alternatives -text {Include reviewed source suggestions} -variable ::GX::LibraryBrowser::alternatives($w)
    set ::GX::LibraryBrowser::alternatives($w) 0
    pack $p.options.label $p.options.prefix $p.options.files $p.options.alternatives -side left -padx 3;pack $p.options -fill x -pady 3
    table $p.suggestions {sku native_class evidence};pack $p.suggestions -fill both -expand 1
    ttk::button $p.suggestionPreview -text {Preview selected suggestion before selection} -command [list ::GX::LibraryBrowser::suggestionPreview $w]
    pack $p.suggestionPreview -anchor w
    ttk::button $p.commit -text {Import selected into persistent Libraries} -command [list ::GX::LibraryBrowser::sourceImport $w]
    pack $p.commit -anchor w -pady 5
    sourceList $w
}
proc ::GX::LibraryBrowser::sourceList {w} {
    set ids {}
    foreach record [::GX::ScientificLibraryManagerAPIv1::listRegisteredLibraries] {if {[dict get $record mode] eq {remote}} {lappend ids [dict get $record library_id]}}
    $w.tabs.sources.top.source configure -values $ids
    if {[llength $ids] && [$w.tabs.sources.top.source get] ni $ids} {$w.tabs.sources.top.source set [lindex $ids 0]}
}
proc ::GX::LibraryBrowser::register {w} {
    run $w {
        set connectors [::GX::ScientificLibraryManagerAPIv1::listSourceConnectors]
        set choices [dict keys [dict get $connectors connectors]]
        if {$choices eq {}} {error {Install a Library Source Connector with the existing Plugin Manager}}
        ::GX::uiFieldFormCreate $w.register {Register Library Source Connector} [dict create connector [dict create type choice values $choices label Connector] library_id {type string label {Stable source registration ID}} display_name {type string label {Source display name}}] [dict create connector [lindex $choices 0]] [list ::GX::LibraryBrowser::registerCommit $w] $w
    }
}
proc ::GX::LibraryBrowser::registerCommit {w values} {
    run $w {
        set info [dict get [::GX::ScientificLibraryManagerAPIv1::listSourceConnectors] connectors [dict get $values connector]]
        set type [lindex [dict get $info library_types] 0]
        ::GX::ScientificLibraryManagerAPIv1::registerLibrary [dict create library_id [dict get $values library_id] library_type $type mode remote display_name [dict get $values display_name] config.connector [dict get $values connector]]
        sourceList $w
        status $w {Source registered. Connection has not been probed. Use Look up for an on-demand source check.}
    }
}
proc ::GX::LibraryBrowser::credentials {w} {
    run $w {
        set source [$w.tabs.sources.top.source get]
        if {$source eq {}} {error {Choose a registered source}}
        ::GX::_scientificLibraryCredentialsDialog $w
    }
}
proc ::GX::LibraryBrowser::cancel {w} {
    variable states
    if {[dict get $states $w request] ne {}} {::GX::scriptJobRequestCancel [dict get $states $w request];status $w {Cancellation requested. A committed Library batch remains saved; wait for its receipt.}}
}
proc ::GX::LibraryBrowser::request {w operation arguments stage} {
    variable states
    if {[dict get $states $w request] ne {}} {error {Wait for the current source request or cancel it}}
    set generation [expr {[dict get $states $w generation]+1}];dict set states $w generation $generation
    set token [::GX::ScientificLibraryManagerAPIv1::libraryRequest $operation $arguments [list ::GX::LibraryBrowser::reply $w $generation $stage]]
    dict set states $w request $token
    status $w {Source request in progress…}
}
proc ::GX::LibraryBrowser::lookup {w} {
    variable states
    run $w {
        dict set states $w source_rows {};dict set states $w bundle {};dict set states $w alternative_skus {}
        $w.tabs.sources.selection.tree delete [$w.tabs.sources.selection.tree children {}]
        set source [$w.tabs.sources.top.source get];if {$source eq {}} {error {Register and select a source first}}
        dict set states $w source_library $source
        request $w content [list $source search_entries [dict create query_json [str [$w.tabs.sources.lookup.query get]] limit 50]] search
    }
}
proc ::GX::LibraryBrowser::sourcePreview {w} {
    variable states
    run $w {
        set ids [$w.tabs.sources.results.tree selection]
        if {[llength $ids]!=1} {error {Select one exact source result; ambiguity must be resolved before import}}
        set row [lindex [dict get $states $w source_rows] [expr {[lindex $ids 0]-1}]]
        dict set states $w primary_source_entry [dict get $row entry_id]
        request $w content [list [dict get $states $w source_library] read_entry [dict create entry_id [dict get $row entry_id]]] preview
    }
}
proc ::GX::LibraryBrowser::suggestionPreview {w} {
    variable states
    run $w {
        if {!$::GX::LibraryBrowser::alternatives($w)} {error {Enable Include reviewed source suggestions to inspect an optional candidate}}
        set ids [$w.tabs.sources.suggestions.tree selection]
        if {[llength $ids]!=1} {error {Choose one actual supplier suggestion}}
        set suggestion [lindex [dict get $states $w bundle suggestions] [expr {[lindex $ids 0]-1}]]
        set sku [dict get $suggestion sku]
        dict set states $w pending_alternative $sku
        request $w content [list [dict get $states $w source_library] read_entry [dict create entry_id $sku]] alternative
    }
}
proc ::GX::LibraryBrowser::reply {w generation stage response} {
    variable states
    if {![dict exists $states $w] || [dict get $states $w generation]!=$generation || ![winfo exists $w]} return
    dict set states $w request {}
    run $w {
        if {![dict get $response ok]} {error [dict get $response error]}
        set result [dict get $response result];set p $w.tabs.sources
        switch $stage {
            search {
                dict set states $w source_rows [dict get $result records]
                $p.results.tree delete [$p.results.tree children {}]
                set n 0;foreach row [dict get $result records] {$p.results.tree insert {} end -id [incr n] -values [list [dict get $row entry_id] [dict get $row metadata]]}
                status $w {Lookup completed without saving Library entries. Select an exact result and preview.}
            }
            preview - alternative {
                set bundle [dict get $result payload]
                if {$stage eq {alternative}} {
                    set old [dict get $states $w bundle]
                    dict set old entries [concat [dict get $old entries] [dict get $bundle entries]]
                    set bundle $old
                    set skus [::GX::datasetPublicationV2DictDefault [dict get $states $w] alternative_skus {}]
                    lappend skus [dict get $states $w pending_alternative]
                    dict set states $w alternative_skus [lsort -unique $skus]
                }
                dict set states $w bundle $bundle
                $p.commit state [expr {[::GX::datasetPublicationV2DictDefault $bundle persistent_import_available 1]?{!disabled}:{disabled}}]
                $p.selection.tree delete [$p.selection.tree children {}]
                set n 0;foreach row [dict get $bundle entries] {
                    set entry [dict get $row entry]
                    $p.selection.tree insert {} end -id [incr n] -values [list [dict get $entry entry_id] [dict get $entry record_type] [dict get $entry label] [llength [dict get $entry resources]]]
                }
                $p.suggestions.tree delete [$p.suggestions.tree children {}]
                set n 0;foreach suggestion [dict get $bundle suggestions] {$p.suggestions.tree insert {} end -id [incr n] -values [list [dict get $suggestion sku] [dict get $suggestion native_class] [dict get $suggestion evidence]]}
                if {![::GX::datasetPublicationV2DictDefault $bundle persistent_import_available 1]} {
                    status $w [dict get $bundle persistence_reason]
                } else {status $w {Preview ready. Select only the records and resources to save. Suggestions are source claims; engineering compatibility is unverified.}}
            }
            image {sourceImageReply $w $result}
            imported {dict set states $w last_receipt $result;refresh $w;status $w "Library source import: [dict get $result status]. View last operation receipt for per-Library results."}
        }
    }
}
proc ::GX::LibraryBrowser::sourceImport {w} {
    variable states
    run $w {
        set p $w.tabs.sources;set chosen [$p.selection.tree selection]
        if {$chosen eq {}} {error {Select the records to preserve in Libraries}}
        set bundle [dict get $states $w bundle];set ids {};set destinations {}
        foreach id $chosen {
            set row [lindex [dict get $bundle entries] [expr {$id-1}]]
            lappend ids [dict get $row entry entry_id]
            dict set destinations [dict get $row library_type] "[$p.options.prefix get]-[dict get $row library_type]"
        }
        set alternativeSkus {};if {$::GX::LibraryBrowser::alternatives($w)} {set alternativeSkus [::GX::datasetPublicationV2DictDefault [dict get $states $w] alternative_skus {}]}
        set primary [dict get [lindex [dict get $bundle entries] 0] entry]
        set expected [::GX::datasetPublicationV2DictDefault [dict get $primary provenance] original_record_sha256 {}]
        set parameters [format {{"entry_id":%s,"selected_ids":%s,"destinations":%s,"expected_source_sha256":%s,"download_assets":%s,"selected_alternatives":%s}} [str [dict get $states $w primary_source_entry]] [array $ids] [object $destinations] [str $expected] [expr {$::GX::LibraryBrowser::download($w)?{true}:{false}}] [array $alternativeSkus]]
        request $w source_import [list [dict get $states $w source_library] $parameters] imported
    }
}
proc ::GX::LibraryBrowser::manualRoot {w} {return $w.tabs.manual.viewport.content}
proc ::GX::LibraryBrowser::buildManual {w} {
    set tab $w.tabs.manual
    canvas $tab.viewport -highlightthickness 0
    ttk::scrollbar $tab.scroll -orient vertical -command [list $tab.viewport yview]
    $tab.viewport configure -yscrollcommand [list $tab.scroll set]
    ttk::frame $tab.viewport.content -padding 6
    $tab.viewport create window 0 0 -anchor nw -window $tab.viewport.content -tags content
    bind $tab.viewport <Configure> [list $tab.viewport itemconfigure content -width %w]
    bind $tab.viewport.content <Configure> [list $tab.viewport configure -scrollregion [list 0 0 %w %h]]
    pack $tab.scroll -side right -fill y
    pack $tab.viewport -fill both -expand 1
    set p $tab.viewport.content
    bind $w <MouseWheel> [list ::GX::LibraryBrowser::manualWheel $w %W %D]
    bind $w <Button-4> [list ::GX::LibraryBrowser::manualWheel $w %W 120]
    bind $w <Button-5> [list ::GX::LibraryBrowser::manualWheel $w %W -120]
    ttk::frame $p.identity
    ttk::label $p.identity.typeLabel -text {Record schema}
    ttk::combobox $p.identity.type -state readonly -values [dict keys [dict get $::GX::LibraryBrowser::states $w schemas record_types]] -width 32
    ttk::label $p.identity.sourceLabel -text {Source / attribution}
    ttk::entry $p.identity.source -width 36
    grid $p.identity.typeLabel -row 0 -column 0 -sticky w -padx 4 -pady 4
    grid $p.identity.type -row 0 -column 1 -sticky ew -padx 4 -pady 4
    grid $p.identity.sourceLabel -row 1 -column 0 -sticky w -padx 4 -pady 4
    grid $p.identity.source -row 1 -column 1 -sticky ew -padx 4 -pady 4
    grid columnconfigure $p.identity 1 -weight 1
    pack $p.identity -fill x
    ttk::frame $p.names
    foreach {key label default} {library {Library ID} personal label {Entry label} {} entry {Stable entry ID (blank creates new)} {}} {
        ttk::label $p.names.${key}Label -text $label;ttk::entry $p.names.$key -width 26;$p.names.$key insert 0 $default
        set row [expr {$key eq {library}?0:($key eq {label}?1:2)}]
        grid $p.names.${key}Label -row $row -column 0 -sticky w -padx 4 -pady 3
        grid $p.names.$key -row $row -column 1 -sticky ew -padx 4 -pady 3
    }
    grid columnconfigure $p.names 1 -weight 1
    pack $p.names -fill x -pady 4
    ttk::frame $p.fields
    ttk::frame $p.fields.content
    pack $p.fields.content -fill x
    pack $p.fields -fill x
    ttk::label $p.pasteLabel -text {Paste original specifications (name TAB value or name: value; parsed according to schema)}
    pack $p.pasteLabel -anchor w
    text $p.paste -height 5 -wrap none -undo 1;pack $p.paste -fill x
    ttk::frame $p.files
    ttk::label $p.files.label -text {Local file role}
    ttk::combobox $p.files.role -values {photo datasheet drawing pinout footprint_illustration document} -width 22;$p.files.role set document
    ttk::button $p.files.add -text {Add downloaded PDF / image…} -command [list ::GX::LibraryBrowser::attach $w]
    ttk::button $p.files.clear -text {Clear selected files} -command [list ::GX::LibraryBrowser::clearAttachments $w]
    grid $p.files.label -row 0 -column 0 -sticky w -padx 3
    grid $p.files.role -row 0 -column 1 -sticky ew -padx 3
    grid $p.files.add -row 1 -column 0 -columnspan 2 -sticky w -pady 3
    grid $p.files.clear -row 1 -column 2 -sticky w -pady 3
    pack $p.files -fill x -pady 3
    ttk::label $p.fileSummary -text {No local attachments} -wraplength 700;pack $p.fileSummary -fill x
    table $p.attachments {role filename sha256}
    $p.attachments.tree configure -height 3
    pack $p.attachments -fill x
    bind $p.attachments.tree <Double-1> [list ::GX::LibraryBrowser::manualOpenAttachment $w]
    ttk::button $p.openAttachment -text {Preview selected original file} -command [list ::GX::LibraryBrowser::manualOpenAttachment $w]
    pack $p.openAttachment -anchor w
    ttk::frame $p.actions
    ttk::button $p.actions.preview -text {Preview typed record} -command [list ::GX::LibraryBrowser::manualPreview $w]
    ttk::button $p.actions.save -text {Save into persistent Library} -command [list ::GX::LibraryBrowser::manualSave $w]
    ttk::button $p.actions.cancel -text {Cancel draft} -command [list ::GX::LibraryBrowser::manualCancel $w]
    pack $p.actions.preview $p.actions.save $p.actions.cancel -side left -padx 3;pack $p.actions -fill x -pady 4
    bind $p.identity.type <<ComboboxSelected>> [list ::GX::LibraryBrowser::manualFields $w]
    set types [$p.identity.type cget -values]
    if {[llength $types]} {$p.identity.type set [lindex $types 0];manualFields $w}
    ::GX::uiFieldScrollAreaAttach $tab.viewport $tab.viewport.content
}
proc ::GX::LibraryBrowser::manualFields {w} {
    variable states
    set p [manualRoot $w];set type [$p.identity.type get]
    foreach child [winfo children $p.fields.content] {destroy $child}
    set definition [dict get $states $w schemas record_types $type]
    set controls {};set editors {};set n 0
    if {[dict exists $definition manual_templates]} {
        ttk::label $p.fields.content.templateLabel -text {Field template}
        ttk::combobox $p.fields.content.template -state readonly -values [dict keys [dict get $definition manual_templates]]
        $p.fields.content.template set [lindex [dict keys [dict get $definition manual_templates]] 0]
        grid $p.fields.content.templateLabel -row $n -column 0 -sticky w -padx 6 -pady 8
        grid $p.fields.content.template -row $n -column 1 -sticky ew -padx 6 -pady 8
        bind $p.fields.content.template <<ComboboxSelected>> [list ::GX::LibraryBrowser::manualTemplate $w]
    }
    dict for {key fieldDefinition} [dict get $definition fields] {
        set field $p.fields.content.f[incr n]
        set label [::GX::datasetPublicationV2DictDefault $fieldDefinition label $key]
        set editor [::GX::datasetPublicationV2DictDefault $fieldDefinition editor entry]
        ttk::label ${field}label -text "$label[expr {[::GX::datasetPublicationV2DictDefault $fieldDefinition required 0]?{ *}:{}}]"
        if {$editor eq {table}} {
            table $field [dict keys [dict get $fieldDefinition columns]]
            $field.tree configure -height 5
            dict for {column columnDefinition} [dict get $fieldDefinition columns] {
                $field.tree heading $column -text [::GX::datasetPublicationV2DictDefault $columnDefinition label $column]
                $field.tree column $column -width 155
            }
            ttk::frame $field.actions
            foreach {action title} {add Add edit Edit remove Remove} {
                ttk::button $field.actions.$action -text $title -command [list ::GX::LibraryBrowser::tableEdit $w $key $action]
                pack $field.actions.$action -side left -padx 3
            }
            grid $field.actions -row 2 -column 0 -sticky w -pady 3
            dict set states $w table_rows $key {}
            bind $field.tree <Double-1> [list ::GX::LibraryBrowser::tableEdit $w $key edit]
            bind $field.tree <Delete> [list ::GX::LibraryBrowser::tableEdit $w $key remove]
        } elseif {$editor eq {multiline}} {text $field -height 3 -wrap word -undo 1
        } elseif {$editor eq {choice}} {ttk::combobox $field -values [dict get $fieldDefinition choices]
        } else {ttk::entry $field -width 54}
        grid ${field}label -row $n -column 0 -sticky nw -padx 6 -pady 5
        grid $field -row $n -column 1 -sticky ew -padx 6 -pady 5
        dict set controls $key $field
        dict set editors $key $editor
    }
    grid columnconfigure $p.fields.content 1 -weight 1
    dict set states $w manual_controls $controls;dict set states $w manual_editors $editors;dict set states $w previous {}
    if {[dict exists $definition manual_templates]} {manualTemplate $w}
}
proc ::GX::LibraryBrowser::manualTemplate {w} {
    variable states
    set p [manualRoot $w]
    set definition [dict get $states $w schemas record_types [$p.identity.type get]]
    set selected [$p.fields.content.template get]
    set template [dict get $definition manual_templates $selected]
    dict for {key value} [dict get $template fields] {
        set control [dict get $states $w manual_controls $key]
        if {[$control get] eq {}} {$control insert 0 $value}
    }
    dict for {key rows} [dict get $template tables] {
        # Template rows are empty prompts. Preserve already-entered properties.
        set old [dict get $states $w table_rows $key]
        set keep {};foreach row $old {if {[::GX::datasetPublicationV2DictDefault $row source_value {}] ne {}} {lappend keep $row}}
        dict set states $w table_rows $key [concat $keep $rows]
        tableRender $w $key
    }
}
proc ::GX::LibraryBrowser::tableRender {w key} {
    variable states
    set control [dict get $states $w manual_controls $key]
    set schema [dict get $states $w schemas record_types [[manualRoot $w].identity.type get] fields $key]
    $control.tree delete [$control.tree children {}]
    set n 0;foreach row [dict get $states $w table_rows $key] {
        set values {};foreach column [dict keys [dict get $schema columns]] {lappend values [::GX::datasetPublicationV2DictDefault $row $column {}]}
        $control.tree insert {} end -id [incr n] -values $values
    }
}
proc ::GX::LibraryBrowser::tableEdit {w key action} {
    variable states
    run $w {
        set control [dict get $states $w manual_controls $key]
        set rows [dict get $states $w table_rows $key]
        set index -1;set initial {}
        if {$action ne {add}} {
            set selected [$control.tree selection]
            if {[llength $selected]!=1} {error {Select one specification row}}
            set index [expr {[lindex $selected 0]-1}];set initial [lindex $rows $index]
        }
        if {$action eq {remove}} {dict set states $w table_rows $key [lreplace $rows $index $index];tableRender $w $key;return}
        if {[llength $rows]>=100 && $action eq {add}} {error {A manual specification table is bounded to 100 rows}}
        set columns [dict get $states $w schemas record_types [[manualRoot $w].identity.type get] fields $key columns]
        set fields {}
        dict for {column definition} $columns {
            set field [dict create type string label [::GX::datasetPublicationV2DictDefault $definition label $column]]
            if {[dict exists $definition choices]} {dict set field type choice;dict set field values [dict get $definition choices]}
            dict set fields $column $field
        }
        ::GX::uiFieldFormCreate $w.specificationRow {Technical specification — preserve original value} $fields $initial [list ::GX::LibraryBrowser::tableCommit $w $key $index] $w
    }
}
proc ::GX::LibraryBrowser::tableCommit {w key index values} {
    variable states
    set rows [dict get $states $w table_rows $key]
    if {$index<0} {lappend rows $values} else {set rows [lreplace $rows $index $index $values]}
    dict set states $w table_rows $key $rows
    tableRender $w $key
}
proc ::GX::LibraryBrowser::tableJson {w key} {
    variable states
    set schema [dict get $states $w schemas record_types [[manualRoot $w].identity.type get] fields $key]
    set result {}
    foreach row [dict get $states $w table_rows $key] {
        set skip [::GX::datasetPublicationV2DictDefault $schema skip_empty_field {}]
        if {$skip ne {} && [::GX::datasetPublicationV2DictDefault $row $skip {}] eq {}} continue
        set fields {}
        dict for {column definition} [dict get $schema columns] {
            set value [::GX::datasetPublicationV2DictDefault $row $column {}]
            if {$value eq {}} continue
            set encoded [str $value]
            if {[dict get $definition type] in {number integer}} {
                if {![regexp {^-?(0|[1-9][0-9]*)([.][0-9]+)?([eE][+-]?[0-9]+)?$} $value]} {error "Enter a valid numeric value in $column, or leave it blank"}
                set encoded $value
            }
            lappend fields "[str $column]:$encoded"
        }
        lappend result \{[join $fields ,]\}
    }
    return \[[join $result ,]\]
}
proc ::GX::LibraryBrowser::attach {w} {
    variable states
    run $w {
        set paths [tk_getOpenFile -parent $w -multiple 1 -title {Select already-downloaded PDF or images} -filetypes {{{PDF and images} {.pdf .png .jpg .jpeg .gif}} {{All files} *}}]
        set attachments [dict get $states $w attachments]
        foreach path $paths {lappend attachments [dict create path $path role [[manualRoot $w].files.role get] expected_sha256 [::GX::sha256File $path]]}
        if {[llength $attachments]>32} {error {Select at most 32 local attachments}}
        dict set states $w attachments $attachments
        manualAttachments $w
    }
}
proc ::GX::LibraryBrowser::clearAttachments {w} {dict set ::GX::LibraryBrowser::states $w attachments {};manualAttachments $w}
proc ::GX::LibraryBrowser::manualParameters {w {withFiles 0}} {
    variable states
    set p [manualRoot $w];set fields {}
    dict for {key control} [dict get $states $w manual_controls] {
        switch [dict get $states $w manual_editors $key] {
            table {dict set fields $key [tableJson $w $key]}
            multiline {dict set fields $key [$control get 1.0 end-1c]}
            default {dict set fields $key [$control get]}
        }
    }
    set attachments {}
    if {$withFiles} {foreach item [dict get $states $w attachments] {lappend attachments [object $item]}}
    set parameters [format {"record_type":%s,"fields":%s,"raw_fields":true,"source_id":%s,"label":%s,"entry_id":%s,"pasted_text":%s,"attachments":[%s]} [str [$p.identity.type get]] [object $fields] [str [$p.identity.source get]] [str [$p.names.label get]] [str [$p.names.entry get]] [str [$p.paste get 1.0 end-1c]] [join $attachments ,]]
    if {[dict get $states $w previous] ne {}} {append parameters ,\"previous\": [object [dict get $states $w previous]]}
    return $parameters
}
proc ::GX::LibraryBrowser::manualPreview {w} {
    variable states
    run $w {
        set parameters [manualParameters $w 1]
        set result [::GX::ScientificLibraryManagerAPIv1::domainRequest manual_prepare \{[manualParameters $w]\}]
        if {[[manualRoot $w].names.entry get] eq {}} {[manualRoot $w].names.entry insert 0 [dict get $result entry entry_id];set parameters [manualParameters $w 1]}
        set review $w.manualReview
        catch {destroy $review};toplevel $review
        wm title $review {Review manual Library entry — no network or Session changes}
        wm geometry $review 960x680;wm minsize $review 620 420
        ttk::label $review.title -text "[dict get $result entry label] • [dict get $result entry record_type]" -padding 10
        pack $review.title -fill x
        ttk::notebook $review.tabs;pack $review.tabs -fill both -expand 1
        ttk::frame $review.tabs.identity;$review.tabs add $review.tabs.identity -text {Identity and source}
        table $review.tabs.identity.values {field value};pack $review.tabs.identity.values -fill both -expand 1
        dict for {key value} [dict get $result entry fields] {
            if {[dict get $states $w manual_editors $key] eq {table}} continue
            $review.tabs.identity.values.tree insert {} end -values [list $key $value]
        }
        $review.tabs.identity.values.tree insert {} end -values [list source_id [dict get $result entry provenance source_id]]
        dict for {key editor} [dict get $states $w manual_editors] {
            if {$editor ne {table}} continue
            set columns [dict keys [dict get $states $w schemas record_types [[manualRoot $w].identity.type get] fields $key columns]]
            ttk::frame $review.tabs.$key;$review.tabs add $review.tabs.$key -text [string totitle [string map {_ { }} $key]]
            table $review.tabs.$key.values $columns;pack $review.tabs.$key.values -fill both -expand 1
            foreach row [::GX::datasetPublicationV2DictDefault [dict get $result entry fields] $key {}] {
                set values {};foreach column $columns {lappend values [::GX::datasetPublicationV2DictDefault $row $column {}]}
                $review.tabs.$key.values.tree insert {} end -values $values
            }
        }
        ttk::frame $review.tabs.files;$review.tabs add $review.tabs.files -text {Original local files}
        table $review.tabs.files.values {role filename sha256};pack $review.tabs.files.values -fill both -expand 1
        foreach file [dict get $states $w attachments] {$review.tabs.files.values.tree insert {} end -values [list [dict get $file role] [file tail [dict get $file path]] [dict get $file expected_sha256]]}
        ttk::frame $review.actions
        ttk::button $review.actions.save -text {Save this reviewed entry into Library} -command [list ::GX::LibraryBrowser::manualCommit $w $parameters [[manualRoot $w].names.library get] $review]
        ttk::button $review.actions.cancel -text {Cancel review} -command [list destroy $review]
        pack $review.actions.save $review.actions.cancel -side left -padx 6 -pady 8
        pack $review.actions -fill x
        status $w {Preview ready. Review the structured identity/specifications and original local file hashes; nothing has been saved.}
    }
}
proc ::GX::LibraryBrowser::manualSave {w} {manualCommit $w [manualParameters $w 1] [[manualRoot $w].names.library get] {}}
proc ::GX::LibraryBrowser::manualCommit {w parameters library review} {
    variable states
    run $w {
        set result [::GX::ScientificLibraryManagerAPIv1::domainRequest manual_import \{$parameters,\"library_id\":[str $library]\}]
        dict set states $w last_receipt $result
        set saved [lindex [dict get $result entries] 0]
        set reference [dict create library_id [dict get $result library_id] entry_id [dict get $saved entry_id]]
        set actual [::GX::ScientificLibraryManagerAPIv1::domainRequest detail [format {{"reference":%s}} [object $reference]]]
        dict set reference revision [dict get $actual revision];dict set reference content_sha256 [dict get $actual content_sha256]
        dict set states $w previous $reference
        [manualRoot $w].names.entry delete 0 end;[manualRoot $w].names.entry insert 0 [dict get $saved entry_id]
        if {[winfo exists $w.manualReview]} {destroy $w.manualReview}
        refresh $w
        status $w "Saved manual record in Library [dict get $result library_id], version [dict get $result version]. Zero Session Datasets created."
    }
}
proc ::GX::LibraryBrowser::manualCancel {w} {
    set p [manualRoot $w]
    manualFields $w;clearAttachments $w
    $p.paste delete 1.0 end
    foreach field [list $p.names.label $p.names.entry] {$field delete 0 end}
    status $w {Manual draft cancelled. Persistent Libraries and Sessions are unchanged.}
}
proc ::GX::LibraryBrowser::manualAttachments {w} {
    variable states
    set table [manualRoot $w].attachments.tree
    $table delete [$table children {}]
    set files [dict get $states $w attachments];set n 0
    foreach file $files {$table insert {} end -id [incr n] -values [list [dict get $file role] [file tail [dict get $file path]] [dict get $file expected_sha256]]}
    [manualRoot $w].fileSummary configure -text "[llength $files] user-selected local files • double-click to view the original • source bytes/SHA checked on Save"
}
proc ::GX::LibraryBrowser::manualOpenAttachment {w} {
    variable states
    run $w {
        set ids [[manualRoot $w].attachments.tree selection]
        if {[llength $ids]!=1} {error {Select one local file}}
        set file [lindex [dict get $states $w attachments] [expr {[lindex $ids 0]-1}]]
        set path [dict get $file path]
        if {[::GX::sha256File $path] ne [dict get $file expected_sha256]} {error {The selected local file changed; select it again}}
        if {[string tolower [file extension $path]] in {.png .jpg .jpeg .gif}} {
            set view $w.localImage;catch {destroy $view};toplevel $view;wm title $view "Local original — [file tail $path]"
            set image [localImage $w $path]
            set factor [expr {max(1,int(ceil(max([image width $image]/800.0,[image height $image]/550.0))))}]
            if {$factor>1} {set scaled [image create photo];$scaled copy $image -subsample $factor $factor;image delete $image;set image $scaled}
            ttk::label $view.image -image $image;pack $view.image -fill both -expand 1
            ttk::label $view.source -text "[dict get $file role] • original SHA256 [dict get $file expected_sha256]" -wraplength 800 -padding 8;pack $view.source -fill x
            bind $view <Destroy> [list ::GX::LibraryBrowser::imageClosed $view %W $image]
        } else {externalOpen $path}
    }
}
proc ::GX::LibraryBrowser::edit {w} {
    variable states
    run $w {
        set reference [reference $w]
        set entry [::GX::ScientificLibraryManagerAPIv1::domainRequest detail [format {{"reference":%s}} [object $reference]]]
        set p [manualRoot $w]
        $p.identity.type set [dict get $entry record_type];manualFields $w
        dict for {key value} [dict get $entry fields] {
            if {![dict exists $states $w manual_controls $key]} continue
            set control [dict get $states $w manual_controls $key]
            set kind [dict get $states $w schemas record_types [dict get $entry record_type] fields $key type]
            set editor [dict get $states $w manual_editors $key]
            if {$editor eq {table}} {dict set states $w table_rows $key $value;tableRender $w $key;continue}
            if {$editor eq {multiline}} {$control insert 1.0 $value;continue}
            if {$kind eq {string}} {$control insert 0 $value} else {
                # Preserve JSON types via the existing native typed decoder.
                set typed [::GX::nativeWorkspaceJsonDecode [dict get $entry result_json]]
                set fieldTyped [dict get [lindex [dict get [lindex $typed 1] fields] 1] $key]
                $control insert 0 [::GX::nativeWorkspaceJsonEncode $fieldTyped]
            }
        }
        foreach {control value} [list $p.names.library [dict get $reference library_id] $p.names.entry [dict get $entry entry_id] $p.names.label [dict get $entry label] $p.identity.source [dict get $entry provenance source_id]] {$control delete 0 end;$control insert 0 $value}
        dict set states $w previous $reference
        clearAttachments $w
        $p.paste delete 1.0 end
        $w.tabs select $w.tabs.manual
        status $w {Editing a new immutable revision. Existing source bytes/history remain preserved.}
    }
}
proc ::GX::LibraryBrowser::openResource {w} {
    variable states
    run $w {
        set selected [$w.tabs.records.detail.resources.values.tree selection]
        if {[llength $selected]!=1} {error {Select one local image or document}}
        set index [expr {[lindex $selected 0]-1}]
        set reference [dict get $states $w selected_reference]
        set resource [lindex [dict get $states $w selected_entry resources] $index]
        if {[dict get $resource availability] ne {local}} {error "External reference: [dict get $resource url]. Download was not claimed; use a source import or add your local file."}
        set allocation [::GX::resourceManagementAllocate scientific_library [dict create kind directory lifetime viewer retention_seconds 0]]
        set staged [::GX::LibraryEntryAcquisitionDispatchAPIv1::_stage [dict create reference $reference resource_index $index] $allocation]
        set state [dict get $states $w];dict lappend state allocations $allocation;dict set states $w $state
        set view $w.resource[llength [dict get $state allocations]]
        toplevel $view;wm title $view "Original Library resource — [dict get $resource role]"
        ttk::label $view.identity -text "[dict get $staged media_type]\nSHA256: [dict get $staged sha256]" -wraplength 800 -padding 8;pack $view.identity -fill x
        if {[string match image/* [dict get $staged media_type]]} {
            set image [localImage $w [dict get $staged source_path]]
            set factor [expr {max(1,int(ceil(max([image width $image]/900.0,[image height $image]/650.0))))}]
            if {$factor>1} {set scaled [image create photo];$scaled copy $image -subsample $factor $factor;image delete $image;set image $scaled}
            ttk::label $view.image -image $image;pack $view.image -fill both -expand 1
            bind $view <Destroy> [list ::GX::LibraryBrowser::imageClosed $view %W $image]
        } elseif {[dict get $staged media_type] eq {chemical/x-mdl-sdfile}} {
            ::GX::viewerOpen viewer.molecule_3d molecule_3d [dict create library_source [dict merge $staged [dict create reference $reference resource_index $index]]]
        } else {
            ttk::label $view.path -text "Original bytes staged read-only for viewing:\n[dict get $staged source_path]\nUse Open original in your configured document application, or explicitly import it to a Session with its installed Acquisition Handler." -wraplength 800 -padding 12;pack $view.path -fill both -expand 1
            ttk::button $view.open -text {Open original document} -command [list ::GX::LibraryBrowser::externalOpen [dict get $staged source_path]];pack $view.open -pady 8
        }
    }
}
proc ::GX::LibraryBrowser::imageClosed {view actual image} {if {$view eq $actual} {catch {image delete $image}}}
proc ::GX::LibraryBrowser::externalOpen {path} {
    if {$::tcl_platform(platform) eq {windows}} {exec {*}[auto_execok start] {} $path &} else {exec xdg-open $path &}
}
proc ::GX::LibraryBrowser::acquire {w} {
    variable states
    run $w {
        set ids [$w.tabs.records.list.tree selection]
        if {$ids eq {}} {error {Select one or more Library records}}
        set queue {};foreach id $ids {lappend queue [lindex [dict get $states $w rows] [expr {$id-1}]]}
        dict set states $w acquisition_queue $queue;dict set states $w acquisition_selections {}
        acquireNext $w
    }
}
proc ::GX::LibraryBrowser::acquireNext {w} {
    variable states
    run $w {
        set queue [dict get $states $w acquisition_queue]
        if {$queue eq {}} {
            set fields [dict create session_path {type string label {Existing target Session path}} namespace {type string label {Destination Namespace (blank = root)}}]
            set session {};if {[info exists ::GX::currentSession]} {set session $::GX::currentSession}
            ::GX::uiFieldFormCreate $w.acquireDestination {Import reviewed selection to Session} $fields [dict create session_path $session namespace {}] [list ::GX::LibraryBrowser::acquireCommit $w] $w
            return
        }
        set reference [dict remove [lindex $queue 0] label]
        set detail [::GX::ScientificLibraryManagerAPIv1::domainRequest detail [format {{"reference":%s}} [object $reference]]]
        set choices {}
        if {[::GX::datasetPublicationV2DictDefault $detail content_contract {}] ne {}} {lappend choices {-1: structured record}}
        set n -1;foreach resource [dict get $detail resources] {incr n;if {[dict get $resource availability] eq {local}} {lappend choices "$n: [dict get $resource role]"}}
        if {$choices eq {}} {error {This selected entry has no locally available acquisition representation; select an actual linked record or file}}
        dict set states $w acquisition_reference $reference
        ::GX::uiFieldFormCreate $w.acquireRepresentation {Choose selected Library representation} [dict create representation [dict create type choice values $choices label Representation] dataset_id {type string label {Proposed Dataset ID}}] [dict create representation [lindex $choices 0] dataset_id [dict get $reference entry_id]] [list ::GX::LibraryBrowser::acquireRepresentation $w] $w
    }
}
proc ::GX::LibraryBrowser::acquireRepresentation {w values} {
    variable states
    run $w {
        set index [lindex [split [dict get $values representation] :] 0]
        set selection [dict create reference [dict get $states $w acquisition_reference] resource_index $index dataset_id [dict get $values dataset_id]]
        set inspected [::GX::LibraryEntryAcquisitionDispatchAPIv1::inspectSelection $selection]
        set handlers [dict get $inspected compatible_handlers]
        if {$handlers eq {}} {error {No enabled compatible Acquisition Handler/Contract for the selected representation}}
        dict set selection expected_sha256 [dict get $inspected sha256]
        dict set states $w acquisition_current $selection
        ::GX::uiFieldFormCreate $w.acquireHandler {Review Acquisition Handler} [dict create handler_id [dict create type choice values $handlers label {Installed compatible handler}]] [dict create handler_id [lindex $handlers 0]] [list ::GX::LibraryBrowser::acquireHandler $w] $w
    }
}
proc ::GX::LibraryBrowser::acquireHandler {w values} {
    variable states
    set state [dict get $states $w]
    dict lappend state acquisition_selections [dict merge [dict get $state acquisition_current] $values]
    dict set state acquisition_queue [lrange [dict get $state acquisition_queue] 1 end]
    dict set states $w $state
    acquireNext $w
}
proc ::GX::LibraryBrowser::acquireCommit {w values} {
    run $w {
        set selections [dict get $::GX::LibraryBrowser::states $w acquisition_selections]
        set receipt [::GX::LibraryEntryAcquisitionDispatchAPIv1::importSelected [dict get $values session_path] $selections [dict get $values namespace]]
        dict set ::GX::LibraryBrowser::states $w last_receipt $receipt
        status $w {Selected Acquisition finished. View last operation receipt for actual per-entry outcomes.}
    }
}

proc ::GX::LibraryBrowser::showReceipt {w} {
    run $w {
        if {![dict exists $::GX::LibraryBrowser::states $w last_receipt]} {error {No completed operation receipt in this Browser lifetime}}
        set view $w.operationReceipt
        catch {destroy $view};toplevel $view;wm title $view {Actual Library operation receipt};wm geometry $view 850x500
        text $view.text -wrap word -yscrollcommand [list $view.y set]
        ttk::scrollbar $view.y -orient vertical -command [list $view.text yview]
        pack $view.y -side right -fill y;pack $view.text -fill both -expand 1
        $view.text insert end [dict get $::GX::LibraryBrowser::states $w last_receipt]
        $view.text configure -state disabled
    }
}

proc ::GX::LibraryBrowser::manualWheel {w actual delta} {
    if {![string match "$w.tabs.manual.*" $actual]} return
    set amount [expr {$delta>0?-3:3}]
    $w.tabs.manual.viewport yview scroll $amount units
}
proc ::GX::LibraryBrowser::sourceInspect {w} {
    variable states
    run $w {
        set chosen [$w.tabs.sources.selection.tree selection]
        if {[llength $chosen]!=1} {error {Select one actual source record to inspect}}
        set row [lindex [dict get $states $w bundle entries] [expr {[lindex $chosen 0]-1}]]
        set entry [dict get $row entry]
        dict set states $w inspected_source_entry $entry
        set view $w.sourceDetail;catch {destroy $view};toplevel $view
        wm title $view {Source record — read-through consultation};wm geometry $view 980x700;wm minsize $view 620 420
        ttk::label $view.title -text "[dict get $entry label] • [dict get $entry record_type]" -padding 10;pack $view.title -fill x
        ttk::notebook $view.tabs;pack $view.tabs -fill both -expand 1
        ttk::frame $view.tabs.identity;$view.tabs add $view.tabs.identity -text {Fields and source}
        table $view.tabs.identity.values {field value};pack $view.tabs.identity.values -fill both -expand 1
        set definitions [dict get $states $w schemas record_types [dict get $entry record_type] fields]
        set n 0
        dict for {key value} [dict get $entry fields] {
            set definition [::GX::datasetPublicationV2DictDefault $definitions $key {}]
            if {[::GX::datasetPublicationV2DictDefault $definition editor {}] eq {table}} {
                set tab $view.tabs.typed[incr n];ttk::frame $tab;$view.tabs add $tab -text [::GX::datasetPublicationV2DictDefault $definition label $key]
                set columns [dict keys [dict get $definition columns]]
                table $tab.values $columns;pack $tab.values -fill both -expand 1
                foreach record $value {set cells {};foreach column $columns {lappend cells [::GX::datasetPublicationV2DictDefault $record $column {}]};$tab.values.tree insert {} end -values $cells}
            } else {$view.tabs.identity.values.tree insert {} end -values [list $key $value]}
        }
        dict for {key value} [dict get $entry provenance] {$view.tabs.identity.values.tree insert {} end -values [list provenance.$key $value]}
        ttk::frame $view.tabs.resources;$view.tabs add $view.tabs.resources -text {Actual source images and documents}
        table $view.tabs.resources.values {role availability url sha256};pack $view.tabs.resources.values -fill both -expand 1
        set n 0;foreach resource [dict get $entry resources] {$view.tabs.resources.values.tree insert {} end -id [incr n] -values [list [dict get $resource role] [dict get $resource availability] [::GX::datasetPublicationV2DictDefault $resource url {}] [::GX::datasetPublicationV2DictDefault $resource sha256 {}]]}
        ttk::frame $view.actions
        ttk::button $view.actions.image -text {View source image (memory only)} -command [list ::GX::LibraryBrowser::sourceImage $w]
        ttk::button $view.actions.document -text {Open original source document link} -command [list ::GX::LibraryBrowser::sourceDocument $w]
        ttk::button $view.actions.close -text Close -command [list destroy $view]
        pack $view.actions.image $view.actions.document $view.actions.close -side left -padx 6 -pady 6;pack $view.actions -fill x
    }
}
proc ::GX::LibraryBrowser::sourceImage {w} {
    variable states
    run $w {
        set entry [dict get $states $w inspected_source_entry]
        set options [format {{"transient_asset_entry_id":%s}} [str [dict get $entry entry_id]]]
        request $w content [list [dict get $states $w source_library] read_entry [dict create entry_id [dict get $states $w primary_source_entry] options_json $options]] image
    }
}
proc ::GX::LibraryBrowser::sourceDocument {w} {
    variable states
    run $w {
        set selected [$w.sourceDetail.tabs.resources.values.tree selection]
        if {[llength $selected]!=1} {error {Select one actual source document link}}
        set resource [lindex [dict get $states $w inspected_source_entry resources] [expr {[lindex $selected 0]-1}]]
        if {![dict exists $resource url] || ![string match https://* [dict get $resource url]]} {error {This resource has no HTTPS source document link}}
        externalOpen [dict get $resource url]
    }
}
proc ::GX::LibraryBrowser::localImage {w path} {
    variable states
    if {![catch {image create photo -file $path} image]} {return $image}
    set allocation [::GX::resourceManagementAllocate scientific_library [dict create kind directory lifetime viewer retention_seconds 0]]
    set state [dict get $states $w];dict lappend state allocations $allocation;dict set states $w $state
    set artifact [::GX::datasetPreviewImageArtifact $path [dict get $allocation path] 1]
    if {![dict exists $artifact path]} {error {Configured image preview cannot display this local format}}
    return [image create photo -file [dict get $artifact path]]
}
proc ::GX::LibraryBrowser::sourceImageReply {w result} {
    variable states
    run $w {
        set images [::GX::datasetPublicationV2DictDefault [dict get $result payload] preview_assets {}]
        if {$images eq {}} {error {This source did not return a supported image preview}}
        set asset [lindex $images 0]
        set generation [dict get $states $w generation]
        set callback [list ::GX::LibraryBrowser::sourceImageConverted $w $generation [dict get $asset role] [dict get $asset sha256]]
        set request [::GX::datasetPreviewImageMemory [binary decode base64 [dict get $asset data_base64]] $callback]
        dict set states $w request $request
        status $w {Preparing bounded image preview in memory…}
    }
}
proc ::GX::LibraryBrowser::sourceImageConverted {w generation role originalSHA response} {
    variable states
    if {![dict exists $states $w] || [dict get $states $w generation]!=$generation} return
    dict set states $w request {}
    run $w {
        if {![dict get $response ok]} {error [dict get $response error]}
        set result [dict get $response result]
        if {[dict get $result original_sha256] ne $originalSHA} {error {Source image identity changed before display}}
        set view $w.sourceImage;catch {destroy $view};toplevel $view;wm title $view {Source image — transient memory, not saved}
        set image [image create photo -data [binary decode base64 [dict get $result data_base64]]]
        ttk::label $view.image -image $image;pack $view.image -fill both -expand 1
        ttk::label $view.source -text "$role • transient memory preview • original SHA256 $originalSHA" -wraplength 900 -padding 8;pack $view.source -fill x
        bind $view <Destroy> [list ::GX::LibraryBrowser::imageClosed $view %W $image]
        status $w {Source image displayed from memory. No API response, image or Library entry was saved.}
    }
}

proc ::GX::LibraryBrowser::layout {w actual width} {
    if {$w ne $actual || ![winfo exists $w.title]} return
    set wrap [expr {max(280,$width-24)}]
    $w.title configure -wraplength $wrap
    $w.status configure -wraplength $wrap
}
proc ::GX::LibraryBrowser::forward {w} {
    variable states
    set state [dict get $states $w];set forward [dict get $state forward_history]
    if {$forward eq {}} return
    dict lappend state history [dict get $state selected_reference];dict set state forward_history [lrange $forward 0 end-1];dict set states $w $state
    inspect $w [lindex $forward end]
}
proc ::GX::LibraryBrowser::externalCandidate {w values} {
    variable states
    set state [dict get $states $w];dict lappend state history [dict get $state selected_reference];dict set state forward_history {};dict set states $w $state
    inspect $w [dict remove [dict get $state external_candidates [dict get $values candidate]] label]
}
proc ::GX::LibraryBrowser::relatedPage {w delta} {
    set offset [::GX::datasetPublicationV2DictDefault [dict get $::GX::LibraryBrowser::states $w] related_offset 0]
    relatedRefresh $w [expr {max(0,$offset+$delta)}]
}
proc ::GX::LibraryBrowser::relatedRefresh {w {offset 0}} {
    variable states
    run $w {
        set p $w.tabs.records.detail.related
        set reference [dict get $states $w selected_reference]
        set relationType [$p.filters.type get];if {$relationType eq {All relation types}} {set relationType {}}
        set parameters [format {{"reference":%s,"direction":%s,"relation_type":%s,"source_id":%s,"offset":%d,"limit":100}} [object $reference] [str [$p.filters.direction get]] [str $relationType] [str [$p.filters.source get]] $offset]
        set result [::GX::ScientificLibraryManagerAPIv1::relatedEntries $parameters]
        dict set states $w relations [dict get $result records];dict set states $w related_offset $offset
        $p.values.tree delete [$p.values.tree children {}]
        set n 0;foreach edge [dict get $result records] {
            set direction [expr {[dict get $edge from_reference library_id] eq [dict get $reference library_id] && [dict get $edge from_reference entry_id] eq [dict get $reference entry_id]?{outgoing}:{incoming}}]
            $p.values.tree insert {} end -id [incr n] -values [list [dict get $edge relation_type] $direction [dict get $edge source_id] [dict get $edge resolution_status] [dict get $edge evidence]]
        }
        status $w "[llength [dict get $result records]] / [dict get $result total] source-attributed relations • offset $offset • read-only traversal"
    }
}
