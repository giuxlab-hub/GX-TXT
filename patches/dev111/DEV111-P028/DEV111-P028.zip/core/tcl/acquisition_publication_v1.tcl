# SPDX-License-Identifier: GPL-3.0-or-later
# Narrow acquisition staging -> existing Publication v2 numeric writer adapter.
# Staged little-endian arrays are standard binary transport, never canonical
# Datasets. Only Publication chooses storage, validates schema and commits SHA.
proc ::GX::acquisitionPreparedPublicationsPreflight {moduleId session outputDir declarations} {
    if {[llength $declarations]<1 || [llength $declarations]>64} {error {Acquisition must prepare 1..64 actual numeric Datasets}}
    set result {};set definitions {};set ids {}
    set declared [splitList [moduleField $moduleId output_datasets {}]]
    foreach item $declarations {
        if {[lsort [dict keys $item]] ne {definition row_count variables}} {error {Prepared Acquisition requires definition, row_count and variables}}
        set definition [dict get $item definition]
        set id [datasetPublicationV2ValidateId dataset [dict get $definition dataset_id]]
        if {$id in $ids} {error {Duplicate prepared Acquisition Dataset ID}}
        lappend ids $id
        if {[dict get $definition contract] ni $declared} {error {Prepared Acquisition output contract is not declared by the producer}}
        if {[dict exists $definition publication_module] && [dict get $definition publication_module] ne $moduleId} {error {Prepared Acquisition cannot change its producer identity}}
        set rows [dict get $item row_count]
        if {![string is wideinteger -strict $rows] || $rows<1} {error {Prepared Acquisition requires a positive exact row count}}
        set variables [dict get $item variables]
        if {[llength $variables]<1 || [llength $variables]>128} {error {Prepared Acquisition requires 1..128 variables}}
        set prepared {};set variableIds {}
        foreach variable $variables {
            if {[lsort [dict keys $variable]] ne {path schema variable_id}} {error {Prepared Acquisition variable requires path, schema and variable_id}}
            set vid [datasetPublicationV2ValidateId variable [dict get $variable variable_id]]
            if {$vid in $variableIds} {error {Prepared Acquisition variable IDs must be unique}}
            lappend variableIds $vid
            set schema [dict get $variable schema]
            set dtype [datasetPublicationV2DictDefault $schema dtype {}]
            if {$dtype ni {float32 float64 int8 int16 int32 int64 uint8 uint16 uint32 uint64 bool}} {error {Prepared Acquisition requires a supported typed numeric dtype}}
            set width [datasetBinaryTransportWidth $dtype]
            set expected [expr {$rows*$width}]
            if {$expected>536870912} {error {Prepared numeric variable exceeds the existing 512 MiB resource bound}}
            lassign [acquisitionHandlerSafeDatasetPath $session $outputDir [dict get $variable path]] path unused
            if {[file size $path]!=$expected} {error {Prepared Acquisition array byte length does not match its typed row count}}
            foreach {key expectedValue} [list variable_id $vid rank 1 dimension_ids row shape [list $rows]] {
                if {[dict exists $schema $key] && [dict get $schema $key] ne $expectedValue} {error "Prepared numeric schema contradicts '$key'"}
                dict set schema $key $expectedValue
            }
            lappend prepared [dict create variable_id $vid schema $schema path $path dtype $dtype width $width]
        }
        dict set definition expected_rows $rows
        lappend definitions $definition
        lappend result [dict create definition $definition row_count $rows variables $prepared]
    }
    datasetPublicationV2BatchPreflight $session $moduleId $definitions
    return $result
}
proc ::GX::_acquisitionPreparedConsumables {session plans callbacks} {
    set root [datasetPublicationV2DictDefault $callbacks prepared_consumable_root {}]
    if {$root eq {}} {return {}}
    set root [file normalize $root]
    set transactionRoot [file normalize [file join $session .acquisition-txn]]
    if {[file tail $root] ne {datasets} || [file dirname [file dirname $root]] ne $transactionRoot || ![regexp {^[A-Za-z0-9_.-]+-[0-9]+-[0-9]+$} [file tail [file dirname $root]]]} {error {Consumable buffers require CORE's owned Acquisition staging root}}
    set state {}
    foreach plan $plans {
        foreach variable [dict get $plan variables] {
            set path [file normalize [dict get $variable path]]
            if {[string first "$root/" "$path/"]!=0 || ![file isfile $path] || [file type $path] ne {file}} {error {Consumable prepared buffer escaped its admitted staging root}}
            if {[dict exists $state $path]} {dict incr state $path 1} else {dict set state $path 1}
        }
    }
    return $state
}
proc ::GX::_acquisitionPreparedConsumed {stateName path} {
    upvar 1 $stateName state
    if {$state eq {}} return
    set path [file normalize $path]
    if {![dict exists $state $path] || [dict get $state $path]<1} {error {Unknown or already consumed prepared buffer}}
    dict incr state $path -1
    if {[dict get $state $path]==0} {
        if {![file isfile $path] || [file type $path] ne {file}} {error {Consumable buffer changed before its final acknowledgement}}
        file delete -- $path
    }
}
proc ::GX::acquisitionPublishPreparedSerial {moduleId session plans sourceProvenance {callbacks {}}} {
    if {![datasetAuthorityActive $session]} {error {Prepared Acquisition publication requires the existing outer Dataset authority transaction}}
    set consumables [_acquisitionPreparedConsumables $session $plans $callbacks]
    set ids {}
    set channel 0
    set totalVariables 0;foreach plan $plans {incr totalVariables [llength [dict get $plan variables]]}
    set completedVariables 0
    set allocation [resourceManagementAllocate acquisition_publication [dict create kind directory session $session lifetime computation]]
    set groupWorkspace [dict get $allocation path]
    set hadScope [info exists ::env(GXTXT_BRIDGE_WORKSPACE)]
    if {$hadScope} {set previousScope $::env(GXTXT_BRIDGE_WORKSPACE)}
    set writer {}
    try {
    if {[llength [info commands ::GX::_acquisitionManagedResourceTrack]]} {_acquisitionManagedResourceTrack $allocation}
    foreach plan $plans {
        incr channel
        set progress [datasetPublicationV2DictDefault $callbacks progress_callback {}]
        set cancel [datasetPublicationV2DictDefault $callbacks cancel_callback {}]
        if {$cancel ne {} && [acquisitionHandlerInvokeCallback $cancel]} {error {Acquisition cancelled before numeric publication}}
        set definition [dict get $plan definition]
        acquisitionHandlerInvokeCallback $progress [dict create phase publication mode determinate current $completedVariables total $totalVariables prepared_channels [expr {$channel-1}] message "Publishing channel $channel / [llength $plans]"]
        set metadata [datasetPublicationV2DictDefault $definition structured_metadata {}]
        dict for {key value} $sourceProvenance {
            if {[dict exists $metadata $key] && [dict get $metadata $key] ne $value} {error "Conflicting pinned Library source field '$key'"}
            dict set metadata $key $value
        }
        dict set definition structured_metadata $metadata
        set publication [datasetPublicationV2Prepare $session $moduleId $definition]
        set workspace [file join $groupWorkspace [format channel-%04d $channel]]
        file mkdir $workspace
        try {
            # Reuse the already public managed binary lane. No numeric values
            # cross the Tcl/Base64 control channel and no HDF5 writer is cloned.
            set ::env(GXTXT_BRIDGE_WORKSPACE) $workspace
            set writer [datasetPublicationV2OpenWriter $publication]
            if {![datasetPublicationV2DictDefault [datasetPublicationV2WriterCapabilities $writer] managed_binary_write 0]} {error {Prepared numeric Acquisition requires a CORE managed-binary writer; choose HDF5}}
            set rows [dict get $plan row_count]
            datasetPublicationV2DeclareDimension $writer row $rows
            foreach variable [dict get $plan variables] {
                if {$cancel ne {} && [acquisitionHandlerInvokeCallback $cancel]} {error {Acquisition cancelled during numeric publication}}
                datasetPublicationV2DeclareVariable $writer [dict get $variable variable_id] [dict get $variable schema]
            }
            set serial 0
            foreach variable [dict get $plan variables] {
                if {$cancel ne {} && [acquisitionHandlerInvokeCallback $cancel]} {error {Acquisition cancelled during numeric payload transfer}}
                set name [format %032x.bin [incr serial]]
                set path [file join $workspace $name]
                file copy -- [dict get $variable path] $path
                set expected [expr {$rows*[dict get $variable width]}]
                if {[file size $path]!=$expected} {error {Prepared numeric array changed during publication}}
                set resource [dict create version 2 dtype [dict get $variable dtype] endian little order F shape [list $rows] count $rows byte_count $expected resource_id $name resource_root $workspace]
                datasetPublicationV2WriteVariable $writer [dict get $variable variable_id] \
                    [dict create __gxtxt_binary_resource 1 shape [list $rows] resource $resource] [list $rows]
                _acquisitionPreparedConsumed consumables [dict get $variable path]
                incr completedVariables
                acquisitionHandlerInvokeCallback $progress [dict create phase publication mode determinate current $completedVariables total $totalVariables message "Publishing channel $channel / [llength $plans]: [dict get $variable variable_id]"]
                file delete -- $path
            }
            acquisitionHandlerInvokeCallback $progress [dict create phase finalization mode indeterminate message "Validating and finalizing channel $channel / [llength $plans]"]
            if {$cancel ne {} && [acquisitionHandlerInvokeCallback $cancel]} {error {Acquisition cancelled before finalization}}
            set result [datasetPublicationV2Finalize $writer];set writer {}
            lappend ids [dict get $result dataset_id]
            acquisitionHandlerInvokeCallback $progress [dict create phase publication mode determinate current $completedVariables total $totalVariables prepared_channels $channel message "Validated channel $channel / [llength $plans]; Group commit pending"]
        } finally {
            if {$writer ne {}} {catch {datasetPublicationV2Abort $writer};set writer {}}
        }
    }
    } finally {
        if {$hadScope} {set ::env(GXTXT_BRIDGE_WORKSPACE) $previousScope} else {unset -nocomplain ::env(GXTXT_BRIDGE_WORKSPACE)}
        resourceManagementRelease [dict get $allocation id]
        resourceManagementCleanup [list [dict get $allocation id]]
    }
    return $ids
}
proc ::GX::acquisitionHandlerDispatchApiInfo {} {
    return [dict create api_id ACQUISITION_HANDLER_PLUGIN_API_v1 api_version 1 \
        source_dispatch_options {source_provenance destination_namespace} prepared_publication_api 1 dataset_group_api 1 \
        prepared_schema gxtxt.acquisition_prepared_numeric.v1 publication_owner DATASET_PUBLICATION_API_v2]
}

# Selected normal strategy: measurements found no reliable end-to-end benefit
# from more provider processes; the additive API remains available to callers.
proc ::GX::acquisitionPublishPrepared {moduleId session plans sourceProvenance {callbacks {}}} {
    return [acquisitionPublishPreparedSerial $moduleId $session $plans $sourceProvenance $callbacks]
}
