# Prepared numeric Acquisition publication v1

This is a narrow additive handoff under the existing Acquisition Handler owner.
`::GX::acquisitionHandlerDispatchApiInfo` advertises `prepared_publication_api=1`,
`dataset_group_api=1` and supported source-dispatch options. It is a host
capability query, unaffected by the existing variadic transaction wrappers.

A handler may return `datasets {}` and `prepared_publications`, a bounded list
of 1–64 declarations. Each contains exactly `definition`, `row_count` and
`variables`. `definition` uses existing Publication v2 dataset_id/contract/storage/
metadata/provenance fields. Each of 1–128 variables contains `variable_id`,
`schema` and a normalized relative `path` beneath the handler's private output
directory. Its actual file contains the existing little-endian numeric array
transport with exactly row_count × dtype-width bytes; this is not a canonical
Dataset format. Each variable has one rank-one `row` dimension, supported numeric
dtype and a maximum 512 MiB, matching the existing managed binary resource lane.

CORE preflights all IDs/contracts/schema/paths/lengths before authoritative
placement, then admits scoped resources and calls the existing Publication v2
managed numeric writer. Only that owner selects actual HDF5 storage, declares
typed variables, validates/flushes/closes and computes canonical SHA. No second
writer, private Registry mutation or relabelled CSV is involved. Existing byte-
preserved file-shaped Acquisition output remains unchanged.

The already-held outer Acquisition/Dataset authority transaction encloses every
publication, RAW placement, metadata, optional declarative Dataset Group and
reviewed destination Namespace. A late failure rolls back all enlisted resources;
no nested finalization can leave a successful partial Group. Temporary array
resources and any failed writer are released through existing Resource Management.
Library provenance options are merged before writer admission, not appended by a
Viewer after import. Producers cannot change their own module identity.

The original source SHA is captured before inspection and matched to the actual
RAW snapshot, preventing changed headers/units between inspection and parsing.
Reference-mode source SHA is additionally rechecked after the handler completes.
No source file is modified, and unknown/malformed outputs refuse normally.
