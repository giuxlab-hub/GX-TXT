# DEV111-P028 incremental overlay

Requires exact P027 source `0f806fff6e070eeae20e8a086575e3dfc4a890ff` and official P027 ZIP SHA256 `445c0185fa68dd8d53217b8cff25a151ee20c747cb95666576ff87bf8dc73046`. P026 and mixed installations are refused by the bundled full essential-runtime baseline closure, including the unchanged Plugin Install sentinel. Extra user files are allowed; existing files at added payload paths are never overwritten. Source commit: `5c9f9c7451f841eea03e4d3499ff2684251779c3`. Paths app/, core/, plugins/ and docs/ overlay the framework root directly; there is no framework/ wrapper.

Stop the target GX-TXT and all its workers before changing any file. Helpers do not detect or enforce stopped processes; --stopped explicitly acknowledges this instruction. Do not install over an unknown active root. Keep original Sessions/scientific data and prior patch notes intact.

Extract only patch_notes/DEV111-P028/ to a separate review directory. Keep DEV111-P028.zip and its .sha256 together, verify the published checksum, then run:

    python3 review/patch_notes/DEV111-P028/apply.py FRAMEWORK DEV111-P028.zip --check
    python3 review/patch_notes/DEV111-P028/apply.py FRAMEWORK DEV111-P028.zip --apply --stopped

Default is read-only. CRC, complete checksums, paths, regular files, modes, full baseline and added-path absence are checked before writes. A verified baseline with no deletion entries also supports the established `unzip -o DEV111-P028.zip -d FRAMEWORK` overlay. If DELETIONS.json is nonempty, use guarded apply; unzip alone cannot remove files.

The overlay already includes every Module listed in MODULE_VERSION_MATRIX.json. Verify its exact host closure:

    python3 review/patch_notes/DEV111-P028/companion_preflight.py FRAMEWORK DEV111-P028.zip

This is read-only and checks the complete exact P028 host closure, including its CORE capabilities. It reports install_not_required and does not authorize reinstalling companion packages onto this overlay. The module framework_min value dev111 alone cannot distinguish P027 from P028. No Plugin Manager admission guard is bypassed.

Affected Module members use the same0644/0755 modes as their standard companion packages. The overlay includes explicit mode-only changes and exact predecessor preimages where necessary. Other unchanged framework modes retain the accepted physical P027 authority.

Companion ZIPs are independently installable through the existing Plugin Manager on a separately prepared compatible P028 host with an absent target or a legitimately managed installation. They are an alternative module delivery artifact, not a required second installation step for this complete overlay. Bundled/unmanaged existing targets correctly refuse normal installation. A normal equal-version reinstall on a managed target changes plugin registry history even when Module bytes match. Any later plugin lifecycle transaction can therefore invalidate the exact overlay/rollback guard; the helper must refuse that changed state. Preserve a complete stopped-framework backup before such later changes. Do not delete bundled folders, fabricate registry entries, restore old registry bytes over current state or weaken guards to force a companion installation or rollback.

Rollback is read-only unless explicitly requested:

    python3 FRAMEWORK/patch_notes/DEV111-P028/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P028/rollback.py FRAMEWORK --rollback --stopped

Interrupted overlay/rollback: use --recover-partial with --check, then with --rollback --stopped. Only exact known before/after hashes and modes are accepted; unknown files are refused. If interruption happened while publishing notes, restore complete verified notes from the exact ZIP first (no product overwrite), then inspect. Reverse later patches first. Rollback restores exact P027 bytes/modes and removes only P028-added product files. Notes/directories remain as evidence and extras are preserved. Move retained P028 notes to a separate evidence directory before a later reapply; helpers never overwrite that notes directory. Guarded writes serialize helpers with a crash-released POSIX directory lock; this does not stop GX-TXT or other writers. The engineering AUTHORITY_CATALOG.yaml is delivered outside this ZIP in operator_records; its accepted-source engineering preimage was not distributed by the prior patch chain and is not imposed as an installed guard. No Session/preferences/scientific cleanup or activation occurs. MAIN1 independent acceptance/deposit remains separate from preparation.
