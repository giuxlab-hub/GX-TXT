# SPDX-License-Identifier: GPL-3.0-or-later
# File-aware presentation of the existing Development project/source owner.
# Every editable tab is an independent shared Source Surface, never a program.
proc ::GX::ViewerDevelopmentWorkspace::projectTabsReset {} {
    variable s
    if {[info exists ::GX::ViewerDevelopmentWorkspace::debug(request)] && $::GX::ViewerDevelopmentWorkspace::debug(request) ne {}} {
        # A copied project can have identical hashes at another path. Drain the
        # old managed debugger before reusing this window for that new root.
        set previous $s(busy);set request $::GX::ViewerDevelopmentWorkspace::debug(request)
        set s(busy) $request;controls;debugStop
        try {vwait ::GX::ViewerDevelopmentWorkspace::debug(request)} finally {if {$s(busy) eq $request} {set s(busy) $previous;controls}}
    }
    if {[info exists ::GX::ViewerDevelopmentWorkspace::debug(poll)] && $::GX::ViewerDevelopmentWorkspace::debug(poll) ne {}} {::GX::scriptJobRequestCancel $::GX::ViewerDevelopmentWorkspace::debug(poll) closed;set ::GX::ViewerDevelopmentWorkspace::debug(poll) {}}
    if {[info exists ::GX::ViewerDevelopmentWorkspace::debug(generation)]} {
        incr ::GX::ViewerDevelopmentWorkspace::debug(generation)
        set ::GX::ViewerDevelopmentWorkspace::debug(snapshot) {};set ::GX::ViewerDevelopmentWorkspace::debug(sequence) -1
        if {[winfo exists .gxViewerDevelopment.debugbar]} {debugRender {state IDLE sequence 0 frames {} locals {}}}
    }
    set book .gxViewerDevelopment.body.center.sources
    foreach page [$book tabs] {$book forget $page;destroy $page}
    set s(tabs) {};set s(editor) {};set s(tabSerial) 0;set s(dirty) 0
}
proc ::GX::ViewerDevelopmentWorkspace::projectTabCreate {name source editable language checksum} {
    variable s
    set page .gxViewerDevelopment.body.center.sources.file[incr s(tabSerial)]
    set widget [::GX::sourceSurfaceCreate $page [dict create mode [expr {$editable?{editable}:{read_only}}] language $language]]
    dict set s(tabs) $name [dict create page $page text $widget baseline $source sha256 $checksum editable $editable dirty 0]
    ::GX::sourceSurfaceSet $widget $source
    .gxViewerDevelopment.body.center.sources add $page -text $name
    bind $widget <<Modified>> +[list ::GX::ViewerDevelopmentWorkspace::modified $widget]
    ::GX::uiTextEditingAttach .gxViewerDevelopment [list $widget]
    bind $widget <Control-w> {::GX::ViewerDevelopmentWorkspace::safe projectTabClose;break}
    return $widget
}
proc ::GX::ViewerDevelopmentWorkspace::projectTabSelected {} {
    variable s
    if {$s(mode) eq {maintenance}} return
    set page [.gxViewerDevelopment.body.center.sources select]
    if {![info exists s(tabs)]} return
    dict for {name tab} $s(tabs) {
        if {[dict get $tab page] ne $page} continue
        set s(editor) [dict get $tab text];set s(file) $name;set s(baseline) [dict get $tab baseline]
        set tree .gxViewerDevelopment.body.left.files.tree
        if {[$tree exists $name] && [$tree selection] ne [list $name]} {$tree selection set $name;$tree see $name}
        set s(status) "$name · [expr {[dict get $tab dirty]?{unsaved}:([dict get $tab editable]?{saved}:{read-only})}]"
        return
    }
}
proc ::GX::ViewerDevelopmentWorkspace::projectDirty {} {
    variable s;set dirty 0
    dict for {name tab} $s(tabs) {
        if {![winfo exists [dict get $tab text]]} continue
        set changed [expr {[dict get $tab editable] && [::GX::sourceSurfaceGet [dict get $tab text]] ne [dict get $tab baseline]}]
        dict set s(tabs) $name dirty $changed
        .gxViewerDevelopment.body.center.sources tab [dict get $tab page] -text "$name[expr {$changed?{ *}:{}}]"
        if {$changed} {set dirty 1}
    }
    set s(dirty) $dirty
    return $dirty
}
proc ::GX::ViewerDevelopmentWorkspace::projectRead {name} {
    variable s
    set names [::GX::viewerDevelopmentSourceFiles $s(project)]
    set roots [dict create project.json [file join $s(project) project.json] MANUAL.md [file join $s(project) MANUAL.md] design.gxtxt-viewer [file join $s(project) design.gxtxt-viewer] validation.json [file join $s(project) derived validation.json] build.json [file join $s(project) derived build.json] adapter.cpp [file join $::GX::scriptDir core development sdk trusted_adapter_v1.cpp]]
    foreach source $names {dict set roots $source [file join $s(project) $source]}
    if {![dict exists $roots $name]} {error {Choose a declared source, manual or generated report}}
    if {[dict exists $s(tabs) $name]} {
        .gxViewerDevelopment.body.center.sources select [dict get $s(tabs) $name page]
        projectTabSelected
        return [text]
    }
    set path [dict get $roots $name];set source {};set checksum {}
    if {[file exists $path]} {
        if {![file isfile $path] || [file type $path] eq {link} || [file size $path]>4194304} {error {Source is not an ordinary bounded file}}
        set stream [::open $path rb];try {set source [encoding convertfrom utf-8 [::read $stream 4194305]]} finally {::close $stream}
        set checksum [::GX::sha256File $path]
    } elseif {$name ne {MANUAL.md}} {error {Selected source/report is unavailable}}
    set editable [expr {$name in $names || $name in {project.json MANUAL.md}}]
    set language [expr {[file extension $name] in {.cpp .hpp}?{cpp}:($name eq {MANUAL.md}?{markdown}:([file extension $name] eq {.json}?{javascript}:{tcl}))}]
    set widget [projectTabCreate $name $source $editable $language $checksum]
    if {$name in $names} {
        ::GX::sourceSurfaceDocumentIdentity $widget [list viewer-cpp:$s(project)/$name [::GX::_viewerDevelopmentSnapshot $s(project)] $checksum]
        if {[info exists ::GX::ViewerDevelopmentWorkspace::debug(request)] && $::GX::ViewerDevelopmentWorkspace::debug(request) ne {}} {::GX::sourceSurfaceBreakpoints $widget lock}
    }
    .gxViewerDevelopment.body.center.sources select [dict get $s(tabs) $name page];projectTabSelected
    return $widget
}
proc ::GX::ViewerDevelopmentWorkspace::projectTreeRefresh {} {
    variable s
    set tree .gxViewerDevelopment.body.left.files.tree;$tree delete [$tree children {}]
    foreach name [::GX::viewerDevelopmentSourceFiles $s(project)] {
        set parent {};set prefix {}
        foreach part [lrange [split $name /] 0 end-1] {
            set prefix [expr {$prefix eq {}?$part:"$prefix/$part"}]
            set id folder:$prefix
            if {![$tree exists $id]} {$tree insert $parent end -id $id -text $part -open 1}
            set parent $id
        }
        $tree insert $parent end -id $name -text "[file tail $name][expr {$name eq {handlers.cpp}?{ · entrypoint}:{}}]"
    }
    foreach {name label} {project.json {Project / facilities / tests} MANUAL.md {Manual (Markdown)} design.gxtxt-viewer {Builder design (read-only)} validation.json {Validation report} build.json {Build manifest} adapter.cpp {Trusted C++ adapter}} {$tree insert {} end -id $name -text $label}
    ::GX::uiFieldInspectionColumnsSchedule $tree
}
proc ::GX::ViewerDevelopmentWorkspace::projectSave {{all 0}} {
    variable s
    if {$s(mode) eq {maintenance}} {return [maintenanceSave]}
    projectDirty
    set updates {};set submitted {}
    dict for {name tab} $s(tabs) {
        if {![dict get $tab dirty] || (!$all && $name ne $s(file))} continue
        set source [::GX::sourceSurfaceGet [dict get $tab text]]
        set checksum [dict get $tab sha256]
        set expected [expr {$checksum eq {}?{null}:[::GX::viewerDevelopmentJsonString $checksum]}]
        lappend updates "[::GX::viewerDevelopmentJsonString $name]:\{\"source\":[::GX::viewerDevelopmentJsonString $source],\"expected_sha256\":$expected\}"
        dict set submitted $name $source
    }
    if {![llength $updates]} {set s(status) {No unsaved source changes.};return}
    set request [format {{"operation":"save_all","expected_project_sha256":"%s","files":{%s}}} $s(projectHash) [join $updates ,]]
    set result [maintenanceWait project_files $request]
    if {[dict get $result status] ne {SAVED}} {error {Save did not complete; source buffers retained}}
    # Only the exact submitted bytes become a baseline. Input may have continued
    # while the managed request yielded; newer keystrokes remain dirty.
    dict for {name source} $submitted {
        set path [file join $s(project) $name]
        set stream [::open $path rb];try {set actual [encoding convertfrom utf-8 [::read $stream]]} finally {::close $stream}
        if {$actual ne $source} {error "Save readback differs for $name; buffers retained, inspect before retry"}
    }
    dict for {name source} $submitted {dict set s(tabs) $name baseline $source;dict set s(tabs) $name sha256 [::GX::sha256File [file join $s(project) $name]]}
    set s(projectHash) [dict get $result project_sha256]
    projectSourceIdentities
    projectDirty;projectTabSelected
    set s(status) "[expr {$all?{Saved all changed files}:{Saved source}}] · [dict size $submitted] file(s) · source revision checked"
    if {[dict exists $submitted project.json]} {apiRefresh}
    return $result
}
proc ::GX::ViewerDevelopmentWorkspace::saveAll {} {return [projectSave 1]}
proc ::GX::ViewerDevelopmentWorkspace::projectTabClose {} {
    variable s
    if {$s(busy) ne {}} {error {Wait or cancel the active request before closing source tabs}}
    if {![dict exists $s(tabs) $s(file)]} return
    set name $s(file);set tab [dict get $s(tabs) $name]
    projectDirty
    if {[dict get $s(tabs) $name dirty]} {
        set answer [tk_messageBox -parent .gxViewerDevelopment -type yesnocancel -icon question -title {Close source tab} -message "Save $name before closing this tab?"]
        if {$answer eq {cancel}} return
        if {$answer eq {yes}} {projectSave}
        if {$answer eq {yes} && [dict get $s(tabs) $name dirty]} {error {New edits arrived during Save; source tab retained}}
    }
    .gxViewerDevelopment.body.center.sources forget [dict get $tab page];destroy [dict get $tab page];dict unset s(tabs) $name
    projectDirty;projectTabSelected
    if {![dict size $s(tabs)]} {set s(editor) {};set s(file) {};set s(status) {Choose a project file to open a source tab.}}
}
proc ::GX::ViewerDevelopmentWorkspace::projectSourceIdentities {} {
    variable s
    set snapshot [::GX::_viewerDevelopmentSnapshot $s(project)]
    set sources [::GX::viewerDevelopmentSourceFiles $s(project)]
    dict for {name tab} $s(tabs) {
        if {$name in $sources} {::GX::sourceSurfaceDocumentIdentity [dict get $tab text] [list viewer-cpp:$s(project)/$name $snapshot [dict get $tab sha256]]}
    }
}
proc ::GX::ViewerDevelopmentWorkspace::projectFileDialog {operation} {
    variable s
    if {$s(mode) ne {cpp} || $s(project) eq {} || $s(busy) ne {}} {error {Open an idle C++ project first}}
    set s(fileOperation) $operation;set s(newFileSource) {};set s(newFileName) src/helper.cpp
    if {$operation eq {import}} {
        set path [tk_getOpenFile -parent .gxViewerDevelopment -title {Add existing source/header} -filetypes {{{C++ project sources} {.cpp .hpp}}}]
        if {$path eq {}} return
        if {![file isfile $path] || [file type $path] eq {link} || [file size $path]>65536} {error {Choose an ordinary UTF-8 source/header within64KiB}}
        set stream [::open $path rb];try {set s(newFileSource) [encoding convertfrom utf-8 [::read $stream 65537]]} finally {::close $stream}
        set s(newFileName) [file join [expr {[file extension $path] eq {.hpp}?{include}:{src}}] [file tail $path]]
    } elseif {$operation eq {rename}} {
        if {$s(file) ni [::GX::viewerDevelopmentSourceFiles $s(project)] || $s(file) eq {handlers.cpp}} {error {Open an auxiliary source/header to rename or move}}
        set s(fileOriginal) $s(file);set s(newFileName) $s(file)
    }
    set w .gxViewerDevelopment.projectFile;catch {destroy $w}
    ::GX::uiFieldDialogCreate $w .gxViewerDevelopment [expr {$operation eq {rename}?{Rename or move project file}:{Add project file}}] 620x220
    ttk::label $w.help -text {Use src/path.cpp for a translation unit or include/path.hpp for a local header. Names are project-relative. Rename/move preserves source bytes and does not rewrite C++ include statements.} -wraplength 570 -justify left
    ttk::label $w.label -text {Project-relative file name}
    ttk::entry $w.name -textvariable ::GX::ViewerDevelopmentWorkspace::s(newFileName) -width 55
    ::GX::uiTextEditingAttach $w [list $w.name]
    ttk::frame $w.buttons
    ttk::button $w.buttons.apply -text [expr {$operation eq {rename}?{Rename / move}:{Add file}}] -command {::GX::ViewerDevelopmentWorkspace::safe projectFileCommit}
    ttk::button $w.buttons.cancel -text Cancel -command [list ::GX::uiFieldDialogClose $w]
    pack $w.help $w.label $w.name -fill x -padx 12 -pady 6;pack $w.buttons -fill x -padx 8 -pady 8
    pack $w.buttons.apply $w.buttons.cancel -side left -padx 4
    bind $w.name <Return> {::GX::ViewerDevelopmentWorkspace::safe projectFileCommit;break}
    bind $w <Escape> [list ::GX::uiFieldDialogClose $w]
    ::GX::uiFieldDialogPresent $w $w.name 0
}
proc ::GX::ViewerDevelopmentWorkspace::projectFileCommit {} {
    variable s
    if {$s(dirty)} {saveAll}
    if {$s(dirty)} {error {New edits arrived during Save All; project files are preserved}}
    set name $s(newFileName);set fields [format {"expected_project_sha256":"%s"} $s(projectHash)]
    if {$s(fileOperation) eq {rename}} {
        set original $s(fileOriginal)
        set request [format {{"operation":"rename",%s,"name":%s,"target":%s}} $fields [::GX::viewerDevelopmentJsonString $original] [::GX::viewerDevelopmentJsonString $name]]
    } else {
        set source $s(newFileSource)
        if {$source eq {} && [file extension $name] eq {.hpp}} {set source "#pragma once\n"}
        set request [format {{"operation":"add",%s,"name":%s,"source":%s}} $fields [::GX::viewerDevelopmentJsonString $name] [::GX::viewerDevelopmentJsonString $source]]
    }
    set result [maintenanceWait project_files $request]
    if {$s(fileOperation) eq {rename} && [dict exists $s(tabs) $original]} {
        set page [dict get $s(tabs) $original page];.gxViewerDevelopment.body.center.sources forget $page;destroy $page;dict unset s(tabs) $original
    }
    set s(projectHash) [dict get $result project_sha256];projectTreeRefresh;projectSourceIdentities;read $name
    ::GX::uiFieldDialogClose .gxViewerDevelopment.projectFile
    set s(status) "Project file [expr {$s(fileOperation) eq {rename}?{renamed/moved}:{added}}]: $name · Build explicitly for this revision"
}
proc ::GX::ViewerDevelopmentWorkspace::projectFileRemove {} {
    variable s
    set name $s(file)
    if {$name eq {handlers.cpp} || $name ni [::GX::viewerDevelopmentSourceFiles $s(project)]} {error {Open an auxiliary source/header to remove}}
    if {![prepare]} return
    if {[tk_messageBox -parent .gxViewerDevelopment -type yesno -default no -icon warning -title {Remove project file} -message "Remove $name from this project and its source folder? Other source text and includes are preserved."] ne {yes}} return
    set request [format {{"operation":"remove","expected_project_sha256":"%s","name":%s}} $s(projectHash) [::GX::viewerDevelopmentJsonString $name]]
    set result [maintenanceWait project_files $request]
    if {[dict exists $s(tabs) $name]} {set page [dict get $s(tabs) $name page];.gxViewerDevelopment.body.center.sources forget $page;destroy $page;dict unset s(tabs) $name}
    set s(projectHash) [dict get $result project_sha256];projectTreeRefresh;projectSourceIdentities;read handlers.cpp
    set s(status) "Removed $name · remaining includes may need editing before Build"
}
proc ::GX::ViewerDevelopmentWorkspace::importProject {} {
    variable s
    if {![prepare]} return
    set package [tk_getOpenFile -parent .gxViewerDevelopment -title {Import exported C++ Viewer project} -filetypes {{{Viewer package} {.zip}}}]
    if {$package eq {}} return
    set parent [tk_chooseDirectory -parent .gxViewerDevelopment -title {Parent folder for the imported editable project}]
    if {$parent eq {}} return
    set s(newProject) [file join $parent viewer_import_[clock microseconds]]
    incr s(generation)
    set s(busy) [::GX::viewerDevelopmentRequest import_project $s(newProject) [list ::GX::ViewerDevelopmentWorkspace::created $s(generation)] [dict create source_package $package]]
    set s(status) {Checking package/source closure and importing a new editable project…};controls
}

proc ::GX::ViewerDevelopmentWorkspace::apiPanelToggle {} {
    variable s
    set book .gxViewerDevelopment.body.right
    if {$s(apiVisible)} {$book add $book.api -text {API Browser};$book select $book.api} else {$book hide $book.api}
    responsiveBody .gxViewerDevelopment
}
