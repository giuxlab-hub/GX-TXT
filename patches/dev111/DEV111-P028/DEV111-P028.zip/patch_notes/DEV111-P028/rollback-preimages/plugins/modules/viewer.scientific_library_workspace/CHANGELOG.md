# Changelog

## 1.0.4

Rebuild and export against the current reviewed multifile compiler recipe. Bind the final source/design/project version and source-to-binary receipt while retaining byte-identical scientific-library native behavior. The prior1.0.3 candidate remains preserved.

## 1.0.3

Unify library management in the Builder-authored Scientific Libraries Viewer.
Add true normalized entry search, source-bound entry pages, individual metadata/
provenance inspection, provider inventory and exact type filtering before paging.
Deprecate redundant legacy catalog tiles while retaining their saved routes.

## Earlier library API development

The registry extension was documented as Step1/dev-045, capability/catalog
presentation as Step2/dev109, normalized content as Step3/dev110 candidate,
finite Python/Octave projections as Step4 and protected credentials as Step5.
P025 added external JSON/HTTPS and managed IR/NMR normalized content plus
independent scoped credential/runtime validation. Historical staged-acceptance
notes and exact original source remain in the accepted P026 Git baseline and
preserved task210/library_step3, library_step4 and library_step5 handoffs.
The current API manual now describes present contracts and explicit limits.
