# Development Workspace change history

## 1.2.2

- Applies the existing UI Field inspection font/row-height owner to the shared API Browser while its tree is empty, preserving the Browser column and scrolling policy. Real enlarged-font API family and method glyphs no longer clip vertically.
- Recalculates the existing three-row/four-line window budget from those actual rows. Source, compiler, SDK, runtime and scientific operations remain unchanged.
- Retains1.2.1 allocation evidence as a separate scope; later independent visual review found raw default Treeview20px rows clipped30px font18 glyphs despite sufficient pane bounds.

## 1.2.1

- Keeps the existing shared API Browser list and details readable with saved larger Appearance fonts. Compact search/actions release redundant chrome, settled native sashes retain actual row/line minima, and the Workspace window minimum follows measured control/notebook/Diagnostics budgets.
- Preserves ordinary-font 980×650 composition, the regular script Browser, all source/runtime services and the compiler recipe.
- Moves prior contract test/rollout notes out of the current API guide. Those include Step2/Dev108/TASK210 chronology, retained E/M nine-state checks, raster acceptance reports and the earlier scaling1.998 21-assertion Browser fixture; they retain their original evidence scope.

## Multifile project authoring

- Extends the existing fixed C++ project/build/GDB owners to ordered translation units and local headers with exact source/build/package closure.
- Adds independent Source Surface tabs, per-file dirty state, Save All, nested source tree and file add/rename/move/remove.
- Adds checked editable project package import and authentic helper/header/caller debugger navigation.
- Moves historical manual acceptance notes out of the functional guide: dev108 visibility/debug facilities; earlier installed Circuit author1.8/1.9 captures and qa_plot_series04 renderer/History acceptance retain their original release evidence. The former73976-byte manual refusal and subsequent74071-byte/seven-asset export are historical author evidence, not current manual instructions.

## 1.1.0 — dev108

Actual admitted-source C++ debugger via approved GUI and structured public CLI; source-bound restricted authoring, bounded Builder history, canonical Save and reviewed presentation-copy facilities; comprehensive illustrated manual and canonical About.

# Changes

## 1.0.0

Restricted C++ source projects use the shared CORE source editor, actual Clang
lexer/AST validation, fixed curated SDK/toolchain, project-write grant and a
separate bounded native worker. GUI and CLI share one backend. Public API
inspection distinguishes installed facilities from the authorized SDK subset.
Export creates an ordinary Viewer package candidate for Plugin Manager review.
Python authoring is disabled.
