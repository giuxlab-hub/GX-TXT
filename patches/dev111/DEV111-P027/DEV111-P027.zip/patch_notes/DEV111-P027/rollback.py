#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Guarded P027→exact P026 rollback; default read-only. Stop GX-TXT first."""
from pathlib import Path
import argparse, sys, zipfile
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
from release_common import GuardError, rollback_overlay

def main():
    p = argparse.ArgumentParser(description=__doc__);p.add_argument('framework', type=Path)
    group = p.add_mutually_exclusive_group();group.add_argument('--check', action='store_true');group.add_argument('--rollback', action='store_true')
    p.add_argument('--recover-partial', action='store_true', help='Accept only exact known before/after states from interrupted overlay/rollback')
    p.add_argument('--stopped', action='store_true', help='Acknowledge target stopped; no process detector')
    a = p.parse_args()
    if a.rollback and not a.stopped:p.error('--rollback requires --stopped acknowledgment; no runtime-stop enforcement is implemented')
    m = rollback_overlay(a.framework, a.rollback, a.recover_partial)
    print(('RESTORED exact P026; notes retained as evidence' if a.rollback else 'CHECK PASS; no writes') + ': ' + m['baseline_commit'])
if __name__ == '__main__':
    try:main()
    except (GuardError, OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as e:raise SystemExit('REFUSED: ' + str(e))
