# SPDX-License-Identifier: GPL-3.0-or-later
"""P027 finite file-overlay guards. No runtime, Session or configuration owner."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, stat, tempfile, zipfile
from contextlib import contextmanager

PATCH = 'DEV111-P027'
BASE = '12bafa70ed76456a05263cff34d486313bff240b'
BASE_SHA = 'a94f534ea4def46cbe665cdf5e1fc8b1ccb1129d732cf09295d0f7a63ae34e2f'
NOTES = 'patch_notes/' + PATCH
MAX_FILE = 128 * 1024 * 1024
MAX_ZIP = 512 * 1024 * 1024

class GuardError(RuntimeError):
    pass

def require(test, message):
    if not test:
        raise GuardError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def relative(name):
    require(isinstance(name, str) and name and len(name) <= 4096 and '\\' not in name and ':' not in name and not any(ord(c) < 32 for c in name), 'Unsafe relative path')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(part not in ('', '.', '..') for part in name.split('/')), 'Unsafe relative path: ' + name)
    return p

SPECIAL = {'gxtxt_pipeline.tcl', 'VERSION.txt', 'PATCH_LEVEL.txt', 'GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'LICENSE'}
SKIP = {'tests', 'validation', 'evidence', 'review', 'archives', 'archive', '__pycache__', '.git', 'node_modules', 'scratch'}

def runtime_path(name):
    p = relative(name)
    # These are installed Native Viewer admission/source receipts, not campaign
    # evidence. Omitting them would pair a new binary with an old build identity.
    if len(p.parts) == 5 and p.parts[:2] == ('plugins', 'modules') and p.parts[3] == 'review' and p.parts[4] in ('build.json', 'validation.json'):
        return True
    if any(x.lower() in SKIP for x in p.parts) or name.lower().endswith(('.zip', '.tar', '.gz', '.xz', '.bz2', '.7z', '.pyc', '.log')):
        return False
    return name in SPECIAL or name.startswith(('app/', 'core/', 'plugins/', 'docs/api/', 'services/'))

def payload_path(name):
    return runtime_path(name) and name not in {'VERSION.txt', 'LICENSE', 'app/gui/help_page.tcl'} and not name.startswith('services/')

def root_path(root):
    root = Path(os.path.abspath(root))
    for p in [*reversed(root.parents), root]:
        require(not p.is_symlink(), 'Linked framework root/ancestor: ' + str(p))
    require(root.is_dir(), 'Existing canonical framework directory required')
    return root

def member(root, name):
    current = root
    parts = relative(name).parts
    for index, part in enumerate(parts):
        current = current / part
        require(not current.is_symlink(), 'Linked target/ancestor: ' + str(current))
        if current.exists() and index < len(parts)-1:
            require(current.is_dir(), 'Non-directory ancestor: ' + str(current))
    return current

def identity(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return None
    require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1, 'Nonregular/linked target: ' + str(path))
    return {'sha256': sha(path), 'mode': stat.S_IMODE(st.st_mode), 'size': st.st_size}

def matches(actual, expected):
    return actual == expected

def zip_index(z):
    entries = {}
    directories = set()
    for item in z.infolist():
        require(not item.flag_bits & 1, 'Encrypted ZIP unsupported')
        name = item.filename.rstrip('/') if item.is_dir() else item.filename
        relative(name)
        require(name not in entries and name not in directories, 'Duplicate ZIP member: ' + name)
        mode = item.external_attr >> 16
        if item.is_dir():
            require(stat.S_IFMT(mode) in (0, stat.S_IFDIR), 'Invalid ZIP directory')
            directories.add(name)
            continue
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG) and not stat.S_ISLNK(mode), 'Nonregular ZIP member: ' + name)
        require(item.file_size <= MAX_FILE, 'Oversized ZIP member: ' + name)
        entries[name] = item
    require(sum(x.file_size for x in entries.values()) <= MAX_ZIP, 'ZIP exceeds patch bound')
    for name in set(entries) | directories:
        require(all(str(p) not in entries for p in PurePosixPath(name).parents if str(p) != '.'), 'ZIP file/directory collision')
    require(z.testzip() is None, 'ZIP CRC failure')
    return entries

def file_record(value, nullable=False):
    if value is None:
        require(nullable, 'Required file identity is absent')
        return
    require(isinstance(value, dict) and set(value) == {'sha256', 'mode', 'size'}, 'Invalid file identity fields')
    require(isinstance(value['sha256'], str) and len(value['sha256']) == 64 and all(c in '0123456789abcdef' for c in value['sha256']), 'Invalid SHA256')
    require(type(value['mode']) is int and 0 <= value['mode'] <= 0o777, 'Invalid file mode')
    require(type(value['size']) is int and 0 <= value['size'] <= MAX_FILE, 'Invalid file size')

def validate(manifest, closure):
    require(isinstance(manifest, dict) and isinstance(closure, dict), 'Manifest/closure must be objects')
    require(manifest.get('schema') == 'gxtxt.dev111.p027.overlay.v1' and manifest.get('patch') == PATCH and manifest.get('baseline_commit') == BASE and manifest.get('baseline_archive_sha256') == BASE_SHA, 'Wrong patch or exact P026 predecessor identity')
    require(isinstance(manifest.get('source_commit'), str) and len(manifest['source_commit']) == 40 and all(c in '0123456789abcdef' for c in manifest['source_commit']), 'Invalid source commit')
    require(closure.get('source_commit') == BASE and isinstance(closure.get('files'), dict) and closure['files'], 'Invalid predecessor closure')
    require('core/tcl/plugin_install_api_v1.tcl' in closure['files'], 'Missing baseline sentinel')
    require(digest(json_bytes(closure)) == manifest.get('baseline_closure_sha256'), 'Baseline closure checksum differs')
    for name, expected in closure['files'].items():
        relative(name); file_record(expected)
    rows = manifest.get('changed_files')
    require(isinstance(rows, list) and rows, 'Nonempty change manifest required')
    seen = set()
    for row in rows:
        require(set(row) == {'path', 'action', 'before', 'after'}, 'Invalid change fields')
        name = row['path'];relative(name)
        require(payload_path(name), 'Protected/non-runtime payload path: ' + name)
        require(name not in seen and not name.startswith('patch_notes/'), 'Duplicate/reserved product path')
        seen.add(name);file_record(row['before'], True);file_record(row['after'], True)
        expected_action = 'add' if row['before'] is None else 'delete' if row['after'] is None else 'replace'
        require(row['action'] == expected_action and not (row['before'] is None and row['after'] is None), 'Invalid change action')
        require(closure['files'].get(name) == row['before'], 'Change preimage differs from exact baseline closure: ' + name)
    return rows

def sums(text):
    result = {}
    for line in text.decode('utf-8').splitlines():
        value, name = line.split('  ', 1);relative(name)
        require(name not in result and len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'Invalid checksum entry')
        result[name] = value
    return result

def archive_data(path, expected_sha=None):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), 'Regular patch ZIP required')
    if expected_sha is None:
        sidecar = Path(str(path) + '.sha256')
        require(not sidecar.is_symlink() and sidecar.is_file(), 'Provide adjacent ZIP.sha256 or --sha256')
        words = sidecar.read_text().split()
        require(len(words) == 2 and words[1] == path.name, 'Invalid archive checksum sidecar')
        expected_sha = words[0]
    require(sha(path) == expected_sha, 'Patch ZIP SHA256 differs')
    with zipfile.ZipFile(path) as z:
        entries = zip_index(z)
        require(NOTES + '/FILES.json' in entries and NOTES + '/BASELINE.json' in entries, 'Missing P027 notes/closure')
        data = {name: z.read(name) for name in entries}
        manifest = json.loads(data[NOTES + '/FILES.json']);closure = json.loads(data[NOTES + '/BASELINE.json'])
        rows = validate(manifest, closure)
        listed = sums(data[NOTES + '/PAYLOAD_SHA256SUMS'])
        require(set(listed) == set(data) - {NOTES + '/PAYLOAD_SHA256SUMS'}, 'Incomplete archive checksums')
        for name, expected in listed.items():
            require(digest(data[name]) == expected, 'Archive checksum differs: ' + name)
        products = {r['path'] for r in rows if r['after'] is not None}
        require(set(data) == products | {n for n in data if n.startswith(NOTES + '/')}, 'Unexpected product member')
        for row in rows:
            for key, name in [('after', row['path']), ('before', NOTES + '/rollback-preimages/' + row['path'])]:
                record = row[key]
                if record is None:
                    continue
                require(name in data and digest(data[name]) == record['sha256'] and len(data[name]) == record['size'] and ((entries[name].external_attr >> 16) & 0o777) == record['mode'], 'Invalid ' + key + ': ' + row['path'])
        return manifest, closure, rows, data, entries

def guard_baseline(root, closure, rows, rollback=False, partial=False):
    changed = {r['path']: r for r in rows}
    for name, expected in closure['files'].items():
        actual = identity(member(root, name));row = changed.get(name)
        if row is None or not rollback:
            require(matches(actual, expected), 'Divergent P026 baseline: ' + name)
    for row in rows:
        actual = identity(member(root, row['path']))
        wanted = row['after'] if rollback else row['before']
        permitted = [wanted, row['before']] if rollback and partial else [wanted]
        require(any(matches(actual, p) for p in permitted), 'Unknown/divergent ' + ('postimage' if rollback else 'preimage') + ': ' + row['path'])

def atomic(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.p027-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data);f.flush();os.fchmod(f.fileno(), mode);os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):os.unlink(temp)

def _apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    manifest, closure, rows, data, entries = archive_data(archive, expected_sha)
    require(not member(root, NOTES).exists(), 'P027 notes already exist; use rollback/recover-partial first')
    guard_baseline(root, closure, rows)
    for name in data:member(root, name)
    if mutate:
        # Publish complete verified rollback information before any product write.
        for name in sorted(data):
            if name.startswith(NOTES + '/'):
                atomic(member(root, name), data[name], (entries[name].external_attr >> 16) & 0o777)
        for row in rows:
            p = member(root, row['path'])
            require(identity(p) == row['before'], 'Preimage changed during apply: ' + row['path'])
            if row['after'] is None:p.unlink()
            else:atomic(p, data[row['path']], row['after']['mode'])
        guard_baseline(root, closure, rows, rollback=True)
    return manifest

def _rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root);notes = member(root, NOTES)
    require(notes.is_dir(), 'Installed P027 notes required')
    manifest_path = member(root, NOTES + '/FILES.json');closure_path = member(root, NOTES + '/BASELINE.json')
    require(identity(manifest_path) is not None and identity(closure_path) is not None, 'Incomplete notes; recover verified notes from the exact archive first')
    manifest = json.loads(manifest_path.read_bytes());closure = json.loads(closure_path.read_bytes());rows = validate(manifest, closure)
    listed = sums(member(root, NOTES + '/PAYLOAD_SHA256SUMS').read_bytes())
    for name, expected in listed.items():
        if name.startswith(NOTES + '/'):
            p = member(root, name)
            require(identity(p) is not None and sha(p) == expected, 'Incomplete/divergent installed notes: ' + name)
    require(NOTES + '/FILES.json' in listed and NOTES + '/BASELINE.json' in listed, 'Unbound installed manifest')
    guard_baseline(root, closure, rows, rollback=True, partial=partial)
    for row in rows:
        if row['before'] is not None:
            p = member(root, NOTES + '/rollback-preimages/' + row['path'])
            require(identity(p) == row['before'], 'Rollback preimage/mode differs: ' + row['path'])
    if mutate:
        for row in reversed(rows):
            p = member(root, row['path']);actual = identity(p)
            require(actual == row['after'] or partial and actual == row['before'], 'Target changed during rollback: ' + row['path'])
            if actual == row['before']:continue
            if row['before'] is None:p.unlink()
            else:
                backup = member(root, NOTES + '/rollback-preimages/' + row['path'])
                atomic(p, backup.read_bytes(), row['before']['mode'])
        guard_baseline(root, closure, rows)
    return manifest

@contextmanager
def operation_lock(root, enabled):
    if not enabled:
        yield
        return
    try:
        import fcntl
    except ImportError as error:
        raise GuardError('Guarded writes require POSIX directory locking; --check remains available') from error
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        try:fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:raise GuardError('Another release helper owns this framework directory') from error
        yield
    finally:os.close(fd)

def apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    with operation_lock(root, mutate):return _apply_overlay(root, archive, mutate, expected_sha)

def rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root)
    with operation_lock(root, mutate):return _rollback_overlay(root, mutate, partial)
