# NIST/PNNL: indice ottico k, griglia standard e replay storico

Generator ID `nist_pnnl_ir_faculty`, versione1.1.0.

Gli originali sono costanti ottiche liquide PNNL/IARPA2017 (etanolo,
metanolo,2-propanolo): indice di dispersione n e indice di assorbimento k sono
quantità diverse. Questo laboratorio pubblica SOLO k; k non è assorbanza. Gli
originali n/k e i derivati k restano immutati in RAW con i checksum del pacchetto.
La Library pubblicata1.0.0 ha una griglia storica nominal-DELTAX, mentre il parser
JCAMP attuale usa FIRSTX/LASTX/NPOINTS. La differenza non è nascosta né corretta
riscrivendo Library o parser.

Leggi STUDENT_GUIDE, FACULTY_GUIDE, EXPECTED_RESULTS, TEST_PLAN e RIGHTS.
Codice originale GPL-3.0-or-later; dati esterni con diritti propri. Il generatore
usa parser/Manager pubblici e Script Bridge Publication v2, non un Registry o
writer HDF5 privato. Richiede capacità effettive, non versioni esatte dei moduli.
Generate non esegue implicitamente Analysis né certifica GUI/portable/HTML.

English: independently installable teaching generator with explicit source and
scientific provenance; execute the full documented workflow after generation.
