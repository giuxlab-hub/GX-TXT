# Piano di test — nist_pnnl_ir_faculty


## Confini obbligatori di verifica

- Import/Export normale del generatore: ID/versione, tutti i checksum, nessuna
  esecuzione nascosta durante l'import e nessun modulo Viewer incorporato.
- Generate in una Session nuova: solo parser/Manager e Script Bridge Publication
  v2; veri payload HDF5, schema v3, ruoli/coordinate/unità e hash/provenienza.
  Un prerequisito mancante rifiuta senza una Session completata fittizia.
- Lettura integrale con API canoniche e oracle indipendente; le prime righe o una
  curva plausibile non bastano. Ripeti in processo nuovo e seconda Session nuova.
- Esecuzione reale della guida nativa con due Dataset, cinque modalità quando
  ammesse e tredici comandi Plot; errore e revoca mantengono l'ultimo frame valido.
- Salvataggio Variant/Workspace/configurazione Session, History e cold reopen;
  portable ZIP in destinazione nuova, Current HTML/ZIP e grafici realmente aperti.
- Analysis reale separata dalla pubblicazione: attendere il Job e leggere tutti i
  prodotti/report. Annotare conti, parametri, sorgenti e limiti dei candidati.
- Distinguere ricevute di generazione, regressione scientifica, GUI, cold/portable
  e accettazione indipendente. Questo documento specifica test, non dichiara PASS.

## Oracle specifico

Etanolo15347; metanolo15345;2-propanolo15345 campioni per ciascuna traccia.
Entrambe conservano tutti gli Y originali; legacy X coincide con FIRSTX+i*DELTAX
e con la Library storica entro1e-8. Standard X coincide con FIRSTX+i*(LASTX−FIRSTX)/(N−1).
Le deviazioni massime X standard-versus-Library osservate preliminarmente sono
2.356000004510861e-5,8.199999956559623e-5,1.1840000297524966e-5cm^-1 rispettivamente;
sono maggiori di1e-8 e DEVONO essere riportate. Nessun PASS XY standard/legacy.
Un oracle indipendente deve leggere gli header originali e verificare tutte le
righe; non usare Library→Library come prova circolare. Lineage standard→legacy,
HDF5 reale, schema stabile e identità k/unità1 devono sopravvivere a cold/ZIP.

English: record actual outcomes and retained failures; do not infer execution
from successful staging, metadata inventories or source code.
