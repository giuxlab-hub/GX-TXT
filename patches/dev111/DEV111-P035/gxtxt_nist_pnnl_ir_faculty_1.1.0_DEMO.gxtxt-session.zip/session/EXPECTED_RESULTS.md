# Risultati attesi / Expected results

Etanolo15347; metanolo15345;2-propanolo15345 campioni per ciascuna traccia.
Entrambe conservano tutti gli Y originali; legacy X coincide con FIRSTX+i*DELTAX
e con la Library storica entro1e-8. Standard X coincide con FIRSTX+i*(LASTX−FIRSTX)/(N−1).
Le deviazioni massime X standard-versus-Library osservate preliminarmente sono
2.356000004510861e-5,8.199999956559623e-5,1.1840000297524966e-5cm^-1 rispettivamente;
sono maggiori di1e-8 e DEVONO essere riportate. Nessun PASS XY standard/legacy.
Un oracle indipendente deve leggere gli header originali e verificare tutte le
righe; non usare Library→Library come prova circolare. Lineage standard→legacy,
HDF5 reale, schema stabile e identità k/unità1 devono sopravvivere a cold/ZIP.

## Identità di pubblicazione

- `ir.nist.ethanol.standard_grid`: 15347 campioni, hdf5, ethanol liquid2017 imaginary refractive-index absorption index k; not absorbance; current FIRSTX/LASTX/NPOINTS grid, legacy X deviation explicitly reported
- `ir.nist.ethanol.legacy_grid`: 15347 campioni, hdf5, ethanol liquid2017 imaginary refractive-index absorption index k; not absorbance; explicitly derived historical FIRSTX+i*nominalDELTAX replay, not current raw decoding
- `ir.nist.methanol.standard_grid`: 15345 campioni, hdf5, methanol liquid2017 imaginary refractive-index absorption index k; not absorbance; current FIRSTX/LASTX/NPOINTS grid, legacy X deviation explicitly reported
- `ir.nist.methanol.legacy_grid`: 15345 campioni, hdf5, methanol liquid2017 imaginary refractive-index absorption index k; not absorbance; explicitly derived historical FIRSTX+i*nominalDELTAX replay, not current raw decoding
- `ir.nist.2_propanol.standard_grid`: 15345 campioni, hdf5, 2_propanol liquid2017 imaginary refractive-index absorption index k; not absorbance; current FIRSTX/LASTX/NPOINTS grid, legacy X deviation explicitly reported
- `ir.nist.2_propanol.legacy_grid`: 15345 campioni, hdf5, 2_propanol liquid2017 imaginary refractive-index absorption index k; not absorbance; explicitly derived historical FIRSTX+i*nominalDELTAX replay, not current raw decoding

Questi sono oracle e confini da verificare, non ricevute di una esecuzione.
Canonical data must remain unchanged by display, Workspace and image export.
