# NIST/PNNL: indice ottico k, griglia standard e replay storico

Gli originali sono costanti ottiche liquide PNNL/IARPA2017 (etanolo,
metanolo,2-propanolo): indice di dispersione n e indice di assorbimento k sono
quantità diverse. Questo laboratorio pubblica SOLO k; k non è assorbanza. Gli
originali n/k e i derivati k restano immutati in RAW con i checksum del pacchetto.
La Library pubblicata1.0.0 ha una griglia storica nominal-DELTAX, mentre il parser
JCAMP attuale usa FIRSTX/LASTX/NPOINTS. La differenza non è nascosta né corretta
riscrivendo Library o parser.

## Avvio

Importa il normale pacchetto del generatore nel Manager, poi New Session → Generate
Session e scegli `nist_pnnl_ir_faculty` versione1.1.0 con un nome nuovo. Leggi RIGHTS
prima di redistribuire. Controlla queste identità effettive:

- `ir.nist.ethanol.standard_grid`: 15347 campioni, hdf5, ethanol liquid2017 imaginary refractive-index absorption index k; not absorbance; current FIRSTX/LASTX/NPOINTS grid, legacy X deviation explicitly reported
- `ir.nist.ethanol.legacy_grid`: 15347 campioni, hdf5, ethanol liquid2017 imaginary refractive-index absorption index k; not absorbance; explicitly derived historical FIRSTX+i*nominalDELTAX replay, not current raw decoding
- `ir.nist.methanol.standard_grid`: 15345 campioni, hdf5, methanol liquid2017 imaginary refractive-index absorption index k; not absorbance; current FIRSTX/LASTX/NPOINTS grid, legacy X deviation explicitly reported
- `ir.nist.methanol.legacy_grid`: 15345 campioni, hdf5, methanol liquid2017 imaginary refractive-index absorption index k; not absorbance; explicitly derived historical FIRSTX+i*nominalDELTAX replay, not current raw decoding
- `ir.nist.2_propanol.standard_grid`: 15345 campioni, hdf5, 2_propanol liquid2017 imaginary refractive-index absorption index k; not absorbance; current FIRSTX/LASTX/NPOINTS grid, legacy X deviation explicitly reported
- `ir.nist.2_propanol.legacy_grid`: 15345 campioni, hdf5, 2_propanol liquid2017 imaginary refractive-index absorption index k; not absorbance; explicitly derived historical FIRSTX+i*nominalDELTAX replay, not current raw decoding

## Due tracce scientifiche esplicite

Per ogni composto Generate pubblica prima `.standard_grid` con il parser corrente
e poi `.legacy_grid` derivato da X_i=FIRSTX+i*DELTAX nominale. Il secondo ha lineage
verso il primo; i valori k/Y e lo SHA originale coincidono. La traccia standard è
la lettura attuale; quella legacy è un replay didattico esplicito, non un'altra
misura. Leggi FIRSTX,LASTX,DELTAX,NPOINTS e la policy nei metadati pubblici.

Confronta, per esempio, `ir.nist.ethanol.standard_grid` e
`ir.nist.ethanol.legacy_grid` con tutti i modi Comparison. Le griglie differiscono:
le differenze interpolate non sono automaticamente zero. Confronta separatamente
ogni legacy con la voce Manager corretta entro1e-8 su TUTTI i campioni; per gli
standard confronta tutti gli Y e riporta la deviazione X, senza dichiarare parità
XY. In Analysis dichiara l'ordinata ottica corretta e scegli solo opzioni fisiche
ammesse; se una rappresentazione non è supportata, il rifiuto è il risultato,
non trasformare k in absorbance cambiando un'etichetta. Un self-match della stessa
fonte è retrieval, non conferma indipendente del composto.

## Confronto riutilizzabile e persistenza

Apri il Viewer IR genuino installato o il client generico Non-IR Comparison Example,
entrambi consumatori del medesimo Comparison Plot pubblico. Scegli gli ID canonici
indicati sotto, X=`wavenumber`, Y=`signal`, e usa Compare → Add Dataset source per
ciascuna sorgente. In Method seleziona Overlay, normalization=none, offset=0,
denominator floor=0 e Compare → Prepare comparison. La tabella deve contenere due
sorgenti reali con unità e identità, non due etichette inventate. Ripeti Top/Bottom,
Stacked (offset esplicito), Difference (prima meno seconda) e Ratio (prima diviso
seconda), quando fisicamente ammessi. Dominio comune e interpolazione lineare
sono dichiarati dall'owner Numeric; non estrapolare fuori dalle misure. Minmax è
una trasformazione di display: non cambia i RAW e può nascondere differenze di
ampiezza. Una rappresentazione incompatibile o Ratio con normalizzazione non
ammessa deve rifiutare conservando il grafico valido precedente.

Con Top/Bottom prova pan e zoom X condivisi e Y indipendenti. Usa il menu primario
Plot: Fit, Zoom in/out, Pick display value/Clear cursor, Reverse X, Properties,
Legend e Series style. Il cursore descrive il display, non una riga canonica né
una sostanza. Copy plot usa PNG nella clipboard; Export PNG produce un'immagine,
non campioni scientifici. Salva una variante con nome riconoscibile, un Workspace
e la configurazione Session: sono tre confini distinti. Riapri in processo nuovo,
carica la variante offerta e controlla dati, unità, sorgenti, stile e annotazioni.

Esporta Current HTML con il normale modulo abilitato e il normale Session ZIP.
HTML è un rapporto navigabile, non un nuovo calcolo; copia e limiti dei dati binari
devono restare espliciti. Importa ZIP in una destinazione nuova e ripeti la lettura
canonica e un confronto. Non cambiare Manifest/Registry per riparare un errore.

## English summary

Reproduce the declared source, quantities and provenance through public owners.
Execute Analysis, native Comparison and cold/portable/export exercises separately;
initial generation is not chemical identification or completed GUI qualification.
