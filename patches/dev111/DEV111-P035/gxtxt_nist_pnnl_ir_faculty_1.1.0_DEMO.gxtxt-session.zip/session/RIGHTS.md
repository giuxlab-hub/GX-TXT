# Diritti e provenienza / Rights and provenance

I singoli record NIST Chemistry WebBook riportano Owner: Public domain
(verifica2026-10-31). Etanolo:
https://webbook.nist.gov/cgi/cbook.cgi?ID=C64175&Index=29&Type=IR-SPEC ; metanolo:
https://webbook.nist.gov/cgi/cbook.cgi?ID=C67561&Index=28&Type=IR-SPEC ;2-propanolo:
https://webbook.nist.gov/cgi/cbook.cgi?ID=C67630&Index=29&Type=IR-SPEC . Conservare
la citazione PNNL/IARPA2017 e gli header; il copyright della compilazione WebBook
è distinto da questi record. Non dichiarare l'intero sito GPL. Il codice e la
documentazione originali sono GPL-3.0-or-later. La derivazione legacy è dichiarata,
non cambia gli originali né il pacchetto Library1.0.0.
