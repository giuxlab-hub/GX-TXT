# Guida docente — NIST/PNNL: indice ottico k, griglia standard e replay storico

Gli originali sono costanti ottiche liquide PNNL/IARPA2017 (etanolo,
metanolo,2-propanolo): indice di dispersione n e indice di assorbimento k sono
quantità diverse. Questo laboratorio pubblica SOLO k; k non è assorbanza. Gli
originali n/k e i derivati k restano immutati in RAW con i checksum del pacchetto.
La Library pubblicata1.0.0 ha una griglia storica nominal-DELTAX, mentre il parser
JCAMP attuale usa FIRSTX/LASTX/NPOINTS. La differenza non è nascosta né corretta
riscrivendo Library o parser.

## Preparazione e valutazione

Installare i pacchetti pubblicati con i Manager normali in un profilo isolato;
nessuna copia di sicurezza del proprietario, vecchia Session o libreria di sistema
va modificata. Richiedere le capacità effettive (parser Spectrum, Publication v2,
HDF5, Plot v4, Comparison, Manager e Analysis IR per il replay); non fissare una
versione di Viewer/Analysis né simulare il loro chiamante. Una capacità assente è
un blocco esplicito, non autorizza scritture private. La generazione pubblica dati
e un Plot; da sola non prova Analysis, GUI, probabilità o identificazione.

Raccogliere oracle, tutte le righe, SHA RAW/canonici, schema, parametri e contesto.
Valutare la distinzione fra ordine dati e asse invertito, quantità fisica e unità,
valori canonici e trasformazioni del display, retrieval e identificazione. Le
attività indipendenti devono ripetere i test, non trasformare questo piano in una
ricevuta. Non dichiarare eseguiti tutti i68 generatori da un inventario di metadati.

## Oracle e limiti

Etanolo15347; metanolo15345;2-propanolo15345 campioni per ciascuna traccia.
Entrambe conservano tutti gli Y originali; legacy X coincide con FIRSTX+i*DELTAX
e con la Library storica entro1e-8. Standard X coincide con FIRSTX+i*(LASTX−FIRSTX)/(N−1).
Le deviazioni massime X standard-versus-Library osservate preliminarmente sono
2.356000004510861e-5,8.199999956559623e-5,1.1840000297524966e-5cm^-1 rispettivamente;
sono maggiori di1e-8 e DEVONO essere riportate. Nessun PASS XY standard/legacy.
Un oracle indipendente deve leggere gli header originali e verificare tutte le
righe; non usare Library→Library come prova circolare. Lineage standard→legacy,
HDF5 reale, schema stabile e identità k/unità1 devono sopravvivere a cold/ZIP.

## English summary

Assess full-source correctness, actual execution and explicit limitations. Keep
source publication, scientific replay and independent acceptance evidence distinct.
