# IR integrated source→Analysis→evidence report laboratory

Verificare sorgenti, quantità, provenienza e replay scientifico separato. La generazione non certifica identificazione o GUI.