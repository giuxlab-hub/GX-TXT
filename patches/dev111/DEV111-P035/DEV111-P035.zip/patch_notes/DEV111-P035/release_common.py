# SPDX-License-Identifier: GPL-3.0-or-later
"""P035 finite file-overlay guards. No runtime, Session or configuration owner."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, stat, tempfile, zipfile
from contextlib import contextmanager

PATCH = 'DEV111-P035'
ARCHIVE = PATCH + '.zip'
RELEASE_REVISION = 1
BASE = '7ae361d67c82f7fce44487a76927c36c846b78b1'
BASE_SHA = '12393a90c14ab511785763edcd114fc3c21587bc3323dfe32043b2b65509a48b'
NOTES = 'patch_notes/' + PATCH
MAX_FILE = 128 * 1024 * 1024
MAX_ZIP = 512 * 1024 * 1024

class GuardError(RuntimeError):
    pass

def require(test, message):
    if not test:
        raise GuardError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def relative(name):
    require(isinstance(name, str) and name and len(name) <= 4096 and '\\' not in name and ':' not in name and not any(ord(c) < 32 for c in name), 'Unsafe relative path')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(part not in ('', '.', '..') for part in name.split('/')), 'Unsafe relative path: ' + name)
    return p

SPECIAL = {'gxtxt_pipeline.tcl', 'VERSION.txt', 'PATCH_LEVEL.txt', 'GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'LICENSE'}
SKIP = {'tests', 'validation', 'evidence', 'review', 'archives', 'archive', '__pycache__', '.git', 'node_modules', 'scratch'}

# Reviewed framework-owned module IDs, including unchanged legacy descriptors
# lacking an explicit core flag. Ordinary core=0 modules have independent owners.
FRAMEWORK_MODULE_IDS = frozenset(['acq.audio', 'acq.generic_csv', 'acq.image_binary', 'acq.pdf_document', 'acq.sketch_dataset', 'acq.tektronix_current_log', 'acq.wav', 'acq.xas', 'analysis.audio_decode', 'analysis.cepstrum', 'analysis.definition_demo', 'analysis.envelope_spectrum', 'analysis.fft_spectrum', 'analysis.fractional_octave_spectrum', 'analysis.harmonic_analysis', 'analysis.octave_script', 'analysis.python_script', 'analysis.spectral_features', 'analysis.spectroscopy.ir', 'analysis.spectroscopy.uvvis', 'analysis.spectroscopy.uvvis_exploration', 'analysis.statistics.descriptive', 'analysis.statistics.grouped', 'analysis.time_dependent_fft', 'analysis.welch_spectrum', 'core.scientific_execution', 'curve.replicate_analysis', 'curvefit.family_global', 'dataset.extract', 'export.session_html', 'gxtxt.ir_identify', 'gxtxt.ir_waveform', 'math.electromagnetic_simulation', 'math.magnetics', 'math.numeric', 'math.rf_network', 'math.signal', 'model.spice_build_validate', 'plot.dataset', 'sequence.table_join', 'tool.script_module_builder', 'viewer.curve_digitizer', 'viewer.development_workspace', 'viewer.document_extractors', 'viewer.interface_builder', 'viewer.pdf_ocr', 'viewer.replicate_curve_analysis', 'viewer.signal_analysis', 'viewer.statistical_analysis', 'viewer.table_extractor'])
MANAGED_MODULES = frozenset({'library.spectroscopy.ir.reference', 'viewer.ir_spectroscopy', 'preview.curve_digitizer'})

def runtime_path(name):
    p = relative(name)
    # Normal Plugin Manager transactions own this mutable registry, including
    # CORE module bookkeeping. It is never a CORE payload or baseline guard.
    if p.parts[:2] == ('plugins', '.registry'):
        return False
    if p.parts[:2] == ('plugins', 'modules'):
        if len(p.parts)<4 or p.parts[2] not in FRAMEWORK_MODULE_IDS:
            return False
        if p.parts[2]=='viewer.curve_digitizer':
            return True  # unchanged accepted CORE-owned original; no new package
        if len(p.parts)==5 and p.parts[3]=='review' and p.parts[4] in ('build.json','validation.json'):
            return True
    if any(x.lower() in SKIP for x in p.parts) or name.lower().endswith(('.zip','.tar','.gz','.xz','.bz2','.7z','.pyc','.log')):
        return False
    return name in SPECIAL or name.startswith(('app/','core/','plugins/','docs/api/','services/','docs/development/dev111_p035/'))

MODULES = {'plot.dataset': '4.4.1', 'viewer.interface_builder': '1.2.13', 'analysis.spectroscopy.ir': '1.2.0', 'library.spectroscopy.ir.reference': '1.2.0', 'viewer.ir_spectroscopy': '1.0.1', 'preview.curve_digitizer': '0.1.12'}
ORIGINAL_MODULES = {'preview.curve_digitizer', 'viewer.ir_spectroscopy'}
GENERATORS = {'ir_library_explorer_lab':'1.0.0','ir_spectral_contracts_lab':'1.0.0','ir_viewer_integrated_study_lab':'1.0.0','refimp_full_training_ir':'1.1.0','nist_pnnl_ir_faculty':'1.1.0','org.giuxlab.gxtxt.ir_teaching_labs':'1.0.0'}

# Exact original owner containers; this metadata grants no functional test acceptance.
OWNER_MODULE = 'preview.curve_digitizer'
OWNER_QUALIFICATION = 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST'
OWNER_QUALIFICATIONS = {'preview.curve_digitizer': 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST'}
# No supplemental containers: original ZIPs are actual normal MODULES companions.
SUPPLIED_INPUT_ARCHIVES = {}
# Exact ordinary Builder1.0.1 original candidate. The identity is mechanical;
# final independent functional/GUI acceptance is still mandatory before deposit.
ORIGINAL_PACKAGE_SHA = {'preview.curve_digitizer': '57a0ae932bef79c64d597299581f7319ed30548bc0c2a7846bcace34c436c5b2', 'viewer.ir_spectroscopy': 'a6f3bd729e09c91a9dd2a458f2c5db475f48bedf84a240eb11684cadd45e0e37'}

def module_archive_name(module, version):
    if module=='preview.curve_digitizer':return 'preview.curve_digitizer_0.1.12_dev111_p032_REQUIRES_CORE_BRIDGE_022.zip'
    return module+'_'+version+'.zip'

BASE_ZIP = Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV111-P034.zip')
NOTE_FILES = {'FILES.json', 'BASELINE.json', 'BUILD_IDENTITY.json', 'MODULE_VERSION_MATRIX.json',
              'DELETIONS.json', 'MODULE_PAYLOADS.json', 'GENERATOR_PACKAGES.json', 'README.md', 'apply.py', 'rollback.py', 'release_common.py',
              'companion_preflight.py', 'PAYLOAD_SHA256SUMS', 'SUPPLIED_INPUTS.json'}

# Exact reviewed P035 product paths; extend explicitly after coherent source review.
PAYLOAD_SCOPE = frozenset(['core/tcl/scientific_recipe_history.tcl', 'core/tcl/project_experiment_management_v1.tcl', 'core/tcl/native2d_presentation_v1.tcl', 'docs/api/OBJECT_ORIGIN_API_v1.md', 'docs/api/NATIVE2D_AXIS_PRESENTATION_v1.md', 'GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'PATCH_LEVEL.txt', 'app/gui/dataset_preview_live.tcl', 'core/api_catalog/catalog.sqlite', 'core/api_catalog/source_manifest.json', 'core/development/policy_v1.json', 'core/development/sdk/gxtxt_viewer_sdk_v1.hpp', 'core/development/sdk/trusted_adapter_v1.cpp', 'core/python/gxtxt_viewer_development.py', 'core/python/gxtxt_viewer_native_worker.py', 'core/python/scientific_library_graph.py', 'core/python/scientific_library_manager.py', 'core/python/scientific_reference_bulk_match.py', 'core/python/scientific_reference_library.py', 'core/tcl/comparison_plot_api_v1.tcl', 'core/tcl/contract_visualizer_api_v1.tcl', 'core/tcl/dataset_preview_api_v1.tcl', 'core/tcl/dataset_preview_cache.tcl', 'core/tcl/dataset_preview_gui_v1.tcl', 'core/tcl/dataset_preview_worker_v1.tcl', 'core/tcl/plot_dataset_v2_bridge.tcl', 'core/tcl/scientific_library_browser_v1.tcl', 'core/tcl/scientific_library_manager_api_v1.tcl', 'core/tcl/scientific_reference_library_api_v1.tcl', 'core/tcl/scientific_spectrum_session_api_v1.tcl', 'core/tcl/session_generator_library_api_v1.tcl', 'core/tcl/ui_field_viewer_regions_v1.tcl', 'core/tcl/viewer_development_api_v1.tcl', 'core/tcl/viewer_development_request.tcl', 'core/tcl/viewer_gui_analysis_v1.tcl', 'core/tcl/viewer_gui_catalog_v1.tcl', 'core/tcl/viewer_gui_comparison_design_v1.tcl', 'core/tcl/viewer_gui_comparison_presentation_v1.tcl', 'core/tcl/viewer_gui_comparison_v1.tcl', 'core/tcl/viewer_gui_design_v1.tcl', 'core/tcl/viewer_gui_host_api_v1.tcl', 'core/tcl/workbench_extension_api_v1.tcl', 'core/tcl/workspace_scientific_codecs_v1.tcl', 'docs/api/COMPARISON_PLOT_API_v1.md', 'docs/api/CONTRACT_VISUALIZER_API_v1.md', 'docs/api/CPP_SUPPORT_CATALOG.md', 'docs/api/DATASET_PREVIEW_API_v1.md', 'docs/api/MODULE_TARGETED_ANALYSIS_API_v1.md', 'docs/api/PLOT_DATASET_OCTAVE_BRIDGE_v1.md', 'docs/api/PREVIEW_COMPONENT_GUI_API_v1.md', 'docs/api/SCIENTIFIC_LIBRARY_DOMAINS_API_v1.md', 'docs/api/SCIENTIFIC_REFERENCE_LIBRARY_API_v1.md', 'docs/api/SCIENTIFIC_SPECTRUM_SESSION_API_v1.md', 'docs/api/SCRIPT_BRIDGE_COVERAGE_v1.json', 'docs/api/UI_FIELD_API_v1.md', 'plugins/modules/analysis.spectroscopy.ir/CHANGELOG.md', 'plugins/modules/analysis.spectroscopy.ir/SHA256SUMS.txt', 'plugins/modules/analysis.spectroscopy.ir/module.ini', 'plugins/modules/analysis.spectroscopy.ir/plugin-package.ini', 'plugins/modules/analysis.spectroscopy.ir/runtime/analysis_spectroscopy_ir_main.m', 'plugins/modules/analysis.spectroscopy.ir/runtime/ir_pipeline.tcl', 'plugins/modules/plot.dataset/CHANGELOG.md', 'plugins/modules/plot.dataset/SHA256SUMS', 'plugins/modules/plot.dataset/SHA256SUMS.txt', 'plugins/modules/plot.dataset/api/plot_dataset_api_v4.tcl', 'plugins/modules/plot.dataset/module.ini', 'plugins/modules/plot.dataset/plugin-package.ini', 'plugins/modules/viewer.interface_builder/CHANGELOG.md', 'plugins/modules/viewer.interface_builder/SHA256SUMS.txt', 'plugins/modules/viewer.interface_builder/api/analysis_profiles.tcl', 'plugins/modules/viewer.interface_builder/api/builder.tcl', 'plugins/modules/viewer.interface_builder/module.ini', 'plugins/modules/viewer.interface_builder/plugin-package.ini'])

def payload_path(name):
    relative(name)
    return name in PAYLOAD_SCOPE

def root_path(root):
    root = Path(os.path.abspath(root))
    for p in [*reversed(root.parents), root]:
        require(not p.is_symlink(), 'Linked framework root/ancestor: ' + str(p))
    require(root.is_dir(), 'Existing canonical framework directory required')
    return root

def member(root, name):
    current = root
    parts = relative(name).parts
    for index, part in enumerate(parts):
        current = current / part
        require(not current.is_symlink(), 'Linked target/ancestor: ' + str(current))
        if current.exists() and index < len(parts)-1:
            require(current.is_dir(), 'Non-directory ancestor: ' + str(current))
    return current

def identity(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return None
    require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1, 'Nonregular/linked target: ' + str(path))
    return {'sha256': sha(path), 'mode': stat.S_IMODE(st.st_mode), 'size': st.st_size}

def matches(actual, expected):
    return actual == expected

def zip_index(z):
    entries = {}
    directories = set()
    for item in z.infolist():
        require(not item.flag_bits & 1, 'Encrypted ZIP unsupported')
        name = item.filename.rstrip('/') if item.is_dir() else item.filename
        relative(name)
        require(name not in entries and name not in directories, 'Duplicate ZIP member: ' + name)
        mode = item.external_attr >> 16
        if item.is_dir():
            require(stat.S_IFMT(mode) in (0, stat.S_IFDIR), 'Invalid ZIP directory')
            directories.add(name)
            continue
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG) and not stat.S_ISLNK(mode), 'Nonregular ZIP member: ' + name)
        require(item.file_size <= MAX_FILE, 'Oversized ZIP member: ' + name)
        entries[name] = item
    require(sum(x.file_size for x in entries.values()) <= MAX_ZIP, 'ZIP exceeds patch bound')
    for name in set(entries) | directories:
        require(all(str(p) not in entries for p in PurePosixPath(name).parents if str(p) != '.'), 'ZIP file/directory collision')
    require(z.testzip() is None, 'ZIP CRC failure')
    return entries

def file_record(value, nullable=False):
    if value is None:
        require(nullable, 'Required file identity is absent')
        return
    require(isinstance(value, dict) and set(value) == {'sha256', 'mode', 'size'}, 'Invalid file identity fields')
    require(isinstance(value['sha256'], str) and len(value['sha256']) == 64 and all(c in '0123456789abcdef' for c in value['sha256']), 'Invalid SHA256')
    require(type(value['mode']) is int and 0 <= value['mode'] <= 0o777, 'Invalid file mode')
    require(type(value['size']) is int and 0 <= value['size'] <= MAX_FILE, 'Invalid file size')

def validate(manifest, closure):
    require(isinstance(manifest, dict) and isinstance(closure, dict), 'Manifest/closure must be objects')
    require(manifest.get('schema') == 'gxtxt.dev111.p035.overlay.v1' and manifest.get('patch') == PATCH and manifest.get('baseline_patch') == 'DEV111-P034' and manifest.get('baseline_commit') == BASE and manifest.get('baseline_archive_sha256') == BASE_SHA, 'Wrong patch or exact P034 predecessor identity')
    require(isinstance(manifest.get('source_commit'), str) and len(manifest['source_commit']) == 40 and all(c in '0123456789abcdef' for c in manifest['source_commit']), 'Invalid source commit')
    require(closure.get('schema') == 'gxtxt.dev111.p035.baseline.v1' and closure.get('source_commit') == BASE and closure.get('archive_sha256') == BASE_SHA and isinstance(closure.get('files'), dict) and closure['files'], 'Invalid predecessor closure')
    require('core/tcl/plugin_install_api_v1.tcl' in closure['files'], 'Missing baseline sentinel')
    require(digest(json_bytes(closure)) == manifest.get('baseline_closure_sha256'), 'Baseline closure checksum differs')
    for name, expected in closure['files'].items():
        require(runtime_path(name), 'Non-runtime predecessor path: ' + name); file_record(expected)
    rows = manifest.get('changed_files')
    require(isinstance(rows, list) and rows, 'Nonempty change manifest required')
    seen = set()
    for row in rows:
        require(set(row) == {'path', 'action', 'before', 'after'}, 'Invalid change fields')
        name = row['path'];relative(name)
        require(payload_path(name), 'Protected/non-runtime payload path: ' + name)
        require(name not in seen and not name.startswith('patch_notes/'), 'Duplicate/reserved product path')
        seen.add(name);file_record(row['before'], True);file_record(row['after'], True)
        expected_action = 'add' if row['before'] is None else 'delete' if row['after'] is None else 'replace'
        require(row['action'] == expected_action and row['before'] != row['after'], 'Invalid or unchanged change action')
        require(closure['files'].get(name) == row['before'], 'Change preimage differs from exact baseline closure: ' + name)
    require(manifest.get('deleted_files') == [r['path'] for r in rows if r['after'] is None], 'Deletion list differs')
    return rows

def sums(text):
    result = {}
    for line in text.decode('utf-8').splitlines():
        value, name = line.split('  ', 1);relative(name)
        require(name not in result and len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'Invalid checksum entry')
        result[name] = value
    return result

def archive_data(path, expected_sha=None):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), 'Regular patch ZIP required')
    if expected_sha is None:
        sidecar = Path(str(path) + '.sha256')
        require(not sidecar.is_symlink() and sidecar.is_file(), 'Provide adjacent ZIP.sha256 or --sha256')
        words = sidecar.read_text().split()
        require(len(words) == 2 and words[1] == path.name, 'Invalid archive checksum sidecar')
        expected_sha = words[0]
    require(sha(path) == expected_sha, 'Patch ZIP SHA256 differs')
    with zipfile.ZipFile(path) as z:
        entries = zip_index(z)
        require(NOTES + '/FILES.json' in entries and NOTES + '/BASELINE.json' in entries, 'Missing P035 notes/closure')
        data = {name: z.read(name) for name in entries}
        manifest = json.loads(data[NOTES + '/FILES.json']);closure = json.loads(data[NOTES + '/BASELINE.json'])
        rows = validate(manifest, closure)
        required_notes = {NOTES + '/' + n for n in NOTE_FILES} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
        require({n for n in data if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected P035 notes')
        for name in required_notes:
            if not name.startswith(NOTES + '/rollback-preimages/'):
                require(((entries[name].external_attr >> 16) & 0o777) == 0o644, 'Wrong notes/helper mode: ' + name)
        build = json.loads(data[NOTES + '/BUILD_IDENTITY.json'])
        require(build.get('original_input_archives') == SUPPLIED_INPUT_ARCHIVES,
                'P035 external modules are separately bound normal companions')
        supplied = json.loads(data[NOTES + '/SUPPLIED_INPUTS.json'])
        require(supplied == {}, 'P035 must not duplicate inherited supplemental inputs')
        require(build.get('patch') == PATCH and build.get('source_commit') == manifest['source_commit']
                and build.get('packaging_helpers_commit') == manifest['source_commit']
                and build.get('baseline_commit') == BASE and build.get('baseline_archive_sha256') == BASE_SHA
                and build.get('native_changes') is False and build.get('packaging_rebuilt_binaries') is False
                and build.get('owner_supplied_qualifications') == OWNER_QUALIFICATIONS,
                'Build/source/helper identity differs')
        for leaf in ('apply.py', 'rollback.py', 'release_common.py', 'companion_preflight.py'):
            expected = build['helper_source_files']['validation/dev111_p035_release/' + leaf]
            file_record(expected)
            raw = data[NOTES + '/' + leaf]
            require(digest(raw) == expected['sha256'] and len(raw) == expected['size'], 'Bundled helper source identity differs: ' + leaf)
        matrix = json.loads(data[NOTES + '/MODULE_VERSION_MATRIX.json'])
        require(matrix.get('patch') == PATCH and len(matrix['modules']) == len(MODULES)
                and {m['module']: m['distribution_version'] for m in matrix['modules']} == MODULES,
                'P035 companion module matrix differs')
        payloads = json.loads(data[NOTES + '/MODULE_PAYLOADS.json'])
        require(payloads.get('patch') == PATCH and set(payloads.get('modules', {})) == set(MODULES),
                'Exact normal companion file identities required')
        for row in matrix['modules']:
            module = row['module']
            require(row.get('delivery_owner') == ('plugin_manager' if module in MANAGED_MODULES else 'framework_overlay'),
                    'Companion delivery owner differs')
            expected = payloads['modules'][module]
            require(isinstance(expected, dict) and expected and 'module.ini' in expected, 'Empty companion file closure')
            for leaf, record in expected.items():
                relative(leaf); file_record(record)
            prefix = 'plugins/modules/' + module + '/'
            if module in MANAGED_MODULES:
                require(not any(n.startswith(prefix) for n in closure['files'])
                        and not any(r['path'].startswith(prefix) for r in rows),
                        'Independently managed companion leaked into CORE ownership')
            else:
                host = dict(closure['files'])
                for changed in rows:
                    if changed['after'] is None:host.pop(changed['path'], None)
                    else:host[changed['path']] = changed['after']
                require(expected == {name[len(prefix):]: rec for name, rec in host.items() if name.startswith(prefix)},
                        'CORE companion differs from exact framework postimages')
            if module in ORIGINAL_MODULES:
                require(row.get('original_sha256') == ORIGINAL_PACKAGE_SHA[module]
                        and row.get('original_filename') == module_archive_name(module, MODULES[module]),
                        'Original companion container identity differs: ' + module)
                if module in OWNER_QUALIFICATIONS:
                    require(row.get('qualification') == OWNER_QUALIFICATIONS[module],
                            'Owner testing exception differs: ' + module)
        generators = json.loads(data[NOTES + '/GENERATOR_PACKAGES.json'])
        require(generators.get('patch')==PATCH and len(generators.get('packages',[]))==len(GENERATORS)
                and {row['id']:row['version'] for row in generators['packages']}==GENERATORS,
                'All five Generator originals and normal teaching Library are mandatory')
        for row in generators['packages']:
            require(set(row)=={'id','version','kind','filename','sha256','members'}
                    and row['kind']==('generator_library' if row['id'].startswith('org.') else 'generator'),
                    'Generator companion declaration differs')
            relative(row['filename']);require('/' not in row['filename'] and row['filename'].endswith('.zip'), 'Generator companion filename must be a ZIP basename')
            require(len(row['sha256'])==64 and all(c in '0123456789abcdef' for c in row['sha256']) and row['members'], 'Generator original SHA/closure absent')
            for leaf,rec in row['members'].items():relative(leaf);file_record(rec)
        require(json.loads(data[NOTES + '/DELETIONS.json']) == manifest['deleted_files'], 'Deletion notes differ')
        listed = sums(data[NOTES + '/PAYLOAD_SHA256SUMS'])
        require(set(listed) == set(data) - {NOTES + '/PAYLOAD_SHA256SUMS'}, 'Incomplete archive checksums')
        for name, expected in listed.items():
            require(digest(data[name]) == expected, 'Archive checksum differs: ' + name)
        products = {r['path'] for r in rows if r['after'] is not None}
        require(set(data) == products | {n for n in data if n.startswith(NOTES + '/')}, 'Unexpected product member')
        for row in rows:
            for key, name in [('after', row['path']), ('before', NOTES + '/rollback-preimages/' + row['path'])]:
                record = row[key]
                if record is None:
                    continue
                require(name in data and digest(data[name]) == record['sha256'] and len(data[name]) == record['size'] and ((entries[name].external_attr >> 16) & 0o777) == record['mode'], 'Invalid ' + key + ': ' + row['path'])
        return manifest, closure, rows, data, entries

def guard_baseline(root, closure, rows, rollback=False, partial=False):
    changed = {r['path']: r for r in rows}
    for name, expected in closure['files'].items():
        actual = identity(member(root, name));row = changed.get(name)
        if row is None or not rollback:
            require(matches(actual, expected), 'Divergent P034 baseline: ' + name)
    for row in rows:
        actual = identity(member(root, row['path']))
        wanted = row['after'] if rollback else row['before']
        permitted = [wanted, row['before']] if rollback and partial else [wanted]
        require(any(matches(actual, p) for p in permitted), 'Unknown/divergent ' + ('postimage' if rollback else 'preimage') + ': ' + row['path'])

def atomic(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.p035-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data);f.flush();os.fchmod(f.fileno(), mode);os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):os.unlink(temp)

def _apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    manifest, closure, rows, data, entries = archive_data(archive, expected_sha)
    require(not member(root, NOTES).exists(), 'P035 notes already exist; use rollback/recover-partial first')
    guard_baseline(root, closure, rows)
    for name in data:member(root, name)
    if mutate:
        # Publish complete verified rollback information before any product write.
        for name in sorted(data):
            if name.startswith(NOTES + '/'):
                atomic(member(root, name), data[name], (entries[name].external_attr >> 16) & 0o777)
        for row in rows:
            p = member(root, row['path'])
            require(identity(p) == row['before'], 'Preimage changed during apply: ' + row['path'])
            if row['after'] is None:p.unlink()
            else:atomic(p, data[row['path']], row['after']['mode'])
        guard_baseline(root, closure, rows, rollback=True)
    return manifest

def _rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root);notes = member(root, NOTES)
    require(notes.is_dir(), 'Installed P035 notes required')
    manifest_path = member(root, NOTES + '/FILES.json');closure_path = member(root, NOTES + '/BASELINE.json')
    require(identity(manifest_path) is not None and identity(closure_path) is not None, 'Incomplete notes; recover verified notes from the exact archive first')
    manifest = json.loads(manifest_path.read_bytes());closure = json.loads(closure_path.read_bytes());rows = validate(manifest, closure)
    checksum_path = member(root, NOTES + '/PAYLOAD_SHA256SUMS')
    checksum_identity = identity(checksum_path)
    require(checksum_identity is not None and checksum_identity['mode'] == 0o644,
            'Installed checksum manifest must be an unlinked regular0644 file')
    listed = sums(checksum_path.read_bytes())
    required_notes = {NOTES + '/' + n for n in NOTE_FILES - {'PAYLOAD_SHA256SUMS'}} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
    require({n for n in listed if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected installed notes inventory')
    for name, expected in listed.items():
        if name.startswith(NOTES + '/'):
            p = member(root, name)
            require(identity(p) is not None and sha(p) == expected, 'Incomplete/divergent installed notes: ' + name)
            expected_mode = 0o644
            if name.startswith(NOTES + '/rollback-preimages/'):
                product = name[len(NOTES + '/rollback-preimages/'):]
                expected_mode = next(r['before']['mode'] for r in rows if r['path'] == product and r['before'] is not None)
            require(identity(p)['mode'] == expected_mode, 'Installed notes mode differs: ' + name)
    require(NOTES + '/FILES.json' in listed and NOTES + '/BASELINE.json' in listed, 'Unbound installed manifest')
    matrix = json.loads(member(root, NOTES + '/MODULE_VERSION_MATRIX.json').read_bytes())
    require(matrix.get('patch') == PATCH, 'Wrong rollback companion matrix')
    # Admission/API dependencies must be removed/reverted by their normal owner
    # before removing the CORE APIs. Never overwrite files or restore a registry.
    import configparser
    for row in matrix['modules']:
        if row['module'] not in MANAGED_MODULES:continue
        descriptor = member(root, 'plugins/modules/' + row['module'] + '/module.ini')
        if identity(descriptor) is None:continue
        parser = configparser.ConfigParser(interpolation=None, strict=True)
        parser.read_string(descriptor.read_text())
        require(parser.get('meta', 'id') == row['module']
                and parser.get('meta', 'version') == row['previous_distribution_version'],
                'Before CORE rollback, normally remove/revert API-dependent companion: ' + row['module'])
    guard_baseline(root, closure, rows, rollback=True, partial=partial)
    for row in rows:
        if row['before'] is not None:
            p = member(root, NOTES + '/rollback-preimages/' + row['path'])
            require(identity(p) == row['before'], 'Rollback preimage/mode differs: ' + row['path'])
    if mutate:
        for row in reversed(rows):
            p = member(root, row['path']);actual = identity(p)
            require(actual == row['after'] or partial and actual == row['before'], 'Target changed during rollback: ' + row['path'])
            if actual == row['before']:continue
            if row['before'] is None:p.unlink()
            else:
                backup = member(root, NOTES + '/rollback-preimages/' + row['path'])
                atomic(p, backup.read_bytes(), row['before']['mode'])
        guard_baseline(root, closure, rows)
    return manifest

@contextmanager
def operation_lock(root, enabled):
    if not enabled:
        yield
        return
    try:
        import fcntl
    except ImportError as error:
        raise GuardError('Guarded writes require POSIX directory locking; --check remains available') from error
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        try:fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:raise GuardError('Another release helper owns this framework directory') from error
        yield
    finally:os.close(fd)

def apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    with operation_lock(root, mutate):return _apply_overlay(root, archive, mutate, expected_sha)

def rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root)
    with operation_lock(root, mutate):return _rollback_overlay(root, mutate, partial)
