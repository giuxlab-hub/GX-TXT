# DEV111-P035: genuine IR Viewer, teaching generators and CORE Cache Bridge022

Exact accepted baseline P034 source `7ae361d67c82f7fce44487a76927c36c846b78b1`, ZIP SHA256 `12393a90c14ab511785763edcd114fc3c21587bc3323dfe32043b2b65509a48b`.
Candidate source `ce34988db2c7500b60f7235b237b2fdb67e5d434`. Final independent A+B receipts are mandatory.
This CORE overlay contains only reviewed framework-owned files and CORE modules.
It does not raw-overlay or lock independently managed non-CORE modules, their
registry, user configuration, Sessions/RAW or installed module update history.

Stop GX-TXT and its workers; --stopped is the operator's assertion, not a process
detector. Extract only patch_notes/DEV111-P035 to a separate review directory:

    python3 review/patch_notes/DEV111-P035/apply.py FRAMEWORK DEV111-P035.zip --check
    python3 review/patch_notes/DEV111-P035/apply.py FRAMEWORK DEV111-P035.zip --apply --stopped
    python3 FRAMEWORK/patch_notes/DEV111-P035/companion_preflight.py FRAMEWORK DEV111-P035.zip

Only after exact CORE postimage preflight, install/update the delivered external
modules through ordinary Plugin Manager: IR Library provider, genuine compiled
IR Viewer, then the original Preview0.1.12 (requires Cache Bridge022). Follow
normal Manager restart-required indications; never force a source/runtime reload. Their full
file identities are bound in MODULE_PAYLOADS.json and versions/delivery owners
in MODULE_VERSION_MATRIX.json. Preview stays visible, updateable, disableable
and removable independently of future CORE releases. Never install012 on old
CORE; never treat an unregistered same-version raw overlay as managed install.
Viewer2.0.26 remains unchanged, inherited from accepted P034.

Exact original Preview container:
preview.curve_digitizer_0.1.12_dev111_p032_REQUIRES_CORE_BRIDGE_022.zip
SHA25657a0ae932bef79c64d597299581f7319ed30548bc0c2a7846bcace34c436c5b2
Qualification OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST.
Only focused NEW CORE/integration validation is authorized; existing module
scientific/functional/GUI suites were not repeated. No owner ZIP was rebuilt.

Install the separately delivered normal IR teaching Generator Library through its
normal Generator Library owner; select its five versioned generators explicitly.
Existing accepted/custom/disabled collections remain unchanged; no in-place
Library Update API or silent source-library overwrite is claimed.

Before CORE rollback, normally remove/revert the new API-dependent external
companions through Plugin Manager. Rollback refuses their newer installed
versions; it never restores the registry or overwrites independent modules.

    python3 FRAMEWORK/patch_notes/DEV111-P035/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P035/rollback.py FRAMEWORK --rollback --stopped

Exact known CORE preimages/modes are restored, only declared additions removed;
extras/notes/independent module state remain. Per-file atomic replacement is not
a whole-root transaction. Unknown source/modes/collisions refuse. Canonical
release deposition does not activate or modify the owner's installation.
