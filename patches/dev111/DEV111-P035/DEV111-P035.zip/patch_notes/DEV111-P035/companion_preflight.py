# SPDX-License-Identifier: GPL-3.0-or-later
"""Read-only exact CORE Bridge admission before ordinary Manager companions."""
from pathlib import Path
import argparse,json,sys,zipfile
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent))
from release_common import GuardError,NOTES,MANAGED_MODULES,archive_data,guard_baseline,root_path,sha

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('framework',type=Path);p.add_argument('archive',type=Path)
 p.add_argument('--sha256',help='Externally verified P035 ZIP SHA256, otherwise adjacent sidecar')
 a=p.parse_args();root=root_path(a.framework)
 manifest,closure,rows,data,entries=archive_data(a.archive,a.sha256)
 guard_baseline(root,closure,rows,rollback=True)
 matrix=json.loads(data[NOTES+'/MODULE_VERSION_MATRIX.json'])
 print(json.dumps(dict(status='PASS_EXACT_CORE_POSTIMAGES',source_commit=manifest['source_commit'],archive_sha256=sha(a.archive),
  module_action='Install/update independent companions through normal Plugin Manager only',
  plugin_manager_companions=[row for row in matrix['modules'] if row['module'] in MANAGED_MODULES],
  order=['CORE overlay verified','normal IR Library provider','normal genuine IR Viewer','original Preview012'],
  registry_modified=False,installed=False,activated=False),indent=2))
if __name__=='__main__':
 try:main()
 except (GuardError,OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as e:raise SystemExit('REFUSED: '+str(e))
