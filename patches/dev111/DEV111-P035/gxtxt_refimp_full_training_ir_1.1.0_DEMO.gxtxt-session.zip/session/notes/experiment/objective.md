# RefIMP full9537 source-equivalent retrieval and evidence study

Verificare sorgenti, quantità, provenienza e replay scientifico separato. La generazione non certifica identificazione o GUI.