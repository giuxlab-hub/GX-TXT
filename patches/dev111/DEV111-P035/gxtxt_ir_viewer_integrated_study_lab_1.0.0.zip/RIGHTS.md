# Diritti e provenienza / Rights and provenance


I dati RefIMP appartengono a Weisser, Jana e Pohl, Teresa (2022), RefIMP
transmission micro-FTIR dataset, TUM mediaTUM1656656:
https://mediatum.ub.tum.de/1656656 . Provenienza e pacchetto pubblicato dichiarano
CC-BY-SA-4.0: conservare attribuzione, licenza e indicazione delle conversioni.
Il sito ha risposto HTTP429 alla verifica del2026-10-31; non è una nuova verifica
live del contenuto remoto. Il CSV ItemID13 ha SHA256
7fd1363d540fb6cccbf1543ad715e219fe672e0036b3b205e58d21a2437fa54b,
637 coppie invariate. Il Manager risolve ItemID13/14 dalla provenienza effettiva,
non dal nome del file. HDF5 è un output esplicito nuovo, non una modifica della
Library. GPL-3.0-or-later riguarda codice/documenti originali, non riassegna i dati.
