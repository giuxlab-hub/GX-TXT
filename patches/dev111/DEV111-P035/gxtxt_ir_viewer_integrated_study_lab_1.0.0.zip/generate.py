#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
import sys
sys.dont_write_bytecode=True
from ir_lab_generator import main
if __name__=="__main__":main()
