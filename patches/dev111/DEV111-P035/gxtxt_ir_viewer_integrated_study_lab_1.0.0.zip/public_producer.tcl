# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted installed Generator bootstrap; only documented public CORE owners.
lassign $argv framework session package
set argv0 __gxtxt_ir_public_generator__
package require Tk
wm withdraw .
source [file join $framework gxtxt_pipeline.tcl]
::GX::defaults
::GX::configurationLoad
::GX::loadModuleCatalog
::GX::openSessionPath $session
proc readUtf8 {path} {set c [open $path r];fconfigure $c -encoding utf-8;try {return [read $c]} finally {close $c}}
set plan [::GX::nativeWorkspaceDecode [::GX::nativeWorkspaceJsonDecode [readUtf8 [file join $package LAB_PLAN.json]]]]
foreach library [dict get $plan required_libraries] {
    if {[catch {set info [::GX::ScientificLibraryManagerAPIv1::getLibraryInfo $library]} problem] || [dict get $info state] ne {installed} || [dict get $info availability] ne {available}} {error "BLOCKED_LIBRARY_REQUIRED $library: install the reviewed published package through Scientific Library Manager before generation"}
}
proc libraryItem {library item} {
    set options [dict create limit 200]
    for {set pageNo 0} {$pageNo<64} {incr pageNo} {
        set page [::GX::ScientificLibraryManagerAPIv1::libraryEntriesPage $library $options]
        foreach record [dict get $page records] {
            if {[dict exists $record provenance source_item_id] && [dict get $record provenance source_item_id] eq $item} {return [dict get $record entry_id]}
        }
        if {![dict exists $page continuation] || [dict get $page continuation] eq {}} break
        dict set options continuation [dict get $page continuation]
    }
    error "Required source ItemID $item is not in actual managed Library $library"
}
proc libraryValue {library entry} {
    set before [::GX::ScientificLibraryManagerAPIv1::getLibraryInfo $library]
    set info [::GX::ScientificLibraryManagerAPIv1::getLibraryEntryInfo $library $entry]
    set value [dict get $info metadata spectrum];set n [dict get $value sample_count]
    if {$n<2 || $n>65536} {error {Library lab supports 2..65536 exact samples}}
    set xs {};set ys {}
    for {set start 0} {$start<$n} {incr start 32768} {
        set take [expr {min(32768,$n-$start)}]
        set r [::GX::ScientificLibraryManagerAPIv1::readLibraryEntry $library $entry [dict create provider_json [format {{"start":%d,"count":%d}} $start $take]]]
        if {[llength [dict get $r payload x]]!=$take || [llength [dict get $r payload y]]!=$take} {error {Library source window was truncated}}
        lappend xs {*}[dict get $r payload x];lappend ys {*}[dict get $r payload y]
    }
    if {[dict get [::GX::ScientificLibraryManagerAPIv1::getLibraryInfo $library] payload_sha256] ne [dict get $before payload_sha256]} {error {Library changed during source read}}
    dict set value x $xs;dict set value y $ys
    dict set value metadata [dict get $info metadata entry]
    dict set value provenance [dict merge [dict get $info provenance] [dict create source_library_id $library source_entry_id $entry source_library_payload_sha256 [dict get $before payload_sha256] original_source_identity [dict get $value source_identity]]]
    dict set value source_identity "gxtxt-library:$library#$entry@[dict get $before payload_sha256]"
    return $value
}
if {[dict exists $plan expected_library_populations]} {
    dict for {library expected} [dict get $plan expected_library_populations] {
        if {[llength [::GX::ScientificLibraryManagerAPIv1::listLibraryEntries $library]]!=$expected} {error "Actual managed Library population differs: $library"}
    }
}
set inputs {}
foreach input [dict get $plan inputs] {
    set kind [dict get $input kind]
    if {$kind in {csv jcamp}} {
        set relative [dict get $input raw_path]
        if {[file pathtype $relative] ne {relative} || {..} in [file split $relative]} {error {Generator RAW path must stay within its target Session}}
        set path [file join $session raw $relative];set sha [::GX::sha256File $path]
        set options [dict get $input parser_options]
        dict set options source_identity "raw/$relative"
        set spectrum [::GX::SpectrumImportAPIv1::parse $kind $path $options]
        if {[dict get $spectrum source_hash] ne $sha || [::GX::sha256File $path] ne $sha} {error {Generator source changed during public parse}}
        set provenance [dict merge [dict get $spectrum provenance] [dict get $input provenance]]
    } elseif {$kind eq {library}} {
        set library [dict get $input library_id]
        if {[dict exists $input source_item_id]} {set entry [libraryItem $library [dict get $input source_item_id]]} else {set entry [dict get $input entry_id]}
        set spectrum [libraryValue $library $entry]
        set provenance [dict merge [dict get $spectrum provenance] [dict get $input provenance]]
    } else {error {Unsupported declared Generator scientific input}}
    if {[dict exists $input axis_policy] && [dict get $input axis_policy] eq {legacy_nominal_deltax}} {
        set metadata [dict get $spectrum metadata]
        foreach key {jcamp.firstx jcamp.lastx jcamp.deltax jcamp.npoints} {if {![dict exists $metadata $key]} {error {Historical grid replay needs original public parser headers}}}
        set first [dict get $metadata jcamp.firstx];set step [dict get $metadata jcamp.deltax];set n [dict get $spectrum sample_count];set xs {}
        for {set i 0} {$i<$n} {incr i} {lappend xs [expr {double($first)+$i*double($step)}]}
        dict set provenance standard_parser_spectrum_hash [dict get $spectrum spectrum_hash]
        dict set provenance coordinate_grid_policy legacy_nominal_deltax
        dict set provenance coordinate_grid_derivation {FIRSTX+i*nominalDELTAX; explicit historical replay, not current JCAMP decoding}
        dict set provenance standard_grid_last_x [lindex [dict get $spectrum x] end]
        dict set spectrum metadata teaching.coordinate_grid_policy legacy_nominal_deltax
        dict set spectrum x $xs;dict set spectrum provenance $provenance
        set spectrum [::GX::SpectrumAPIv1::create $spectrum]
    } else {
        dict set provenance coordinate_grid_policy [expr {[dict exists $spectrum metadata jcamp.grid_policy]?[dict get $spectrum metadata jcamp.grid_policy]:{explicit_source_samples}}]
    }
    if {[dict get $spectrum sample_count] != [dict get $input expected_count]} {error {Source count differs from declared independent oracle}}
    if {[dict exists $input matching_library_id]} {
        set library [dict get $input matching_library_id]
        if {[dict exists $input matching_source_item_id]} {set entry [libraryItem $library [dict get $input matching_source_item_id]]} else {set entry [dict get $input matching_entry_id]}
        set reference [libraryValue $library $entry]
        if {[dict get $reference sample_count] != [dict get $spectrum sample_count]} {error {Source and declared managed reference counts differ}}
        set policy [expr {[dict exists $input reference_match_policy]?[dict get $input reference_match_policy]:{exact}}]
        if {$policy ni {exact y_exact_report_axis_difference}} {error {Unsupported declared reference check}}
        foreach field {x y} {
            set maximum 0.0
            foreach a [dict get $spectrum $field] b [dict get $reference $field] {set maximum [expr {max($maximum,abs(double($a)-double($b)))}]}
            dict set provenance reference_max_abs_$field $maximum
            if {($field eq {y} || $policy eq {exact}) && $maximum>1e-8} {error {All-sample source/reference parity refused}}
        }
        dict set provenance verified_library_id $library
        dict set provenance verified_entry_id $entry
        dict set provenance verified_library_payload_sha256 [dict get $reference provenance source_library_payload_sha256]
        dict set provenance verified_spectrum_hash [dict get $reference spectrum_hash]
        dict set provenance source_reference_check [expr {$policy eq {exact}?{all_samples_absolute_tolerance_1e-8}:{y_within_1e-8_x_deviation_explicitly_reported}}]
    }
    set item {}
    foreach key {dataset_id storage expected_count classification description} {dict set item $key [dict get $input $key]}
    foreach key {x y spectrum_kind x_quantity y_quantity x_unit y_unit y_representation source_identity source_hash spectrum_hash} {dict set item $key [dict get $spectrum $key]}
    dict set item provenance $provenance
    dict set item source_metadata [dict get $spectrum metadata]
    dict set item publication_phase [expr {[dict exists $input publication_phase]?[dict get $input publication_phase]:0}]
    dict set item source_dataset_ids [expr {[dict exists $input source_dataset_ids]?[dict get $input source_dataset_ids]:{}}]
    lappend inputs $item
}
set value [dict create generator_id [dict get $plan generator_id] version [dict get $plan version] title [dict get $plan title] inputs $inputs]
set inputShape {record {dataset_id text storage text expected_count int classification text description text x {array real} y {array real} spectrum_kind text x_quantity text y_quantity text x_unit text y_unit text y_representation text source_identity text source_hash text spectrum_hash text provenance {map text} source_metadata {map text} publication_phase int source_dataset_ids {array text}}}
set typed [::GX::nativeWorkspaceEncode [list record [dict create generator_id text version text title text inputs [list array $inputShape]]] $value]
set json [::GX::nativeWorkspaceJsonEncode $typed]
set code [readUtf8 [file join $package ir_lab_session.py]]
append code "\nproduce(json.loads(" [::GX::nativeWorkspaceJsonEncode [list text $json]] "))\n"
if {[string bytelength $code]>4194304} {error {Registered lab producer exceeds 4 MiB source budget}}
set id "ir_lab_[dict get $plan generator_id]"
::GX::scriptRegistrySave session $id [dict get $plan title] $code [dict create language Python version [dict get $plan version] required_apis {DATASET_PUBLICATION_API_v2;PLOT_DATASET_API_v4} description {Reviewed lab source through public Spectrum/Manager and Publication owners; no independent identification}]
set result [::GX::scriptExecutionRun session:$id {}]
# The Script Bridge committed the graph in its own normal Host. Reopen through
# the public Session owner before committing current notebook/configuration.
::GX::openSessionPath $session
::GX::experimentDocumentSave experiment_objective "# [dict get $plan title]\n\nVerificare sorgenti, quantità, provenienza e replay scientifico separato. La generazione non certifica identificazione o GUI." $session
::GX::experimentDocumentSave experiment_procedure [readUtf8 [file join $package STUDENT_GUIDE.md]] $session
::GX::experimentDocumentSave experiment_notes [readUtf8 [file join $package RIGHTS.md]] $session
::GX::experimentDocumentSave experiment_observations {# Registro delle osservazioni

Pubblicazione iniziale completata tramite owner pubblici. Analysis e prove GUI non ancora eseguite da questa azione. Annotare qui parametri, risultati effettivi e limiti dopo il replay.} $session
::GX::sessionPersistenceCommit
puts [list status GENERATED_PUBLIC_DATASETS script_result $result generator_id [dict get $plan generator_id]]
exit 0
