# Guida docente — Studio IR integrato: sorgente, Analysis e rapporto riproducibile

Questo è un esperimento completo con l'estratto reale RefIMP ItemID13,
637 coppie di trasmissione relativa e numero d'onda cm^-1. Generate pubblica
`ir.integrated.query` dal CSV immutato e `ir.integrated.reference14` da un'esplicita
lettura Manager della voce training ItemID14. La Library training reale ha9537
voci. È un controllo di retrieval dipendente dalla fonte, non un'identificazione
indipendente. Il generatore non fabbrica risultati Analysis o immagini di GUI.

## Preparazione e valutazione

Installare i pacchetti pubblicati con i Manager normali in un profilo isolato;
nessuna copia di sicurezza del proprietario, vecchia Session o libreria di sistema
va modificata. Richiedere le capacità effettive (parser Spectrum, Publication v2,
HDF5, Plot v4, Comparison, Manager e Analysis IR per il replay); non fissare una
versione di Viewer/Analysis né simulare il loro chiamante. Una capacità assente è
un blocco esplicito, non autorizza scritture private. La generazione pubblica dati
e un Plot; da sola non prova Analysis, GUI, probabilità o identificazione.

Raccogliere oracle, tutte le righe, SHA RAW/canonici, schema, parametri e contesto.
Valutare la distinzione fra ordine dati e asse invertito, quantità fisica e unità,
valori canonici e trasformazioni del display, retrieval e identificazione. Le
attività indipendenti devono ripetere i test, non trasformare questo piano in una
ricevuta. Non dichiarare eseguiti tutti i68 generatori da un inventario di metadati.

## Oracle e limiti

Due Dataset iniziali reali637righe, HDF5 float64/schema v3, coordinata
cm^-1/trasmissione relativa unità1 e tutti gli X/Y identici ai rispettivi oracle
CSV/Manager entro1e-8. Analysis iniziale NOT_RUN: il completamento del laboratorio
richiede veri Job e prodotti; nessun rank/peak viene inserito staticamente.
La baseline storica di ItemID13/top score circa1 è retrieval della stessa fonte,
non un'etichetta chimica valida per un campione ignoto. Il report finale deve
riportare parametri, Library payload, source/canonical SHA e limiti, non un PASS
copiato da questo documento.

## English summary

Assess full-source correctness, actual execution and explicit limitations. Keep
source publication, scientific replay and independent acceptance evidence distinct.
