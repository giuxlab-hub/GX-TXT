# Piano di test — ir_viewer_integrated_study_lab


## Confini obbligatori di verifica

- Import/Export normale del generatore: ID/versione, tutti i checksum, nessuna
  esecuzione nascosta durante l'import e nessun modulo Viewer incorporato.
- Generate in una Session nuova: solo parser/Manager e Script Bridge Publication
  v2; veri payload HDF5, schema v3, ruoli/coordinate/unità e hash/provenienza.
  Un prerequisito mancante rifiuta senza una Session completata fittizia.
- Lettura integrale con API canoniche e oracle indipendente; le prime righe o una
  curva plausibile non bastano. Ripeti in processo nuovo e seconda Session nuova.
- Esecuzione reale della guida nativa con due Dataset, cinque modalità quando
  ammesse e tredici comandi Plot; errore e revoca mantengono l'ultimo frame valido.
- Salvataggio Variant/Workspace/configurazione Session, History e cold reopen;
  portable ZIP in destinazione nuova, Current HTML/ZIP e grafici realmente aperti.
- Analysis reale separata dalla pubblicazione: attendere il Job e leggere tutti i
  prodotti/report. Annotare conti, parametri, sorgenti e limiti dei candidati.
- Distinguere ricevute di generazione, regressione scientifica, GUI, cold/portable
  e accettazione indipendente. Questo documento specifica test, non dichiara PASS.

## Oracle specifico

Due Dataset iniziali reali637righe, HDF5 float64/schema v3, coordinata
cm^-1/trasmissione relativa unità1 e tutti gli X/Y identici ai rispettivi oracle
CSV/Manager entro1e-8. Analysis iniziale NOT_RUN: il completamento del laboratorio
richiede veri Job e prodotti; nessun rank/peak viene inserito staticamente.
La baseline storica di ItemID13/top score circa1 è retrieval della stessa fonte,
non un'etichetta chimica valida per un campione ignoto. Il report finale deve
riportare parametri, Library payload, source/canonical SHA e limiti, non un PASS
copiato da questo documento.

English: record actual outcomes and retained failures; do not infer execution
from successful staging, metadata inventories or source code.
