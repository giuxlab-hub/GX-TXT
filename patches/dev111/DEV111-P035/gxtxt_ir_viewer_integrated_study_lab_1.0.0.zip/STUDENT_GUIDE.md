# Studio IR integrato: sorgente, Analysis e rapporto riproducibile

Questo è un esperimento completo con l'estratto reale RefIMP ItemID13,
637 coppie di trasmissione relativa e numero d'onda cm^-1. Generate pubblica
`ir.integrated.query` dal CSV immutato e `ir.integrated.reference14` da un'esplicita
lettura Manager della voce training ItemID14. La Library training reale ha9537
voci. È un controllo di retrieval dipendente dalla fonte, non un'identificazione
indipendente. Il generatore non fabbrica risultati Analysis o immagini di GUI.

## Avvio

Importa il normale pacchetto del generatore nel Manager, poi New Session → Generate
Session e scegli `ir_viewer_integrated_study_lab` versione1.0.0 con un nome nuovo. Leggi RIGHTS
prima di redistribuire. Controlla queste identità effettive:

- `ir.integrated.query`: 637 campioni, hdf5, RefIMP2022 genuine ItemID13 source-equivalent retrieval fixture; not independent polymer identification
- `ir.integrated.reference14`: 637 campioni, hdf5, Explicit Generate action copies reviewed RefIMP training ItemID14 through public read/Publication; ordinary Browser selection never publishes

## Dal query al rapporto

Ispeziona RAW, Variables, Source e SHA del query. Nel Viewer IR genuino scegli
l'Analysis IR effettivamente disponibile e la Library training; annota tutti i
parametri e attendi il normale Job fino al risultato. Riproduci la configurazione
storica (none baseline/smoothing, derivata0, resample4cm^-1, cosine,
mean_center_unit_vector, fingerprint1300..1800 peso0.35) solo se supportata e
fisicamente coerente con la rappresentazione. Apri processed spectrum, peaks,
rank e report; controlla che il dato derivato abbia lineage verso query e source.
Distingui9537 voci del corpus dal limite dei candidati stampati nel report.

Confronta query e reference14 nei cinque modi comuni; aggiungi il processed
spectrum come terza sorgente soltanto se unità/quantità effettive sono compatibili.
Nel quaderno scrivi obiettivo, procedura, osservazioni e conclusione con limiti:
origine condivisa, preprocessing, numero di candidati, score non probabilistico.
Produci grafici con titoli/unità/legenda e annotazione propria, una variante e un
Workspace. Dopo cold reopen verifica query, risultati, report e annotazione;
esporta Session ZIP e Current HTML e ripeti dal portabile in nuova destinazione.

## Confronto riutilizzabile e persistenza

Apri il Viewer IR genuino installato o il client generico Non-IR Comparison Example,
entrambi consumatori del medesimo Comparison Plot pubblico. Scegli gli ID canonici
indicati sotto, X=`wavenumber`, Y=`signal`, e usa Compare → Add Dataset source per
ciascuna sorgente. In Method seleziona Overlay, normalization=none, offset=0,
denominator floor=0 e Compare → Prepare comparison. La tabella deve contenere due
sorgenti reali con unità e identità, non due etichette inventate. Ripeti Top/Bottom,
Stacked (offset esplicito), Difference (prima meno seconda) e Ratio (prima diviso
seconda), quando fisicamente ammessi. Dominio comune e interpolazione lineare
sono dichiarati dall'owner Numeric; non estrapolare fuori dalle misure. Minmax è
una trasformazione di display: non cambia i RAW e può nascondere differenze di
ampiezza. Una rappresentazione incompatibile o Ratio con normalizzazione non
ammessa deve rifiutare conservando il grafico valido precedente.

Con Top/Bottom prova pan e zoom X condivisi e Y indipendenti. Usa il menu primario
Plot: Fit, Zoom in/out, Pick display value/Clear cursor, Reverse X, Properties,
Legend e Series style. Il cursore descrive il display, non una riga canonica né
una sostanza. Copy plot usa PNG nella clipboard; Export PNG produce un'immagine,
non campioni scientifici. Salva una variante con nome riconoscibile, un Workspace
e la configurazione Session: sono tre confini distinti. Riapri in processo nuovo,
carica la variante offerta e controlla dati, unità, sorgenti, stile e annotazioni.

Esporta Current HTML con il normale modulo abilitato e il normale Session ZIP.
HTML è un rapporto navigabile, non un nuovo calcolo; copia e limiti dei dati binari
devono restare espliciti. Importa ZIP in una destinazione nuova e ripeti la lettura
canonica e un confronto. Non cambiare Manifest/Registry per riparare un errore.

## English summary

Reproduce the declared source, quantities and provenance through public owners.
Execute Analysis, native Comparison and cold/portable/export exercises separately;
initial generation is not chemical identification or completed GUI qualification.
