# Studio IR integrato: sorgente, Analysis e rapporto riproducibile

Generator ID `ir_viewer_integrated_study_lab`, versione1.0.0.

Questo è un esperimento completo con l'estratto reale RefIMP ItemID13,
637 coppie di trasmissione relativa e numero d'onda cm^-1. Generate pubblica
`ir.integrated.query` dal CSV immutato e `ir.integrated.reference14` da un'esplicita
lettura Manager della voce training ItemID14. La Library training reale ha9537
voci. È un controllo di retrieval dipendente dalla fonte, non un'identificazione
indipendente. Il generatore non fabbrica risultati Analysis o immagini di GUI.

Leggi STUDENT_GUIDE, FACULTY_GUIDE, EXPECTED_RESULTS, TEST_PLAN e RIGHTS.
Codice originale GPL-3.0-or-later; dati esterni con diritti propri. Il generatore
usa parser/Manager pubblici e Script Bridge Publication v2, non un Registry o
writer HDF5 privato. Richiede capacità effettive, non versioni esatte dei moduli.
Generate non esegue implicitamente Analysis né certifica GUI/portable/HTML.

English: independently installable teaching generator with explicit source and
scientific provenance; execute the full documented workflow after generation.
