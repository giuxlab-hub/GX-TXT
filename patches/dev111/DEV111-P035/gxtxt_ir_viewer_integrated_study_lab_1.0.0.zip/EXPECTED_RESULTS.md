# Risultati attesi / Expected results

Due Dataset iniziali reali637righe, HDF5 float64/schema v3, coordinata
cm^-1/trasmissione relativa unità1 e tutti gli X/Y identici ai rispettivi oracle
CSV/Manager entro1e-8. Analysis iniziale NOT_RUN: il completamento del laboratorio
richiede veri Job e prodotti; nessun rank/peak viene inserito staticamente.
La baseline storica di ItemID13/top score circa1 è retrieval della stessa fonte,
non un'etichetta chimica valida per un campione ignoto. Il report finale deve
riportare parametri, Library payload, source/canonical SHA e limiti, non un PASS
copiato da questo documento.

## Identità di pubblicazione

- `ir.integrated.query`: 637 campioni, hdf5, RefIMP2022 genuine ItemID13 source-equivalent retrieval fixture; not independent polymer identification
- `ir.integrated.reference14`: 637 campioni, hdf5, Explicit Generate action copies reviewed RefIMP training ItemID14 through public read/Publication; ordinary Browser selection never publishes

Questi sono oracle e confini da verificare, non ricevute di una esecuzione.
Canonical data must remain unchanged by display, Workspace and image export.
