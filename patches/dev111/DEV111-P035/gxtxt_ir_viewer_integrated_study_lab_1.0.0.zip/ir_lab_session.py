"""Registered public producer; all scientific files are owned by Publication v2."""
# SPDX-License-Identifier: GPL-3.0-or-later
import json,math
import numpy as np
from gxtxt import gxtxt_api_call as call,gxtxt_api_require

def produce(plan):
    gxtxt_api_require(['DATASET_PUBLICATION_API_v2','PLOT_DATASET_API_v4'])
    requests={0:[],1:[]}
    for item in plan['inputs']:
        xs=list(map(float,item['x']));ys=list(map(float,item['y']))
        if len(xs)!=item['expected_count'] or len(ys)!=len(xs) or not all(math.isfinite(v) for v in xs+ys):raise ValueError('Verified source count/finite values differ')
        xname=item['x_quantity'];yname=item['y_quantity']
        provenance=dict(item['provenance'],spectrum_kind=item['spectrum_kind'],x_quantity=xname,y_quantity=yname,y_representation=item['y_representation'],source_hash=item['source_hash'],source_identity=item['source_identity'],source_spectrum_hash=item['spectrum_hash'])
        provenance['source_metadata']=item['source_metadata']
        req={'dataset_id':item['dataset_id'],'contract':'spectrum.scientific','storage':item.get('storage','hdf5'),
             'x_variable':{'variable_id':'wavenumber','name':xname,'unit':item['x_unit'],'dtype':'float64','semantic_role':'independent','coordinate_role':'coordinate'},
             'y_variable':{'variable_id':'signal','name':yname,'unit':item['y_unit'],'dtype':'float64','semantic_role':'measured','coordinate_variable_ids':['wavenumber']},
             'x_values':np.asarray(xs,dtype=np.float64),'y_values':np.asarray(ys,dtype=np.float64),'producer_version':plan['version'],'source':item['source_identity'],'provenance':provenance,
             'structured_metadata':{'spectral_x_variable_id':'wavenumber','spectral_y_variable_id':'signal','spectrum_kind':item['spectrum_kind'],'spectrum.y_representation':item['y_representation'],'teaching.generator_id':plan['generator_id'],'teaching.source_classification':item['classification']},
             'notes':item['description']+'; source order and values retained; no implicit scientific identification.'}
        if item['source_dataset_ids']:req['source_dataset_ids']=item['source_dataset_ids']
        phase=item['publication_phase']
        if phase not in requests:raise ValueError('Unsupported publication phase')
        requests[phase].append(req)
    outputs=[]
    for phase in (0,1):
        if requests[phase]:outputs.append(call('DATASET_PUBLICATION_API_v2','publish_series_batch',[{'series':requests[phase]}]))
    # Ordinary canonical PlotSpec, shared native renderer. Comparison exercises
    # use the genuine Builder Comparison owner in the explicitly separate replay.
    first=plan['inputs'][0]
    spec={'schema':'PLOT_DATASET_PLOTSPEC_v2','graph_type':'cartesian_2d','graph_id':'plot.dataset.xy','title':plan['title'],'defaults':{'style':{}},
          'panels':[{'id':'source','title':'Canonical source values; no display normalization','axes':{'x':{'label':'Wavenumber (cm^-1)','scale':'linear','direction':'reverse'},'y_left':{'label':first['y_quantity']+' ('+first['y_unit']+')','scale':'linear'}},
                     'series':[{'id':'query','dataset_id':first['dataset_id'],'x_variable_id':'wavenumber','y_variable_id':'signal','axis':'left','kind':'line','label':first['description'],'style':{'color':'#1565C0'}}],'annotations':[]}],'output':{}}
    graph=call('PLOT_DATASET_API_v4','create_plot',[spec,'variant'])
    print(json.dumps({'schema':'gxtxt.ir_lab_generation.v1','status':'GENERATED','generator_id':plan['generator_id'],'dataset_receipts':outputs,'plot':graph,'scientific_analysis':'NOT_RUN_BY_INITIAL_GENERATION','native_gui':'SEPARATE_REQUIRED_EXERCISE'},default=str),flush=True)
