"""Portable Session generator bootstrap; scientific storage belongs to GX-TXT."""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse,configparser,hashlib,json,os,shutil,subprocess
from pathlib import Path

DOCUMENTS=('STUDENT_GUIDE.md','FACULTY_GUIDE.md','TEST_PLAN.md','EXPECTED_RESULTS.md','RIGHTS.md','README.md','LICENSE')
def main():
    p=argparse.ArgumentParser();p.add_argument('--target-session',required=True);p.add_argument('--library-id');p.add_argument('--generator-id');p.add_argument('--framework',default=os.environ.get('GXTXT_FRAMEWORK_ROOT',''));a=p.parse_args()
    here=Path(__file__).resolve().parent;target=Path(a.target_session).resolve(strict=True);framework=Path(a.framework).resolve(strict=True) if a.framework else None
    if framework is None or not (framework/'gxtxt_pipeline.tcl').is_file():p.error('Real GXTXT_FRAMEWORK_ROOT or --framework is required')
    descriptor=configparser.ConfigParser(interpolation=None);descriptor.read(here/'generator.ini',encoding='utf-8');gid=descriptor['generator']['generator_id']
    if a.generator_id and a.generator_id!=gid:raise ValueError('Actual generator identity changed')
    plan=json.loads((here/'LAB_PLAN.json').read_text());assert plan['generator_id']==gid and plan['version']==descriptor['generator']['version']
    if not (target/'metadata').is_dir() or not (target/'channels').is_dir():raise ValueError('Existing fresh public Generator Session required')
    pins={}
    for line in (here/'SHA256SUMS.txt').read_text(encoding='ascii').splitlines():
        sha,rel=line.split('  ',1)
        if Path(rel).is_absolute() or '..' in Path(rel).parts:raise ValueError('Invalid package manifest')
        source=here/rel
        if source.is_symlink() or hashlib.sha256(source.read_bytes()).hexdigest()!=sha:raise ValueError('Asset identity differs: '+rel)
        if rel.startswith('assets/'):pins[rel]=sha
    for rel,sha in pins.items():
        dst=target/'raw'/Path(rel).relative_to('assets')
        if dst.exists():raise FileExistsError(dst)
        dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(here/rel,dst)
        if hashlib.sha256(dst.read_bytes()).hexdigest()!=sha:raise ValueError('RAW copy differs')
    for name in DOCUMENTS:
        dst=target/name
        if dst.exists():raise FileExistsError(dst)
        shutil.copyfile(here/name,dst)
    subprocess.run(['tclsh',str(here/'public_producer.tcl'),str(framework),str(target),str(here)],check=True)
    print(json.dumps({'status':'GENERATED_PUBLIC_CANONICAL_SOURCES','generator_id':gid,'version':plan['version'],'raw_assets':pins,'analysis_execution':'SEPARATE_EXPLICIT_REPLAY','native_GUI':'NOT_RUN_BY_GENERATION'},ensure_ascii=False),flush=True)
