# IR Spectral Contracts — RAW, HDF5 and display meaning

Verificare sorgenti, quantità, provenienza e replay scientifico separato. La generazione non certifica identificazione o GUI.