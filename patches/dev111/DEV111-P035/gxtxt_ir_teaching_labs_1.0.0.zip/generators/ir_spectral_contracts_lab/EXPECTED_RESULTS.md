# Risultati attesi / Expected results

Tutti i numeri derivano dal modello sintetico dichiarato, non da una misura.
Le quattro pubblicazioni hanno cinque righe, dtype float64, coordinata
`wavenumber` cm^-1 e risposta `signal`1, ruoli independent/measured, riferimento
esplicito alla coordinata. A/JDX/copiaCSV devono conservare tutte le coppie.

| X (cm^-1), ordine RAW | A | B | A−B | A/B |
|---|---|---|---|---|
|1800|0.12|0.24|−0.12|0.5|
|1600|0.14|0.28|−0.14|0.5|
|1450|0.155|0.31|−0.155|0.5|
|1300|0.17|0.34|−0.17|0.5|
|1000|0.20|0.40|−0.20|0.5|

Confrontare per coordinata X, tolleranza assoluta1e-12 per i valori binary64;
la presentazione può scegliere un ordine dell'asse differente, i RAW no.
Minmax(A)=Minmax(B)={0,0.25,0.4375,0.625,1} nell'ordine RAW. Non significa A=B.
Con offset1 nello Stacked dichiarato, la seconda curva è B+1 se normalization=none;
non rappresentare quei numeri come campioni originali. Canonical SHA non deve
cambiare quando si modificano modalità/assi/stile/cursore.

Output attesi: `ir.contracts.a`, `ir.contracts.b`, `ir.contracts.jcamp` HDF5,
`ir.contracts.csv_compat` CSV, un normale Plot Variant dei valori originali.
I nomi fisici sono scelti da Publication v2 e non sono un contratto del generatore.
La generazione non esegue l'intero percorso GUI/Analysis/portable; consultare TEST_PLAN.

Un quinto Dataset `ir.contracts.refimp_authentic` conserva637 coppie autentiche
RefIMP ItemID13, non sintetiche, x3706.38→1253.45cm^-1 e trasmissione relativa1.
Lo SHA RAW è riportato in RIGHTS. Non va confrontato come assorbanza con A/B:
il rifiuto delle rappresentazioni incompatibili è parte della lezione.
