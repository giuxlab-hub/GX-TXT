# Contratti spettrali IR: dal RAW al confronto riproducibile

Questo laboratorio costruisce dati **SINTETICI**, non misure di uno spettrometro.
Serve a capire quali informazioni sopravvivono tra CSV, JCAMP-DX, Dataset canonico
e rappresentazione grafica. Non identifica una sostanza e non stima probabilità.

## Esperimento e teoria

La coordinata indipendente è il numero d'onda in cm^-1. Nei cinque nodi irregolari
1800,1600,1450,1300,1000 definiamo A(x)=0.1+(2000-x)/10000 e B(x)=2A(x).
La risposta dichiarata è assorbanza, adimensionale (unità1). L'assorbanza non è
l'indice di assorbimento ottico k, né un segnale arbitrario di trasmissione.
L'ordine originale decrescente è parte dei dati. Invertire l'asse sullo schermo
non autorizza a riordinare o modificare i campioni canonici.

## Preparazione

Importa il pacchetto del generatore con il normale Manager dei Session Generators.
Nel dialogo New Session → Generate Session seleziona l'identità
`ir_spectral_contracts_lab` nella tua libreria installata e un nome nuovo.
La generazione usa i parser pubblici CSV/JCAMP e Publication v2: crea A e B HDF5,
una copia CSV di A per il controllo di compatibilità e la stessa A letta da JCAMP.
Se manca il backend HDF5, l'operazione deve fallire esplicitamente; non rinominare
un CSV in .h5 e non modificare il Registry per aggirare l'errore.

Apri ogni Dataset e la sua lista Variables. Verifica gli ID `wavenumber` e `signal`,
i ruoli independent/measured, il riferimento alla coordinata e l'unità cm^-1/1.
Controlla tutte le cinque coppie di EXPECTED_RESULTS, non solo la prima anteprima.
I file originali sono in RAW e devono mantenere lo SHA registrato nel pacchetto.

## Confronto nativo riutilizzabile

Apri un Viewer genuino installato che dichiari Comparison Plot (il client generico
pubblicato si chiama Non-IR Comparison Example; il nuovo IR Viewer usa lo stesso
owner). Non occorre ricompilare un Viewer per ogni Session o fissarne una versione.
Nella pagina Sources scegli `ir.contracts.a`, X=`wavenumber`, Y=`signal`, poi
Compare → Add Dataset source. Ripeti per `ir.contracts.b`. Nella pagina Method
scegli Overlay, normalization=none, offset=0 e denominator floor=0, quindi
Compare → Prepare comparison. La tabella Sources deve mostrare due Dataset reali,
le unità e gli identificatori effettivi; un'etichetta simile non è un'identità.

Passa a Top/Bottom e Prepare: le X restano sincronizzate mentre le Y sono
indipendenti. Prova Plot → Zoom in/Zoom out/Fit; lo zoom non cambia il Dataset.
Con Stacked usa un offset dichiarato, per esempio1: la traslazione è una scelta
di visualizzazione, non un valore fisico acquisito. Con Difference l'ordine A−B
conta; con Ratio A/B deve risultare0.5 a ogni nodo comune. L'owner Numeric usa
l'interpolazione dichiarata nel dominio comune, senza estrapolare nuove misure.
Associa sempre ogni risultato al suo valore X, senza inferirlo dall'ordine delle
righe visualizzate. I numeri attesi sono nel documento allegato.

Ora prova normalization=minmax in Overlay. Le due forme coincidono anche se B è
il doppio di A: spiega perché somiglianza della forma non significa uguaglianza
fisica. Ripristina none prima di Difference/Ratio; non confondere i valori
normalizzati sul display con quelli canonici. Ratio+normalizzazione non ammessa
deve essere rifiutato mantenendo l'ultimo grafico valido.

## Ispezione, salvataggio e ripetizione

Usa Plot → Reverse X, Pick display value e Clear cursor. Il cursore riporta un
valore visualizzato, non una pretesa identità chimica o una riga canonica implicita.
Properties, Legend e Series style cambiano la presentazione: dopo Apply riapri
Variables e controlla che i numeri siano uguali. Export PNG salva un'immagine,
Copy plot copia l'immagine PNG; nessuna delle due azioni esporta dati scientifici.
Salva una Plot Variant con un nome riconoscibile, salva il Workspace e salva la
configurazione della Session prima di chiudere. Sono confini di persistenza
distinti. Riapri in un processo nuovo e carica la variante dal suo nome effettivo.

## Errori da discutere

Un Dataset mancante, una sorgente modificata o unità incompatibili non devono
produrre un nuovo grafico convincente. Leggi l'errore e verifica che il grafico
valido precedente e i file RAW siano conservati. Non sostituire un segnale k con
assorbanza soltanto perché entrambe le unità sono1. Come esercizio successivo,
proponi una seconda griglia X e descrivi l'interpolazione necessaria prima di
confrontare; non alterare i RAW di questa Session.

## English summary

Explicit synthetic irregular descending wavenumber knots, declared absorbance,
public CSV/JCAMP parsing and HDF5/CSV publication. Compare two canonical Datasets
through shared Comparison Plot, distinguish display transforms from source values,
and verify named variants/Workspace/Session persistence. Generation itself does
not certify Analysis, native GUI execution, cold portability or identification.

## Controllo con una sorgente autentica

Il Dataset aggiuntivo `ir.contracts.refimp_authentic` contiene l'estratto reale
RefIMP ItemID13, separato dal modello sintetico. Leggi RIGHTS e i637 campioni.
La trasmissione relativa non diventa assorbanza perché l'unità è1: tentare un
confronto fisico non compatibile deve produrre una diagnosi, non una conversione
implicita o una presunta identificazione chimica.
