# Diritti e provenienza / Rights and provenance

I tre piccoli file di input sono un modello numerico originale Giux-Lab:
A(x)=0.1+(2000-x)/10000; B(x)=2A(x), nodi1800,1600,1450,1300,1000cm^-1.
Sono esplicitamente SINTETICI, non misure o dati esterni. Codice, documentazione
e questi input originali sono GPL-3.0-or-later. L'header JCAMP dichiara tale origine;
non finge uno strumento o una licenza di una collezione esterna.

Gli asset hanno SHA256 in SHA256SUMS.txt e sono copiati immutati in RAW. I parser
CORE e Publication v2 conservano ordine, valori e provenienza. Nessuna licenza di
una futura misura autentica può essere dedotta da questa licenza o dal suo nome.

## Estratto autentico distinto dal modello

`assets/refimp_pp_item13.csv` è una copia byte-identica dell'asset storico pubblicato,
SHA2567fd1363d540fb6cccbf1543ad715e219fe672e0036b3b205e58d21a2437fa54b:
637 coppie reali ItemID13, RefIMP transmission micro-FTIR, Weisser/Jana e Pohl/Teresa
(2022), TUM mediaTUM1656656, https://mediatum.ub.tum.de/1656656 . I dati sono
CC-BY-SA-4.0 secondo la provenienza/registrazione pubblicata; restano separati dalla
licenza GPL del codice. Conservare attribuzione, licenza e provenienza. Nessuna
modifica dei valori; la conversione HDF5 è un nuovo output esplicito. La risposta è
trasmissione relativa, non assorbanza: il confronto fisico non può cambiarla.
Verifica online della pagina TUM attuale limitata da HTTP429 il2026-10-31; nessuna
pretesa di nuova verifica di licenza live oltre all'evidenza pubblicata e ai byte.
