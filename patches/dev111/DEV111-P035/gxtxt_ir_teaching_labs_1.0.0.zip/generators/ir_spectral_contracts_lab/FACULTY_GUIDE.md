# Guida docente — contratti e significato dei valori IR

Obiettivo: far separare agli studenti quattro identità spesso confuse: sorgente
RAW, Dataset canonico, dichiarazione fisica della variabile e presentazione Plot.
Il generatore è anche una prova d'integrazione del framework, ma una creazione
riuscita non basta per assegnare PASS a calcoli, GUI o riapertura portabile.

Prima della lezione installare normalmente il generatore e un Viewer genuino con
Comparison Plot. Verificare API Publication v2, parser Spectrum CSV/JCAMP, HDF5 e
Plot v4 disponibili. Non distribuire moduli nascosti nel generatore e non imporre
versioni esatte di Viewer o Analysis. L'assenza di una capacità è un prerequisito
esplicito, non un motivo per scrivere manualmente Registry o payload canonici.

La coppia A/B è volutamente costruita. A(x)=0.1+(2000-x)/10000 e B=2A sui cinque
nodi dichiarati; non è uno spettro sperimentale né una simulazione molecolare.
Sono tratti lineari per imparare la semantica. L'assorbanza è dichiarata; non va
trasferita automaticamente a un'ordinata k o a trasmissione relativa. Presentare
prima i dati originali, poi minmax: la coincidenza normalizzata mostra una perdita
del fattore di ampiezza e non dimostra l'identità di due materiali.

Far completare STUDENT_GUIDE prima senza automazione. Per ogni passo annotare
Dataset/Variable ID reali, modalità, normalizzazione, unità e ordine dei sorgenti.
Per Top/Bottom richiedere una vera interazione: zoom/pan X condivisi, Y indipendenti.
Per Difference chiedere il segno A−B; per Ratio chiedere numeratore, denominatore,
dominio comune e politica per zeri/quasi-zeri. In questo fixture il denominatore
non è zero; una prova negativa di zeri richiede un input esplicitamente dichiarato,
non modificare silenziosamente questa serie o sostituire campioni scientifici.

Verificare tutti i campioni CSV/JCAMP/HDF5 attraverso lettori pubblici canonici,
con tolleranza1e-12 per questo modello binary64, e conservare hash/schema/provenienza.
La copia CSV dimostra il lettore legacy senza migrare o sovrascrivere Session
storiche. Un confronto con una misura reale autorizzata va aggiunto soltanto con
byte/licenza/provenienza verificati e senza chiamarla sintetica o cambiare unità.

Valutazione: correttezza numerica e semantica; ripetibilità da installazione pulita;
lettura degli errori senza perdere l'ultimo grafico; chiarezza della distinzione
tra valori canonici e normalizzati; uso reale di tastiera/mouse, salvare/riaprire,
export. Conservare separatamente ricevuta di generazione, replay scientifico,
prove GUI, cold/portable e accettazione indipendente. Nessuna schermata inventata.

English summary: source identity, typed units/roles, binary canonical publication,
legacy readability and scientifically explicit display transforms are assessed
separately. Synthetic data and integration checks are not independent identification.
