# Piano di test / Test plan

1. Import normale in una libreria privata pulita; identità/versione/asset SHA e
   scoperta GUI dell'esatto generatore. Nessuna esecuzione durante l'import.
2. Generate Session con nome nuovo: parser pubblici CSV/JCAMP e writer Publication
   v2 producono cinque Dataset (quattro sintetici e uno autentico distinto). Backend HDF5 assente → rifiuto esplicito/rollback,
   nessuna Session completata fittizia. Ripetere in una seconda nuova Session.
3. Leggere TUTTE le coppie dai lettori pubblici, schema/ruoli/unità/coordinate refs;
   confrontare EXPECTED_RESULTS entro1e-12, RAW SHA invariati, storage reale corretto.
4. Eseguire realmente STUDENT_GUIDE con un client C++ genuino installato. Due
   Dataset canonici, cinque modalità, normalizzazione esplicita, interazioni Plot,
   nomi/unità/metadati, ultimo grafico valido su errore; non sostituire screenshot
   o chiamate dirette al controller ai gesti nativi richiesti.
5. Salva Variant, Workspace e configurazione Session. Chiudi normalmente, processo
   nuovo e riapri. Esporta con i normali owner Session ZIP e Current HTML; importa
   ZIP in nuova destinazione, controlla dati/provenienza e ripeti un confronto.
6. Documentare negativi realmente eseguiti: sorgente mancante/cambiata, capacità
   revocata, rappresentazione/unità incompatibili, impostazioni Ratio non ammesse.
   Nessun PASS da descrizione o da sola generazione; evitare unità inventate.

Accettazione scientifica e GUI appartengono a validatori indipendenti. Le ricevute
sono nuovi artefatti esterni; non scrivere PASS statici dentro il generatore.
