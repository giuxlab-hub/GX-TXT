# IR Spectral Contracts lab

Version1.0.0, logical generator ID `ir_spectral_contracts_lab`. Italian Student /
Faculty guides with English summaries. Independently installable ordinary Session
Generator; no bundled scientific module or exact Viewer/Analysis version dependency.

Generation calls existing CSV/JCAMP Spectrum parsers, registers a normal Python
producer and publishes explicit HDF5 plus CSV through DATASET_PUBLICATION_API_v2.
No private Registry/Manifest/HDF5 writer. Source assets are synthetic and pinned.
The real shared Comparison exercise uses two canonical Datasets and all five modes;
its science/GUI/cold/HTML/ZIP checks are separately required by TEST_PLAN.
