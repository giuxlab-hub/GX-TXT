# Risultati attesi / Expected results

Popolazioni effettive15/9537/1/3; ItemID13/14 risolti dalla provenienza,
637 coppie ciascuno, nessuna deduzione dal nome. Le copie HDF5 coincidono con tutte
le letture Manager bounded delle voci e conservano payload SHA/source SHA/diritti.
Non esiste un oracle di identificazione per questa esercitazione: somiglianza
normalizzata non è probabilità. Tutti i modi producono la trasformazione Numeric
dichiarata sui dati veri, o un rifiuto motivato quando non definiti/compatibili.

## Identità di pubblicazione

- `ir.explorer.item13`: 637 campioni, hdf5, Explicit Generate action copies reviewed RefIMP training ItemID13 through public read/Publication; ordinary Browser selection never publishes
- `ir.explorer.item14`: 637 campioni, hdf5, Explicit Generate action copies reviewed RefIMP training ItemID14 through public read/Publication; ordinary Browser selection never publishes

Questi sono oracle e confini da verificare, non ricevute di una esecuzione.
Canonical data must remain unchanged by display, Workspace and image export.
