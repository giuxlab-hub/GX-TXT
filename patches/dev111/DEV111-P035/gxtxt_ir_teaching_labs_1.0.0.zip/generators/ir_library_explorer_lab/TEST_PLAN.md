# Piano di test — ir_library_explorer_lab


## Confini obbligatori di verifica

- Import/Export normale del generatore: ID/versione, tutti i checksum, nessuna
  esecuzione nascosta durante l'import e nessun modulo Viewer incorporato.
- Generate in una Session nuova: solo parser/Manager e Script Bridge Publication
  v2; veri payload HDF5, schema v3, ruoli/coordinate/unità e hash/provenienza.
  Un prerequisito mancante rifiuta senza una Session completata fittizia.
- Lettura integrale con API canoniche e oracle indipendente; le prime righe o una
  curva plausibile non bastano. Ripeti in processo nuovo e seconda Session nuova.
- Esecuzione reale della guida nativa con due Dataset, cinque modalità quando
  ammesse e tredici comandi Plot; errore e revoca mantengono l'ultimo frame valido.
- Salvataggio Variant/Workspace/configurazione Session, History e cold reopen;
  portable ZIP in destinazione nuova, Current HTML/ZIP e grafici realmente aperti.
- Analysis reale separata dalla pubblicazione: attendere il Job e leggere tutti i
  prodotti/report. Annotare conti, parametri, sorgenti e limiti dei candidati.
- Distinguere ricevute di generazione, regressione scientifica, GUI, cold/portable
  e accettazione indipendente. Questo documento specifica test, non dichiara PASS.

## Oracle specifico

Popolazioni effettive15/9537/1/3; ItemID13/14 risolti dalla provenienza,
637 coppie ciascuno, nessuna deduzione dal nome. Le copie HDF5 coincidono con tutte
le letture Manager bounded delle voci e conservano payload SHA/source SHA/diritti.
Non esiste un oracle di identificazione per questa esercitazione: somiglianza
normalizzata non è probabilità. Tutti i modi producono la trasformazione Numeric
dichiarata sui dati veri, o un rifiuto motivato quando non definiti/compatibili.

English: record actual outcomes and retained failures; do not infer execution
from successful staging, metadata inventories or source code.
