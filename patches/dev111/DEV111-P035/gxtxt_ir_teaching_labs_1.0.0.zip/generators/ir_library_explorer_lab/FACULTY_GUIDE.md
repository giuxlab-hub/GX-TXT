# Guida docente — Library Explorer IR: identità, diritti e confronti

Installa normalmente le quattro Library pubblicate: RefIMP reference15,
RefIMP training/test9537, OpenSpecy nitrocellulosa1, NIST/PNNL k3. Sono quattro
scelte scientifiche con diritti e quantità differenti, non quattro copie dello
stesso corpus. La normale selezione Browser è read-only e non crea Dataset.
Generate è un'azione esplicita distinta: legge le voci ItemID13 e14 training dalla
provenienza Manager e ne pubblica due copie canoniche HDF5 con source entry/payload
SHA e licenza. Gli ID sono `ir.explorer.item13` e `ir.explorer.item14`.

## Preparazione e valutazione

Installare i pacchetti pubblicati con i Manager normali in un profilo isolato;
nessuna copia di sicurezza del proprietario, vecchia Session o libreria di sistema
va modificata. Richiedere le capacità effettive (parser Spectrum, Publication v2,
HDF5, Plot v4, Comparison, Manager e Analysis IR per il replay); non fissare una
versione di Viewer/Analysis né simulare il loro chiamante. Una capacità assente è
un blocco esplicito, non autorizza scritture private. La generazione pubblica dati
e un Plot; da sola non prova Analysis, GUI, probabilità o identificazione.

Raccogliere oracle, tutte le righe, SHA RAW/canonici, schema, parametri e contesto.
Valutare la distinzione fra ordine dati e asse invertito, quantità fisica e unità,
valori canonici e trasformazioni del display, retrieval e identificazione. Le
attività indipendenti devono ripetere i test, non trasformare questo piano in una
ricevuta. Non dichiarare eseguiti tutti i68 generatori da un inventario di metadati.

## Oracle e limiti

Popolazioni effettive15/9537/1/3; ItemID13/14 risolti dalla provenienza,
637 coppie ciascuno, nessuna deduzione dal nome. Le copie HDF5 coincidono con tutte
le letture Manager bounded delle voci e conservano payload SHA/source SHA/diritti.
Non esiste un oracle di identificazione per questa esercitazione: somiglianza
normalizzata non è probabilità. Tutti i modi producono la trasformazione Numeric
dichiarata sui dati veri, o un rifiuto motivato quando non definiti/compatibili.

## English summary

Assess full-source correctness, actual execution and explicit limitations. Keep
source publication, scientific replay and independent acceptance evidence distinct.
