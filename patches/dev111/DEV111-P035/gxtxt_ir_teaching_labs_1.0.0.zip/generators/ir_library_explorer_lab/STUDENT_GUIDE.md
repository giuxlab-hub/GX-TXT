# Library Explorer IR: identità, diritti e confronti

Installa normalmente le quattro Library pubblicate: RefIMP reference15,
RefIMP training/test9537, OpenSpecy nitrocellulosa1, NIST/PNNL k3. Sono quattro
scelte scientifiche con diritti e quantità differenti, non quattro copie dello
stesso corpus. La normale selezione Browser è read-only e non crea Dataset.
Generate è un'azione esplicita distinta: legge le voci ItemID13 e14 training dalla
provenienza Manager e ne pubblica due copie canoniche HDF5 con source entry/payload
SHA e licenza. Gli ID sono `ir.explorer.item13` e `ir.explorer.item14`.

## Avvio

Importa il normale pacchetto del generatore nel Manager, poi New Session → Generate
Session e scegli `ir_library_explorer_lab` versione1.0.0 con un nome nuovo. Leggi RIGHTS
prima di redistribuire. Controlla queste identità effettive:

- `ir.explorer.item13`: 637 campioni, hdf5, Explicit Generate action copies reviewed RefIMP training ItemID13 through public read/Publication; ordinary Browser selection never publishes
- `ir.explorer.item14`: 637 campioni, hdf5, Explicit Generate action copies reviewed RefIMP training ItemID14 through public read/Publication; ordinary Browser selection never publishes

## Indagine guidata

Nel Browser IR elenca Library effettive, capacità, entry ID, modalità, quantità,
unità, licenza, source URL e provenienza. Visita una voce di ciascuna Library;
non attribuire assorbanza a k né trasmissione relativa a OpenSpecy senza leggerne
la dichiarazione. Confronta le due copie canoniche training con i cinque modi;
spiega somiglianze/differenze e trasformazioni display senza assegnare una classe
chimica dalla sola forma. Leggi la corrispondente voce Manager e dimostra il
confine fra read-only reference e Dataset Session creato esplicitamente.

Prova una combinazione fisicamente incompatibile (query trasmissione relativa e
riferimento k) nel normale owner. Richiedi diagnosi e ultimo frame mantenuto,
non una falsa curva con unità forzate. Verifica anche Library assente e source
identity cambiata in un profilo privato: non danneggiare Library/Session originali.

## Confronto riutilizzabile e persistenza

Apri il Viewer IR genuino installato o il client generico Non-IR Comparison Example,
entrambi consumatori del medesimo Comparison Plot pubblico. Scegli gli ID canonici
indicati sotto, X=`wavenumber`, Y=`signal`, e usa Compare → Add Dataset source per
ciascuna sorgente. In Method seleziona Overlay, normalization=none, offset=0,
denominator floor=0 e Compare → Prepare comparison. La tabella deve contenere due
sorgenti reali con unità e identità, non due etichette inventate. Ripeti Top/Bottom,
Stacked (offset esplicito), Difference (prima meno seconda) e Ratio (prima diviso
seconda), quando fisicamente ammessi. Dominio comune e interpolazione lineare
sono dichiarati dall'owner Numeric; non estrapolare fuori dalle misure. Minmax è
una trasformazione di display: non cambia i RAW e può nascondere differenze di
ampiezza. Una rappresentazione incompatibile o Ratio con normalizzazione non
ammessa deve rifiutare conservando il grafico valido precedente.

Con Top/Bottom prova pan e zoom X condivisi e Y indipendenti. Usa il menu primario
Plot: Fit, Zoom in/out, Pick display value/Clear cursor, Reverse X, Properties,
Legend e Series style. Il cursore descrive il display, non una riga canonica né
una sostanza. Copy plot usa PNG nella clipboard; Export PNG produce un'immagine,
non campioni scientifici. Salva una variante con nome riconoscibile, un Workspace
e la configurazione Session: sono tre confini distinti. Riapri in processo nuovo,
carica la variante offerta e controlla dati, unità, sorgenti, stile e annotazioni.

Esporta Current HTML con il normale modulo abilitato e il normale Session ZIP.
HTML è un rapporto navigabile, non un nuovo calcolo; copia e limiti dei dati binari
devono restare espliciti. Importa ZIP in una destinazione nuova e ripeti la lettura
canonica e un confronto. Non cambiare Manifest/Registry per riparare un errore.

## English summary

Reproduce the declared source, quantities and provenance through public owners.
Execute Analysis, native Comparison and cold/portable/export exercises separately;
initial generation is not chemical identification or completed GUI qualification.
