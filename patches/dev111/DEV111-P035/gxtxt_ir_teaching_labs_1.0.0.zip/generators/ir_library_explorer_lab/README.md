# Library Explorer IR: identità, diritti e confronti

Generator ID `ir_library_explorer_lab`, versione1.0.0.

Installa normalmente le quattro Library pubblicate: RefIMP reference15,
RefIMP training/test9537, OpenSpecy nitrocellulosa1, NIST/PNNL k3. Sono quattro
scelte scientifiche con diritti e quantità differenti, non quattro copie dello
stesso corpus. La normale selezione Browser è read-only e non crea Dataset.
Generate è un'azione esplicita distinta: legge le voci ItemID13 e14 training dalla
provenienza Manager e ne pubblica due copie canoniche HDF5 con source entry/payload
SHA e licenza. Gli ID sono `ir.explorer.item13` e `ir.explorer.item14`.

Leggi STUDENT_GUIDE, FACULTY_GUIDE, EXPECTED_RESULTS, TEST_PLAN e RIGHTS.
Codice originale GPL-3.0-or-later; dati esterni con diritti propri. Il generatore
usa parser/Manager pubblici e Script Bridge Publication v2, non un Registry o
writer HDF5 privato. Richiede capacità effettive, non versioni esatte dei moduli.
Generate non esegue implicitamente Analysis né certifica GUI/portable/HTML.

English: independently installable teaching generator with explicit source and
scientific provenance; execute the full documented workflow after generation.
