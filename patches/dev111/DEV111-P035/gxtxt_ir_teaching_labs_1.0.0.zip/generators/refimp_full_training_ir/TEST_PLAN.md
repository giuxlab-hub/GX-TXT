# Piano di test — refimp_full_training_ir


## Confini obbligatori di verifica

- Import/Export normale del generatore: ID/versione, tutti i checksum, nessuna
  esecuzione nascosta durante l'import e nessun modulo Viewer incorporato.
- Generate in una Session nuova: solo parser/Manager e Script Bridge Publication
  v2; veri payload HDF5, schema v3, ruoli/coordinate/unità e hash/provenienza.
  Un prerequisito mancante rifiuta senza una Session completata fittizia.
- Lettura integrale con API canoniche e oracle indipendente; le prime righe o una
  curva plausibile non bastano. Ripeti in processo nuovo e seconda Session nuova.
- Esecuzione reale della guida nativa con due Dataset, cinque modalità quando
  ammesse e tredici comandi Plot; errore e revoca mantengono l'ultimo frame valido.
- Salvataggio Variant/Workspace/configurazione Session, History e cold reopen;
  portable ZIP in destinazione nuova, Current HTML/ZIP e grafici realmente aperti.
- Analysis reale separata dalla pubblicazione: attendere il Job e leggere tutti i
  prodotti/report. Annotare conti, parametri, sorgenti e limiti dei candidati.
- Distinguere ricevute di generazione, regressione scientifica, GUI, cold/portable
  e accettazione indipendente. Questo documento specifica test, non dichiara PASS.

## Oracle specifico

637 coppie per entrambi i Dataset, stessa provenienza/RAW SHA, storage HDF5
e CSV reali e schema float64 rank1 con coordinata `wavenumber` cm^-1, risposta
`signal` unità1. Tutti gli X/Y devono coincidere con l'asset e la voce Manager
risolta entro1e-8. L'ordine originale resta invariato. Difference HDF5−CSV=0;
Ratio=1 soltanto dove il denominatore è definito. Nessuna divisione per zero è
inventata o sostituita.

Il precedente rapporto storico aveva top ItemID13, cosine circa1 e tre picchi
1403.87/2364.21/2857.88cm^-1 con quei parametri. È un oracle STORICO da verificare,
non il risultato già acquisito di questa versione. Registrare differenze reali;
non abbassare soglie né chiamare il punteggio probabilità chimica.

English: record actual outcomes and retained failures; do not infer execution
from successful staging, metadata inventories or source code.
