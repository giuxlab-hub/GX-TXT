# RefIMP: retrieval full-training e limiti dell’identificazione

La misura autentica è l'estratto RefIMP ItemID13:637 coppie numero d'onda
cm^-1 / segnale relativo di trasmissione (unità1). Non è assorbanza. Il Manager deve
mostrare la vera libreria training/test di9537 voci, non la piccola libreria di15.
L'ID corrente è risolto da source_item_id=13, senza assumerlo dal filename.
Generate crea `ir.refimp.item13` HDF5 e `ir.refimp.csv_compat` CSV dagli stessi
byte: sono due rappresentazioni dello stesso esperimento, non misure indipendenti.
Confrontarle è un controllo di interoperabilità, non una conferma chimica.

## Avvio

Importa il normale pacchetto del generatore nel Manager, poi New Session → Generate
Session e scegli `refimp_full_training_ir` versione1.1.0 con un nome nuovo. Leggi RIGHTS
prima di redistribuire. Controlla queste identità effettive:

- `ir.refimp.item13`: 637 campioni, hdf5, RefIMP2022 genuine ItemID13 source-equivalent retrieval fixture; not independent polymer identification
- `ir.refimp.csv_compat`: 637 campioni, csv, Explicit legacy CSV readability copy of the same ItemID13; not a second independent measurement

## Replay scientifico reale

Seleziona `ir.refimp.item13` nel Viewer IR e controlla coordinate, unità, quantità
e provenienza prima dell'Analysis. Scegli la Library training reale; verifica9537
voci e la corrispondenza sorgente ItemID13. Esegui il normale Job Analysis IR con
rappresentazione relative_transmission_signal, baseline none, smoothing none,
derivata0, passo di ricampionamento4cm^-1, cosine, mean_center_unit_vector e
fingerprint1300..1800/peso0.35, registrando anche il range effettivo. Leggi
processed spectrum, peaks, rank e report; non fabbricare output nella generazione.
Il numero di righe candidate restituite può essere10: non confonderlo con9537
voci realmente disponibili/esaminate. Leggi il report effettivo per quel confine.

Il self-match di un estratto incluso nel corpus deve essere chiamato retrieval
coerente, non identificazione indipendente del polimero. Confronta il query con
una seconda misura autorizzata solo esplicitandone identità e dipendenza.

## Confronto riutilizzabile e persistenza

Apri il Viewer IR genuino installato o il client generico Non-IR Comparison Example,
entrambi consumatori del medesimo Comparison Plot pubblico. Scegli gli ID canonici
indicati sotto, X=`wavenumber`, Y=`signal`, e usa Compare → Add Dataset source per
ciascuna sorgente. In Method seleziona Overlay, normalization=none, offset=0,
denominator floor=0 e Compare → Prepare comparison. La tabella deve contenere due
sorgenti reali con unità e identità, non due etichette inventate. Ripeti Top/Bottom,
Stacked (offset esplicito), Difference (prima meno seconda) e Ratio (prima diviso
seconda), quando fisicamente ammessi. Dominio comune e interpolazione lineare
sono dichiarati dall'owner Numeric; non estrapolare fuori dalle misure. Minmax è
una trasformazione di display: non cambia i RAW e può nascondere differenze di
ampiezza. Una rappresentazione incompatibile o Ratio con normalizzazione non
ammessa deve rifiutare conservando il grafico valido precedente.

Con Top/Bottom prova pan e zoom X condivisi e Y indipendenti. Usa il menu primario
Plot: Fit, Zoom in/out, Pick display value/Clear cursor, Reverse X, Properties,
Legend e Series style. Il cursore descrive il display, non una riga canonica né
una sostanza. Copy plot usa PNG nella clipboard; Export PNG produce un'immagine,
non campioni scientifici. Salva una variante con nome riconoscibile, un Workspace
e la configurazione Session: sono tre confini distinti. Riapri in processo nuovo,
carica la variante offerta e controlla dati, unità, sorgenti, stile e annotazioni.

Esporta Current HTML con il normale modulo abilitato e il normale Session ZIP.
HTML è un rapporto navigabile, non un nuovo calcolo; copia e limiti dei dati binari
devono restare espliciti. Importa ZIP in una destinazione nuova e ripeti la lettura
canonica e un confronto. Non cambiare Manifest/Registry per riparare un errore.

## English summary

Reproduce the declared source, quantities and provenance through public owners.
Execute Analysis, native Comparison and cold/portable/export exercises separately;
initial generation is not chemical identification or completed GUI qualification.
