# RefIMP: retrieval full-training e limiti dell’identificazione

Generator ID `refimp_full_training_ir`, versione1.1.0.

La misura autentica è l'estratto RefIMP ItemID13:637 coppie numero d'onda
cm^-1 / segnale relativo di trasmissione (unità1). Non è assorbanza. Il Manager deve
mostrare la vera libreria training/test di9537 voci, non la piccola libreria di15.
L'ID corrente è risolto da source_item_id=13, senza assumerlo dal filename.
Generate crea `ir.refimp.item13` HDF5 e `ir.refimp.csv_compat` CSV dagli stessi
byte: sono due rappresentazioni dello stesso esperimento, non misure indipendenti.
Confrontarle è un controllo di interoperabilità, non una conferma chimica.

Leggi STUDENT_GUIDE, FACULTY_GUIDE, EXPECTED_RESULTS, TEST_PLAN e RIGHTS.
Codice originale GPL-3.0-or-later; dati esterni con diritti propri. Il generatore
usa parser/Manager pubblici e Script Bridge Publication v2, non un Registry o
writer HDF5 privato. Richiede capacità effettive, non versioni esatte dei moduli.
Generate non esegue implicitamente Analysis né certifica GUI/portable/HTML.

English: independently installable teaching generator with explicit source and
scientific provenance; execute the full documented workflow after generation.
