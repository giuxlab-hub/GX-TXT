# Guida docente — RefIMP: retrieval full-training e limiti dell’identificazione

La misura autentica è l'estratto RefIMP ItemID13:637 coppie numero d'onda
cm^-1 / segnale relativo di trasmissione (unità1). Non è assorbanza. Il Manager deve
mostrare la vera libreria training/test di9537 voci, non la piccola libreria di15.
L'ID corrente è risolto da source_item_id=13, senza assumerlo dal filename.
Generate crea `ir.refimp.item13` HDF5 e `ir.refimp.csv_compat` CSV dagli stessi
byte: sono due rappresentazioni dello stesso esperimento, non misure indipendenti.
Confrontarle è un controllo di interoperabilità, non una conferma chimica.

## Preparazione e valutazione

Installare i pacchetti pubblicati con i Manager normali in un profilo isolato;
nessuna copia di sicurezza del proprietario, vecchia Session o libreria di sistema
va modificata. Richiedere le capacità effettive (parser Spectrum, Publication v2,
HDF5, Plot v4, Comparison, Manager e Analysis IR per il replay); non fissare una
versione di Viewer/Analysis né simulare il loro chiamante. Una capacità assente è
un blocco esplicito, non autorizza scritture private. La generazione pubblica dati
e un Plot; da sola non prova Analysis, GUI, probabilità o identificazione.

Raccogliere oracle, tutte le righe, SHA RAW/canonici, schema, parametri e contesto.
Valutare la distinzione fra ordine dati e asse invertito, quantità fisica e unità,
valori canonici e trasformazioni del display, retrieval e identificazione. Le
attività indipendenti devono ripetere i test, non trasformare questo piano in una
ricevuta. Non dichiarare eseguiti tutti i68 generatori da un inventario di metadati.

## Oracle e limiti

637 coppie per entrambi i Dataset, stessa provenienza/RAW SHA, storage HDF5
e CSV reali e schema float64 rank1 con coordinata `wavenumber` cm^-1, risposta
`signal` unità1. Tutti gli X/Y devono coincidere con l'asset e la voce Manager
risolta entro1e-8. L'ordine originale resta invariato. Difference HDF5−CSV=0;
Ratio=1 soltanto dove il denominatore è definito. Nessuna divisione per zero è
inventata o sostituita.

Il precedente rapporto storico aveva top ItemID13, cosine circa1 e tre picchi
1403.87/2364.21/2857.88cm^-1 con quei parametri. È un oracle STORICO da verificare,
non il risultato già acquisito di questa versione. Registrare differenze reali;
non abbassare soglie né chiamare il punteggio probabilità chimica.

## English summary

Assess full-source correctness, actual execution and explicit limitations. Keep
source publication, scientific replay and independent acceptance evidence distinct.
