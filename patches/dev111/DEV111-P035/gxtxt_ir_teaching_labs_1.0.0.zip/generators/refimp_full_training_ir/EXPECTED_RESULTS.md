# Risultati attesi / Expected results

637 coppie per entrambi i Dataset, stessa provenienza/RAW SHA, storage HDF5
e CSV reali e schema float64 rank1 con coordinata `wavenumber` cm^-1, risposta
`signal` unità1. Tutti gli X/Y devono coincidere con l'asset e la voce Manager
risolta entro1e-8. L'ordine originale resta invariato. Difference HDF5−CSV=0;
Ratio=1 soltanto dove il denominatore è definito. Nessuna divisione per zero è
inventata o sostituita.

Il precedente rapporto storico aveva top ItemID13, cosine circa1 e tre picchi
1403.87/2364.21/2857.88cm^-1 con quei parametri. È un oracle STORICO da verificare,
non il risultato già acquisito di questa versione. Registrare differenze reali;
non abbassare soglie né chiamare il punteggio probabilità chimica.

## Identità di pubblicazione

- `ir.refimp.item13`: 637 campioni, hdf5, RefIMP2022 genuine ItemID13 source-equivalent retrieval fixture; not independent polymer identification
- `ir.refimp.csv_compat`: 637 campioni, csv, Explicit legacy CSV readability copy of the same ItemID13; not a second independent measurement

Questi sono oracle e confini da verificare, non ricevute di una esecuzione.
Canonical data must remain unchanged by display, Workspace and image export.
