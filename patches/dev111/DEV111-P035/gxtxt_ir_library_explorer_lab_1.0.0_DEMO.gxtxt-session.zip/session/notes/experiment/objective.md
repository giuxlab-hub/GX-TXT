# IR Library Explorer — identities, rights and meaningful comparisons

Verificare sorgenti, quantità, provenienza e replay scientifico separato. La generazione non certifica identificazione o GUI.