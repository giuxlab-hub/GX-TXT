# Osservazioni effettive / Actual observations

Questo DEMO conserva il Workspace reale del Viewer C++ IR Spectroscopy 1.0.1, selezioni, confronto e consultazione effettiva dei risultati. Generazione iniziale e replay GUI sono azioni distinte.

Questa revisione ripete solo la presentazione e la configurazione: Analysis resta la precedente invocazione realmente completata, senza nuovo Run e senza riattribuire autorità al nuovo processo.

Analysis invocata dal menu nativo autorizzato; stato finale pubblico COMPLETED. Run: analysis.spectroscopy.ir-analysis-1793488656364-298079-1. Report e configurazione reali: analysis/analysis.spectroscopy.ir/ir_analysis_report.txt e runtime.ini. I conteggi dichiarati, bulk_scanned ed exact_examined sono distinti nel report; top-N non significa esame esatto dell’intera Library.

Workspace: P035 IR Library Explorer — ranked consultation. Variante: P035 Explorer — final complete legend. Le quantità e rappresentazioni delle sorgenti sono dichiarate nei Dataset. Per NIST k è indice di assorbimento, non assorbanza; griglia standard e replay legacy restano distinti. Il recupero di una sorgente equivalente non è identificazione chimica indipendente e gli score non sono probabilità.

English summary: genuine native Analysis completed and the real IR Workspace/Plot variant was saved. Exact source provenance, processing parameters, ranked references and rights are retained. This is an author teaching replay, not independent chemical validation; original scientific values and external rights are unchanged. See the Italian Student/Faculty/TestPlan/ExpectedResults and rights notes for scope.
