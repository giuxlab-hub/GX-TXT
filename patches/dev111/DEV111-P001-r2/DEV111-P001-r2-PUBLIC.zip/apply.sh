#!/usr/bin/env bash
# DEV111-P001, installer revision 2. Run only after closing GX-TXT.
set -euo pipefail
patch_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
operation=apply
if [[ ${1:-} == --help || ${1:-} == -h ]]; then
    printf '%s\n' 'Uso: ./apply.sh [cartella-GX-TXT]' 'Ripristino: ./apply.sh --rollback [cartella-GX-TXT]' 'Senza percorso usa /home/giu/script-ag/current/gxtxt. Chiudere GX-TXT prima.'
    exit 0
fi
if [[ ${1:-} == --rollback ]]; then
    operation=rollback
    shift
fi
if (( $# > 1 )); then
    printf '%s\n' 'Uso: ./apply.sh [--rollback] [cartella-GX-TXT]' >&2
    exit 2
fi
target_dir=${1:-/home/giu/script-ag/current/gxtxt}
python3 - "$target_dir" "$patch_dir" "$operation" <<'PYTHON'
import sys, pathlib, json, hashlib, zipfile, os, stat, tempfile
sys.excepthook = lambda kind, error, trace: print("Errore:", error, file=sys.stderr)
root=pathlib.Path(sys.argv[1]).resolve(strict=True)
patch=pathlib.Path(sys.argv[2]).resolve(strict=True)
op=sys.argv[3]
assert op in {'apply','rollback'}
m=json.loads((patch/'MANIFEST.json').read_text())
assert m['patch_id']=='DEV111-P001' and m['required_predecessor_patch']==0
sha=lambda b:hashlib.sha256(b).hexdigest()
for guard in m['unchanged_guards']:
    p=root/guard['path']
    assert p.is_file() and not p.is_symlink() and sha(p.read_bytes())==guard['sha256'], ('wrong release/owner',p)
archive=patch/('DEV111-P001.zip' if op=='apply' else 'ROLLBACK.zip')
assert sha(archive.read_bytes())==m['archives'][archive.name]['sha256']
oldkey,newkey=('before_sha256','after_sha256') if op=='apply' else ('after_sha256','before_sha256')
with zipfile.ZipFile(archive) as z:
    paths=[r['path'] for r in m['files']]
    assert len(z.namelist())==len(paths) and set(z.namelist())==set(paths)
    data={p:z.read(p) for p in paths}
preimages={}
for r in m['files']:
    rel=pathlib.PurePosixPath(r['path']);assert not rel.is_absolute() and '..' not in rel.parts
    p=root/rel
    assert p.parent.resolve().is_relative_to(root) and not p.is_symlink() and p.is_file(), p
    b=p.read_bytes();assert sha(b)==r[oldkey], ('preflight old hash mismatch',p)
    assert stat.S_IMODE(p.stat().st_mode)==r['mode'], ('preflight mode mismatch',p)
    assert sha(data[r['path']])==r[newkey], ('payload hash mismatch',p)
    preimages[r['path']]=b
print('PASS preflight: all paths; no files replaced yet')
transaction=pathlib.Path(tempfile.mkdtemp(prefix='.DEV111-P001-'+op+'-',dir=root))
for r in m['files']:
    backup=transaction/r['path'];backup.parent.mkdir(parents=True,exist_ok=True)
    backup.write_bytes(preimages[r['path']]);os.chmod(backup,r['mode'])
log=transaction/'TRANSACTION.json'
state={'operation':op,'completed':[],'patch':'DEV111-P001'}
log.write_text(json.dumps(state,indent=2)+'\n')
for r in m['files']:
    p=root/r['path']
    assert sha(p.read_bytes())==r[oldkey], ('changed since preflight',p)
    fd,tmp=tempfile.mkstemp(prefix='.DEV111-P001-',dir=p.parent)
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data[r['path']]);f.flush();os.fsync(f.fileno())
        os.chmod(tmp,r['mode']);os.replace(tmp,p)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    assert sha(p.read_bytes())==r[newkey]
    state['completed'].append(r['path']);log.write_text(json.dumps(state,indent=2)+'\n')
print('PASS',op,'; retained transaction/preimages:',transaction)
PYTHON
printf '%s\n' 'Operazione completata. Ora puoi riaprire GX-TXT.'
