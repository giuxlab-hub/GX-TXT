DEV111-P001 installer revision 2
Compatible only with GX-TXT 0.9.8.10-dev-111 r3.
The same original 6 Tcl source file patch and rollback archives; simplified Bash/Python installer.
Use APPLY.md. P002 requires P001 already installed.
License GPL-3.0-or-later.
