# DEV111-P007 — GX-TXT dev111 r3 cumulative maintenance update

Install after P006 with GX-TXT closed. Preserve a full backup of the previous framework before extracting. This package contains the public framework-file delta for P007; the original author archive and internal testing evidence are preserved privately.

    unzip -o DEV111-P007-PUBLIC.zip -d /path/to/gxtxt

Restore exact previous file bytes from the backup to roll back, and remove files that were new in this patch.
The public manifest documents all source SHA256 values and source compatibility. Scientific executable files and native binaries are identical to the owner-deposited signed patch. Private developer test receipts and internal work catalogues are omitted.


