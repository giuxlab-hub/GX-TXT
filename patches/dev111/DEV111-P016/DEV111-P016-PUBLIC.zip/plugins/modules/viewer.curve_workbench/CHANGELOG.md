## 2.21.15 — DEV111-P016

- Obtain retained sprite geometry directly from the authoritative C scene through
  public CORE C++ synchronization, with exact change detection and managed lifetime.
  Ordinary redraws no longer reconstruct every curve's Tcl snapshot/primitives.
- Adopt the public CORE CAD context for semantic selection, native manipulation,
  control/constraint coordination, retained components and topology operations.
  Generic highlights and constituent picking move to CORE. Dataset/Session,
  coordinate admission, History and publication remain with established owners.
- Preserve Cairo, scientific C algorithms, native grid, scheduling and UI layout.
  See the public API and responsibility audit for supported boundaries/limitations.

## 2.21.14 — DEV111-P015

- Use the shared retained C++/Cairo sprite scene for scientific paths, defining
  controls, Dataset point markers and direction arrows. The native C scientific
  model, selection/constraint/gizmo transactions, units, History and publication
  owners are preserved; existing Tk interaction overlays remain above the scene.
- Keep the accepted native grid, graphics profiles, menu/History and comparison
  interface. No other production Viewer adopts this rendering layer.
- CORE provides independent optional P009 tooltip presentation switches and
  idempotent tooltip registration. See the CORE audit and focused validation.

## 2.21.13 — DEV111-P014

Use one retained CORE Cairo grid/axes item, preserving scientific axis/unit owners,
with native batching/reuse of defining-handle Tk items. CORE Appearance settings
supply Low5/Medium10/Fast20 intensive update limits (Low default) and optional
additional16pixel grid suppression. Wheel/pan/resize/viewport callbacks adopt the
shared scheduler; point/geometry transactions remain authoritative. Restore Help
immediately after Workspace with User Manual/F1 and metadata-derived About.
No geometry engine, grid-generation or snapping algorithm changes.

## 2.21.12 — DEV111-P013

Activate the matching CORE Native2D presentation batches through the existing
shared grid and viewport clipping path. No Workbench rendering, scheduling,
scientific, editing or publication callback is changed. CORE reduces redundant
Canvas queries/clipping work and grid transfer/style preparation while preserving
reference grid geometry, axes, labels, units and presentation. Measured local
individual-redraw improvement; the reported3–4second user stall was not reproduced.

## 2.21.11 — DEV111-P012

Use the opt-in public CORE GUI update scheduler for wheel redraws only. Preserve
immediate Native2D zoom and cursor anchoring, normal16ms scheduling and350ms view
persistence. Rapid request activity can temporarily use100ms frame spacing;
quiet recovery delivers the final state and restores normal scheduling. Transfer
pending frame ownership when normal editing resumes, dispose on close/context
invalidation. Preserve all P011 transaction fixes and comparison/scientific owners.

## 2.21.10 — DEV111-P011

Defer coordinate-frame visibility/view reconciliation while Native2D owns an
active drag. Keep Translate/Rotate previews rendering without attempting a
conflicting scene mutation. Cancel a rejected ordinary point-drag commit through
the existing Native owner before refreshing the GUI, preserving exact geometry
and avoiding an orphan transaction. Preserve gizmo/pivot/constraints, History,
Undo/Redo, P010 comparison/deviation publication and all prior GUI corrections.
No Native2D engine, public API, scientific algorithm or layout change.

## 2.21.9 — DEV111-P010

Embed comparison and geometric measurement controls in the existing scrollable
Native2D compare panel. Remove the permanent upper row; keep the Plot v4 residual
surface. Explicit Reference/Target path IDs replace implicit active targeting.
Show current/stale/unavailable receipts and publication prerequisites without
implicit comparison. Rename the numeric metric target Expected value. Reuse
existing Native2D/Statistics/Publication services and Workspace/History payloads.
P007–P009, Sketch palette and scientific algorithms remain unchanged.

## 2.21.8 — DEV111-P008

Connect the bottom Description/History selector to the existing Viewer-bounded
UI Field selector. Retain the shared canvas tooltip lifecycle rather than
destroying tooltip windows from Workbench bindings. The matching CORE correction
distinguishes internal focus/harmless stacking from genuine tooltip dismissal.
Preserve the P007 layout and menus; no scientific or performance change.

## 2.21.7 — DEV111-P007

Restore the accepted bottom Description/History strip and remove its upper row.
Place Save workspace in Workspace, all Publish selection choices in Objects,
and Publication settings in Settings. Remove the upper publication button group
and its width allocation. Preserve 2.21.6 command, publication, native viewport,
History, workspace and scientific behavior; no performance change is claimed.

## 2.21.4 — dev109

Offer informed, default-No axis review before ordinary canonical Sketch Open
replaces a Workspace. Resolve effective physical dimensions through the existing
frame and Unit Registry owners. Explicit Yes enables heterogeneous axes only for
the new draft; explicit caller policy and homogeneous intake keep their existing
behavior. Recheck the reviewed Session, source and parent around modal decisions
and before the original import owner runs.

Refresh the existing object list and defining-handle/point table after a
successful canonical Sketch import. Opening a draft now projects its imported
objects into these controls, including when the utility area is revealed later.
Geometry, source identities and the existing semantic selection remain owned by
their original services.

Scoped native object-name selection and scientific-axis declaration, Sketch
export and ordinary reopen are separately MAIN-accepted. This does not establish
a whole-GUI or release PASS. At the recorded AFTER12 cutoff, the custom
construction and effective-dimension Add curve facets remain pending. Fresh
packaging must use the corrected source; earlier immutable packages and their
scoped admission receipts are preserved.

## 2.21.3 — dev109

Reserve the existing comparison residual panel before the expanding main viewport
so its plot and axis labels remain visible when comparison controls open. Keep
the same public Plot v4 widget, source identities and statistical owners.

Focused native verification and MAIN acceptance remain separately receipted.
The immutable 2.21.2 candidate is preserved; this patch requires a fresh package.

## 2.21.2 — dev109

Numerical comparison display uses public Plot v4 while retaining original geometry/statistical/publication owners; lifecycle and authorized Save presentation binding. Requires dev109 shared comparison support.

Focused acceptance receipts remain separate from this version declaration; final integrated release acceptance/deposition is pending.

## 2.21.1 — 2026-10-17

Use shared CORE dialog lifecycle for source selection and declare native-resolution scientific catalog artwork.

## 2.20.0

Admit registered proportional homogeneous coordinate frames of any physical
dimension through the shared Unit Registry. Preserve conservative mixed/affine
rejection and physical Native3D length contracts. Use explicit reviewed whole-
Workspace conversions, formal area units and the same retained geometry engine.

# viewer.curve_workbench

## 2.19.0

Move/Pivot and axis dimensions use independent scientific display units while
retaining canonical Native2D geometry, constraints and parameter expressions.
Keep metric operation guards and distinguish affine origins from displacement.
Trace the CAD unit label through toolbar layout and correct numeric forms' active
curve fallback and inline null-reference handling.

Add explicit independent scientific axes for new point curves and unbound or
missing-unit sources. Preserve declarations, original values, dependencies,
constraints, Undo/Redo, publication and Workspace reopen. Route CAD unit checks
and small-curve publication through the actual coordinate-frame owner; Y locks
use Y units. Known Dataset units require compatible conversion or explicit
normalization instead of relabelling.

## 2.18.0 — dev097 integration in progress

Accepted-model Workbench transfer retains exact supported Native2D primitives,
independent axis units, original parameter mappings and immutable model resources.
Unsupported representations are explicitly sampled; no refit or statistics are
computed. Public Numeric/Fitter operations and CORE nested resource adoption
serve both scripting languages. Targeted evidence is recorded in checkpoint157.
Workbench/current API manual chronology is moved to existing release history;
compatibility contracts and literal document paths remain unchanged.

## 2.17.0 — dev097 integration in progress

Independent scientific axis display uses CORE Unit Registry/Metadata presentation
for ticks, cursor, paged points, retained handles, numeric edits and X selection.
Named Workspaces retain display choices and the canonical reference for persistent
Dataset magnification; transient zoom remains independent. Unlike axes use the
existing Native host scientific viewport policy and offer signed Y comparison,
without raw mixed-axis physical length/path choices. Canonical publication now
preserves coordinate/sketch annotations through the public metadata overlay.
Grid origins/spacing now use captured CORE forward/inverse plans with stale-frame
guards. Exports preserve converted tick/axis text and the same visible palette,
points-only mode and source/control markers as the view. Fixed white default
Native styles leaking into Workbench export; shared exporter corrects centered
text and compound direction markers.
Compatible mixed-unit comparisons and geometric metrics now use CORE affine
evaluation frames. Display changes refresh comparison units; residual labels,
highlights, source-tuple/deviation publication and Workspace reopen retain the
recorded frame. Readable metric labels preserve canonical saved identifiers.
Dimension/transform dialogs, multiple-source viewport frames and unbound unit
declarations remain part of the integrated work, not claimed complete here.

## 2.16.0 — dev097 shared comparison semantics

Native comparisons use public CORE statistical-result interpretation and typed
publication records, with source/geometry unit changes invalidating saved results.

Reuse shared CORE Viewer command validation and authoritative Workspace titles while preserving retained geometry and existing History.

## 2.15.1 — GX-TXT dev094

Explicit CORE Scientific Recipe history rebase with confirmed Workspace Clear History; generic shared central/local shortcut configuration. Existing geometry and layouts remain unchanged.

## 2.15.0 — dev-092

Contextual per-subpath arrows use native stable identities and physical placement,
with independent flip, Undo/Redo, saved Workspace and Script Bridge support.
Shared workarea-aware native menus and compact grid sections; responsive History
and publication controls; active tools and exact constraint-reference overlays.
Discoverable managed background graphic import, percent opacity, two-point physical
calibration/reset and reference dimensions. Requires framework dev092 or newer.

## 2.13.0

Persistent History and atomic Sketch recovery; exact adaptive Native2D display. Requires framework dev071 or newer.

## 2.12.0 — dev-070

Exact local Spline conversion, canonical Sketch workflows, PDF exports and middle Pan.

## 2.11.4 — dev-069

Consistent Spline attachment termination and explicit local/whole selection.
Whole-object feedback, list Select and Native-backed exact Spline span targeting.

## 2.11.3 — dev-068 workflows

Correct semantic selection feedback/retry, non-modal invalid-input guidance,
construction tool switches, one instruction row and existing-segment attachment.

## 2.11.2 — dev-067 focused corrections

Restore pre-CAD version-2 Workspaces, retain save protection without repeated
automatic dialogs, show one Spline instruction and commit Paths on existing
line/branch controls. Independent Spline invalid-input report remains unresolved.

## 2.11.1 — GX-TXT dev-066 remote X11 usability

Use real viewport descendants and host-resolved panels for render/input routing.
Place feedback/readout labels in their real parent frames, fit the initial window
within the screen, and retain valid Native construction prefixes on degenerate
cursor previews. No scientific evaluator, topology, parameter authority or
persistence format changed. Remote GUI validation is in the framework report.

## 2.10.0 — GX-TXT 0.9.8.10-dev-063

Square visible initial grid, one-row operation/coordinate readout, and exact
Spline tangent-handle editing inside a composed Path through existing CORE APIs.
Shared viewport controls reserve aspect overrides for host APIs.

## 2.9.0 — GX-TXT0.9.8.10-dev-062

Selection-independent pivot activation/placement and automatic connected
retained Path construction. Internal Path vertices/curve controls remain
directly editable using the shared Native2D reference/preview/edit authority.

## 2.8.1 — GX-TXT0.9.8.10-dev-061

Place Select and Transform/Pivot in the existing shared icon toolbar above the
canvas and remove their visible upper-toolbar duplicates. Command behavior is
unchanged.

## 2.8.0 — GX-TXT0.9.8.10-dev-060

One exact logical heterogeneous Path is the normal connected Join result;
internal coincidence constraints become Path junctions and Undo restores them.
Main and sketch Select controls use the shared pictographic glyph. The
Workbench also inherits the no-Session workspace refresh correction.

## 2.3.0 — GX-TXT0.9.8.10-dev-054

Graphical persistent constraints and dimensions, CORE retained component driving and genuine G2, driving/reference mode, inline edits and independent annotation placement, reliable marker interaction, in-Workbench palette and coherent rejected edits. Existing scientific Dataset/representation/publication/units/history/recovery workflows preserved.

## 2.2.0 — GX-TXT0.9.8.10-dev-053

Mixed typed workspace, canvas retained creation/preview/Escape, Native defining controls and direct edits, selection-based constraints/dimensions and readable inspection, explicit primitive↔Dataset provenance/fit workflows. Dataset scientific operations and existing Dataset→Native/primitive→Native paths remain distinct. Shared actual viewport clipping, semantic history and fresh-process persistence.

# viewer.curve_workbench changelog

## 2.1.0 — GX-TXT0.9.8.10-dev-052

Retained geometry/CAD/constraints/measurements/organization/units/recipes, exact mixed/polar/family publication and reentrancy-safe point selection; complete real-GUI validation.


## 2.16.0 (dev097)

Comparison reports and publications use public CORE statistical interpretations
of Numeric's native reductions. Preserve signed X deviations and sampling policy;
reject mixed-unit Euclidean comparisons. Persist typed records, refresh legacy
receipts and invalidate comparisons when coordinate identities or units change.


- dev097 checkpoint 43: retain independent source frames; automatically align
  compatible newly loaded bindings through CORE, with explicit existing-source
  alignment, per-frame view state and complete-source reconstruction on reopen.
- Preserve transient pan/zoom during whole-Workspace physical conversions and
  retain explicit undeclared-source unit assumptions through CORE presentation.
- Reject unnormalized custom source formulas before physical comparison and
  show geometric metrics in the selected display unit. Scientific IDs unchanged.
