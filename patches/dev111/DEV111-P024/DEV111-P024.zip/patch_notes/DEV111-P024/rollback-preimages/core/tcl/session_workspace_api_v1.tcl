# SPDX-License-Identifier: GPL-3.0-or-later
# A workspace is an Interactive Document with provider metadata, not a second
# registry. Its ID, generation, transaction and resource lifetime remain CORE's.
namespace eval ::GX::SessionWorkspace {variable providers {};variable views {};variable refreshTimer {}}
proc ::GX::sessionWorkspaceApiInfo {} {
    return [dict create api_id SESSION_WORKSPACE_API_v1 api_version 1 operations {list get available_name create update rename delete validate note_read note_write preview_set export import resource_copy_tree} managed_destinations 1]
}
proc ::GX::sessionWorkspaceProviderRegister {provider descriptor} {
    variable ::GX::SessionWorkspace::providers
    foreach field {module_id type schema version validate open} {if {![dict exists $descriptor $field]} {error "Workspace provider needs $field"}}
    _interactiveDocumentValidateOwner [dict get $descriptor module_id] $provider
    dict set providers $provider $descriptor
}
proc ::GX::sessionWorkspaceProviderDiscover {module} {
    set data $::GX::moduleCatalog($module,dict)
    foreach provider [splitList [descriptorValue $data workspaces ids {}]] {
        set section workspace.$provider
        set entry [descriptorValue $data $section entrypoint {}]
        set root [file normalize [file dirname [moduleField $module descriptor]]]
        set file [file normalize [file join $root $entry]]
        if {$entry eq {} || ![string match ${root}/* $file] || ![file isfile $file]} {error {Invalid Workspace provider contribution}}
        source $file
        set descriptor [dict create module_id $module]
        foreach field {type schema version validate open} {dict set descriptor $field [descriptorValue $data $section $field {}]}
        set viewer [descriptorValue $data $section viewer_provider {}]
        if {$viewer ne {}} {dict set descriptor viewer_provider $viewer}
        set versions [descriptorValue $data $section accepted_versions {}]
        if {$versions ne {}} {dict set descriptor accepted_versions [splitList $versions]}
        sessionWorkspaceProviderRegister $provider $descriptor
    }
}
proc ::GX::_workspaceProvider {provider} {
    variable ::GX::SessionWorkspace::providers
    if {![dict exists $providers $provider]} {error "Workspace provider '$provider' is unavailable"}
    set descriptor [dict get $providers $provider]
    set module [dict get $descriptor module_id]
    if {[moduleField $module descriptor {}] eq {}} {error "Workspace provider '$provider' is not installed"}
    set enabled [moduleIsEnabled $module]
    if {[moduleField $module kind {}] eq {viewer} && [dict exists $descriptor viewer_provider]} {
        set viewer [dict get $descriptor viewer_provider]
        set enabled [expr {$viewer in [viewerProviderIds $module] && [viewerProviderEnabled $module $viewer]}]
    }
    if {!$enabled} {error "Workspace provider '$provider' is not enabled"}
    return $descriptor
}
proc ::GX::_workspaceValidatePayload {provider payload version {deep 0}} {
    set descriptor [_workspaceProvider $provider]
    if {$version ni [datasetPublicationV2DictDefault $descriptor accepted_versions [list [dict get $descriptor version]]]} {error "Unsupported workspace schema version '$version'"}
    if {[string bytelength $payload]>16777216} {error {Workspace payload exceeds 16 MiB; use managed resources for large scientific values}}
    if {[catch {dict size $payload}]} {error {Workspace payload must be a dictionary}}
    uplevel #0 [list {*}[dict get $descriptor validate] $payload]
    if {$deep&&[dict exists $descriptor validate_deep]} {uplevel #0 [list {*}[dict get $descriptor validate_deep] $payload]}
}
proc ::GX::sessionWorkspaceList {} {
    variable currentSession
    if {$currentSession eq {}||![file isdirectory $currentSession]} {return {}}
    variable ::GX::SessionWorkspace::providers
    set result {}
    foreach doc [interactiveDocumentList] {
        set provider [dict get $doc provider_id]
        if {![dict exists $providers $provider]||[dict get $doc format] ne [dict get $providers $provider schema] || [catch {_workspaceProvider $provider}]} continue
        lappend result [dict remove [sessionWorkspaceGet [dict get $doc id]] payload]
    }
    return $result
}
proc ::GX::sessionWorkspaceGet {id} {
    set doc [interactiveDocumentRead $id];set provider [dict get $doc provider_id]
    set descriptor [_workspaceProvider $provider]
    if {[dict get $doc format] ne [dict get $descriptor schema]} {error {Document is not a registered workspace}}
    set payload [dict get $doc payload]
    set metadata [datasetPublicationV2DictDefault $payload workspace_metadata [dict create name "[dict get $descriptor type] $id" preview {} note {}]]
    return [dict merge [dict remove $doc payload] [dict create workspace_id $id name [dict get $metadata name] type [dict get $descriptor type] schema [dict get $doc format] schema_version [dict get $doc format_version] preview [dict get $metadata preview] note [dict get $metadata note] payload [dict remove $payload workspace_metadata]]]
}
proc ::GX::_workspaceName {name {except {}}} {
    set name [string trim $name];_interactiveDocumentValidateSingleLine $name {Workspace name}
    if {$name eq {}||[string length $name]>160} {error {Workspace name must contain 1..160 characters}}
    foreach item [sessionWorkspaceList] {if {[dict get $item workspace_id] ne $except&&[dict get $item name] eq $name} {error "Workspace name '$name' already exists"}}
    return $name
}
# Suggested presentation names use the same canonical Workspace inventory.
proc ::GX::sessionWorkspaceAvailableName {preferred} {
    set preferred [string trim $preferred]
    _interactiveDocumentValidateSingleLine $preferred {Workspace name}
    if {$preferred eq {} || [string length $preferred]>150} {error {Preferred Workspace name must contain 1..150 characters}}
    set used [lmap item [sessionWorkspaceList] {dict get $item name}]
    set name $preferred;set index 1
    while {$name in $used} {set name "$preferred [incr index]"}
    return $name
}
proc ::GX::sessionWorkspaceCreate {provider name payload} {
    set descriptor [_workspaceProvider $provider];set version [dict get $descriptor version]
    set name [_workspaceName $name];_workspaceValidatePayload $provider $payload $version 1
    _workspacePreflightResources $payload
    dict set payload workspace_metadata [dict create name $name preview {} note {}]
    set doc [interactiveDocumentCreate [dict get $descriptor module_id] $provider [dict get $descriptor schema] $version $payload]
    return [sessionWorkspaceGet [dict get $doc id]]
}
proc ::GX::sessionWorkspaceUpdate {id payload} {
    set workspace [sessionWorkspaceGet $id]
    _workspaceValidatePayload [dict get $workspace provider_id] $payload [dict get $workspace schema_version] 1
    set prior [dict get [interactiveDocumentRead $id] payload]
    _workspacePreflightResources $payload $prior
    set metadata [dict get $prior workspace_metadata]
    dict set payload workspace_metadata $metadata
    interactiveDocumentUpdate $id $payload
    return [sessionWorkspaceGet $id]
}
proc ::GX::sessionWorkspacePromote {id {name {}}} {
    set workspace [sessionWorkspaceGet $id]
    set doc [interactiveDocumentRead $id];set payload [dict get $doc payload]
    if {![dict exists $payload workspace_metadata]} {
        if {$name eq {}} {set name [dict get $workspace name]}
        dict set payload workspace_metadata [dict create name [_workspaceName $name $id] preview {} note {}]
        interactiveDocumentUpdate $id $payload
    }
    return [sessionWorkspaceGet $id]
}
proc ::GX::sessionWorkspaceRename {id name} {
    sessionWorkspacePromote $id
    set payload [dict get [interactiveDocumentRead $id] payload]
    dict set payload workspace_metadata name [_workspaceName $name $id]
    interactiveDocumentUpdate $id $payload
    return [sessionWorkspaceGet $id]
}
proc ::GX::sessionWorkspaceDelete {id} {
    sessionWorkspaceGet $id
    set path [_noteDocumentPath $id]
    interactiveDocumentDelete $id
    if {[file exists $path]} {file delete -- $path}
    return 1
}
proc ::GX::sessionWorkspaceValidate {id} {
    set workspace [sessionWorkspaceGet $id]
    _workspaceValidatePayload [dict get $workspace provider_id] [dict get $workspace payload] [dict get $workspace schema_version] 1
    set references {};set budget 0
    _documentResourceReferences [dict get [interactiveDocumentRead $id] payload] $id 0 budget references
    if {[dict get $workspace note] ne {}} {noteDocumentRead $id}
    return [dict create valid 1 resource_count [dict size $references] workspace_id $id]
}
proc ::GX::managedResourceWrite {document metadata bytes} {
    set writer [interactiveDocumentResourceOpenWriter $document $metadata]
    try {
        for {set i 0} {$i<[string length $bytes]} {incr i 1048576} {interactiveDocumentResourceAppend $writer [string range $bytes $i [expr {$i+1048575}]]}
        set resource [interactiveDocumentResourceFinalize $writer];set writer {}
        return $resource
    } finally {if {$writer ne {}} {interactiveDocumentResourceAbort $writer}}
}
# Reuse the portable Workspace collector/remapper: preserve exact untouched text
# and adopt every nested resource once, including resources inside metadata.
proc ::GX::managedResourceCopyTree {document value} {
    sessionWorkspaceGet $document
    if {[string bytelength $value]>16777216} {error {Resource tree exceeds the 16 MiB Workspace payload bound}}
    set references {};_workspacePackageReferences $value 0 references
    set mapping {}
    dict for {sha reference} $references {dict set mapping $sha [managedResourceCopy $document $reference]}
    return [_workspaceRemapResources $value $mapping 0]
}
# Convert before Tcl crosses tkinter: a dual string/list object otherwise
# becomes a Python tuple, which discards its original scientific text spacing.
proc ::GX::sessionWorkspaceResourceCopyTreeUtf8 {document value} {
    return [encoding convertto utf-8 [managedResourceCopyTree $document $value]]
}
proc ::GX::managedResourceCopy {document reference} {
    # A retained Job result can be adopted by another real Workspace without
    # borrowing the producing Document's generation or deriving private paths.
    set info [interactiveDocumentResourceInfo $reference]
    set reader [interactiveDocumentResourceOpenReader $reference]
    set writer {}
    try {
        set writer [interactiveDocumentResourceOpenWriter $document [dict get $info metadata]]
        while {1} {
            set page [interactiveDocumentResourceNext $reader 1048576]
            interactiveDocumentResourceAppend $writer [dict get $page bytes]
            if {[dict get $page eof]} break
        }
        set result [interactiveDocumentResourceFinalize $writer];set writer {}
        if {[dict get $result sha256] ne [dict get $info sha256]||[dict get $result size_bytes]!=[dict get $info size_bytes]} {error {Resource content changed during ownership transfer}}
        return $result
    } finally {
        interactiveDocumentResourceCloseReader $reader
        if {$writer ne {}} {interactiveDocumentResourceAbort $writer}
    }
}
proc ::GX::sessionWorkspacePreviewSet {id reference} {
    sessionWorkspacePromote $id
    interactiveDocumentResourceInfo $reference
    if {[dict get $reference document_id] ne $id||[dict get $reference metadata format] ni {image.png image.svg}} {error {Preview must be an image owned by this workspace}}
    set payload [dict get [interactiveDocumentRead $id] payload]
    dict set payload workspace_metadata preview $reference
    interactiveDocumentUpdate $id $payload
    return [sessionWorkspaceGet $id]
}
proc ::GX::_noteDocumentPath {id} {sessionWorkspaceGet $id;return [_noteDocumentManagedPath $id]}
proc ::GX::_noteDocumentManagedPath {id} {
    if {![interactiveDocumentExists $id]} {error {Note owner does not exist}}
    set session [_interactiveDocumentRequireSession];set path $session
    foreach part [list notes workspaces "$id.md"] {
        set path [file join $path $part]
        if {![catch {file lstat $path status}]&&$status(type) eq "link"} {error {Note document symlinks are forbidden}}
    }
    return $path
}
proc ::GX::noteDocumentRead {id} {
    set path [_noteDocumentPath $id]
    set workspace [sessionWorkspaceGet $id];set association [dict get $workspace note]
    if {$association ne {}&&(![file isfile $path]||[sha256File $path] ne [dict get $association sha256])} {error {Workspace note is missing or corrupt}}
    return [dict create workspace_id $id text [noteReadUtf8 $path] format GX-Markup]
}
proc ::GX::noteDocumentWrite {id text} {
    if {[string length [encoding convertto utf-8 $text]]>1048576} {error {Note source exceeds 1 MiB}}
    sessionWorkspacePromote $id
    set path [_noteDocumentPath $id];set existed [file exists $path];set before [noteReadUtf8 $path]
    try {
        noteWriteUtf8 $path $text
        set payload [dict get [interactiveDocumentRead $id] payload]
        dict set payload workspace_metadata note [dict create api_id NOTE_DOCUMENT_API_v1 workspace_id $id sha256 [sha256File $path]]
        interactiveDocumentUpdate $id $payload
    } on error {message options} {
        if {$existed} {noteWriteUtf8 $path $before} elseif {[file exists $path]} {file delete -- $path}
        return -options $options $message
    }
    sessionWorkspaceViewsChanged
    return [noteDocumentRead $id]
}
proc ::GX::noteDocumentOpen {id {mode view}} {
    set workspace [sessionWorkspaceGet $id];set text [dict get [noteDocumentRead $id] text]
    set token [interactiveDocumentSessionToken];set receipt [_workspaceHostReceipt $id]
    if {$mode eq "edit"} {return [openMarkupEditor "Notes — [dict get $workspace name]" $text [list ::GX::sessionWorkspaceHostNoteSave $token $receipt $id]]}
    if {$mode ne "view"} {error {Note mode must be view or edit}}
    set window .workspaceNoteView;catch {destroy $window};toplevel $window;wm title $window "Notes — [dict get $workspace name]"
    text $window.text -wrap word -width 80 -height 25;pack $window.text -fill both -expand 1
    markupConfigurePreviewTags $window.text;markupRenderStringToWidget $window.text $text;$window.text configure -state disabled
    ttk::button $window.edit -text Edit -command [list ::GX::sessionWorkspaceHostNoteEdit $token $receipt $id];pack $window.edit -side bottom
    return $window
}
proc ::GX::sessionWorkspaceOpen {id} {
    set workspace [sessionWorkspaceGet $id];sessionWorkspaceValidate $id
    set descriptor [_workspaceProvider [dict get $workspace provider_id]]
    set module [dict get $descriptor module_id]
    foreach api [modulePublicApiIds $module] {modulePublicApiActivate $module $api}
    set context [parameterContext [dict get [_datasetPrivateModuleContext $module] capability] $id]
    parameterList $context
    return [_datasetPrivateWithModule $module [list {*}[dict get $descriptor open] $id]]
}
proc ::GX::_workspaceCurveValidate {payload} {
    foreach key {version curves next active view reference target external_feedback} {if {![dict exists $payload $key]} {error "Curve workspace is missing $key"}}
    if {[dict get $payload version]!=2||![string is entier -strict [dict get $payload next]]||[dict get $payload next]<0||[catch {dict size [dict get $payload curves]}]} {error {Unsupported Curve workspace payload}}
}
proc ::GX::_workspaceCurveValidateDeep {payload} {
    native2DEnsure;set scene [::GX::Native2D::core scene]
    try {
        ::GX::Native2D::core view $scene [dict get $payload view]
        dict for {id record} [dict get $payload curves] {
            foreach key {id name source samples x y parents operations representation visible locked edited breaks} {if {![dict exists $record $key]} {error "Curve $id is missing $key"}}
            if {[dict get $record id] ne $id} {error {Curve identity mismatch}}
            if {[dict exists $record working_unit]&&[dict get $record working_unit] ne {}} {unitRegistryConversionPlan [dict get $record working_unit] [dict get $record working_unit]}
            if {[datasetPublicationV2DictDefault $record dataset_binding_only 0]} {
                if {[dict get $record source] eq {}||[dict get $record edited]||[dict get $record samples] ne {}||[dict exists $record sketch_definition]||[dict exists $record geometry_resource]} {error {Dataset binding cannot contain a second geometry authority}}
                foreach key {source_request source_descriptor point_count} {if {![dict exists $record $key]} {error "Dataset binding is missing $key"}}
                foreach key {dataset_id x_variable_id y_variable_id} {if {![dict exists $record source_request $key]} {error "Dataset request is missing $key"}}
                if {[dict get $record source_request dataset_id] ne [dict get $record source]} {error {Dataset source binding identity mismatch}}
                if {![string is entier -strict [dict get $record point_count]]||[dict get $record point_count]<1} {error {Dataset binding requires a positive authoritative point count}}
            } elseif {[dict exists $record sketch_definition]} {
                set object [::GX::Native2D::core sketch_create $scene [dict get $record sketch_definition] 2]
                ::GX::Native2D::core delete $scene $object
            } elseif {[dict exists $record geometry_resource]} {
                set resource [dict get $record geometry_resource]
                set count [dict get $resource metadata point_count]
                if {![string is entier -strict $count]||$count<1||[dict get $resource metadata format] ne "native2d.float64_xy_le_v1"||[dict get $resource size_bytes]!=16*$count} {error {Invalid retained geometry resource shape}}
            } else {
                set points {};foreach sample [dict get $record samples] {lappend points [list [dict get $sample x] [dict get $sample y]]}
                if {$points eq {}} {error {Curve has no retained geometry or samples}}
                set object [::GX::Native2D::core add $scene $points];::GX::Native2D::core delete $scene $object
            }
        }
        if {[dict exists $payload cad_workspace reference_images]} {
            dict for {id record} [dict get $payload cad_workspace reference_images] {
                unitRegistryConversionPlan [dict get $record state length_unit] m
                lassign [_native2DImageDimensions [dict get $record resource]] width height
                if {$width!=[dict get $record state width]||$height!=[dict get $record state height]} {error {Raster dimensions differ from retained image state}}
                set object [::GX::Native2D::core image_create $scene [dict get $record state]]
                if {[dict get $record state resource_id] ne [dict get $record resource sha256]} {error {Raster resource identity mismatch}}
                ::GX::Native2D::core delete $scene $object
            }
        }
    } finally {::GX::Native2D::core destroy $scene}
}
proc ::GX::_workspaceCurveOpen {id} {
    modulePublicApiActivate viewer.curve_workbench CURVE_WORKBENCH_API_v1
    return [::GX::CurveWorkbench::open [dict create workspace_id $id]]
}
::GX::sessionWorkspaceProviderRegister curve_workbench [dict create module_id viewer.curve_workbench type {Curve Workbench} schema gxtxt.curve_workbench.workspace version 2.0 validate ::GX::_workspaceCurveValidate validate_deep ::GX::_workspaceCurveValidateDeep open ::GX::_workspaceCurveOpen]
# Export packages use the existing Portable Resource manifest and integrity
# checks. Script outputs land in the same Document-owned writer authority.
proc ::GX::sessionWorkspaceExport {id} {
    variable scriptDir;variable version
    sessionWorkspacePromote $id;sessionWorkspaceValidate $id
    set workspace [sessionWorkspaceGet $id];set doc [interactiveDocumentRead $id]
    set root [_documentResourceRoot $id];file mkdir $root
    set channel [file tempfile plan [file join $root .export-plan-]]
    set archive "${plan}.zip"
    try {
        fconfigure $channel -encoding utf-8 -translation lf
        foreach {key value} [list workspace_id $id name [dict get $workspace name] provider_id [dict get $workspace provider_id] module_id [dict get $workspace module_id] schema [dict get $workspace schema] schema_version [dict get $workspace schema_version] source_document_receipt [dict remove $doc payload] source_session_origin [sessionOriginRead [_interactiveDocumentRequireSession]] payload [dict get $doc payload]] {puts $channel "$key\t[binary encode base64 -maxlen 0 [encoding convertto utf-8 $value]]"}
        set references {};_workspacePackageReferences [dict get $doc payload] 0 references
        dict for {sha reference} $references {
            interactiveDocumentResourceInfo $reference
            puts $channel "blob\t$sha\t[binary encode base64 -maxlen 0 [dict get $reference document_id]]"
        }
        close $channel;set channel {}
        _portableResourceRun export-workspace [_interactiveDocumentRequireSession] $plan $archive $version
        set current [interactiveDocumentRead $id]
        foreach key {generation revision sha256} {if {[dict get $current $key] ne [dict get $doc $key]} {error {Workspace changed during export; create a fresh package}}}
        return [interactiveDocumentResourceImportNumeric $id $archive {format gxtxt.workspace.zip}]
    } finally {if {$channel ne {}} {close $channel};file delete -force -- $plan $archive}
}
proc ::GX::_workspaceRemapResources {value mapping depth} {
    if {$depth>64} {error {Workspace resource nesting exceeds limit}}
    if {![catch {dict get $value api_id} marker]&&$marker eq "INTERACTIVE_DOCUMENT_RESOURCE_API_v1"} {
        set sha [dict get $value sha256]
        if {![dict exists $mapping $sha]} {error {Workspace references an unpackaged resource}}
        if {![dict exists $value metadata]} {
            _documentResourceProvenanceReference $value
            return [dict remove [dict get $mapping $sha] metadata]
        }
        return [dict merge [dict get $mapping $sha] [dict create metadata [_workspaceRemapResources [dict get $value metadata] $mapping [expr {$depth+1}]]]]
    }
    if {[catch {llength $value} n]||$n==0} {return $value}
    set result {};set changed 0
    foreach item $value {
        if {$item eq $value} {return $value}
        set remapped [_workspaceRemapResources $item $mapping [expr {$depth+1}]]
        if {$remapped ne $item} {set changed 1}
        lappend result $remapped
    }
    # Untouched strings and structured receipts retain their exact original
    # representation. Parsing arbitrary scientific text as a Tcl list must not
    # rewrite quotes, braces, whitespace or the CORE interpretation signature.
    if {!$changed} {return $value}
    return $result
}
proc ::GX::sessionWorkspaceImport {resource {name {}}} {
    interactiveDocumentResourceInfo $resource
    if {[dict get $resource metadata format] ne "gxtxt.workspace.zip"} {error {Import requires a managed Workspace package resource}}
    set path [file join [_documentResourceRoot [dict get $resource document_id]] [dict get $resource sha256].blob]
    return [_sessionWorkspaceImportPath $path $name]
}
# Verified package metadata is provenance, not authentication. Foreign IDs are
# retained as inert source receipts, never resolved against the receiving Session.
proc ::GX::_workspacePackageSourceOrigin {fields payloadHash archiveHash} {
    set parent [dict create source_archive_sha256 $archiveHash]
    if {![dict exists $fields source_document_receipt] && ![dict exists $fields source_session_origin]} {dict set parent source_document_lineage unavailable;return $parent}
    if {![dict exists $fields source_document_receipt] || ![dict exists $fields source_session_origin]} {error {Workspace source lineage receipt is incomplete}}
    set source [dict get $fields source_document_receipt]
    foreach key {id generation revision sha256 module_id provider_id format format_version origin} {if {![dict exists $source $key]} {error "Workspace source receipt is missing $key"}}
    if {[dict get $source id] ne [dict get $fields workspace_id] || [dict get $source module_id] ne [dict get $fields module_id] || [dict get $source provider_id] ne [dict get $fields provider_id] || [dict get $source format] ne [dict get $fields schema] || [dict get $source format_version] ne [dict get $fields schema_version] || [dict get $source sha256] ne $payloadHash} {error {Workspace source receipt differs from packaged identity or payload}}
    _interactiveDocumentValidateSingleLine [dict get $source generation] {Workspace source generation}
    if {![interactiveDocumentIdValid [dict get $source id]] || ![string is entier -strict [dict get $source revision]] || [dict get $source revision]<1 || ![regexp {^[0-9a-f]{64}$} $payloadHash]} {error {Workspace source receipt has invalid identity or revision}}
    foreach origin [list [dict get $source origin] [dict get $fields source_session_origin]] {
        if {[catch {dict size $origin}] || ![dict exists $origin version] || [dict get $origin version] ne {1}} {error {Workspace source origin snapshot is malformed}}
    }
    dict set parent source_document_lineage recorded
    dict set parent source_document $source
    dict set parent source_session_origin [dict get $fields source_session_origin]
    return $parent
}
proc ::GX::_sessionWorkspaceImportPath {path {name {}} {expectedProvider {}}} {
    set session [_interactiveDocumentRequireSession]
    set stage [file join $session metadata .workspace-import-[pid]-[clock clicks]]
    set created {}
    try {
        _portableResourceRun extract $path $stage
        set fields [_portableResourceFields [file join $stage workspace identity.json]]
        set provider [dict get $fields provider_id]
        if {$expectedProvider ne {} && $provider ne $expectedProvider} {error {Package belongs to a different provider. Use the unscoped Session Workspaces manager.}}
        set descriptor [_workspaceProvider $provider]
        if {[dict get $fields schema] ne [dict get $descriptor schema]||[dict get $fields module_id] ne [dict get $descriptor module_id]} {error {Workspace provider/schema mismatch}}
        set payload [noteReadUtf8 [file join $stage workspace payload.utf8]]
        set sourceOrigin [_workspacePackageSourceOrigin $fields [sha256File [file join $stage workspace payload.utf8]] [sha256File $path]]
        _workspaceValidatePayload $provider $payload [dict get $fields schema_version]
        if {$name eq {}} {set name [dict get $fields name]}
        set name [_workspaceName $name]
        # Preflight every embedded reference before allocating a Document. The
        # created Document is removed on failure; no partial workspace survives.
        set old [dict get $payload workspace_metadata];set references {};set budget 0
        _workspacePackageReferences $payload 0 references
        dict for {sha ref} $references {
            set blob [file join $stage workspace blobs $sha.blob]
            if {![file isfile $blob]||[file size $blob]!=[dict get $ref size_bytes]||[sha256File $blob] ne $sha} {error {Packaged workspace resource is missing or corrupt}}
        }
        set note [file join $stage workspace notes.md]
        if {[dict get $old note] ne {}&&(![file isfile $note]||[sha256File $note] ne [dict get $old note sha256])} {error {Packaged note is missing or corrupt}}
        set receipt [_interactiveDocumentCreateWithOrigin [dict get $descriptor module_id] $provider gxtxt.workspace.staging [dict get $descriptor version] {} {} $sourceOrigin];set created [dict get $receipt id]
        set mapping {}
        dict for {sha ref} $references {dict set mapping $sha [interactiveDocumentResourceImportNumeric $created [file join $stage workspace blobs $sha.blob] [dict get $ref metadata]]}
        set payload [_workspaceRemapResources $payload $mapping 0]
        dict set payload workspace_metadata name $name
        dict set payload workspace_metadata note {}
        if {[dict get $old note] ne {}} {
            set managedNote [_noteDocumentManagedPath $created]
            noteWriteUtf8 $managedNote [noteReadUtf8 $note]
            dict set payload workspace_metadata note [dict create api_id NOTE_DOCUMENT_API_v1 workspace_id $created sha256 [sha256File $managedNote]]
        }
        _workspaceValidatePayload $provider $payload [dict get $descriptor version] 1
        interactiveDocumentUpdate $created $payload [dict get $descriptor schema] [dict get $descriptor version]
        sessionWorkspaceValidate $created
        return [sessionWorkspaceGet $created]
    } on error {message options} {
        if {$created ne {}&&[interactiveDocumentExists $created]} {interactiveDocumentDelete $created;set note [file join $session notes workspaces $created.md];if {[file exists $note]} {file delete -- $note}}
        return -options $options $message
    } finally {if {[file exists $stage]} {file delete -force -- $stage}}
}
proc ::GX::_workspacePackageReferences {value depth resultName} {
    upvar 1 $resultName result
    if {$depth>64} {error {Workspace resource nesting exceeds limit}}
    if {![catch {dict get $value api_id} marker]&&$marker eq "INTERACTIVE_DOCUMENT_RESOURCE_API_v1"} {
        set compact [expr {![dict exists $value metadata]}]
        set value [_documentResourceProvenanceReference $value]
        set sha [dict get $value sha256]
        if {![regexp {^[a-f0-9]{64}$} $sha]} {error {Invalid packaged resource identity}}
        if {[dict exists $result $sha]&&[dict get $result $sha size_bytes]!=[dict get $value size_bytes]} {error {Conflicting resource sizes}}
        if {!$compact || ![dict exists $result $sha]} {dict set result $sha $value}
        _workspacePackageReferences [dict get $value metadata] [expr {$depth+1}] result
        return
    }
    if {[catch {llength $value} n]} return
    foreach item $value {if {$item ne $value} {_workspacePackageReferences $item [expr {$depth+1}] result}}
}
rename ::GX::buildSessionFileExplorerGui ::GX::buildSessionFileExplorerGui_workspace056_base
proc ::GX::buildSessionFileExplorerGui {} {
    buildSessionFileExplorerGui_workspace056_base
    set f .top.nb.sessionfiles
    if {![winfo exists $f.workspaceArea]} {
        ttk::labelframe $f.workspaceArea -text Workspaces
        sessionWorkspaceBuild $f.workspaceArea
    }
    sessionPageSelect
}
proc ::GX::managedResourceWriteBase64 {document metadata encoded} {
    if {[string length $encoded]>5592408} {error {Managed write exceeds the bounded 4 MiB data contract}}
    set bytes [binary decode base64 -strict $encoded]
    if {[string length $bytes]>4194304} {error {Managed write exceeds 4 MiB}}
    return [managedResourceWrite $document $metadata $bytes]
}
proc ::GX::managedResourceReadBase64 {reference start count} {return [binary encode base64 -maxlen 0 [interactiveDocumentResourceReadChunk $reference $start $count]]}
proc ::GX::managedResourceNumericWidths {} {
    return {bool 1 int8 1 uint8 1 int16 2 uint16 2 int32 4 uint32 4 int64 8 uint64 8 float32 4 float64 8 complex64 8 complex128 16}
}
proc ::GX::managedResourceNumericOwner {document} {
    _documentResourceRoot $document
    return [_documentResourceOwnerGeneration $document]
}
proc ::GX::managedResourceImportNumeric {document generation path metadata} {
    if {[managedResourceNumericOwner $document] ne $generation} {error {Numeric resource owner generation changed}}
    foreach key {format dtype endian order columns row_count} {if {![dict exists $metadata $key]} {error "Numeric resource metadata requires $key"}}
    set widths [managedResourceNumericWidths];set dtype [dict get $metadata dtype]
    if {![dict exists $widths $dtype]||[dict get $metadata endian] ne "little"||[dict get $metadata order] ne "C"} {error {Unsupported numeric resource dtype/order/endian}}
    set columns [dict get $metadata columns];set rows [dict get $metadata row_count];set count [llength $columns]
    if {$count<1||$count>128||[llength [lsort -unique $columns]]!=$count||![string is entier -strict $rows]||$rows<0} {error {Numeric resource needs 1..128 distinct columns and a nonnegative row count}}
    foreach column $columns {if {[string trim $column] eq {}||[regexp {[\x00-\x1f]} $column]} {error {Numeric column identities must be nonempty single-line text}}}
    switch [dict get $metadata format] {
        gxtxt.numeric_matrix_le_v1 {}
        float64_interleaved_le {if {$dtype ne "float64"} {error {Interleaved binary64 resources require float64 values}}}
        uint64_le {if {$dtype ne "uint64"||$count!=1} {error {Exact row resources require one uint64 column}}}
        native2d.uint8_break_before_v1 {
            if {$dtype ne "uint8"||$columns ne {break_before}||$rows<1} {error {Native2D gaps need a nonempty uint8 break_before column}}
            dict set metadata point_count $rows
        }
        native2d.float64_xy_le_v1 {
            if {$dtype ne "float64"||$columns ne {x y}||$rows<1} {error {Native2D geometry needs nonempty float64 X/Y columns}}
            dict set metadata point_count $rows
        }
        default {error {Unsupported typed numeric resource format}}
    }
    set bytes [expr {$rows*$count*[dict get $widths $dtype]}]
    if {$bytes>536870912||![file isfile $path]||[file type $path] eq "link"||[file size $path]!=$bytes} {error {Numeric resource payload differs from its bounded declared shape}}
    return [interactiveDocumentResourceImportNumeric $document $path $metadata]
}
proc ::GX::managedResourceNumericPage {reference start count} {
    set info [interactiveDocumentResourceInfo $reference];set metadata [dict get $info metadata]
    if {![string is entier -strict $start]||![string is entier -strict $count]||$start<0||$count<0||$count>65536} {error {Numeric resource pages require a nonnegative start and 0..65536 rows}}
    set format [dict get $metadata format];set width 8
    switch $format {
        gxtxt.numeric_matrix_le_v1 {
            set dtype [dict get $metadata dtype];set widths [managedResourceNumericWidths]
            if {![dict exists $widths $dtype]||[dict get $metadata endian] ne "little"||[dict get $metadata order] ne "C"} {error {Unsupported numeric resource dtype/order/endian}}
            set width [dict get $widths $dtype];set columns [dict get $metadata columns]
        }
        float64_interleaved_le {set dtype float64;set columns [dict get $metadata columns]}
        native2d.float64_xy_le_v1 {set dtype float64;set columns {x y}}
        uint64_le {set dtype uint64;set columns {value}}
        native2d.uint8_break_before_v1 {set dtype uint8;set width 1;set columns {value}}
        default {error "Resource format '$format' has no declared fixed-width numeric page contract"}
    }
    set nc [llength $columns]
    if {$nc<1||$nc>128||[llength [lsort -unique $columns]]!=$nc} {error {Numeric resource columns must have 1..128 unique identities}}
    set size [dict get $info size_bytes];set stride [expr {$width*$nc}]
    if {$size%$stride} {error {Numeric resource size differs from its declared row width}}
    set total [expr {$size/$stride}]
    if {[dict exists $metadata row_count]&&[dict get $metadata row_count]!=$total} {error {Numeric resource row count differs from its owned payload}}
    if {$start>$total} {error {Numeric resource page starts outside the resource}}
    set n [expr {min($count,$total-$start)}]
    if {$n*$stride>1048576} {error {Numeric resource pages may contain at most 1 MiB; request fewer rows}}
    set bytes [interactiveDocumentResourceReadChunk $reference [expr {$start*$stride}] [expr {$n*$stride}]]
    return [dict create schema gxtxt.numeric_resource_page.v1 dtype $dtype endian little order C columns $columns start $start row_count $n total_rows $total source_sha256 [dict get $info sha256] bytes $bytes]
}
proc ::GX::managedResourceApiInfo {} {return [dict create api_id MANAGED_RESOURCE_API_v1 api_version 1 operations {write read info copy write_numeric read_numeric} write_bytes_max 4194304 read_bytes_max 1048576 numeric_write_bytes_max 536870912 numeric_page_rows_max 65536 numeric_dtypes [dict keys [managedResourceNumericWidths]] arbitrary_paths 0]}
proc ::GX::noteDocumentApiInfo {} {return [dict create api_id NOTE_DOCUMENT_API_v1 api_version 1 operations {read write} storage UTF-8.md editor GX-Markup graphical_editor host_only]}

# Compare immutable subtrees before traversing them. Camera-only updates keep
# scientific records/resources byte-identical; walking every sampled value on
# pointer release would otherwise turn a tiny view change into a long UI stall.
# Changed branches still use the full resource parser and ownership validation.
proc ::GX::_workspaceChangedResourceReferences {value prior depth resultName} {
    upvar 1 $resultName result
    if {$value eq $prior} return
    if {$depth>64} {error {Workspace resource nesting exceeds limit}}
    if {![catch {dict get $value api_id} marker]&&$marker eq "INTERACTIVE_DOCUMENT_RESOURCE_API_v1"} {
        _workspacePackageReferences $value $depth result
        return
    }
    if {[catch {llength $value} n]} return
    if {[catch {llength $prior}]} {set prior {}}
    set index 0
    foreach item $value {
        if {$item ne $value} {_workspaceChangedResourceReferences $item [lindex $prior $index] [expr {$depth+1}] result}
        incr index
    }
}
proc ::GX::_workspacePreflightResources {payload {prior {}}} {
    set changed {}
    _workspaceChangedResourceReferences $payload $prior 0 changed
    dict for {sha resource} $changed {
        if {[_documentResourceDisposable [dict get $resource metadata]]} {_documentResourceIdentity $resource} else {interactiveDocumentResourceInfo $resource}
    }
}

# UI subscriptions contain widget paths only. Listing/identity continue to come
# from the existing Document registry; an idle refresh never owns saved state.
proc ::GX::sessionWorkspaceViewsChanged {} {
    if {![llength [info commands winfo]]} return
    if {$::GX::SessionWorkspace::views eq {} && $::GX::SessionWorkspace::titles eq {}} return
    if {$::GX::SessionWorkspace::refreshTimer eq {}} {set ::GX::SessionWorkspace::refreshTimer [after idle ::GX::sessionWorkspaceViewsRefresh]}
}
proc ::GX::sessionWorkspaceViewsRefresh {} {
    set ::GX::SessionWorkspace::refreshTimer {}
    sessionWorkspaceViewerTitlesRefresh
    # An empty Session page is a valid UI state. A Document token is meaningful
    # only while a Session is open; asking for one here used to raise at idle.
    if {$::GX::currentSession eq {}||![file isdirectory $::GX::currentSession]} {
        set signature [list no-session]
    } else {
        set signature [list [interactiveDocumentSessionToken]]
        foreach workspace [sessionWorkspaceList] {lappend signature [list [dict get $workspace workspace_id] [dict get $workspace name] [dict get $workspace type] [dict get $workspace provider_id] [dict get $workspace preview] [dict get $workspace generation] [dict get $workspace revision]]}
    }
    dict for {frame prior} $::GX::SessionWorkspace::views {
        if {![winfo exists $frame]} {dict unset ::GX::SessionWorkspace::views $frame;continue}
        if {$prior eq $signature} continue
        set selected [$frame.tree selection]
        sessionWorkspaceGuiAction $frame refresh
        if {[llength $selected]==1&&[$frame.tree exists $selected]} {$frame.tree selection set $selected}
        dict set ::GX::SessionWorkspace::views $frame $signature
    }
}
foreach command {sessionWorkspaceCreate sessionWorkspaceUpdate sessionWorkspaceRename sessionWorkspaceDelete sessionWorkspacePreviewSet _sessionWorkspaceImportPath} {
    rename ::GX::$command ::GX::${command}_workspace_ui_base
    proc ::GX::$command args [format {
        set result [::GX::%s_workspace_ui_base {*}$args]
        ::GX::sessionWorkspaceViewsChanged
        return $result
    } $command]
}
rename ::GX::sessionFileExplorerPopulate ::GX::sessionFileExplorerPopulate_workspace056_base
proc ::GX::sessionFileExplorerPopulate {} {
    set result [sessionFileExplorerPopulate_workspace056_base]
    sessionWorkspaceViewsChanged
    return $result
}

source [file join [file dirname [info script]] session_workspace_viewer_gui.tcl]

source [file join [file dirname [info script]] session_workspace_gui_host.tcl]
