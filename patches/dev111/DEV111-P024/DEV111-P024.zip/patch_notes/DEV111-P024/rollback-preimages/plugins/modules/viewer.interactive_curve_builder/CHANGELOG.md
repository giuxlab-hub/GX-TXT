## 1.2.1 — 2026-10-17

Declare distinct native-resolution scientific catalog artwork, short title and semantic group through the existing Viewer Provider descriptor.

# viewer.interactive_curve_builder 1.1.0

Independent Family/Member filters and graph scope, optional reviewed ordering OFF by default, simple middle-row Options/Workspace without History.

SPDX-License-Identifier: GPL-3.0-or-later


## 1.2.0 — integrated dev097

- Route actual fit Preview status and publication through CORE statistical
  interpretation; preserve Numeric calculations and canonical model identities.
- Retain per-axis physical units/parameter order, explicit constant-response
  R-squared state, validated metadata and legacy captured-preview compatibility.
- Reject altered interpretation before Dataset creation. Workspace schema and
  existing scientific Datasets remain unchanged.
