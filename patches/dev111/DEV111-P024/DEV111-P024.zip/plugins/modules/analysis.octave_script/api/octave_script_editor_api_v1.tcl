# GX-TXT Octave Script Workspace Viewer API v1
# SPDX-License-Identifier: GPL-3.0-or-later
#
# Host-independent activation/persistence layer. The optional Tk implementation
# lives under ui/ and is loaded only after a real Viewer open/rerender request.

namespace eval ::GX::OctaveScriptEditor {
    variable version 1.2.0
    variable moduleId analysis.octave_script
    variable providerId octave_script_editor
    variable documentFormat gxtxt.octave_script.document
    variable documentFormatVersion 1.0
    variable moduleRoot [file normalize [file join [file dirname [info script]] ..]]
}

proc ::GX::OctaveScriptEditor::requireSession {} {
    return [::GX::sessionInspectionCurrentSession]
}

proc ::GX::OctaveScriptEditor::_b64e {value} {
    return [binary encode base64 -maxlen 0 [encoding convertto utf-8 $value]]
}

proc ::GX::OctaveScriptEditor::_b64d {value} {
    return [encoding convertfrom utf-8 [binary decode base64 $value]]
}

proc ::GX::OctaveScriptEditor::payloadEncode {name arguments description code} {
    set name [string trim $name]
    if {$name eq ""} { set name "Untitled script" }
    return "GXTXT_OCTAVE_SCRIPT_DOCUMENT_V1\nname64=[_b64e $name]\narguments64=[_b64e $arguments]\ndescription64=[_b64e $description]\n---\n$code"
}

proc ::GX::OctaveScriptEditor::payloadDecode {payload} {
    set marker "\n---\n"
    set splitAt [string first $marker $payload]
    if {$splitAt < 0} { error "Invalid Octave Script document: missing payload separator." }
    set header [string range $payload 0 [expr {$splitAt - 1}]]
    set code [string range $payload [expr {$splitAt + [string length $marker]}] end]
    set lines [split $header "\n"]
    if {[llength $lines] < 4 || [lindex $lines 0] ne "GXTXT_OCTAVE_SCRIPT_DOCUMENT_V1"} {
        error "Invalid Octave Script document format."
    }
    set fields [dict create]
    foreach line [lrange $lines 1 end] {
        set eq [string first = $line]
        if {$eq < 1} continue
        dict set fields [string range $line 0 [expr {$eq - 1}]] [string range $line [expr {$eq + 1}] end]
    }
    foreach required {name64 arguments64 description64} {
        if {![dict exists $fields $required]} { error "Invalid Octave Script document: missing $required." }
    }
    return [dict create \
        name [_b64d [dict get $fields name64]] \
        arguments [_b64d [dict get $fields arguments64]] \
        description [_b64d [dict get $fields description64]] \
        code $code]
}

proc ::GX::OctaveScriptEditor::_ownedDocumentRead {documentId} {
    error {Obsolete Octave Workspace documents cannot be opened or converted. Use the existing Script Registry editor for current scripts.}
}

proc ::GX::OctaveScriptEditor::documentList {} {
    variable moduleId
    variable providerId
    requireSession
    set out {}
    foreach item [::GX::interactiveDocumentList $moduleId $providerId] {
        set id [dict get $item id]
        dict set item name "$id (obsolete Workspace)"
        dict set item restorable 0;dict set item writable 0
        lappend out $item
    }
    return $out
}

proc ::GX::OctaveScriptEditor::documentRead {documentId} {
    tailcall _ownedDocumentRead $documentId
}

proc ::GX::OctaveScriptEditor::documentCreate {name arguments description code} {
    error {Obsolete Octave Workspace creation is unsupported. Save current executable sources through Script Registry.}
}

proc ::GX::OctaveScriptEditor::documentUpdate {documentId expectedSha name arguments description code} {
    error {Obsolete Octave Workspace updates are unsupported. No in-framework conversion is available.}
}

proc ::GX::OctaveScriptEditor::documentDelete {documentId expectedSha {confirmed 0}} {
    if {![string is boolean -strict $confirmed] || !$confirmed} {error {Obsolete Workspace deletion requires explicit confirmation}}
    set current [::GX::interactiveDocumentMetadata $documentId]
    if {[dict get $current module_id] ne {analysis.octave_script} || [dict get $current provider_id] ne {octave_script_editor} || [dict get $current format] ne {gxtxt.octave_script.document}} {error {Document belongs to another owner or format}}
    if {$expectedSha eq {} || [string tolower [dict get $current sha256]] ne [string tolower [string trim $expectedSha]]} {
        error "This script changed outside this window. Reload it before deleting."
    }
    return [::GX::interactiveDocumentDelete $documentId]
}

# Registered scripts remain the existing executable source authority. Obsolete
# prototype Workspace documents are metadata-only, with no conversion route.
proc ::GX::OctaveScriptEditor::workspaceList {} {
    set out {}
    foreach m [::GX::scriptRegistryList] {
        if {[dict get $m language] ne "Octave"} continue
        dict set m reference "[dict get $m scope]:[dict get $m id]"
        lappend out $m
    }
    return $out
}
proc ::GX::OctaveScriptEditor::workspaceRead {reference} {
    if {[string match legacy:* $reference]} {
        error {Obsolete Octave Workspace restore/conversion is unsupported}
    }
    set m [::GX::scriptRegistryDescribe $reference]
    if {[dict get $m language] ne "Octave"} {error "This Workspace edits Octave scripts only."}
    set ch [open [dict get $m source_path] r]
    fconfigure $ch -encoding binary -translation binary
    try {set bytes [read $ch]} finally {close $ch}
    set code [encoding convertfrom utf-8 $bytes]
    if {[encoding convertto utf-8 $code] ne $bytes} {error {Registered Octave source contains invalid UTF-8 bytes.}}
    dict set m reference $reference
    dict set m script_id [dict get $m id]
    dict set m code $code
    dict set m arguments [::GX::datasetPublicationV2DictDefault $m default_arguments {}]
    return $m
}
proc ::GX::OctaveScriptEditor::workspaceSave {reference expectedSha scope scriptId name description code {arguments {}} {properties {}}} {
    if {$scope ni {user session}} {error "Choose User or Session scope."}
    ::GX::scriptRegistryId $scriptId
    # Keep the original call signature compatible; only supplied editable fields
    # augment the Registry update, which retains unrelated registered metadata.
    set metadata [dict create description $description default_arguments $arguments]
    foreach key [dict keys $properties] {
        if {$key ni {version required_apis parameters}} {error "Unsupported Workspace property '$key'."}
        dict set metadata $key [dict get $properties $key]
    }
    if {[string match legacy:* $reference]} {error {Obsolete Workspace conversion is unsupported}}
    if {$reference eq ""} {
        set result [::GX::scriptRegistrySave $scope $scriptId $name $code [dict merge $metadata [dict create language Octave]]]
    } else {
        if {$reference ne "$scope:$scriptId"} {error "Registered script scope and ID cannot change; use Save copy."}
        set result [::GX::scriptRegistryUpdate $scope $scriptId $expectedSha [dict merge $metadata [dict create name $name]] $code]
    }
    dict set result reference "$scope:$scriptId"
    catch {::GX::sessionScriptExplorerPopulate}
    catch {::GX::scriptAnalysisRefresh}
    catch {::GX::scriptLibraryRefresh}
    return $result
}
proc ::GX::OctaveScriptEditor::workspaceDelete {reference expectedSha} {
    if {[string match legacy:* $reference]} {error {Use explicitly confirmed obsolete Workspace deletion; no legacy script operation is supported}}
    set current [::GX::scriptRegistryDescribe $reference]
    if {[dict get $current sha256] ne $expectedSha} {error "Script changed; reload before deleting."}
    ::GX::scriptRegistryRemove $reference
}

proc ::GX::OctaveScriptEditor::defaultCode {} {
    return {% GX-TXT Octave Script
% This is ordinary GNU Octave code with access to GX-TXT public APIs through
% OCTAVE_SCRIPT_BRIDGE_API_v1.

ctx = gxtxt_context();
disp(ctx);

% Discover script-callable public APIs:
apis = gxtxt_api_list();
fprintf('Available GX-TXT APIs: %d\n', numel(apis));

% Example pattern:
% api_id = 'SOME_PUBLIC_API_v1';
% if (!gxtxt_api_has(api_id))
%   error('Required GX-TXT API is unavailable: %s', api_id);
% endif
% description = gxtxt_api_describe(api_id);
% disp(description);
% request = struct();
% result = gxtxt_api_call(api_id, 'documented_operation', {request});
}
}

proc ::GX::OctaveScriptEditor::_ensureUi {} {
    variable moduleRoot
    if {[llength [info commands ::GX::OctaveScriptEditorUI::open]]} { return }
    set adapter [file join $moduleRoot ui octave_script_editor_ui.tcl]
    if {![file isfile $adapter]} { error "Octave Script Workspace UI adapter is missing: $adapter" }
    source $adapter
    if {![llength [info commands ::GX::OctaveScriptEditorUI::open]]} {
        error "Octave Script Workspace UI adapter did not register its open command."
    }
}

proc ::GX::OctaveScriptEditor::_launch {} {
    _ensureUi
    return [::GX::OctaveScriptEditorUI::open]
}

proc ::GX::OctaveScriptEditor::viewerDispatch {action scene} {
    switch -- $action {
        open - rerender { return [_launch] }
        default { error "Unsupported Octave Script Workspace viewer action '$action'." }
    }
}

::GX::viewerBackendRegister octave_script_editor_tk ::GX::OctaveScriptEditor::viewerDispatch
