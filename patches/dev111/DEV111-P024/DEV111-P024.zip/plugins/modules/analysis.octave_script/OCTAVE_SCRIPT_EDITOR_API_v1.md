# OCTAVE_SCRIPT_EDITOR_API_v1

The lazy Tk editor saves executable source through CORE Script Registry, using
`session:<id>` and `user:<id>` identities. Its title “Workspace” denotes its
source editor; it is not a scientific Session Workspace persistence provider.

`workspaceList` lists registered Octave scripts. `workspaceRead reference`
returns current registered source/metadata. `workspaceSave reference expectedSha
scope scriptId name description code ?arguments? ?properties?` creates or updates
the exact Registry identity. Updates retain language and unrelated metadata and
require the loaded source SHA. Optional properties accept canonical `version`,
manual `required_apis` and typed `parameters`; omitted properties retain values.
Source-declared requirements are discovered by Registry. Default arguments is
separate inert text. `workspaceDelete reference expectedSha` deletes the selected
registered identity through the normal Registry lifecycle.

Obsolete `gxtxt.octave_script.document` body reads, writes, registration and
conversion are unsupported. `documentCreate` and `documentUpdate` refuse clearly;
`documentRead` does not parse the old body. Confirmed obsolete deletion uses the
common metadata/resource-safe Workspace lifecycle. No compatibility writer or
legacy registration action remains.

The editor exposes New, Save, Save copy, Delete, Import/Export `.m`, source search,
clipboard, folding, breakpoints and native managed debugging. Its Octave metadata
panel contains Scope, ID, Name, Default arguments and Description. Version,
additional requirements and typed parameters belong to Run → Script Library.
Session operations require the original Session lifetime; User authoring works
without a Session. Runner/Debug execution uses the public Script Execution and
Octave Script Bridge APIs. See [Manual](MANUAL.md) for the complete control,
source identity, output publication and debugging contracts.
