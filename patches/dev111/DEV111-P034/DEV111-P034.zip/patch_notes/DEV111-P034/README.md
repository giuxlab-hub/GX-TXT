# DEV111-P034: reusable native Comparison Plot

Exact accepted predecessor DEV111-P033 source `c46767878984f04c4b2fc00fc223f1852a0aad53`, ZIP SHA256 `b39eff6747900e4b0777d3a06ed5805e8142fda3c1d20edebeb9df2baf812776`.
Candidate source `7ae361d67c82f7fce44487a76927c36c846b78b1`. BASELINE and FILES define complete guarded bytes
and physical modes, including original owner member permissions. MAIN alone
freezes, accepts and deposits; consult exact independent A/B artifact receipts.

CORE public Comparison Plot, existing Numeric and native Plot v4 owners implement
Overlay, Top/Bottom, Stacked, Difference and Ratio, pinned Dataset/managed-Library
sources, compiled SDK admission, Builder, Workspace and History. A genuine Builder
C++ non-IR consumer accompanies the three authored updated modules. Scientific
limits, units, source pins and non-identification semantics are documented publicly.

The definitive owner modules are Viewer2.0.26 and Preview0.1.10. Their original ZIPs
are delivered as actual normal companion modules, unchanged, without rebuilding
or module scientific/functional/GUI/installation/regression tests. Qualification:
OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST. Exact original filenames,
SHA256 and versions appear in MODULE_VERSION_MATRIX.json. Earlier supplied versions
are superseded for this release. Generic Preview replacement is tested using an
independently authored fixture; no owner module behavior is claimed.

Keep the ZIP and sidecar, stop GX-TXT and its workers. The --stopped acknowledgement
is the operator's assertion; helpers have no process detector. Extract only
patch_notes/DEV111-P034/ to a separate review directory, then:

    python3 review/patch_notes/DEV111-P034/apply.py FRAMEWORK DEV111-P034.zip --check
    python3 review/patch_notes/DEV111-P034/apply.py FRAMEWORK DEV111-P034.zip --apply --stopped

Default check is read-only. Exact rollback preimages precede product writes.
Atomic per-file replacement is not a whole-root transaction. Recovery accepts
only known before/after states; unknown edits/modes/collisions refuse. Plain unzip
cannot implement deletions. User extras and previous notes remain.

    python3 FRAMEWORK/patch_notes/DEV111-P034/rollback.py FRAMEWORK --check
    python3 FRAMEWORK/patch_notes/DEV111-P034/rollback.py FRAMEWORK --rollback --stopped

Rollback restores exact accepted P033 bytes/modes and removes only declared P034
additions; notes/extras remain. Reverse later patches first. No Session/RAW,
configuration, installed-framework activation or prior-release changes are allowed.
The overlay bundles all six modules; companion_preflight.py checks postimages.
Separate normal module ZIPs are alternative delivery for a compatible host and
legitimate Plugin Manager state. Native P034 clients require matching P034 CORE
and explicit grants. Canonical deposit does not activate the owner's installation.
