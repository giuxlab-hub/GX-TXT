# SPDX-License-Identifier: GPL-3.0-or-later
"""P034 finite file-overlay guards. No runtime, Session or configuration owner."""
from pathlib import Path, PurePosixPath
import hashlib, json, os, stat, tempfile, zipfile
from contextlib import contextmanager

PATCH = 'DEV111-P034'
ARCHIVE = PATCH + '.zip'
RELEASE_REVISION = 1
BASE = 'c46767878984f04c4b2fc00fc223f1852a0aad53'
BASE_SHA = 'b39eff6747900e4b0777d3a06ed5805e8142fda3c1d20edebeb9df2baf812776'
NOTES = 'patch_notes/' + PATCH
MAX_FILE = 128 * 1024 * 1024
MAX_ZIP = 512 * 1024 * 1024

class GuardError(RuntimeError):
    pass

def require(test, message):
    if not test:
        raise GuardError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def relative(name):
    require(isinstance(name, str) and name and len(name) <= 4096 and '\\' not in name and ':' not in name and not any(ord(c) < 32 for c in name), 'Unsafe relative path')
    p = PurePosixPath(name)
    require(not p.is_absolute() and all(part not in ('', '.', '..') for part in name.split('/')), 'Unsafe relative path: ' + name)
    return p

SPECIAL = {'gxtxt_pipeline.tcl', 'VERSION.txt', 'PATCH_LEVEL.txt', 'GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'LICENSE'}
SKIP = {'tests', 'validation', 'evidence', 'review', 'archives', 'archive', '__pycache__', '.git', 'node_modules', 'scratch'}

def runtime_path(name):
    p = relative(name)
    # Exact owner-supplied module includes inert tests/documentation unchanged.
    if name.startswith(('plugins/modules/viewer.curve_digitizer/', 'plugins/modules/preview.curve_digitizer/')):
        return True
    # These are installed Native Viewer admission/source receipts, not campaign
    # evidence. Omitting them would pair a new binary with an old build identity.
    if len(p.parts) == 5 and p.parts[:2] == ('plugins', 'modules') and p.parts[3] == 'review' and p.parts[4] in ('build.json', 'validation.json'):
        return True
    if any(x.lower() in SKIP for x in p.parts) or name.lower().endswith(('.zip', '.tar', '.gz', '.xz', '.bz2', '.7z', '.pyc', '.log')):
        return False
    return name in SPECIAL or name.startswith(('app/', 'core/', 'plugins/', 'docs/api/', 'services/', 'docs/development/dev111_p033/', 'docs/development/dev111_p034/'))

MODULES = {'plot.dataset': '4.4.0', 'math.numeric': '1.64.0', 'viewer.interface_builder': '1.2.12', 'viewer.comparison_example': '1.0.2', 'viewer.curve_digitizer': '2.0.26', 'preview.curve_digitizer': '0.1.10'}
ORIGINAL_MODULES = {'preview.curve_digitizer', 'viewer.comparison_example', 'viewer.curve_digitizer'}

# Exact original owner containers; this metadata grants no functional test acceptance.
OWNER_MODULE = 'viewer.curve_digitizer'
OWNER_QUALIFICATION = 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST'
OWNER_QUALIFICATIONS = {'viewer.curve_digitizer': 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST', 'preview.curve_digitizer': 'OWNER_SUPPLIED_UNMODIFIED; NOT_TESTED_BY_OWNER_REQUEST'}
# No supplemental containers: original ZIPs are actual normal MODULES companions.
SUPPLIED_INPUT_ARCHIVES = {}
ORIGINAL_PACKAGE_SHA = {'viewer.comparison_example': '4cc0878a07dc6a528a6988cfe50be8801fb2993ad0d6cd14c5a90b59badcbb26', 'viewer.curve_digitizer': 'ded07ad9a85c79f68fa53866edef9a4a186ef06546882940526b56d9894a1198', 'preview.curve_digitizer': '0c15e4bae34d5b8d9467fb25c075d63886dab08ecd23010d125e7e854d9f4de7'}

def module_archive_name(module, version):
    return {'viewer.curve_digitizer': 'viewer.curve_digitizer_2.0.26_dev111_p032_standalone.zip', 'preview.curve_digitizer': 'preview.curve_digitizer_0.1.10_dev111_p032_standalone.zip'}.get(module, module + '_' + version + '.zip')

BASE_ZIP = Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV111-P033.zip')
NOTE_FILES = {'FILES.json', 'BASELINE.json', 'BUILD_IDENTITY.json', 'MODULE_VERSION_MATRIX.json',
              'DELETIONS.json', 'README.md', 'apply.py', 'rollback.py', 'release_common.py',
              'companion_preflight.py', 'PAYLOAD_SHA256SUMS', 'SUPPLIED_INPUTS.json'}

# Exact reviewed P034 product paths; extend explicitly after coherent source review.
PAYLOAD_SCOPE = frozenset(['GX-TXT_REMAINING_WORK_TODO.md', 'GX-TXT_REMAINING_WORK_TODO.md.sha256', 'PATCH_LEVEL.txt', 'app/gui/dataset_preview_live.tcl', 'core/api_catalog/catalog.sqlite', 'core/api_catalog/source_manifest.json', 'core/development/policy_v1.json', 'core/development/sdk/gxtxt_viewer_sdk_v1.hpp', 'core/development/sdk/trusted_adapter_v1.cpp', 'core/native2d/bin/BUILD_RECEIPT_P034.json', 'core/native2d/bin/gx2dtcl.so', 'core/native2d/gx2d_plot_v4.cpp', 'core/python/gxtxt_viewer_development.py', 'core/python/gxtxt_viewer_native_worker.py', 'core/python/gxtxt_viewer_workspace.py', 'core/tcl/comparison_plot_api_v1.tcl', 'core/tcl/dataset_authority_v1.tcl', 'core/tcl/dataset_preview_api_v1.tcl', 'core/tcl/dataset_preview_cache.tcl', 'core/tcl/dataset_preview_provider_v1.tcl', 'core/tcl/plugin_bundle_api_v1.tcl', 'core/tcl/plugin_install_api_v1.tcl', 'core/tcl/session_workspace_gui_host.tcl', 'core/tcl/ui_field_viewer_regions_v1.tcl', 'core/tcl/viewer_development_api_v1.tcl', 'core/tcl/viewer_gui_comparison_design_v1.tcl', 'core/tcl/viewer_gui_comparison_presentation_v1.tcl', 'core/tcl/viewer_gui_comparison_v1.tcl', 'core/tcl/viewer_gui_design_v1.tcl', 'core/tcl/workbench_extension_api_v1.tcl', 'core/tcl/workspace_scientific_codecs_v1.tcl', 'docs/api/COMPARISON_PLOT_API_v1.md', 'docs/api/CPP_SUPPORT_CATALOG.md', 'docs/api/PLOT_DATASET_API_v4.md', 'docs/api/PLUGIN_INSTALL_API_v1.md', 'docs/api/SCRIPT_BRIDGE_COVERAGE_v1.json', 'docs/api/VIEWER_GUI_DESIGN_v1.md', 'docs/api/VIEWER_GUI_HOST_API_v1.md', 'gxtxt_pipeline.tcl', 'plugins/modules/math.numeric/CHANGELOG.md', 'plugins/modules/math.numeric/NUMERIC_API_v1.md', 'plugins/modules/math.numeric/SHA256SUMS', 'plugins/modules/math.numeric/SHA256SUMS.txt', 'plugins/modules/math.numeric/api/numeric_api_v1.tcl', 'plugins/modules/math.numeric/api/octave/gxtxt_numeric_comparison_curves_v1.m', 'plugins/modules/math.numeric/api/octave/gxtxt_numeric_v1.m', 'plugins/modules/math.numeric/api/operations_v1.tsv', 'plugins/modules/math.numeric/module.ini', 'plugins/modules/math.numeric/plugin-package.ini', 'plugins/modules/math.numeric/runtime/gxtxt_numeric_worker_main.m', 'plugins/modules/plot.dataset/CHANGELOG.md', 'plugins/modules/plot.dataset/SHA256SUMS', 'plugins/modules/plot.dataset/SHA256SUMS.txt', 'plugins/modules/plot.dataset/api/plot_dataset_api_v2.tcl', 'plugins/modules/plot.dataset/api/plot_dataset_api_v4.tcl', 'plugins/modules/plot.dataset/api/plot_dataset_v4_cell_field.tcl', 'plugins/modules/plot.dataset/api/plot_dataset_v4_comparison.tcl', 'plugins/modules/plot.dataset/module.ini', 'plugins/modules/plot.dataset/plugin-package.ini', 'plugins/modules/preview.curve_digitizer/CHANGELOG.md', 'plugins/modules/preview.curve_digitizer/CORE_GAPS.md', 'plugins/modules/preview.curve_digitizer/MANUAL.md', 'plugins/modules/preview.curve_digitizer/README.md', 'plugins/modules/preview.curve_digitizer/RELEASE_VALIDATION.md', 'plugins/modules/preview.curve_digitizer/SHA256SUMS.txt', 'plugins/modules/preview.curve_digitizer/api/preview.tcl', 'plugins/modules/preview.curve_digitizer/api/table_preview.tcl', 'plugins/modules/preview.curve_digitizer/gui/design.tcldict', 'plugins/modules/preview.curve_digitizer/gui/table_design.tcldict', 'plugins/modules/preview.curve_digitizer/module.ini', 'plugins/modules/preview.curve_digitizer/plugin-package.ini', 'plugins/modules/preview.curve_digitizer/tests/test_builder_design_012.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_compact_toolbar_018.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_point_id_019.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_preview_async_012.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_preview_dispatch_014.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_preview_y2_016.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_table_preview_017.tcl', 'plugins/modules/preview.curve_digitizer/tests/test_uncertainty_cache_020.tcl', 'plugins/modules/viewer.comparison_example/LICENSE', 'plugins/modules/viewer.comparison_example/MANUAL.md', 'plugins/modules/viewer.comparison_example/RESTRICTED_VIEWER_PROVENANCE.json', 'plugins/modules/viewer.comparison_example/SHA256SUMS.txt', 'plugins/modules/viewer.comparison_example/api/viewer.tcl', 'plugins/modules/viewer.comparison_example/gui/design.tcldict', 'plugins/modules/viewer.comparison_example/handlers.tcl', 'plugins/modules/viewer.comparison_example/module.ini', 'plugins/modules/viewer.comparison_example/native/SDK_CONTRACT.json', 'plugins/modules/viewer.comparison_example/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/viewer.comparison_example/native/trusted_adapter_v1.cpp', 'plugins/modules/viewer.comparison_example/native/viewer.so', 'plugins/modules/viewer.comparison_example/plugin-package.ini', 'plugins/modules/viewer.comparison_example/review/build.json', 'plugins/modules/viewer.comparison_example/review/validation.json', 'plugins/modules/viewer.comparison_example/source/MANUAL.md', 'plugins/modules/viewer.comparison_example/source/SOURCE_MANIFEST.json', 'plugins/modules/viewer.comparison_example/source/design.gxtxt-viewer', 'plugins/modules/viewer.comparison_example/source/handlers.cpp', 'plugins/modules/viewer.comparison_example/source/include/comparison_client.hpp', 'plugins/modules/viewer.comparison_example/source/project.json', 'plugins/modules/viewer.comparison_example/source/src/comparison_client.cpp', 'plugins/modules/viewer.curve_digitizer/ASSISTED_TRACING_DESIGN.md', 'plugins/modules/viewer.curve_digitizer/CALIBRATION_API_v1.md', 'plugins/modules/viewer.curve_digitizer/CHANGELOG.md', 'plugins/modules/viewer.curve_digitizer/CURVE_DATASET_SCHEMA_API_v1.md', 'plugins/modules/viewer.curve_digitizer/IMAGE_PROCESSING_API_v1.md', 'plugins/modules/viewer.curve_digitizer/LICENSE', 'plugins/modules/viewer.curve_digitizer/MANUAL.md', 'plugins/modules/viewer.curve_digitizer/QUALITY_API_v2.md', 'plugins/modules/viewer.curve_digitizer/README.md', 'plugins/modules/viewer.curve_digitizer/RELEASE_VALIDATION.md', 'plugins/modules/viewer.curve_digitizer/SHA256SUMS.txt', 'plugins/modules/viewer.curve_digitizer/STROKE_WIDTH_API_v1.md', 'plugins/modules/viewer.curve_digitizer/UNCERTAINTY_API_v1.md', 'plugins/modules/viewer.curve_digitizer/api/configuration_schema.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_calibration_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_companion_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_core_consumers.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_dataset_schema_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_factor_guard.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_image_processing_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_numeric_core.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_quality_api_v2.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_stroke_width_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_uncertainty_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/curve_digitizer_viewer_api_v1.tcl', 'plugins/modules/viewer.curve_digitizer/api/script_bridge_binding.py', 'plugins/modules/viewer.curve_digitizer/api/workspace_provider.tcl', 'plugins/modules/viewer.curve_digitizer/icons/curve_digitizer.png', 'plugins/modules/viewer.curve_digitizer/icons/curve_digitizer.svg', 'plugins/modules/viewer.curve_digitizer/module.ini', 'plugins/modules/viewer.curve_digitizer/plugin-package.ini', 'plugins/modules/viewer.curve_digitizer/python/assisted_constraints.py', 'plugins/modules/viewer.curve_digitizer/python/assisted_exclusion_ui.py', 'plugins/modules/viewer.curve_digitizer/python/assisted_sampling.py', 'plugins/modules/viewer.curve_digitizer/python/assisted_tracing.py', 'plugins/modules/viewer.curve_digitizer/python/auto_enhancement.py', 'plugins/modules/viewer.curve_digitizer/python/calibration_manifest.py', 'plugins/modules/viewer.curve_digitizer/python/calibration_verification.py', 'plugins/modules/viewer.curve_digitizer/python/calibration_verification_dialog.py', 'plugins/modules/viewer.curve_digitizer/python/companion_bridge.py', 'plugins/modules/viewer.curve_digitizer/python/digitizer_model.py', 'plugins/modules/viewer.curve_digitizer/python/gxtxt_curve_digitizer.py', 'plugins/modules/viewer.curve_digitizer/python/image_canvas.py', 'plugins/modules/viewer.curve_digitizer/python/image_processing.py', 'plugins/modules/viewer.curve_digitizer/python/point_ordering.py', 'plugins/modules/viewer.curve_digitizer/python/processing_controls.py', 'plugins/modules/viewer.curve_digitizer/python/publication_planning.py', 'plugins/modules/viewer.curve_digitizer/python/publication_y2.py', 'plugins/modules/viewer.curve_digitizer/python/quality_diagnostics.py', 'plugins/modules/viewer.curve_digitizer/python/scale_bar.py', 'plugins/modules/viewer.curve_digitizer/python/stroke_width_measure.py', 'plugins/modules/viewer.curve_digitizer/python/stroke_width_ui.py', 'plugins/modules/viewer.curve_digitizer/python/uncertainty_dialog.py', 'plugins/modules/viewer.curve_digitizer/python/uncertainty_engine.py', 'plugins/modules/viewer.curve_digitizer/requirements.txt', 'plugins/modules/viewer.curve_digitizer/tests/test_assisted_constraints_205.py', 'plugins/modules/viewer.curve_digitizer/tests/test_assisted_count_1223_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_assisted_sampling_1223.py', 'plugins/modules/viewer.curve_digitizer/tests/test_assisted_tracing.py', 'plugins/modules/viewer.curve_digitizer/tests/test_assisted_tracing_advanced.py', 'plugins/modules/viewer.curve_digitizer/tests/test_assisted_tracing_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_api_extended.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_identity.py', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_inline_layout_2023_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_replicates.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_scrolling_2012_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_verification_2022.py', 'plugins/modules/viewer.curve_digitizer/tests/test_calibration_verification_gui_2022.py', 'plugins/modules/viewer.curve_digitizer/tests/test_catalog_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_catalog_namespace.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_comparison_initial_fit_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_core_configuration.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_core_guidance.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_core_inline_202.py', 'plugins/modules/viewer.curve_digitizer/tests/test_core_settings_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_curve_dataset_schema.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_curve_dataset_schema_y2_2024.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_curves_list_and_proposal_order_1227_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_curves_scrolling_1229_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_curves_two_column_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_dataset_notes_export.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_density_partial_1223.py', 'plugins/modules/viewer.curve_digitizer/tests/test_exclusion_persistence_2019_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_exclusion_undo_206.py', 'plugins/modules/viewer.curve_digitizer/tests/test_far_correction_1224_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_full_factor_consistency_203.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_group_legacy_multicalibration_2024.py', 'plugins/modules/viewer.curve_digitizer/tests/test_guided_edit_and_appearance_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_guides_before_proposal_2013_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_image_processing_api.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_image_processing_bridge.py', 'plugins/modules/viewer.curve_digitizer/tests/test_image_processing_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_image_publication.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_manager_actions_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_measurement_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_multi_publish_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_naming_template_validation.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_numeric_core_guard_201.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_numeric_public_only_202.py', 'plugins/modules/viewer.curve_digitizer/tests/test_ordering_settings_1222_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_point_ordering_1222_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_processing_comparison_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_proposal_context_and_session_restore_1226.py', 'plugins/modules/viewer.curve_digitizer/tests/test_proposal_zoom_and_corrections_2015_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_publication_classification_2020.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_publication_manifest.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_publication_planning.py', 'plugins/modules/viewer.curve_digitizer/tests/test_publication_three_curves_2020_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_quality_api_v2.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_quality_v2.py', 'plugins/modules/viewer.curve_digitizer/tests/test_raster_points_api.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_repeated_calibration.py', 'plugins/modules/viewer.curve_digitizer/tests/test_session_refresh_and_output_1225.py', 'plugins/modules/viewer.curve_digitizer/tests/test_settings_apply_1223_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_smooth_prior_effect_2014.py', 'plugins/modules/viewer.curve_digitizer/tests/test_smoothing_mode_refresh_2014_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_step_20_2018_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_step_range_and_quality_2018.py', 'plugins/modules/viewer.curve_digitizer/tests/test_stroke_companion_208.py', 'plugins/modules/viewer.curve_digitizer/tests/test_stroke_curve_switch_209.py', 'plugins/modules/viewer.curve_digitizer/tests/test_stroke_measure_209.py', 'plugins/modules/viewer.curve_digitizer/tests/test_stroke_width_208.py', 'plugins/modules/viewer.curve_digitizer/tests/test_stroke_width_public_208.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_trace_ground_truth_2017.py', 'plugins/modules/viewer.curve_digitizer/tests/test_tracing_ui_206.py', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_api_v2.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_dialog_200_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_dual_y_f5.py', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_f5_backend.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_f5_dialog_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_f5_publication_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_f5_transport.py', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_f5_transport.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_publication_v2.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_uncertainty_v2.py', 'plugins/modules/viewer.curve_digitizer/tests/test_unified_history_206.py', 'plugins/modules/viewer.curve_digitizer/tests/test_workspace_config_2016_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_workspace_rename_2016.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f1_companion.py', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f1_gui_bridge.py', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f2_gui.py', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f2_log_scale.py', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f3_gui_publication.py', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f3_planning.py', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_f3_publication_api.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_group_producer_2024.tcl', 'plugins/modules/viewer.curve_digitizer/tests/test_y2_model_f1.py', 'plugins/modules/viewer.interface_builder/CHANGELOG.md', 'plugins/modules/viewer.interface_builder/SHA256SUMS.txt', 'plugins/modules/viewer.interface_builder/api/builder.tcl', 'plugins/modules/viewer.interface_builder/module.ini', 'plugins/modules/viewer.interface_builder/plugin-package.ini'])

def payload_path(name):
    relative(name)
    return name in PAYLOAD_SCOPE

def root_path(root):
    root = Path(os.path.abspath(root))
    for p in [*reversed(root.parents), root]:
        require(not p.is_symlink(), 'Linked framework root/ancestor: ' + str(p))
    require(root.is_dir(), 'Existing canonical framework directory required')
    return root

def member(root, name):
    current = root
    parts = relative(name).parts
    for index, part in enumerate(parts):
        current = current / part
        require(not current.is_symlink(), 'Linked target/ancestor: ' + str(current))
        if current.exists() and index < len(parts)-1:
            require(current.is_dir(), 'Non-directory ancestor: ' + str(current))
    return current

def identity(path):
    try:
        st = path.lstat()
    except FileNotFoundError:
        return None
    require(stat.S_ISREG(st.st_mode) and st.st_nlink == 1, 'Nonregular/linked target: ' + str(path))
    return {'sha256': sha(path), 'mode': stat.S_IMODE(st.st_mode), 'size': st.st_size}

def matches(actual, expected):
    return actual == expected

def zip_index(z):
    entries = {}
    directories = set()
    for item in z.infolist():
        require(not item.flag_bits & 1, 'Encrypted ZIP unsupported')
        name = item.filename.rstrip('/') if item.is_dir() else item.filename
        relative(name)
        require(name not in entries and name not in directories, 'Duplicate ZIP member: ' + name)
        mode = item.external_attr >> 16
        if item.is_dir():
            require(stat.S_IFMT(mode) in (0, stat.S_IFDIR), 'Invalid ZIP directory')
            directories.add(name)
            continue
        require(stat.S_IFMT(mode) in (0, stat.S_IFREG) and not stat.S_ISLNK(mode), 'Nonregular ZIP member: ' + name)
        require(item.file_size <= MAX_FILE, 'Oversized ZIP member: ' + name)
        entries[name] = item
    require(sum(x.file_size for x in entries.values()) <= MAX_ZIP, 'ZIP exceeds patch bound')
    for name in set(entries) | directories:
        require(all(str(p) not in entries for p in PurePosixPath(name).parents if str(p) != '.'), 'ZIP file/directory collision')
    require(z.testzip() is None, 'ZIP CRC failure')
    return entries

def file_record(value, nullable=False):
    if value is None:
        require(nullable, 'Required file identity is absent')
        return
    require(isinstance(value, dict) and set(value) == {'sha256', 'mode', 'size'}, 'Invalid file identity fields')
    require(isinstance(value['sha256'], str) and len(value['sha256']) == 64 and all(c in '0123456789abcdef' for c in value['sha256']), 'Invalid SHA256')
    require(type(value['mode']) is int and 0 <= value['mode'] <= 0o777, 'Invalid file mode')
    require(type(value['size']) is int and 0 <= value['size'] <= MAX_FILE, 'Invalid file size')

def validate(manifest, closure):
    require(isinstance(manifest, dict) and isinstance(closure, dict), 'Manifest/closure must be objects')
    require(manifest.get('schema') == 'gxtxt.dev111.p034.overlay.v1' and manifest.get('patch') == PATCH and manifest.get('baseline_patch') == 'DEV111-P033' and manifest.get('baseline_commit') == BASE and manifest.get('baseline_archive_sha256') == BASE_SHA, 'Wrong patch or exact P033 predecessor identity')
    require(isinstance(manifest.get('source_commit'), str) and len(manifest['source_commit']) == 40 and all(c in '0123456789abcdef' for c in manifest['source_commit']), 'Invalid source commit')
    require(closure.get('schema') == 'gxtxt.dev111.p034.baseline.v1' and closure.get('source_commit') == BASE and closure.get('archive_sha256') == BASE_SHA and isinstance(closure.get('files'), dict) and closure['files'], 'Invalid predecessor closure')
    require('core/tcl/plugin_install_api_v1.tcl' in closure['files'], 'Missing baseline sentinel')
    require(digest(json_bytes(closure)) == manifest.get('baseline_closure_sha256'), 'Baseline closure checksum differs')
    for name, expected in closure['files'].items():
        require(runtime_path(name), 'Non-runtime predecessor path: ' + name); file_record(expected)
    rows = manifest.get('changed_files')
    require(isinstance(rows, list) and rows, 'Nonempty change manifest required')
    seen = set()
    for row in rows:
        require(set(row) == {'path', 'action', 'before', 'after'}, 'Invalid change fields')
        name = row['path'];relative(name)
        require(payload_path(name), 'Protected/non-runtime payload path: ' + name)
        require(name not in seen and not name.startswith('patch_notes/'), 'Duplicate/reserved product path')
        seen.add(name);file_record(row['before'], True);file_record(row['after'], True)
        expected_action = 'add' if row['before'] is None else 'delete' if row['after'] is None else 'replace'
        require(row['action'] == expected_action and row['before'] != row['after'], 'Invalid or unchanged change action')
        require(closure['files'].get(name) == row['before'], 'Change preimage differs from exact baseline closure: ' + name)
    require(manifest.get('deleted_files') == [r['path'] for r in rows if r['after'] is None], 'Deletion list differs')
    return rows

def sums(text):
    result = {}
    for line in text.decode('utf-8').splitlines():
        value, name = line.split('  ', 1);relative(name)
        require(name not in result and len(value) == 64 and all(c in '0123456789abcdef' for c in value), 'Invalid checksum entry')
        result[name] = value
    return result

def archive_data(path, expected_sha=None):
    path = Path(path)
    require(not path.is_symlink() and path.is_file(), 'Regular patch ZIP required')
    if expected_sha is None:
        sidecar = Path(str(path) + '.sha256')
        require(not sidecar.is_symlink() and sidecar.is_file(), 'Provide adjacent ZIP.sha256 or --sha256')
        words = sidecar.read_text().split()
        require(len(words) == 2 and words[1] == path.name, 'Invalid archive checksum sidecar')
        expected_sha = words[0]
    require(sha(path) == expected_sha, 'Patch ZIP SHA256 differs')
    with zipfile.ZipFile(path) as z:
        entries = zip_index(z)
        require(NOTES + '/FILES.json' in entries and NOTES + '/BASELINE.json' in entries, 'Missing P034 notes/closure')
        data = {name: z.read(name) for name in entries}
        manifest = json.loads(data[NOTES + '/FILES.json']);closure = json.loads(data[NOTES + '/BASELINE.json'])
        rows = validate(manifest, closure)
        required_notes = {NOTES + '/' + n for n in NOTE_FILES} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
        require({n for n in data if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected P034 notes')
        for name in required_notes:
            if not name.startswith(NOTES + '/rollback-preimages/'):
                require(((entries[name].external_attr >> 16) & 0o777) == 0o644, 'Wrong notes/helper mode: ' + name)
        build = json.loads(data[NOTES + '/BUILD_IDENTITY.json'])
        require(build.get('original_input_archives') == SUPPLIED_INPUT_ARCHIVES,
                'P034 must not introduce original-input archives')
        supplied = json.loads(data[NOTES + '/SUPPLIED_INPUTS.json'])
        require(supplied == {}, 'P034 must not duplicate inherited supplemental inputs')
        require(build.get('patch') == PATCH and build.get('source_commit') == manifest['source_commit']
                and build.get('packaging_helpers_commit') == manifest['source_commit']
                and build.get('baseline_commit') == BASE and build.get('baseline_archive_sha256') == BASE_SHA
                and build.get('native_changes') is True and build.get('packaging_rebuilt_binaries') is False
                and build.get('owner_supplied_qualifications') == OWNER_QUALIFICATIONS,
                'Build/source/helper identity differs')
        for leaf in ('apply.py', 'rollback.py', 'release_common.py', 'companion_preflight.py'):
            expected = build['helper_source_files']['validation/dev111_p034_release/' + leaf]
            file_record(expected)
            raw = data[NOTES + '/' + leaf]
            require(digest(raw) == expected['sha256'] and len(raw) == expected['size'], 'Bundled helper source identity differs: ' + leaf)
        matrix = json.loads(data[NOTES + '/MODULE_VERSION_MATRIX.json'])
        require(matrix.get('patch') == PATCH and len(matrix['modules']) == len(MODULES)
                and {m['module']: m['distribution_version'] for m in matrix['modules']} == MODULES,
                'P034 companion module matrix differs')
        for row in matrix['modules']:
            module = row['module']
            if module in ORIGINAL_MODULES:
                require(row.get('original_sha256') == ORIGINAL_PACKAGE_SHA[module]
                        and row.get('original_filename') == module_archive_name(module, MODULES[module]),
                        'Original companion container identity differs: ' + module)
                if module in OWNER_QUALIFICATIONS:
                    require(row.get('qualification') == OWNER_QUALIFICATIONS[module],
                            'Owner testing exception differs: ' + module)
        require(json.loads(data[NOTES + '/DELETIONS.json']) == manifest['deleted_files'], 'Deletion notes differ')
        listed = sums(data[NOTES + '/PAYLOAD_SHA256SUMS'])
        require(set(listed) == set(data) - {NOTES + '/PAYLOAD_SHA256SUMS'}, 'Incomplete archive checksums')
        for name, expected in listed.items():
            require(digest(data[name]) == expected, 'Archive checksum differs: ' + name)
        products = {r['path'] for r in rows if r['after'] is not None}
        require(set(data) == products | {n for n in data if n.startswith(NOTES + '/')}, 'Unexpected product member')
        for row in rows:
            for key, name in [('after', row['path']), ('before', NOTES + '/rollback-preimages/' + row['path'])]:
                record = row[key]
                if record is None:
                    continue
                require(name in data and digest(data[name]) == record['sha256'] and len(data[name]) == record['size'] and ((entries[name].external_attr >> 16) & 0o777) == record['mode'], 'Invalid ' + key + ': ' + row['path'])
        return manifest, closure, rows, data, entries

def guard_baseline(root, closure, rows, rollback=False, partial=False):
    changed = {r['path']: r for r in rows}
    for name, expected in closure['files'].items():
        actual = identity(member(root, name));row = changed.get(name)
        if row is None or not rollback:
            require(matches(actual, expected), 'Divergent P033 baseline: ' + name)
    for row in rows:
        actual = identity(member(root, row['path']))
        wanted = row['after'] if rollback else row['before']
        permitted = [wanted, row['before']] if rollback and partial else [wanted]
        require(any(matches(actual, p) for p in permitted), 'Unknown/divergent ' + ('postimage' if rollback else 'preimage') + ': ' + row['path'])

def atomic(path, data, mode):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.p034-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            f.write(data);f.flush();os.fchmod(f.fileno(), mode);os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):os.unlink(temp)

def _apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    manifest, closure, rows, data, entries = archive_data(archive, expected_sha)
    require(not member(root, NOTES).exists(), 'P034 notes already exist; use rollback/recover-partial first')
    guard_baseline(root, closure, rows)
    for name in data:member(root, name)
    if mutate:
        # Publish complete verified rollback information before any product write.
        for name in sorted(data):
            if name.startswith(NOTES + '/'):
                atomic(member(root, name), data[name], (entries[name].external_attr >> 16) & 0o777)
        for row in rows:
            p = member(root, row['path'])
            require(identity(p) == row['before'], 'Preimage changed during apply: ' + row['path'])
            if row['after'] is None:p.unlink()
            else:atomic(p, data[row['path']], row['after']['mode'])
        guard_baseline(root, closure, rows, rollback=True)
    return manifest

def _rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root);notes = member(root, NOTES)
    require(notes.is_dir(), 'Installed P034 notes required')
    manifest_path = member(root, NOTES + '/FILES.json');closure_path = member(root, NOTES + '/BASELINE.json')
    require(identity(manifest_path) is not None and identity(closure_path) is not None, 'Incomplete notes; recover verified notes from the exact archive first')
    manifest = json.loads(manifest_path.read_bytes());closure = json.loads(closure_path.read_bytes());rows = validate(manifest, closure)
    checksum_path = member(root, NOTES + '/PAYLOAD_SHA256SUMS')
    checksum_identity = identity(checksum_path)
    require(checksum_identity is not None and checksum_identity['mode'] == 0o644,
            'Installed checksum manifest must be an unlinked regular0644 file')
    listed = sums(checksum_path.read_bytes())
    required_notes = {NOTES + '/' + n for n in NOTE_FILES - {'PAYLOAD_SHA256SUMS'}} | {NOTES + '/rollback-preimages/' + r['path'] for r in rows if r['before'] is not None}
    require({n for n in listed if n.startswith(NOTES + '/')} == required_notes, 'Incomplete/unexpected installed notes inventory')
    for name, expected in listed.items():
        if name.startswith(NOTES + '/'):
            p = member(root, name)
            require(identity(p) is not None and sha(p) == expected, 'Incomplete/divergent installed notes: ' + name)
            expected_mode = 0o644
            if name.startswith(NOTES + '/rollback-preimages/'):
                product = name[len(NOTES + '/rollback-preimages/'):]
                expected_mode = next(r['before']['mode'] for r in rows if r['path'] == product and r['before'] is not None)
            require(identity(p)['mode'] == expected_mode, 'Installed notes mode differs: ' + name)
    require(NOTES + '/FILES.json' in listed and NOTES + '/BASELINE.json' in listed, 'Unbound installed manifest')
    guard_baseline(root, closure, rows, rollback=True, partial=partial)
    for row in rows:
        if row['before'] is not None:
            p = member(root, NOTES + '/rollback-preimages/' + row['path'])
            require(identity(p) == row['before'], 'Rollback preimage/mode differs: ' + row['path'])
    if mutate:
        for row in reversed(rows):
            p = member(root, row['path']);actual = identity(p)
            require(actual == row['after'] or partial and actual == row['before'], 'Target changed during rollback: ' + row['path'])
            if actual == row['before']:continue
            if row['before'] is None:p.unlink()
            else:
                backup = member(root, NOTES + '/rollback-preimages/' + row['path'])
                atomic(p, backup.read_bytes(), row['before']['mode'])
        guard_baseline(root, closure, rows)
    return manifest

@contextmanager
def operation_lock(root, enabled):
    if not enabled:
        yield
        return
    try:
        import fcntl
    except ImportError as error:
        raise GuardError('Guarded writes require POSIX directory locking; --check remains available') from error
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY)
    try:
        try:fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:raise GuardError('Another release helper owns this framework directory') from error
        yield
    finally:os.close(fd)

def apply_overlay(root, archive, mutate=False, expected_sha=None):
    root = root_path(root)
    with operation_lock(root, mutate):return _apply_overlay(root, archive, mutate, expected_sha)

def rollback_overlay(root, mutate=False, partial=False):
    root = root_path(root)
    with operation_lock(root, mutate):return _rollback_overlay(root, mutate, partial)
