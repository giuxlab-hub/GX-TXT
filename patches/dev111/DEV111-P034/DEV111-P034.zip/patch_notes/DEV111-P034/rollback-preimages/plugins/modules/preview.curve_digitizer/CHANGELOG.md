# 0.1.5 — DEV111-P031

P0310.1.5 is a separately versioned presentation correction of the retained
owner0.1.4 input: two control-character caption separators become em dashes,
and the readonly Dataset identity wraps without taking half the curve-list
width. The runtime api/preview.tcl and all scientific/schema/Plot operations
remain byte-identical to0.1.4. Original ZIP SHA256 c07ae52b27dd81737eb2f95acaf842eb56e6c48f6eccdc6722b41d854335cfac.
Independent final P031 acceptance is required; the original historical
validation below is not claimed as acceptance of this corrective package.

## 0.1.4 — Explicit Curves selection and Preview lifecycle

- Initialize the Curves list with a clear, non-scientific placeholder
  instead of an unexplained blank box. Clicking it triggers the same
  source-bound Load action as the Load curves button.
- Keep scientific reads OUT of guiMount; the first user action schedules
  the existing bounded cooperative page reader.
- No CORE cache extension, no changes to scientific Dataset/Session data;
  native Plot v4 continues to own rendering.

## 0.1.4 — Tcl Preview action dispatch validation

- Fix a Tcl switch parsing error in the Preview controls dispatcher.
  The previous inline ';#' comment was parsed as extra switch patterns,
  breaking every action originating from the Curves GUI.
- Preserve the existing Tk GUI layout, separate canonical table and native
  Plot Dataset API v4 renderer. No CORE or Dataset changes.
- Add an explicit regression of the actual generated GUI event callback,
  covering Load curves, passive selection and Plot v4 visibility.

## 0.1.4

- GUI: async-cooperative canonical page scan with a bounded work step per
  Tk event, progress status, stale Session/source cancellation and disposal.
- CORE Native2D C++ Plot API v4 remains the exclusive graph renderer.
- Repeated Load cancels its prior coroutine. No nested update(), no CORE
  thread/scheduler override, no direct private scientific file I/O.
- More compact Curve selector, stable GUI control identity.

## 0.1.4

- Correct the Preview-target GUI design contract syntax: the real
  GX-TXT Builder validator requires semicolon-separated Dataset contracts.
- This repairs the observed GUI mount refusal:
  Invalid canonical Dataset contract ID.
- Add live-host design validation and regression guarding the serialized
  GUI design (previous synthetic stub allowed invalid contract strings).
- Preserve all 0.1.0 preview functionality; no CORE changes.

## 0.1.4

- Three-tab read-only Dataset Preview contribution, independent install.
- Preview-target Viewer Interface Builder GUI, native Plot Dataset API v4.
- Source-bound per-curve/calibration visibility; published quality metadata.
- Canonical CORE Dataset Preview table, no private dataset readers.
- No CORE edits.
