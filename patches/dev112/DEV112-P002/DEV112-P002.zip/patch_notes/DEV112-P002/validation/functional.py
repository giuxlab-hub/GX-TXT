#!/usr/bin/env python3
"""Actual private graphical functional validation against canonical Datasets."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile


def main():
    work, out = (Path(x).resolve() for x in sys.argv[1:])
    assert not out.exists()
    out.mkdir()
    framework = work / 'framework'
    receipt = json.loads((work/'unified_project/derived/candidate.json').read_text())
    package = Path(receipt['package'])
    assert hashlib.sha256(package.read_bytes()).hexdigest() == receipt['sha256']
    target = framework/'plugins/modules/viewer.unified_document_extraction'
    original = work/'original_unified_module'
    if not original.exists():
        shutil.move(target, original)
    elif target.exists():
        shutil.move(target, out/'previous_candidate')
    with zipfile.ZipFile(package) as archive:
        for name in archive.namelist():
            assert not name.startswith('/') and '..' not in Path(name).parts
        archive.extractall(out/'exported')
    descriptors = list((out/'exported').rglob('module.ini'))
    assert len(descriptors) == 1
    shutil.copytree(descriptors[0].parent, target)
    # Preserve historical source requests verbatim; no TODO is closed by export.
    requests = original/'source/requests'
    if requests.exists():
        shutil.copytree(requests,target/'source/requests',dirs_exist_ok=True)
    checksum = target/'SHA256SUMS.txt'
    checksum.write_text(''.join(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(target))+'\n' for path in sorted(target.rglob('*')) if path.is_file() and path != checksum))
    for previous in original.rglob('*'):
        current = target/previous.relative_to(original)
        if previous.is_file() and current.is_file():
            current.chmod(previous.stat().st_mode & 0o777)
    fixtures = out/'fixtures' 
    fixtures.mkdir()
    from reportlab.pdfgen.canvas import Canvas
    from reportlab.lib.utils import ImageReader
    native = fixtures/'native.pdf'
    canvas = Canvas(str(native), pagesize=(612, 792))
    for page in range(1, 3):
        canvas.setFont('Helvetica-Bold', 18)
        canvas.drawString(60, 740, f'GX-TXT Document Validation Page {page}')
        canvas.setFont('Helvetica', 14)
        canvas.drawString(60, 700, 'Scientific sample measurements and recovery results.')
        for y, row in zip((640, 605, 570, 535),
                          [('Sample', 'Mass', 'Recovery'), ('A1', '10.5', '98.2'),
                           ('B2', '20.0', '97.4'), ('C3', '30.5', '99.1')]):
            for x, value in zip((60, 250, 420), row):
                canvas.drawString(x, y, value)
        canvas.drawString(60, 450, 'The quick brown fox jumps over the lazy dog.')
        canvas.showPage()
    canvas.save()
    subprocess.run(['pdftoppm','-f','1','-l','1','-singlefile','-r','200','-png',str(native),str(fixtures/'scan')],check=True)
    scanned = Canvas(str(fixtures/'scanned.pdf'), pagesize=(612,792))
    scanned.drawImage(ImageReader(str(fixtures/'scan.png')),0,0,width=612,height=792)
    scanned.showPage(); scanned.save()
    env=os.environ.copy(); env['PYTHONDONTWRITEBYTECODE']='1'
    for key,name in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime'),('TMPDIR','tmp')]:
        path=out/name;path.mkdir(mode=0o700);env[key]=str(path)
    config=out/'config/gxtxt_pipeline';config.mkdir()
    (config/'configuration.ini').write_text('[user]\n'+''.join(k+'='+str(out/v)+'\n' for k,v in {'storage.session_root':'Sessions','storage.temp_dir':'tmp','storage.cache_dir':'cache','scripts.user_root':'scripts','libraries.scientific_root':'libraries'}.items()))
    command=['xvfb-run','-a','-s','-screen 0 1800x1200x24 -nolisten tcp','tclsh',str(Path(__file__).with_name('functional.tcl')),str(framework),str(out)]
    with (out/'gui.log').open('w') as log:
        result=subprocess.run(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=650)
    print(json.dumps(dict(returncode=result.returncode,evidence=str(out))))
    if result.returncode:
        print((out/'gui.log').read_text()[-6000:])
        raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
