# Actual graphical controls drive the installed private C++ candidate.
lassign $argv framework output
source [file join $framework gxtxt_pipeline.tcl]
proc record {name value} {set f [open [file join $::output $name] a];fconfigure $f -encoding utf-8;puts $f $value;close $f}
proc bgerror {message} {set ::bgfailure $::errorInfo;record background_error.txt $::errorInfo}
proc settle {{ms 80}} {after $ms {set ::settled 1};vwait ::settled;update;if {[info exists ::bgfailure]} {error $::bgfailure}}
proc check {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc heartbeat {} {incr ::beats;after 40 heartbeat}
proc capture {w name} {raise $w;settle 180;exec import -window [winfo id $w] [file join $::output $name.png]}
proc widget {id} {return [dict get $::GX::ViewerGui::instances $::w widgets $id]}
proc value {id val} {::GX::viewerGuiDesignValueSet $::w $id $val}
proc state {} {return [dict get $::GX::ViewerDocuments::forms [list $::w documents] state]}
proc action {id} {
    set start [clock milliseconds];set before $::beats
    set key [list $::w documents]
    if {[dict exists $::GX::ViewerDocuments::forms $key last_error]} {dict unset ::GX::ViewerDocuments::forms $key last_error}
    while {([dict get $::GX::ViewerDocuments::forms $key pending] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING}) && [clock milliseconds]<$start+45000} {settle}
    set result [[widget doc_$id] invoke]
    record dispatch.tsv [list $id $result]
    settle 150
    set limit [expr {$start+180000}]
    while {([dict get $::GX::ViewerDocuments::forms $key pending] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING}) && [clock milliseconds]<$limit} {settle}
    check {[dict get $::GX::ViewerDocuments::forms $key pending] eq {}} "Operation hung: $id"
    if {[dict exists $::GX::ViewerDocuments::forms $key last_error]} {error "$id: [dict get $::GX::ViewerDocuments::forms $key last_error]"}
    check {[dict get $::GX::ViewerDevelopment::windows $::w status] eq {COMPLETED}} "C++ action failed: $id [dict get $::GX::ViewerDevelopment::windows $::w last_result]"
    record actions.tsv [list $id [expr {[clock milliseconds]-$start}] [expr {$::beats-$before}] [state]]
}
proc tab {name} {[widget pages] select [widget $name];settle}
proc roi {values} {
    set key [list $::w documents];set c [widget preview].canvas
    set width [dict get $::GX::ViewerDocuments::forms $key display_width];set height [dict get $::GX::ViewerDocuments::forms $key display_height]
    lassign $values a b d e
    event generate $c <ButtonPress-1> -x [expr {int($a*$width)}] -y [expr {int($b*$height)}]
    event generate $c <B1-Motion> -x [expr {int($d*$width)}] -y [expr {int($e*$height)}]
    event generate $c <ButtonRelease-1> -x [expr {int($d*$width)}] -y [expr {int($e*$height)}]
    settle
    check {[dict get [state] roi] ne {}} {GUI region selection failed}
}
proc run {} {
    ::GX::defaults;::GX::loadModuleCatalog;::GX::launchGui
    wm geometry . 1500x1000+0+0;settle
    set ::session [::GX::createNewSession unified_functional {} 0]
    check {[string match $::output/* $::session]} {Private Session escaped evidence root}
    record session.txt $::session
    foreach {id file contract format media} {source.native native.pdf document.pdf pdf application/pdf source.scan scanned.pdf document.pdf pdf application/pdf source.image scan.png image.raster png image/png} {
        ::GX::datasetFilePublicationPublish $::session viewer.unified_document_extraction [dict create dataset_id $id source_file [file join $::output fixtures $file] contract $contract format $format storage_kind binary media_type $media]
    }
    set ::beats 0;heartbeat
    set ::w [::GX::viewerOpen viewer.unified_document_extraction unified_document_extraction]
    set deadline [expr {[clock milliseconds]+45000}]
    while {[winfo exists $::w.loading] && [clock milliseconds]<$deadline} {settle}
    check {![winfo exists $::w.loading]} {C++ Viewer preparation hung}
    check {[dict exists $::GX::ViewerGui::instances $::w]} {C++ Viewer not composed}
    wm geometry $::w 1650x1080+0+0;raise $::w;settle
    value source source.native;value dpi 200;action open_source
    check {[dict get [state] page_count]==2} {Wrong PDF page count}
    check {[dict get [state] width]==1700} {Wrong full-resolution width}
    capture $::w candidate_pdf
    action next;check {[dict get [state] page]==2} {Next page failed}
    action previous;check {[dict get [state] page]==1} {Previous page failed}
    action zoom_in;action zoom_out;action fit_width;action fit
    roi {0.07 0.17 0.94 0.35}
    capture $::w candidate_roi
    tab ocr_page;value ocr_engine {PDF OCR};value scope Region;action ocr
    check {[string match *Sample* [dict get [state] text]]} {Region OCR did not recognize the table header}
    record pdf_ocr_region.txt [dict get [state] text]
    set text [widget text_review].editor
    $text insert end "\nReviewed correction: verified.\n";event generate $text <<Modified>>
    value output_text unified.corrected;action publish_text
    set path [dict get [::GX::sessionInspectionDatasetPayload unified.corrected $::session] path]
    set f [open $path];set content [read $f];close $f
    check {[string match {*Reviewed correction: verified.*} $content]} {Corrected OCR text was not published}
    value scope Page;action ocr;record pdf_ocr_page.txt [dict get [state] text]
    value scope Document;action ocr;record pdf_ocr_document.txt [dict get [state] text]
    check {[string match {*Page 2*} [dict get [state] text]]} {Whole-PDF OCR omitted the second page}
    value ocr_engine {Document OCR};value method Native;value scope Document;action ocr
    record document_ocr_native.txt [dict get [state] text]
    capture $::w candidate_ocr
    tab tables_page;value table_engine {Table Extractor};value method Auto;value expected_columns 3;action table
    record native_table.tcldict [dict get [state] rows]
    check {[llength [dict get [state] rows]]==4} {Native table rows mismatch}
    check {[llength [lindex [dict get [state] rows] 0]]==3} {Native table columns mismatch}
    set tree [widget table_review].tree
    lassign [$tree bbox r1 c1] x y width height
    # Use the real double-click binding; event generate forbids Double modifiers.
    event generate $tree <ButtonPress-1> -x [expr {$x+10}] -y [expr {$y+10}]
    event generate $tree <ButtonRelease-1> -x [expr {$x+10}] -y [expr {$y+10}]
    event generate $tree <ButtonPress-1> -x [expr {$x+10}] -y [expr {$y+10}]
    event generate $tree <ButtonRelease-1> -x [expr {$x+10}] -y [expr {$y+10}]
    settle
    check {[winfo exists $tree.edit]} {Table cell editor did not open}
    $tree.edit delete 0 end;$tree.edit insert 0 11.25;event generate $tree.edit <Return>;settle
    check {[lindex [dict get [state] rows] 1 1] eq {11.25}} {Table edit was not committed}
    value output_table unified.corrected_table;action publish_table
    record published_table.tcldict [::GX::sessionInspectionDataset unified.corrected_table $::session]
    capture $::w candidate_table
    value table_engine {Document Tables};action table
    tab view_page;value source source.scan;action open_source;roi {0.07 0.17 0.94 0.35}
    tab tables_page;value method Auto;value table_engine {Table Extractor};action table
    record scanned_table.tcldict [dict get [state] rows]
    check {[dict get [state] table_context method] ne {pdf_native}} {Scanned PDF did not use OCR fallback}
    value table_engine {Document Tables};value method OCR;action table
    tab ocr_page;value ocr_engine {Document OCR};value method OCR;value scope Page;action ocr
    record scanned_ocr.txt [dict get [state] text]
    tab outputs_page;value output_pdf unified.searchable;action searchable_pdf
    set searchable [dict get [::GX::sessionInspectionDatasetPayload unified.searchable $::session] path]
    record searchable_qpdf.txt [exec qpdf --check $searchable]
    check {[string match *Sample* [exec pdftotext $searchable -]]} {Searchable PDF has no recognized text}
    value output_image unified.crop;action publish_image
    value output_image unified.page;action publish_page
    capture $::w candidate_outputs
    tab view_page;value source source.image;action open_source;roi {0.07 0.17 0.94 0.35}
    tab ocr_page;value scope Region;value ocr_engine {PDF OCR};action ocr
    tab tables_page;value table_engine {Table Extractor};value method OCR;action table
    record image_table.tcldict [dict get [state] rows]
    capture $::w candidate_image_table
    record final_state.tcldict [::GX::viewerGuiDesignCapture $::w]
    record complete.txt CANDIDATE_FUNCTIONAL_PASS
    destroy $::w;settle
}
set code [catch run result options]
if {$code} {record failure.txt [dict get $options -errorinfo];puts stderr [dict get $options -errorinfo]}
catch {::GX::stderrDiagnosticsShutdown}
destroy .
exit $code
