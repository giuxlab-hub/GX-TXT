lassign $argv framework sourcePdf output
file mkdir $output
source [file join $framework gxtxt_pipeline.tcl]
::GX::defaults
set base [::GX::TableExtractorAPIv1::inferSchema {matrix {{Name Value} {A 1}}}]
if {[lsort [dict keys $base]] ne [lsort {columns data_rows first_row_header}]} {error {Default schema result shape changed}}
set options {method auto dpi 200 psm 6 expected_columns 5 minimum_rows 2 minimum_columns 2 native_minimum_columns 5 split_repeated_headers 0 roi {0.07 0.17 0.94 0.35} roi_mode crop}
set fallback [::GX::TableExtractorAPIv1::extractPdfPage $sourcePdf 1 $options]
if {[dict get $fallback source method] ne {tesseract}} {error {Expected-column native acceptance did not fall back to OCR}}
if {[dict get $fallback table_count]!=1} {error {OCR fallback failed to preserve a valid smaller table}}
dict set options method native
set native [::GX::TableExtractorAPIv1::extractPdfPage $sourcePdf 1 $options]
if {[dict get $native table_count]!=0} {error {Native-only threshold accepted an insufficient table}}
set monthly [::GX::TableExtractorAPIv1::inferSchema {matrix {{{Annual measurements} {} {} {} {} {}} {January February March April May June} {1 2 3 4 5 6}}} {monthly_title_header 1}]
if {[dict get $monthly title] ne {Annual measurements} || [llength [dict get $monthly data_rows]]!=1} {error {Monthly title/header handling failed}}
set f [open [file join $output result.tcldict] w];puts $f [dict create status PASS default_schema $base fallback $fallback native_only $native monthly $monthly];close $f
puts SERVICE_COMPATIBILITY_PASS
