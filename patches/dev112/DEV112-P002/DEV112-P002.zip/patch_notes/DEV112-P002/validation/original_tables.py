#!/usr/bin/env python3
"""Run unchanged original Viewer GUIs with isolated configuration and display."""
import os
from pathlib import Path
import subprocess
import sys
framework,fixtures,out=(Path(x).resolve() for x in sys.argv[1:])
assert not out.exists();out.mkdir()
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
for key,name in [('XDG_CONFIG_HOME','config'),('XDG_CACHE_HOME','cache'),('XDG_DATA_HOME','data'),('XDG_STATE_HOME','state'),('XDG_RUNTIME_DIR','runtime'),('TMPDIR','tmp')]:
    path=out/name;path.mkdir(mode=0o700);env[key]=str(path)
config=out/'config/gxtxt_pipeline';config.mkdir()
(config/'configuration.ini').write_text('[user]\n'+''.join(k+'='+str(out/v)+'\n' for k,v in {'storage.session_root':'Sessions','storage.temp_dir':'tmp','storage.cache_dir':'cache','scripts.user_root':'scripts','libraries.scientific_root':'libraries'}.items()))
command=['xvfb-run','-a','-s','-screen 0 1800x1200x24 -nolisten tcp','tclsh',str(Path(__file__).with_suffix('.tcl')),str(framework),str(fixtures),str(out)]
with (out/'gui.log').open('w') as log:
    result=subprocess.run(command,env=env,cwd=out,stdout=log,stderr=subprocess.STDOUT,timeout=600)
print(result.returncode)
if result.returncode:print((out/'gui.log').read_text()[-5000:])
raise SystemExit(result.returncode)
