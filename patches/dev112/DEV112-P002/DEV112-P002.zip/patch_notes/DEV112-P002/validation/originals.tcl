# Read-only original Viewer GUI comparison; private test Session only.
lassign $argv framework fixtures output
source [file join $framework gxtxt_pipeline.tcl]
proc record {name value} {set f [open [file join $::output $name] a];fconfigure $f -encoding utf-8;puts $f $value;close $f}
proc settle {{ms 200}} {after $ms {set ::settled 1};vwait ::settled;update}
proc bgerror {message} {record background_error.txt $::errorInfo;set ::bgfailure $::errorInfo}
proc check {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc app {title} {
    set limit [expr {[clock milliseconds]+30000}]
    while {[clock milliseconds]<$limit} {
        foreach name [winfo interps] {
            if {![catch {send $name {wm title .}} result] && $result eq $title} {return $name}
        }
        settle
    }
    error "Original GUI did not open: $title"
}
proc remoteSetup {name} {
    send $name {
        proc validationWidgets {{w .}} {
            set result [list $w]
            foreach child [winfo children $w] {lappend result {*}[validationWidgets $child]}
            return $result
        }
        proc validationButton {label} {
            foreach w [validationWidgets] {
                if {![catch {$w cget -text} text] && $text eq $label && [winfo class $w] eq {TButton}} {return $w}
            }
            error "Button not found: $label"
        }
        proc validationNear {label} {
            foreach w [validationWidgets] {
                if {![catch {$w cget -text} text] && $text eq $label && [winfo class $w] eq {TLabel}} {
                    set peers [winfo children [winfo parent $w]]
                    return [lindex $peers [expr {[lsearch -exact $peers $w]+1}]]
                }
            }
            error "Field not found: $label"
        }
        proc validationField {label value} {
            set w [validationNear $label]
            set var [$w cget -textvariable]
            uplevel #0 [list set $var $value]
            event generate $w <<ComboboxSelected>>
        }
    }
}
proc remoteClick {name label} {
    set button [send $name [list validationButton $label]]
    set marker [file join $::output action_[clock microseconds].done]
    send -async $name [list apply {{button marker} {$button invoke;set f [open $marker w];puts $f completed;close $f}} $button $marker]
    set limit [expr {[clock milliseconds]+180000}]
    while {![file exists $marker] && [clock milliseconds]<$limit} {settle}
    check {[file exists $marker]} "Original action did not finish: $label"
    settle
    record original_actions.tsv [list $name $label]
}
proc remoteCapture {name file} {
    set id [send $name {raise .;update;winfo id .}]
    settle;exec import -window $id [file join $::output $file.png]
}
proc remoteText {name} {
    return [send $name {set result {};foreach w [validationWidgets] {if {[winfo class $w] eq {Text}} {append result [$w get 1.0 end-1c]}};set result}]
}
proc remoteRegion {name} {
    send $name {
        foreach c [validationWidgets] {
            if {[winfo class $c] ne {Canvas}} continue
            set bbox [$c bbox page]
            if {$bbox eq {}} {set bbox [$c bbox source]}
            if {$bbox eq {}} continue
            lassign $bbox left top right bottom
            set width [expr {$right-$left}];set height [expr {$bottom-$top}]
            set x1 [expr {int(.07*$width)}];set y1 [expr {int(.17*$height)}]
            set x2 [expr {int(.94*$width)}];set y2 [expr {int(.35*$height)}]
            event generate $c <ButtonPress-1> -x $x1 -y $y1
            event generate $c <B1-Motion> -x $x2 -y $y2
            event generate $c <ButtonRelease-1> -x $x2 -y $y2
            break
        }
    }
    settle
}
proc run {} {
    ::GX::defaults;::GX::loadModuleCatalog;::GX::launchGui
    wm geometry . 1440x900+0+0
    set ::session [::GX::createNewSession originals_comparison {} 0]
    check {[string match $::output/* $::session]} {Private Session escaped evidence root}
    foreach {id filename contract format media} {source.native native.pdf document.pdf pdf application/pdf source.scan scanned.pdf document.pdf pdf application/pdf source.image scan.png image.raster png image/png} {
        ::GX::datasetFilePublicationPublish $::session viewer.unified_document_extraction [dict create dataset_id $id source_file [file join $::fixtures $filename] contract $contract format $format storage_kind binary media_type $media]
    }
    ::GX::viewerOpen viewer.pdf_ocr pdf_ocr
    settle 5000
    set name [app {GX-TXT PDF OCR Viewer}];remoteSetup $name;settle 1500
    send $name {validationField {PDF Dataset:} source.native;validationField {DPI:} 200;validationField {Layout:} Block}
    remoteClick $name Load;remoteRegion $name;remoteClick $name {OCR selection}
    record pdf_ocr_region.txt [remoteText $name]
    remoteCapture $name original_pdf_ocr_region
    remoteClick $name {OCR whole page → Dataset};record pdf_ocr_page.txt [remoteText $name]
    remoteClick $name {OCR whole PDF → text Dataset};record pdf_ocr_document.txt [remoteText $name]
    remoteClick $name {Publish crop Dataset};remoteClick $name {Publish whole page Dataset}
    send $name {validationField {PDF Dataset:} source.scan}
    remoteClick $name Load;remoteClick $name {OCR whole PDF → PDF Dataset}
    record original_pdf_datasets.tcldict [::GX::sessionInspectionDatasetIds $::session]
    send $name {event generate . <<NoOperation>>}
    remoteClick $name Save
    record pdf_workspace.tcldict [::GX::nativeWorkspaceQuery pdf_ocr]
    send $name {destroy .};settle
    ::GX::viewerOpen viewer.table_extractor table_extractor
    settle 5000
    set name [app {GX-TXT Table Extractor}];remoteSetup $name;settle 1500
    record table_widgets.tcldict [send $name {set result {};foreach w [validationWidgets] {set row [list $w [winfo class $w]];foreach key {-text -values -textvariable} {if {![catch {$w cget $key} v]} {lappend row $key $v}};lappend result $row};set result}]
    remoteCapture $name original_table_initial
    record complete.txt ORIGINAL_PROBE_COMPLETED
}
set code [catch run result options]
if {$code} {record failure.txt [dict get $options -errorinfo];puts stderr [dict get $options -errorinfo]}
catch {::GX::stderrDiagnosticsShutdown}
destroy .
exit $code
