# Actual graphical controls drive the installed private C++ candidate.
lassign $argv framework fixtures output
source [file join $framework gxtxt_pipeline.tcl]
proc record {name value} {set f [open [file join $::output $name] a];fconfigure $f -encoding utf-8;puts $f $value;close $f}
proc bgerror {message} {set ::bgfailure $::errorInfo;record background_error.txt $::errorInfo}
proc settle {{ms 80}} {after $ms {set ::settled 1};vwait ::settled;update;if {[info exists ::bgfailure]} {error $::bgfailure}}
proc check {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc heartbeat {} {incr ::beats;after 40 heartbeat}
proc capture {w name} {raise $w;settle 180;exec import -window [winfo id $w] [file join $::output $name.png]}
proc widget {id} {return [dict get $::GX::ViewerGui::instances $::w widgets $id]}
proc value {id val} {::GX::viewerGuiDesignValueSet $::w $id $val}
proc state {} {return [dict get $::GX::ViewerDocuments::forms [list $::w documents] state]}
proc action {id} {
    set start [clock milliseconds];set before $::beats
    set key [list $::w documents]
    if {[dict exists $::GX::ViewerDocuments::forms $key last_error]} {dict unset ::GX::ViewerDocuments::forms $key last_error}
    while {([dict get $::GX::ViewerDocuments::forms $key pending] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING}) && [clock milliseconds]<$start+45000} {settle}
    set result [[widget doc_$id] invoke]
    record dispatch.tsv [list $id $result]
    settle 150
    set limit [expr {$start+180000}]
    while {([dict get $::GX::ViewerDocuments::forms $key pending] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING}) && [clock milliseconds]<$limit} {settle}
    check {[dict get $::GX::ViewerDocuments::forms $key pending] eq {}} "Operation hung: $id"
    if {[dict exists $::GX::ViewerDocuments::forms $key last_error]} {error "$id: [dict get $::GX::ViewerDocuments::forms $key last_error]"}
    check {[dict get $::GX::ViewerDevelopment::windows $::w status] eq {COMPLETED}} "C++ action failed: $id [dict get $::GX::ViewerDevelopment::windows $::w last_result]"
    record actions.tsv [list $id [expr {[clock milliseconds]-$start}] [expr {$::beats-$before}] [state]]
}
proc tab {name} {[widget pages] select [widget $name];settle}
proc roi {values} {
    set key [list $::w documents];set c [widget preview].canvas
    set width [dict get $::GX::ViewerDocuments::forms $key display_width];set height [dict get $::GX::ViewerDocuments::forms $key display_height]
    lassign $values a b d e
    event generate $c <ButtonPress-1> -x [expr {int($a*$width)}] -y [expr {int($b*$height)}]
    event generate $c <B1-Motion> -x [expr {int($d*$width)}] -y [expr {int($e*$height)}]
    event generate $c <ButtonRelease-1> -x [expr {int($d*$width)}] -y [expr {int($e*$height)}]
    settle
    check {[dict get [state] roi] ne {}} {GUI region selection failed}
}
proc ready {} {
    settle 150
    set limit [expr {[clock milliseconds]+60000}]
    while {([winfo exists $::w.loading] || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING} || ([dict exists $::GX::ViewerDocuments::forms [list $::w documents]] && [dict get $::GX::ViewerDocuments::forms [list $::w documents] pending] ne {})) && [clock milliseconds]<$limit} {settle}
    check {![winfo exists $::w.loading]} {C++ Viewer preparation hung}
}
proc run {} {
    ::GX::defaults;::GX::loadModuleCatalog;::GX::launchGui;settle
    set ::session [::GX::createNewSession extended_functional {} 0]
    check {[string match $::output/* $::session]} {Private Session escaped output}
    foreach {id file contract format media} {source.native native.pdf document.pdf pdf application/pdf source.scan scanned.pdf document.pdf pdf application/pdf source.image scan.png image.raster png image/png} {
        ::GX::datasetFilePublicationPublish $::session viewer.unified_document_extraction [dict create dataset_id $id source_file [file join $::fixtures $file] contract $contract format $format storage_kind binary media_type $media]
    }
    set ::beats 0;heartbeat
    set ::w [::GX::viewerOpen viewer.unified_document_extraction unified_document_extraction];ready
    wm geometry $::w 1440x900+0+0;settle
    value source source.native;value dpi 200;action open_source
    roi {0.07 0.17 0.94 0.35}
    set before [dict get [state] roi]
    set c [widget preview].canvas
    set key [list $::w documents]
    set dw [dict get $::GX::ViewerDocuments::forms $key display_width];set dh [dict get $::GX::ViewerDocuments::forms $key display_height]
    lassign $before a b d e
    set x [expr {int(($a+$d)*$dw/2)}];set y [expr {int(($b+$e)*$dh/2)}]
    event generate $c <ButtonPress-1> -x $x -y $y
    event generate $c <B1-Motion> -x [expr {$x+8}] -y [expr {$y+4}]
    event generate $c <ButtonRelease-1> -x [expr {$x+8}] -y [expr {$y+4}];settle
    set moved [dict get [state] roi]
    check {$before ne $moved} {ROI move failed}
    action zoom_in;check {[dict get [state] roi] eq $moved} {ROI drifted after zoom}
    action fit
    set dw [dict get $::GX::ViewerDocuments::forms $key display_width];set dh [dict get $::GX::ViewerDocuments::forms $key display_height]
    lassign $moved a b d e
    set x [expr {int($d*$dw)}];set y [expr {int($e*$dh)}]
    event generate $c <ButtonPress-1> -x $x -y $y
    event generate $c <B1-Motion> -x [expr {$x+6}] -y [expr {$y+5}]
    event generate $c <ButtonRelease-1> -x [expr {$x+6}] -y [expr {$y+5}];settle
    set resized [dict get [state] roi]
    check {$moved ne $resized} {ROI resize failed}
    record roi_states.tcldict [list original $before moved $moved resized $resized]
    capture $::w roi_moved_resized
    ::GX::viewerGuiDesignAction $::w undo;ready
    record history_undo.tcldict [state]
    check {[dict get [state] roi] eq $moved} {History undo did not restore ROI}
    ::GX::viewerGuiDesignAction $::w redo;ready
    check {[dict get [state] roi] eq $resized} {History redo did not restore ROI}
    tab ocr_page;value scope Page;action ocr
    set text [widget text_review].editor;$text insert end "\nSaved review correction.\n";event generate $text <<Modified>>;event generate $text <FocusOut>;settle
    tab tables_page;value expected_columns 3;action table
    set snapshot [state]
    set menu [widget workspace];$menu invoke 2;settle
    set id [dict get $::GX::ViewerGui::instances $::w workspace_id]
    check {$id ne {}} {Workspace Save did not associate an ID}
    record workspace_saved.tcldict [::GX::sessionWorkspaceGet $id]
    capture $::w workspace_saved
    $menu invoke 6;settle
    check {![winfo exists $::w]} {Normal Workspace close did not close Viewer}
    set ::w [::GX::sessionWorkspaceOpen $id];ready
    check {[dict get [state] rows] eq [dict get $snapshot rows]} {Workspace table review did not persist}
    check {[dict get [state] text] eq [dict get $snapshot text]} {Workspace corrected text did not persist}
    check {[dict get [state] roi] eq [dict get $snapshot roi]} {Workspace ROI did not persist}
    capture $::w workspace_reopened
    foreach {size name} {1024x768 compact 1440x900 normal} {
        wm geometry $::w $size;settle
        foreach page {view_page ocr_page tables_page outputs_page} {tab $page;capture $::w ${name}_$page}
    }
    value source source.missing
    set code [catch {action open_source} message];check {$code} {Missing source was accepted};record missing_source.txt $message
    value source source.image;action open_source
    set path [dict get [::GX::sessionInspectionDatasetPayload source.image $::session] path]
    set f [open $path ab];puts -nonewline $f {source-change-negative};close $f
    tab ocr_page;value scope Page
    set code [catch {action ocr} message];check {$code} {Changed source was accepted};record changed_source.txt $message
    # Public, realistic system documentation; no private scientific files.
    foreach {id path} {source.manual /usr/share/doc/shared-mime-info/shared-mime-info-spec.pdf source.large /usr/share/doc/octave/octave.pdf} {
        ::GX::datasetFilePublicationPublish $::session viewer.unified_document_extraction [dict create dataset_id $id source_file $path contract document.pdf format pdf storage_kind binary media_type application/pdf]
    }
    value source source.manual;value dpi 150;tab view_page;action open_source;capture $::w realistic_pdf
    tab ocr_page;value ocr_engine {Document OCR};value method Native;value scope Page;action ocr
    check {[string length [dict get [state] text]]>100} {Realistic PDF extraction was empty}
    record realistic_native_text.txt [dict get [state] text]
    value ocr_engine {PDF OCR};value method OCR;action ocr
    check {[string length [dict get [state] text]]>100} {Realistic PDF OCR was empty}
    record realistic_ocr_text.txt [dict get [state] text]
    value source source.large;value dpi 600;tab view_page
    [widget doc_open_source] invoke;settle 250
    check {[dict get $::GX::ViewerDocuments::forms [list $::w documents] pending] ne {}} {Large PDF request was not active}
    set before $::beats
    set code [catch {action cancel} message]
    record cancel.txt [list error $code message $message heartbeat_delta [expr {$::beats-$before}]]
    check {$::beats>$before} {GUI heartbeat stopped during cancellation}
    value source source.native;value dpi 200;action open_source
    # Start another owned request and close through the normal saved menu.
    value source source.large;value dpi 600;[widget doc_open_source] invoke;settle 250
    destroy $::w;settle 1500
    check {![dict exists $::GX::ViewerDocuments::forms [list $::w documents]]} {Closed Viewer retained a document operation}
    set ::w [::GX::viewerOpen viewer.unified_document_extraction unified_document_extraction];ready
    value source source.native;value dpi 200;action open_source;capture $::w reopened_after_cancel

    set input [open [file join [file dirname [info script]] catalog.tcldict]];set expectedCatalog [read $input];close $input
    dict for {id expected} $expectedCatalog {
        set provider [::GX::viewerProviderDefinition [dict get $expected module] [dict get $expected provider] 1]
        check {[dict get $provider semantic_group] eq [dict get $expected group]} "P001 category was reverted: $id"
        check {[dict get $provider group_title] eq [dict get $expected title]} "P001 category title was reverted: $id"
        if {[dict get $provider icon_path] ne {}} {
            check {[file isfile [dict get $provider icon_path]]} "Missing cumulative catalog icon: $id"
            set photo [::GX::viewerCatalogIcon $provider]
            check {[image width $photo]>0} "Cumulative catalog icon did not load: $id"
        }
        record cumulative_catalog.tcldict [list $id $provider]
    }
    raise .;.top.nb select .top.nb.viewers;::GX::viewerGuiRefresh;settle
    capture . cumulative_catalog

    record complete.txt EXTENDED_FUNCTIONAL_PASS
    destroy $::w;settle
}
set code [catch run result options]
if {$code} {record failure.txt [dict get $options -errorinfo];puts stderr [dict get $options -errorinfo]}
catch {::GX::stderrDiagnosticsShutdown}
destroy .
exit $code
