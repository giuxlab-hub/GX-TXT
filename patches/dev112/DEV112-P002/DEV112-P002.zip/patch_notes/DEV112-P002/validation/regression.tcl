# Actual graphical controls drive the installed private C++ candidate.
lassign $argv framework fixtures output
source [file join $framework gxtxt_pipeline.tcl]
proc record {name value} {set f [open [file join $::output $name] a];fconfigure $f -encoding utf-8;puts $f $value;close $f}
proc bgerror {message} {set ::bgfailure $::errorInfo;record background_error.txt $::errorInfo}
proc settle {{ms 80}} {after $ms {set ::settled 1};vwait ::settled;update;if {[info exists ::bgfailure]} {error $::bgfailure}}
proc check {condition message} {if {![uplevel 1 [list expr $condition]]} {error $message}}
proc heartbeat {} {incr ::beats;after 40 heartbeat}
proc capture {w name} {raise $w;settle 180;exec import -window [winfo id $w] [file join $::output $name.png]}
proc widget {id} {return [dict get $::GX::ViewerGui::instances $::w widgets $id]}
proc value {id val} {::GX::viewerGuiDesignValueSet $::w $id $val}
proc state {} {return [dict get $::GX::ViewerDocuments::forms [list $::w documents] state]}
proc action {id} {
    set start [clock milliseconds];set before $::beats
    set key [list $::w documents]
    if {[dict exists $::GX::ViewerDocuments::forms $key last_error]} {dict unset ::GX::ViewerDocuments::forms $key last_error}
    while {([dict get $::GX::ViewerDocuments::forms $key pending] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING}) && [clock milliseconds]<$start+45000} {settle}
    set result [[widget doc_$id] invoke]
    record dispatch.tsv [list $id $result]
    settle 150
    set limit [expr {$start+180000}]
    while {([dict get $::GX::ViewerDocuments::forms $key pending] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING}) && [clock milliseconds]<$limit} {settle}
    check {[dict get $::GX::ViewerDocuments::forms $key pending] eq {}} "Operation hung: $id"
    if {[dict exists $::GX::ViewerDocuments::forms $key last_error]} {error "$id: [dict get $::GX::ViewerDocuments::forms $key last_error]"}
    check {[dict get $::GX::ViewerDevelopment::windows $::w status] eq {COMPLETED}} "C++ action failed: $id [dict get $::GX::ViewerDevelopment::windows $::w last_result]"
    record actions.tsv [list $id [expr {[clock milliseconds]-$start}] [expr {$::beats-$before}] [state]]
}
proc tab {name} {[widget pages] select [widget $name];settle}
proc roi {values} {
    set key [list $::w documents];set c [widget preview].canvas
    set width [dict get $::GX::ViewerDocuments::forms $key display_width];set height [dict get $::GX::ViewerDocuments::forms $key display_height]
    lassign $values a b d e
    event generate $c <ButtonPress-1> -x [expr {int($a*$width)}] -y [expr {int($b*$height)}]
    event generate $c <B1-Motion> -x [expr {int($d*$width)}] -y [expr {int($e*$height)}]
    event generate $c <ButtonRelease-1> -x [expr {int($d*$width)}] -y [expr {int($e*$height)}]
    settle
    check {[dict get [state] roi] ne {}} {GUI region selection failed}
}
proc ready {} {
    settle 150
    set limit [expr {[clock milliseconds]+60000}]
    while {([winfo exists $::w.loading] || [dict get $::GX::ViewerDevelopment::windows $::w busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $::w status] eq {RUNNING} || ([dict exists $::GX::ViewerDocuments::forms [list $::w documents]] && [dict get $::GX::ViewerDocuments::forms [list $::w documents] pending] ne {})) && [clock milliseconds]<$limit} {settle}
    check {![winfo exists $::w.loading]} {C++ Viewer preparation hung}
}
proc invokeExisting {window action} {
    set limit [expr {[clock milliseconds]+30000}]
    while {([dict get $::GX::ViewerDevelopment::windows $window busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $window status] eq {RUNNING}) && [clock milliseconds]<$limit} {settle}
    set component {}
    foreach c [dict get $::GX::ViewerGui::instances $window design components] {
        if {[dict exists $c properties action] && [dict get $c properties action] eq $action} {set component [dict get $c id];break}
    }
    if {$component ne {}} {
        [dict get $::GX::ViewerGui::instances $window widgets $component] invoke
    } else {
        set found {}
        set widgets [list $window]
        for {set i 0} {$i<[llength $widgets]} {incr i} {
            set child [lindex $widgets $i];lappend widgets {*}[winfo children $child]
            if {![catch {$child cget -command} command] && [lsearch -exact $command $action]>=0 && [winfo class $child] eq {TButton}} {set found $child;break}
        }
        if {$found ne {}} {$found invoke} else {::GX::viewerCommandInvoke $window $action}
    }
    settle 100
    while {([dict get $::GX::ViewerDevelopment::windows $window busy] ne {} || [dict get $::GX::ViewerDevelopment::windows $window status] eq {RUNNING}) && [clock milliseconds]<$limit} {settle}
    set result [dict get $::GX::ViewerDevelopment::windows $window last_result]
    record ${action}.tcldict $result
    check {[dict get $::GX::ViewerDevelopment::windows $window status] eq {COMPLETED}} "Original action failed: $action $result"
    return [dict get $result result operations]
}
proc run {} {
    ::GX::defaults;::GX::loadModuleCatalog;::GX::launchGui
    set session [::GX::createNewSession sdk_regression {} 0]
    foreach {module provider action operation} {viewer.comparison_example comparison_example comparison_discover comparison_command viewer.ir_spectroscopy ir_spectroscopy analysis_dd1b5896_discover analysis_command} {
        set ::w [::GX::viewerOpen $module $provider];ready
        set operations [invokeExisting $::w $action]
        set found 0
        foreach row $operations {if {[dict get $row operation] eq $operation} {set found 1}}
        check {$found} "Original opcode did not reach its existing owner: $operation"
        capture $::w $operation
        destroy $::w;settle
    }
    set matrix {{Café Café {12 Mass} {!!!} {ΔValue}} {1 2 −3 4.5 6} {7 8 –9 1e2 3}}
    set schema [::GX::TableExtractorAPIv1::inferSchema [dict create matrix $matrix] {first_row_header 1 ascii_header_ids 1 normalize_numeric 1}]
    record schema_edges.tcldict $schema
    check {[dict get [lindex [dict get $schema columns] 0] id] eq {cafe}} {Accented header normalization failed}
    check {[dict get [lindex [dict get $schema columns] 1] id] eq {cafe_2}} {Duplicate header suffix failed}
    check {[lindex [dict get $schema data_rows] 0 2] eq {-3}} {Unicode minus normalization failed}
    record complete.txt EXISTING_SDK_RUNTIME_AND_SCHEMA_REGRESSION_PASS
}
set code [catch run result options]
if {$code} {record failure.txt [dict get $options -errorinfo];puts stderr [dict get $options -errorinfo]}
catch {::GX::stderrDiagnosticsShutdown}
destroy .
exit $code
