# Independent Unified Documents validator report

**Conclusion: INCOMPLETE pending authoritative patch deposition/readback only.** Completed functional, architecture and GUI checks pass; all three independently reproduced blockers were corrected and retested. This is not owner acceptance.

`W` means `/srv/gxtxt/agents/scratch/DEV112-UNIFIED-DOCUMENTS-20261101/`. One independent read-only validator operated the actual compiled GUI in private Xvfb/XDG/controlled Sessions. No product implementation, patch creation, release change, owner installation or original Session write was performed by this validator. Frozen private framework copies omit the three original module directories, removing all four reference providers. Final snapshot: validator16/source_identity.json and package05_audit.json. All 39 payload files are byte-identical to the tested final snapshot; full suites are validator05/07, with focused delta retests through16. MAIN evidence is identified explicitly and was independently inspected/compared, not represented as independent execution.

## Results for every owner matrix ID

| ID | Status | Source, actual procedure and observable evidence |
|---|---|---|
| A01 | PASS | Accepted public TAR independently reread: SHA-256 `8fda1fd6e485d9d917adfb08d64991c2403f8faf19ed10f4770565d8afcdbaa0`. Private baseline Git `68f4915017eb0821b9e6cba9292cf1639b5f3fcd`; changed paths recorded in validator01/changed_paths.txt. Development is isolated under W/framework. |
| A02 | PASS | Actual Builder and Workspace screenshots, normal Validate/Build/Export receipts: author11/*.png, validate.status.txt and complete.txt. Inspected C++ source/handlers.cpp and official exported native/viewer.so; independent GUI tests execute that compiled module. |
| A03 | PASS | All four original providers are physically absent from frozen validator02,04,07,11 framework copies. Independent actual GUI extraction/publication suites pass. C++ handlers use only admitted Host::documents_command; no imports, calls or paths to another Viewer. |
| A04 | PASS | CORE Python helper imports only standard library/Pillow; Tcl worker calls CORE OCRLayoutAPIv1/TableExtractorAPIv1. Static import/path audit and real absent-provider execution pass, including final realistic material and schema publication. |
| A05 | PASS | Existing CORE services own PDF rendering/native text/OCR, OCRmyPDF, reconstruction and Dataset operations; see source/API map below. Validator05/07 verify real bytes/cells and canonical publication. |
| A06 | PASS | Restricted API gap reproduced in original admission probes. Minimal finite GUI Host extension consumes existing services. Reviewed regression03 actual comparison opcode48 and analysis opcode49 GUI results, original schema comparison, plus service_compatibility01 and independent validator11 default-shape/publication tests. |
| A07 | PASS | viewer_gui_documents_v1.tcl::_viewerDocumentsSource/_Start/_Done use canonical Session Inspection and SHA guards. Independent validator06 actual GUI rejects incompatible, missing and deliberately changed private payloads, with English errors/screenshots. |
| A08 | PASS | All processing, editing and publication actions execute in one actual compiled C++ Viewer while the four original providers are absent. |
| A09 | PASS | All43 original provider files remain byte-equal baseline. Original OCR/table comparisons pass. workspace_reference_baseline and workspace_reference_candidate both pass actual PDF Save/reopen after normal public module enabling in private configuration; original_tables02 Save also passes. Earlier direct-driver Save refusal was omitted module policy, not a regression. |
| A10 | PASS | Actual new finite commands execute through compiled C++ in validator05/07/11/12, including Refresh, Select page, Clear region, Render, Copy text and clipboard. SDK, policy, broker opcode50, Host, Builder metadata and three API documents agree. |
| A11 | PASS | Existing managed Script Job process groups/UI lifetime and Resource Management own requests and files. Generation/Session/SHA guards inspected. Independent validator10 retests final cleanup delta: real large-document OCR cancellation, recovery, normal close and Workspace reopen pass. No owned worker remained after completed runs. |
| A12 | PASS | Inspected changed source/manuals and real GUI screenshots. Labels, errors, Help, code comments and dynamic statuses are English. Chinese OCR input and month-name data are content, not product UI. |
| F01 | PASS | Independent validator05 selects canonical PDF/image Datasets; validator06 exercises actual incompatible document.text, missing Dataset and changed payload rejection. |
| F02 | PASS | Validator05 operates multipage navigation, render, zoom, fit page/width and actual drag pan. Validator07 additionally navigates a realistic image-only two-page PDF with correct count. |
| F03 | PASS | Validator05 displays canonical 1700×2200 raster with preserved aspect ratio, normalized source coordinates, actual zoom and drag pan; candidate_image_table.png and action assertions. |
| F04 | PASS | Validator05 creates ROI by mouse, asserts eight handles plus rectangle, verifies normalized ROI unchanged after zoom and exercises pan. MAIN extended03 move/resize/Undo/Redo images and roi_states.tcldict independently inspected. |
| F05 | PASS | RGB dimensions/lineage pass. V-F05-02 fixed and independently retested: validator16 actual ROI acquisition preserves every RGBA pixel/alpha, palette transparency and16-bit grayscale sample, with exact dimensions and original modes. pixel_comparison.json and publication screenshots. |
| F06 | PASS | Validator05 performs real ROI/page/full-PDF/image OCR. Original region/page outputs match after terminal newline trim; full PDF matches byte-for-byte. Validator07 adds realistic two-page scanned PDF and real-page image OCR. |
| F07 | PASS | Installed eng/chi_sim/chi_tra/osd discovered and displayed. Actual GUI language, DPI, PSM, scope and method controls are consumed. Validator10 successfully runs eng+chi_sim recognition of Chinese and English; Native/Auto/OCR tested in validator05/07. |
| F08 | PASS | Actual text correction and document.text bytes verified in validator05. Metadata/source SHA/lineage independently read back. Validator12 confirms registered document.text and normal public Dataset Viewer displays corrected text; Copy text/clipboard also passes. |
| F09 | PASS | Validator05 produces actual searchable PDF from scanned input, validates qpdf --check and pdftotext known text, then reads canonical document.pdf publication metadata. Original corresponding GUI operation inspected in originals03. |
| F10 | PASS | Native table extraction matches original 4×3 sample exactly; validator07 also asserts every cell of a realistic published manual’s 8×8 table. |
| F11 | PASS | Validator05 tests scanned PDF Auto OCR fallback and explicit Document Tables OCR; source method differs from native. Independent comparison with original scanned table is exact. |
| F12 | PASS | Actual canonical image table OCR in validator05; matrix matches original image table byte-for-byte. |
| F13 | PASS | Actual ROI reconstruction, expected columns, header and schema publication in validator05/07/11. Inspected opt-in ASCII header/monthly title parity and regression03 original edge-case comparison. |
| F14 | PASS | Real double-click/Enter changes A1 mass10.5 to11.25. Independently read published CSV retains11.25 with correct variables, source SHA, ROI and lineage. Originals define no units for these inputs; empty units preserved. |
| F15 | PASS | Initial V-F15-01 fixed. Independent validator10 public Workspace save, close and reopen restores corrected text and ROI exactly; MAIN extended03 additionally preserves corrected table and exercises changed-source guards. |
| F16 | PASS | MAIN extended03 actually moves/resizes ROI, zooms, Undo/Redo and reopens; history_undo.tcldict/roi_states inspected. Source records History operations and flushes text before transitions. Independent validator10 verifies review persistence. |
| F17 | PASS | Validator05 repeated PDF/image/page/action switching and normal close; validator06 source negatives; validator10 real66-page OCR cancellation, recovery and reopen. Heartbeats demonstrate responsiveness; owned worker processes drain. |
| F18 | PASS | Reviewed final_reports/FUNCTIONAL_PARITY.md and JSON:25 inherited capabilities map all four original providers to CORE owners, original/current implementations and actual execution evidence. Independent OCR/table comparisons, realistic suites and corrected pixel-mode gold tests in validator16 support the register. |
| G01 | PASS | Actual integrated walkthrough in validator05/07: PDF/image, OCR, tables, review and outputs in one Viewer; original providers absent. |
| G02 | PASS | Source/settings/region tools, task tabs, review, publishing and status have clear named roles. See all-tab normal/compact screenshots in validator05. |
| G03 | PASS | Final entries and labels align consistently; Reset-wrapper noise removed. Minor whitespace at right of left-aligned navigation group is a polish issue, not overlap or loss of access. |
| G04 | PASS | Initial V-G04-01 fixed. Actual1024×768 and1440×900 screenshots show critical controls. Requested width926<1024. Focus reveals compact editable table through native scrolling (compact_table_edit.png); rows/cells remain readable and usable. |
| G05 | PASS | Dedicated catalog PNG loads/displays through real Tk at192×192; validator08/icon.png, icon.txt and provider.tcldict. GX-TXT native controls have readable contrast and no missing/fallback labels or icons. |
| G06 | PASS | English labels/defaults/units for page, DPI, zoom, languages, PSM, method and scope; actual busy/Cancel/error/publication messages inspected. Manual explains language codes, workflows and review. |
| G07 | PASS | Real ROI/pan mouse gestures, editable text, table double-click/Enter and keyboard focus tested. Compact table focus reveals scrolling viewport. Copy text and clipboard assertions pass in validator12. |
| G08 | PASS | Independent validator10 real66-page OCR cancellation completes while GUI heartbeat continues; subsequent Chinese OCR and Workspace reopen succeed. Errors recover clearly in validator06. |
| G09 | PASS | Actual source→ROI→OCR/table→correct→publish workflow completes without duplicate entry or needless modal sequences. Compact review remains accessible by focus/scroll. |
| G10 | PASS | Actual normal/compact/error/busy/cancel/publication UI is English; source/manual scan agrees. Recognized document language is user content. |
| D01 | PASS | Accepted TAR independently retains exact baseline hash. Validator writes only private snapshots/evidence/controlled Sessions; MAIN development remains isolated. No owner installation command or accepted release mutation observed. |
| D02 | PASS | package05 standard DEV112-P002 archive inspected: 39 changed files (31 replacements, 8 additions), no deletions. Accepted r2/000 baseline; predecessor null explicitly because P001 is deposited/not integrated. All payload bytes, hashes and exact baseline preimages pass; modes 0644. validator16/package05_audit.json. |
| D03 | NOT_RUN | Pending independent readback at the absolute authoritative patch path. |
| D04 | PASS | Inspected package05 APPLICATION_VALIDATION and actual applied_gui EXTENDED_FUNCTIONAL_PASS. Independently compared all 5435 baseline files after rollback: zero byte or mode differences. Profile/Session/registry sentinels and original modules preserved; idempotence and independent-edit/registry refusal checks pass. validator16/package05_audit.json. |
| D05 | PASS | Current Git changed-path audit contains no remaining-work TODO edits. Nine historical GAP request documents restored byte-for-byte; no speculative completion or deletion is asserted. |

## Execution and helper registration

Each private validator directory has its own SCRIPT_CATALOG.md documenting helper arguments, version scope and side effects. Helpers take FRAMEWORK OUTPUT and write only their own controlled Session, XDG and evidence. None stages or modifies product source.

| Evidence | Actual operation |
|---|---|
| validator01 | Initial GUI layout, source inventory and hashes of43 original provider files. |
| validator02 | Independent full compiled GUI extraction/publication suite without original providers. |
| validator03 | Realistic PDF, cancellation, multilingual OCR; first reproduced Workspace defect. |
| validator04 | Fixed Workspace, realistic PDF, cancellation and multilingual OCR; independent original result comparison. |
| validator05 | Full GUI/publication suite, eight ROI handles, zoom anchoring, drag pan, all tabs at both sizes, compact editable-table focus. |
| validator06 | Actual incompatible/missing/changed-source GUI rejection. Only its own test payload was intentionally altered. |
| validator07 | Final realistic material suite: image-only multipage PDF, realistic image OCR, exact64-cell native table. |
| validator08 | Actual catalog provider icon resolution, PNG loading and display. |
| validator09 | Registered text contract; first preview helper used a legacy metadata renderer and had an invalid payload-display expectation. Retained as helper failure, superseded by12. |
| validator10 | Final cleanup delta: large-PDF OCR cancellation/recovery, multilingual OCR, Workspace save/close/reopen. |
| validator11 | Final three-file CORE compatibility delta: default schema shape, ASCII headers and actual GUI table publication. |
| validator12 | Registered document.text, normal public Dataset Viewer shows corrected text, remaining finite commands and clipboard. |
| validator13 | Native-column acceptance delta: actual GUI native publication, Auto expected5 OCR fallback, Native-only rejection. |
| validator14 | Generic actor delta: actual text/table publication and metadata retain the admitted actor. |
| validator15 | Actual RGBA ROI pixel-gold test reproduced loss of alpha; failing evidence retained. |
| validator16 | Corrected RGBA, palette transparency and 16-bit ROI acquisition preserve exact pixel gold. Final package05 audit checks all 39 payload files and 5435 rollback files, including modes. |

Completion files/logs prove actual outcomes. Read-only publication_assertions.json independently checks output dimensions, CSV values, metadata and lineage. Known process lists after completion showed no owned worker remaining.

Realistic controlled material includes public system latexmk.pdf (66pages), its first two pages rasterized into a genuinely image-only PDF, a canonical image of a real page, and published luaprogtable-doc.pdf physical page10 with an8×8 numeric table. Every one of64 table cells is asserted. Generated native/scanned fixtures supplement these realistic files for original/candidate equivalent comparisons. A Chinese/English image verifies installed non-English and multilingual recognition. No private scientific library was accessed.

Original GUI evidence in originals03/original_tables01 was inspected. Independent comparisons in validator04/original_comparison.json show region/page OCR equivalent except terminal newline, full PDF text byte-identical, and native/scanned/image table matrices byte-identical. Corrected published CSV retains A1,11.25,98.2. Published crop1481×396 and full page1700×2200 match metadata; source SHA/page/ROI/settings/lineage are retained.

## Source/API dependency audit

The C++ source/handlers.cpp calls admitted SDK Host::documents_command. The trusted adapter and broker use opcode50 and admit only a complete declared extraction form and finite commands. GUI Host resolves canonical Session/Dataset ownership, then checks SHA before and after work/publication. Existing Script Job and Resource Management own asynchronous processes, cancellation, timeouts, temporary files and close cleanup.

PDF/native text/render/OCR/searchable PDF use core/tcl/ocr_layout_api_v1.tcl. Raw-text/searchable methods extend its existing options, renderer and tool contracts. Table reconstruction/schema use core/tcl/table_extractor_api_v1.tcl with opt-in parity options. The CORE Python helper uses Pillow for raster orientation/zoom/crop and standard-library Unicode normalization for headers. It imports no Viewer. Existing File Publication, Dataset Publication V2, Metadata, Workspace and History own canonical outputs and review persistence. Publication derives actor_module from the admitted live GUI instance; no hardcoded target owner remains in the controller. Independent validator14 confirms actual text/table producer identity and extraction.viewer metadata. The C++ Viewer has no raw paths, direct processes or private plugin access.

Changed-interface justification is concrete: initial restricted SDK admission denied existing extraction services, so finite GUI Host admission was extended; arbitrary service invocation was not introduced. Existing typed Workspace/History receives a document review domain; existing jobs/resources own work. Existing OCR/Table services remain processing authorities. Comparison48 and analysis49 are preserved and exercised in regression03; schema defaults retain the old result shape (independent validator11). Documentation is updated in docs/api/VIEWER_GUI_HOST_API_v1.md, OCR_LAYOUT_API_v1.md and TABLE_EXTRACTOR_API_v1.md.

The text contract remains registered by acq.text_document with originals absent; validator12/contract.tcldict records status registered. Normal public DatasetViewerOpen displays the corrected canonical payload through CORE read-only text consultation. No new registration API or dependency on the original four providers is needed.

## Defects and retests

- **V-G04-01, initial BLOCKER:** recognition settings and Clear region/Select page were off-screen at1024×768. Initial measured Select page x1120,width95 and requested width2035. Fixed through actual Builder compact entries and wrapped tools. Final requested width926; actual normal/compact screenshots and focused table editing remain usable. **FIXED.**
- **V-F15-01, initial BLOCKER:** Workspace saved corrected text in SQLite but public reopen restored an empty form. MAIN corrected History checkpoint recording and transition flushing. Independent validator04 and final validator10 public save/close/reopen restore corrected text and ROI exactly. **FIXED.**
- No unresolved functional or severe GUI defect remains after the pixel-preservation retest in validator16. Minor polish: whitespace to the right of the navigation cluster; compact table options/review use existing overflow scrolling and focus reveal. Neither hides an unreachable critical action.

## Visual quality rubric

| Dimension | Score | Observable basis |
|---|---:|---|
| Hierarchy |2/2| Named source/settings/tools, task tabs, review and status. |
| Alignment/spacing |1/2| Controls align; some right-side whitespace and compact scrolling remain. |
| Readability |2/2| Native controls, adequate contrast, readable labels and edited cells. |
| Workflow clarity |2/2| Actual source→region→process→correct→publish sequence is direct. |
| Polish/consistency |1/2| Restrained GX-TXT controls and dedicated icon; functional presentation with minor spacing limitations. |

**8/10, no zero.** Actual images: validator05/layout_1440x900_*.png, layout_1024x768_*.png, compact_table_edit.png; functional ROI/OCR/table/output screens in05; realistic/multilingual/cancel/restored screens in07/10; dedicated icon08. Author11 changes only the icon, retaining the reviewed layout. Initial4/10 evidence is retained but superseded by the corrected candidate.

## Remaining acceptance gates

Do not infer PASS for NOT_RUN rows. The final named parity register has been inspected. The corrected standard incremental patch and isolated apply/rollback checks pass. Only authoritative absolute-path byte/hash readback remains mandatory. Final owner acceptance is separate.


Original Workspace triage is resolved: both exact baseline and candidate start PDF module disabled. After normal public moduleSetEnabled in private configuration, actual Save and selector reopen pass. No original module or product correction was required.


## Late blocking pixel-integrity defect

**V-F05-02 BLOCKER, FIXED:** validator15 actual canonical RGBA image→Open source→Select page ROI→Publish selected region executes successfully but outputs RGB. Source/output dimensions both200×100; converted RGBA pixel bytes differ. Evidence: validator15/pixel_comparison.json, output_path.txt, rgba_crop_publication.png and original RGBA fixture. Original Document OCR source _ocrShowPreview/_ocrAcquire uses ImageMagick auto-orient then PNG crop without RGB conversion, preserving alpha. The new CORE helper unconditionally converts the full-resolution source and crop to RGB. This was loss of inherited acquisition behavior, not a new feature request. CORE separates display conversion from full-resolution samples. Independent validator16 actual GUI ROI crop preserves RGBA, palette transparency and16-bit grayscale samples exactly, including all pixel/alpha values and output dimensions. F05/F18 now PASS. Prepared package04 remains superseded; final corrected package05 audit passes.

Independent validator16 source_identity.json freezes the corrected raster helper. Actual cropped box is(50,20)-(150,80); outputs preserve RGBA/P/I;16 modes and pixel gold exactly. The16-bit fixture has20,000 distinct values with maximum19,999, so this verifies absence of8-bit quantization.

Final prepared package05 audit: SHA-25671de9c7bc4127046e283ed06854a69b816a6d4ebf576c83008fb971d00164e1d before notes-only report refresh. All 39 product files match tested final bytes, manifest hashes and baseline preimages; all modes 0644; no deletions. All 5435 baseline files match post-rollback bytes and modes. Final archive hash must be independently reread after notes refresh and authoritative deposition.
