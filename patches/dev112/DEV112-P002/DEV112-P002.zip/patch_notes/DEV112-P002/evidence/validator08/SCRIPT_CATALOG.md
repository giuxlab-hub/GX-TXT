icon.tcl FRAMEWORK OUTPUT: read-only actual modulecatalog provider definition and TkPNG loading/display/capture of dedicated catalogicon in privateXvfb/XDG; no Session/source/release/owner writes.
