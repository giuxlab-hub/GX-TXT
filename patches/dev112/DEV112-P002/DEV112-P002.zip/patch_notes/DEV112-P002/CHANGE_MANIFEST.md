# DEV112-P002 change manifest after P001

39product files:31replacements,8additions,0deletions, measured against DEV112.r2 with P001 fully applied. Beforeimages and rollback preimages come from that exact combined baseline.38prior P002 postimages are reused byte-for-byte, including all CORE/SDK/C++/GUI code and graphical assets. Only the target checksum list is refreshed to retain P001 inherited icon files.

Two P001 files are intentionally updated: Unified Documents module.ini (completed Viewer) and its SHA256SUMS.txt. All other31P001 postimages remain unchanged. Both inherited target PNG/SVG files remain unchanged and are covered by the new module checksum list. Registry, unrelated modules, user profiles, Sessions, scientific libraries and TODO are untouched.
