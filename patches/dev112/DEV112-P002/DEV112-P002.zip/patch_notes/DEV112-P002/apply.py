#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Guarded DEV112.r2 + DEV112-P001 Unified Documents incremental overlay. Default: read-only check."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
import zipfile

PATCH='DEV112-P002'
NOTES='patch_notes/'+PATCH
MODULES={'viewer.'+s for s in ('ir_spectroscopy','ic_chromatograms','script_library','markdown_documents','unified_document_extraction','uml_editor','stderr_diagnostics','crystal_structure','molecule_3d')}

def digest(data):return hashlib.sha256(data).hexdigest()
def require(ok,message):
    if not ok:raise ValueError(message)

def safe_relative(name):
    p=PurePosixPath(name)
    require(not p.is_absolute() and '\\' not in name and all(v not in ('','.','..') for v in name.split('/')),'Unsafe path: '+name)
    return p

def member(root,name):
    parts=safe_relative(name).parts
    p=root
    for i,v in enumerate(parts):
        p=p/v
        require(not p.is_symlink(),'Symlink target/ancestor: '+str(p))
        if p.exists() and i<len(parts)-1:require(p.is_dir(),'Non-directory ancestor: '+str(p))
    return p

def identity(p):
    if not p.exists():return None
    s=p.lstat()
    require(stat.S_ISREG(s.st_mode) and s.st_nlink==1,'Nonregular/hardlinked target: '+str(p))
    return dict(sha256=digest(p.read_bytes()),size=s.st_size,mode=stat.S_IMODE(s.st_mode))

def replace(p,data,mode):
    p.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.catalog-patch-',dir=p.parent)
    try:
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        os.chmod(tmp,mode);os.replace(tmp,p)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def owner_guard(root,manifest):
    import configparser
    regpath=member(root,'plugins/.registry/installed.ini')
    require(identity(regpath) is not None,'Factory registry missing')
    reg=configparser.ConfigParser(interpolation=None,strict=True);reg.read(regpath,encoding='utf-8')
    deltas={r['path']:r for r in manifest['files']}
    for module,guard in manifest['factory_module_guards'].items():
        section='plugin.'+module
        observed=dict(reg[section]) if reg.has_section(section) else None
        expected=guard['registry']
        if expected is None:
            require(observed is None,'Independently managed module refuses factory overlay: '+module)
        else:
            require(observed is not None,'Factory registration missing: '+module)
            for key in ('id','type','version','package_file','bundle_id','bundle_version'):
                require(observed.get(key)==expected.get(key),'Independent registration/package differs: '+module+'/'+key)
        prefix='plugins/modules/'+module+'/'
        directory=member(root,prefix.rstrip('/'))
        require(directory.is_dir(),'Factory module missing: '+module)
        observed_files={}
        for p in directory.rglob('*'):
            require(not p.is_symlink(),'Linked module member: '+str(p))
            if not p.is_dir():observed_files[str(p.relative_to(directory))]=identity(p)
        new={rel[len(prefix):] for rel,row in deltas.items() if rel.startswith(prefix) and row['before'] is None}
        require(set(guard['files']).issubset(observed_files) and set(observed_files).issubset(set(guard['files'])|new),'Independent module file inventory differs: '+module)
        for rel,actual in observed_files.items():
            row=deltas.get(prefix+rel)
            allowed=(row['before'],row['after']) if row else (guard['files'][rel],)
            require(actual in allowed,'Independent module edit refuses replacement: '+module+'/'+rel)


def predecessor_guard(root,manifest):
    require(manifest.get('predecessor')=='DEV112-P001','This P002 requires DEV112-P001')
    deltas={row['path']:row for row in manifest['files']}
    for relative,expected in manifest['predecessor_files'].items():
        delta=deltas.get(relative)
        allowed=(expected,delta['after']) if delta else (expected,)
        require(identity(member(root,relative)) in allowed,'DEV112-P001 prerequisite missing or changed: '+relative)

def run(a):
    root=Path(os.path.abspath(a.framework))
    for p in [*root.parents,root]:require(not p.is_symlink(),'Linked framework path')
    require(root.is_dir(),'Framework directory missing')
    archive=Path(a.archive)
    checksum=Path(str(archive)+'.sha256').read_text().split()[0]
    require(digest(archive.read_bytes())==checksum,'Archive SHA256 does not match adjacent sidecar')
    with zipfile.ZipFile(archive) as z:
        names=z.namelist()
        require(len(names)==len(set(names)),'Duplicate archive entries')
        for item in z.infolist():
            safe_relative(item.filename)
            require(not item.is_dir() and item.file_size<=4*1024*1024 and stat.S_IFMT(item.external_attr>>16) in (0,stat.S_IFREG),'Invalid archive member')
        manifest=json.loads(z.read(NOTES+'/FILES.json'))
        require(manifest['patch']==PATCH,'Wrong patch')
        require((root/'VERSION.txt').read_text().strip()=='0.9.8.10-dev-112','Wrong framework version')
        require((root/'PATCH_LEVEL.txt').read_text().strip()=='000','Wrong baseline patch level')
        for rel,expected in manifest['host_guards'].items():
            p=member(root,rel)
            require(p.is_file() and digest(p.read_bytes())==expected,'Host guard differs: '+rel)
        rows=manifest['files'];payload={r['path'] for r in rows}
        require(len(payload)==len(rows),'Duplicate payload paths')
        require(set(n for n in names if not n.startswith(NOTES+'/'))==payload,'Undeclared payload')
        for row in rows:
            rel=row['path'];parts=safe_relative(rel).parts
            require(rel in {'docs/api/VIEWER_GUI_HOST_API_v1.md', 'core/development/sdk/trusted_adapter_v1.cpp', 'plugins/modules/viewer.unified_document_extraction/RESTRICTED_VIEWER_PROVENANCE.json', 'core/tcl/viewer_gui_host_api_v1.tcl', 'plugins/modules/viewer.unified_document_extraction/native/gxtxt_viewer_sdk_v1.hpp', 'plugins/modules/viewer.unified_document_extraction/MANUAL.md', 'plugins/modules/viewer.unified_document_extraction/native/viewer.so', 'plugins/modules/viewer.unified_document_extraction/review/validation.json', 'core/tcl/workbench_extension_api_v1.tcl', 'plugins/modules/viewer.unified_document_extraction/SHA256SUMS.txt', 'plugins/modules/viewer.unified_document_extraction/resources/icons/unified_documents.png', 'plugins/modules/viewer.unified_document_extraction/resources/icons/catalog.json', 'plugins/modules/viewer.unified_document_extraction/review/build.json', 'plugins/modules/viewer.unified_document_extraction/review/original-build.json', 'core/tcl/viewer_gui_documents_v1.tcl', 'plugins/modules/viewer.unified_document_extraction/source/SOURCE_MANIFEST.json', 'core/tcl/viewer_development_api_v1.tcl', 'core/development/policy_v1.json', 'docs/api/OCR_LAYOUT_API_v1.md', 'docs/api/TABLE_EXTRACTOR_API_v1.md', 'plugins/modules/viewer.unified_document_extraction/source/MANUAL.md', 'plugins/modules/viewer.unified_document_extraction/native/SDK_CONTRACT.json', 'core/tcl/viewer_gui_design_v1.tcl', 'gxtxt_pipeline.tcl', 'core/python/gxtxt_viewer_development.py', 'core/development/sdk/gxtxt_viewer_sdk_v1.hpp', 'core/python/gxtxt_document_extraction_worker.py', 'plugins/modules/viewer.unified_document_extraction/source/design.gxtxt-viewer', 'plugins/modules/viewer.unified_document_extraction/source/project.json', 'plugins/modules/viewer.unified_document_extraction/gui/design.tcldict', 'plugins/modules/viewer.unified_document_extraction/source/handlers.cpp', 'core/tcl/ocr_layout_api_v1.tcl', 'plugins/modules/viewer.unified_document_extraction/native/trusted_adapter_v1.cpp', 'core/tcl/ui_field_viewer_regions_v1.tcl', 'plugins/modules/viewer.unified_document_extraction/module.ini', 'plugins/modules/viewer.unified_document_extraction/plugin-package.ini', 'core/tcl/document_extraction_worker.tcl', 'plugins/modules/viewer.unified_document_extraction/resources/icons/unified_documents.source.png', 'core/tcl/table_extractor_api_v1.tcl'},'Out-of-scope product path: '+rel)
            data=z.read(rel);after=row['after']
            require(digest(data)==after['sha256'] and len(data)==after['size'],'Bad payload bytes: '+rel)
            if row['before']:
                data=z.read(NOTES+'/preimages/'+rel)
                require(digest(data)==row['before']['sha256'],'Bad rollback preimage: '+rel)
        # Preflight every target before any mutation. Known before/after states
        # permit recovery after interruption; unknown edits always refuse.
        predecessor_guard(root,manifest)
        owner_guard(root,manifest)
        states={}
        for row in rows:
            actual=identity(member(root,row['path']))
            require(actual==row['before'] or actual==row['after'],'Unknown target bytes/mode or asset collision: '+row['path'])
            states[row['path']]=actual
        if not (a.apply or a.rollback):
            print('CHECK PASS; no writes; '+str(len(rows))+' product files');return
        for row in rows:
            p=member(root,row['path']);target=row['before'] if a.rollback else row['after']
            require(identity(p)==states[row['path']],'Target changed during preflight: '+row['path'])
            if identity(p)==target:continue
            if target is None:p.unlink()
            else:
                data=z.read(NOTES+'/preimages/'+row['path'] if a.rollback else row['path'])
                replace(p,data,target['mode'])
            require(identity(p)==target,'Postimage verification failed')
        print(('ROLLBACK' if a.rollback else 'APPLY')+' PASS; restart GX-TXT to adopt the patch')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('framework');p.add_argument('archive')
    g=p.add_mutually_exclusive_group();g.add_argument('--check',action='store_true');g.add_argument('--apply',action='store_true');g.add_argument('--rollback',action='store_true')
    p.add_argument('--stopped',action='store_true',help='Operator acknowledgement only; does not stop or detect running processes')
    a=p.parse_args()
    if (a.apply or a.rollback) and not a.stopped:p.error('Writes require --stopped acknowledgement')
    try:run(a)
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as e:raise SystemExit('REFUSED: '+str(e))

if __name__=='__main__':main()
