# DEV112-P002 — incremental update after DEV112-P001

**Required order: accepted DEV112.r2 → DEV112-P001 → DEV112-P002.** This corrected P002 must be applied on top of the complete P001 patch. Plain r2, partial P001 and independently modified target files are refused before any write. The physical VERSION/PATCH_LEVEL files remain those of the existing framework convention; prerequisite recognition checks all33P001 postimages, allowing only the two intentional P002 overlaps.

P001 archive SHA-256: b73fd26aaf6e8d3950de355988640bce0c6f0180e0ccc18aa5a19962e8f68d4b.
Accepted r2 public TAR SHA-256: 8fda1fd6e485d9d917adfb08d64991c2403f8faf19ed10f4770565d8afcdbaa0.

The completed independent Unified Documents C++ implementation is preserved:38previous postimages, including every executable/source/graphical asset, are byte-identical. Only its module checksum list is refreshed for the two inherited P001 icons. The delta contains39actual changed/added framework files relative to P001, exact baseline preimages, SHA-256 manifests and the existing guarded DEV112 apply/rollback procedure. No original Viewer implementation, registry, profile, Session or library is overwritten.

## Application and rollback

Apply P001 first using its delivered procedure, then use this P002 archive and adjacent checksum sidecar. Close the target framework/workers and run as its owner. Review FILES.json and BASELINE.json. The --stopped flag acknowledges this condition; it does not terminate any process.

```sh
unzip DEV112-P002.zip 'patch_notes/DEV112-P002/*' -d review
python3 review/patch_notes/DEV112-P002/apply.py FRAMEWORK DEV112-P002.zip --check
python3 review/patch_notes/DEV112-P002/apply.py FRAMEWORK DEV112-P002.zip --apply --stopped
python3 review/patch_notes/DEV112-P002/rollback.py FRAMEWORK DEV112-P002.zip --rollback --stopped
```

**Rolling back P002 restores the exact P001-applied state, including its descriptor, checksums and icons. It does not remove P001.** Only after P002 has been rolled back may P001 be rolled back with its own procedure. Unknown changes, independent registration, links and collisions refuse. Replacement is atomic per file; known before/after states allow retry. Restart GX-TXT after a change.

CHAIN_VALIDATION.json records clean sequential application, rejection of plain/partial predecessor states, idempotence, real combined-base GUI checks, preservation of all unaffected P001 files and exact layered rollback. Existing full functional/independent evidence is reused because processing code and the compiled Viewer are unchanged; historical r2-only packaging records are clearly separated under historical_validation. A new independent chain/readback report accompanies this corrected delivery.

The earlier r2-only P002 archive is superseded and preserved, not the application base. The archive is deposited only; owner acceptance is required before integration. No installation, Debian rebuild or GitHub publication is performed.

Runtime dependencies and documented limits are unchanged: existing Poppler/Tesseract/Pillow, OCRmyPDF/qpdf for searchable PDF;4MiB editable OCR text,8MiB review state,24million display pixels. Source/crop samples and alpha are preserved. OCRmyPDF can reject already searchable input as in the original workflow. See the preserved functional parity and architecture reports.

The embedded independent report is the pre-deposit chain audit. The final authoritative ZIP SHA/readback is recorded beside the deposited archive in VALIDATOR_REPORT.md and FINAL_DEPOSIT_VERIFICATION.json.
