# Independent P001-chain validator report

**Prepared-chain technical validation: PASS. Final authoritative replacement/readback: INCOMPLETE.** No product/source, release or owner installation was changed by this validator.

Required chain: **accepted DEV112.r2 → exact DEV112-P001 → corrected DEV112-P002**. This report supersedes the earlier plain-r2 packaging conclusions. The prior full functional evidence remains applicable to the reused implementation bytes, but is not represented as having run on the new combined baseline. A new independent actual GUI regression was executed on the P001-based candidate.

## Scope and evidence

Work: `/srv/gxtxt/agents/scratch/DEV112-P002-ON-P001-20261101/`. Independent evidence: `validator01/CHAIN_AUDIT.json`, `PREFLIGHT_CHECKS.json`, `gui/`, and old-delivery inventories. Helper scope is registered in `validator01/SCRIPT_CATALOG.md`; the workspace and task catalogs were read before execution.

| Check | Result | Concrete evidence |
|---|---|---|
| Exact predecessor | PASS | Authoritative P001 ZIP independently reread: SHA-256 `b73fd26aaf6e8d3950de355988640bce0c6f0180e0ccc18aa5a19962e8f68d4b`,1119249bytes. All CRCs and33 manifest postimages verified. |
| Actual P001 baseline | PASS | Existing delivered P001 apply procedure executed by MAIN on isolated r2. Independent full-tree comparison confirms exactly its33 effects and no others:5435 r2 files become5449 P001 files. Every P001 postimage hash/size/mode matches. |
| New P002 contract | PASS | FILES/BASELINE explicitly require DEV112-P001 and exact predecessor archive hash. Guard checks all33 predecessor postimages, permitting only the two declared P002 overlap postimages for retry/idempotence. Plain r2 is not the base. |
| Exact delta/preimages | PASS |39 payload files:31 replacements,8 additions, no deletions. Every beforeimage equals the isolated P001 tree; every payload byte/hash/mode equals candidate. All modes0644. |
| Implementation reuse | PASS |38 prior P002 postimages are byte-identical, including CORE/SDK/GUI/C++ and graphical assets. The only changed prior postimage is target SHA256SUMS.txt. No functional redevelopment occurred. |
| Cumulative P001 effects | PASS |31 unaffected P001 postimages remain exact. Only target module.ini and SHA256SUMS.txt overlap intentionally. Both inherited target catalog PNG/SVG assets remain exact; the refreshed SHA list adds exactly their two entries and preserves every prior entry/value. |
| Refusal before mutation | PASS | Independent actual --check accepts complete P001, rejects plain r2 and an own partial P001 copy missing an unrelated UML SVG. Before/after snapshots show no target byte/mode/inventory changes. MAIN separately executes --apply refusal for a partial IR descriptor and plain r2. |
| Ownership/other guards | PASS | Inspected SUPPLEMENTAL_GUARDS.json: independent registry, CORE edit and inherited icon edit refuse without writes; P001 rollback while P002 is active also refuses. Existing ownership mechanism retained. |
| P002 layer rollback | PASS | Independently compare all5449 P001 baseline files against post-rollback apply_test: exact bytes/modes. Only the two known private sentinels are extra, with exact expected contents. Repeated apply/rollback passes. |
| Full reverse chain | PASS | Independent reverse_chain full snapshot equals all5435 r2 files after P002 rollback then delivered P001 rollback. |
| Combined-base GUI | PASS | Independent existing gui_tools/extended.py run against candidate, with fresh Xvfb/XDG/Session: validator01/gui/complete.txt EXTENDED_FUNCTIONAL_PASS. Actual PDF/ROI/OCR/review, Workspace/History, errors, cancellation/reopen and nine cumulative P001 category/icon assertions execute. Screenshots, actions.tsv and cumulative_catalog.tcldict retained. MAIN's separate combined_gui also passes. |
| Old delivery preservation | PENDING | Before replacement, old authoritative ZIP still has SHA-256 `2a4c0fe34aa7098c01e7f39b428740b04cc249c6ef699f3082db1452f2b84f23`. Independent inventories capture21 authoritative flat-delivery files and403 canonical expanded files. Exact superseded preservation must be verified before final signoff. |
| Corrected authoritative readback | PENDING | Final notes-only archive refresh and authorized same-path replacement are not yet independently verified. Final ZIP SHA, CRCs,39 payload hashes/modes, P001 preimages and canonical pair must be reread after replacement. |

Prepared archive SHA-256: `8924a7725283b70819549d944b4a43cd96e234703da2d1d425a8ab5525a0dafa`. A notes-only refresh may change that ZIP hash, never its39 product postimages.

## Decision

D02 and D04 pass for the corrected P001-based package. D03 remains pending final authoritative replacement/readback. The superseded archive must remain available exactly, including its entire flat delivery and canonical archive/expanded pair. No installation or integration into the owner's framework was performed.

The earlier functional report covers the unchanged implementation on its original test baseline. The new independent combined-base GUI and strict predecessor/layered rollback checks close the packaging rebase scope without repeating the entire development campaign. No defect was found in the prepared chain.
