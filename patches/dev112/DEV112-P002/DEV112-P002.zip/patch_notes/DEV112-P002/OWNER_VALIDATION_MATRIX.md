# GX-TXT DEV112 — Unified Documents: Owner Validation Matrix

**Document:** OWNER_VALIDATION_MATRIX.md  
**Date:** 2026-11-01  
**Status:** Mandatory acceptance criteria; not evidence of completed tests  
**Project:** `viewer.unified_document_extraction` — C++ Viewer built with the actual GX-TXT Viewer Interface Builder  
**Development baseline:** accepted DEV112.r2, `/srv/gxtxt/releases/dev112/0.9.8.10-dev-112-r2/` (read-only reference)  
**Work area:** `/srv/gxtxt/agents/scratch/DEV112-UNIFIED-DOCUMENTS-20261101/`  
**Reviewer:** one independent **Sol 6.1 Low** validation agent, verification only

## 1. Non-negotiable outcome

Deliver ONE fully functional **Unified Documents C++ Viewer**, containing the working capabilities of:
- `viewer.pdf_ocr` — PDF OCR
- `viewer.table_extractor` — Table Extractor
- `viewer.document_extractors` / `generic_ocr` — Document OCR
- `viewer.document_extractors` / `table_extractor` — Document Tables

The original Viewers are **reference implementations**, never dependencies of the new Viewer. The solution must remain functional even when the four original Viewer providers are absent. The original modules remain unmodified during development. All product code, comments, identifiers, GUI labels, messages, technical documentation and tests must be **English**.

**Correct architecture:** `Unified Documents (C++ Viewer) → admitted public CORE contracts → existing CORE services`. CORE must never import or depend on a Viewer/plugin implementation. Tcl/Python remain legitimate internal CORE implementation languages; the new Viewer is authored through the C++ Viewer framework and the real Interface Builder. There is no requirement to rewrite shared scientific algorithms in C++.

## 2. Validator mandate and evidence rules

The independent **Sol 6.1 Low** validator has ONE job: inspect whether the implementation satisfies **every applicable row in this matrix**, including actual GUI usability, layout and visual quality. It must not implement features, change source, create patches, change release contents, or instruct unrelated redesign.

The MAIN agent continues implementation and corrections autonomously; the validator reports defects to MAIN without repeatedly seeking owner approval. The validator is **not** a second developer.

For every ID record `PASS`, `FAIL`, `NOT_RUN`, or `NOT_APPLICABLE`, with: (a) exact source/API reference as appropriate; (b) actual test procedure; (c) observable result or screenshot/log; (d) defect ID when failing. `NOT_APPLICABLE` needs a concrete explanation. A claim, README, compilation, Validate PASS, or synthetic stub is **not** proof of working functionality. Do not invent evidence or label unexecuted tests PASS.

**Blocking rule:** any failed architecture criterion, missing original Viewer capability, broken publication or persistence, severe GUI defect, or application freeze prevents final acceptance. The reviewer may inspect intermediate increments and issue corrections early, but signs off only on the finished candidate.

## 3. Architecture and engineering matrix

| ID | Priority | Verification criterion | Required evidence |
|---|---|---|---|
| A01 | BLOCKER | Work is based on accepted DEV112.r2; accepted release and owner installation are unchanged. All code changes are in isolated worktree/candidate. | Baseline identity, hash comparison, changed-path inventory |
| A02 | BLOCKER | GUI is actually designed/edited in the **Viewer Interface Builder**; implementation uses C++ Viewer Development Workspace and its normal build/export path. No hand-authored substitute project. | Builder GUI evidence; project/build receipts; C++ source |
| A03 | BLOCKER | Unified Documents has **zero imports, runtime dependencies, plugin calls, direct paths or symbol references** to internal code of `viewer.pdf_ocr`, `viewer.table_extractor`, `viewer.document_extractors` or any other Viewer. | Static import/path/call search; dependency graph; isolated runtime test without reference Viewers |
| A04 | BLOCKER | **CORE has no dependency on `plugins/modules/` or another Viewer**. In particular, inspect and eliminate the observed direct imports in `core/python/gxtxt_document_extraction_worker.py`; moving those imports elsewhere inside CORE is not a fix. | Search of changed CORE files + transitive imports, actual no-plugin test |
| A05 | BLOCKER | OCR, PDF render, table reconstruction and Dataset/Workspace operations reuse existing **CORE-owned** facilities; no duplicate processing engine in Viewer or CORE. | Per-feature mapping to existing CORE service/contract |
| A06 | BLOCKER | Existing public APIs/SDK/GUI Host are reused or extended first. Each CORE/SDK change has a concrete consuming feature, a proven gap, minimal diff, and focused regression evidence. A new public API is justified only when extending existing contracts is insufficient. | CORE/SDK diff and brief justification per change |
| A07 | BLOCKER | The Viewer accesses canonical Session/Dataset content through admitted CORE ownership, not raw paths, private APIs, bypasses or unbounded direct subprocess invocation. Source, Session and SHA/revision guards work. | Source trace + invalid/changed-source tests |
| A08 | BLOCKER | No launch of the four original Viewer windows as a substitute for integration. All requested actions operate inside Unified Documents. | GUI action walk-through; window/process observation |
| A09 | BLOCKER | Original Viewers and their published contracts, saved Workspaces and existing behavior remain unchanged. | File/content hashes of original modules; regression comparison |
| A10 | MAJOR | SDK, admission policy, actual runtime dispatch, GUI Host, Builder metadata and documentation agree; no Validate-only capability that fails at runtime. | Real runtime operation for each new admitted command |
| A11 | MAJOR | Async jobs, cancellation, temporary files, failure paths and shutdown are owned/cleaned up by existing CORE lifecycle conventions; no orphan work or stale source binding. | Cancel/close/reopen and error-injection tests |
| A12 | MAJOR | Source, GUI, errors, Help, code comments and tests are in English, including default settings and dynamic statuses. | Static scan plus real GUI screenshots |

## 4. Functional parity matrix

For every feature, test the **original Viewer** and **Unified Documents** on an equivalent real Dataset. Match observable behavior and correctly published data; preserve source identity, metadata and provenance. The following feature coverage is mandatory.

| ID | Priority | Required user-visible behavior | Evidence |
|---|---|---|---|
| F01 | BLOCKER | Select actual canonical `document.pdf` and `image.raster` Datasets from the active Session; reject incompatible/missing sources clearly. | Selection and rejection cases |
| F02 | BLOCKER | Display PDF pages with navigation, page count, previous/next limits, zoom, fit page/width, scroll and pan. | Real multipage PDF GUI run |
| F03 | BLOCKER | Display images with correct aspect ratio, coordinate meaning, zoom and pan. | Real raster Dataset screenshot |
| F04 | BLOCKER | Create, select, move and resize ROI, including eight handles where the originals support them; ROI remains anchored correctly after zoom/page changes. | Drag/resize screenshots and pixel-coordinate checks |
| F05 | BLOCKER | Render/extract a complete PDF page and a selected crop; publish `image.raster` through canonical CORE publication. | Input/output identities, dimensions, lineage |
| F06 | BLOCKER | Perform real OCR on ROI, full page, full PDF and image Datasets, not simulated text or launch-only callbacks. | OCR outputs against known readable test content |
| F07 | BLOCKER | Present language discovery/selection, multi-language OCR, DPI, PSM and supported OCR method options. | GUI controls and actual option-specific run |
| F08 | BLOCKER | Show OCR text, allow intended corrections/copy, publish corrected `document.text`, retain metadata and original PDF unchanged. | Edited output and re-opened published Dataset |
| F09 | BLOCKER | Generate a genuinely searchable PDF with existing OCRmyPDF-based functionality, validate output, publish `document.pdf`, preserve original source. | Openable/searchable output; provenance; PDF validation |
| F10 | BLOCKER | Extract native positioned text from PDF tables where available. | Native-text table sample, cells/row comparisons |
| F11 | BLOCKER | Automatic fallback to OCR for scanned PDFs and explicit OCR selection work. | Native / Auto / OCR comparison on suitable samples |
| F12 | BLOCKER | Extract tables from canonical image Datasets, not only PDFs. | Real scanned image with table |
| F13 | BLOCKER | Provide ROI-based reconstruction, row/column results, expected-column and header controls, and applicable type/schema inference. | Reconstructed table preview and settings changes |
| F14 | BLOCKER | Edit individual extracted cells before publishing; edits persist in published `table.generic` Dataset with correct variables, units where defined, metadata and provenance. | Before/after cell values, published Dataset verification |
| F15 | BLOCKER | Preserve Session association, editable review state and Workspace save/reopen; rejected source changes do not silently reuse stale results. | Save, close, reopen, changed-source test |
| F16 | MAJOR | Existing History/undo/redo behavior is respected for supported ROI/review operations; no false claims of support. | Actual edit/undo/reopen observations |
| F17 | BLOCKER | Switching documents/pages, repeated operations, invalid source, user cancellation and normal close/reopen do not hang the GUI or leave unbounded jobs/resources. | Real stress/negative GUI run and process/resource observations |
| F18 | BLOCKER | All four original Viewer feature sets are accounted for by name in a before/after parity register. Any missing feature is FAIL, not silently dropped or relabeled optional. | Feature inventory tied to original source/UI |

## 5. GUI usability, layout and visual-quality matrix

The validator **must open and operate the real GUI**; inspecting only screenshots, Tcldict or compilation output is insufficient. The result must be professionally usable, not a raw Builder demonstration.

| ID | Priority | Acceptance criterion | Evidence |
|---|---|---|---|
| G01 | BLOCKER | One coherent Viewer: PDF, OCR, tables and results are accessible in the same application without launching four external Viewer windows. | Full GUI walkthrough |
| G02 | MAJOR | Clear information hierarchy: source and document controls are distinct from processing choices, results, publishing and status. Common actions are easy to find. | Full-window screenshots with annotated observations |
| G03 | MAJOR | Layout is consistently aligned: balanced margins, spacing, labels, typography and control widths; no arbitrary empty areas, congested clusters or visual noise. | Normal/compact window screenshots |
| G04 | BLOCKER | Resize testing at approximately 1024×768 and 1440×900: no overlapping, clipped critical buttons, unusable text or controls rendered off-screen; scroll/panel behavior remains usable. | Two actual screenshots, controls exercised |
| G05 | MAJOR | Visual design is consistent with GX-TXT: purposeful icons, readable contrast, reasonable density and professional, restrained presentation. No missing/fallback icons or placeholder labels. | Icon/contrast review with screenshots |
| G06 | MAJOR | Controls provide understandable English names, units/defaults, states, tooltips/help where necessary; disabled actions and busy state are explained. | Interaction walkthrough and messages |
| G07 | MAJOR | Keyboard/focus order, text-edit behavior, table editing, mouse ROI operations, scroll/zoom and panel navigation are practical and predictable. | Real keyboard/mouse GUI checks |
| G08 | BLOCKER | Processing does not freeze the main GUI; progress, cancellation, errors and recovery are visible, and the user can close normally. | Real OCR / table / large-PDF run and cancellation |
| G09 | MAJOR | Workflow is economical: select source → inspect/ROI → OCR or table extraction → correct → publish, with no needless modal sequences or duplicate entry. | Task-based usability walkthrough |
| G10 | BLOCKER | The GUI is entirely English (menus, dialogs, status, dynamically generated errors, names, help). | Screen review plus string scan |

**Visual quality rubric:** score 0 (unacceptable), 1 (adequate), 2 (good) for each of five dimensions: hierarchy, alignment/spacing, readability, workflow clarity, and polish/consistency. Target at least **8/10**, with **no zero**. Record concrete issues and images; do not score solely on personal taste. A reproducible overlap/freeze/unusable control is a FAIL regardless of score.

## 6. Test material and negative cases

Use actual canonical Session Datasets from a controlled test Session: (1) native-text multipage PDF, (2) scanned/image-only multipage PDF, (3) PDF containing a real table, (4) image Dataset containing text/table, (5) document requiring at least one available non-English OCR language where installed, and (6) sufficiently large/complex PDF for responsiveness testing. Synthetic fixtures may supplement, **not replace**, realistic files. Avoid user/private scientific libraries and do not alter real Sessions.

For publication verify Dataset contract/ID, metadata, actual bytes/values and lineage, not merely the GUI status. Record screenshots of source, ROI, OCR result, table edit, publication result, errors, narrow layout and normal layout.

## 7. Patch, isolation and acceptance

| ID | Priority | Criterion | Evidence |
|---|---|---|---|
| D01 | BLOCKER | All changes remain in an isolated development copy; accepted DEV112.r2 release and owner installation remain untouched. | Pre/post hashes of authoritative artifacts |
| D02 | BLOCKER | Final payload is a **standard incremental DEV112 patch**, correct next sequential number and predecessor, containing actual changed files relative to the verified accepted baseline/patch state. No invented installer or Debian rebuild. | Patch file list, predecessor, SHA-256 |
| D03 | BLOCKER | Patch exists at the **absolute authoritative path** under `/srv/gxtxt/releases/dev112/patches/`, and its bytes and SHA-256 are verified by reading back from there. Development-relative ZIP is not delivery. | Final absolute path and independent readback |
| D04 | BLOCKER | Isolated install/apply and rollback preserve unrelated modules, original Viewers, user profiles, Session data and CORE public compatibility. | Apply/rollback focused evidence |
| D05 | MAJOR | Remaining work TODO is changed **only** for work actually completed and accepted; no speculative completion claims. | TODO diff or explicit unchanged statement |

## 8. Reporting and decision

Validator output: one `VALIDATOR_REPORT.md` with a status/evidence table by ID, categorized defects, source/API dependency audit, GUI screenshots and visual-quality rubric, plus an explicit **PASS / FAIL / INCOMPLETE** conclusion.

- **PASS** only if all BLOCKER and MAJOR criteria pass with evidence and requested feature parity is demonstrated.
- **FAIL** if any applicable BLOCKER fails (especially CORE → Viewer dependencies, Viewer → Viewer imports, missed original functionality, GUI hang or non-delivery).
- **INCOMPLETE** if essential GUI tests/evidence have not been executed; do not turn NOT_RUN into PASS.

Report identified defects promptly to MAIN, which retains responsibility to fix and retest them. The validator must remain independent and read-only. **Do not stop MAIN development for routine approval requests.** Final owner acceptance remains separate from technical validation.

## 9. Known initial facts — NOT acceptance

The earlier investigation reproduced `CAPABILITY_DENIED` when requesting `OCR_LAYOUT_API_v1/extractPdfPage` and `TABLE_EXTRACTOR_API_v1/extractDataset` through the restricted C++ profile. The CORE services themselves exist. During subsequent development, `core/python/gxtxt_document_extraction_worker.py` was seen importing private Python code from `viewer.pdf_ocr` and `viewer.table_extractor`. **That dependency violates A03/A04 and must be removed before acceptance.** Other implementation changes observed in the isolated development copy are not validated by this document.

**This matrix is an acceptance standard, not a command to modify the deposited DEV112.r2 release or to publish a Debian package.**
