// SPDX-License-Identifier: GPL-3.0-or-later
// Authored with the actual GX-TXT Interface Builder. CORE owns processing.
void on_event(gx::Host& host, gx::State& state, const gx::Event& event) {
    if (event.kind == gx::EventKind::open) {host.text(89, "Select a canonical PDF or image Dataset, then Open source."); return;}
    if (event.kind != gx::EventKind::invoke) return;
    if (event.component == 4) {host.documents_command(1, "open_source"); state.counter += 1;}
    else if (event.component == 5) {host.documents_command(1, "refresh_sources"); state.counter += 1;}
    else if (event.component == 27) {host.documents_command(1, "previous"); state.counter += 1;}
    else if (event.component == 28) {host.documents_command(1, "next"); state.counter += 1;}
    else if (event.component == 29) {host.documents_command(1, "render"); state.counter += 1;}
    else if (event.component == 30) {host.documents_command(1, "fit"); state.counter += 1;}
    else if (event.component == 31) {host.documents_command(1, "fit_width"); state.counter += 1;}
    else if (event.component == 32) {host.documents_command(1, "zoom_out"); state.counter += 1;}
    else if (event.component == 33) {host.documents_command(1, "zoom_in"); state.counter += 1;}
    else if (event.component == 34) {host.documents_command(1, "apply_zoom"); state.counter += 1;}
    else if (event.component == 35) {host.documents_command(1, "roi"); state.counter += 1;}
    else if (event.component == 36) {host.documents_command(1, "pan"); state.counter += 1;}
    else if (event.component == 37) {host.documents_command(1, "clear_roi"); state.counter += 1;}
    else if (event.component == 38) {host.documents_command(1, "select_page"); state.counter += 1;}
    else if (event.component == 53) {host.documents_command(1, "ocr"); state.counter += 1;}
    else if (event.component == 54) {host.documents_command(1, "publish_text"); state.counter += 1;}
    else if (event.component == 55) {host.documents_command(1, "copy_text"); state.counter += 1;}
    else if (event.component == 72) {host.documents_command(1, "table"); state.counter += 1;}
    else if (event.component == 73) {host.documents_command(1, "publish_table"); state.counter += 1;}
    else if (event.component == 80) {host.documents_command(1, "publish_image"); state.counter += 1;}
    else if (event.component == 81) {host.documents_command(1, "publish_page"); state.counter += 1;}
    else if (event.component == 86) {host.documents_command(1, "searchable_pdf"); state.counter += 1;}
    else if (event.component == 90) {host.documents_command(1, "cancel"); state.counter += 1;}
}
