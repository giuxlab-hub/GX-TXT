# SPDX-License-Identifier: GPL-3.0-or-later
"""CORE raster preparation for the existing managed document services.

Only pixel orientation, scaling and cropping live here. PDF decoding, OCR and
table reconstruction are owned by the public CORE service APIs.
"""
from __future__ import annotations
import hashlib
from pathlib import Path
import sys
import tkinter
import unicodedata


def tcl(value):
    if isinstance(value, dict):
        return tkinter._join([tcl(x) for pair in value.items() for x in pair])
    if isinstance(value, (list, tuple)):
        return tkinter._join([tcl(x) for x in value])
    return str(int(value)) if isinstance(value, bool) else str(value)



def main():
    interp = tkinter.Tcl()
    raw = Path(sys.argv[1]).read_text(encoding='utf-8')
    fields = interp.splitlist(raw)
    request = dict(zip(fields[::2], fields[1::2]))
    if request['python_operation'] == 'normalize_headers':
        print(tcl([unicodedata.normalize('NFKD', label).encode('ascii', 'ignore').decode('ascii') for label in interp.splitlist(request['labels'])]))
        return
    source = Path(request['path'])
    expected = request['sha256']
    if hashlib.file_digest(source.open('rb'), 'sha256').hexdigest() != expected:
        raise RuntimeError('Canonical source changed before processing')
    directory = Path(request['directory'])
    image_path = Path(request.get('image_path', str(source)))
    from PIL import Image, ImageOps
    with Image.open(image_path) as original:
        image = ImageOps.exif_transpose(original)
        # Preserve PNG-representable source samples, including alpha and 16-bit
        # grayscale, in the full-resolution publication image. Display scaling
        # uses a separate conversion and cannot change the publication pixels.
        if image.mode in {'1', 'L', 'LA', 'P', 'RGB', 'RGBA', 'I;16', 'I;16B'}:
            image = image.copy()
        elif image.mode in {'I', 'I;16L'}:
            image = image.convert('I;16')
        else:
            image = image.convert('RGBA' if 'A' in image.getbands() else 'RGB')
    width, height = image.size
    operation = request['python_operation']
    if operation == 'preview':
        full = directory / 'source.png'
        image.save(full)
        zoom = float(request.get('zoom', '0'))
        view_width = max(100, int(request.get('view_width', '1000')))
        view_height = max(100, int(request.get('view_height', '620')))
        scale = zoom / 100 if zoom > 0 else min(view_width / width, view_height / height) if zoom == 0 else view_width / width
        scale = max(0.005, min(8.0, scale))
        size = (max(1, round(width * scale)), max(1, round(height * scale)))
        if size[0] * size[1] > 24000000:
            raise RuntimeError('Zoom exceeds the 24-million display-pixel budget; reduce zoom')
        display = directory / 'display.png'
        display_image = image
        if image.mode in {'I;16', 'I;16B'}:
            display_image = image.convert('I').point(lambda value: value / 256).convert('L')
        display_mode = 'RGBA' if 'A' in display_image.getbands() or 'transparency' in display_image.info else 'RGB'
        display_image.convert(display_mode).resize(size, Image.Resampling.LANCZOS).save(display)
        result = dict(image_path=str(full), display_path=str(display), width=width,
                      height=height, display_width=size[0], display_height=size[1], zoom=scale * 100)
    elif operation == 'crop':
        values = [float(x) for x in interp.splitlist(request.get('roi', ''))]
        if values:
            if len(values) != 4 or not all(0 <= x <= 1 for x in values):
                raise ValueError('ROI must contain four normalized coordinates')
            x1, y1, x2, y2 = [round(v * extent) for v, extent in zip(values, (width, height, width, height))]
            left, top, right, bottom = min(x1, x2), min(y1, y2), max(x1, x2), max(y1, y2)
            if right <= left or bottom <= top:
                raise ValueError('ROI has no image pixels')
        else:
            left, top, right, bottom = 0, 0, width, height
        output = directory / 'crop.png'
        image.crop((left, top, right, bottom)).save(output)
        result = dict(output_path=str(output), roi_px=[left, top, right, bottom],
                      width=right-left, height=bottom-top, full_width=width, full_height=height)
    else:
        raise ValueError('Unsupported CORE raster operation')
    if hashlib.file_digest(source.open('rb'), 'sha256').hexdigest() != expected:
        raise RuntimeError('Canonical source changed during processing')
    print(tcl(result))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
