# Unified Documents

Unified Documents is an independent C++ Viewer authored in the GX-TXT Viewer Interface Builder and C++ Viewer Development Workspace. Its compiled event handlers use the public GUI Host and existing CORE OCR, PDF, table, Dataset, Workspace and History services. No other Viewer is imported, embedded or launched.

Select a canonical PDF or image Dataset and press **Open source**. The PDF / Image tab provides page selection, Previous/Next, DPI, zoom, fit, pan and normalized regions with eight resize handles. Drag inside a region to move it. Middle mouse pans. Render page applies page/DPI changes; Apply zoom uses the current rendered pixels.

In OCR, choose the PDF OCR plain-text workflow or Document OCR layout workflow, language codes joined by `+`, Tesseract PSM, and Region, Page or Document scope. Document OCR additionally supports Auto/native/OCR PDF text. Correct the recognized text in the editable preview, then publish a canonical UTF-8 document.text Dataset or copy the text.

In Tables, select a region on the page and choose Auto/native/OCR extraction. Expected columns guides the existing CORE reconstruction. Table Extractor requires a two-dimensional table and falls back to OCR if native text cannot reconstruct one. Document Tables supports multiple detected tables through its table index. Double-click preview cells, press Enter to commit or Escape to cancel. First row is header controls schema inference. Publish creates table.generic with labels, inferred types, source identity and provenance.

Images / Searchable PDF publishes a full-resolution selected crop or whole page as image.raster. Searchable PDF uses the CORE-owned OCRmyPDF/Tesseract workflow and qpdf verification on a PDF Dataset; an already searchable PDF may be rejected by OCRmyPDF, as in the original PDF OCR workflow. Source payloads remain unchanged. Output IDs must be valid canonical Dataset IDs and cannot replace another module's outputs.

Save, reopen and manage this Viewer's Workspace with the standard footer. Source identity, page/DPI/zoom, region, recognition settings, editable text and table are retained; rendered pixels are regenerated. History uses the existing CORE owner. Processing runs asynchronously through the existing managed job service; Cancel stops the owned request. Closing the Viewer cancels its outstanding operation and releases its temporary resources.

Runtime tools: Poppler, Tesseract (with requested language data), Pillow; OCRmyPDF and qpdf for searchable PDF. Missing tools and invalid sources produce visible errors. Display images have a 24-million-pixel budget and editable OCR text has a 4 MiB limit; canonical full-resolution output is preserved. No original Viewers are runtime dependencies.
