# DEV112-P004 cumulative owner-review candidate

One net overlay admits exact clean DEV112.r2 or exact DEV112.r2+P001+corrected P002+P003.
No intermediate patches are executed or separately needed for clean r2. No other states are supported.
Verify SHA256SUMS and use the standalone helper delivered beside the archive.

```text
python3 -I -B apply.py FRAMEWORK DEV112-P004.zip --check
python3 -I -B apply.py FRAMEWORK DEV112-P004.zip --apply --owner-authorized --stopped
python3 -I -B apply.py FRAMEWORK DEV112-P004.zip --rollback --route r2 --owner-authorized --stopped
python3 -I -B apply.py FRAMEWORK DEV112-P004.zip --rollback --route post-p003 --owner-authorized --stopped
```

Preserve the apply stdout JSON audit; it records route, source identities and completed writes.
Rollback requires the original route explicitly: final product bytes are identical for both routes.
Flags acknowledge separately granted authorization and stopped target; they grant neither.
Whole-tree replacement is not atomic. Each file is atomically replaced and fsynced; PATCH_LEVEL is committed last.
Concurrent modification is unsupported. Interrupted mixed states refuse automatic continuation.
Preserve logs/files and restore the exact original only under owner control. Empty created directories may remain after rollback.
All shipped source trees are exact: undeclared files/directories there and extra root executable/source files refuse.
Unrelated extra user data outside source trees, including Sessions, is preserved. Additional installed modules in the factory plugins tree are outside these exact supported routes and refuse safely.
No automatic migration, activation, process stop/detection or acceptance is performed.
