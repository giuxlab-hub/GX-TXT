# Native Canvas Demonstrator

Original Restricted C++ client of the CORE Canvas component. Two independent
Canvases share a splitter; Canvas B is in a normal tab. The design was authored
in the actual graphical Interface Builder; its saved bytes remain unchanged.

Draw with the CORE tool selector. Ctrl-drag edits native controls; Escape cancels.
Use the CORE layer/object inspectors for flags, opacity, order, group and merge.
Copy/Paste uses the CORE managed clipboard between compatible layers/Canvases.
Undo/Redo are independent per Canvas; Viewer History/Workspace is global.

Choose a canonical raster Dataset and Bind image to A. Select its image before
Invert A. Filtering and full flatten produce explicit RGBA8 sRGB derived data;
original source bytes remain immutable. Save A/B saves their independent native
documents. Workspace Save retains the full Viewer state and bindings. Publish A
creates a new canonical PNG named canvas.demonstration.output; editable objects
remain intact. Cancel A cancels a pending managed request.

No example/source image is bundled as scientific data. Runtime needs an active
Session; source-free drawings need no Dataset. The module contains no editor,
geometry algorithm, pixel processing or private framework calls.

The Development Workspace Test checks compiled open-event/ABI admission only;
functional appearance, gestures, source guards and performance use separate
mapped-GUI evidence. Candidate installation does not imply owner acceptance.
