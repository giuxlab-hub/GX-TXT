// SPDX-License-Identifier: GPL-3.0-or-later
// Original demonstrator. CORE owns editing, geometry and resources.
void on_event(gx::Host& host, gx::State&, const gx::Event& event) {
    if (event.kind != gx::EventKind::invoke) return;
    if (event.component == 7) host.canvas_command(2, "bind_source", gx::workspace_object({{"source_selector", gx::workspace_integer(6)}}));
    if (event.component == 8) host.canvas_command(2, "filter", gx::workspace_object({{"name", gx::workspace_text("invert")}}));
    if (event.component == 9) host.canvas_command(2, "save", gx::workspace_object({}));
    if (event.component == 10) host.canvas_command(3, "save", gx::workspace_object({}));
    if (event.component == 11) host.canvas_command(2, "publish", gx::workspace_object({{"dataset_id", gx::workspace_text("canvas.demonstration.output")}, {"name", gx::workspace_text("Canvas demonstration composition")}, {"format", gx::workspace_text("png")}, {"precision", gx::workspace_text("rgba8")}}));
    if (event.component == 12) host.canvas_command(2, "cancel", gx::workspace_object({}));
}
