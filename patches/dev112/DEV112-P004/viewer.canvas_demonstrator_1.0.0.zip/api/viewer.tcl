# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted generated facade; author logic is restricted C++ in a separate worker.
::GX::workbenchExtensionRequireApi VIEWER_DEVELOPMENT_API_v1
namespace eval ::GX::Restricted_viewer_canvas_demonstrator {variable root [file dirname [file dirname [info script]]]}
proc ::GX::Restricted_viewer_canvas_demonstrator::handlers {} {return [::GX::viewerDevelopmentInstalledBindings viewer.canvas_demonstrator canvas_demonstrator [set ::GX::Restricted_viewer_canvas_demonstrator::root]]}
proc ::GX::Restricted_viewer_canvas_demonstrator::dispatch {operation scene} {return [::GX::viewerDevelopmentInstalledOpen viewer.canvas_demonstrator canvas_demonstrator [set ::GX::Restricted_viewer_canvas_demonstrator::root] [::GX::datasetPublicationV2DictDefault $scene open_context {}]]}
proc ::GX::Restricted_viewer_canvas_demonstrator::workspaceOpen {context} {return [::GX::viewerDevelopmentInstalledOpen viewer.canvas_demonstrator canvas_demonstrator [set ::GX::Restricted_viewer_canvas_demonstrator::root] $context]}
proc ::GX::Restricted_viewer_canvas_demonstrator::texOpen {document} {return [::GX::viewerDevelopmentInstalledOpen viewer.canvas_demonstrator canvas_demonstrator [set ::GX::Restricted_viewer_canvas_demonstrator::root] [dict create tex_document_id $document]]}
::GX::viewerBackendRegister viewer_canvas_demonstrator_restricted_cpp_v1 ::GX::Restricted_viewer_canvas_demonstrator::dispatch
