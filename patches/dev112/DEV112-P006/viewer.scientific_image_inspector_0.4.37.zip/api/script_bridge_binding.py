"""Inert metadata supplied by the existing viewer.scientific_image_inspector public owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_OPERATIONS = ('apiInfo',)
REGISTRATION = {
    'api_id': 'SCIENTIFIC_IMAGE_INSPECTOR_API_v1', 'api_version': 1,
    'provider_kind': 'module', 'provider_id': 'viewer.scientific_image_inspector',
    'documentation_ref': 'plugins/modules/viewer.scientific_image_inspector/MANUAL.md',
    'operations': {name: {'name': name, 'summary': 'Read existing provider metadata: '+name,
        'arguments': [], 'argument_convention': 'no arguments',
        'result_contract': 'Typed inert public owner metadata; no GUI/scientific operation'}
        for name in _OPERATIONS},
}


_LEAVES = ('manifest_get', 'manifest_summary', 'annotations_json', 'inspect', 'catalog', 'capabilities')
_READERS = _LEAVES + ('apiCall',)
_CONTROL_MAX = 1048576
_MANIFEST_MAX = 524288
for _name in _READERS:
    _args = ([('operation', 'one original literal leaf'), ('argument', 'leaf Dataset ID or catalog query', False)]
             if _name == 'apiCall' else [('query', 'optional catalog query', False)] if _name == 'catalog'
             else [] if _name == 'capabilities' else [('dataset_id', 'current canonical Dataset ID (registered local or remote)' if _name in ('manifest_get', 'manifest_summary', 'annotations_json') else 'current local canonical Dataset ID')])
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Original bounded headless SII owner: '+_name,
        'arguments': [{'name': item[0], 'kind': item[1], 'required': item[2] if len(item)>2 else True} for item in _args],
        'argument_convention': ', '.join(item[0] for item in _args) or 'no arguments',
        'result_contract': ('Exact retained original annotation JSON UTF-8' if _name == 'annotations_json' else
                            'Bounded original owner data; retained provenance/current output validation distinguished; no caller path/program/view authority'),
    }


# PUBLIC_SII_DTO02: explicit managed methods, separate from legacy apiCall.
# Preparation is portable DATA, never a process-local token or authority.
_PROCESSING_ARGUMENTS = {
    'presets': (),
    'validate_steps': ('steps',),
    'processing_prepare': ('request',),
    'processing_submit': ('preparation',),
    'processing_status': ('job_id',),
    'processing_cancel': ('job_id',),
    'processing_result': ('job_id',),
    'processing_resource': ('job_id', 'output_token', 'document_guard'),
    'processing_publish': ('job_id', 'output_token', 'publication'),
}
_PROCESSING_RESULTS = {
    'presets': 'Exact original preset recipe records; native Workspace typed array',
    'validate_steps': 'Original normalized validated steps; native Workspace typed array',
    'processing_prepare': 'Normalized source/runtime-pinned DATA; correlation digest confers no authority',
    'processing_submit': 'Revalidated DATA, original prepare+submit in SAME Host; durable owned Job receipt',
    'processing_status': 'Original bounded typed owned SII Job status; no private paths/ENV/commands',
    'processing_cancel': 'Original Supervisor cancellation/status; no output adoption',
    'processing_result': 'Complete source-current result descriptors/analysis/provenance; no truncated image claim',
    'processing_resource': 'Complete original Document Resource with owner_generation/count/SHA',
    'processing_publish': 'Original new canonical Dataset receipt and SII manifest/source/output SHA',
}
for _name, _arguments in _PROCESSING_ARGUMENTS.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Original managed SII owner: ' + _name,
        'arguments': [{'name': name, 'kind': 'closed PUBLIC_SII_DTO02 value', 'required': True}
                      for name in _arguments],
        'argument_convention': ', '.join(_arguments) or 'no arguments',
        'result_contract': _PROCESSING_RESULTS[_name],
    }


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    if isinstance(value, bytes): return value.decode('utf-8')
    return str(host.tcl.call('format', '%s', value))


def _map(host, value):
    return {str(k): _text(host, v) for k, v in host.as_dict(value).items()}


def _bounded(value):
    import json
    if len(json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')) > _CONTROL_MAX:
        _invalid('SII public metadata exceeds its1MiB UTF-8 result limit')
    return value


def _stamp(host, dataset, inspecting=False):
    import hashlib
    session = _text(host, host.call('::GX::interactiveDocumentSessionToken'))
    record = host.as_dict(host.call('::GX::sessionInspectionDataset', dataset, host.session))
    remote = str(record.get('storage_provider', '')) == 'remote'
    revision = host.call('::GX::datasetRevisionToken', dataset, host.session)
    metadata = host.call('::GX::datasetMetadataRead', host.session, dataset)
    if remote:
        # Preserve the original retained-reader verifier's best-effort contract.
        # Authentication concerns only registered remote revision/metadata;
        # there is no local byte hash or assertion about parent-source freshness.
        validation = {'state': 'retained_remote_metadata_unverified',
                      'remote_metadata_verified': False, 'local_payload_verified': False,
                      'parent_sources_current': 'not_asserted'}
        if not inspecting:
            try:
                payload = host.as_dict(host.call('::GX::sessionInspectionDatasetPayload', dataset, host.session))
            except Exception:
                pass  # Original manifestGet likewise retains metadata on unavailable verification.
            else:
                validation.update(state='authenticated_remote_metadata', remote_metadata_verified=True,
                    remote_origin=_map(host, payload['remote_source']))
        # inspect still calls original sourceInfo, whose payload must be a
        # regular local file; no remote raster reader/materializer is added.
    else:
        try:
            location = host.as_dict(host.call('::GX::sessionInspectionDatasetLocation', dataset, host.session))
        except Exception as exc:
            if inspecting or not str(exc).startswith("Dataset '"+dataset+"' payload is missing: "):
                raise
            validation = {'state': 'missing_retained_only', 'local_payload_verified': False,
                          'registered_sha256': str(record.get('canonical_sha256', '')),
                          'parent_sources_current': 'not_asserted'}
        else:
            if inspecting and int(location['size_bytes']) > 67108864:
                _invalid('SII local inspection source exceeds64MiB encoded bytes')
            payload = host.as_dict(host.call('::GX::sessionInspectionDatasetPayload', dataset, host.session))
            validation = {'state': 'verified_local_payload_sha256', 'local_payload_verified': True,
                          'sha256': str(payload['sha256']), 'parent_sources_current': 'not_asserted'}
    pieces = [session, _text(host, revision), _text(host, metadata), str(validation)]
    digest = hashlib.sha256('\0'.join(pieces).encode('utf-8')).hexdigest()
    return digest, validation


def _steps(host, value):
    result = []
    for raw in host.as_list(value):
        item = _map(host, raw)
        source = host.as_dict(raw)
        if 'params' in source: item['params'] = _map(host, source['params'])
        if 'roi' in source: item['roi'] = [_text(host, v) for v in host.as_list(source['roi'])]
        result.append(item)
    return result


def _manifest(host, raw, validation, stamp):
    source = host.as_dict(raw)
    exact = _text(host, raw)
    # This is AFTER the original canonical metadata read/owner validation.
    if len(exact.encode('utf-8')) > _MANIFEST_MAX: _invalid('Retained SII manifest exceeds512KiB UTF-8')
    value = _map(host, raw)
    for field in ('source_sha256_map', 'figure_settings', 'coordinate_system'):
        if field in source: value[field] = _map(host, source[field])
    if 'source_facts' in source:
        facts = {}
        for key, item in host.as_dict(source['source_facts']).items():
            mapped = _map(host, item);parts = host.as_dict(item)
            if 'dataset_metadata' in parts: mapped['dataset_metadata'] = _map(host, parts['dataset_metadata'])
            facts[str(key)] = mapped
        value['source_facts'] = facts
    value['operation_steps'] = _steps(host, source['operation_steps'])
    panels = []
    for panel in host.as_list(source['figure_panels']):
        item = _map(host, panel);parts = host.as_dict(panel)
        if 'steps' in parts: item['steps'] = _steps(host, parts['steps'])
        panels.append(item)
    value['figure_panels'] = panels
    value['annotations'] = [_map(host, item) for item in host.as_list(source['annotations'])]
    if (value['schema'] == 'scientific_image_inspector.manifest.v2' and
            value['source_profile'] == 'native_canvas_document_v1'):
        # Explicit original-owner union. Packed Tcl records remain opaque inert
        # base64 text; never infer/decode their nested scientific/native values.
        native = host.as_dict(source['native_canvas'])
        value['native_canvas'] = _map(host, source['native_canvas'])
        for field in ('output_receipt', 'producing_job'):
            value['native_canvas'][field] = _map(host, native[field])
        counts = host.as_dict(source['native_counts'])
        value['native_counts'] = {field: int(counts[field]) for field in
            ('images', 'annotations', 'objects', 'resources', 'canonical_sources')}
    elif (value['schema'] == 'scientific_image_inspector.manifest.v2' and
            value['source_profile'] == 'selected_current_resource_v1'):
        selected = host.as_dict(source['selected_resource'])
        value['selected_resource'] = _map(host, source['selected_resource'])
        for field in ('output_receipt', 'producing_job'):
            value['selected_resource'][field] = _map(host, selected[field])
        counts = host.as_dict(source['selected_counts'])
        value['selected_counts'] = {field: int(counts[field]) for field in
            ('images', 'resources', 'canonical_sources')}
    elif value['schema'] == 'scientific_image_inspector.manifest.v2':
        _invalid('Unsupported retained SII manifest source profile')
    value['output'] = _map(host, source['output']);output = host.as_dict(source['output'])
    if 'raster_properties' in output: value['output']['raster_properties'] = _map(host, output['raster_properties'])
    return {'manifest': value, 'manifest_tcl_utf8': exact, 'output_validation': validation,
            'source_receipt': {'dataset_id': str(value['output']['dataset_id']), 'sha256': stamp},
            'numeric_lexemes': 'Original retained text; no guessed scientific conversion'}


def _read(host, operation, args):
    if operation == 'apiCall':
        if not args or not isinstance(args[0], str) or args[0] not in _LEAVES:
            _invalid('SII apiCall accepts only its original six literal reader/query operations')
        operation, args = args[0], args[1:]
    if operation == 'capabilities':
        if args: _invalid('SII capabilities takes no arguments')
    elif operation == 'catalog':
        if len(args)>1 or args and (not isinstance(args[0], str) or '\0' in args[0] or len(args[0].encode('utf-8'))>4096):
            _invalid('SII catalog takes only an optional bounded query string')
    elif len(args)!=1 or not isinstance(args[0], str) or not args[0] or '\0' in args[0] or len(args[0].encode('utf-8'))>256:
        _invalid('SII readers take exactly one current canonical Dataset identity')
    dataset = args[0] if operation not in ('catalog', 'capabilities') else None
    if dataset is not None:
        host.call('::GX::datasetPublicationV2ValidateId', 'dataset', dataset)
        stamp, validation = _stamp(host, dataset, operation=='inspect')
    host.call('::GX::modulePublicApiActivate', 'viewer.scientific_image_inspector', 'SCIENTIFIC_IMAGE_INSPECTOR_API_v1')
    # Literal dispatch is exclusively the original finite owner, not a caller
    # procedure/library/path/program/renderer or arbitrary namespace lookup.
    raw = host.call('::GX::SII::apiCall', operation, *args)
    if dataset is not None:
        after, after_validation = _stamp(host, dataset, operation=='inspect')
        if after != stamp:
            raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Canonical SII Dataset/metadata/payload/Session changed while reading')
    if operation == 'annotations_json': return _bounded(_text(host, raw))
    if operation == 'manifest_get': return _bounded(_manifest(host, raw, validation, stamp))
    if operation == 'manifest_summary':
        source = host.as_dict(raw);result = _map(host, raw)
        for field in ('operation_count','panel_count','annotation_count'): result[field] = int(source[field])
        if (result['schema'] == 'scientific_image_inspector.manifest.v2' and
                result['source_profile'] == 'native_canvas_document_v1'):
            result['object_count'] = int(source['object_count'])
        elif (result['schema'] == 'scientific_image_inspector.manifest.v2' and
                result['source_profile'] == 'selected_current_resource_v1'):
            for field in ('image_count', 'resource_count', 'canonical_source_count'):
                result[field] = int(source[field])
        elif result['schema'] == 'scientific_image_inspector.manifest.v2':
            _invalid('Unsupported retained SII summary source profile')
        result['sources'] = _map(host, source['sources']);result['output'] = _map(host, source['output'])
        output = host.as_dict(source['output'])
        if 'raster_properties' in output: result['output']['raster_properties'] = _map(host, output['raster_properties'])
        result['output_validation'] = validation
        return _bounded(result)
    if operation == 'inspect':
        source = host.as_dict(raw);result = _map(host, raw);result.pop('path', None)
        result['metadata'] = _map(host, source['metadata'])
        for field in ('size_bytes','width','height','pixel_count','depth','frames','frame_count'):
            if field in result and result[field] != 'unavailable': result[field] = int(result[field])
        result['output_validation'] = validation;result['source_receipt'] = {'dataset_id': dataset, 'sha256': stamp}
        return _bounded(result)
    if operation == 'capabilities': return _bounded(_map(host, raw))
    result = []
    for spec in host.as_list(raw):
        source = host.as_dict(spec);item = _map(host, spec);item['roi'] = bool(host.tcl.getboolean(source['roi']))
        params = []
        for parameter in host.as_list(source['params']):
            values = host.as_list(parameter)
            if len(values)!=6: _invalid('Original SII catalog parameter contract changed')
            params.append([_text(host, v) for v in values[:5]] + [[_text(host, v) for v in host.as_list(values[5])]])
        item['params'] = params;result.append(item)
    return _bounded(result)


def _processing_text(value, label, empty=False):
    if not isinstance(value, str) or (not empty and not value) or '\0' in value:
        _invalid('SII ' + label + ' requires UTF-8 text without NUL')
    try:
        value.encode('utf-8')
    except UnicodeError:
        _invalid('SII ' + label + ' requires valid UTF-8')
    return value


def _processing_fields(value, required, optional, label):
    if not isinstance(value, dict) or not set(required) <= value.keys() or value.keys() - set(required) - set(optional):
        _invalid('Invalid closed SII ' + label + ' fields')
    return dict(value)


def _processing_integer(value, label):
    import math
    # Ordinary Octave control scalars may be exact integral binary64. This
    # normalization never rounds; scientific range checks stay in SII.
    if type(value) is float and math.isfinite(value) and value.is_integer():
        value = int(value)
    if type(value) is not int:
        _invalid('SII ' + label + ' requires an exact integer')
    return value


def _processing_number(value, label):
    import math
    if type(value) not in (int, float) or type(value) is float and not math.isfinite(value):
        _invalid('SII ' + label + ' requires a finite number')
    return value


def _processing_array(value, label, maximum=None, minimum=0):
    from gxtxt_script_bridge_server import NumericArray
    # Ordinary Octave [] is an empty NumericArray, including for an empty
    # recipe/annotation array. Nonempty record arrays still need actual lists.
    if type(value) is NumericArray and not len(value.values): value = []
    if not isinstance(value, (list, tuple)) or len(value) < minimum or maximum is not None and len(value) > maximum:
        _invalid('Invalid SII ' + label + ' array')
    return list(value)


def _processing_integer_array(value):
    from gxtxt_script_bridge_server import NumericArray
    from gxtxt_cell_v1 import CellArray
    if isinstance(value, CellArray):
        if not value: return []
        if len(value.shape) != 2 or 1 not in value.shape:
            _invalid('SII ROI requires a cell vector, not a shaped cell matrix')
    if type(value) is NumericArray:
        if not len(value.values): return []
        shape = value.shape
        if not (len(shape) == 1 or len(shape) == 2 and 1 in shape):
            _invalid('SII ROI requires a numeric vector')
        value = value.values.tolist() if hasattr(value.values, 'tolist') else list(value.values)
    value = _processing_array(value, 'ROI')
    return [_processing_integer(v, 'ROI coordinate') for v in value]


def _processing_rectangle(value, empty=False):
    value = _processing_integer_array(value)
    if len(value) != 4 and not (empty and not value):
        _invalid('SII ROI requires four integers or the declared empty ROI')
    return value


def _processing_sha(value, label, lower=False):
    value = _processing_text(value, label)
    if len(value) != 64 or any(c not in '0123456789abcdefABCDEF' for c in value):
        _invalid('SII ' + label + ' requires an exact SHA-256 hex value')
    if lower and value != value.lower():
        _invalid('SII ' + label + ' requires lowercase SHA-256 hex')
    return value


def _processing_source(value):
    value = _processing_fields(value, ('dataset_id', 'source_sha256', 'source_revision'), (), 'source guard')
    value['dataset_id'] = _processing_text(value['dataset_id'], 'Dataset ID')
    for key in ('source_sha256', 'source_revision'):
        value[key] = _processing_sha(value[key], key)
    return value


def _processing_steps(value):
    result = []
    for raw in _processing_array(value, 'steps', 64):
        step = _processing_fields(raw, ('op', 'params'), ('scope', 'roi'), 'step')
        step['op'] = _processing_text(step['op'], 'catalog operation')
        scope = step.get('scope', 'all')
        if scope not in ('all', 'roi'):
            _invalid('SII step scope must be all or roi')
        if not isinstance(step['params'], dict):
            _invalid('SII step parameters require a dictionary of primitive values')
        params = {}
        for key, item in step['params'].items():
            key = _processing_text(key, 'parameter name')
            params[key] = (_processing_text(item, 'parameter', True) if isinstance(item, str)
                           else _processing_number(item, 'parameter'))
        step['params'] = params
        if scope == 'roi':
            if 'roi' not in step: _invalid('SII ROI step requires its rectangle')
            step['roi'] = _processing_rectangle(step['roi'])
        elif 'roi' in step:
            # DTO03 preserves original inactive ROI data. Its length/area and
            # source bounds have active-ROI semantics only when scope is roi.
            step['roi'] = _processing_integer_array(step['roi'])
        result.append(step)
    return result


def _processing_annotation(value):
    required = ('kind', 'x1', 'y1')
    common = ('color', 'stroke', 'rotation', 'pivot_x', 'pivot_y', 'name', 'id')
    text = ('text', 'size', 'font_family', 'font_unit', 'font_value', 'font_dpi', 'box_width', 'box_height')
    if not isinstance(value, dict) or value.get('kind') not in ('text', 'line', 'arrow', 'rectangle', 'ellipse'):
        _invalid('SII annotation requires one original annotation kind')
    is_text = value['kind'] == 'text'
    value = _processing_fields(value, required if is_text else required + ('x2', 'y2'), common + text if is_text else common, 'annotation')
    for key in ('kind', 'color', 'name', 'id', 'text', 'font_family', 'font_unit'):
        if key in value: value[key] = _processing_text(value[key], 'annotation ' + key, key in ('text', 'name'))
    for key in ('x1', 'y1', 'x2', 'y2', 'stroke', 'size', 'font_dpi', 'box_width', 'box_height'):
        if key in value: value[key] = _processing_integer(value[key], 'annotation ' + key)
    for key in ('rotation', 'pivot_x', 'pivot_y', 'font_value'):
        if key in value: value[key] = _processing_number(value[key], 'annotation ' + key)
    if ('pivot_x' in value) != ('pivot_y' in value):
        _invalid('SII annotation pivot requires both coordinates')
    # Original SII alone checks text character semantics, colors/fonts, bounds,
    # defaults, zero-length geometry and rendering. No UTF-8 byte surrogate cap.
    return value


def _processing_request(value):
    if not isinstance(value, dict): _invalid('SII preparation requires a closed request')
    if 'facts_profile' in value and (not isinstance(value['facts_profile'], str) or value['facts_profile'] != 'stored_f32_full_v1'):
        _invalid('SII facts_profile accepts only stored_f32_full_v1 when present')
    if value.get('kind') == 'image':
        value = _processing_fields(value, ('kind', 'source', 'operation', 'steps'), ('format', 'analysis', 'analysis_target', 'facts_profile'), 'image request')
        action = value['operation']
        options = {'process': (), 'inspect': (), 'statistics': ('channel', 'roi'),
                   'histogram': ('channel', 'roi'), 'palette': ('roi', 'colors'),
                   'pixel': ('x', 'y'), 'channel_preview': ('channel',)}
        if not isinstance(action, str) or action not in options: _invalid('Unknown finite SII image operation')
        value['source'] = _processing_source(value['source'])
        value['steps'] = _processing_steps(value['steps'])
        if 'format' in value and (action != 'process' or value['format'] not in ('png16', 'tiff16', 'tiff32f', 'miff')):
            _invalid('SII image format applies only to original processing formats')
        target = value.get('analysis_target', 'Working')
        if target not in ('Working', 'Source', 'Preview'): _invalid('Unknown SII analysis target role')
        analysis = _processing_fields(value.get('analysis', {}), ('x', 'y') if action == 'pixel' else (), options[action], 'analysis')
        if 'roi' in analysis:
            analysis['roi'] = _processing_rectangle(analysis['roi'], True)
            if analysis['roi'] and target != 'Working': _invalid('SII analysis ROI requires the Working target')
        if 'channel' in analysis: analysis['channel'] = _processing_text(analysis['channel'], 'analysis channel')
        for key in ('x', 'y', 'colors'):
            if key in analysis: analysis[key] = _processing_integer(analysis[key], 'analysis ' + key)
        if 'analysis' in value or action == 'pixel': value['analysis'] = analysis
        return value
    if value.get('kind') == 'figure':
        value = _processing_fields(value, ('kind', 'panels', 'settings', 'annotations', 'format'), ('facts_profile',), 'figure request')
        if value['format'] not in ('png16', 'tiff16', 'tiff32f'): _invalid('Unknown SII figure publication format')
        panels = []
        for raw in _processing_array(value['panels'], 'panels', 12, 1):
            panel = _processing_fields(raw, ('source', 'steps'), (), 'panel')
            panel['source'] = _processing_source(panel['source'])
            panel['steps'] = _processing_steps(panel['steps'])
            panels.append(panel)
        value['panels'] = panels
        settings = _processing_fields(value['settings'], (), ('width', 'height', 'margin', 'gutter', 'layout', 'background'), 'figure settings')
        for key in ('width', 'height', 'margin', 'gutter'):
            if key in settings: settings[key] = _processing_integer(settings[key], 'figure ' + key)
        for key in ('layout', 'background'):
            if key in settings: settings[key] = _processing_text(settings[key], 'figure ' + key)
        value['settings'] = settings
        value['annotations'] = [_processing_annotation(a) for a in _processing_array(value['annotations'], 'annotations')]
        return value
    _invalid('SII request kind must be image or figure')


def _processing_document(value):
    value = _processing_fields(value, ('document_id', 'generation', 'revision', 'sha256'), (), 'Document guard')
    for key in ('document_id', 'generation'): value[key] = _processing_text(value[key], 'Document ' + key)
    value['revision'] = _processing_integer(value['revision'], 'Document revision')
    if value['revision'] <= 0: _invalid('SII Document revision requires a positive exact integer')
    value['sha256'] = _processing_sha(value['sha256'], 'Document SHA')
    return value


def _processing_preparation(value):
    required = ('schema', 'request', 'provider_id', 'provider_version', 'worker_sha256',
                'adapter_sha256', 'runtime_files', 'source_guards', 'preparation_sha256')
    value = _processing_fields(value, required, (), 'portable preparation DATA')
    if value['schema'] != 'scientific_image_inspector.processing_preparation.v1':
        _invalid('Unsupported SII preparation DATA schema')
    value['request'] = _processing_request(value['request'])
    for key in ('provider_id', 'provider_version'):
        value[key] = _processing_text(value[key], key)
    for key in ('worker_sha256', 'adapter_sha256', 'preparation_sha256'):
        value[key] = _processing_sha(value[key], key)
    if not isinstance(value['runtime_files'], dict):
        _invalid('SII runtime fingerprints require the original hash map')
    value['runtime_files'] = {_processing_text(k, 'runtime fingerprint key'): _processing_sha(v, 'runtime fingerprint')
                              for k, v in value['runtime_files'].items()}
    value['source_guards'] = _processing_preparation_guards(value['source_guards'])
    # No digest recomputation or source/provider comparison here: correlation
    # DATA grants nothing. The original owner revalidates every live guard and
    # performs original prepare+submit in this SAME Host.
    return value


def _processing_preparation_guards(value):
    value = _processing_fields(value, ('session_fingerprint', 'session_origin', 'datasets'), (), 'preparation source guards')
    value['session_fingerprint'] = _processing_sha(value['session_fingerprint'], 'Session fingerprint', True)
    # Exact original sessionOriginRead Tcl dictionary TEXT: neither parsed nor
    # evaluated, and never replaced by a guessed Python schema or authority.
    value['session_origin'] = _processing_text(value['session_origin'], 'Session origin', True)
    datasets = []
    for raw in _processing_array(value['datasets'], 'preparation datasets', 12, 1):
        record = _processing_fields(raw, ('dataset_id', 'source_sha256', 'source_revision', 'source_stamp'), (), 'preparation Dataset identity')
        record['dataset_id'] = _processing_text(record['dataset_id'], 'Dataset ID')
        for key in ('source_sha256', 'source_revision', 'source_stamp'):
            record[key] = _processing_sha(record[key], key, True)
        datasets.append(record)
    # First-appearance deduplication/conflicts and current identity comparison
    # belong to the original owner. These three digests are distinct guards;
    # no read stamp is treated as payload/Resource bytes or authentication.
    value['datasets'] = datasets
    return value


def _processing_publication(value):
    value = _processing_fields(value, ('dataset_id', 'format'), ('workspace_id',), 'publication')
    value['dataset_id'] = _processing_text(value['dataset_id'], 'new Dataset ID')
    if value['format'] not in ('png16', 'tiff16', 'tiff32f'): _invalid('Unknown SII publication format')
    if 'workspace_id' in value: value['workspace_id'] = _processing_text(value['workspace_id'], 'Workspace ID', True)
    return value


def _processing_structure(value, depth=0):
    # Inherited public argument depth, independently for each application arg.
    # No new total UTF-8/node/annotation limit or fixed wrapper depth charge.
    if depth > 32: _invalid('SII value exceeds inherited public argument depth32')
    if isinstance(value, dict):
        return {_processing_text(k, 'field name'): _processing_structure(v, depth + 1) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_processing_structure(v, depth + 1) for v in value]
    if isinstance(value, str): return _processing_text(value, 'value', True)
    return _processing_number(value, 'value')


def _processing_facts_error():
    raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original SII optional facts summary violates its closed typed contract')


def _processing_facts_fields(value, required, optional=()):
    if type(value) is not dict or not set(required) <= value.keys() or value.keys() - set(required) - set(optional):
        _processing_facts_error()
    return value


def _processing_facts_text(value, expected=None):
    if type(value) is not str or not value or '\0' in value:
        _processing_facts_error()
    try: value.encode('utf-8')
    except UnicodeError: _processing_facts_error()
    if expected is not None and value != expected: _processing_facts_error()


def _processing_facts_hex(value, digits):
    if type(value) is not str or len(value) != digits or any(c not in '0123456789abcdef' for c in value):
        _processing_facts_error()


def _processing_facts_count(value):
    if type(value) is not int or not 0 <= value <= 9223372036854775807:
        _processing_facts_error()


def _processing_facts_source(value):
    required = ('source_alias', 'source_kind', 'source_revision', 'encoded_sha256', 'encoded_size_bytes',
                'coverage', 'word_basis', 'word_digest_order', 'finite_order', 'channels',
                'logical_values', 'profile_facts', 'profile_coverage')
    value = _processing_facts_fields(value, required, ('canonical_source_sha256',))
    for key in ('source_alias', 'source_kind', 'source_revision'): _processing_facts_text(value[key])
    if value['source_kind'] not in ('canonical_dataset', 'document_resource'): _processing_facts_error()
    if 'canonical_source_sha256' in value:
        if value['source_kind'] != 'canonical_dataset': _processing_facts_error()
        _processing_facts_hex(value['canonical_source_sha256'], 64)
    _processing_facts_hex(value['encoded_sha256'], 64)
    _processing_facts_count(value['encoded_size_bytes'])
    constants = {
        'word_basis': 'losslessly_decoded_IEEE_binary32_before_float_evaluation_or_color_alpha_photometric_transform',
        'word_digest_order': 'row_major_per_channel_canonical_little_endian_words',
        'finite_order': 'numeric_order_negative_zero_before_positive_zero',
    }
    for key, expected in constants.items(): _processing_facts_text(value[key], expected)
    coverage = _processing_facts_fields(value['coverage'], ('frame', 'admitted_frame_count', 'x', 'y', 'width',
                                      'height', 'pixels_per_channel', 'rows_scanned', 'complete', 'channels'))
    for key in ('frame', 'admitted_frame_count', 'x', 'y', 'width', 'height', 'pixels_per_channel', 'rows_scanned'):
        _processing_facts_count(coverage[key])
    if (coverage['frame'] != 0 or coverage['admitted_frame_count'] != 1 or coverage['x'] != 0 or coverage['y'] != 0
            or coverage['width'] < 1 or coverage['height'] < 1 or coverage['complete'] is not True
            or coverage['rows_scanned'] != coverage['height']
            or coverage['pixels_per_channel'] != coverage['width'] * coverage['height']):
        _processing_facts_error()
    names = coverage['channels']
    if type(names) is not list or not 1 <= len(names) <= 4: _processing_facts_error()
    for name in names: _processing_facts_text(name)
    if len(set(names)) != len(names): _processing_facts_error()
    channels = value['channels']
    if type(channels) is not list or len(channels) != len(names): _processing_facts_error()
    classes = ('normal', 'subnormal', 'positive_zero', 'negative_zero', 'positive_inf', 'negative_inf', 'nan')
    for name, raw in zip(names, channels):
        channel = _processing_facts_fields(raw, ('channel', 'total_count', *classes, 'finite_count', 'word_sha256',
                                                'finite_minimum_word', 'finite_maximum_word', 'nan_payload_status'))
        _processing_facts_text(channel['channel'], name)
        for key in ('total_count', *classes, 'finite_count'): _processing_facts_count(channel[key])
        if (sum(channel[key] for key in classes) != channel['total_count']
                or channel['total_count'] != coverage['pixels_per_channel']
                or channel['finite_count'] != sum(channel[key] for key in classes[:4])):
            _processing_facts_error()
        _processing_facts_hex(channel['word_sha256'], 64)
        for key in ('finite_minimum_word', 'finite_maximum_word'):
            if channel['finite_count'] == 0:
                if channel[key] is not None: _processing_facts_error()
            else: _processing_facts_hex(channel[key], 8)
        _processing_facts_text(channel['nan_payload_status'], 'digest_bound_not_enumerated' if channel['nan'] else 'absent')
    logical = _processing_facts_fields(value['logical_values'], ('status',))
    _processing_facts_text(logical['status'], 'not_computed')
    profile = _processing_facts_fields(value['profile_facts'], ('status', 'provenance', 'facts'))
    _processing_facts_text(profile['status'], 'unknown')
    _processing_facts_text(profile['provenance'], 'reviewed_import_tag_contract_not_supplied')
    if type(profile['facts']) is not dict or profile['facts']: _processing_facts_error()
    profile_coverage = _processing_facts_fields(value['profile_coverage'], ('status', 'reviewed_tag_set', 'import_route_revision'))
    for key, expected in (('status', 'unknown'), ('reviewed_tag_set', 'not_supplied'), ('import_route_revision', 'not_supplied')):
        _processing_facts_text(profile_coverage[key], expected)


def _processing_facts_result(value):
    import json
    fields = ('facts_profile', 'facts_tool_sha256', 'facts_snapshot_sha256', 'source_facts')
    request = value.get('request') if type(value) is dict else None
    summary = value.get('summary') if type(value) is dict else None
    requested = type(request) is dict and 'facts_profile' in request
    present = set(fields) & summary.keys() if type(summary) is dict else set()
    if not requested and not present: return value
    if (not requested or type(summary) is not dict or present != set(fields)
            or request['facts_profile'] != 'stored_f32_full_v1'):
        _processing_facts_error()
    _processing_facts_text(summary['facts_profile'], 'stored_f32_full_v1')
    for key in ('facts_tool_sha256', 'facts_snapshot_sha256'): _processing_facts_hex(summary[key], 64)
    facts = summary['source_facts']
    if type(facts) is not list or not 1 <= len(facts) <= 16: _processing_facts_error()
    for source in facts: _processing_facts_source(source)
    if len({source['source_alias'] for source in facts}) != len(facts): _processing_facts_error()
    try:
        size = len(json.dumps({key: summary[key] for key in fields}, ensure_ascii=False,
                              separators=(',', ':'), allow_nan=False).encode('utf-8'))
    except (ValueError, TypeError, UnicodeError): _processing_facts_error()
    if size > 32768: _processing_facts_error()
    # Shape/correlation only: the fixed original owner already checked this
    # immutable Job and refused private Resource results. source_kind grants
    # nothing; no native facts, logical values or precision verdict is inferred.
    return value


def _processing(host, operation, args):
    import json
    if not isinstance(args, (list, tuple)) or len(args) != len(_PROCESSING_ARGUMENTS[operation]):
        _invalid('Invalid original managed SII argument count')
    values = list(args)
    if operation == 'validate_steps': values[0] = _processing_steps(values[0])
    elif operation == 'processing_prepare': values[0] = _processing_request(values[0])
    elif operation == 'processing_submit': values[0] = _processing_preparation(values[0])
    elif operation in ('processing_status', 'processing_cancel', 'processing_result', 'processing_resource', 'processing_publish'):
        values[0] = _processing_text(values[0], 'owned Job ID')
        if len(values) > 1: values[1] = _processing_text(values[1], 'output token')
        if operation == 'processing_resource': values[2] = _processing_document(values[2])
        if operation == 'processing_publish': values[2] = _processing_publication(values[2])
    values = [_processing_structure(value) for value in values]
    host.call('::GX::modulePublicApiActivate', 'viewer.scientific_image_inspector', 'SCIENTIFIC_IMAGE_INSPECTOR_API_v1')
    raw = host.call('::GX::SII::processingCall', operation, values)
    result = json.loads(str(host.call('::GX::nativeWorkspaceJsonEncode', raw)))
    return _processing_facts_result(result) if operation == 'processing_result' else result


def invoke(host, operation, args):
    if operation in _PROCESSING_ARGUMENTS: return _processing(host, operation, args)
    if operation in _READERS: return _read(host, operation, args)
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown provider metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Provider metadata takes no arguments')
    host.call('::GX::modulePublicApiActivate', 'viewer.scientific_image_inspector', 'SCIENTIFIC_IMAGE_INSPECTOR_API_v1')
    raw = host.call('::GX::SII::'+operation)
    source = host.as_dict(raw)
    return {'api_id': str(source['api_id']), 'manifest_schema': str(source['manifest_schema']),
            'manifest_schemas': [_text(host, item) for item in host.as_list(source['manifest_schemas'])],
            'native_source_profile': _text(host, source['native_source_profile']),
            'manifest_source_profiles': [_text(host, item) for item in host.as_list(source['manifest_source_profiles'])],
            'operations': [str(item) for item in host.as_list(source['operations'])],
            'gui_required': bool(int(source['gui_required']))}
