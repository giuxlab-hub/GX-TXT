# GX-TXT public Image Inspector API and viewer activation (headless on source).
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII {
    variable moduleId viewer.scientific_image_inspector
    variable viewerId scientific_image_inspector
    variable version 0.4.37
    variable root [file normalize [file join [file dirname [info script]] ..]]
}
source [file join $::GX::SII::root runtime catalog.tcl]
source [file join $::GX::SII::root runtime engine.tcl]
source [file join $::GX::SII::root runtime article.tcl]
source [file join $::GX::SII::root runtime annotations_json.tcl]
source [file join $::GX::SII::root runtime manifest.tcl]
source [file join $::GX::SII::root runtime local_sources.tcl]
source [file join $::GX::SII::root runtime presets_v1.tcl]
source [file join $::GX::SII::root runtime lod_plan_v1.tcl]
source [file join $::GX::SII::root runtime managed_processing_v1.tcl]
# Headless application definitions precede actual scientific provider binding.
# Registration runs only inside the original approved public API activation;
# later callers reuse its issued ownership instead of creating lazy authority.
source [file join $::GX::SII::root runtime native2d_canvas_sii_v1.tcl]
source [file join $::GX::SII::root runtime native2d_canvas_sii_preferences_v1.tcl]
source [file join $::GX::SII::root runtime native2d_canvas_sii_roi_v1.tcl]
source [file join $::GX::SII::root runtime native_canvas_extension_v1.tcl]
::GX::SII::_processingRegisterProvider
::GX::SII::CanvasApplication::registerExtension

proc ::GX::SII::dispatch {action scene} {
    variable root
    if {![llength [info commands ::GX::SII::guiOpen]]} {source [file join $root runtime gui.tcl]}
    if {![llength [info commands ::GX::SII::historyStripCreate]]} {source [file join $root runtime history_strip.tcl]}
    if {![llength [info commands ::GX::SII::lodReset]]} {source [file join $root runtime lod.tcl]}
    if {![llength [info commands ::GX::SII::nativeCanvasCreate]]} {source [file join $root runtime native_canvas.tcl]}
    if {![llength [info commands ::GX::SII::buildSimpleTab]]} {source [file join $root runtime article_gui.tcl];source [file join $root runtime annotation_tools.tcl];source [file join $root runtime editor_controls.tcl];source [file join $root runtime roi_context.tcl]}
    return [guiOpen $action $scene]
}
::GX::viewerBackendRegister scientific_image_inspector_tk [list ::GX::SII::dispatch]
