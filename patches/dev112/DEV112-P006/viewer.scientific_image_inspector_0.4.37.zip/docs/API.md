# Scientific Image Inspector — Public API and Manifest Contract

SPDX-License-Identifier: GPL-3.0-or-later

## Registration

Module ID: `viewer.scientific_image_inspector`; Viewer Provider ID: `scientific_image_inspector`; declared public API: `SCIENTIFIC_IMAGE_INSPECTOR_API_v1`. Activate through GX-TXT's normal `modulePublicApiActivate` contract. GUI activation remains lazy. Do **not** source Viewer Tcl files directly in another module.

## Headless public operations

These procs are defined in namespace `::GX::SII` after API activation; they do not require a Tk window. Metadata reads use CORE's public Dataset Metadata API and current Session identity, not a separate plugin registry.

```tcl
::GX::modulePublicApiActivate viewer.scientific_image_inspector SCIENTIFIC_IMAGE_INSPECTOR_API_v1
set info [::GX::SII::apiInfo]
set manifest [::GX::SII::manifestGet my_derived_image]
set summary [::GX::SII::manifestSummary my_derived_image]
set annotations_json [::GX::SII::apiCall annotations_json my_derived_image]
# Alternative dispatch:
set manifest [::GX::SII::apiCall manifest_get my_derived_image]
set summary [::GX::SII::apiCall manifest_summary my_derived_image]
```

Additional supported `apiCall` operations: `inspect dataset_id`, `catalog ?search?`, `capabilities`. `manifestGet` fails explicitly when the source Dataset has no Inspector manifest, schema is unsupported, output ID is mismatched, or a known output SHA differs from CORE's published payload receipt.

`::GX::SII::catalogList ?query?`, `::GX::SII::catalogGet operation_id`, `::GX::SII::validate operation_id parameters_dict`, `::GX::SII::inspect dataset_id`, `::GX::SII::stats canonical_source_path ?roi? ?channel?` (internal path trust boundary applies), and `::GX::SII::histogram` are exposed Tcl procedures. Authorized Dataset entrypoints should be preferred to naked file paths in third-party modules. `::GX::SII::process dataset_id steps_list ?format?` produces a bounded temporary resource which must be released with `::GX::SII::releaseResult`; it does not publish.

`::GX::SII::publish source_id steps output_dataset_id ?format? ?manifest?` and `::GX::SII::figurePublish panels settings annotations output_dataset_id ?format? ?manifest?` go through the existing `::GX::datasetFilePublicationPublish` public service and return its authoritative Dataset publication receipt. Supported Dataset output formats: `png16`, `tiff16`, `tiff32f`. The consumer must not replace a canonical Dataset identity without explicit ownership permission. No Viewer UI command writes directly to a user-selected image file.

## Dataset manifest schema

Namespace in CORE structured metadata:

```text
image.inspector.manifest_schema = scientific_image_inspector.manifest.v1
image.inspector.manifest        = <UTF-8 serialized Tcl dictionary>
```

Manifest required fields:

| Field | Contents |
|---|---|
| `schema` | `scientific_image_inspector.manifest.v1` |
| `producer_module` | `viewer.scientific_image_inspector` |
| `primary_source_id` | Main canonical source Dataset ID |
| `source_sha256_map` | Canonical parent Dataset IDs → 64-character hashes |
| `source_facts` | Per-parent file size, format/MIME, decoded dimensions, channels, depth, color space, orientation, density/resolution and upstream Dataset metadata |
| `operation_steps` | Ordered, validated global operations, typed parameters, step scope and ROI |
| `figure_panels` | Exact per-panel Dataset references, parent SHA and approved processing steps for compositions |
| `figure_settings` | Canvas width/height, margins/gutters, background and layout for compositions |
| `annotations` | Editable annotation dictionaries (stable `id`, type, color, pixel coordinates, text/stroke as relevant) |
| `annotation_layers_json` | JSON projection of the same retained objects with `scientific_image_inspector.annotations.v1`, top-left pixel coordinates and stable IDs |
| `coordinate_system` | Image pixel coordinates with top-left origin, no inferred physical calibration |
| `color_policy` | Processing/color calibration disclosure |
| `image_magick_version` | Actual ImageMagick engine version string at publication |
| `workspace_id` | GX-TXT Session Workspace ID when available, otherwise empty |
| `created_utc` | UTC timestamp |
| `output` | `format`, new `dataset_id`, `expected_sha256`, `raster_properties` (format, dimensions, depth, channels, color space, etc.) |

Manifest text is **data**, never executable Tcl code; retrieve with `dict get` and validate fields using the provided `manifestValidate`. SHA-256 for the committed Dataset is authoritative in CORE publication; manifest's expected output SHA can be checked against the CORE payload. The original parent Dataset always retains its own independent identity and hash. A client should not infer scientific correctness or sample calibration from this recipe. File format conversion, ICC transforms and 8-bit previews remain scientific/provenance considerations.

## Workspace recipe (distinct from Dataset manifest)

Provider ID: `scientific_image_inspector`; workspace schema: `scientific_image_inspector.recipe` version `1.0` (payload marker `scientific_image_inspector.recipe.v2`). This Workspace contains `source_id`, `source_sha`, `steps`, `panels`, `figure_settings`, `annotations`, and optional `image_annotations`, `figure_annotations`, `canvas_mode` and derived `annotation_layers_json`, with `sidebar_sections` for Workspace-specific visible inspector panels and the compatible optional `scientific_history` (general CORE record) / `domain_history` (image and figure CORE records). Legacy `history_timeline` snapshots are imported once; new saves retain complete incremental records. These optional collections preserve independent image/figure overlays; compatibility with earlier experimental alpha payloads is not guaranteed. CORE owns ID, revisions, notes, preview/resources and serialization.

`::GX::sessionWorkspaceViewerMenu` supplies New/Open/Save/Duplicate/Rename/Close/Delete/Manager. Opening a Workspace by exact ID verifies source SHA before restoring state. Pending adjustment previews and Tk photo caches are never authoritative Workspace state. The JSON layer projection is generated from the authoritative `annotations` objects, and cannot be modified independently. `::GX::SII::annotationsJson annotations` serializes trusted validated objects. After publication `apiCall annotations_json dataset_id` reads the validated manifest and returns the overlay projection.

## Security, lifecycle and permissions

Runtime executable comes from `::GX::runtimeToolRequired magick`. No user-entered unrestricted CLI strings or direct shell interpolation are accepted. Images are taken from GX-TXT canonical Dataset sources and managed temporary files. Preview/candidate storage is ephemeral; publication is explicit. The plugin does not write into other Viewers or GX-TXT CORE. `F1` opens a viewer-local manual window and uses CORE markup renderer when present.

## Editable annotation overlay transform extension

Within the `annotations_json` projection, each object may contain `rotation` (clockwise degrees), `pivot_x` and `pivot_y` (working-image pixel coordinates, top-left origin). `pivot_x` and `pivot_y` must occur as a pair when supplied. Omitting them selects a default pivot: text insertion point, or geometric bounds-center. The Workspace Tcl dictionary remains authoritative; JSON is a read-only interoperable projection available through `SCIENTIFIC_IMAGE_INSPECTOR_API_v1` after Dataset publication. The schema ID stays `scientific_image_inspector.annotations.v1`; these optional fields are backward-compatible.

### Named overlay objects

The `annotations_json` result includes a user-editable `name` for each object when available, in addition to the stable `id`, `kind`, coordinates, style, `rotation`, and optional `pivot_x`/`pivot_y`. The JSON schema identifier remains `scientific_image_inspector.annotations.v1` (additive optional field). Workspace payloads from earlier versions without names receive display names on load; their original stable IDs are retained.


### Text annotation properties

Text overlay records additionally support `font_family` (validated ImageMagick font name), `size` (final size in image pixels), `font_unit` (`px` or `pt`), `font_value` (user-entered size), optional `font_dpi` (the output-DPI assumption used for pt conversion), and `box_width`/`box_height` (editable image-pixel bounding box). These are additive fields of `annotations_json` and are retained in the CORE-owned Workspace payload and published Dataset manifest. The stable annotation/manifest API IDs remain unchanged.

P017 GUI recording uses the public CORE `scientificHistoryViewerRecordOperation`, context navigation and shared strip APIs. `saveState` is the internal gesture acceptance hook; `historySaveExplicit` drains journals and commits the canonical Workspace. The public image inspection/manifest APIs are unchanged. History is not evaluated as Tcl code. Workspace validation checks inert owners, cursor/range, retained limits and patch dictionaries without activating Native2D or ImageMagick.


## Shared Script Bridge readers

The module-owned Python/Octave registration retains `apiInfo` and exposes
`manifest_get`, `manifest_summary`, `annotations_json`, `inspect`, `catalog`,
`capabilities` and `apiCall`. `apiCall` accepts only the six original leaf names
and their normal argument forms: one canonical Dataset ID for Dataset readers,
zero or one text query for catalog, no arguments for capabilities. Its typed
projection rejects surplus capabilities arguments, which the raw variadic Tcl
dispatcher ignores. No arbitrary Tcl method, processing/publication operation,
path, program, argv, callback, Resource or GUI/native-view authority is accepted.

`manifest_get` returns `manifest` plus the complete original
`manifest_tcl_utf8`, `output_validation` and an opaque current source receipt.
Nested manifest dictionaries/lists are projected explicitly; scientific numeric,
parameter-default, JSON and unknown metadata lexemes retain original text.
`annotations_json` returns the exact original JSON string without reparsing or
replacement serialization. Summary counts are original integer list lengths.
Manifest provenance describes the retained publication; parent source facts are
not a statement that the parents still exist or are current.

Local payloads are verified through the original canonical SHA owner before and
after a Dataset reader. Only its explicit missing-payload outcome permits a
retained-only manifest/summary/annotation read. The first two report
`missing_retained_only`; annotation JSON is retained definitions, never current
pixel verification. Integrity/SHA/symlink/path/registry failures refuse rather
than downgrade to missing. Registered remote retained-manifest readers preserve
the original authenticated canonical metadata verifier and existing enabled
Execution Configuration node authority. Successful verification is labelled
`authenticated_remote_metadata`, scoped only to the registered remote
Dataset/revision/metadata; `local_payload_verified` remains false. If the
original verifier is unavailable, original retained-reader behavior remains
available with `retained_remote_metadata_unverified` and
`remote_metadata_verified=false`. Neither state claims local output bytes or
current parents. The direct annotation JSON remains exact retained definitions;
use manifest/summary for its explicit output-validation envelope. No caller
node, endpoint, credential, remote Session or revision is accepted. Actual
authenticated remote execution has not been tested in this author batch.
Original remote raster inspection still requires a regular local payload and
does not add a remote preview/download/materialization path.

Inspection returns original canonical/engine/header facts with its internal
payload path omitted. Exact integer dimensions/counts are typed; resolution,
density and interpretation labels retain original lexemes and imply no physical
calibration. A local encoded inspection source is limited to64MiB before full
hash/ping. Retained manifest512KiB UTF-8 checks occur after the original metadata
read, so they are not pre-read allocation bounds. Complete public results are
limited to1MiB UTF-8 without truncation. The original runner's1048576 Tcl-character
cap is per subprocess query, distinct from this byte bound and its8s/12s/30s
per-call timeouts; no whole-operation hard deadline is promised.

Catalog support flags remain declared adapter metadata, with original parameter
lexemes and disabled/recognized entries visible. Capabilities and inspection use
only the original configured ImageMagick runner and fixed version/list/identify
queries. Actual tool absence or refusal remains an error; catalog metadata alone
does not prove tool availability or successful image processing. No GUI/native
view, parser, scientific algorithm, process executor or storage owner is added.

## Retained native Canvas manifest union in Script Bridge readers

The existing reader signatures and API/provider identities are unchanged.
`manifest_get(dataset_id)`, `manifest_summary(dataset_id)` and
`annotations_json(dataset_id)` also read the original validated
`scientific_image_inspector.manifest.v2` with
`source_profile = native_canvas_document_v1`. The earlier manifest/annotation
field tables describe the legacy v1 branch; this native branch records the
actual captured Document rather than manufacturing legacy recipe panels.

`manifest_get` retains its existing envelope and complete `manifest_tcl_utf8`.
The explicit native fields in `manifest` are:

| Field | Public type and meaning |
|---|---|
| `native_canvas` | Dictionary with original `encoding`, `capture_request_base64`, `result_summary_base64`, `output_receipt` and `producing_job` |
| `native_canvas.encoding` | Exact text `base64_utf8_original_Tcl_record` |
| `capture_request_base64`, `result_summary_base64` | Opaque, lossless original UTF-8 Tcl-record base64 text; the adapter never decodes, evaluates or guesses nested types |
| `output_receipt` | Original declared output-receipt dictionary, with private `source_file` omitted by the original manifest owner; other receipt lexemes remain text |
| `producing_job` | Dictionary of original `job_id`, `request_sha256` and `provider_version`; provenance, not caller authority |
| `native_counts` | Five integer fields: `images`, `annotations`, `objects`, `resources`, `canonical_sources` |
| `annotations` | Ordered original dictionaries containing `object`, `encoding` and `definition_base64`; complete editable native definition text stays packed and inert |
| `source_facts`, `source_sha256_map` | Original canonical origin records and hashes; maps may be empty, without borrowing image provenance |

Full original projection/capture provenance, transforms, style, font/glyph
definitions, Resource identities and nonpainting reasons remain in the packed
records and exact manifest text. This projection does not replay the captured
recipe or imply that retained parents remain current. Existing output-validation
states and canonical before/after read guards still apply.

Native `manifest_summary` returns the actual original owner summary:
`operation_count` is zero; `panel_count` counts painted images;
`annotation_count` counts painted annotations; `object_count` counts all captured
objects. These four fields are integers. `source_profile`, `sources`, `output`
and Workspace identity remain original data. This differs from legacy summary
list-length meanings and does not add Resource/canonical counts to the summary.

Native `annotations_json` returns the exact original
`scientific_image_inspector.native_annotations.v1` JSON text. Its fields are
`schema`, `encoding = inert_original_Tcl_record_not_executable`,
`coordinate_system = native_frame`, `projection_sha256`, `objects_tcl_utf8` and
`projection_tcl_utf8`. The adapter does not parse or replace this serializer;
multiline text and Tcl-looking strings remain inert data. Legacy
`scientific_image_inspector.annotations.v1` JSON remains unchanged.

The typed `apiCall` still accepts only its six reader/query leaves. The current
raw owner also contains separately managed processing arms; their presence does
not expand this dispatcher or expose private native publication. Existing typed
`apiInfo` returns all seven original inert metadata fields: `api_id`,
`manifest_schema`, `manifest_schemas`, `native_source_profile`,
`manifest_source_profiles`, complete original `operations`, and `gui_required`.

The existing 512 KiB retained-manifest UTF-8 limit and 1 MiB complete-result
limit remain, without truncation. The manifest limit occurs after the original
metadata read, so it is not a pre-read allocation bound. No arbitrary large or
4000-object manifest-read guarantee follows. Focused author checks cover inert
original-owner metadata and shared conversion only; actual producing Job, GUI
publication, remote behavior and independent controller acceptance are separate.

## Selected current Resource retained-manifest branch

The existing reader signatures also distinguish
`scientific_image_inspector.manifest.v2` with
`source_profile = selected_current_resource_v1`. This discriminator belongs to
retained publication metadata; it is not a new public request or Job profile.
The original v1 and `native_canvas_document_v1` branches remain unchanged.

Selected manifests have `selected_resource`, with exact
`encoding = base64_utf8_original_Tcl_record`, opaque original
`capture_request_base64`, `publication_source_base64` and
`result_summary_base64`, plus declared `output_receipt` and `producing_job`
dictionaries. The adapter does not decode or evaluate packed records, replay
ancestral processing, or infer nested Tcl values. The original owner omits the
private `source_file` from the output receipt. Other receipt and scientific
lexemes remain original text. The complete original `manifest_tcl_utf8` and
existing output-validation envelope are retained.

`selected_counts` has exactly three integer fields: `images`, `resources`,
`canonical_sources`. The first two count the one selected current raster and
its one Resource, while canonical origins retain all proven source identities.
`native_canvas` and `native_counts` are absent. `primary_source_id`,
`operation_steps`, `figure_panels`, `figure_settings` and `annotations` are
empty by the original selected-publication contract. Current realized Resource
pixels are authoritative; no canonical parent substitutes for those pixels,
no whole-Document projection is implied, and ancestral steps are not replayed.
The complete selected item, lineage and original precision/producer records
remain losslessly packed.

Selected `manifest_summary` returns the original owner fields:

| Field | Meaning/type |
|---|---|
| `operation_count`, `panel_count`, `annotation_count` | Integer zero: this Job has empty new steps, no composition panels and no separately rendered annotation layers |
| `image_count`, `resource_count` | Integer one |
| `canonical_source_count` | Original canonical-origin count as an integer |
| `annotation_count_scope` | Exact text `separately_rendered_by_this_publication` |
| `input_pixel_stage` | Original recorded input precision/provenance label |
| `scientific_precision_preserved` | Original text `0` for derived RGBA8 or `not_asserted` for the admitted high-depth SII producer; never a new boolean or precision PASS |

The original schema/profile/source map/output/Workspace fields remain. There
is no selected `object_count` or `source_scope` key. The manifest's declared
coordinate system instead records `scope = selected_current_resource`, and
annotation JSON states its own exact scope. Native Document summary semantics
(painted images, painted annotations, all objects) remain separate.

Selected `annotations_json` returns exact original
`scientific_image_inspector.selected_resource_annotations.v1` JSON text, with
`scope = selected_current_raster_not_whole_document`,
`encoding = inert_original_Tcl_record_not_executable`,
`separate_annotation_layers_rendered = false`, `selected_item_tcl_utf8` and
`lineage_tcl_utf8`. This is retained selected-item metadata, not an empty
native-Document overlay or a claim about other layers. No public JSON
replacement serializer or callback is added.

The current typed `apiInfo` retains the original `manifest_source_profiles`
array along with both manifest schemas and the native source profile text. The typed `apiCall` still admits only its six
literal reader/query leaves. The nine explicit managed methods are unchanged;
private selected/native publication is not exposed by these readers. Original
producer authority, completed-Job/Session/Document/Resource/canonical guards and
transaction semantics remain with their owners.

Original 512 KiB retained-manifest and 1 MiB full-result bounds remain unchanged.
Focused author checks cover only selected retained metadata conversion with
minimal v1/native preservation controls. Actual selected-Resource producing Job,
GUI/publication/transaction/precision and independent acceptance remain separate.
Requested high-depth output never restores precision lost by a prior Native
RGBA8 filter/flatten; actual high-depth producer provenance does not establish a
global numerical-preservation guarantee.


## Managed processing through the existing shared API

The same `SCIENTIFIC_IMAGE_INSPECTOR_API_v1`, version1, module provider
`viewer.scientific_image_inspector` has nine additional explicit operation names.
They call the fixed original `::GX::SII::processingCall operation arguments`
owner after normal module/API activation. They are separate from `apiCall`,
which still accepts only its original six reader/query leaves. `apiInfo`, all
six leaves, their read/retained-validation semantics, and ordinary reader
callability remain unchanged. A retained reader `source_receipt.sha256` is a
READSTAMP, not the canonical source SHA, Resource byte SHA or permission to run.

Python calls `gxtxt_api_call(api_id, operation, arguments_list)`; Octave uses the
same API ID/operation with its ordinary argument cell. The result uses the
existing native Workspace typed decoder: empty objects/arrays, nulls, text,
booleans and exact integers keep their declared distinctions. No generic Tcl
procedure, command line, callback, worker/path, allocator or producer selector is
accepted. The registered computational provider is the existing
`viewer.scientific_image_inspector.processing`, version0.4.3, under CORE
Scientific Execution/Script Job; this is distinct from the module API provider.

| Operation | Exact argument list | Result and effects |
|---|---|---|
| `presets` | none | Array of original15 `{title, description, steps, roi_compatible}` records. Original literal recipes and declared ROI compatibility; listing does not execute them or attest backend availability. |
| `validate_steps` | `steps` | Original normalized step array. Uses original catalog/default/type/availability/ROI validation and may query configured ImageMagick help. No Job or output is created. |
| `processing_prepare` | `request` | Normalized portable preparation DATA with source/provider/runtime fingerprints. May activate/register the original provider, verify source bytes/metadata and configured ImageMagick HDRI/version. No snapshot file, reservation, process-local token, Job or publication is created. |
| `processing_submit` | `preparation` | Revalidates current owner-normalized DATA and all original guards, then calls original ScientificExecution prepare and submit in the SAME Host. Returns `{job_id,state,provider_id}`. Existing capture, quota, guardian and cancellation owners apply. |
| `processing_status` | `job_id` | Allowlisted typed status for the actual SII provider/profile Job in this Session/origin. Historical/stale-source status is observable; a status read does not assert source freshness or scientific eligibility. |
| `processing_cancel` | `job_id` | Original Supervisor cancellation request followed by the same status projection. No restart, result acceptance, Resource adoption or publication is implied. |
| `processing_result` | `job_id` | Only a COMPLETED, source-current SII Job with validated output structure: `{job_id,provider_id,summary,outputs,request}`. Canonical-source result projection explicitly refuses private Resource-source Jobs. |
| `processing_resource` | `job_id, output_token, document_guard` | Full original Document Resource reference with `owner_generation`, exact byte count/SHA and metadata, after guarded complete output streaming. This creates a Resource blob, not a Canvas/History/Workspace commit. |
| `processing_publish` | `job_id, output_token, publication` | Explicit create-only canonical image Dataset publication with original SII manifest and actual output SHA. Returns the original Dataset receipt including a SESSION-RELATIVE canonical `path`; this is storage data, not a caller-supplied path or worker output filename. |

### Request and portable preparation DATA

All records are closed: unknown fields, callbacks, tool maps, source-kind grants,
paths, allocation IDs and caller-selected producers are refused. Scientific
grammar, bounds, defaults and rendering remain in the original SII owner.

`source` is exactly `{dataset_id, source_sha256, source_revision}` for a current
canonical `image.raster` Dataset. Source SHA and revision come from the original
source identity owner; a matching-looking caller digest grants nothing. This
public request does not accept a Document Resource as an alternative source.

A step requires `op` and primitive-valued `params`. Optional `scope` defaults to
`all`; optional `roi` defaults empty. Supplied inactive ROI integer arrays are
retained. Only active `scope=roi` requires exactly four integer
`x,y,width,height` values, original positive area/operation support and processing
containment in the actual per-stage raster coordinates. The original limit is64
steps. No second catalog/recipe validator or arbitrary ImageMagick switch exists.

An image request requires `{kind:"image", source, operation, steps}`. Operations
are `process`, `inspect`, `statistics`, `histogram`, `palette`, `pixel` and
`channel_preview`. `process` alone accepts optional `format`:
`miff` (default), `png16`, `tiff16` or `tiff32f`; the original owner rejects its
analysis fields. Analysis operations accept optional `analysis_target`
`Working` (default), `Source` or `Preview`, and a closed `analysis` record:

| Operation | Analysis fields and original interpretation |
|---|---|
| `inspect` | No analysis fields; original metadata for the selected materialized target. |
| `statistics` | `channel` (default `All`) and ROI; original normalized quantum0..1 metrics, not raw-sample units. |
| `histogram` | `channel` (default `Gray`) and ROI; `All` maps to `Gray`; original256 bins at8bit depth. |
| `palette` | ROI and integer `colors` (default16, original2..128); original8bit palette quantization. |
| `pixel` | Required integer `x,y`, actual target containment; no channel/ROI option, original all-channel text. |
| `channel_preview` | `channel` default `All` (RGB view); original8bit read-only thumbnail, no ROI, accepted image unchanged. |

The original normalizer permits no nonempty analysis ROI outside Working;
per-step processing ROI is a separate contract. Source analysis requires an empty
recipe. Source/Working/Preview text labels in headless requests reconstruct a
declared recipe; they do not confer a mounted Viewer/Canvas or pending-preview
capability. The real mounted controller binds its own current target/resource.
Empty normalized ROI remains valid for Source/Preview portable DATA roundtrips;
the shared guard normalizes the declared empty vector before checking that only
nonempty ROI requires Working. This conveys no mounted-target or ROI capability.

A figure request requires `{kind:"figure", panels, settings, annotations,
format}`. Each of1..12 panels is exactly `{source, steps}`. All six setting keys
are optional and use original defaults: `width=2400`, `height=1600`, `margin=32`,
`gutter=24`, `layout="grid"`, `background="#FFFFFF"`. Original bounds are
120..12000 dimensions,0..1000 margin/gutter, layouts grid/horizontal/vertical,
strict color and cell/area checks, at most80MP. The renderer alone validates them.
Publication formats are `png16`, `tiff16`, `tiff32f`.

Annotations require `kind,x1,y1`; line/arrow/rectangle/ellipse additionally require
`x2,y2`. Original kinds are text/line/arrow/rectangle/ellipse. Optional common
fields: `color,stroke,rotation,pivot_x,pivot_y,name,id`; pivots occur together.
Text-only fields: `text,size,font_family,font_unit,font_value,font_dpi,box_width,
box_height`. Original character semantics, color/font/geometry/default bounds,
zero-length rules and rendering remain authoritative. The binding does not
replace character bounds with UTF8-byte caps or invent an annotation count cap.

Both request kinds may contain optional `facts_profile`, whose only present
value is the text `stored_f32_full_v1`; absent is truly absent. Empty/wrong values,
types or extra tool/path markers refuse. Ordinary SII has no added native-facts
dependency when the field is absent.

Preparation is exactly `{schema,request,provider_id,provider_version,
worker_sha256,adapter_sha256,runtime_files,source_guards,preparation_sha256}`.
The schema is `scientific_image_inspector.processing_preparation.v1`.
`runtime_files` is the complete registered runtime hash map as DATA, not a caller
file selector. `source_guards` contains exactly `session_fingerprint` (original
cold-stable64lowerhex projection), `session_origin` (exact inert original Tcl
dictionary TEXT, not evaluated/reparsed), and `datasets` (ordered1..12 distinct
canonical records `{dataset_id,source_sha256,source_revision,source_stamp}`).
The three dataset digests are original lowercase64hex and distinct meanings.
First-appearance deduplication requires identical complete owner identity;
conflicts refuse. No raw Session directory is exported by this preparation.

`preparation_sha256` is deterministic correlation/integrity only, NOT a signature,
authentication, admission CAS, reservation or authority. Submit redoes actual
Session/origin/source/metadata/provider/runtime/tool/grant checks and compares
normalized current DATA. Process-local ScientificExecution tokens remain wholly
inside that submit Host. No public `processing_discard` or new token store exists.
Submit requires the original execution destination `local`; remote/auto image
admission refuses explicitly instead of silently falling back to local limits.

### Job status, output and guarded materialization

Status has `job_id,provider_id,state` and optional original typed
`created,started,finished,error,cancel,cpu_seconds,peak_rss_bytes,peak_processes,
peak_threads,temporary_bytes,progress` (text map). It returns no command, ENV or
private Job/output root. A cancellation response does not attest that an output
may be adopted. Existing Supervisor drain/cleanup and terminal states apply.

Result output descriptors use only declared
`role,format,live,token,job_id,logical_id,availability,source_generation,size_bytes,
change,content_class,sha256` when present. The summary may contain original
`kind,operation,info,source_byte_provenance,engine,validation,
implicit_dataset_publication,format,display_precision,panel_count,
annotation_count,requested_target_label,target_authority` and operation-specific
`analysis`. Header info retains format/dimensions/pixel count/depth/channel/color/
orientation/frame/resolution/density facts. Statistics retain original
minimum/maximum/mean/stddev/median/rms/skewness/kurtosis/entropy and unique-color
semantics. RMS uses the existing native in-memory square/mean on the same selected
pixels; native properties supply skewness/kurtosis. This is one source read with
unchanged limits and configured tool precision. Missing/nonfinite statistics
refuse instead of producing a partial success report. Histogram, palette, inspect
and pixel retain their original typed shapes. No recorded manifest or descriptor is a scientific correctness verdict.

`document_guard` is exactly `{document_id,generation,revision,sha256}`: actual
existing Document ID, nonempty opaque generation text, positive exact integer
revision and exact SHA. Resource streaming checks Session, source/Job/output
generation, all Document guards, exact full count/SHA and owned child lifecycle
through the original writer. Pages are at most1MiB raw with bounded encoded
transport and one in flight. No16MiB truncated freeze becomes a complete image.
Finalize returns the original Resource reference including `owner_generation`.
This is not an accepted Canvas recipe or History/Workspace transaction; failure
after blob finalization does not imply a cross-owner rollback of an unadopted blob.

`publication` is exactly `{dataset_id,format}` with optional `workspace_id`.
A nonempty provenance `workspace_id` is checked by original
`interactiveDocumentRead`; it is not a caller-selected storage location.
There is no source replacement, caller `producer`, path, callback or
`replace_owned` flag. The immutable nonlive raster role and actual output format
must match; analysis and8bit previews cannot be republished as a high-depth raster.
Original Dataset Authority transaction and provider ownership surround source,
Session and SHA rechecks through commit. The returned `path` is relative to the
canonical Session, e.g. `datasets/publications/files/<id>.<extension>`, produced
by the original safe publication target. Use canonical Dataset APIs/ID; do not
treat receipt text as filesystem permission or a worker source pathname.

### Optional same-Job stored-float32 facts

Only an immutable Job that requested `facts_profile="stored_f32_full_v1"` may
return the complete four-field bundle in `summary`:
`facts_profile,facts_tool_sha256,facts_snapshot_sha256,source_facts`. All four
must appear together; requested facts cannot silently disappear. The original
owner matches the fixed tool and sealed snapshot SHA to the Job, and public facts
aliases to actual canonical captured sources/encoded-byte provenance. It refuses
unrequested facts and private Resource-source results; `source_kind` is data,
never a Resource capability, fake Dataset ID or public source union.

Each source fact is closed: `source_alias,source_kind,source_revision,
encoded_sha256,encoded_size_bytes,coverage,word_basis,word_digest_order,
finite_order,channels,logical_values,profile_facts,profile_coverage` and canonical
`canonical_source_sha256`. Public canonical rows require that canonical SHA;
internal worker Resource facts have separate actual owner identity and do not
grant this public result route. Physical `source_file_stamp` is omitted from the
public projection and remains internal provenance.

Coverage is `{frame,admitted_frame_count,x,y,width,height,pixels_per_channel,
rows_scanned,complete,channels}`: complete full admitted frame/all stored channels,
not caller/display geometry. Each channel is exactly
`{channel,total_count,normal,subnormal,positive_zero,negative_zero,positive_inf,
negative_inf,nan,finite_count,word_sha256,finite_minimum_word,finite_maximum_word,
nan_payload_status}`. Counts are exact nonnegative integers with the original
class/total/finite identities. Both bounds are actual typed null iff no finite
samples; otherwise they are original lowercase8hex word TEXT, never converted
to float. NaN payload status is `absent` or `digest_bound_not_enumerated` as the
actual original counts require.

Original interpretation constants are
`losslessly_decoded_IEEE_binary32_before_float_evaluation_or_color_alpha_photometric_transform`,
`row_major_per_channel_canonical_little_endian_words`, and
`numeric_order_negative_zero_before_positive_zero`. `logical_values` is exactly
`{status:"not_computed"}`. `profile_facts` remains
`{status:"unknown",provenance:"reviewed_import_tag_contract_not_supplied",facts:{}}`;
`profile_coverage` remains `{status:"unknown",reviewed_tag_set:"not_supplied",
import_route_revision:"not_supplied"}`. These do not infer scale1, logical/profile
eligibility, tolerance or a precision PASS.

The existing canonical route still has at most12 distinct Datasets. Internal
facts/materializer16-source and32KiB aggregate limits do not widen it. Original
native facts admission (including current encoded-size/full-frame/dtype/format
limits) remains separate from ordinary SII processing; optional facts do not
exclude otherwise supported SII inputs when absent. The producer bounds complete
raw facts/source/tool/snapshot metadata before ImageMagick; the binding also
bounds compactUTF8 of the four public fields without truncation. Neither bound
is an image-byte limit or waiver of Resource/Job quotas. No extra output role,
store, Job, endpoint, decoder, scientific algorithm or scheduler is introduced.

This API reference describes source contracts, not independent acceptance.
Shared controller API coverage, actual producer/typed-client/Job/GUI/keyboard
qualification and the final coherent119+W cut remain separate. No full raw
Tcl/GUI/C++/scientific parity or hostile-code sandbox is asserted by a binding.

### Current source and evidence qualification for the managed facade

This managed section is composed with the retained v1/native-Document/selected-Resource
reader sections above; their complete existing text is preserved. The current
nine literal public operation signatures and their canonical-only public
publication boundary remain unchanged. The native and selected private
publication entries need their original captured GUI current predicate/receipt;
they are not public callbacks, dispatcher arms or new source capabilities.
Source review includes the integrated private publication transaction/output
checks; four cited CORE import/guard bodies remain identical to a7 despite
surrounding source/line changes. The old source/shape receipts remain
historical; this composition does not replay or promote them to current Job,
GUI, stream-lifecycle or installed-runtime evidence.

Provider runtime registration adds the fixed native placement helper since a7.
Its LOD helper and conditional managed ImageMagick loader/manifest anchors already
existed. Incomplete
installation anchors and already-registered closure mismatch refuse. Provider
hashes/preparation correlation must come from the final actual runtime cut;
no earlier native or precision artifact hash is frozen as current by this text.
The optional stored-float32 source facts describe their original representation
contract, not global precision PASS or ordinary-input exclusion. Actual current
precision producer/assets and independent evidence remain separately qualified.
The 183 public, 209 SDK-signature and one entry-macro authority scopes stay
separate; neither this documentation nor their union establishes coverage.

### Complete original apiInfo metadata

The existing zeroargument typed `apiInfo` now returns all seven original fields: scalar text `api_id`, `manifest_schema`, `native_source_profile`; ordered text arrays `manifest_schemas`, `manifest_source_profiles`, `operations`; and logical `gui_required`. Original metadata and ordering are preserved, with no fabricated API version or actual tool-availability claim. Discovery does not grant Source, GUI, processing, Resource or Publication authority. The original six-leaf `apiCall` and nine explicit managed methods retain their existing guards and contracts.

Design-mode preference restoration retains its validated typed record and only projects declared sidebar visibility. Live Canvas preferences, navigation and source readiness remain subject to the original runtime owner guards. Design mode does not obtain native resources or scientific execution authority.
