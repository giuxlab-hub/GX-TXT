# SPDX-License-Identifier: GPL-3.0-or-later
# Original generic Native/Tk/geometry capture is owned by CORE. The application
# passes the original opaque edit capability unchanged; no engine/row copy.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureDocumentFrame {handle held} {
    return [::GX::native2DCanvasCaptureDocumentFrame $handle $held]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureAnnotation {handle held logical frameLogical} {
    return [::GX::native2DCanvasCaptureAnnotation $handle $held $logical $frameLogical]
}
