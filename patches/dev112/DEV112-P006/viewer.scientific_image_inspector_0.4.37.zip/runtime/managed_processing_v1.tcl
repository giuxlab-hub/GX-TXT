# Script Bridge managed operation contracts: managed_processing_v1.script_bridge_policy.json (documentation only).
# Original SII processing facade over ScientificExecution/Resource/Workspace owners.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII {variable processingImportSerial 0;variable processingImportReplies {}}
proc ::GX::SII::_processingFields {value required {optional {}}} {
    if {[catch {dict size $value}]} {error {SII processing requires an inert dictionary}}
    foreach key $required {if {![dict exists $value $key]} {error "Missing SII processing field '$key'"}}
    foreach key [dict keys $value] {if {$key ni $required && $key ni $optional} {error "Unknown SII processing field '$key'"}}
}
proc ::GX::SII::_processingFactsProfile {request} {
    if {![dict exists $request facts_profile]} {return {}}
    if {[dict get $request facts_profile] ne {stored_f32_full_v1}} {error {Unsupported closed SII facts_profile}}
    return stored_f32_full_v1
}
proc ::GX::SII::_processingSource {source {capturedSources {}}} {
    _processingFields $source {dataset_id source_sha256 source_revision}
    if {$capturedSources eq {}} {set current [::GX::quantitativeRasterSourceIdentity [dict get $source dataset_id]]} else {
        # PRIVATE actual sealed Resource context only. Public prepare never
        # supplies this argument; source spelling/digest alone grants nothing.
        if {![dict exists $capturedSources [dict get $source dataset_id]]} {error {SII source is outside its actual sealed input context}}
        set current [dict get $capturedSources [dict get $source dataset_id]]
    }
    foreach key {dataset_id source_sha256 source_revision} {
        if {[dict get $current $key] ne [dict get $source $key]} {error {SII canonical source changed; explicitly prepare again}}
    }
    return $current
}
proc ::GX::SII::_processingProviderRuntimeFiles {} {
    set base plugins/modules/viewer.scientific_image_inspector/runtime
    set files [list $base/catalog.tcl $base/engine.tcl $base/article.tcl $base/annotations_json.tcl $base/presets_v1.tcl \
        $base/managed_processing_v1.tcl $base/managed_worker_v1.tcl $base/native_figure_placement_bridge_v1.tcl $base/lod_plan_v1.tcl plugins/modules/viewer.scientific_image_inspector/api/workspace_native.tcl \
        $base/native2d_canvas_sii_v1.tcl $base/native2d_canvas_sii_preferences_v1.tcl \
        $base/native2d_canvas_sii_figure_v1.tcl $base/native2d_canvas_sii_projection_v1.tcl $base/native2d_canvas_sii_roi_v1.tcl $base/native_canvas_extension_v1.tcl]
    return [concat $files [dict get [::GX::scientificExecutionImageRuntimeInfo] provider_runtime_files]]

}
proc ::GX::SII::_processingRegisterProvider {} {
    # Initial registration ONLY in the existing approved API activation. CORE
    # authenticates that real context and issues its binding; APP cannot mint it.
    set id viewer.scientific_image_inspector.processing
    set base plugins/modules/viewer.scientific_image_inspector/runtime
    set files [_processingProviderRuntimeFiles]
    ::GX::scientificExecutionRegister $id [dict create module_id viewer.scientific_image_inspector version 0.4.37 \
        module_api_id SCIENTIFIC_IMAGE_INSPECTOR_API_v1 \
        worker $base/scientific_provider.py tools {magick} parameters {} runtime_files $files \
        input_profile image_resource_files_v1 image_source_info ::GX::SII::sourceInfo \
        canvas_source_profile native_canvas_document_v1 \
        canvas_parameters [::GX::SII::CanvasApplication::canvasParameters] \
        image_canvas_recipe ::GX::SII::CanvasApplication::imageCanvasRecipe \
        image_canvas_result ::GX::SII::processingNativePublicationFacts \
        image_publish ::GX::SII::processingImagePublish]
    return $id
}
proc ::GX::SII::_processingProvider {} {
    # Reuse only the entry installed by actual public API activation. Reading
    # the descriptor does not issue a module context or create lazy authority.
    set id viewer.scientific_image_inspector.processing
    set description [::GX::scientificExecutionDescribe $id]
    if {[dict get $description module_id] ne {viewer.scientific_image_inspector} ||
        [dict get $description module_api_id] ne {SCIENTIFIC_IMAGE_INSPECTOR_API_v1} ||
        [dict get $description input_profile] ne {image_resource_files_v1} ||
        [dict get $description runtime_files] ne [_processingProviderRuntimeFiles]} {
        error {SII runtime/source closure changed after provider registration; restart the owning Host}
    }
    return $id
}
proc ::GX::SII::_processingNormalize {request {capturedSources {}}} {
    if {![dict exists $request kind]} {error {Missing SII processing request kind}}
    switch -- [dict get $request kind] {
        image {
            _processingFields $request {kind source operation steps} {format analysis analysis_target facts_profile}
            set factsProfile [_processingFactsProfile $request]
            _processingSource [dict get $request source] $capturedSources
            set operation [dict get $request operation]
            if {$operation ni {process inspect statistics histogram palette pixel channel_preview}} {error {Unknown original SII image operation}}
            set steps [validateSteps [dict get $request steps]]
            set source [dict get $request source]
            set source [dict create dataset_id [dict get $source dataset_id] source_sha256 [dict get $source source_sha256] source_revision [dict get $source source_revision]]
            set result [dict create kind image source $source operation $operation steps $steps]
            if {$factsProfile ne {}} {dict set result facts_profile $factsProfile}
            if {$operation eq {process}} {
                if {[dict exists $request analysis] || [dict exists $request analysis_target]} {error {SII process does not accept analysis fields}}
                set format [get $request format miff]
                if {$format ni {miff png16 tiff16 tiff32f}} {error {Unsupported original image output format}}
                dict set result format $format
            } else {
                if {[dict exists $request format]} {error {Analysis does not accept a publication format}}
                set target [get $request analysis_target Working]
                if {$target ni {Working Source Preview}} {error {Unknown original analysis target}}
                if {$target eq {Source} && [llength $steps]} {error {Source analysis requires the immutable original recipe}}
                set analysis [get $request analysis {}]
                set required {};set allowed {}
                switch -- $operation {
                    statistics {set allowed {channel roi};set channel [get $analysis channel All]}
                    histogram {set allowed {channel roi};set channel [get $analysis channel Gray]}
                    palette {set allowed {colors roi}}
                    pixel {set required {x y};set allowed {x y}}
                    channel_preview {set allowed channel;set channel [get $analysis channel All]}
                }
                _processingFields $analysis $required $allowed
                set clean {}
                if {$operation in {statistics histogram channel_preview}} {
                    if {$channel ni {All Gray R G B A}} {error {Unsupported original analysis channel}}
                    if {$operation eq {histogram} && $channel eq {All}} {set channel Gray}
                    dict set clean channel $channel
                }
                if {$operation in {statistics histogram palette}} {
                    set roi [get $analysis roi {}]
                    if {$roi ne {} && $target ne {Working}} {error {Original SII analysis ROI belongs only to Working}}
                    regionArgs $roi
                    dict set clean roi $roi
                }
                if {$operation eq {palette}} {set colors [get $analysis colors 16];number $colors 2 128 1;dict set clean colors $colors}
                if {$operation eq {pixel}} {foreach key {x y} {set value [dict get $analysis $key];number $value 0 1000000 1;dict set clean $key $value}}
                dict set result analysis_target $target;dict set result analysis $clean
            }
            return $result
        }
        figure {
            _processingFields $request {kind panels settings annotations format} {facts_profile}
            set factsProfile [_processingFactsProfile $request]
            set panels {};set originalPanels {}
            foreach panel [dict get $request panels] {
                _processingFields $panel {source steps}
                set source [dict get $panel source];_processingSource $source $capturedSources
                set steps [validateSteps [dict get $panel steps]]
                set source [dict create dataset_id [dict get $source dataset_id] source_sha256 [dict get $source source_sha256] source_revision [dict get $source source_revision]]
                lappend panels [dict create source $source steps $steps]
                lappend originalPanels [dict create source_id [dict get $source dataset_id] source_sha [dict get $source source_sha256] steps $steps]
            }
            set settings [dict get $request settings]
            _processingFields $settings {} {width height margin gutter layout background}
            set clean {}
            foreach {key low high default} {width 120 12000 2400 height 120 12000 1600 margin 0 1000 32 gutter 0 1000 24} {
                dict set clean $key [figureValidInt [get $settings $key $default] $low $high $key]
            }
            set layout [get $settings layout grid];set background [figureColor [get $settings background #FFFFFF]]
            dict set clean layout $layout;dict set clean background $background
            set w [dict get $clean width];set h [dict get $clean height]
            figurePlan $originalPanels $w $h [dict get $clean margin] [dict get $clean gutter] $layout
            if {wide($w)*wide($h)>80000000} {error {Figure export limited to 80 megapixels}}
            set annotations {};foreach annotation [dict get $request annotations] {lappend annotations [validateAnnotation $annotation $w $h]}
            set format [dict get $request format]
            if {$format ni {png16 tiff16 tiff32f}} {error {Unsupported original public figure output format}}
            set result [dict create kind figure panels $panels settings $clean annotations $annotations format $format]
            if {$factsProfile ne {}} {dict set result facts_profile $factsProfile}
            return $result
        }
        default {error {Unknown SII request kind}}
    }
}
proc ::GX::SII::_processingSources {request} {
    if {[dict get $request kind] eq {image}} {return [list [dict get $request source]]}
    return [lmap panel [dict get $request panels] {dict get $panel source}]
}
proc ::GX::SII::_processingPrepareData {request} {
    set request [_processingNormalize $request]
    set provider [_processingProvider]
    set sources [_processingSources $request]
    if {![llength $sources]} {error {SII processing needs its original finite source set}}
    set identity [::GX::scientificExecutionImagePreparationIdentity $provider $request $sources]
    if {[llength [dict get $identity source_guards datasets]]>12} {error {SII processing needs its original finite source set}}
    set prepared [dict create schema scientific_image_inspector.processing_preparation.v1 request $request provider_id $provider]
    foreach key {provider_version worker_sha256 adapter_sha256 runtime_files source_guards} {dict set prepared $key [dict get $identity $key]}
    # Runtime identity contributes correlation only, never caller authority.
    set tool [magickPath];set version [magickVersion]
    if {[string first HDRI $version]<0} {error {SII precision processing requires the original configured ImageMagick HDRI runtime; select it in Configuration > Runtime}}
    set canonical [_processingCanonicalNode [_processingPreparedNode $prepared]]
    set metadataStamps [dict get $identity metadata_stamps]
    set orderedMetadata {};foreach id [lsort [dict keys $metadataStamps]] {lappend orderedMetadata $id [dict get $metadataStamps $id]}
    set stamp [::GX::nativeWorkspaceMetadataDigest [list gxtxt.sii.processing_preparation.v1 $canonical $orderedMetadata [::GX::sha256File $tool] $version]]
    dict set prepared preparation_sha256 $stamp
    return $prepared
}
proc ::GX::SII::_processingSubmit {prepared {documentGuard {}} {callback {}} {tracked 0}} {
    _processingFields $prepared {schema request provider_id provider_version worker_sha256 adapter_sha256 runtime_files source_guards preparation_sha256}
    if {[dict get $prepared schema] ne {scientific_image_inspector.processing_preparation.v1}} {error {Unknown SII portable preparation}}
    set current [_processingPrepareData [dict get $prepared request]]
    if {[dict get $current preparation_sha256] ne [dict get $prepared preparation_sha256] ||
        [_processingCanonicalNode [_processingPreparedNode [dict remove $current preparation_sha256]]] ne
        [_processingCanonicalNode [_processingPreparedNode [dict remove $prepared preparation_sha256]]]} {error {SII source/runtime/preparation changed; explicitly prepare again}}
    set request [dict get $current request];set sources {};set ids {};set index 0
    foreach source [_processingSources $request] {
        set id [dict get $source dataset_id]
        if {$id in $ids} continue
        lappend ids $id;dict set sources source[incr index] $source
    }
    # Preserve the owner's selected execution policy. This image profile has
    # no admitted target materializer/budget route; do not silently force a
    # remote/auto selection back onto local execution.
    if {[::GX::scientificExecutionDestination] ne {local}} {
        return -code error -errorcode {GXTXT SCIENTIFIC IMAGE_REMOTE_UNAVAILABLE} {Select the local Scientific Execution destination for original SII processing; remote image admission is unavailable}
    }
    # Process-local ScientificExecution preparation never escapes this Host.
    set options [dict create node_id local dataset_sources $ids image_sources $sources image_recipe $request]
    if {$documentGuard ne {}} {
        _processingFields $documentGuard {document_id generation revision sha256}
        ::GX::scientificExecutionPublicationGuard $documentGuard
        dict set options document_id [dict get $documentGuard document_id]
        dict set options expected_revision [dict get $documentGuard revision]
        dict set options expected_generation [dict get $documentGuard generation]
        dict set options expected_sha256 [dict get $documentGuard sha256]
    }
    set token [::GX::scientificExecutionPrepare [dict get $current provider_id] {} {} $options]
    try {
        if {$tracked} {return [::GX::scientificExecutionSubmitTracked $token $callback]}
        return [::GX::scientificExecutionSubmit $token $callback]
    } on error {message options} {
        # Tracked post-ID failures are contained by original CORE. A thrown
        # pre-ID refusal leaves this locally-owned preparation token intact.
        catch {::GX::scientificExecutionDiscard $token}
        return -options $options $message
    }
}
proc ::GX::SII::_processingRequestNode {request} {
    if {![llength [info commands ::GX::SII::workspaceStepEncode]]} {
        source [file join $::GX::SII::root api workspace_native.tcl]
    }
    set source {record {dataset_id text source_sha256 text source_revision text}}
    set steps {array {codec ::GX::SII::workspaceStepEncode}}
    if {[dict get $request kind] eq {image}} {
        set shape [list record [dict create kind text source $source operation text steps $steps format text analysis_target text facts_profile text \
            analysis {record {channel text roi {array int} colors int x int y int}}]]
    } else {
        set shape [list record [dict create kind text facts_profile text panels [list array [list record [dict create source $source steps $steps]]] \
            settings {record {width int height int margin int gutter int layout text background text}} \
            annotations {array {named image_inspector_annotation}} format text]]
    }
    return [::GX::nativeWorkspaceEncode $shape $request]
}
proc ::GX::SII::_processingPreparedNode {prepared} {
    set value $prepared
    dict set value request [_processingRequestNode [dict get $prepared request]]
    return [::GX::nativeWorkspaceEncode {record {schema text request typed provider_id text provider_version text worker_sha256 text \
        adapter_sha256 text runtime_files {map text} source_guards {record {session_fingerprint text session_origin text \
        datasets {array {record {dataset_id text source_sha256 text source_revision text source_stamp text}}}}}}} $value]
}
proc ::GX::SII::_processingCanonicalNode {typed} {
    lassign $typed kind value
    switch -- $kind {
        object - resource {
            set result {}
            foreach key [lsort [dict keys $value]] {dict set result $key [_processingCanonicalNode [dict get $value $key]]}
            return [list $kind $result]
        }
        array {return [list array [lmap item $value {_processingCanonicalNode $item}]]}
        int {return [list int [expr {wide($value)}]]}
        real {return [list real [format %.17g [expr {double($value)}]]]}
        bool {return [list bool [expr {!!$value}]]}
        text - null {return $typed}
        default {error {Unknown original typed SII preparation value}}
    }
}
proc ::GX::SII::_processingCompletedFacts {id} {
    # All callers require completed/current sources. CORE owns those checks;
    # this module receives only inert result/provenance correlation facts.
    set job [::GX::scientificExecutionImageJobFacts $id]
    if {[dict get $job provider_id] ne {viewer.scientific_image_inspector.processing}} {error {Job is not owned by the original SII processing provider}}
    return $job
}
proc ::GX::SII::_processingOwnedStatus {id} {
    set status [::GX::scientificExecutionImageStatus $id]
    if {[dict get $status provider_id] ne {viewer.scientific_image_inspector.processing}} {error {Job is not owned by the original SII processing provider}}
    return $status
}
proc ::GX::SII::_processingStatusNode {id} {
    set raw [_processingOwnedStatus $id];set result {}
    set types {job_id text provider_id text state text created real started real finished real error text cancel bool cpu_seconds real \
        peak_rss_bytes int peak_processes int peak_threads int temporary_bytes int progress {map text}}
    dict for {field shape} $types {if {[dict exists $raw $field] && [dict get $raw $field] ne {}} {dict set result $field [dict get $raw $field]}}
    return [::GX::nativeWorkspaceEncode [list record $types] $result]
}
proc ::GX::SII::_processingFactsNode {rows} {
    if {![llength $rows] || [llength $rows]>16} {error {Invalid bounded SII source facts set}}
    set result {};set aliases {}
    set coverageShape {record {frame int admitted_frame_count int x int y int width int height int pixels_per_channel int rows_scanned int complete bool channels {array text}}}
    set channelShape {record {channel text total_count int normal int subnormal int positive_zero int negative_zero int positive_inf int negative_inf int nan int finite_count int word_sha256 text finite_minimum_word typed finite_maximum_word typed nan_payload_status text}}
    set rowShape [dict create source_alias text source_kind text source_revision text canonical_source_sha256 text encoded_sha256 text encoded_size_bytes int \
        coverage $coverageShape word_basis text word_digest_order text finite_order text channels [list array $channelShape] \
        logical_values {record {status text}} profile_facts {record {status text provenance text facts {record {}}}} \
        profile_coverage {record {status text reviewed_tag_set text import_route_revision text}}]
    foreach row $rows {
        _processingFields $row {source_alias source_kind source_revision encoded_sha256 encoded_size_bytes coverage word_basis word_digest_order finite_order channels logical_values profile_facts profile_coverage} {canonical_source_sha256}
        set alias [dict get $row source_alias];set kind [dict get $row source_kind]
        if {![regexp {^[A-Za-z_][A-Za-z0-9_]{0,63}$} $alias] || $alias in $aliases || $kind ni {canonical_dataset document_resource} || [dict get $row source_revision] eq {}} {error {Invalid original SII facts source association}}
        lappend aliases $alias
        if {($kind eq {canonical_dataset}) != [dict exists $row canonical_source_sha256]} {error {SII facts cannot invent canonical identity for Resource bytes}}
        foreach field {encoded_sha256 canonical_source_sha256} {if {[dict exists $row $field] && ![regexp {^[a-f0-9]{64}$} [dict get $row $field]]} {error {Invalid SII facts digest}}}
        if {![string is entier -strict [dict get $row encoded_size_bytes]] || [dict get $row encoded_size_bytes]<1 || [dict get $row encoded_size_bytes]>67108864} {error {Invalid original facts encoded byte count}}
        set coverage [dict get $row coverage]
        _processingFields $coverage {frame admitted_frame_count x y width height pixels_per_channel rows_scanned complete channels}
        foreach field {frame admitted_frame_count x y width height pixels_per_channel rows_scanned} {if {![string is entier -strict [dict get $coverage $field]]} {error {Invalid facts coverage integer}}}
        set pixels [dict get $coverage pixels_per_channel]
        if {[dict get $coverage frame]!=0 || [dict get $coverage admitted_frame_count]!=1 || [dict get $coverage x]!=0 || [dict get $coverage y]!=0 ||
            [dict get $coverage width]<1 || [dict get $coverage width]>16384 || [dict get $coverage height]<1 || [dict get $coverage height]>16384 ||
            $pixels!=wide([dict get $coverage width])*[dict get $coverage height] || $pixels>16777216 || [dict get $coverage rows_scanned]!=[dict get $coverage height] ||
            [dict get $coverage complete] ni {1 true}} {error {Incomplete original full-source facts}}
        set names [dict get $coverage channels]
        if {$names ni {Gray {R G B} {R G B A}} || [llength [dict get $row channels]]!=[llength $names]} {error {Invalid stored facts channel coverage}}
        set channels {};set index 0
        foreach channel [dict get $row channels] {
            _processingFields $channel {channel total_count normal subnormal positive_zero negative_zero positive_inf negative_inf nan finite_count word_sha256 finite_minimum_word finite_maximum_word nan_payload_status}
            if {[dict get $channel channel] ne [lindex $names $index] || ![regexp {^[a-f0-9]{64}$} [dict get $channel word_sha256]]} {error {Invalid original channel facts}}
            incr index;set total 0;set finite 0
            foreach field {normal subnormal positive_zero negative_zero positive_inf negative_inf nan} {
                set n [dict get $channel $field]
                if {![string is entier -strict $n] || $n<0 || $n>$pixels} {error {Invalid original representation count}}
                incr total $n;if {$field in {normal subnormal positive_zero negative_zero}} {incr finite $n}
            }
            if {$total!=$pixels || [dict get $channel total_count] ne $pixels || [dict get $channel finite_count] ne $finite} {error {Incomplete original representation count identity}}
            foreach field {finite_minimum_word finite_maximum_word} {
                set value [dict get $channel $field]
                if {$finite==0} {
                    if {$value ne {}} {error {Nonfinite channel facts require null bounds}}
                    dict set channel $field [list null {}]
                } else {
                    if {![regexp {^[a-f0-9]{8}$} $value]} {error {Finite facts bounds require original hex words}}
                    dict set channel $field [list text $value]
                }
            }
            set nanStatus [expr {[dict get $channel nan]>0?{digest_bound_not_enumerated}:{absent}}]
            if {[dict get $channel nan_payload_status] ne $nanStatus} {error {Invalid NaN payload facts status}}
            lappend channels $channel
        }
        dict set row channels $channels
        foreach {field expected} {word_basis losslessly_decoded_IEEE_binary32_before_float_evaluation_or_color_alpha_photometric_transform word_digest_order row_major_per_channel_canonical_little_endian_words finite_order numeric_order_negative_zero_before_positive_zero} {
            if {[dict get $row $field] ne $expected} {error {Unknown original facts interpretation}}
        }
        _processingFields [dict get $row logical_values] {status}
        _processingFields [dict get $row profile_facts] {status provenance facts}
        _processingFields [dict get $row profile_coverage] {status reviewed_tag_set import_route_revision}
        if {[dict get $row logical_values status] ne {not_computed} || [dict get $row profile_facts status] ne {unknown} ||
            [dict get $row profile_facts provenance] ne {reviewed_import_tag_contract_not_supplied} || [dict size [dict get $row profile_facts facts]] ||
            [dict get $row profile_coverage status] ne {unknown} || [dict get $row profile_coverage reviewed_tag_set] ne {not_supplied} || [dict get $row profile_coverage import_route_revision] ne {not_supplied}} {error {Source facts cannot fabricate profile coverage}}
        lappend result [::GX::nativeWorkspaceEncode [list record $rowShape] $row]
    }
    return [list array $result]
}
proc ::GX::SII::_processingSummaryNode {summary} {
    set info {record {format text width int height int pixel_count int depth int channels text colorspace text type text orientation text frames int resolution_x text resolution_y text density_units text im_bytes text}}
    set shape [dict create kind text operation text info $info source_byte_provenance {map {record {sha256 text size_bytes int canonical_source_sha256 text source_revision text}}} \
        engine text validation text implicit_dataset_publication bool format text display_precision text panel_count int annotation_count int \
        requested_target_label text target_authority text]
    set factsFields {facts_profile facts_tool_sha256 facts_snapshot_sha256 source_facts}
    set present 0;foreach field $factsFields {if {[dict exists $summary $field]} {incr present}}
    if {$present} {
        if {$present!=4 || [dict get $summary facts_profile] ne {stored_f32_full_v1}} {error {Incomplete or unknown original source facts summary}}
        foreach field {facts_tool_sha256 facts_snapshot_sha256} {if {![regexp {^[a-f0-9]{64}$} [dict get $summary $field]]} {error {Invalid source facts summary identity}}}
        dict set summary source_facts [_processingFactsNode [dict get $summary source_facts]]
        foreach field {facts_profile facts_tool_sha256 facts_snapshot_sha256} {dict set shape $field text}
        dict set shape source_facts typed
    }
    if {[dict exists $summary analysis]} {
        switch -- [dict get $summary operation] {
            histogram {dict set shape analysis {record {channel text bins {array int} bin_depth int roi {array int}}}}
            palette {dict set shape analysis {array {record {count int color text}}}}
            statistics {dict set shape analysis {record {minimum scientific_real maximum scientific_real mean scientific_real stddev scientific_real \
                median scientific_real rms scientific_real skewness scientific_real kurtosis scientific_real entropy scientific_real unique_colors int}}}
            inspect {dict set shape analysis {map text}}
            pixel {dict set shape analysis text}
            default {error {Unexpected original SII analysis result}}
        }
    }
    return [::GX::nativeWorkspaceEncode [list record $shape] $summary]
}
proc ::GX::SII::_processingResultNode {id} {
    set job [_processingCompletedFacts $id]
    if {[dict size [dict get $job validation_context image_resource_sources]]} {error {This canonical-only result projection does not reinterpret private GUI Resource sources as Dataset identities; inspect the actual Canvas Resource receipt}}
    if {[dict get $job state] ne {COMPLETED}} {error {Only a COMPLETED original SII Job has an eligible result}}
    set result [::GX::scientificExecutionImageOutputs $id]
    if {[dict get $result validation] ne {validated_structure}} {error {Original SII provider did not validate output structure}}
    set requestedFacts [_processingFactsProfile [dict get $job validation_context image_recipe]]
    set summary [dict get $result summary]
    if {$requestedFacts ne {}} {
        foreach field {facts_profile facts_tool_sha256 facts_snapshot_sha256 source_facts} {if {![dict exists $summary $field]} {error {Requested SII source facts result is incomplete}}}
        if {[dict get $summary facts_profile] ne $requestedFacts ||
            [dict get $summary facts_tool_sha256] ne [dict get $job validation_context image_facts_tool binary_sha256] ||
            [dict get $summary facts_snapshot_sha256] ne [dict get $job validation_context image_input_snapshot sha256]} {error {SII source facts differs from its immutable Job identity}}
        set expectedSources [dict get $job validation_context image_capture_options image_sources]
        if {[llength [dict get $summary source_facts]]!=[dict size $expectedSources]} {error {SII source facts alias coverage differs from its immutable Job}}
        foreach row [dict get $summary source_facts] {
            set alias [dict get $row source_alias]
            if {![dict exists $expectedSources $alias] || [dict get $row source_kind] ne {canonical_dataset}} {error {SII public facts source alias is not canonical authority}}
            set expected [dict get $expectedSources $alias];dict unset expectedSources $alias
            set bytes [dict get $summary source_byte_provenance [dict get $expected dataset_id]]
            if {[dict get $row canonical_source_sha256] ne [dict get $expected source_sha256] || [dict get $row source_revision] ne [dict get $expected source_revision] ||
                [dict get $row encoded_sha256] ne [dict get $bytes sha256] || [dict get $row encoded_size_bytes] ne [dict get $bytes size_bytes]} {error {SII source facts association differs from its actual captured source}}
        }
    } else {
        foreach field {facts_profile facts_tool_sha256 facts_snapshot_sha256 source_facts} {if {[dict exists $summary $field]} {error {Unrequested SII source facts result}}}
    }
    set fields [dict create job_id [list text $id] provider_id [list text [dict get $result provider_id]] \
        summary [_processingSummaryNode [dict get $result summary]]]
    set outputs {}
    foreach row [dict get $result outputs] {
        set output {};set allowed {role text format text live bool token text job_id text logical_id text availability text source_generation int size_bytes int change text content_class text sha256 text}
        dict for {field shape} $allowed {if {[dict exists $row $field]} {dict set output $field [dict get $row $field]}}
        lappend outputs [::GX::nativeWorkspaceEncode [list record $allowed] $output]
    }
    dict set fields outputs [list array $outputs]
    dict set fields request [_processingRequestNode [dict get $job validation_context image_recipe]]
    return [list object $fields]
}
proc ::GX::SII::processingCall {operation arguments} {
    switch -- $operation {
        presets {
            if {[llength $arguments]} {error {presets takes no arguments}}
            set rows {}
            foreach entry [basicPresetCatalog] {
                lassign $entry title description rawSteps
                set steps {};set roi 1
                foreach raw $rawSteps {
                    lassign $raw op params
                    lappend steps [dict create op $op params $params scope all roi {}]
                    if {![dict get [catalogGet $op] roi]} {set roi 0}
                }
                set row [dict create title $title description $description steps $steps roi_compatible $roi]
                # The original schema is data; listing presets does not run tools.
                if {![llength [info commands ::GX::SII::workspaceStepEncode]]} {source [file join $::GX::SII::root api workspace_native.tcl]}
                lappend rows [::GX::nativeWorkspaceEncode {record {title text description text steps {array {codec ::GX::SII::workspaceStepEncode}} roi_compatible bool}} $row]
            }
            return [list array $rows]
        }
        validate_steps {
            if {[llength $arguments]!=1} {error {validate_steps takes steps}}
            set steps [validateSteps [lindex $arguments 0]]
            set request [dict create kind image source {dataset_id {} source_sha256 {} source_revision {}} operation process steps $steps format miff]
            return [dict get [lindex [_processingRequestNode $request] 1] steps]
        }
        processing_prepare {
            if {[llength $arguments]!=1} {error {processing_prepare takes one typed request}}
            set prepared [_processingPrepareData [lindex $arguments 0]]
            set fields [lindex [_processingPreparedNode [dict remove $prepared preparation_sha256]] 1]
            dict set fields preparation_sha256 [list text [dict get $prepared preparation_sha256]]
            return [list object $fields]
        }
        processing_submit {
            if {[llength $arguments]!=1} {error {processing_submit takes one portable data preparation}}
            return [::GX::nativeWorkspaceEncode {record {job_id text state text provider_id text}} [_processingSubmit [lindex $arguments 0]]]
        }
        processing_status {
            if {[llength $arguments]!=1} {error {processing_status takes one Job ID}}
            return [_processingStatusNode [lindex $arguments 0]]
        }
        processing_cancel {
            if {[llength $arguments]!=1} {error {processing_cancel takes one Job ID}}
            set id [lindex $arguments 0];_processingOwnedStatus $id
            ::GX::scientificExecutionCancel $id
            return [_processingStatusNode $id]
        }
        processing_result {
            if {[llength $arguments]!=1} {error {processing_result takes one Job ID}}
            return [_processingResultNode [lindex $arguments 0]]
        }
        processing_resource {
            if {[llength $arguments]!=3} {error {processing_resource takes Job ID, output token and complete Document guard}}
            lassign $arguments id token guard
            set job [_processingCompletedFacts $id]
            if {[dict get $job state] ne {COMPLETED}} {error {Only a COMPLETED SII Job may materialize a result Resource}}
            return [_processingResource $id $token $guard]
        }
        processing_publish {
            if {[llength $arguments]!=3} {error {processing_publish takes Job ID, output token and publication request}}
            lassign $arguments id token request
            set job [_processingCompletedFacts $id]
            if {[dict get $job state] ne {COMPLETED}} {error {Only a COMPLETED SII Job may publish}}
            return [_processingPublish $id $token $request]
        }
        default {error {Unknown finite SII processing operation}}
    }
}

proc ::GX::SII::_processingOutput {id token} {
    set result [::GX::scientificExecutionImageOutputs $id]
    set found {}
    foreach output [dict get $result outputs] {if {[dict get $output token] eq $token} {if {$found ne {}} {error {Duplicate original SII output identity}};set found $output}}
    if {$found eq {}} {error {Unknown immutable SII output token}}
    return [list $found $result]
}
proc ::GX::SII::processingResourceImported {key response} {
    variable processingImportReplies
    if {[dict exists $processingImportReplies $key]} {dict set processingImportReplies $key $response}
}
proc ::GX::SII::_processingResource {id token guard} {
    variable processingImportSerial;variable processingImportReplies
    _processingFields $guard {document_id generation revision sha256}
    lassign [_processingOutput $id $token] output result
    set key import-[incr processingImportSerial]
    dict set processingImportReplies $key {}
    try {
        ::GX::scientificExecutionImageImport $id $output $guard [list ::GX::SII::processingResourceImported $key]
        while {[dict get $processingImportReplies $key] eq {}} {vwait ::GX::SII::processingImportReplies}
        set response [dict get $processingImportReplies $key]
        if {![dict get $response ok]} {error [dict get $response error]}
        return [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} [dict get $response result]]
    } finally {dict unset processingImportReplies $key}
}
proc ::GX::SII::_processingNativePublish {id outputToken publication currentPredicate} {
    if {[llength $currentPredicate]!=2 || [lindex $currentPredicate 0] ne {::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationCurrent}} {error {Native publication requires the original module-owned current predicate}}
    set job [_processingCompletedFacts $id]
    if {[get [dict get $job validation_context] image_source_profile {}] ne {native_canvas_document_v1}} {error {Private native publication requires its captured Canvas Job}}
    return [_processingPublish $id $outputToken $publication $currentPredicate]
}
proc ::GX::SII::_processingPublicationCurrent {predicate} {
    if {$predicate eq {}} return
    if {[llength $predicate]!=2 || [lindex $predicate 0] ne {::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationCurrent}} {error {Unknown private publication predicate}}
    # Literal module owner, never an operation/command from a public DTO.
    ::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationCurrent [lindex $predicate 1]
}
proc ::GX::SII::_processingResourcePublish {id outputToken publication currentPredicate} {
    set row [_processingPublicationCurrent $currentPredicate]
    if {$currentPredicate eq {} || ![dict exists $row sii_resource_publication]} {error {Selected Resource publication requires its private captured owner receipt}}
    set capture [dict get $row sii_resource_publication]
    if {[dict get $capture job_id] ne $id} {error {Selected Resource publication belongs to another Job}}
    return [_processingPublish $id $outputToken $publication $currentPredicate $capture]
}
proc ::GX::SII::_processingPublicationBoundCurrent {predicate resourceCapture} {
    set row [_processingPublicationCurrent $predicate]
    if {$resourceCapture ne {} && (![dict exists $row sii_resource_publication] || [dict get $row sii_resource_publication] ne $resourceCapture)} {error {Selected Resource publication captured owner receipt changed}}
}
proc ::GX::SII::_processingResourceReference {reference} {
    _processingFields $reference {api_id document_id owner_generation sha256 size_bytes metadata}
    if {[dict get $reference api_id] ne {INTERACTIVE_DOCUMENT_RESOURCE_API_v1} || [dict get $reference document_id] eq {} ||
        [dict get $reference owner_generation] eq {} || ![regexp {^[a-f0-9]{64}$} [dict get $reference sha256]] ||
        ![string is entier -strict [dict get $reference size_bytes]] || [dict get $reference size_bytes]<1 || [catch {dict size [dict get $reference metadata]}]} {error {Invalid selected current Resource reference}}
}
proc ::GX::SII::_processingResourcePublicationFacts {request summary output capture} {
    # Pure association checks; only the literal module predicate supplies
    # this captured receipt to the actual publication path.
    _processingFields $capture {schema job_id input_alias resource lineage selected_item precision}
    if {[dict get $capture schema] ne {scientific_image_inspector.selected_resource_publication.v1} || [dict get $capture input_alias] ne {source1}} {error {Unknown selected Resource publication receipt}}
    if {[dict get $request image_profile] ne {image_resource_files_v1} || [get $request image_source_profile {}] ne {} ||
        [lsort [dict keys [dict get $request image_resource_sources]]] ne {source1} || [dict size [dict get $request image_capture_options image_sources]]} {error {Selected Resource publication requires the original single Resource image profile}}
    set ref [dict get $capture resource];_processingResourceReference $ref
    set declared [dict get $request image_resource_sources source1];_processingResourceReference $declared
    foreach key {api_id document_id owner_generation sha256 size_bytes metadata} {if {[dict get $declared $key] ne [dict get $ref $key]} {error {Selected Resource differs from the actual Job input}}}
    set geometry [dict get $capture selected_item resource];_processingResourceReference $geometry
    foreach key {document_id owner_generation} {if {[dict get $geometry $key] ne [dict get $ref $key]} {error {Selected geometry belongs to another Document incarnation}}}
    set itemRef [dict get $geometry metadata image_resource];_processingResourceReference $itemRef
    foreach key {api_id document_id owner_generation sha256 size_bytes metadata} {if {[dict get $itemRef $key] ne [dict get $ref $key]} {error {Selected item does not name its actual current Resource}}}
    set workspace [dict get $request source_identities workspace]
    if {[dict get $workspace id] ne [dict get $ref document_id] || [dict get $workspace generation] ne [dict get $ref owner_generation]} {error {Selected Resource belongs to another Document incarnation}}
    set identity [dict get $request source_identities source1]
    foreach key {api_id document_id owner_generation sha256 size_bytes} {if {[dict get $identity $key] ne [dict get $ref $key]} {error {Selected Resource immutable source guard changed}}}
    set recipe [dict get $request image_recipe];_processingFields $recipe {kind source operation steps format}
    set source [dict get $recipe source];_processingFields $source {dataset_id source_sha256 source_revision}
    set sourceId resource:[dict get $ref sha256]
    if {[dict get $recipe kind] ne {image} || [dict get $recipe operation] ne {process} || [llength [dict get $recipe steps]] ||
        [dict get $source dataset_id] ne $sourceId || [dict get $source source_sha256] ne [dict get $ref sha256] ||
        [dict get $source source_revision] ne [dict get $ref owner_generation] || [dict get $recipe format] ni {png16 tiff16 tiff32f}} {error {Selected Resource publication must encode current pixels without a Raw seed or recipe replay}}
    set lineage [dict get $capture lineage];_processingFields $lineage {sources steps}
    set origins {}
    foreach origin [dict get $lineage sources] {
        _processingFields $origin {dataset_id source_sha256 source_revision}
        set id [dict get $origin dataset_id]
        if {$id eq {} || [string match resource:* $id] || [string match local:* $id] || [dict exists $origins $id] ||
            ![regexp {^[a-f0-9]{64}$} [dict get $origin source_sha256]] || [dict get $origin source_revision] eq {}} {error {Selected Resource needs its genuine unique canonical roots}}
        dict set origins $id $origin
    }
    if {![dict size $origins] || [lsort [dict keys [get [dict get $request source_identities] datasets {}]]] ne [lsort [dict keys $origins]] ||
        [lsort -unique [dict get $request image_capture_options dataset_sources]] ne [lsort [dict keys $origins]]} {error {Selected Resource must retain ALL verified canonical roots}}
    set snapshot [dict get $request image_input_snapshot sha256]
    if {![regexp {^[a-f0-9]{64}$} $snapshot]} {error {Selected Resource lacks its immutable input snapshot}}
    if {[dict get $summary kind] ne {image} || [dict get $summary operation] ne {process} || [dict get $summary validation] ne {validated_structure} ||
        [dict get $summary implicit_dataset_publication] ni {0 false} || [dict get $summary format] ne [dict get $recipe format] ||
        [dict get $output role] ne {raster} || [dict get $output format] ne [dict get $recipe format] || [dict get $output live] ni {0 false} ||
        [dict get $output job_id] ne [dict get $capture job_id]} {error {Selected Resource publication requires its actual completed immutable raster result}}
    if {[dict keys [dict get $summary source_byte_provenance]] ne [list $sourceId]} {error {Selected Resource summary has another source association}}
    set bytes [dict get $summary source_byte_provenance $sourceId]
    foreach {key expected} [list sha256 [dict get $ref sha256] size_bytes [dict get $ref size_bytes] source_revision [dict get $ref owner_generation]] {
        if {[dict get $bytes $key] ne $expected} {error {Selected Resource captured byte identity changed}}
    }
    if {[dict exists $bytes canonical_source_sha256]} {error {Current Resource pixels cannot masquerade as canonical Raw bytes}}
    foreach key {facts_profile facts_tool_sha256 facts_snapshot_sha256 source_facts native_canvas} {if {[dict exists $summary $key]} {error {Selected Resource result contains an unrequested projection}}}
    if {![regexp {^[a-f0-9]{64}$} [dict get $output sha256]] || ![regexp {^output-[a-f0-9]{64}$} [dict get $output token]] ||
        ![string is entier -strict [dict get $output source_generation]] || [dict get $output source_generation]<1 ||
        ![string is entier -strict [dict get $output size_bytes]] || [dict get $output size_bytes]<1} {error {Selected Resource output identity is invalid}}
    foreach key {width height depth} {if {![string is entier -strict [dict get $summary info $key]] || [dict get $summary info $key]<1} {error {Selected Resource output raster facts are invalid}}}
    set precision [dict get $capture precision]
    _processingFields $precision {schema pixel_stage provider_id producing_job_id resource_sha256 resource_generation output_receipt owner_summary}
    if {[dict get $precision schema] ne {scientific_image_inspector.current_resource_precision.v1} || [dict get $precision producing_job_id] eq {} ||
        [dict get $precision producing_job_id] eq [dict get $capture job_id] || [dict get $precision resource_sha256] ne [dict get $ref sha256] ||
        [dict get $precision resource_generation] ne [dict get $ref owner_generation] || [dict get $precision producing_job_id] ne [dict get $ref metadata source_job_id]} {error {Selected Resource original precision provenance changed}}
    set parent [dict get $precision output_receipt];_processingFields $parent {role format token source_generation sha256 size_bytes live}
    if {[dict get $parent role] ne {raster} || [dict get $parent live] ni {0 false} || [dict get $parent sha256] ne [dict get $ref sha256] ||
        [dict get $parent size_bytes] ne [dict get $ref size_bytes] || [dict get $parent token] ne [dict get $ref metadata source_output_token] ||
        [dict get $parent source_generation] ne [dict get $ref metadata source_generation] || ![string is entier -strict [dict get $parent source_generation]] ||
        [dict get $parent source_generation]<1 || ![regexp {^output-[a-f0-9]{64}$} [dict get $parent token]] ||
        [dict get $parent format] ne [dict get $ref metadata format]} {error {Selected Resource differs from its actual parent raster receipt}}
    set owner [dict get $precision owner_summary]
    if {[dict get $owner validation] ne {validated_structure}} {error {Selected Resource producing owner did not validate structure}}
    switch -- [dict get $precision pixel_stage] {
        derived_rgba8_sRGB {
            if {[dict get $precision provider_id] ne {core.native2d.raster} || [dict get $parent format] ne {png} ||
                [dict get $owner scientific_precision_preserved] ni {0 false} || [dict get $owner rgba] ni {1 true} ||
                [dict get $owner output_sha256] ne [dict get $ref sha256]} {error {Native RGBA8 derivative precision must remain explicit}}
            set sourceInfo $owner
        }
        completed_sii_image_raster - completed_sii_figure_raster {
            set kind [expr {[dict get $precision pixel_stage] eq {completed_sii_image_raster}?{image}:{figure}}]
            if {[dict get $precision provider_id] ne {viewer.scientific_image_inspector.processing} || [dict get $owner kind] ne $kind ||
                [dict get $owner format] ne [dict get $parent format] || [dict get $parent format] ni {miff png16 tiff16 tiff32f}} {error {SII current raster precision must retain its actual producer/container}}
            foreach key {width height depth} {if {![string is entier -strict [dict get $owner info $key]] || [dict get $owner info $key]<1} {error {SII original raster facts are invalid}}}
            set sourceInfo [dict get $owner info]
        }
        default {error {Unknown original current Resource pixel stage}}
    }
    foreach key {width height} {if {[dict get $summary info $key] ne [dict get $sourceInfo $key]} {error {Selected current pixels changed extent during identity encoding}}}
    return [dict create origins $origins counts [dict create images 1 resources 1 canonical_sources [dict size $origins]]]
}
proc ::GX::SII::_processingResourcePublicationCurrent {request capture} {
    set workspace [dict get $request source_identities workspace]
    ::GX::scientificExecutionPublicationGuard [dict create document_id [dict get $workspace id] generation [dict get $workspace generation] revision [dict get $workspace revision] sha256 [dict get $workspace sha256]]
    ::GX::interactiveDocumentResourceInfo [dict get $capture resource]
    ::GX::interactiveDocumentResourceInfo [dict get $capture selected_item resource]
    foreach origin [dict get $capture lineage sources] {_processingSource $origin}
}
proc ::GX::SII::_processingPublicationValidate {id publication output result currentPredicate resourceCapture} {
    _processingFields $publication {dataset_id format} {workspace_id}
    set format [dict get $publication format]
    if {$format ni {png16 tiff16 tiff32f}} {error {SII publication requires an original high-depth publication format}}
    ::GX::datasetPublicationV2ValidateId dataset [dict get $publication dataset_id]
    if {[dict exists $publication workspace_id] && [dict get $publication workspace_id] ne {}} {::GX::interactiveDocumentRead [dict get $publication workspace_id]}
    set job [_processingCompletedFacts $id]
    set native [expr {[get [dict get $job validation_context] image_source_profile {}] eq {native_canvas_document_v1}}]
    set selected [expr {$resourceCapture ne {}}]
    if {$selected && ($native || $currentPredicate eq {})} {error {Selected Resource publication requires its distinct private captured owner}}
    if {$native && $currentPredicate eq {}} {error {Native publication requires its original private Canvas current predicate}}
    if {!$native && !$selected && $currentPredicate ne {}} {error {Private Canvas predicate cannot authorize a legacy publication}}
    if {!$native && !$selected && [dict size [dict get $job validation_context image_resource_sources]]} {error {Publish source images as canonical Datasets before creating a derived image}}
    if {[dict get $job state] ne {COMPLETED}} {error {SII publication requires its COMPLETED Job}}
    _processingPublicationBoundCurrent $currentPredicate $resourceCapture
    if {[dict get $output role] ne {raster} || [dict get $output format] ne $format || [dict get $output live]} {error {SII publication format must match its immutable raster output}}
    if {$native} {_processingNativePublicationFacts [dict get $job validation_context] [dict get $result summary] $output}
    if {$selected} {_processingResourcePublicationFacts [dict get $job validation_context] [dict get $result summary] $output $resourceCapture}
    return $job
}
proc ::GX::SII::_processingPublish {id token publication {currentPredicate {}} {resourceCapture {}}} {
    _processingPublicationBoundCurrent $currentPredicate $resourceCapture
    lassign [_processingOutput $id $token] output result
    _processingPublicationValidate $id $publication $output $result $currentPredicate $resourceCapture
    set receipt [::GX::scientificExecutionImagePublish $id $token $publication \
        [dict create current_predicate $currentPredicate resource_capture $resourceCapture]]
    return [::GX::nativeWorkspaceEncode {record {dataset_id text contract text format text storage_kind text media_type text path text sha256 text}} $receipt]
}
proc ::GX::SII::processingImagePublish {id publication output result applicationContext} {
    _processingFields $applicationContext {current_predicate resource_capture}
    set facts [_processingCompletedFacts $id]
    return [_processingPublishCommit $id $publication $output $result [::GX::interactiveDocumentSessionToken] \
        [dict get $facts request_sha256] [dict get $applicationContext current_predicate] [dict get $applicationContext resource_capture]]
}
proc ::GX::SII::processingNativePublicationFacts {request summary output} {
    # Literal public provider callback; scientific validation stays unchanged.
    tailcall ::GX::SII::_processingNativePublicationFacts $request $summary $output
}
proc ::GX::SII::_processingNativePublicationFacts {request summary output} {
    # Pure validation of captured data, never a Job issuer or a rendering path.
    foreach key {image_source_profile image_native_projection image_native_projection_sha256 image_native_canonical_sources image_resource_sources image_input_snapshot image_recipe source_identities} {
        if {![dict exists $request $key]} {error "Incomplete native SII publication capture: $key"}
    }
    if {[dict get $request image_source_profile] ne {native_canvas_document_v1}} {error {Unknown native SII publication profile}}
    set p [dict get $request image_native_projection];set recipe [dict get $request image_recipe]
    if {[dict get $recipe kind] ne {figure} || [llength [dict get $recipe panels]] || [llength [dict get $recipe annotations]] ||
        [dict get $recipe settings] ne [dict get $p settings]} {error {Native publication cannot reinterpret a legacy figure recipe}}
    set digest [::GX::nativeWorkspaceMetadataDigest [binary encode base64 -maxlen 0 [encoding convertto utf-8 $p]]]
    if {$digest ne [dict get $request image_native_projection_sha256]} {error {Native publication projection digest changed}}
    set snapshot [dict get $request image_input_snapshot sha256]
    if {![regexp {^[a-f0-9]{64}$} $snapshot]} {error {Native publication lacks its immutable input snapshot}}
    if {[dict get $summary kind] ne {figure} || [dict get $summary operation] ne {figure} ||
        [dict get $summary validation] ne {validated_structure} || [dict get $summary implicit_dataset_publication] ni {0 false} ||
        [dict get $summary format] ne [dict get $recipe format] || [dict get $output format] ne [dict get $recipe format] ||
        [dict get $output role] ne {raster} || [dict get $output live] ni {0 false}} {error {Native publication requires its validated immutable figure raster}}
    set native [dict get $summary native_canvas]
    foreach {key value} [list projection_schema [dict get $p schema] projection_sha256 $digest canvas_id [dict get $p canvas_id] sequence [dict get $p sequence] source_snapshot_sha256 [dict get $p snapshot_sha256]] {
        if {[dict get $native $key] ne $value} {error "Native publication summary association changed: $key"}
    }
    set guard [dict get $p document_guard]
    foreach key {document_id generation revision sha256} {
        set sourceKey [expr {$key eq {document_id}?{id}:$key}]
        if {[dict get $native document_guard $key] ne [dict get $guard $key] ||
            [dict get $request source_identities workspace $sourceKey] ne [dict get $guard $key]} {error {Native publication Document association changed}}
    }
    if {![llength [info commands ::GX::SII::NativeFigurePlacementV1::validate]]} {
        source [file join $::GX::SII::root runtime native_figure_placement_bridge_v1.tcl]
    }
    set resources [dict get $request image_resource_sources];set origins [dict get $request image_native_canonical_sources]
    set requestedFacts [_processingFactsProfile $recipe]
    set factsFields {facts_profile facts_tool_sha256 facts_snapshot_sha256 source_facts}
    if {$requestedFacts ne {}} {
        foreach key $factsFields {if {![dict exists $summary $key]} {error {Native publication requested source facts are incomplete}}}
        if {[dict get $summary facts_profile] ne $requestedFacts || [dict get $summary facts_snapshot_sha256] ne $snapshot ||
            [dict get $summary facts_tool_sha256] ne [dict get $request image_facts_tool binary_sha256]} {error {Native publication source facts Job identity changed}}
        _processingFactsNode [dict get $summary source_facts]
        set factsAliases {}
        foreach row [dict get $summary source_facts] {
            set alias [dict get $row source_alias]
            if {![dict exists $resources $alias] || $alias in $factsAliases || [dict get $row source_kind] ne {document_resource}} {error {Native publication facts alias is not its actual Resource}}
            lappend factsAliases $alias;set ref [dict get $resources $alias]
            if {[dict get $row source_revision] ne [dict get $ref owner_generation] || [dict get $row encoded_sha256] ne [dict get $ref sha256] ||
                [dict get $row encoded_size_bytes] ne [dict get $ref size_bytes]} {error {Native publication source facts byte association changed}}
        }
        if {[lsort $factsAliases] ne [lsort [dict keys $resources]]} {error {Native publication source facts coverage changed}}
    } else {
        foreach key $factsFields {if {[dict exists $summary $key]} {error {Unrequested native publication source facts}}}
    }
    set capture [dict create projection $p resources $resources canonical_sources $origins]
    set plan [::GX::SII::NativeFigurePlacementV1::validate $capture \
        [dict create resources [dict get $native actual_resource_refs] canonical_sources [dict get $native canonical_sources]] [dict create format [dict get $output format]]]
    if {[dict size [dict get $plan unfinished]]} {error {An unfinished native projection cannot acquire publication authority}}
    if {[lsort [dict keys [dict get $summary source_byte_provenance]]] ne [lsort [dict keys $resources]]} {error {Native publication input alias coverage changed}}
    dict for {alias ref} $resources {
        if {[dict get $ref document_id] ne [dict get $guard document_id] || [dict get $ref owner_generation] ne [dict get $guard generation]} {error {Native publication Resource belongs to another Document incarnation}}
        set identity [dict get $request source_identities $alias]
        foreach key {api_id document_id owner_generation sha256 size_bytes} {
            if {[dict get $identity $key] ne [dict get $ref $key]} {error {Native publication Resource guard changed}}
        }
        set bytes [dict get $summary source_byte_provenance $alias]
        foreach {field expected} [list sha256 [dict get $ref sha256] size_bytes [dict get $ref size_bytes] source_revision [dict get $ref owner_generation]] {
            if {[dict get $bytes $field] ne $expected} {error {Native publication captured byte association changed}}
        }
    }
    set expectedDatasets [get [dict get $request source_identities] datasets {}]
    if {[lsort [dict keys $expectedDatasets]] ne [lsort [dict keys $origins]]} {error {Native publication canonical lineage coverage changed}}
    set images 0;set annotations {};set lineage {}
    foreach object [dict get $p objects] {
        switch -- [dict get $object disposition] {
            paint_image {incr images;dict set lineage [dict get $object object] [dict get $object canonical_source_ids]}
            paint_annotation {lappend annotations $object}
        }
    }
    if {[lsort [dict keys $lineage]] ne [lsort [dict keys [dict get $native image_lineage]]]} {error {Native publication per-image lineage coverage changed}}
    dict for {object ids} $lineage {if {$ids ne [dict get $native image_lineage $object]} {error {Native publication per-image lineage changed}}}
    set counts [dict create images $images annotations [llength $annotations] objects [llength [dict get $p objects]] resources [dict size $resources] canonical_sources [dict size $origins]]
    if {[dict get $summary panel_count] ne $images || [dict get $summary annotation_count] ne [llength $annotations] ||
        [dict get $native object_count] ne [dict get $counts objects]} {error {Native publication counts differ from the actual captured projection}}
    foreach key {width height} {if {[dict get $summary info $key] ne [dict get $p settings $key]} {error {Native publication raster extent differs from its frame}}}
    foreach key {token sha256 source_generation size_bytes job_id} {if {![dict exists $output $key]} {error {Native publication output identity is incomplete}}}
    if {![regexp {^[a-f0-9]{64}$} [dict get $output sha256]] || ![regexp {^output-[a-f0-9]{64}$} [dict get $output token]] ||
        ![string is entier -strict [dict get $output source_generation]] || [dict get $output source_generation]<1 ||
        ![string is entier -strict [dict get $output size_bytes]] || [dict get $output size_bytes]<1} {error {Native publication output identity is invalid}}
    return [dict create counts $counts annotations $annotations]
}
proc ::GX::SII::_processingNativePublicationCurrent {request} {
    ::GX::scientificExecutionPublicationGuard [dict get $request image_native_projection document_guard]
    dict for {alias ref} [dict get $request image_resource_sources] {::GX::interactiveDocumentResourceInfo $ref}
    dict for {id origin} [dict get $request image_native_canonical_sources] {_processingSource $origin}
}
proc ::GX::SII::_processingPublicationOutputMatches {expectedOutput expectedResult output result} {
    # 'change' is an observation label (initial/unchanged), not byte identity.
    foreach key {role format live token job_id logical_id availability source_generation size_bytes content_class sha256 source_file} {
        if {[dict get $expectedOutput $key] ne [dict get $output $key]} {error {SII publication immutable output changed}}
    }
    foreach key {provider_id validation summary} {
        if {[dict get $expectedResult $key] ne [dict get $result $key]} {error {SII publication immutable result changed}}
    }
    if {[dict get $result validation] ne {validated_structure}} {error {SII publication result is not structurally validated}}
}
proc ::GX::SII::_processingPublishCommit {id publication output result sessionToken originalRequest currentPredicate resourceCapture} {
    if {$sessionToken ne [::GX::interactiveDocumentSessionToken]} {error {SII publication Session changed}}
    if {![::GX::datasetAuthorityActive [::GX::sessionInspectionCurrentSession]]} {error {SII publication commit requires the original Dataset Authority transaction}}
    _processingPublicationBoundCurrent $currentPredicate $resourceCapture
    set job [_processingPublicationValidate $id $publication $output $result $currentPredicate $resourceCapture]
    if {[dict get $job state] ne {COMPLETED}} {error {Only the completed original SII Job can publish}}
    if {[dict get $job request_sha256] ne $originalRequest} {error {SII publication original Job request changed}}
    lassign [_processingOutput $id [dict get $output token]] currentOutput currentResult
    _processingPublicationBoundCurrent $currentPredicate $resourceCapture
    _processingPublicationOutputMatches $output $result $currentOutput $currentResult
    set recipe [dict get $job validation_context image_recipe]
    set native [expr {[get [dict get $job validation_context] image_source_profile {}] eq {native_canvas_document_v1}}]
    set selected [expr {$resourceCapture ne {}}]
    if {$selected && ($native || $currentPredicate eq {})} {error {Selected Resource publication commit requires its distinct private owner}}
    set panels {};set steps {};set settings {};set annotations {}
    if {$native} {
        if {$currentPredicate eq {}} {error {Native publication commit requires its private Canvas predicate}}
        set captureRequest [dict get $job validation_context]
        _processingNativePublicationFacts $captureRequest [dict get $result summary] $output
        _processingNativePublicationCurrent $captureRequest
        set workspaceId [dict get $captureRequest image_native_projection document_guard document_id]
        if {[get $publication workspace_id $workspaceId] ne $workspaceId} {error {Native publication Workspace differs from its captured Document}}
        set manifest [makeNativeManifest $captureRequest [dict get $result summary] $output $id \
            $originalRequest [dict get $job provider_version]]
        set sources [dict values [dict get $captureRequest image_native_canonical_sources]]
    } elseif {$selected} {
        set captureRequest [dict get $job validation_context]
        set facts [_processingResourcePublicationFacts $captureRequest [dict get $result summary] $output $resourceCapture]
        _processingResourcePublicationCurrent $captureRequest $resourceCapture
        set workspaceId [dict get $captureRequest source_identities workspace id]
        if {[get $publication workspace_id $workspaceId] ne $workspaceId} {error {Selected Resource publication Workspace differs from its captured Document}}
        set manifest [makeResourceManifest $captureRequest [dict get $result summary] $output $resourceCapture \
            $originalRequest [dict get $job provider_version]]
        set sources [dict values [dict get $facts origins]]
    } else {
      if {[dict size [dict get $job validation_context image_resource_sources]]} {error {Publish source images as canonical Datasets before creating a derived image}}
      set sources [_processingSources $recipe];set sourceId [dict get [lindex $sources 0] dataset_id]
      if {[dict get $recipe kind] eq {figure}} {
        foreach panel [dict get $recipe panels] {
            set source [dict get $panel source]
            lappend panels [dict create source_id [dict get $source dataset_id] source_sha [dict get $source source_sha256] steps [dict get $panel steps]]
        }
        set settings [dict get $recipe settings];set annotations [dict get $recipe annotations]
      } else {
        if {[dict get $recipe operation] ne {process}} {error {Analysis/8-bit projections are not high-depth publication rasters}}
        set steps [dict get $recipe steps]
      }
      set manifest [makeManifest $sourceId $steps $panels $settings $annotations [dict get $publication format] [get $publication workspace_id {}]]
    }
    set format [dict get $publication format];set outputId [dict get $publication dataset_id]
    # Original manifest owner; actual producing runtime and pixel properties
    # come from the completed source-bound worker, not a later re-render.
    dict set manifest image_magick_version [dict get $result summary engine]
    dict set manifest output dataset_id $outputId
    dict set manifest output expected_sha256 [dict get $output sha256]
    dict set manifest output raster_properties [dict get $result summary info]
    manifestValidate $manifest
    set sourceIds {};foreach source $sources {set sourceId [dict get $source dataset_id];if {$sourceId ni $sourceIds} {lappend sourceIds $sourceId}}
    set metadata [dict create image.inspector.manifest $manifest image.inspector.manifest_schema [dict get $manifest schema] \
        image.inspector.engine [dict get $result summary engine] image.inspector.format $format \
        image.inspector.job_id $id image.inspector.output_token [dict get $output token] image.inspector.source_generation [dict get $output source_generation] \
        image.inspector.operations $steps image.inspector.color_policy {ImageMagick color-space operations only; source ICC not reinterpreted} \
        image.inspector.roi_coordinates {per-step current raster coordinates; top-left origin}]
    if {$native} {
        dict set metadata image.inspector.source_profile native_canvas_document_v1
        dict set metadata image.inspector.native_counts [dict get $manifest native_counts]
        dict set metadata image.inspector.roi_coordinates {native frame; exact editable geometry/transforms retained in manifest.v2}
    }
    if {$selected} {
        dict set metadata image.inspector.source_profile selected_current_resource_v1
        dict set metadata image.inspector.selected_counts [dict get $manifest selected_counts]
        dict set metadata image.inspector.roi_coordinates {selected current raster; no whole-Document or Raw reconstruction}
        dict set metadata image.inspector.input_pixel_stage [dict get $resourceCapture precision pixel_stage]
        dict set metadata image.inspector.scientific_precision_preserved not_asserted
        if {[dict get $resourceCapture precision pixel_stage] eq {derived_rgba8_sRGB}} {dict set metadata image.inspector.scientific_precision_preserved 0}
    }
    set request [dict create dataset_id $outputId contract image.raster format [expr {$format eq {png16}?{png}:{tiff}}] \
        storage_kind binary media_type [expr {$format eq {png16}?{image/png}:{image/tiff}}] source_file [dict get $output source_file] \
        verified_source_sha256 [dict get $output sha256] source_dataset_ids $sourceIds producer_version [dict get $job provider_version] \
        source {Scientific Image Inspector managed high-depth raster} provenance "Original SII processing Job $id; immutable output [dict get $output token]" structured_metadata $metadata]
    _processingCompletedFacts $id
    _processingPublicationBoundCurrent $currentPredicate $resourceCapture
    set receipt [::GX::datasetFilePublicationPublish [::GX::sessionInspectionCurrentSession] viewer.scientific_image_inspector $request]
    # These checks are INSIDE the original Dataset Authority transaction, so a
    # failed source/Session/CAS guard rolls publication back before commit.
    if {$sessionToken ne [::GX::interactiveDocumentSessionToken]} {error {SII publication Session changed}}
    set current [_processingCompletedFacts $id]
    if {[dict get $current state] ne {COMPLETED}} {error {SII publication Job state changed}}
    if {[dict get $current request_sha256] ne $originalRequest} {error {SII publication original Job request changed}}
    if {$native} {_processingNativePublicationCurrent [dict get $current validation_context]}
    if {$selected} {_processingResourcePublicationCurrent [dict get $current validation_context] $resourceCapture}
    if {[dict get $receipt sha256] ne [dict get $output sha256]} {error {SII publication byte identity changed}}
    if {$native || $selected} {
        lassign [_processingOutput $id [dict get $output token]] currentOutput currentResult
        _processingPublicationBoundCurrent $currentPredicate $resourceCapture
        _processingPublicationOutputMatches $output $result $currentOutput $currentResult
        if {$sessionToken ne [::GX::interactiveDocumentSessionToken]} {error {SII publication Session changed}}
        set current [_processingCompletedFacts $id]
        if {[dict get $current state] ne {COMPLETED} || [dict get $current request_sha256] ne $originalRequest} {error {SII publication producing Job changed}}
        if {$native} {_processingNativePublicationCurrent [dict get $current validation_context]}
        if {$selected} {_processingResourcePublicationCurrent [dict get $current validation_context] $resourceCapture}
    }
    # Still inside the original rollback-capable Dataset Authority transaction.
    _processingPublicationBoundCurrent $currentPredicate $resourceCapture
    return $receipt
}
