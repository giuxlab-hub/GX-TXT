"""Registered adapter into the original SII Tcl engine; no second image kernel."""
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib
import json
import tkinter
import re
import tempfile

from gxtxt_scientific_execution import tdict, tvalue

_FACTS_PROFILE = 'stored_f32_full_v1'
_FACTS_MAX_BYTES = 32768
_FACTS_CLASSES = ('normal', 'subnormal', 'positive_zero', 'negative_zero',
                  'positive_inf', 'negative_inf', 'nan')
_FACTS_STRINGS = dict(
    word_basis='losslessly_decoded_IEEE_binary32_before_float_evaluation_or_color_alpha_photometric_transform',
    word_digest_order='row_major_per_channel_canonical_little_endian_words',
    finite_order='numeric_order_negative_zero_before_positive_zero')

def _facts_fields(value, fields):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise ValueError('Invalid closed original source facts record')

def _facts_integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError('Invalid original source facts integer')
    return value

def _facts_unique(pairs):
    value = {}
    for key, item in pairs:
        if key in value: raise ValueError('Duplicate original source facts field')
        value[key] = item
    return value

def _facts_nonfinite(value):
    raise ValueError('Nonfinite JSON control value in original source facts')

def _validate_source_facts(result, record):
    _facts_fields(result, ('schema','metadata','roi','buffers','timings_ms','facts_profile','source_facts'))
    if (result['schema'] != 'gxtxt.quantitative_raster.extract.v1' or
            result['facts_profile'] != _FACTS_PROFILE or result['buffers'] != []):
        raise ValueError('Unsupported original source facts profile or sample output')
    metadata = result['metadata']; facts = result['source_facts']
    if not isinstance(metadata, dict) or any(metadata.get(k) != v for k,v in
            dict(format='TIFF',dtype='float32',sample_depth=32,frame=0,frame_count=1).items()):
        raise ValueError('Source facts does not describe its admitted original TIFF32f')
    _facts_fields(facts, ('source_binding','coverage','word_basis','word_digest_order','finite_order',
                         'channels','logical_values','profile_facts','profile_coverage'))
    binding = facts['source_binding']
    _facts_fields(binding, ('encoded_sha256','encoded_size_bytes','scope','stability','source_file_stamp'))
    if (binding['encoded_sha256'] != record['sha256'] or
            type(binding['encoded_size_bytes']) is not int or binding['encoded_size_bytes'] != record['size_bytes'] or
            binding['scope'] != 'decoder_input_only_managed_owner_identity_bound_by_provider' or
            binding['stability'] != 'descriptor_and_path_same_before_after_full_sha'):
        raise ValueError('Source facts is not bound to the actual sealed input bytes')
    stamp = binding['source_file_stamp']
    _facts_fields(stamp, ('device','inode','mode','links','mtime_seconds','mtime_nanoseconds','ctime_seconds','ctime_nanoseconds'))
    if any(type(v) is not int for v in stamp.values()) or stamp['links'] != 1 or stamp['mode'] & 0o170000 != 0o100000:
        raise ValueError('Invalid original source facts physical stamp')
    coverage = facts['coverage']
    _facts_fields(coverage, ('frame','admitted_frame_count','x','y','width','height','pixels_per_channel','rows_scanned','complete','channels'))
    width = _facts_integer(coverage['width'],1,16384);height = _facts_integer(coverage['height'],1,16384)
    pixels = _facts_integer(coverage['pixels_per_channel'],1,16777216)
    names = coverage['channels']
    if (type(coverage['complete']) is not bool or not coverage['complete'] or pixels != width*height or
            any(type(coverage[k]) is not int for k in ('frame','admitted_frame_count','x','y','rows_scanned')) or
            [coverage[k] for k in ('frame','admitted_frame_count','x','y','rows_scanned')] != [0,1,0,0,height] or
            names not in (['Gray'],['R','G','B'],['R','G','B','A']) or metadata.get('channels') != names or
            metadata.get('width') != width or metadata.get('height') != height or
            result['roi'] != dict(x=0,y=0,width=width,height=height)):
        raise ValueError('Incomplete original full-source/channel facts coverage')
    if any(facts[k] != v for k,v in _FACTS_STRINGS.items()):
        raise ValueError('Unknown original source facts word interpretation')
    channels = facts['channels']
    if not isinstance(channels,list) or len(channels) != len(names):
        raise ValueError('Incomplete original source facts channel set')
    for name, channel in zip(names,channels):
        _facts_fields(channel, ('channel','total_count',*_FACTS_CLASSES,'finite_count','word_sha256',
                               'finite_minimum_word','finite_maximum_word','nan_payload_status'))
        if channel['channel'] != name or not isinstance(channel['word_sha256'],str) or not re.fullmatch('[a-f0-9]{64}',channel['word_sha256']):
            raise ValueError('Invalid original channel facts identity')
        counts = [_facts_integer(channel[k],0,pixels) for k in _FACTS_CLASSES]
        if (sum(counts) != pixels or _facts_integer(channel['total_count'],0,pixels) != pixels or
                _facts_integer(channel['finite_count'],0,pixels) != sum(counts[:4])):
            raise ValueError('Original representation class coverage differs')
        bounds = [channel['finite_minimum_word'],channel['finite_maximum_word']]
        if not channel['finite_count']:
            if bounds != [None,None]:raise ValueError('Nonfinite channel requires null word bounds')
        else:
            if any(not isinstance(v,str) or not re.fullmatch('[a-f0-9]{8}',v) for v in bounds):
                raise ValueError('Finite channel requires original hex word bounds')
            words = [int(v,16) for v in bounds]
            if any((v & 0x7f800000)==0x7f800000 for v in words):raise ValueError('Nonfinite word in finite bounds')
            ordered = [(~v & 0xffffffff) if v & 0x80000000 else (v ^ 0x80000000) for v in words]
            if ordered[0] > ordered[1]:raise ValueError('Original finite word order differs')
        if channel['nan_payload_status'] != ('digest_bound_not_enumerated' if counts[6] else 'absent'):
            raise ValueError('Original NaN payload status differs')
    if (facts['logical_values'] != dict(status='not_computed') or
            facts['profile_facts'] != dict(status='unknown',provenance='reviewed_import_tag_contract_not_supplied',facts={}) or
            facts['profile_coverage'] != dict(status='unknown',reviewed_tag_set='not_supplied',import_route_revision='not_supplied')):
        raise ValueError('Source facts cannot invent logical/profile qualification')
    return facts

def _source_facts_stage(context):
    recipe = tdict(context.request['image_recipe'])
    profile = recipe.get('facts_profile')
    if profile is None:
        if 'image_facts_tool' in context.request:raise ValueError('Unrequested original source facts binding')
        return None
    if profile != _FACTS_PROFILE:raise ValueError('Unsupported closed original SII facts profile')
    binding = tdict(context.request.get('image_facts_tool',''))
    _facts_fields(binding, ('profile','tool_name','tool_path','version','binary_relative','binary_sha256','runtime_files'))
    relative = 'core/quantitative_raster_native/gxtxt_quantitative_extract'
    provenance = 'core/quantitative_raster_native/BUILD_PROVENANCE.json'
    fixed = Path(__file__).resolve().parents[4] / relative
    if (binding['profile'] != profile or binding['tool_name'] != 'quantitative_raster_native' or
            binding['binary_relative'] != relative or binding['tool_path'] != str(fixed) or
            context.tools.get('quantitative_raster_native') != str(fixed) or fixed.is_symlink() or
            not binding['version'].startswith('gxtxt_quantitative_extract 1.1.0;')):
        raise ValueError('Source facts lacks its original fixed native1.1.0 owner')
    pins = tdict(binding['runtime_files'])
    if (set(pins) != {relative,provenance} or pins[relative] != binding['binary_sha256'] or
            any(context.request['runtime_files'].get(k) != v for k,v in pins.items()) or
            hashlib.sha256(fixed.read_bytes()).hexdigest() != binding['binary_sha256']):
        raise ValueError('Source facts native/runtime identity changed')
    if (not 1 <= len(context.input_records) <= 16 or
            set(context.input_files) != set(context.input_records)):
        raise ValueError('Invalid bounded original source facts input set')
    snapshot = tdict(context.request['image_input_snapshot'])
    public=[];native=[]
    summary=dict(facts_profile=profile,facts_tool_sha256=binding['binary_sha256'],facts_snapshot_sha256=snapshot['sha256'],source_facts=public)
    for alias,record in sorted(context.input_records.items()):
        if not re.fullmatch('[A-Za-z_][A-Za-z0-9_]{0,63}',alias):raise ValueError('Invalid sealed source facts alias')
        guard=tdict(record['source_guard']);kind=guard.get('kind')
        if kind=='canonical_dataset':
            identity=tdict(guard['identity']);revision=identity['source_revision']
        elif kind=='document_resource':
            identity=tdict(guard['reference']);revision=identity['owner_generation']
        else:raise ValueError('Source facts alias lacks an original owner association')
        output=Path(tempfile.mkdtemp(prefix='sii-source-facts-',dir=context.scratch))
        # The original native header alone derives full geometry. No describe,
        # ImageMagick decode or duplicate source SHA pass is introduced here.
        response=context.run('quantitative_raster_native',[str(context.input_files[alias]),record['sha256'],str(output),'source_facts','0','0','1','1','all','0'])
        wire=response['stdout'].encode('utf-8')
        if response.get('truncated') or len(wire)>_FACTS_MAX_BYTES:raise ValueError('Original source facts metadata exceeds32KiB')
        result=json.loads(wire,object_pairs_hook=_facts_unique,parse_constant=_facts_nonfinite)
        facts=_validate_source_facts(result,record)
        row=dict(source_alias=alias,source_kind=kind,source_revision=revision,
                 encoded_sha256=facts['source_binding']['encoded_sha256'],encoded_size_bytes=facts['source_binding']['encoded_size_bytes'])
        if kind=='canonical_dataset':row['canonical_source_sha256']=identity['source_sha256']
        for key in ('coverage','word_basis','word_digest_order','finite_order','channels','logical_values','profile_facts','profile_coverage'):row[key]=facts[key]
        public.append(row);native.append(dict(source_alias=alias,result=result))
        aggregate=dict(**summary,source_facts_native=native)
        if len(json.dumps(aggregate,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8'))>_FACTS_MAX_BYTES:
            raise ValueError('Aggregate original source facts exceeds32KiB')
    return summary,native


def run(context):
    if context.request.get('image_profile') != 'image_resource_files_v1':
        raise ValueError('SII requires its original sealed image profile')
    from scientific_image_materializer_v1 import native_source_binding
    native_profile, projection_sha = native_source_binding(context.request)
    source_metadata = tdict(context.request.get('image_source_metadata', ''))
    sources = {}
    identities = {}
    byte_sources = {}
    for alias, item in context.input_records.items():
        guard = tdict(item['source_guard'])
        if native_profile and guard.get('kind') != 'document_resource':
            raise ValueError('Scientific Canvas paint inputs must be current Document Resources')
        if guard.get('kind') == 'canonical_dataset':
            identity = tdict(guard['identity'])
            info = tdict(guard['source_info'])
            source_id = identity['dataset_id']
            if info.get('id') != source_id:
                raise ValueError('SII canonical source identity differs')
            if alias not in source_metadata:
                raise ValueError('Missing original captured source metadata')
            info['metadata'] = source_metadata[alias]
        elif guard.get('kind') == 'document_resource':
            if set(guard) != {'kind', 'reference', 'document'}:
                raise ValueError('SII Resource source guard fields differ')
            reference = tdict(guard['reference']); document = tdict(guard['document'])
            declared = tdict(tdict(context.request['image_resource_sources'])[alias])
            if ({k: v for k, v in declared.items() if k != 'metadata'} != reference or
                    tdict(tdict(context.request['source_identities'])[alias]) != reference or
                    tdict(tdict(context.request['source_identities'])['workspace']) != document or
                    reference['document_id'] != document['id'] or not reference.get('owner_generation') or
                    reference['owner_generation'] != document['generation'] or
                    reference['sha256'] != item['sha256'] or int(reference['size_bytes']) != item['size_bytes']):
                raise ValueError('SII Resource source is outside its actual immutable Document capture')
            source_id = 'resource:' + reference['sha256']
            identity = dict(dataset_id=source_id, source_sha256=reference['sha256'],
                            source_revision=reference['owner_generation'])
            info = dict(id=source_id, sha256=reference['sha256'], contract='image.raster', metadata='',
                        format='', media_type='image/raster', size_bytes=item['size_bytes'], local_file=1)
        else:
            raise ValueError('SII input lacks its verified original source association')
        info['path'] = str(context.input_files[alias])
        info['source_revision'] = identity['source_revision']
        # Private actual-source context, never a request or source-info grant.
        # Overwrite any canonical source_info field with the sealed guard kind.
        info['_sii_source_guard_kind'] = guard['kind']
        if 'source_stamp' in identity:
            info['source_stamp'] = identity['source_stamp']
        if native_profile:
            # Native paint consumes alias-bound sealed files directly. Two
            # aliases may legitimately name the SAME immutable Resource; their
            # different snapshot filenames do not create conflicting sources.
            byte_sources[alias] = dict(sha256=item['sha256'], size_bytes=item['size_bytes'],
                                       source_revision=identity['source_revision'])
            continue
        if source_id in sources and sources[source_id] != info:
            raise ValueError('Conflicting SII source associations')
        sources[source_id] = info
        identities[source_id] = identity
        byte_sources[source_id] = dict(sha256=item['sha256'], size_bytes=item['size_bytes'],
                                      source_revision=identity['source_revision'])
        if guard['kind'] == 'canonical_dataset':
            byte_sources[source_id]['canonical_source_sha256'] = identity['source_sha256']
    facts_stage = _source_facts_stage(context)
    t = tkinter.Tcl()
    t.call('namespace', 'eval', '::GX', '')
    def tool(name):
        if name != 'magick' or name not in context.tools:
            raise ValueError('Unregistered SII runtime tool')
        return context.tools[name]
    def captured(source_id):
        if source_id not in sources:
            raise ValueError('Unknown sealed SII source')
        return tvalue(sources[source_id])
    def captured_identity(source_id):
        if source_id not in identities:
            raise ValueError('Unknown captured canonical identity')
        return tvalue(identities[source_id])
    t.createcommand('::GX::_quantitativeRasterSourceIdentity', captured_identity)
    t.createcommand('::GX::runtimeToolRequired', tool)
    t.createcommand('::GX::configurationTempDirectory', lambda: str(context.scratch))
    t.createcommand('::GX::__siiCapturedSource', captured)
    # Trusted fixed helpers alone use this original sealed-byte digest owner.
    t.createcommand('::GX::sha256File', lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest())
    root = Path(__file__).resolve().parent
    for name in ('catalog.tcl', 'engine.tcl', 'article.tcl', 'annotations_json.tcl', 'managed_processing_v1.tcl', 'managed_worker_v1.tcl'):
        t.call('source', str(root / name))
    try:
        if native_profile:
            t.call('source', str(root / 'native_figure_placement_bridge_v1.tcl'))
            references = tdict(context.request['image_resource_sources'])
            if set(references) != set(context.input_records):
                raise ValueError('Scientific Canvas Resource alias set differs from its sealed inputs')
            origins = tdict(context.request['image_native_canonical_sources'])
            capture = dict(projection=context.request['image_native_projection'],
                           resources=references, canonical_sources=origins)
            facts = dict(resources=references, canonical_sources=origins)
            plan = t.call('::GX::SII::NativeFigurePlacementV1::validate', tvalue(capture),
                          tvalue(facts), tvalue(dict(format=tdict(context.request['image_recipe'])['format'])))
            raw = t.call('::GX::SII::NativeFigurePlacementV1::render', plan,
                         tvalue({alias: str(path) for alias, path in context.input_files.items()}),
                         tvalue(dict(directory=str(context.output))))
        else:
            raw = t.call('::GX::SII::managedWorker', context.request['image_recipe'], str(context.output), tvalue(identities))
        result = tdict(str(t.call('format', '%s', raw)))
        info = tdict(result['info'])
        for field in ('width', 'height', 'pixel_count', 'depth', 'frames'):
            info[field] = int(info[field])
        summary = dict(kind=result['kind'], operation=result['operation'], info=info,
                       source_byte_provenance=byte_sources,
                       engine=str(t.call('::GX::SII::magickVersion')),
                       validation='validated_structure', implicit_dataset_publication=False)
        if facts_stage is not None:summary.update(facts_stage[0])
        if result.get('result_file'):
            context.publish_output(result['result_file'], 'raster', result['format'])
            summary['format'] = result['format']
        if result.get('display_file'):
            context.publish_output(result['display_file'], 'display_preview', 'png8')
            summary['display_precision'] = '8bit projection; not authoritative scientific pixels'
        if result['kind'] == 'figure':
            summary.update(panel_count=int(result['image_count'] if native_profile else result['panel_count']),
                           annotation_count=int(result['annotation_count']))
            if native_profile:
                summary['native_canvas'] = dict(
                    projection_schema=result['native_projection_schema'],
                    projection_sha256=projection_sha,
                    document_guard=tdict(result['document_guard']),
                    canvas_id=result['canvas_id'], sequence=int(result['sequence']),
                    source_snapshot_sha256=result['source_snapshot_sha256'],
                    actual_resource_refs={key: tdict(value) for key, value in references.items()},
                    canonical_sources={key: tdict(value) for key, value in origins.items()},
                    image_lineage={key: list(t.splitlist(value)) for key, value in tdict(result['image_lineage']).items()},
                    object_count=int(result['object_count']))
        elif result['operation'] == 'histogram':
            data = tdict(result['data'])
            summary['analysis'] = dict(channel=data['channel'], bins=[int(x) for x in t.splitlist(data['bins'])],
                                       bin_depth=int(data['bin_depth']), roi=[int(x) for x in t.splitlist(data['roi'])])
        elif result['operation'] == 'palette':
            summary['analysis'] = [dict(count=int(t.splitlist(row)[0]), color=t.splitlist(row)[1])
                                   for row in t.splitlist(result['data'])]
        elif result['operation'] in ('statistics', 'inspect'):
            # Original metric spelling/undefined representation is retained.
            summary['analysis'] = tdict(result['data'])
        elif result['operation'] == 'pixel':
            summary['analysis'] = result['data']
        if result.get('analysis_target'):
            summary['requested_target_label'] = result['analysis_target']
            summary['target_authority'] = 'explicit source plus recipe; actual mounted GUI target is separately owner-bound'
        provenance = dict(schema='scientific_image_inspector.managed_result.v1', **summary,
                          original_request_encoding='inert_original_Tcl_record_not_executable',
                          original_request=context.request['image_recipe'])
        if facts_stage is not None:provenance['source_facts_native']=facts_stage[1]
        if native_profile:
            provenance['native_projection_encoding'] = 'inert_original_Tcl_record_not_executable'
            provenance['native_projection'] = context.request['image_native_projection']
        with (context.output / 'provenance.json').open('x', encoding='utf-8') as stream:
            json.dump(provenance, stream, ensure_ascii=False, sort_keys=True)
        context.publish_output('provenance.json', 'provenance', 'json')
        context.summary(summary)
    finally:
        t.call('::GX::SII::cleanTemps')
