# SII application implementation; registered by its approved public module API.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII::CanvasApplication {variable preferenceDialogs {}}
# Module-owned host presentation adapter. Scientific state and all existing hooks
# remain with their original Canvas/SII/Workspace owners.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesCatalog {} {
    return {simple Editor figure Figures annotations Annotations source {Image Info} analyze Colors history History publish Publish}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesRecord {record} {
    set keys {sidebar_sections sync grid show_annotation_coordinates pending_visible}
    fields $record $keys $keys
    if {[llength $record]!=2*[dict size $record]} {error {Repeated SII preference field}}
    set sections [dict get $record sidebar_sections]
    if {[llength $sections]<1 || [llength $sections]>7} {error {Choose at least one original sidebar section}}
    set seen {}
    foreach section $sections {
        if {![dict exists [_nativeCanvasSiiPreferencesCatalog] $section] || $section in $seen} {error {Invalid or repeated SII sidebar section}}
        lappend seen $section
    }
    set result [dict create sidebar_sections $seen]
    foreach key [lrange $keys 1 end] {dict set result $key [::GX::uiFieldNormalize {type boolean required 1} [dict get $record $key]]}
    return $result
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesMap {records} {
    if {[string bytelength $records]>65536} {error {SII presentation exceeds the ordinary Workspace domain bound}}
    if {[llength $records]!=2*[dict size $records]} {error {Repeated SII Canvas component key}}
    set result {}
    dict for {component record} $records {
        if {![regexp {^[A-Za-z_][A-Za-z0-9_.-]*$} $component]} {error {Invalid SII Canvas component key}}
        dict set result $component [_nativeCanvasSiiPreferencesRecord $record]
    }
    return $result
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesEncode {records} {
    return [::GX::nativeWorkspaceEncode {map {record {sidebar_sections {array text} sync bool grid bool show_annotation_coordinates bool pending_visible bool}}} [_nativeCanvasSiiPreferencesMap $records]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDecode {typed} {
    if {[llength $typed]!=2 || [lindex $typed 0] ne {object}} {error {SII presentation must be a typed object}}
    if {[llength [lindex $typed 1]]!=2*[dict size [lindex $typed 1]]} {error {Repeated typed SII component key}}
    set records {}
    dict for {component record} [lindex $typed 1] {
        if {[llength $record]!=2 || [lindex $record 0] ne {object}} {error {SII preference record must be a typed object}}
        if {[llength [lindex $record 1]]!=2*[dict size [lindex $record 1]]} {error {Repeated typed SII field}}
        set value {}
        dict for {key field} [lindex $record 1] {
            if {[llength $field]!=2} {error {Malformed typed SII preference}}
            lassign $field kind content
            if {$key eq {sidebar_sections}} {
                if {$kind ne {array}} {error {Sidebar sections require a typed array}}
                set sections {}
                foreach section $content {
                    if {[llength $section]!=2 || [lindex $section 0] ne {text}} {error {Sidebar section requires typed text}}
                    lappend sections [lindex $section 1]
                }
                dict set value $key $sections
            } else {
                if {$kind ne {bool} || $content ni {0 1 true false}} {error {SII preference requires a native typed boolean}}
                dict set value $key $content
            }
        }
        dict set records $component [_nativeCanvasSiiPreferencesRecord $value]
    }
    return [_nativeCanvasSiiPreferencesMap $records]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesGuard {window component {expected {}}} {
    if {![::GX::viewerGuiDesignGuard $window]} {error {SII preferences belong to a closed Viewer or previous Session}}
    set instance [viewerRecord $window]
    if {[dict get $instance mode] eq {observed} || ![dict exists $instance design requirements SCIENTIFIC_IMAGE_INSPECTOR_API_v1] ||
        [dict get $instance design requirements SCIENTIFIC_IMAGE_INSPECTOR_API_v1] ne {1}} {error {Declare SCIENTIFIC_IMAGE_INSPECTOR_API_v1 version1 on the owning Viewer}}
    set handle [viewerHandle $window $component]
    if {$expected ne {} && $expected ne $handle} {error {SII preferences target a different Canvas instance}}
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {[dict get $row module] ne [dict get $instance module] || [dict get $row provider] ne [dict get $instance provider]} {error {SII Canvas has a foreign Viewer owner}}
    set roles {}
    foreach section [dict keys [_nativeCanvasSiiPreferencesCatalog]] {
        set id sii_section_$section
        set actual [::GX::viewerGuiComponentContext $window $id]
        set definition [dict get $actual definition]
        if {[dict get $definition type] ne {section} || [dict get $definition parent] ne {inspector} ||
            ![dict get $actual mounted]} {error {SII preferences require the actual seven declared sidebar sections}}
        dict set roles $id [dict create definition $definition incarnation [dict get $actual incarnation]]
    }
    return [dict create window $window incarnation [dict get $instance incarnation] component $component handle $handle session [dict get $row session] \
        module [dict get $instance module] actor_module [dict get $instance actor_module] provider [dict get $instance provider] context_epoch [dict get $instance context_epoch] document [dict get $row document] receipt [dict get $row receipt] roles $roles]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDefaults {} {
    set sections {simple figure};set coordinates 0
    # Initial defaults are READ ONLY. In particular, the original annotation
    # toggle's User configuration writer is never called by this adapter.
    dict for {id descriptor} [::GX::configurationModuleFields viewer.scientific_image_inspector] {
        set key [dict get $descriptor module_key]
        if {$key ni {sidebar_tabs annotation_coordinates} || [catch {set value [dict get [::GX::configurationResolve $id] effective]}]} continue
        if {$key eq {annotation_coordinates}} {
            if {![catch {::GX::uiFieldNormalize {type boolean required 1} $value} normalized]} {set coordinates $normalized}
        } else {
            set selected {}
            foreach section [split $value ,] {
                if {$section eq {operations}} {set section simple}
                if {[dict exists [_nativeCanvasSiiPreferencesCatalog] $section] && $section ni $selected} {lappend selected $section}
            }
            if {$selected ne {}} {set sections $selected}
        }
    }
    return [dict create sidebar_sections $sections sync 0 grid 0 show_annotation_coordinates $coordinates pending_visible 1]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesGet {window component} {
    _nativeCanvasSiiPreferencesGuard $window $component
    set domain [::GX::viewerGuiDesignContextGet $window]
    set records [_nativeCanvasSiiPreferencesRestoreCheck $window $domain]
    if {[dict exists $records $component]} {return [dict get $records $component]}
    return [_nativeCanvasSiiPreferencesDefaults]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesVisible {window component prefs} {
    set temporary [::GX::datasetPublicationV2DictDefault [::GX::datasetPublicationV2DictDefault [viewerStateRead $window] sii_preferences_revealed {}] $component {}]
    foreach section [dict keys [_nativeCanvasSiiPreferencesCatalog]] {
        ::GX::viewerGuiDesignComponentVisible $window sii_section_$section [expr {$section in [dict get $prefs sidebar_sections] || $section in $temporary}]
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesProject {window component prefs} {
    set guard [_nativeCanvasSiiPreferencesGuard $window $component]
    _nativeCanvasSiiPreferencesVisible $window $component $prefs
    # Project actual owned presentation; accepted navigation hooks consume
    # the same sole Workspace preference record.
    if {[llength [info commands ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationApply]]} {
        _nativeCanvasSiiPresentationApply $window $component [dict get $guard handle] $prefs
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesCommit {window records clearTemporary} {
    set before [::GX::viewerGuiDesignContextGet $window]
    set temporary [::GX::datasetPublicationV2DictDefault [viewerStateRead $window] sii_preferences_revealed {}]
    set old {}
    dict for {component prefs} $records {
        _nativeCanvasSiiPreferencesGuard $window $component
        dict set old $component [_nativeCanvasSiiPreferencesGet $window $component]
    }
    set next $before
    dict for {component prefs} $records {dict set next sii_presentation $component $prefs}
    ::GX::viewerGuiDesignContextSet $window $next
    if {$clearTemporary} {dict for {component prefs} $records {viewerState set $window sii_preferences_revealed $component {}}}
    if {[catch {dict for {component prefs} $records {_nativeCanvasSiiPreferencesProject $window $component $prefs}} message options]} {
        ::GX::viewerGuiDesignContextSet $window $before
        viewerState set $window sii_preferences_revealed $temporary
        set rollback {}
        dict for {component prefs} $old {if {[catch {_nativeCanvasSiiPreferencesProject $window $component $prefs} failure]} {lappend rollback $failure}}
        if {$rollback ne {}} {append message "; preference projection rollback failed: [join $rollback {; }]"}
        return -options $options $message
    }
    return $records
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesSet {window component updates} {
    _nativeCanvasSiiPreferencesGuard $window $component
    fields $updates {sidebar_sections sync grid show_annotation_coordinates pending_visible}
    if {[llength $updates]!=2*[dict size $updates]} {error {Repeated SII preference update field}}
    set prefs [_nativeCanvasSiiPreferencesRecord [dict merge [_nativeCanvasSiiPreferencesGet $window $component] $updates]]
    _nativeCanvasSiiPreferencesCommit $window [dict create $component $prefs] [dict exists $updates sidebar_sections]
    return $prefs
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesCapture {window} {
    if {![::GX::viewerGuiDesignGuard $window]} {error {Cannot capture preferences from a previous Viewer lifetime}}
    set instance [viewerRecord $window]
    if {![_nativeCanvasSiiPreferencesEditable $instance]} {return {}}
    set result {}
    dict for {component handle} [::GX::datasetPublicationV2DictDefault $instance canvas_slots {}] {
        if {![_nativeCanvasSiiPreferencesEditable $instance $component]} continue
        _nativeCanvasSiiPreferencesGuard $window $component $handle
        dict set result $component [_nativeCanvasSiiPreferencesGet $window $component]
    }
    return [_nativeCanvasSiiPreferencesMap $result]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesCaptureVisibility {window visibility} {
    if {![::GX::viewerGuiDesignGuard $window]} {error {Cannot capture visibility from a previous Viewer lifetime}}
    set instance [viewerRecord $window]
    if {![dict exists $instance design requirements SCIENTIFIC_IMAGE_INSPECTOR_API_v1]} {return $visibility}
    # Names alone grant no authority. Only the actual declared, mounted SII
    # Canvas association may exclude its derived seven-section projection.
    set actual [_nativeCanvasSiiPreferencesCapture $window]
    if {$actual eq {}} {return $visibility}
    foreach section [dict keys [_nativeCanvasSiiPreferencesCatalog]] {dict unset visibility sii_section_$section}
    return $visibility
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesRestoreCheck {window domain} {
    if {![::GX::viewerGuiDesignGuard $window]} {error {Cannot restore preferences into a previous Viewer lifetime}}
    set records [_nativeCanvasSiiPreferencesMap [::GX::datasetPublicationV2DictDefault $domain sii_presentation {}]]
    set instance [viewerRecord $window]
    if {![_nativeCanvasSiiPreferencesEditable $instance]} {return {}}
    dict for {component prefs} $records {
        if {[dict get $instance mode] eq {demo}} {
            if {![_nativeCanvasSiiPreferencesEditable $instance $component]} {error {SII preferences require their declared Canvas component}}
            foreach section [dict keys [_nativeCanvasSiiPreferencesCatalog]] {
                set actual [::GX::viewerGuiComponentContext $window sii_section_$section]
                if {![dict get $actual mounted]} {error {SII preferences require the actual seven declared sidebar sections}}
            }
        } else {_nativeCanvasSiiPreferencesGuard $window $component}
    }
    return $records
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesRestore {window domain} {
    set records [_nativeCanvasSiiPreferencesRestoreCheck $window $domain]
    if {[dict get [viewerRecord $window] mode] eq {demo}} {
        # The design host retains the original typed record without a native
        # engine. Project only its already validated sidebar visibility here.
        dict for {component prefs} $records {_nativeCanvasSiiPreferencesVisible $window $component $prefs}
        return $records
    }
    # Missing optional records are the original draft defaults, not inherited
    # preferences from a different Workspace previously open in this window.
    dict for {component prefs} [_nativeCanvasSiiPreferencesCapture $window] {
        if {![dict exists $records $component]} {dict set records $component [_nativeCanvasSiiPreferencesDefaults]}
    }
    if {$records ne {}} {_nativeCanvasSiiPreferencesCommit $window $records 1}
    return $records
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesReveal {window component section} {
    _nativeCanvasSiiPreferencesGuard $window $component
    if {![dict exists [_nativeCanvasSiiPreferencesCatalog] $section]} {error {Unknown SII sidebar section}}
    set prefs [_nativeCanvasSiiPreferencesGet $window $component]
    set prior [::GX::datasetPublicationV2DictDefault [::GX::datasetPublicationV2DictDefault [viewerStateRead $window] sii_preferences_revealed {}] $component {}]
    set next $prior
    if {$section ni $next} {lappend next $section}
    viewerState set $window sii_preferences_revealed $component $next
    if {[catch {_nativeCanvasSiiPreferencesVisible $window $component $prefs} message options]} {
        viewerState set $window sii_preferences_revealed $component $prior
        catch {_nativeCanvasSiiPreferencesVisible $window $component $prefs}
        return -options $options $message
    }
    ::GX::viewerGuiComponentSee $window sii_section_$section
    return [dict create status revealed section $section]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDialogApply {token action values} {
    variable preferenceDialogs
    if {![dict exists $preferenceDialogs $token]} {error {SII preference dialog lifetime ended}}
    set captured [dict get $preferenceDialogs $token]
    set window [dict get $captured window];set component [dict get $captured component]
    set dialog [dict get $captured dialog]
    if {![winfo exists $dialog] || [winfo id $dialog] ne [dict get $captured dialog_incarnation] ||
        [_nativeCanvasSiiPreferencesGuard $window $component [dict get $captured handle]] ne [dict remove $captured dialog dialog_incarnation subscription]} {error {SII preference owner changed; reopen its current dialog}}
    set updates {};set selected {}
    foreach section [dict keys [_nativeCanvasSiiPreferencesCatalog]] {
        if {[dict get $values sidebar_$section]} {lappend selected $section}
    }
    dict set updates sidebar_sections $selected
    if {$action eq {viewer_settings}} {foreach key {sync grid show_annotation_coordinates pending_visible} {dict set updates $key [dict get $values $key]}}
    return [_nativeCanvasSiiPreferencesSet $window $component $updates]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDialogSession {token receipt} {
    variable preferenceDialogs
    if {![dict exists $preferenceDialogs $token]} return
    set captured [dict get $preferenceDialogs $token]
    if {[dict get $receipt event] ni {session_changed deleted owner_replaced}} return
    set dialog [dict get $captured dialog]
    catch {if {[winfo exists $dialog] && [winfo id $dialog] eq [dict get $captured dialog_incarnation]} {destroy $dialog}}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDialogDestroyed {token actual} {
    variable preferenceDialogs
    if {![dict exists $preferenceDialogs $token]} return
    set captured [dict get $preferenceDialogs $token]
    if {$actual ne [dict get $captured dialog]} return
    if {[dict exists $captured subscription]} {::GX::interactiveDocumentLifecycleUnsubscribe [dict get $captured subscription]}
    dict unset preferenceDialogs $token
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesCommand {window component handle action} {
    if {$action ni {sidebar_settings viewer_settings}} {error {Unknown SII preference action}}
    set captured [_nativeCanvasSiiPreferencesGuard $window $component $handle]
    ::GX::viewerGuiContextCommandCurrent $window $component
    set prefs [_nativeCanvasSiiPreferencesGet $window $component]
    set dialog $window.sii_preferences_[binary encode hex [encoding convertto utf-8 $component]]_$action
    if {[winfo exists $dialog]} {raise $dialog;return [dict create status presented]}
    set fields {};set initial {}
    foreach {section label} [_nativeCanvasSiiPreferencesCatalog] {
        dict set fields sidebar_$section [dict create type boolean required 1 label $label section sidebar]
        dict set initial sidebar_$section [expr {$section in [dict get $prefs sidebar_sections]}]
    }
    set sections [dict create sidebar {Sidebar sections}]
    if {$action eq {viewer_settings}} {
        dict set sections display {Display and navigation}
        foreach {key label} {sync {Synchronize comparison zoom and pan} grid {Show pixel coordinate grid} show_annotation_coordinates {Show exact annotation coordinates} pending_visible {Show pending adjustment pane}} {
            dict set fields $key [dict create type boolean required 1 label $label section display]
            dict set initial $key [dict get $prefs $key]
        }
    }
    variable preferenceDialogs
    set token sii-preferences-[pid]-[incr ::GX::SII::CanvasApplication::siiSerial]
    ::GX::uiFieldFormCreate $dialog {Scientific Image Inspector — Workspace preferences} $fields $initial [list ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDialogApply $token $action] $window $sections
    dict set captured dialog $dialog
    dict set captured dialog_incarnation [winfo id $dialog]
    dict set preferenceDialogs $token $captured
    set callback [list ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDialogSession $token]
    set subscription [::GX::interactiveDocumentLifecycleSubscribe $callback $dialog [dict get $captured document]]
    dict set preferenceDialogs $token subscription $subscription
    bind $dialog <Destroy> +[list ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDialogDestroyed $token %W]
    return [dict create status presented]
}
::GX::viewerWorkspaceCodecRegister domains sii_presentation ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesEncode
::GX::nativeWorkspaceCodecDecodeRegister ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesEncode ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDecode
# Persisted pre-extraction codec keys remain readable through this module.
# This registers data-key compatibility, never a CORE application command.
::GX::nativeWorkspaceCodecDecodeRegister ::GX::_nativeCanvasSiiPreferencesEncode ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesDecode

# Finite projection over the existing Native2D views. Preference values remain
# solely in sii_presentation; these records describe actual live owners only.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationTarget {handle} {
    set host [::GX::native2DCanvasPresentationHost $handle]
    set context [dict get $host context]
    return [dict merge $host [dict create document [dict get $context document_id] receipt [dict get $context document_receipt] \
        session [dict get $context session] module [dict get $context module_id] provider [dict get $context provider_id] sequence [dict get $context sequence]]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationOwners {window component handle} {
    set guard [_nativeCanvasSiiPreferencesGuard $window $component $handle]
    set main [_nativeCanvasSiiPresentationTarget $handle]
    if {[dict get $main toplevel] ne $window} {error {SII view belongs to another actual Viewer window}}
    set targets [dict create $handle $main];set candidate {}
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {[dict exists $row sii_comparison]} {
        set binding [dict get $row sii_comparison]
        fields $binding {handle parent} {handle parent}
        set candidate [dict get $binding handle]
        if {$candidate eq $handle || [dict get $binding parent] ne [dict get $main frame]} {error {SII comparison has another parent view}}
        set other [_nativeCanvasSiiPresentationTarget $candidate]
        foreach key {document session module provider} {
            if {[dict get $other $key] ne [dict get $main $key]} {error {SII comparison belongs to another owner}}
        }
        foreach key {generation revision sha256} {
            if {[dict get $other receipt $key] ne [dict get $main receipt $key]} {error {SII comparison has another Document lifetime}}
        }
        if {![dict get $other read_only] || [dict get $other parent_handle] ne $handle ||
            [dict get $other geometry] eq [dict get $main geometry] || [dict get $other toplevel] ne $window} {error {SII comparison is not the original independent read-only presentation}}
        dict set targets $candidate $other
    }
    set parent [dict get [::GX::viewerGuiComponentHost $window sii_section_annotations] widget]
    return [dict create window $window component $component handle $handle guard $guard targets $targets candidate $candidate coordinate_parent $parent]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationRequire {owners prefs} {
    set window [dict get $owners window];set component [dict get $owners component];set handle [dict get $owners handle]
    if {[_nativeCanvasSiiPresentationOwners $window $component $handle] ne $owners ||
        [_nativeCanvasSiiPreferencesGet $window $component] ne $prefs} {error {SII presentation owner or Workspace preferences changed; retry in its current view}}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationTargetCurrent {owners target} {
    if {[catch {
        set window [dict get $owners window];set component [dict get $owners component];set main [dict get $owners handle]
        if {[_nativeCanvasSiiPreferencesGuard $window $component $main] ne [dict get $owners guard]} {error stale}
        if {$target ne $main} {
            set row [::GX::SII::CanvasApplication::appRecord $main]
            if {![dict exists $row sii_comparison] || [dict get $row sii_comparison handle] ne $target ||
                [dict get $row sii_comparison parent] ne [dict get $owners targets $main frame]} {error stale}
        }
        if {[_nativeCanvasSiiPresentationTarget $target] ne [dict get $owners targets $target]} {error stale}
    }]} {return 0}
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationApply {window component handle prefs} {
    set prefs [_nativeCanvasSiiPreferencesRecord $prefs]
    set owners [_nativeCanvasSiiPresentationOwners $window $component $handle]
    _nativeCanvasSiiPresentationRequire $owners $prefs
    set text {}
    if {[dict get $prefs show_annotation_coordinates]} {
        if {![llength [info commands ::GX::SII::CanvasApplication::_nativeCanvasSiiAnnotationCoordinates]]} {error {Matching SII annotation coordinate owner is unavailable}}
        set text [_nativeCanvasSiiAnnotationCoordinates $handle]
        if {[string bytelength $text]>1048576} {error {SII annotation coordinate readout exceeds the existing CORE text bound}}
        # Revalidate the real association
        # and the sole Workspace authority before changing any projection.
        _nativeCanvasSiiPresentationRequire $owners $prefs
    }
    set parent [dict get $owners coordinate_parent]
    set label $parent.sii_coordinate_readout
    set marker GXSiiCoordinateReadout:[dict get $owners guard incarnation]:[binary encode hex [encoding convertto utf-8 $component]]:[winfo id $parent]
    set labelBefore {};set labelCreated {};set grids {};set changed {}
    if {[winfo exists $label]} {
        if {[winfo class $label] ne {TLabel} || $marker ni [bindtags $label] || [winfo manager $label] ni {{} grid}} {error {SII coordinate readout is owned by another presentation}}
        set labelBefore [dict create id [winfo id $label] text [$label cget -text] visible [expr {[winfo manager $label] eq {grid}}]]
    }
    dict for {target stamp} [dict get $owners targets] {dict set grids $target [::GX::native2DGeometryCall [dict get $stamp geometry] grid {}]}
    set candidate [dict get $owners candidate];set pendingBefore {};set pendingChanged 0
    if {$candidate ne {}} {
        set pendingBefore [::GX::native2DCanvasReadOnlyViewVisibility $handle $candidate]
    }
    try {
        dict for {target stamp} [dict get $owners targets] {
            _nativeCanvasSiiPresentationRequire $owners $prefs
            set grid [dict get $grids $target]
            # Hiding the application grid must preserve the accepted native
            # enable/snap state. Only an explicit visible grid needs enabling.
            if {[dict get $prefs grid]} {dict set grid enabled 1}
            dict set grid visible [dict get $prefs grid]
            lappend changed $target
            ::GX::native2DGeometryCall [dict get $stamp geometry] grid [dict create arguments [list $grid]]
        }
        if {$candidate ne {}} {
            _nativeCanvasSiiPresentationRequire $owners $prefs
            set pendingChanged 1
            ::GX::native2DCanvasReadOnlyViewVisibility $handle $candidate [dict get $prefs pending_visible]
        }
        _nativeCanvasSiiPresentationRequire $owners $prefs
        if {[dict get $prefs show_annotation_coordinates]} {
            if {![winfo exists $label]} {
                ttk::label $label -anchor w -justify left -wraplength 380 -takefocus 1
                bindtags $label [linsert [bindtags $label] 0 $marker]
                set labelCreated [winfo id $label]
                grid $label -row [lindex [grid size $parent] 1] -column 0 -columnspan 2 -sticky ew -pady 4
            }
            $label configure -text $text
            grid $label
        } elseif {[winfo exists $label]} {grid remove $label}
        _nativeCanvasSiiPresentationRequire $owners $prefs
        dict for {target stamp} [dict get $owners targets] {::GX::native2DCanvasSchedule $target}
    } on error {message options} {
        # Restore only our view/widget changes, and only in the same actual
        # owner incarnation. Never restore a scientific snapshot or a new pane.
        foreach target $changed {
            if {[_nativeCanvasSiiPresentationTargetCurrent $owners $target]} {catch {::GX::native2DGeometryCall [dict get $owners targets $target geometry] grid [dict create arguments [list [dict get $grids $target]]]}}
        }
        if {$pendingChanged && [_nativeCanvasSiiPresentationTargetCurrent $owners $candidate]} {
            catch {::GX::native2DCanvasReadOnlyViewVisibility $handle $candidate $pendingBefore}
        }
        if {[_nativeCanvasSiiPresentationTargetCurrent $owners $handle]} {
            if {$labelCreated ne {}} {
                catch {if {[winfo exists $label] && [winfo id $label] eq $labelCreated && $marker in [bindtags $label]} {destroy $label}}
            } elseif {$labelBefore ne {}} {
                catch {
                    if {[winfo exists $label] && [winfo id $label] eq [dict get $labelBefore id] && $marker in [bindtags $label]} {
                        $label configure -text [dict get $labelBefore text]
                        if {[dict get $labelBefore visible]} {grid $label} else {grid remove $label}
                    }
                }
            }
        }
        dict for {target stamp} [dict get $owners targets] {if {[_nativeCanvasSiiPresentationTargetCurrent $owners $target]} {catch {::GX::native2DCanvasSchedule $target}}}
        return -options $options $message
    }
    # sync is consumed by the accepted-input hook below. Toggling it never
    # copies a foreign viewport's dimensions, calibration, grid or background.
    return [dict create status projected grid [dict get $prefs grid] candidate_present [expr {$candidate ne {}}] \
        pending_visible [expr {$candidate ne {} && [::GX::native2DCanvasReadOnlyViewVisibility $handle $candidate]}] coordinates_visible [dict get $prefs show_annotation_coordinates] sync [dict get $prefs sync]]
}
# Recognition is structural, not a replacement lifetime/authorization guard.
# An API declaration alone does not opt an ordinary Canvas into this editor.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesEditable {instance {component {}}} {
    if {[dict get $instance mode] eq {observed} || ![dict exists $instance design requirements SCIENTIFIC_IMAGE_INSPECTOR_API_v1] ||
        [dict get $instance design requirements SCIENTIFIC_IMAGE_INSPECTOR_API_v1] ne {1}} {return 0}
    set definitions {}
    foreach definition [dict get $instance design components] {dict set definitions [dict get $definition id] $definition}
    foreach section [dict keys [_nativeCanvasSiiPreferencesCatalog]] {
        set id sii_section_$section
        if {![dict exists $definitions $id] || [dict get $definitions $id type] ne {section} || [dict get $definitions $id parent] ne {inspector}} {return 0}
    }
    if {$component ne {}} {
        if {![dict exists $definitions $component] || [dict get $definitions $component type] ne {native2d} ||
            [::GX::datasetPublicationV2DictDefault [dict get $definitions $component properties] source_kind {}] ne {canvas}} {return 0}
    }
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPreferencesForHandle {handle} {
    set matches {}
    variable viewerStateByLifetime
    dict for {lifetime values} $viewerStateByLifetime {
        set window [lindex $lifetime 0]
        if {[catch {set currentKey [viewerStateKey $window]}] || $currentKey ne $lifetime ||
            [catch {set instance [viewerRecord $window]}]} continue
        if {![_nativeCanvasSiiPreferencesEditable $instance]} continue
        dict for {component main} [::GX::datasetPublicationV2DictDefault $instance canvas_slots {}] {
            if {![_nativeCanvasSiiPreferencesEditable $instance $component]} continue
            if {$handle eq $main || ([::GX::SII::CanvasApplication::canvasState exists $main sii_comparison handle] &&
                [::GX::SII::CanvasApplication::canvasState get $main sii_comparison handle] eq $handle)} {lappend matches [list $window $component $main]}
        }
    }
    if {$matches eq {}} {return {}}
    if {[llength $matches]!=1} {error {SII view has ambiguous actual Viewer ownership}}
    lassign [lindex $matches 0] window component main
    set owners [_nativeCanvasSiiPresentationOwners $window $component $main]
    set other [expr {$handle eq $main ? [dict get $owners candidate] : $main}]
    return [dict create window $window component $component handle $main source_handle $handle other_handle $other \
        prefs [_nativeCanvasSiiPreferencesGet $window $component] owners $owners]
}

# Accepted-AFTER navigation: the original owner has already changed the source
# view. Mirror only the same actual comparison owner, never reenter commands or
# copy viewport dimensions, calibration, grid, alpha or scientific snapshots.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiNavigation {handle operation request} {
    switch -- $operation {
        pan {fields $request {dx dy} {dx dy};set dx [number [dict get $request dx] -1e9 1e9 dx];set dy [number [dict get $request dy] -1e9 1e9 dy]}
        zoom {
            fields $request {factor center} {factor}
            set factor [number [dict get $request factor] 1e-12 1e12 factor]
            set center [::GX::datasetPublicationV2DictDefault $request center {0 0}]
            if {[llength $center]!=2} {error {SII zoom requires two actual device coordinates}}
            set center [lmap x $center {number $x -1e9 1e9 center}]
        }
        fit {fields $request {}}
        default {error {Unsupported accepted SII navigation operation}}
    }
    set binding [_nativeCanvasSiiPreferencesForHandle $handle]
    if {$binding eq {}} {return {status unassociated}}
    set owners [dict get $binding owners];set prefs [dict get $binding prefs]
    _nativeCanvasSiiPresentationRequire $owners $prefs
    set other [dict get $binding other_handle]
    if {![dict get $prefs sync] || $other eq {}} {return {status independent}}
    set stamp [dict get $owners targets $other];set geometry [dict get $stamp geometry]
    switch -- $operation {
        pan {::GX::native2DGeometryCall $geometry pan [dict create delta [list $dx $dy]]}
        zoom {::GX::native2DGeometryCall $geometry zoom [dict create factor $factor point $center]}
        fit {lassign [dict get [::GX::native2DCanvasViewInfo $other] extent] width height;::GX::native2DGeometryCall $geometry fit_bounds [dict create bounds [list 0 0 $width $height]]}
    }
    ::GX::native2DCanvasViewChanged $other
    return [dict create status synchronized operation $operation]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiInputCancel {handle} {
    if {![::GX::SII::CanvasApplication::canvasState exists $handle sii_navigation_pan]} return
    set pan [::GX::SII::CanvasApplication::canvasState get $handle sii_navigation_pan]
    ::GX::SII::CanvasApplication::canvasState unset $handle sii_navigation_pan
    set other [dict get $pan other]
    if {$other ne {} && [_nativeCanvasSiiPresentationTargetCurrent [dict get $pan owners] $other]} {
        set geometry [dict get $pan owners targets $other geometry]
        set view [::GX::native2DGeometryCall $geometry view_requested {}]
        # Restore only this pane's own pre-gesture camera. A current resize,
        # calibration, background or other view metadata must remain current.
        lset view 6 [dict get $pan world]
        ::GX::native2DGeometryCall $geometry view [dict create arguments [list $view]]
        ::GX::native2DCanvasViewChanged $other
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiInputAccepted {handle kind data receipt} {
    set binding [_nativeCanvasSiiPreferencesForHandle $handle]
    if {$binding eq {}} return
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {$kind eq {down} && [dict get [::GX::native2DCanvasViewInfo $handle] tool] eq {pan} && [::GX::datasetPublicationV2DictDefault $receipt provisional 0]} {
        set other [dict get $binding other_handle];set world {}
        if {$other ne {} && [dict get $binding prefs sync]} {set world [lindex [::GX::native2DGeometryCall [dict get $binding owners targets $other geometry] view_requested {}] 6]} else {set other {}}
        ::GX::SII::CanvasApplication::canvasState set $handle sii_navigation_pan [dict create owners [dict get $binding owners] prefs [dict get $binding prefs] other $other world $world position [dict get $data position]]
        return
    }
    if {[dict exists $row sii_navigation_pan]} {
        set pan [dict get $row sii_navigation_pan]
        if {[::GX::datasetPublicationV2DictDefault $receipt canceled 0]} {_nativeCanvasSiiInputCancel $handle;return}
        if {$kind in {move up}} {
            _nativeCanvasSiiPresentationRequire [dict get $pan owners] [dict get $pan prefs]
            lassign [dict get $pan position] x y;lassign [dict get $data position] nx ny
            _nativeCanvasSiiNavigation $handle pan [dict create dx [expr {$nx-$x}] dy [expr {$ny-$y}]]
            if {$kind eq {up}} {::GX::SII::CanvasApplication::canvasState unset $handle sii_navigation_pan} else {::GX::SII::CanvasApplication::canvasState set $handle sii_navigation_pan position [dict get $data position]}
        }
    } elseif {$kind eq {wheel} && [::GX::datasetPublicationV2DictDefault $receipt changed 0]} {
        # Exact original Canvas event factor, also applied once by its native
        # source owner. Unlike the old display preview, no photo resampling.
        _nativeCanvasSiiNavigation $handle zoom [dict create factor [expr {pow(1.2,-[dict get $data delta]/120.0)}] center [dict get $data position]]
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAnnotationCoordinates {handle} {
    set state [::GX::native2DCanvasRetainedInfo $handle]
    set frame {};set frameName {};set lines {}
    foreach layer [dict get $state layers] {
        if {![dict exists $layer attributes gx.sii.figure]} continue
        set figure [dict get $layer attributes gx.sii.figure]
        fields $figure {schema settings panels annotations frame_object} {schema settings panels annotations frame_object}
        if {[dict get $figure schema] ne {gxtxt.sii.native_figure.v1}} {error {Unsupported native figure coordinate owner}}
        set logical [dict get $figure frame_object]
        if {$logical eq {}} continue
        foreach item [dict get $state objects] {
            if {[dict get $item logical_id] ne $logical} continue
            set marker [dict get $item attributes gx.sii.figure]
            fields $marker {schema layer role} {schema layer role}
            if {[dict get $marker schema] ne {gxtxt.sii.native_figure_member.v1} || [dict get $marker layer] ne [dict get $layer logical_id] || [dict get $marker role] ne {frame} || [dict get $item kind] ne {image}} {error {Foreign native figure coordinate frame}}
            if {$frame ne {}} {error {Ambiguous native figure coordinate frame}}
            set frame $item;set frameName $logical
        }
    }
    if {$frame eq {}} {
        foreach item [dict get $state objects] {
            if {[dict get $item logical_id] in [dict get $state selection] && [dict get $item kind] eq {image}} {set frame $item;set frameName [dict get $item logical_id];break}
        }
    }
    foreach item [dict get $state objects] {
        set logical [dict get $item logical_id]
        if {$logical ni [dict get $state selection] || $logical eq $frameName} continue
        set bounds [dict get $item bounds]
        if {[llength $bounds]!=4} continue
        lassign $bounds x0 y0 x1 y1
        set line "$logical: Native world bounds [join $bounds {, }]"
        if {$frame ne {}} {
            set corners {}
            foreach point [list [list $x0 $y0] [list $x1 $y0] [list $x1 $y1] [list $x0 $y1]] {lappend corners [geometryImageMap [dict get $frame geometry] [dict get $frame object_token] $point 1]}
            append line "\n  Image px corners of bounds ($frameName): [join $corners { ; }]"
        }
        lappend lines $line
        if {[string bytelength [join $lines \n]]>1048576} {error {SII annotation coordinate readout exceeds the existing CORE text bound}}
    }
    if {$lines eq {}} {return {Select a Native annotation to inspect its current coordinates.}}
    return [join $lines \n]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationRefresh {handle} {
    set binding [_nativeCanvasSiiPreferencesForHandle $handle]
    if {$binding eq {}} return
    set prefs [dict get $binding prefs]
    if {![dict get $prefs show_annotation_coordinates]} return
    set owners [dict get $binding owners]
    _nativeCanvasSiiPresentationRequire $owners $prefs
    set parent [dict get $owners coordinate_parent];set label $parent.sii_coordinate_readout
    if {![winfo exists $label]} return
    set marker GXSiiCoordinateReadout:[dict get $owners guard incarnation]:[binary encode hex [encoding convertto utf-8 [dict get $binding component]]]:[winfo id $parent]
    if {[winfo class $label] ne {TLabel} || $marker ni [bindtags $label]} {error {SII coordinate readout is owned by another presentation}}
    $label configure -text [_nativeCanvasSiiAnnotationCoordinates [dict get $binding handle]]
}
