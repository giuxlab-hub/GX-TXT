# Original SII viewport arithmetic and fixed renderer, shared by its owners.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII {}
proc ::GX::SII::lodCropPlan {iw ih cw ch first last} {
    if {$iw<1 || $ih<1 || $cw<20 || $ch<20} {return {}}
    lassign $first ax ay
    lassign $last bx by
    set x [expr {max(0,int(floor(min($ax,$bx))))}]
    set y [expr {max(0,int(floor($ih-max($ay,$by))))}]
    set right [expr {min($iw,int(ceil(max($ax,$bx))))}]
    set bottom [expr {min($ih,int(ceil($ih-min($ay,$by))))}]
    if {$right <= $x || $bottom <= $y} {return {}}
    return [list $x $y [expr {$right-$x}] [expr {$bottom-$y}]]
}
proc ::GX::SII::lodDevicePlan {source crop first last} {
    lassign $crop x y sw sh
    lassign $first dx0 dy0
    lassign $last dx1 dy1
    set dw [expr {int(round(abs($dx1-$dx0)))}]
    set dh [expr {int(round(abs($dy1-$dy0)))}]
    if {$dw<10 || $dh<10 || $dw>4096 || $dh>4096 || wide($dw)*$dh>8500000} {return {}}
    return [list $source $x $y $sw $sh $dw $dh [expr {int(round($dx0))}] [expr {int(round($dy0))}]]
}
proc ::GX::SII::lodRenderArgv {plan output} {
    lassign $plan source x y sw sh dw dh px py
    return [list [magickPath] {*}[limits] [frame0 $source] \
        -crop "${sw}x${sh}+${x}+${y}" +repage \
        -filter Lanczos -resize "${dw}x${dh}!" -depth 8 "PNG:$output"]
}
