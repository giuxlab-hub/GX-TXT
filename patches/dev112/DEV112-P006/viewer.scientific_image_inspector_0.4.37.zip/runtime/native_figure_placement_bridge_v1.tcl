# SPDX-License-Identifier: GPL-3.0-or-later
# Private original SII/ImageMagick bridge; this file grants no GUI authority.
# ROOT binds and seals Package schema102 in the original prepared Job. Public
# SII9 and the legacy Native PNG/RGBA8 routes do not dispatch here.
namespace eval ::GX::SII::NativeFigurePlacementV1 {}

proc ::GX::SII::NativeFigurePlacementV1::_fail {message {kind INVALID}} {
    return -code error -errorcode [list GXTXT SII NATIVE_FIGURE $kind] $message
}
proc ::GX::SII::NativeFigurePlacementV1::_record {value required {optional {}}} {
    _map $value
    foreach key $required {if {![dict exists $value $key]} {_fail "Missing native figure field '$key'"}}
    foreach key [dict keys $value] {if {$key ni $required && $key ni $optional} {_fail "Unknown native figure field '$key'"}}
}
proc ::GX::SII::NativeFigurePlacementV1::_map {value} {
    if {[catch {llength $value} count] || $count%2} {_fail {Expected an inert key/value record}}
    set seen {}
    foreach {key item} $value {
        if {[dict exists $seen $key]} {_fail "Duplicate native record/map key '$key'"}
        dict set seen $key 1
    }
}
proc ::GX::SII::NativeFigurePlacementV1::_text {value} {
    if {$value eq {} || [string first \x00 $value]>=0} {_fail {Invalid empty/NUL native identity}}
    return $value
}
proc ::GX::SII::NativeFigurePlacementV1::_int {value} {
    if {![string is entier -strict $value]} {_fail {Expected an integer native field}}
    return $value
}
proc ::GX::SII::NativeFigurePlacementV1::_number {value} {
    if {![string is double -strict $value] || [catch {expr {double($value)>-Inf && double($value)<Inf}} finite] || !$finite} {_fail {Native numeric fields must be finite}}
    return [expr {double($value)}]
}
proc ::GX::SII::NativeFigurePlacementV1::_unit {value} {
    set n [_number $value]
    if {$n<0 || $n>1} {_fail {Opacity/color component outside original native range}}
    return $n
}
proc ::GX::SII::NativeFigurePlacementV1::_bool {value} {
    if {![string is boolean -strict $value]} {_fail {Invalid native boolean}}
    return [expr {!!$value}]
}
proc ::GX::SII::NativeFigurePlacementV1::_vector {value count} {
    if {[llength $value]!=$count} {_fail "Expected $count native numeric components"}
    foreach v $value {_number $v}
}
proc ::GX::SII::NativeFigurePlacementV1::_sha {value} {
    if {![regexp {^[a-f0-9]{64}$} $value]} {_fail {Expected original lowercase SHA-256}}
}
proc ::GX::SII::NativeFigurePlacementV1::_resource {reference} {
    _record $reference {api_id document_id owner_generation sha256 size_bytes metadata}
    if {[dict get $reference api_id] ne {INTERACTIVE_DOCUMENT_RESOURCE_API_v1}} {_fail {Unknown Document Resource owner}}
    _text [dict get $reference document_id];_text [dict get $reference owner_generation]
    _sha [dict get $reference sha256]
    if {[_int [dict get $reference size_bytes]]<0 || [catch {dict size [dict get $reference metadata]}]} {_fail {Invalid Document Resource facts}}
    # Metadata is the original named resource_metadata, validated by ROOT's
    # original codec/materializer. Do not invent a competing metadata union.
}
proc ::GX::SII::NativeFigurePlacementV1::_sameResource {left right} {
    _resource $left;_resource $right
    foreach key {api_id document_id owner_generation sha256 size_bytes metadata} {
        if {[dict get $left $key] ne [dict get $right $key]} {_fail "Captured/materialized Resource association differs: $key" ASSOCIATION}
    }
}
proc ::GX::SII::NativeFigurePlacementV1::_style {style} {
    _record $style {visible selectable locked order line_style marker line_width color}
    foreach key {visible selectable locked} {_bool [dict get $style $key]}
    foreach key {order line_style marker} {_int [dict get $style $key]}
    set width [_number [dict get $style line_width]]
    if {$width<0 || $width>256} {_fail {Original native line width must be0..256}}
    _vector [dict get $style color] 4
    foreach c [dict get $style color] {_unit $c}
}
proc ::GX::SII::NativeFigurePlacementV1::_origin {origin} {
    _record $origin {dataset_id source_sha256 source_revision}
    _text [dict get $origin dataset_id];_text [dict get $origin source_revision]
    _sha [dict get $origin source_sha256]
}
proc ::GX::SII::NativeFigurePlacementV1::_imageState {state style} {
    _record $state {resource_id length_unit width height scale rotation opacity calibrated_distance visible locked calibrated translation calibration}
    _text [dict get $state resource_id];_text [dict get $state length_unit]
    foreach key {width height scale} {if {[_number [dict get $state $key]]<=0} {_fail "Invalid native image $key"}}
    _number [dict get $state rotation];_number [dict get $state calibrated_distance]
    _unit [dict get $state opacity]
    foreach key {visible locked calibrated} {_bool [dict get $state $key]}
    _vector [dict get $state translation] 2
    if {[llength [dict get $state calibration]]!=2} {_fail {Expected both original calibration points}}
    foreach point [dict get $state calibration] {_vector $point 2}
    # image_metadata/image_get mirror style.opacity, visible and locked. These
    # are consistency checks, NOT additional multiplicative image opacity.
    if {[dict get $state opacity]!=[lindex [dict get $style color] 3] ||
        [_bool [dict get $state visible]]!=[_bool [dict get $style visible]] ||
        [_bool [dict get $state locked]]!=[_bool [dict get $style locked]]} {_fail {Native image/style alias facts differ} ASSOCIATION}
}
proc ::GX::SII::NativeFigurePlacementV1::_isText {object} {
    return [expr {[dict exists $object canvas_metadata kind] && [dict get $object canvas_metadata kind] eq {text}}]
}
proc ::GX::SII::NativeFigurePlacementV1::_visible {object layers groups} {
    set layer [dict get $object layer];set group [dict get $object group]
    set visible [expr {[_bool [dict get $object style visible]] && [lindex [dict get $object style color] 3]>0 &&
        [_bool [dict get $layers $layer properties visible]] && [dict get $layers $layer properties opacity]>0}]
    if {$group ne {}} {set visible [expr {$visible && [_bool [dict get $groups $group style visible]] && [lindex [dict get $groups $group style color] 3]>0}]}
    return $visible
}
proc ::GX::SII::NativeFigurePlacementV1::_glyphInk {object} {
    # Native canvasMode uses unit ink alpha; fill has its own original alpha.
    if {[dict exists $object canvas_metadata fill]} {return [dict get $object canvas_metadata fill]}
    return [lreplace [dict get $object style color] 3 3 1]
}
proc ::GX::SII::NativeFigurePlacementV1::_validateGlyph {object resources} {
    if {[dict exists $object native_sampling] && ![_bool [dict get [_sampling $object] skip_path]]} {_fail {Original text is a special Native path, not a sampled curve} ASSOCIATION}
    foreach key {font_facts text_glyph} {if {![dict exists $object $key]} {_fail "Text annotation requires original '$key'"}}
    set metadata [dict get $object canvas_metadata];_map $metadata
    if {![dict exists $metadata text] || [string bytelength [dict get $metadata text]]>8192} {_fail {Original native text exceeds8192UTF8 bytes or is missing}}
    set definition [dict get $object definition];_map $definition
    foreach key {family controls matrix} {if {![dict exists $definition $key]} {_fail {Text needs its original native rectangle definition}}}
    if {[dict get $definition family] ne {rectangle} || [llength [dict get $definition controls]]!=2} {_fail {Text needs its original native rectangle anchor}}
    foreach point [dict get $definition controls] {_vector $point 2};_vector [dict get $definition matrix] 6
    set facts [dict get $object font_facts]
    _record $facts {descriptor actual metrics world_size anchor glyph_receipt}
    set descriptor [dict get $facts descriptor]
    if {[string bytelength $descriptor]<1 || [string bytelength $descriptor]>512} {_fail {Original font descriptor must contain1..512bytes}}
    set actual [dict get $facts actual];_record $actual {-family -size -weight -slant -underline -overstrike}
    _int [dict get $actual -size]
    foreach key {-underline -overstrike} {_bool [dict get $actual $key]}
    set metrics [dict get $facts metrics];_record $metrics {-ascent -descent -linespace -fixed}
    foreach key {-ascent -descent -linespace} {_int [dict get $metrics $key]}
    _bool [dict get $metrics -fixed]
    if {[dict get $metrics -ascent]<0 || [dict get $metrics -descent]<0 || [dict get $metrics -linespace]<1 || [dict get $metrics -linespace]>4096} {_fail {Invalid original Tk font metrics}}
    set world [_number [dict get $facts world_size]]
    if {$world<1 || $world>1200 || [dict get $facts anchor] ni {n ne e se s sw w nw center}} {_fail {Invalid original native font size/anchor}}
    set receipt [dict get $facts glyph_receipt];_record $receipt {offset width height renderer}
    if {[llength [dict get $receipt offset]]!=2} {_fail {Original glyph offset requires2integers}}
    foreach n [dict get $receipt offset] {_int $n}
    if {[dict get $receipt renderer] ne {Native2D.TkGlyph.CairoRGBA}} {_fail {Expected original Native/Tk glyph owner}}
    set glyph [dict get $object text_glyph]
    _record $glyph {resource input_alias width height matrix coverage_stage}
    if {[dict get $glyph coverage_stage] ne {original_native_tk_glyph_alpha8_v1}} {_fail {Unknown original glyph coverage stage}}
    foreach key {width height} {
        set n [_int [dict get $glyph $key]];_int [dict get $receipt $key]
        if {$n<1 || $n>16384 || $n!=[dict get $receipt $key]} {_fail {Original glyph Resource/receipt dimensions differ} ASSOCIATION}
    }
    if {wide([dict get $glyph width])*wide([dict get $glyph height])>16000000} {_fail {Original glyph exceeds16MP} CAPACITY}
    _vector [dict get $glyph matrix] 6
    set alias [dict get $glyph input_alias]
    if {![regexp {^image[1-9][0-9]*$} $alias] || ![dict exists $resources $alias]} {_fail {Text glyph has no original materialized Resource alias} ASSOCIATION}
    _sameResource [dict get $glyph resource] [dict get $resources $alias]
    set meta [dict get $glyph resource metadata];_map $meta
    foreach {key expected} {format png media_type image/png encoding png-alpha8 role native_tk_glyph_alpha source_kind native_tk_glyph} {
        if {![dict exists $meta $key] || [dict get $meta $key] ne $expected} {_fail "Original glyph Resource metadata differs: $key" ASSOCIATION}
    }
    foreach key {width height} {if {![dict exists $meta $key] || [dict get $meta $key]!=[dict get $glyph $key]} {_fail {Original glyph metadata extent differs} ASSOCIATION}}
    if {![dict exists $meta scientific_authority] || [_bool [dict get $meta scientific_authority]] || ![dict exists $meta disposable] || ![_bool [dict get $meta disposable]]} {_fail {Glyph Resource must retain its original presentation-only facts} ASSOCIATION}
    set ink [_glyphInk $object];_vector $ink 4;foreach n $ink {_unit $n}
    return $alias
}

proc ::GX::SII::NativeFigurePlacementV1::_marker {marker} {
    _record $marker {present visible forward interpolation fraction offset_px length_px line_width head_scale color}
    foreach key {present visible forward interpolation} {_bool [dict get $marker $key]}
    _unit [dict get $marker fraction]
    foreach key {offset_px length_px line_width head_scale} {_number [dict get $marker $key]}
    if {abs([dict get $marker offset_px])>4096 || [dict get $marker length_px]<4 || [dict get $marker length_px]>4096 ||
        [dict get $marker line_width]<=0 || [dict get $marker line_width]>64 || [dict get $marker head_scale]<=0 || [dict get $marker head_scale]>4} {_fail {Invalid original Native direction style}}
    _vector [dict get $marker color] 4;foreach n [dict get $marker color] {_unit $n}
}
proc ::GX::SII::NativeFigurePlacementV1::_markerGeometry {geometry part} {
    # Empty is the exact original kernel NOT_FOUND result, not invented geometry.
    if {$geometry eq {}} return
    set required {anchor tail tip head_left head_right fraction}
    if {!$part} {lappend required bounds}
    _record $geometry $required
    foreach key {anchor tail tip head_left head_right} {_vector [dict get $geometry $key] 2}
    _unit [dict get $geometry fraction]
    if {!$part} {_vector [dict get $geometry bounds] 4}
}
proc ::GX::SII::NativeFigurePlacementV1::_definition {definition {part 0}} {
    _record $definition {family controls matrix radius_x radius_y rotation angle_start angle_sweep} {parts nodes closed tolerance tangents segments part_identity_counter}
    set family [dict get $definition family]
    if {$family ni {point line construction_line polyline rectangle circle arc ellipse quadratic_bezier cubic_bezier spline path composite_path compound}} {_fail {Unknown original retained sketch family}}
    _vector [dict get $definition matrix] 6
    foreach key {radius_x radius_y rotation angle_start angle_sweep} {_number [dict get $definition $key]}
    set controls [dict get $definition controls];set count [llength $controls]
    foreach p $controls {_vector $p 2}
    if {$family in {composite_path compound}} {
        if {$part || $count} {_fail {Native compositions must contain flat exact primitives}}
        foreach key {parts closed tolerance part_identity_counter} {if {![dict exists $definition $key]} {_fail "Missing original composition '$key'"}}
        _bool [dict get $definition closed]
        if {$family eq {compound} && [_bool [dict get $definition closed]]} {_fail {Original unordered compound has no closed global traversal}}
        if {[_number [dict get $definition tolerance]]<0} {_fail {Invalid original join tolerance}}
        set rows [dict get $definition parts]
        if {[llength $rows]<1 || [llength $rows]>256} {_fail {Original composition needs1..256 parts}}
        set ids {};set total 0;set maximum 0
        foreach row $rows {
            _record $row {definition reversed part_id direction};_bool [dict get $row reversed]
            set id [_int [dict get $row part_id]]
            if {$id<1 || [dict exists $ids $id]} {_fail {Duplicate/invalid original constituent identity}}
            dict set ids $id 1;set maximum [expr {max($maximum,$id)}]
            _marker [dict get $row direction]
            set leaf [dict get $row definition]
            if {[dict get $leaf family] in {point construction_line}} {_fail {Original composition cannot contain point/construction parts}}
            incr total [_definition $leaf 1]
        }
        if {$total>65536} {_fail {Original composition exceeds65536 defining controls} CAPACITY}
        if {[_int [dict get $definition part_identity_counter]]<$maximum} {_fail {Original constituent counter precedes its identities}}
        if {[dict exists $definition nodes]} {
            set nodes [dict get $definition nodes]
            if {![llength $nodes] || [llength $nodes]>65536} {_fail {Invalid original retained node count}}
            set i 0;foreach node $nodes {if {[_int $node]<0 || $node>$i} {_fail {Invalid original node reference}};incr i}
        }
        return $total
    }
    if {$count<1 || $count>65536} {_fail {Original primitive needs1..65536 defining controls}}
    foreach key {parts nodes tolerance part_identity_counter} {if {[dict exists $definition $key]} {_fail {Primitive contains composition-only fields}}}
    switch -- $family {
        point {set expected 1}
        line - construction_line - rectangle {set expected 2}
        circle - arc - ellipse {set expected 1}
        quadratic_bezier {set expected 3}
        cubic_bezier {set expected 4}
        default {set expected 0;if {$count<2} {_fail {Original retained path needs at least2 controls}}}
    }
    if {$expected && $count!=$expected} {_fail {Original retained primitive control count differs}}
    if {$family in {line construction_line} && [lindex $controls 0] eq [lindex $controls 1]} {_fail {Original line needs distinct controls}}
    if {$family eq {rectangle}} {
        lassign [lindex $controls 0] ax ay;lassign [lindex $controls 1] bx by
        if {$ax==$bx || $ay==$by} {_fail {Original rectangle needs nonzero sides}}
    }
    if {$family in {circle arc ellipse} && [dict get $definition radius_x]<=0} {_fail {Original circle/arc/ellipse radius must be positive}}
    if {$family eq {ellipse} && [dict get $definition radius_y]<=0} {_fail {Original ellipse radius must be positive}}
    if {$family eq {arc} && ([dict get $definition angle_sweep]==0 || abs([dict get $definition angle_sweep])>2*acos(-1))} {_fail {Invalid original arc sweep}}
    if {[dict exists $definition tangents]} {
        set tangents [dict get $definition tangents]
        if {$family ne {spline} || [llength $tangents]!=$count} {_fail {Original spline needs one tangent state per knot}}
        set i 0
        foreach row $tangents {
            if {[llength $row]!=3} {_fail {Invalid original spline tangent record}}
            set flags [_int [lindex $row 0]]
            if {$flags<0 || $flags>3 || ($i==0 && ($flags&1)) || ($i==$count-1 && ($flags&2))} {_fail {Invalid original spline tangent flags}}
            _vector [lindex $row 1] 2;_vector [lindex $row 2] 2;incr i
        }
    }
    if {$family eq {path}} {
        foreach key {closed segments} {if {![dict exists $definition $key]} {_fail "Missing original path '$key'"}}
        set closed [_bool [dict get $definition closed]]
        if {$closed && $count<3} {_fail {Closed original path needs3 controls}}
        set edges [dict get $definition segments]
        if {[llength $edges]!=$count-1+$closed} {_fail {Original path edge count differs}}
        set i 0
        foreach edge $edges {
            _record $edge {family first last}
            if {[dict get $edge family] ne {line} || [_int [dict get $edge first]]!=$i || [_int [dict get $edge last]]!=($i+1)%$count} {_fail {Original path edge association differs}}
            incr i
        }
    } elseif {[dict exists $definition closed] || [dict exists $definition segments]} {_fail {Nonpath primitive contains path-only fields}}
    return $count
}
proc ::GX::SII::NativeFigurePlacementV1::_sameMarker {left right} {
    foreach key {present visible forward interpolation} {if {[_bool [dict get $left $key]]!=[_bool [dict get $right $key]]} {_fail {Original constituent direction alias differs} ASSOCIATION}}
    foreach key {fraction offset_px length_px line_width head_scale} {if {[dict get $left $key]!=[dict get $right $key]} {_fail {Original constituent direction alias differs} ASSOCIATION}}
    foreach a [dict get $left color] b [dict get $right color] {if {$a!=$b} {_fail {Original constituent ink alias differs} ASSOCIATION}}
}
proc ::GX::SII::NativeFigurePlacementV1::_sampling {object} {
    set sample [dict get $object native_sampling]
    _record $sample {native_kind method budget sample_markers skip_path draw_line draw_symbols marker radius_px line_width_px geometry}
    set kind [dict get $sample native_kind]
    if {$kind ni {curve point_set point} || $kind ne [dict get $object native_kind]} {_fail {Original sampled native kind differs} ASSOCIATION}
    set method [expr {$kind eq {curve}?{render_curve_lod}:{render_lod}}]
    if {[dict get $sample method] ne $method || [_int [dict get $sample budget]]!=4096} {_fail {Sampling differs from original CanvasPresent method/budget} ASSOCIATION}
    foreach key {sample_markers skip_path draw_line draw_symbols} {_bool [dict get $sample $key]}
    set marker [_int [dict get $sample marker]]
    if {$marker ni {0 1 2 3} || $marker!=[dict get $object style marker] || [_number [dict get $sample radius_px]]!=3 || [_number [dict get $sample line_width_px]]!=1} {_fail {Original sampled symbol facts differ} ASSOCIATION}
    set skip [_bool [dict get $sample skip_path]]
    set symbols [expr {!$skip && ($kind ne {curve} || ([_bool [dict get $sample sample_markers]] && $marker!=0))}]
    if {[_bool [dict get $sample draw_line]]!=(!$skip && $kind eq {curve}) || [_bool [dict get $sample draw_symbols]]!=$symbols} {_fail {Original sampled paint flags are inconsistent} ASSOCIATION}
    set geometry [dict get $sample geometry];_record $geometry {points point_indices breaks}
    set points [dict get $geometry points];set count [llength $points]
    if {$count>[dict get $sample budget] || [llength [dict get $geometry point_indices]]!=$count} {_fail {Original sampled point/index count differs} ASSOCIATION}
    foreach point $points {_vector $point 2}
    foreach index [dict get $geometry point_indices] {if {[_int $index]<0} {_fail {Original sampled index must be nonnegative}}}
    set previous -1
    foreach cut [dict get $geometry breaks] {
        if {[_int $cut]<0 || $cut<=$previous || $cut>=$count-1} {_fail {Original sampled cuts must be ordered inclusive ends before next segment}}
        set previous $cut
    }
    return $sample
}
proc ::GX::SII::NativeFigurePlacementV1::_validateVector {object frame} {
    set d [dict get $object definition];set raw [expr {$d eq {}}];set sample {}
    if {[dict exists $object native_sampling]} {set sample [_sampling $object]}
    if {$raw} {
        if {$sample eq {}} {return {Original raw geometry capture is unfinished}}
        set family {}
    } else {_definition $d;set family [dict get $d family]}
    set marker [dict get $object direction_marker];_marker $marker
    if {[dict get $object style line_style] ni {0 1 2} || [dict get $object style marker] ni {0 1 2 3}} {_fail {Unknown original Native dash/point marker}}
    if {$family in {composite_path compound}} {
        foreach key {composition_states part_marker_geometry} {if {![dict exists $object $key]} {return "Original '$key' capture is unfinished"}}
        set states [dict get $object composition_states];set parts [dict get $d parts]
        if {[llength $states]!=[llength $parts]} {_fail {Original constituent state count differs} ASSOCIATION}
        set expected {};set i 0
        foreach state $states row $parts {
            _record $state {part_id ordinal direction};_marker [dict get $state direction]
            if {[_int [dict get $state ordinal]]!=$i || [_int [dict get $state part_id]]!=[dict get $row part_id]} {_fail {Original constituent state identity/order differs} ASSOCIATION}
            _sameMarker [dict get $state direction] [dict get $row direction]
            if {($sample eq {} || ![_bool [dict get $sample skip_path]]) && [_bool [dict get $state direction present]] && [_bool [dict get $state direction visible]]} {dict set expected [dict get $state part_id] $i}
            incr i
        }
        set seen {}
        foreach row [dict get $object part_marker_geometry] {
            _record $row {part_id ordinal geometry};set id [_int [dict get $row part_id]]
            if {![dict exists $expected $id] || [dict exists $seen $id] || [_int [dict get $row ordinal]]!=[dict get $expected $id]} {_fail {Original painted constituent arrow association differs} ASSOCIATION}
            dict set seen $id 1;_markerGeometry [dict get $row geometry] 1
        }
        if {[lsort [dict keys $seen]] ne [lsort [dict keys $expected]]} {_fail {Original painted constituent arrow coverage differs} ASSOCIATION}
        if {[dict exists $object marker_geometry] && [dict get $object marker_geometry] ne {}} {_fail {Original composite global marker is not separately painted} ASSOCIATION}
    } else {
        foreach key {composition_states part_marker_geometry} {if {[dict exists $object $key]} {_fail {Noncomposite contains constituent-only fields}}}
        if {[_bool [dict get $marker present]] && [_bool [dict get $marker visible]] && [dict get $object native_kind] eq {curve}} {
            if {[dict exists $object marker_geometry]} {_markerGeometry [dict get $object marker_geometry] 0} elseif {$sample eq {} || ![_bool [dict get $sample skip_path]]} {return {Original direction geometry capture is unfinished}}
        } elseif {[dict exists $object marker_geometry] && [dict get $object marker_geometry] ne {}} {_fail {Nonpainting original direction contains painted geometry} ASSOCIATION}
    }
    if {[dict exists $object canvas_metadata]} {
        _map [dict get $object canvas_metadata]
        if {[dict exists $object canvas_metadata fill]} {_vector [dict get $object canvas_metadata fill] 4;foreach n [dict get $object canvas_metadata fill] {_unit $n}}
    }
    if {!$raw && $family ne {construction_line} && ![dict exists $frame world_to_frame]} {return {Original world-to-frame inverse capture is unfinished}}
    if {$family eq {construction_line}} {
        if {$sample eq {}} {return {Original clipped construction-line geometry capture is unfinished}}
        if {[llength [dict get $sample geometry points]] ni {0 2} || [dict get $sample geometry breaks] ne {}} {_fail {Original construction clip must retain zero or two exact endpoints} ASSOCIATION}
    }
    if {[dict get $object native_kind] eq {curve} && [dict get $object style marker]!=0 && $sample eq {}} {return {Original sampled curve point-marker geometry capture is unfinished}}
    return {}
}

proc ::GX::SII::NativeFigurePlacementV1::validate {capture inputFacts outputSpec} {
    _record $capture {projection resources canonical_sources}
    _record $inputFacts {resources canonical_sources}
    _record $outputSpec {format}
    if {[dict get $outputSpec format] ni {png16 tiff16 tiff32f}} {_fail {Unknown original scientific figure output format}}
    set p [dict get $capture projection]
    _record $p {schema document_guard canvas_id sequence snapshot_sha256 settings frame background layers groups objects}
    if {[dict get $p schema] ne {gxtxt.sii.native_canvas_projection.v1}} {_fail {Unknown private Canvas projection schema}}
    if {[string bytelength $p]>8388608} {_fail {Projection exceeds existing8MiB transport; original owner adaptation is required} CAPACITY}
    _record [dict get $p document_guard] {document_id generation revision sha256}
    foreach key {document_id generation} {_text [dict get $p document_guard $key]}
    if {[_int [dict get $p document_guard revision]]<0 || [_int [dict get $p sequence]]<0} {_fail {Invalid original Document revision/sequence}}
    _sha [dict get $p document_guard sha256];_sha [dict get $p snapshot_sha256];_text [dict get $p canvas_id]
    _vector [dict get $p background] 4
    foreach component [dict get $p background] {_unit $component}
    set settings [dict get $p settings];set frame [dict get $p frame]
    set documentFrame [expr {[dict exists $frame kind] && [dict get $frame kind] eq {native_document_extent}}]
    if {$documentFrame} {
        _record $settings {width height}
        _record $frame {kind canvas_id extent width height world_to_frame matrix_convention}
        if {[dict get $frame canvas_id] ne [dict get $p canvas_id] || [llength [dict get $frame extent]]!=2} {_fail {Actual Document extent/Canvas association differs} ASSOCIATION}
        set i 0
        foreach key {width height} {
            set value [_int [dict get $settings $key]]
            if {$value<1 || $value>16384 || $value!=[_int [dict get $frame $key]] || $value!=[_int [lindex [dict get $frame extent] $i]]} {_fail {Document frame differs from original CORE extent} ASSOCIATION}
            incr i
        }
        if {wide([dict get $settings width])*wide([dict get $settings height])>16777216} {_fail {Document extent exceeds original CORE16777216pixels} CAPACITY}
    } else {
    _record $settings {width height margin gutter layout background}
    foreach key {width height} {
        set v [_int [dict get $settings $key]]
        if {$v<120 || $v>12000} {_fail {Original figure dimensions must be120..12000}}
    }
    if {wide([dict get $settings width])*wide([dict get $settings height])>80000000} {_fail {Original figure exceeds80MP} CAPACITY}
    foreach key {margin gutter} {set v [_int [dict get $settings $key]];if {$v<0 || $v>1000} {_fail {Invalid original figure spacing}}}
    if {[dict get $settings layout] ni {horizontal vertical grid} || ![regexp {^#[0-9a-fA-F]{6}$} [dict get $settings background]]} {_fail {Invalid original figure layout/background}}
    _record $frame {object layer geometry image_resource width height matrix_convention} {world_to_frame}
    _text [dict get $frame object];_text [dict get $frame layer]
    _resource [dict get $frame geometry];_resource [dict get $frame image_resource]
    foreach key {width height} {if {[_int [dict get $frame $key]]!=[dict get $settings $key]} {_fail {Frame intrinsic dimensions differ from output settings} ASSOCIATION}}
    }
    if {[dict exists $frame world_to_frame]} {_vector [dict get $frame world_to_frame] 6}
    if {[dict get $frame matrix_convention] ne {native_source_topdown_to_frame_topdown_v1}} {_fail {Expected source-defined topdown image mapping; legacy bottomup matrices are not interchangeable}}
    set resources [dict get $capture resources];set canonical [dict get $capture canonical_sources]
    _map $resources;_map $canonical
    _map [dict get $inputFacts resources];_map [dict get $inputFacts canonical_sources]
    # This private whole-Document route is sealed by ROOT's actual GUI binder.
    # The public SII preparation's16alias bound does not limit Native leaves.
    if {[dict size $resources]>4000} {_fail {Current Resource inputs exceed original4000 Native identity admission} CAPACITY}
    foreach key {resources canonical_sources} {
        if {[lsort [dict keys [dict get $capture $key]]] ne [lsort [dict keys [dict get $inputFacts $key]]]} {_fail "Prepared/captured $key membership differs" ASSOCIATION}
    }
    dict for {alias ref} $resources {
        if {![regexp {^image[1-9][0-9]*$} $alias]} {_fail {Invalid original Resource input alias}}
        _sameResource $ref [dict get $inputFacts resources $alias]
    }
    dict for {id origin} $canonical {
        _origin $origin;_origin [dict get $inputFacts canonical_sources $id]
        if {$id ne [dict get $origin dataset_id]} {_fail {Canonical provenance key differs from Dataset identity} ASSOCIATION}
        foreach key {dataset_id source_sha256 source_revision} {
            if {[dict get $origin $key] ne [dict get $inputFacts canonical_sources $id $key]} {_fail {Canonical source guard changed} ASSOCIATION}
        }
    }
    set layers {};set groups {};set identities {};set previous {};set first 1
    foreach layer [dict get $p layers] {
        _record $layer {logical_id paint_order properties blend}
        set id [_text [dict get $layer logical_id]]
        if {[dict exists $identities $id]} {_fail {Duplicate native identity}}
        dict set identities $id layer
        set order [_int [dict get $layer paint_order]]
        if {!$first && $order<=$previous} {_fail {Layer paint order is not the actual deterministic sequence}}
        set first 0;set previous $order
        set props [dict get $layer properties];_record $props {visible selectable locked order opacity}
        foreach key {visible selectable locked} {_bool [dict get $props $key]}
        _int [dict get $props order];_unit [dict get $props opacity]
        if {[dict get $layer blend] ni {Over Multiply Screen Overlay SoftLight}} {_fail {Unknown native Canvas layer blend}}
        dict set layers $id $layer
    }
    if {!$documentFrame && ![dict exists $layers [dict get $frame layer]]} {_fail {Coordinate frame layer is missing}}
    foreach group [dict get $p groups] {
        _record $group {logical_id layer members style}
        set id [_text [dict get $group logical_id]]
        if {[dict exists $identities $id] || ![dict exists $layers [dict get $group layer]]} {_fail {Duplicate/missing native group identity or layer}}
        dict set identities $id group;_style [dict get $group style]
        if {[llength [dict get $group members]]!=[llength [lsort -unique [dict get $group members]]]} {_fail {Duplicate native group member}}
        dict set groups $id $group
    }
    set objects {};set byLayer {};set groupMembers {};set aliases {};set unfinished {};set frameSeen 0
    foreach object [dict get $p objects] {
        set common {object layer group paint_order geometry style native_kind disposition reason}
        _map $object
        foreach key $common {if {![dict exists $object $key]} {_fail "Missing native object field '$key'"}}
        set id [_text [dict get $object object]];set layer [dict get $object layer];set group [dict get $object group]
        if {[dict exists $identities $id] || ![dict exists $layers $layer]} {_fail {Duplicate/missing native leaf identity or layer}}
        dict set identities $id object;_resource [dict get $object geometry];_style [dict get $object style]
        _text [dict get $object native_kind];set order [_int [dict get $object paint_order]]
        if {[dict exists $byLayer $layer] && [llength [dict get $byLayer $layer]]} {
            set last [lindex [dict get $byLayer $layer] end]
            if {$order<=[dict get $objects $last paint_order]} {_fail {Object paint order is not the actual native sequence}}
        }
        dict lappend byLayer $layer $id
        if {$group ne {}} {
            if {![dict exists $groups $group] || [dict get $groups $group layer] ne $layer} {_fail {Native group/member layers differ}}
            dict lappend groupMembers $group $id
        }
        set disposition [dict get $object disposition]
        switch -- $disposition {
            paint_image {
                _record $object [concat $common {image_resource width height matrix image_state pixel_stage input_alias canonical_source_ids}] {canonical_origin accepted_recipe}
                if {[dict get $object reason] ne {} || [dict get $object pixel_stage] ne {current_resource_already_realized}} {_fail {Only realized current Resource image inputs are admitted}}
                _resource [dict get $object image_resource]
                if {!$documentFrame && $id eq [dict get $frame object]} {
                    if {$layer ne [dict get $frame layer] || ![_visible $object $layers $groups]} {_fail {Painted coordinate frame differs from actual effective visibility/layer} ASSOCIATION}
                    _sameResource [dict get $object geometry] [dict get $frame geometry]
                    _sameResource [dict get $object image_resource] [dict get $frame image_resource]
                    foreach key {width height} {if {[dict get $object $key]!=[dict get $frame $key]} {_fail {Painted coordinate frame extent differs} ASSOCIATION}}
                    incr frameSeen
                }
                set alias [dict get $object input_alias]
                if {![dict exists $resources $alias]} {_fail {Painted image has no captured Resource input} ASSOCIATION}
                _sameResource [dict get $object image_resource] [dict get $resources $alias]
                if {[dict exists $aliases $alias] && [dict get $aliases $alias] ne {image}} {_fail {A glyph Resource role cannot become a scientific image} ASSOCIATION}
                dict set aliases $alias image
                foreach key {width height} {if {[_int [dict get $object $key]]<=0} {_fail {Invalid source image dimensions}}}
                if {wide([dict get $object width])*wide([dict get $object height])>100000000} {_fail {Source exceeds original100MP admission; owner adaptation required} CAPACITY}
                _vector [dict get $object matrix] 6;_imageState [dict get $object image_state] [dict get $object style]
                set sourceIds [dict get $object canonical_source_ids]
                if {![llength $sourceIds]} {_fail "Image '$id' needs its original verified canonical sources; satisfy the original import-source prerequisite" PREREQUISITE}
                if {[llength $sourceIds]!=[llength [lsort -unique $sourceIds]]} {_fail {Duplicate per-image canonical source identity} ASSOCIATION}
                foreach source $sourceIds {
                    _text $source
                    if {![dict exists $canonical $source]} {_fail "Image '$id' has no original guard for canonical source '$source'" ASSOCIATION}
                }
                if {[dict exists $object canonical_origin]} {
                    set origin [dict get $object canonical_origin];_origin $origin;set source [dict get $origin dataset_id]
                    if {[llength $sourceIds]!=1 || $source ne [lindex $sourceIds 0]} {_fail {Singular canonical_origin does not describe this image's actual lineage} ASSOCIATION}
                    if {![dict exists $canonical $source]} {_fail {Canonical image origin is missing from original guards} ASSOCIATION}
                    foreach key {dataset_id source_sha256 source_revision} {if {[dict get $origin $key] ne [dict get $canonical $source $key]} {_fail {Image canonical origin differs from its guard} ASSOCIATION}}
                }
                # accepted_recipe is the original workspaceStep value, already
                # codec-validated by ROOT. Preserve it; NEVER replay its steps.
            }
            invisible - coordinate_frame {
                _record $object $common
                if {[dict get $object reason] eq {}} {_fail {A nonpainting object needs its actual native reason}}
                if {$disposition eq {coordinate_frame}} {
                    if {$documentFrame} {_fail {Actual Document extent must not invent a coordinate-frame leaf} ASSOCIATION}
                    if {$id ne [dict get $frame object] || $layer ne [dict get $frame layer] || [_visible $object $layers $groups]} {_fail {Nonpainting coordinate frame differs from effectively hidden native frame}}
                    _sameResource [dict get $object geometry] [dict get $frame geometry];incr frameSeen
                } else {
                    set hidden [expr {![_visible $object $layers $groups]}]
                    if {!$hidden} {_fail "Visible native leaf '$id' cannot be silenced by a reason string" ASSOCIATION}
                }
            }
            paint_annotation {
                _record $object [concat $common {definition direction_marker}] {canvas_metadata marker_geometry font_facts text_glyph composition_states part_marker_geometry native_sampling}
                if {[_isText $object]} {
                    if {[dict get $object reason] ne {}} {_fail {Painted text cannot carry an unfinished reason}}
                    set alias [_validateGlyph $object $resources]
                    if {[dict exists $aliases $alias] && [dict get $aliases $alias] ne {glyph}} {_fail {An image Resource role cannot become a presentation glyph} ASSOCIATION}
                    dict set aliases $alias glyph
                } else {
                    if {[dict exists $object text_glyph] || [dict exists $object font_facts]} {_fail {Original glyph/font facts require actual native text metadata} ASSOCIATION}
                    if {[dict get $object reason] ne {}} {_fail {Painted vector cannot carry an unfinished reason}}
                    set pending [_validateVector $object $frame]
                    if {$pending ne {}} {dict set unfinished $id $pending}
                }
            }
            unimplemented {
                _record $object $common
                if {[dict get $object reason] eq {}} {_fail {Unimplemented native object needs its actual owner reason}}
                dict set unfinished $id [dict get $object reason]
            }
            default {_fail "Unknown native object disposition '$disposition'"}
        }
        dict set objects $id $object
    }
    if {[dict size $identities]>4000} {_fail {Projection exceeds original4000 native identities; owner adaptation required} CAPACITY}
    if {$frameSeen!=(!$documentFrame)} {_fail {Complete native coverage differs from its actual frame authority}}
    if {[lsort [dict keys $aliases]] ne [lsort [dict keys $resources]]} {_fail {Input Resources do not exactly match painted image aliases} ASSOCIATION}
    dict for {id group} $groups {
        set actual [expr {[dict exists $groupMembers $id]?[dict get $groupMembers $id]:{}}]
        # Native paint order comes from descriptor z/insertion, not the group's
        # membership array. Preserve that array; compare membership as a set.
        if {[lsort $actual] ne [lsort [dict get $group members]]} {_fail {Native group membership differs from captured leaves}}
        set layer [dict get $group layer]
        set rows [expr {[dict exists $byLayer $layer]?[dict get $byLayer $layer]:{}}];set ended 0;set started 0
        foreach leaf $rows {
            if {[dict get $objects $leaf group] eq $id} {if {$ended} {_fail {Native flat group members are not contiguous}};set started 1} elseif {$started} {set ended 1}
        }
    }
    return [dict create schema gxtxt.sii.native_figure_plan.v1 capture $capture inputFacts $inputFacts outputSpec $outputSpec layers $layers groups $groups objects $objects byLayer $byLayer unfinished $unfinished]
}

proc ::GX::SII::NativeFigurePlacementV1::_im {arguments} {
    # All callers below construct fixed argument lists from validated facts.
    return [::GX::SII::run [list [::GX::SII::magickPath] {*}[::GX::SII::limits] {*}$arguments] 35000]
}
proc ::GX::SII::NativeFigurePlacementV1::_temporary {trackedName} {
    upvar 1 $trackedName tracked
    set p [::GX::SII::tempFile .miff];lappend tracked $p;return $p
}
proc ::GX::SII::NativeFigurePlacementV1::_blank {size color trackedName} {
    upvar 1 $trackedName tracked
    set p [_temporary tracked]
    _im [list -size $size xc:$color -define quantum:format=floating-point -depth 32 MIFF:$p]
    return $p
}
proc ::GX::SII::NativeFigurePlacementV1::_rgba {color} {
    # Actual normalized native RGBA, not the editor's quantized hex setting.
    # Every operand is validated numeric; no user color/MVG/option text enters.
    set rgb {}
    foreach v [lrange $color 0 2] {lappend rgb "[format %.17g [expr {$v*100.0}]]%"}
    return "rgba([join $rgb ,],[format %.17g [lindex $color 3]])"
}
proc ::GX::SII::NativeFigurePlacementV1::_transparentBlack {color} {
    foreach value $color {
        # A hidden color or negative zero is not the code-created empty pixel.
        if {$value!=0 || [string index [format %.17g [expr {double($value)}]] 0] eq {-}} {return 0}
    }
    return 1
}
proc ::GX::SII::NativeFigurePlacementV1::_compose {bottom top opacity blend trackedName {emptyName {}}} {
    upvar 1 $trackedName tracked
    if {$emptyName ne {}} {
        upvar 1 $emptyName empty
        set topEmpty [expr {[dict exists $empty $top] && [dict get $empty $top]}]
        set bottomEmpty [expr {[dict exists $empty $bottom] && [dict get $empty $bottom]}]
        # These are code-proven absent contributions, never alpha heuristics.
        if {$topEmpty || $opacity==0} {
            if {$top ne $bottom} {catch {file delete -- $top};if {[dict exists $empty $top]} {dict unset empty $top}}
            return $bottom
        }
        if {$bottomEmpty && $opacity==1 && $blend eq {Over}} {
            if {$top ne $bottom} {catch {file delete -- $bottom};if {[dict exists $empty $bottom]} {dict unset empty $bottom}}
            return $top
        }
    }
    set p [_temporary tracked]
    set arguments {}
    if {$blend eq {Over}} {lappend arguments -define compose:clamp=false}
    lappend arguments MIFF:$bottom
    # Empty-surface reuse can leave a Gray destination. Expand its neutral
    # components before adding RGB ink; otherwise IM discards colored ink.
    # Tag only Gray channels: no gamma conversion or HDRI sample arithmetic.
    if {[dict get [::GX::SII::inspectFile $bottom] colorspace] in {Gray LinearGray}} {
        lappend arguments -set colorspace sRGB
    }
    lappend arguments ( MIFF:$top -alpha on
    if {$opacity!=1} {lappend arguments -channel A -evaluate multiply [format %.17g $opacity]}
    # Restore the full channel mask even when the unit multiply was omitted.
    lappend arguments +channel ) -compose $blend -composite -define quantum:format=floating-point -depth 32 MIFF:$p
    _im $arguments
    # Only private intermediates are consumed here. Bound live scratch to the
    # active canvas/layer/group/object chain instead of retaining every image.
    foreach old [list $bottom $top] {
        catch {file delete -- $old}
        if {$emptyName ne {} && [dict exists $empty $old]} {dict unset empty $old}
    }
    if {$emptyName ne {}} {dict set empty $p 0}
    return $p
}
proc ::GX::SII::NativeFigurePlacementV1::_ordinary {path directory} {
    if {[file pathtype $path] ne {absolute} || [file normalize $path] ne $path} {_fail {Managed file role must be an absolute canonical path}}
    set probe {}
    foreach part [file split $path] {set probe [file join $probe $part];if {[file exists $probe] && [file type $probe] eq {link}} {_fail {Managed file role cannot contain symlinks}}}
    if {$directory} {if {![file isdirectory $path]} {_fail {Original Job output directory is missing}}} elseif {![file isfile $path] || [file type $path] ne {file}} {_fail {Original materialized input role is missing/nonordinary}}
}
proc ::GX::SII::NativeFigurePlacementV1::_latticePlacement {object size} {
    lassign [dict get $object matrix] a b c d tx ty
    if {$a!=1 || $b!=0 || $c!=0 || $d!=1 || $tx!=floor($tx) || $ty!=floor($ty)} {return {}}
    # Finite integral doubles may exceed a machine integer. Decimal bignums
    # let an entirely outside image be clipped without overflow or a new cap.
    set tx [format %.0f $tx];set ty [format %.0f $ty]
    lassign [split $size x] width height
    set sourceWidth [dict get $object width];set sourceHeight [dict get $object height]
    set left [expr {max(0,$tx)}];set top [expr {max(0,$ty)}]
    set right [expr {min($width,$tx+$sourceWidth)}];set bottom [expr {min($height,$ty+$sourceHeight)}]
    if {$left>=$right || $top>=$bottom} {return [dict create empty 1]}
    return [dict create empty 0 crop [list [expr {$left-$tx}] [expr {$top-$ty}] [expr {$right-$left}] [expr {$bottom-$top}]] \
        padding [list $left $top [expr {$width-$right}] [expr {$height-$bottom}]]]
}
proc ::GX::SII::NativeFigurePlacementV1::_paintImage {object input size trackedName {emptyName {}}} {
    upvar 1 $trackedName tracked
    set p [_temporary tracked];set coefficients {}
    set placement [_latticePlacement $object $size]
    if {$placement ne {}} {
        set isEmpty [dict get $placement empty]
        if {$isEmpty} {
            _im [list -size $size xc:none -define quantum:format=floating-point -depth 32 MIFF:$p]
        } else {
            # Intrinsic pixel coordinates precede crop. All channels are copied;
            # a persisted MIFF operation mask must not omit a scalar channel.
            set arguments [list [::GX::SII::frame0 $input] -alpha on +channel -background none +repage -gravity NorthWest]
            lassign [dict get $placement crop] x y width height
            if {$x!=0 || $y!=0 || $width!=[dict get $object width] || $height!=[dict get $object height]} {
                lappend arguments -crop ${width}x${height}+${x}+${y} +repage
            }
            lassign [dict get $placement padding] left top right bottom
            if {$left!=0 || $top!=0} {lappend arguments -splice ${left}x${top}+0+0}
            if {$right!=0 || $bottom!=0} {
                set x [expr {$left+$width}];set y [expr {$top+$height}]
                lappend arguments -splice ${right}x${bottom}+${x}+${y}
            }
            lappend arguments +repage -define quantum:format=floating-point -depth 32 MIFF:$p
            _im $arguments
        }
        if {$emptyName ne {}} {upvar 1 $emptyName empty;dict set empty $p $isEmpty}
        return $p
    }
    foreach n [dict get $object matrix] {lappend coefficients [format %.17g $n]}
    # Package102 supplies SOURCE TOPDOWN -> FRAME TOPDOWN. No extra flip,
    # legacy placement boxes, preview byte path or recipe reapplication.
    _im [list [::GX::SII::frame0 $input] -alpha on -virtual-pixel transparent -background none -define distort:viewport=${size}+0+0 -distort AffineProjection [join $coefficients ,] +repage -define quantum:format=floating-point -depth 32 MIFF:$p]
    if {$emptyName ne {}} {upvar 1 $emptyName empty;dict set empty $p 0}
    return $p
}
proc ::GX::SII::NativeFigurePlacementV1::_multiply {m n} {
    lassign $m a b c d e f;lassign $n g h i j k l
    set result [list [expr {$a*$g+$b*$i}] [expr {$a*$h+$b*$j}] [expr {$c*$g+$d*$i}] [expr {$c*$h+$d*$j}] [expr {$a*$k+$b*$l+$e}] [expr {$c*$k+$d*$l+$f}]]
    _vector $result 6;return $result
}
proc ::GX::SII::NativeFigurePlacementV1::_point {matrix point {linear 0}} {
    lassign $matrix a b c d e f;lassign $point x y
    if {$linear} {set e 0;set f 0}
    set result [list [expr {$a*$x+$b*$y+$e}] [expr {$c*$x+$d*$y+$f}]]
    _vector $result 2;return $result
}
proc ::GX::SII::NativeFigurePlacementV1::_command {kind points} {
    set result [list $kind]
    foreach p $points {foreach n $p {lappend result [format %.17g [_number $n]]}}
    return $result
}
proc ::GX::SII::NativeFigurePlacementV1::_polyline {points} {
    set commands [list [_command M [list [lindex $points 0]]]]
    foreach p [lrange $points 1 end] {lappend commands [_command L [list $p]]}
    return $commands
}
proc ::GX::SII::NativeFigurePlacementV1::_ellipsePoint {center u v angle} {
    lassign $center x y;lassign $u a b;lassign $v c d
    return [list [expr {$x+$a*cos($angle)+$c*sin($angle)}] [expr {$y+$b*cos($angle)+$d*sin($angle)}]]
}
proc ::GX::SII::NativeFigurePlacementV1::_ellipsePath {definition matrix reverse} {
    set family [dict get $definition family];set pi [expr {acos(-1)}]
    set radius [dict get $definition radius_x]
    set ry [expr {$family eq {ellipse}?[dict get $definition radius_y]:$radius}]
    set rotation [dict get $definition rotation]
    set u [_point $matrix [list [expr {$radius*cos($rotation)}] [expr {$radius*sin($rotation)}]] 1]
    set v [_point $matrix [list [expr {-$ry*sin($rotation)}] [expr {$ry*cos($rotation)}]] 1]
    set center [_point $matrix [lindex [dict get $definition controls] 0]]
    set start 0;set sweep [expr {2*$pi}]
    if {$family eq {arc}} {
        set start [expr {fmod([dict get $definition angle_start],2*$pi)}]
        if {$start>$pi} {set start [expr {$start-2*$pi}]};if {$start<-$pi} {set start [expr {$start+2*$pi}]}
        set sweep [dict get $definition angle_sweep]
        if {$reverse} {set start [expr {$start+$sweep}]}
    }
    if {$reverse} {set sweep [expr {-$sweep}]}
    lassign $u ux uy;lassign $v vx vy
    set scale [expr {max(abs($ux),abs($uy),abs($vx),abs($vy))}]
    if {$scale==0} {return [_polyline [list $center $center]]}
    set a [expr {$ux/$scale}];set b [expr {$uy/$scale}];set c [expr {$vx/$scale}];set d [expr {$vy/$scale}]
    set xx [expr {$a*$a+$c*$c}];set xy [expr {$a*$b+$c*$d}];set yy [expr {$b*$b+$d*$d}]
    set disc [expr {sqrt(($xx-$yy)*($xx-$yy)+4*$xy*$xy)}]
    set major [expr {sqrt(($xx+$yy+$disc)/2)}];set determinant [expr {$a*$d-$b*$c}]
    set minor [expr {abs($determinant)/$major}]
    if {$minor==0} {
        # An allowed singular native affine collapses an ellipse to a line.
        # Preserve exact turning locations, rather than inventing a tessellation.
        if {abs($ux)+abs($vx)>=abs($uy)+abs($vy)} {set turn [expr {atan2($vx,$ux)}]} else {set turn [expr {atan2($vy,$uy)}]}
        set low [expr {min($start,$start+$sweep)}];set high [expr {max($start,$start+$sweep)}];set ts {0 1}
        for {set k [expr {int(floor(($low-$turn)/$pi))}]} {$k<=ceil(($high-$turn)/$pi)} {incr k} {
            set t [expr {($turn+$k*$pi-$start)/$sweep}];if {$t>0 && $t<1} {lappend ts $t}
        }
        set points {};foreach t [lsort -real $ts] {lappend points [_ellipsePoint $center $u $v [expr {$start+$sweep*$t}]]}
        return [_polyline $points]
    }
    set rx [expr {$major*$scale}];set ry [expr {$minor*$scale}]
    set angle [expr {atan2(2*$xy,$xx-$yy)*90/$pi}]
    set first [_ellipsePoint $center $u $v $start];set commands [list [_command M [list $first]]]
    set steps [expr {int(ceil(abs($sweep)/$pi))}];set flag [expr {$determinant*$sweep>0}]
    for {set i 1} {$i<=$steps} {incr i} {
        if {$family ne {arc} && $i==$steps} {set end $first} else {set end [_ellipsePoint $center $u $v [expr {$start+$sweep*$i/$steps}]]}
        set command [_command A [list [list $rx $ry] [list $angle 0 $flag] $end]]
        lappend commands $command
    }
    return $commands
}
proc ::GX::SII::NativeFigurePlacementV1::_paths {definition outer size {reverse 0}} {
    set matrix [_multiply $outer [dict get $definition matrix]];set family [dict get $definition family]
    set controls [dict get $definition controls]
    if {$family in {compound composite_path}} {
        set rows [dict get $definition parts];if {$reverse} {set rows [lreverse $rows]}
        set paths {};set continuous [expr {$family eq {composite_path} && ![dict exists $definition nodes]}]
        foreach row $rows {
            set paths2 [_paths [dict get $row definition] $matrix $size [expr {[_bool [dict get $row reversed]]!=$reverse}]]
            foreach commands $paths2 {
                if {$continuous && [llength $paths]} {
                    set old [lindex $paths end];lappend old [lreplace [lindex $commands 0] 0 0 L]
                    lappend old {*}[lrange $commands 1 end];lset paths end $old
                } else {lappend paths $commands}
            }
        }
        return $paths
    }
    if {$family in {circle arc ellipse}} {return [list [_ellipsePath $definition $matrix $reverse]]}
    if {$family eq {rectangle}} {
        lassign [lindex $controls 0] ax ay;lassign [lindex $controls 1] bx by
        set r [dict get $definition rotation];set points {}
        foreach p [list [list $ax $ay] [list $bx $ay] [list $bx $by] [list $ax $by] [list $ax $ay]] {
            lassign $p x y
            lappend points [list [expr {$ax+cos($r)*($x-$ax)-sin($r)*($y-$ay)}] [expr {$ay+sin($r)*($x-$ax)+cos($r)*($y-$ay)}]]
        }
        set controls $points
    }
    if {$family eq {construction_line}} {
        # Original sketch_construction_clip chooses the exact canonical-view
        # start; extending endpoints would shift Native dash/dot phase.
        _fail {Construction lines require original canonical clipped sample geometry} UNFINISHED
    }
    if {$family eq {spline}} {
        # Exact same cubic controls as gx2d_sketch.inc sketch_spline_controls.
        set segments {};set count [llength $controls]
        for {set i 0} {$i<$count-1} {incr i} {
            set a [lindex $controls [expr {max(0,$i-1)}]];set b [lindex $controls $i];set c [lindex $controls [expr {$i+1}]];set e [lindex $controls [expr {min($count-1,$i+2)}]]
            set left {};set right {}
            foreach av $a bv $b cv $c ev $e {lappend left [expr {$bv+($cv-$av)/6.0}];lappend right [expr {$cv-($ev-$bv)/6.0}]}
            if {[dict exists $definition tangents]} {
                set t [dict get $definition tangents];set lt [lindex $t $i];set rt [lindex $t [expr {$i+1}]]
                if {[lindex $lt 0]&2} {set left {};foreach bv $b v [lindex $lt 2] {lappend left [expr {$bv+$v}]}}
                if {[lindex $rt 0]&1} {set right {};foreach cv $c v [lindex $rt 1] {lappend right [expr {$cv+$v}]}}
            }
            lappend segments [list $b $left $right $c]
        }
        if {$reverse} {set segments [lmap segment [lreverse $segments] {lreverse $segment}]}
        set commands [list [_command M [list [_point $matrix [lindex [lindex $segments 0] 0]]]]]
        foreach segment $segments {set points [lmap p [lrange $segment 1 end] {_point $matrix $p}];lappend commands [_command C $points]}
        return [list $commands]
    }
    if {$family eq {path} && [_bool [dict get $definition closed]]} {lappend controls [lindex $controls 0]}
    if {$reverse} {set controls [lreverse $controls]}
    set points [lmap p $controls {_point $matrix $p}]
    if {$family in {quadratic_bezier cubic_bezier}} {
        set kind [expr {$family eq {quadratic_bezier}?{Q}:{C}}]
        return [list [list [_command M [list [lindex $points 0]]] [_command $kind [lrange $points 1 end]]]]
    }
    return [list [_polyline $points]]
}
proc ::GX::SII::NativeFigurePlacementV1::_mvgPrimitive {commands stroke fill width {dash 0}} {
    set data "push graphic-context\nstroke-linecap butt\nstroke-linejoin round\nfill-rule nonzero\n"
    if {$stroke eq {} || $width<=0} {append data "stroke none\n"} else {append data "stroke '[_rgba $stroke]'\nstroke-width [format %.17g $width]\n"}
    if {$fill eq {}} {append data "fill none\n"} else {append data "fill '[_rgba $fill]'\n"}
    if {$dash==1} {append data "stroke-dasharray 6,3\n"} elseif {$dash==2} {append data "stroke-dasharray 1,3\n"}
    set path {};foreach command $commands {lappend path [join $command { }]}
    append data "path '[join $path { }]'\npop graphic-context\n"
    return $data
}
proc ::GX::SII::NativeFigurePlacementV1::_arrowMVG {style geometry} {
    if {$geometry eq {}} {return {}}
    set ink [dict get $style color];set width [dict get $style line_width]
    set shaft [_polyline [list [dict get $geometry tail] [dict get $geometry tip]]]
    set head [_polyline [list [dict get $geometry head_left] [dict get $geometry tip] [dict get $geometry head_right]]]
    return "[_mvgPrimitive $shaft $ink {} $width][_mvgPrimitive $head $ink {} $width]"
}
proc ::GX::SII::NativeFigurePlacementV1::_symbolsMVG {points marker ink} {
        set data {}
        foreach p $points {
            lassign $p x y
            if {$marker==3} {
                append data [_mvgPrimitive [_polyline [list [list [expr {$x-3}] $y] [list [expr {$x+3}] $y]]] $ink {} 1]
                append data [_mvgPrimitive [_polyline [list [list $x [expr {$y-3}]] [list $x [expr {$y+3}]]]] $ink {} 1]
            } elseif {$marker==2} {
                set corners [list [list [expr {$x-3}] [expr {$y-3}]] [list [expr {$x+3}] [expr {$y-3}]] [list [expr {$x+3}] [expr {$y+3}]] [list [expr {$x-3}] [expr {$y+3}]]]
                set commands [_polyline $corners];lappend commands Z;append data [_mvgPrimitive $commands $ink $ink 1]
            } else {
                set commands [list [_command M [list [list [expr {$x+3}] $y]]] [list A 3 3 0 0 1 [format %.17g [expr {$x-3}]] [format %.17g $y]] [list A 3 3 0 0 1 [format %.17g [expr {$x+3}]] [format %.17g $y]] Z]
                append data [_mvgPrimitive $commands $ink $ink 1]
            }
        }
        return $data
}
proc ::GX::SII::NativeFigurePlacementV1::_samplingLinesMVG {sample ink width dash} {
    if {![_bool [dict get $sample draw_line]]} {return {}}
    set points [dict get $sample geometry points];set start 0;set data {}
    foreach cut [concat [dict get $sample geometry breaks] [list [expr {[llength $points]-1}]]] {
        set segment [lrange $points $start $cut];set start [expr {$cut+1}]
        if {[llength $segment]>=2} {append data [_mvgPrimitive [_polyline $segment] $ink {} $width $dash]}
    }
    return $data
}
proc ::GX::SII::NativeFigurePlacementV1::_paintVector {object frame size trackedName} {
    upvar 1 $trackedName tracked
    set definition [dict get $object definition];set raw [expr {$definition eq {}}]
    set family {};if {!$raw} {set family [dict get $definition family]}
    set sample {};set skip 0
    if {[dict exists $object native_sampling]} {set sample [dict get $object native_sampling];set skip [_bool [dict get $sample skip_path]]}
    set ink [lreplace [dict get $object style color] 3 3 1];set data {}
    if {!$skip} {
        if {$raw || $family eq {construction_line}} {
            # Already canonical TOPDOWN geometry from the ORIGINAL Native
            # display/clip owner. Never reproject, substitute controls or join cuts.
            append data [_samplingLinesMVG $sample $ink [dict get $object style line_width] [dict get $object style line_style]]
        } else {
            lassign [dict get $frame world_to_frame] a b c d e f;set outer [list $a $c $b $d $e $f]
            if {[dict get $object native_kind] eq {curve}} {
                set fill {};set closed [expr {$family in {rectangle circle ellipse} || ([dict exists $definition closed] && [_bool [dict get $definition closed]])}]
                if {$closed && [dict exists $object canvas_metadata fill] && [lindex [dict get $object canvas_metadata fill] 3]>0} {set fill [dict get $object canvas_metadata fill]}
                foreach commands [_paths $definition $outer $size] {
                    if {$fill ne {}} {lappend commands Z}
                    append data [_mvgPrimitive $commands $ink $fill [dict get $object style line_width] [dict get $object style line_style]]
                }
            } elseif {$sample eq {}} {
                set matrix [_multiply $outer [dict get $definition matrix]]
                set points [lmap p [dict get $definition controls] {_point $matrix $p}]
                append data [_symbolsMVG $points [dict get $object style marker] $ink]
            }
        }
        if {$sample ne {} && [_bool [dict get $sample draw_symbols]]} {append data [_symbolsMVG [dict get $sample geometry points] [dict get $sample marker] $ink]}
    }
    if {!$skip && $family in {compound composite_path}} {
        set states [dict get $object composition_states]
        foreach row [dict get $object part_marker_geometry] {append data [_arrowMVG [dict get [lindex $states [dict get $row ordinal]] direction] [dict get $row geometry]]}
    } elseif {!$skip && [dict exists $object marker_geometry]} {append data [_arrowMVG [dict get $object direction_marker] [dict get $object marker_geometry]]}
    if {$data eq {}} {return [_blank $size none tracked]}
    set mvg [::GX::SII::tempFile .mvg];lappend tracked $mvg
    set channel [open $mvg {WRONLY CREAT EXCL}]
    try {fconfigure $channel -translation lf -encoding ascii;puts $channel $data} finally {close $channel}
    set p [_temporary tracked]
    # Fixed numeric-only internally generated MVG in an actual SII-owned file.
    # Reading the original coder avoids Linux argument limits for65536 controls;
    # no indirect @read, policy relaxation, caller MVG or alternative engine.
    _im [list -size $size -background none -depth 32 MVG:$mvg -define quantum:format=floating-point -depth 32 MIFF:$p]
    catch {file delete -- $mvg}
    return $p
}
proc ::GX::SII::NativeFigurePlacementV1::_paintGlyph {object input size trackedName} {
    upvar 1 $trackedName tracked
    set glyph [dict get $object text_glyph];set ink [_glyphInk $object]
    set color [_rgba [lreplace $ink 3 3 1]];set coefficients {}
    foreach n [dict get $glyph matrix] {lappend coefficients [format %.17g $n]}
    set p [_temporary tracked]
    # Only the authentic Native/Tk PNG ALPHA is used. Original scientific ink
    # is created at HDRI precision; no PNG RGB, text parser or IM font/layout.
    # Ink alpha belongs to this primitive; outer object alpha is applied once
    # by the same existing object/group/layer compositor as scientific images.
    _im [list -size [dict get $glyph width]x[dict get $glyph height] xc:$color \
        ( [::GX::SII::frame0 $input] -alpha extract ) -alpha off -compose CopyOpacity -composite \
        -alpha on -channel A -evaluate multiply [format %.17g [lindex $ink 3]] +channel \
        -virtual-pixel transparent -background none -define distort:viewport=${size}+0+0 \
        -distort AffineProjection [join $coefficients ,] +repage \
        -define quantum:format=floating-point -depth 32 MIFF:$p]
    return $p
}
proc ::GX::SII::NativeFigurePlacementV1::render {validatedPlan jobOwnedInputRoles jobOwnedOutputRoles} {
    _record $validatedPlan {schema capture inputFacts outputSpec layers groups objects byLayer unfinished}
    if {[dict get $validatedPlan schema] ne {gxtxt.sii.native_figure_plan.v1}} {_fail {Unknown private validated figure plan}}
    set plan [validate [dict get $validatedPlan capture] [dict get $validatedPlan inputFacts] [dict get $validatedPlan outputSpec]]
    if {[dict size [dict get $plan unfinished]]} {_fail "Native scientific coverage is unfinished: [dict get $plan unfinished]" UNFINISHED}
    # Refuse all unresolved coverage BEFORE dependencies, pixel I/O or output.
    foreach command {run magickPath magickVersion limits tempFile frame0 inspectFile previewFile} {
        if {![llength [info commands ::GX::SII::$command]]} {_fail "Original SII dependency is unavailable: $command" INTEGRATION}
    }
    if {[string first HDRI [::GX::SII::magickVersion]]<0} {_fail {Original SII scientific rendering requires its configured ImageMagick HDRI} INTEGRATION}
    if {![llength [info commands ::GX::sha256File]]} {_fail {Original CORE sha256File owner must be wired by the trusted worker} INTEGRATION}
    _record $jobOwnedOutputRoles {directory}
    set directory [dict get $jobOwnedOutputRoles directory];_ordinary $directory 1
    set resources [dict get $plan capture resources]
    if {[lsort [dict keys $jobOwnedInputRoles]] ne [lsort [dict keys $resources]]} {_fail {Managed input role membership changed} ASSOCIATION}
    dict for {alias path} $jobOwnedInputRoles {
        _ordinary $path 0;set ref [dict get $resources $alias]
        if {[file size $path]!=[dict get $ref size_bytes] || [::GX::sha256File $path] ne [dict get $ref sha256]} {_fail {Materialized actual Resource bytes changed} ASSOCIATION}
        if {[file dirname $path] eq $directory} {_fail {Input and output roles must remain separate}}
    }
    set p [dict get $plan capture projection];set settings [dict get $p settings]
    set size [dict get $settings width]x[dict get $settings height]
    set format [dict get $plan outputSpec format];set ext [expr {$format eq {png16}?{png}:{tif}}]
    set result [file join $directory result.$ext];set preview [file join $directory preview.png]
    if {[file exists $result] || [file exists $preview]} {_fail {Original Job output roles already exist}}
    set tracked {};set empty {};set published 0
    try {
        # Actual current MIFF inputs must become real SII-owned working files,
        # not foreign paths inserted into the original intermediate whitelist.
        # Copy bytes once per alias, verify them again, and account for these
        # temporaries through the existing Job/temp budget and finally cleanup.
        set workingInputs {}
        dict for {alias source} $jobOwnedInputRoles {
            set working [_temporary tracked]
            file copy -- $source $working
            set ref [dict get $resources $alias]
            if {[file size $working]!=[dict get $ref size_bytes] || [::GX::sha256File $working] ne [dict get $ref sha256]} {_fail {Owned working Resource copy differs from materialized bytes} ASSOCIATION}
            dict set workingInputs $alias $working
        }
        # Validate actual byte/domain dimensions before creating pixel output.
        dict for {id object} [dict get $plan objects] {
            set disposition [dict get $object disposition]
            if {$disposition eq {paint_image}} {set expected $object} elseif {$disposition eq {paint_annotation} && [_isText $object]} {set expected [dict get $object text_glyph]} else continue
            set facts [::GX::SII::inspectFile [dict get $workingInputs [dict get $expected input_alias]]]
            foreach key {width height} {if {[dict get $facts $key]!=[dict get $expected $key]} {_fail {Actual Resource pixel dimensions differ from captured mapping} ASSOCIATION}}
            if {$disposition eq {paint_annotation} && ([dict get $facts format] ne {PNG} || [dict get $facts depth]!=8 || ![string match *a* [dict get $facts channels]])} {_fail {Original glyph Resource must be its actual PNG8 alpha coverage} ASSOCIATION}
        }
        # Native paintScene paints actual Canvas background once, before any
        # isolated layer. Original settings.background remains provenance.
        set base [_blank $size [_rgba [dict get $p background]] tracked]
        dict set empty $base [_transparentBlack [dict get $p background]]
        foreach layer [dict get $p layers] {
            set id [dict get $layer logical_id]
            if {![_bool [dict get $layer properties visible]] || ![dict exists $plan byLayer $id]} continue
            # Native paints EVERY layer in isolation, then layer blend/alpha once.
            set surface [_blank $size none tracked];dict set empty $surface 1
            set rows [dict get $plan byLayer $id];set i 0
            while {$i<[llength $rows]} {
                set object [dict get $plan objects [lindex $rows $i]];set group [dict get $object group]
                set end [expr {$i+1}];set alpha 1.0;set visible 1
                if {$group ne {}} {
                    set gs [dict get $plan groups $group style];set alpha [lindex [dict get $gs color] 3];set visible [_bool [dict get $gs visible]]
                    while {$end<[llength $rows] && [dict get $plan objects [lindex $rows $end] group] eq $group} {incr end}
                }
                if {$visible && $alpha>0} {
                    set isolated [expr {$group ne {} && $alpha<1}]
                    if {$isolated} {set target [_blank $size none tracked];dict set empty $target 1} else {set target $surface}
                    for {set k $i} {$k<$end} {incr k} {
                        set item [dict get $plan objects [lindex $rows $k]]
                        set disposition [dict get $item disposition]
                        if {$disposition ni {paint_image paint_annotation} || ![_bool [dict get $item style visible]]} continue
                        set opacity [lindex [dict get $item style color] 3]
                        if {$opacity<=0} continue
                        if {$disposition eq {paint_image}} {
                            set leaf [_paintImage $item [dict get $workingInputs [dict get $item input_alias]] $size tracked empty]
                        } elseif {[_isText $item]} {
                            set leaf [_paintGlyph $item [dict get $workingInputs [dict get $item text_glyph input_alias]] $size tracked]
                        } else {
                            set leaf [_paintVector $item [dict get $p frame] $size tracked]
                        }
                        # Leaf opacity ONCE here, never image_get's alias or
                        # the glyph PNG's quantized ink/outer style a second time.
                        set target [_compose $target $leaf $opacity Over tracked empty]
                    }
                    if {$isolated} {set surface [_compose $surface $target $alpha Over tracked empty]} else {set surface $target}
                }
                set i $end
            }
            set base [_compose $base $surface [dict get $layer properties opacity] [dict get $layer blend] tracked empty]
        }
        switch -- $format {
            png16 {set output [list -define png:bit-depth=16 -depth 16 PNG:$result]}
            tiff16 {set output [list -depth 16 -compress Zip TIFF:$result]}
            tiff32f {set output [list -define quantum:format=floating-point -depth 32 -compress Zip TIFF:$result]}
        }
        _im [list MIFF:$base {*}$output]
        if {![file isfile $result] || [file size $result]<1} {_fail {Original ImageMagick produced no figure output}}
        set info [::GX::SII::inspectFile $result]
        foreach key {width height} {if {[dict get $info $key]!=[dict get $settings $key]} {_fail {Output extent differs from captured frame}}}
        ::GX::SII::previewFile $result $preview 2400 2400
        set published 1
        set imageCount 0;set annotationCount 0;set imageLineage {}
        dict for {id object} [dict get $plan objects] {
            if {[dict get $object disposition] eq {paint_image}} {incr imageCount;dict set imageLineage $id [dict get $object canonical_source_ids]}
            if {[dict get $object disposition] eq {paint_annotation}} {incr annotationCount}
        }
        return [dict create kind figure operation figure format $format result_file result.$ext display_file preview.png info $info \
            native_projection_schema [dict get $p schema] document_guard [dict get $p document_guard] canvas_id [dict get $p canvas_id] \
            sequence [dict get $p sequence] source_snapshot_sha256 [dict get $p snapshot_sha256] \
            actual_resource_refs $resources canonical_sources [dict get $plan capture canonical_sources] image_lineage $imageLineage \
            object_count [dict size [dict get $plan objects]] image_count $imageCount annotation_count $annotationCount]
    } finally {
        foreach file $tracked {catch {file delete -- $file}}
        if {!$published} {foreach file [list $result $preview] {catch {file delete -- $file}}}
    }
}
