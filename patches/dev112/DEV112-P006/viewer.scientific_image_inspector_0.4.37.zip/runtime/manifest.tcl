# Script Bridge exact operation policy: manifest.script_bridge_policy.json; original owners unchanged.
# Public, headless processing manifest for canonical image.raster Datasets.
# All persistence belongs to GX-TXT's Dataset Metadata + File Publication APIs.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII { variable manifestSchema scientific_image_inspector.manifest.v1 }

proc ::GX::SII::nativeManifestPack {value} {
    return [binary encode base64 -maxlen 0 [encoding convertto utf-8 $value]]
}
proc ::GX::SII::nativeManifestUnpack {native field} {
    if {[dict get $native encoding] ne {base64_utf8_original_Tcl_record}} {error {Unknown native manifest encoding}}
    set encoded [dict get $native ${field}_base64]
    if {[string length $encoded]>16777216 || [catch {set value [encoding convertfrom utf-8 [binary decode base64 -strict $encoded]]}] ||
        [nativeManifestPack $value] ne $encoded} {error {Invalid lossless native manifest record}}
    return $value
}
proc ::GX::SII::nativeManifestAnnotations {facts} {
    set rows {}
    foreach object [dict get $facts annotations] {
        lappend rows [dict create object [dict get $object object] encoding base64_utf8_original_Tcl_record definition_base64 [nativeManifestPack $object]]
    }
    return $rows
}

proc ::GX::SII::makeNativeManifest {request summary output jobId requestSha providerVersion} {
    set facts [_processingNativePublicationFacts $request $summary $output]
    if {[dict get $output job_id] ne $jobId || ![regexp {^[a-f0-9]{64}$} $requestSha]} {error {Native manifest producing Job identity differs}}
    set captured {}
    foreach key {image_source_profile image_native_projection image_native_projection_sha256 image_native_canonical_sources image_resource_sources image_recipe source_identities} {
        dict set captured $key [dict get $request $key]
    }
    # Snapshot paths are private implementation details; preserve its sealed
    # byte identity, not a portable promise about a Job scratch directory.
    dict set captured image_input_snapshot [dict create sha256 [dict get $request image_input_snapshot sha256]]
    if {[_processingFactsProfile [dict get $request image_recipe]] ne {}} {dict set captured image_facts_tool [dict create binary_sha256 [dict get $request image_facts_tool binary_sha256]]}
    set descriptor [dict remove $output source_file]
    set p [dict get $request image_native_projection]
    set sources {};set sourceFacts {}
    dict for {id origin} [dict get $request image_native_canonical_sources] {
        dict set sources $id [dict get $origin source_sha256]
        dict set sourceFacts $id $origin
    }
    set manifest [dict create schema scientific_image_inspector.manifest.v2 producer_module viewer.scientific_image_inspector \
        source_profile native_canvas_document_v1 source_sha256_map $sources source_facts $sourceFacts primary_source_id {} \
        operation_steps {} figure_panels {} figure_settings [dict get $p settings] annotations [nativeManifestAnnotations $facts] \
        coordinate_system [dict create origin native_frame coordinate_unit source_defined matrix_convention [dict get $p frame matrix_convention]] \
        image_magick_version [dict get $summary engine] workspace_id [dict get $p document_guard document_id] \
        native_canvas [dict create encoding base64_utf8_original_Tcl_record capture_request_base64 [nativeManifestPack $captured] \
            result_summary_base64 [nativeManifestPack $summary] output_receipt $descriptor \
            producing_job [dict create job_id $jobId request_sha256 $requestSha provider_version $providerVersion]] \
        native_counts [dict get $facts counts] \
        output [dict create format [dict get $output format] dataset_id {} expected_sha256 [dict get $output sha256] raster_properties [dict get $summary info]] \
        created_utc [clock format [clock seconds] -gmt 1 -format {%Y-%m-%dT%H:%M:%SZ}]]
    dict set manifest annotation_layers_json [nativeManifestAnnotationsJson $manifest]
    return $manifest
}
proc ::GX::SII::nativeManifestAnnotationsJson {manifest} {
    # Native definitions cannot be translated into legacy integer pixel
    # annotations without losing transforms/style/Resource provenance.
    set request [nativeManifestUnpack [dict get $manifest native_canvas] capture_request]
    set p [dict get $request image_native_projection];set objects {}
    foreach object [dict get $p objects] {if {[dict get $object disposition] eq {paint_annotation}} {lappend objects $object}}
    return "{\"schema\":\"scientific_image_inspector.native_annotations.v1\",\"encoding\":\"inert_original_Tcl_record_not_executable\",\"coordinate_system\":\"native_frame\",\"projection_sha256\":[jsonQuote [dict get $request image_native_projection_sha256]],\"objects_tcl_utf8\":[jsonQuote $objects],\"projection_tcl_utf8\":[jsonQuote $p]}"
}
proc ::GX::SII::nativeManifestValidate {manifest} {
    foreach key {producer_module source_profile source_sha256_map source_facts primary_source_id operation_steps figure_panels figure_settings annotations coordinate_system image_magick_version workspace_id native_canvas native_counts output created_utc annotation_layers_json} {
        if {![dict exists $manifest $key]} {error "Native Image Inspector manifest missing field: $key"}
    }
    if {[dict get $manifest producer_module] ne {viewer.scientific_image_inspector} || [dict get $manifest source_profile] ne {native_canvas_document_v1}} {error {Unsupported native manifest owner/profile}}
    set native [dict get $manifest native_canvas];set request [nativeManifestUnpack $native capture_request]
    set summary [nativeManifestUnpack $native result_summary];set receipt [dict get $native output_receipt]
    set facts [_processingNativePublicationFacts $request $summary $receipt]
    set job [dict get $native producing_job]
    if {[dict get $job job_id] ne [dict get $receipt job_id] || ![regexp {^[a-f0-9]{64}$} [dict get $job request_sha256]] ||
        ![regexp {^[0-9]+\.[0-9]+\.[0-9]+$} [dict get $job provider_version]]} {error {Native manifest producing Job provenance is invalid}}
    set sources {};dict for {id origin} [dict get $request image_native_canonical_sources] {dict set sources $id [dict get $origin source_sha256]}
    foreach key {format dataset_id expected_sha256 raster_properties} {if {![dict exists $manifest output $key]} {error "Native manifest output missing field: $key"}}
    set coordinates [dict create origin native_frame coordinate_unit source_defined matrix_convention [dict get $request image_native_projection frame matrix_convention]]
    if {[dict get $manifest source_sha256_map] ne $sources || [dict get $manifest source_facts] ne [dict get $request image_native_canonical_sources] ||
        [dict get $manifest primary_source_id] ne {} || [dict get $manifest operation_steps] ne {} || [dict get $manifest figure_panels] ne {} ||
        [dict get $manifest figure_settings] ne [dict get $request image_native_projection settings] ||
        [dict get $manifest coordinate_system] ne $coordinates ||
        [dict get $manifest annotations] ne [nativeManifestAnnotations $facts] || [dict get $manifest native_counts] ne [dict get $facts counts] ||
        [dict get $manifest workspace_id] ne [dict get $request image_native_projection document_guard document_id] ||
        [dict get $manifest image_magick_version] ne [dict get $summary engine] ||
        [dict get $manifest output format] ne [dict get $receipt format] || [dict get $manifest output expected_sha256] ne [dict get $receipt sha256] ||
        [dict get $manifest output raster_properties] ne [dict get $summary info]} {error {Native manifest differs from its captured editable provenance/output}}
    if {[dict get $manifest annotation_layers_json] ne [nativeManifestAnnotationsJson $manifest]} {error {Native annotation JSON differs from retained editable definitions}}
    return $manifest
}

proc ::GX::SII::makeResourceManifest {request summary output publicationSource requestSha providerVersion} {
    set facts [_processingResourcePublicationFacts $request $summary $output $publicationSource]
    if {![regexp {^[a-f0-9]{64}$} $requestSha]} {error {Selected Resource manifest request identity is invalid}}
    set captured {}
    foreach key {image_profile image_resource_sources image_capture_options image_recipe source_identities} {dict set captured $key [dict get $request $key]}
    dict set captured image_input_snapshot [dict create sha256 [dict get $request image_input_snapshot sha256]]
    set origins [dict get $facts origins];set sources {}
    dict for {id origin} $origins {dict set sources $id [dict get $origin source_sha256]}
    set manifest [dict create schema scientific_image_inspector.manifest.v2 producer_module viewer.scientific_image_inspector \
        source_profile selected_current_resource_v1 source_sha256_map $sources source_facts $origins primary_source_id {} \
        operation_steps {} figure_panels {} figure_settings {} annotations {} \
        coordinate_system [dict create origin top-left coordinate_unit current_resource_pixel scope selected_current_resource] \
        image_magick_version [dict get $summary engine] workspace_id [dict get $request source_identities workspace id] \
        selected_resource [dict create encoding base64_utf8_original_Tcl_record capture_request_base64 [nativeManifestPack $captured] \
            publication_source_base64 [nativeManifestPack $publicationSource] result_summary_base64 [nativeManifestPack $summary] \
            output_receipt [dict remove $output source_file] producing_job [dict create job_id [dict get $publicationSource job_id] request_sha256 $requestSha provider_version $providerVersion]] \
        selected_counts [dict get $facts counts] \
        output [dict create format [dict get $output format] dataset_id {} expected_sha256 [dict get $output sha256] raster_properties [dict get $summary info]] \
        created_utc [clock format [clock seconds] -gmt 1 -format {%Y-%m-%dT%H:%M:%SZ}]]
    dict set manifest annotation_layers_json [resourceManifestAnnotationsJson $manifest]
    return $manifest
}
proc ::GX::SII::resourceManifestAnnotationsJson {manifest} {
    set source [nativeManifestUnpack [dict get $manifest selected_resource] publication_source]
    return "{\"schema\":\"scientific_image_inspector.selected_resource_annotations.v1\",\"scope\":\"selected_current_raster_not_whole_document\",\"encoding\":\"inert_original_Tcl_record_not_executable\",\"separate_annotation_layers_rendered\":false,\"selected_item_tcl_utf8\":[jsonQuote [dict get $source selected_item]],\"lineage_tcl_utf8\":[jsonQuote [dict get $source lineage]]}"
}
proc ::GX::SII::resourceManifestValidate {manifest} {
    foreach key {producer_module source_profile source_sha256_map source_facts primary_source_id operation_steps figure_panels figure_settings annotations coordinate_system image_magick_version workspace_id selected_resource selected_counts output created_utc annotation_layers_json} {
        if {![dict exists $manifest $key]} {error "Selected Resource manifest missing field: $key"}
    }
    if {[dict get $manifest producer_module] ne {viewer.scientific_image_inspector} || [dict get $manifest source_profile] ne {selected_current_resource_v1} ||
        [dict exists $manifest native_canvas] || [dict exists $manifest native_counts]} {error {Selected Resource manifest cannot claim whole-Document scope}}
    set block [dict get $manifest selected_resource]
    set request [nativeManifestUnpack $block capture_request];set summary [nativeManifestUnpack $block result_summary]
    set capture [nativeManifestUnpack $block publication_source];set receipt [dict get $block output_receipt]
    set facts [_processingResourcePublicationFacts $request $summary $receipt $capture]
    set job [dict get $block producing_job]
    if {[dict get $job job_id] ne [dict get $capture job_id] || ![regexp {^[a-f0-9]{64}$} [dict get $job request_sha256]] ||
        ![regexp {^[0-9]+\.[0-9]+\.[0-9]+$} [dict get $job provider_version]]} {error {Selected Resource producing Job provenance is invalid}}
    set origins [dict get $facts origins];set sources {};dict for {id origin} $origins {dict set sources $id [dict get $origin source_sha256]}
    foreach key {format dataset_id expected_sha256 raster_properties} {if {![dict exists $manifest output $key]} {error "Selected Resource manifest output missing field: $key"}}
    if {[dict get $manifest source_sha256_map] ne $sources || [dict get $manifest source_facts] ne $origins ||
        [dict get $manifest primary_source_id] ne {} || [dict get $manifest operation_steps] ne {} || [dict get $manifest figure_panels] ne {} ||
        [dict get $manifest figure_settings] ne {} || [dict get $manifest annotations] ne {} || [dict get $manifest selected_counts] ne [dict get $facts counts] ||
        [dict get $manifest coordinate_system] ne {origin top-left coordinate_unit current_resource_pixel scope selected_current_resource} ||
        [dict get $manifest workspace_id] ne [dict get $request source_identities workspace id] || [dict get $manifest image_magick_version] ne [dict get $summary engine] ||
        [dict get $manifest output format] ne [dict get $receipt format] || [dict get $manifest output expected_sha256] ne [dict get $receipt sha256] ||
        [dict get $manifest output raster_properties] ne [dict get $summary info] || [dict get $manifest annotation_layers_json] ne [resourceManifestAnnotationsJson $manifest]} {error {Selected Resource manifest differs from its exact captured provenance/output}}
    return $manifest
}

proc ::GX::SII::makeManifest {sourceId steps panels settings annotations format {workspaceId {}}} {
    variable manifestSchema
    set sources {}
    set sourceFacts {}
    set entries [expr {[llength $panels] ? $panels : [list [dict create source_id $sourceId steps $steps]]}]
    foreach panel $entries {
        set id [dict get $panel source_id]
        if {[string match {local:*} $id]} {error {Publish source images as canonical Datasets before creating a derived image}}
        set data [sourceInfo $id]
        if {[dict exists $panel source_sha] && [dict get $panel source_sha] ne [dict get $data sha256]} {
            error "Source Dataset '$id' SHA-256 changed"
        }
        dict set sources $id [dict get $data sha256]
        set facts [dict create format [dict get $data format] media_type [dict get $data media_type]             size_bytes [dict get $data size_bytes] sha256 [dict get $data sha256]]
        set technical [inspectFile [dict get $data path]]
        foreach field {width height depth channels colorspace orientation frames resolution_x resolution_y density_units} {
            dict set facts $field [dict get $technical $field]
        }
        # Source's own metadata is a verified CORE record, not inferred by DPI.
        dict set facts dataset_metadata [dict get $data metadata]
        dict set sourceFacts $id $facts
    }
    set geometry [dict create origin top-left coordinate_unit pixel calibrated 0]
    # The annotated figure canvas and image pipeline coordinate systems differ
    # only when explicit geometry operators are accepted in the recipe.
    set recipe [validateSteps $steps]
    set overlay {}
    foreach a $annotations {
        # Preserve editable definitions, not flattened preview samples.
        lappend overlay $a
    }
    return [dict create schema $manifestSchema producer_module viewer.scientific_image_inspector \
        source_sha256_map $sources source_facts $sourceFacts primary_source_id $sourceId \
        operation_steps $recipe figure_panels $panels figure_settings $settings \
        annotations $overlay annotation_layers_json [annotationsJson $overlay] coordinate_system $geometry \
        color_policy {Uncalibrated image values; no physical pixel size inferred from DPI; ICC is not silently assigned} \
        image_magick_version [magickVersion] \
        workspace_id $workspaceId \
        output [dict create format $format dataset_id {} expected_sha256 {}] \
        created_utc [clock format [clock seconds] -gmt 1 -format {%Y-%m-%dT%H:%M:%SZ}]]
}
proc ::GX::SII::manifestValidate {manifest} {
    variable manifestSchema
    if {[catch {dict size $manifest}]} {error {Image Inspector manifest is not a dictionary}}
    if {[dict exists $manifest schema] && [dict get $manifest schema] eq {scientific_image_inspector.manifest.v2}} {
        if {[dict exists $manifest source_profile] && [dict get $manifest source_profile] eq {selected_current_resource_v1}} {return [resourceManifestValidate $manifest]}
        return [nativeManifestValidate $manifest]
    }
    foreach key {schema producer_module source_sha256_map source_facts primary_source_id operation_steps figure_panels figure_settings annotations coordinate_system image_magick_version output created_utc} {
        if {![dict exists $manifest $key]} {error "Image Inspector manifest missing field: $key"}
    }
    if {[dict get $manifest schema] ne $manifestSchema} {error {Unsupported Image Inspector manifest schema}}
    if {[dict get $manifest producer_module] ne "viewer.scientific_image_inspector"} {error {Manifest does not belong to Scientific Image Inspector}}
    dict for {id sha} [dict get $manifest source_sha256_map] {
        if {$id eq {} || ![regexp -nocase {^[0-9a-f]{64}$} $sha]} {error {Manifest source identity is invalid}}
    }
    if {[dict exists $manifest annotation_layers_json] && [dict get $manifest annotation_layers_json] ne [annotationsJson [dict get $manifest annotations]]} {
        error {Published annotation JSON does not match the retained overlay definitions}
    }
    foreach key {format dataset_id expected_sha256} {
        if {![dict exists $manifest output $key]} {error "Manifest output missing $key"}
    }
    return $manifest
}
proc ::GX::SII::manifestGet {datasetId} {
    # This method works headlessly; no Tk, ImageMagick processing, or workspace GUI.
    set session [::GX::sessionInspectionCurrentSession]
    set metadata [::GX::datasetMetadataRead $session $datasetId]
    if {![dict exists $metadata image.inspector.manifest]} {
        error "Dataset '$datasetId' has no Scientific Image Inspector manifest"
    }
    set manifest [manifestValidate [dict get $metadata image.inspector.manifest]]
    # Read-only consistency check against CORE's published file identity when available.
    if {[llength [info commands ::GX::sessionInspectionDatasetPayload]]} {
        if {![catch {set receipt [::GX::sessionInspectionDatasetPayload $datasetId $session]}]} {
            if {[dict exists $receipt sha256] &&                 ![string equal -nocase [dict get $receipt sha256] [dict get $manifest output expected_sha256]]} {
                error {Image Inspector manifest output SHA-256 mismatch}
            }
        }
    }
    if {[dict get $manifest output dataset_id] ne $datasetId} {
        error {Image Inspector manifest Dataset identity mismatch}
    }
    return $manifest
}
proc ::GX::SII::manifestSummary {datasetId} {
    set manifest [manifestGet $datasetId]
    if {[dict get $manifest schema] eq {scientific_image_inspector.manifest.v2} && [dict get $manifest source_profile] eq {selected_current_resource_v1}} {
        set captured [nativeManifestUnpack [dict get $manifest selected_resource] publication_source]
        return [dict create dataset_id $datasetId schema [dict get $manifest schema] source_profile selected_current_resource_v1 \
            sources [dict get $manifest source_sha256_map] operation_count 0 panel_count 0 annotation_count 0 \
            annotation_count_scope separately_rendered_by_this_publication image_count 1 resource_count 1 \
            canonical_source_count [dict get $manifest selected_counts canonical_sources] input_pixel_stage [dict get $captured precision pixel_stage] \
            scientific_precision_preserved [expr {[dict get $captured precision pixel_stage] eq {derived_rgba8_sRGB}?{0}:{not_asserted}}] \
            output [dict get $manifest output] workspace_id [dict get $manifest workspace_id]]
    }
    if {[dict get $manifest schema] eq {scientific_image_inspector.manifest.v2}} {
        return [dict create dataset_id $datasetId schema [dict get $manifest schema] source_profile [dict get $manifest source_profile] \
            sources [dict get $manifest source_sha256_map] operation_count 0 panel_count [dict get $manifest native_counts images] \
            annotation_count [dict get $manifest native_counts annotations] object_count [dict get $manifest native_counts objects] \
            output [dict get $manifest output] workspace_id [dict get $manifest workspace_id]]
    }
    return [dict create dataset_id $datasetId schema [dict get $manifest schema] \
        sources [dict get $manifest source_sha256_map] \
        operation_count [llength [dict get $manifest operation_steps]] \
        panel_count [llength [dict get $manifest figure_panels]] \
        annotation_count [llength [dict get $manifest annotations]] \
        output [dict get $manifest output] \
        workspace_id [dict get $manifest workspace_id]]
}
proc ::GX::SII::apiInfo {} {
    return [dict create api_id SCIENTIFIC_IMAGE_INSPECTOR_API_v1 manifest_schema scientific_image_inspector.manifest.v1 \
        manifest_schemas {scientific_image_inspector.manifest.v1 scientific_image_inspector.manifest.v2} native_source_profile native_canvas_document_v1 \
        manifest_source_profiles {native_canvas_document_v1 selected_current_resource_v1} \
        operations {manifest_get manifest_summary annotations_json inspect catalog capabilities presets validate_steps processing_prepare processing_submit processing_status processing_cancel processing_result processing_resource processing_publish} gui_required 0]
}
proc ::GX::SII::apiCall {operation args} {
    switch -- $operation {
        manifest_get {if {[llength $args] != 1} {error {manifest_get requires dataset_id}};return [manifestGet [lindex $args 0]]}
        manifest_summary {if {[llength $args] != 1} {error {manifest_summary requires dataset_id}};return [manifestSummary [lindex $args 0]]}
        annotations_json {
            if {[llength $args]!=1} {error {annotations_json requires dataset_id}}
            set manifest [manifestGet [lindex $args 0]]
            if {[dict get $manifest schema] eq {scientific_image_inspector.manifest.v2} && [dict get $manifest source_profile] eq {selected_current_resource_v1}} {return [resourceManifestAnnotationsJson $manifest]}
            if {[dict get $manifest schema] eq {scientific_image_inspector.manifest.v2}} {return [nativeManifestAnnotationsJson $manifest]}
            return [annotationsJson [dict get $manifest annotations]]
        }
        inspect {if {[llength $args] != 1} {error {inspect requires dataset_id}};return [inspect [lindex $args 0]]}
        catalog {return [catalogList {*}$args]}
        capabilities {return [capabilities]}
        presets - validate_steps - processing_prepare - processing_submit - processing_status -
        processing_cancel - processing_result - processing_resource - processing_publish {
            return [processingCall $operation $args]
        }
        default {error "Unsupported Scientific Image Inspector API operation: $operation"}
    }
}
