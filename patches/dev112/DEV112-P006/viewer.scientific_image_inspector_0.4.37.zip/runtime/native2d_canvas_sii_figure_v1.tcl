# SII application implementation; registered by its approved public module API.
# SPDX-License-Identifier: GPL-3.0-or-later
# Private SII figure composition over the original Canvas/Document owners.
# These helpers return candidates; the controller alone commits one History edit.
# The completed raster is a hidden pixel-coordinate frame, not a flattened editor
# or evidence that later native edits equal the producing high-depth raster.

proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureSettings {settings {panels {}}} {
    fields $settings {width height margin gutter layout background}
    set clean {}
    foreach {key low high default} {width 120 12000 2400 height 120 12000 1600 margin 0 1000 32 gutter 0 1000 24} {
        dict set clean $key [::GX::SII::figureValidInt [::GX::datasetPublicationV2DictDefault $settings $key $default] $low $high $key]
    }
    dict set clean layout [::GX::datasetPublicationV2DictDefault $settings layout grid]
    dict set clean background [::GX::SII::figureColor [::GX::datasetPublicationV2DictDefault $settings background #FFFFFF]]
    set check $panels
    if {![llength $check]} {set check [list {}]}
    ::GX::SII::figurePlan $check [dict get $clean width] [dict get $clean height] [dict get $clean margin] [dict get $clean gutter] [dict get $clean layout]
    if {wide([dict get $clean width])*wide([dict get $clean height])>80000000} {error {Figure export limited to 80 megapixels}}
    return $clean
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureLayer {snapshot {editable 0} {logical {}}} {
    if {$logical eq {}} {set logical [dict get $snapshot active_layer]}
    foreach layer [dict get $snapshot layers] {
        if {[dict get $layer logical_id] ne $logical} continue
        if {$editable} {
            set properties [dict get $layer properties]
            if {[dict get $properties locked] || ![dict get $properties visible] || ![dict get $properties selectable]} {error {Figure layer is locked, hidden or unselectable}}
        }
        return $layer
    }
    error {Choose a live Native2D layer for the figure}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureMember {snapshot logical layer role} {
    set item [snapshotLeaf $snapshot $logical]
    # The marker identifies catalog creation, not permanent native layer
    # placement. Legal native layer_assign retains that original association.
    _nativeCanvasSiiFigureLayer $snapshot 0 [dict get $item layer_logical_id]
    set reference [dict get $item resource]
    if {[dict get $reference document_id] ne [dict get $snapshot document_id] || [dict get $reference owner_generation] ne [dict get $snapshot generation]} {error {Foreign native figure Resource owner}}
    ::GX::interactiveDocumentResourceInfo $reference
    if {![dict exists $reference metadata sketch_attributes gx.sii.figure]} {error {Figure member has no original native association}}
    set marker [dict get $reference metadata sketch_attributes gx.sii.figure]
    fields $marker {schema layer role} {schema layer role}
    if {[dict get $marker schema] ne {gxtxt.sii.native_figure_member.v1} || [dict get $marker layer] ne $layer || [dict get $marker role] ne $role} {error {Foreign native figure member}}
    if {$role in {panel frame} && (![dict exists $reference metadata reference_image] || ![dict exists $reference metadata image_resource])} {error {Figure image member is not a retained native image}}
    if {$role eq {annotation}} {
        set kind [dict get $reference metadata sketch_attributes gx.canvas kind]
        if {$kind ni {text line arrow rectangle ellipse}} {error {Unknown original native figure annotation kind}}
    }
    return $item
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureEditable {snapshot item {internalFrame 0}} {
    set logical [dict get $item logical_id]
    _nativeCanvasSiiFigureLayer $snapshot 1 [dict get $item layer_logical_id]
    foreach group [dict get $snapshot groups] {
        if {$logical in [dict get $group members]} {error {Ungroup the figure member through its original Native2D owner before editing it}}
    }
    set style [dict get $item style]
    # Only the private coordinate frame intentionally hides/locks itself.
    # This exception never bypasses its actual current layer or group owner.
    if {$internalFrame && ![dict get $style visible] && ![dict get $style selectable] && [dict get $style locked]} {return}
    snapshotEditable $snapshot $item
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureDiagnostics {snapshot state} {
    set current {}
    foreach item [dict get $snapshot objects] {dict set current [dict get $item logical_id] $item}
    set origin [dict get $snapshot active_layer]
    set missing {};set moved {}
    set frame [dict get $state frame_object]
    foreach role {panel annotation frame} members [list [dict get $state panels] [dict get $state annotations] [expr {$frame eq {} ? {} : [list $frame]}]] {
        foreach logical $members {
            if {![dict exists $current $logical]} {lappend missing [dict create object $logical role $role];continue}
            # Existing foreign/corrupt members refuse; only a genuinely absent
            # logical ID is eligible for an explicit association-only prune.
            set item [_nativeCanvasSiiFigureMember $snapshot $logical $origin $role]
            if {[dict get $item layer_logical_id] ne $origin} {lappend moved [dict create object $logical role $role current_layer [dict get $item layer_logical_id]]}
        }
    }
    return [dict create missing $missing moved $moved]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureState {snapshot {diagnosticsVariable {}}} {
    set layer [_nativeCanvasSiiFigureLayer $snapshot]
    set logical [dict get $layer logical_id]
    set state [::GX::datasetPublicationV2DictDefault [dict get $layer attributes] gx.sii.figure {}]
    if {$state eq {}} {
        set state [dict create schema gxtxt.sii.native_figure.v1 settings [_nativeCanvasSiiFigureSettings {}] panels {} annotations {} frame_object {}]
    }
    fields $state {schema settings panels annotations frame_object} {schema settings panels annotations frame_object}
    if {[dict get $state schema] ne {gxtxt.sii.native_figure.v1}} {error {Unsupported native figure schema}}
    set panels [dict get $state panels];set annotations [dict get $state annotations]
    if {[llength $panels]>12} {error {Figure supports at most 12 panels}}
    set ids [concat $panels $annotations]
    set frame [dict get $state frame_object]
    if {$frame ne {}} {lappend ids $frame}
    if {[llength $ids]!=[llength [lsort -unique $ids]]} {error {Duplicate native figure membership}}
    foreach id $ids {if {$id eq {} || [string is entier -strict $id]} {error {Invalid native figure logical identity}}}
    set observed [_nativeCanvasSiiFigureDiagnostics $snapshot $state]
    if {$diagnosticsVariable ne {}} {upvar 1 $diagnosticsVariable diagnostics;set diagnostics $observed}
    dict set state settings [_nativeCanvasSiiFigureSettings [dict get $state settings] $panels]
    return $state
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureGet {handle} {
    _nativeCanvasSiiModule
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set snapshot [::GX::native2DCanvasCapture $handle]
    set result [_nativeCanvasSiiFigureState $snapshot diagnostics]
    # Current member identity is retained by the native scene/Resource, not an
    # alternate list of scientific recipes. Yielding image checks happen only
    # in the held edit functions, which recheck the original EditCurrent guard.
    foreach logical [dict get $result panels] {
        if {[dict create object $logical role panel] in [dict get $diagnostics missing]} continue
        set item [snapshotLeaf $snapshot $logical]
        ::GX::interactiveDocumentResourceInfo [dict get $item resource metadata image_resource]
    }
    set current [::GX::SII::CanvasApplication::appRecord $handle]
    ::GX::native2DCanvasContextCurrent $handle [dict get $row context]
    if {[dict remove [::GX::native2DCanvasCapture $handle] view_state tool] ne [dict remove $snapshot view_state tool]} {error {Canvas changed while reading its figure}}
    return [dict merge $result [dict create diagnostics $diagnostics]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigurePut {snapshot state} {
    # Diagnostics belong to this read, never to the persisted editor catalog.
    set state [dict remove $state diagnostics]
    fields $state {schema settings panels annotations frame_object} {schema settings panels annotations frame_object}
    set layers {}
    foreach layer [dict get $snapshot layers] {
        if {[dict get $layer logical_id] eq [dict get $snapshot active_layer]} {dict set layer attributes gx.sii.figure $state}
        lappend layers $layer
    }
    dict set snapshot layers $layers
    return $snapshot
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureIdentity {snapshot role} {
    set ids [lmap item [dict get $snapshot objects] {dict get $item logical_id}]
    set logical sii_figure_${role}_[clock clicks]
    while {$logical in $ids} {append logical x}
    return $logical
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureReplace {snapshot item} {
    set result {};set found 0
    foreach old [dict get $snapshot objects] {
        if {[dict get $old logical_id] eq [dict get $item logical_id]} {lappend result $item;set found 1} else {lappend result $old}
    }
    if {!$found} {lappend result $item}
    dict set snapshot objects $result
    return $snapshot
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureRemove {snapshot logical} {
    foreach group [dict get $snapshot groups] {
        if {$logical in [dict get $group members]} {error {Ungroup the figure member through its original Native2D owner before removing it}}
    }
    dict set snapshot objects [lmap item [dict get $snapshot objects] {if {[dict get $item logical_id] eq $logical} continue;set item}]
    dict set snapshot selection [lmap id [dict get $snapshot selection] {if {$id eq $logical} continue;set id}]
    return $snapshot
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureMark {scene object logical layer role} {
    set attrs [geometryAttributes $scene $object]
    set canvas [::GX::datasetPublicationV2DictDefault $attrs gx.canvas {}]
    dict set canvas logical_id $logical
    geometryAttribute $scene $object gx.canvas $canvas
    geometryAttribute $scene $object gx.sii.figure [dict create schema gxtxt.sii.native_figure_member.v1 layer $layer role $role]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureCopy {handle snapshot logical} {
    set model [_nativeCanvasSiiImageModelFor $handle $logical 1]
    set item [snapshotLeaf $snapshot $logical]
    _nativeCanvasSiiFigureEditable $snapshot $item
    set copy [_nativeCanvasSiiFigureIdentity $snapshot panel]
    set layer [dict get $snapshot active_layer]
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set scene [::GX::native2DGeometryOpen [dict get $row document]]
    try {
        set reference [dict get $item resource]
        set object [geometryRestore $scene $reference]
        _nativeCanvasSiiFigureMark $scene $object $copy $layer panel
        geometryAttribute $scene $object gx.image.sii [dict remove $model object]
        dict set item resource [geometryStore $scene $object [dict get $reference metadata]]
    } finally {
        ::GX::native2DGeometryClose $scene
    }
    dict set item logical_id $copy;dict set item layer_logical_id $layer
    dict set item name {Independent figure panel}
    return $item
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureFrameMatrix {scene object} {
    # Ask the original reference-image mapping for its basis. No independent
    # camera, calibration or pixel/world conversion is introduced here.
    lassign [geometryImageMap $scene $object {0 0} 0] x y
    lassign [geometryImageMap $scene $object {1 0} 0] ax ay
    lassign [geometryImageMap $scene $object {0 1} 0] bx by
    return [list [expr {$ax-$x}] [expr {$bx-$x}] [expr {$ay-$y}] [expr {$by-$y}] $x $y]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigurePlace {scene frame object slot height} {
    set image [geometryImageState $scene $object]
    # Original figurePlan owns the box; Native owns the continuous similarity.
    # IM integer resize may differ at its rounded edges. Only this independent
    # copy's presentation enters figure pixels; source calibration is untouched.
    set scale [expr {min(double([dict get $slot width])/[dict get $image width],double([dict get $slot height])/[dict get $image height])}]
    set x [expr {[dict get $slot x]+([dict get $slot width]-[dict get $image width]*$scale)/2.0}]
    set y [expr {$height-[dict get $slot y]-([dict get $slot height]+[dict get $image height]*$scale)/2.0}]
    dict set image scale $scale;dict set image rotation 0
    dict set image translation [geometryImageMap $scene $frame [list $x $y] 0]
    dict set image length_unit px;dict set image calibrated 0
    return [dict get [::GX::native2DGeometryCall $scene image_pixel_projection [dict create object_token $object changes [dict create scale [dict get $image scale] rotation [dict get $image rotation] translation [dict get $image translation]]]] image_state]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureAnnotation {handle snapshot state annotation logical {old {}}} {
    set settings [dict get $state settings]
    set a [::GX::SII::validateAnnotation $annotation [dict get $settings width] [dict get $settings height]]
    set frame [dict get $state frame_object]
    if {$frame eq {}} {error {Complete a verified figure pixel frame before adding native annotations}}
    set layer [dict get $snapshot active_layer]
    set frameItem [_nativeCanvasSiiFigureMember $snapshot $frame $layer frame]
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set scene [::GX::native2DGeometryOpen [dict get $row document]]
    try {
        set frameId [geometryRestore $scene [dict get $frameItem resource]]
        set frameState [geometryImageState $scene $frameId]
        if {[dict get $frameState width]!=[dict get $settings width] || [dict get $frameState height]!=[dict get $settings height]} {error {Figure settings changed; regenerate the verified frame first}}
        set kind [dict get $a kind];set x [dict get $a x1];set y [expr {[dict get $settings height]-[dict get $a y1]}]
        switch -- $kind {
            text {
                set width [::GX::datasetPublicationV2DictDefault $a box_width [expr {max(14.0,[string length [dict get $a text]]*[dict get $a size]*0.59)}]]
                set height [::GX::datasetPublicationV2DictDefault $a box_height [expr {max(9.0,[dict get $a size]*1.2)}]]
                set definition [dict create family rectangle controls [list [list $x [expr {$y-$height}]] [list [expr {$x+$width}] $y]]]
            }
            line - arrow {set definition [dict create family line controls [list [list $x $y] [list [dict get $a x2] [expr {[dict get $settings height]-[dict get $a y2]}]]]]}
            rectangle {set definition [dict create family rectangle controls [list [list $x $y] [list [dict get $a x2] [expr {[dict get $settings height]-[dict get $a y2]}]]]]}
            ellipse {
                set x2 [dict get $a x2];set y2 [expr {[dict get $settings height]-[dict get $a y2]}]
                set definition [dict create family ellipse controls [list [list [expr {($x+$x2)/2.0}] [expr {($y+$y2)/2.0}]]] radius_x [expr {max(1,abs($x2-$x)/2.0)}] radius_y [expr {max(1,abs($y2-$y)/2.0)}]]
            }
        }
        dict set definition matrix [::GX::SII::annotationNativeMatrix $a [dict get $settings height]]
        set object [dict get [::GX::native2DGeometryCall $scene sketch [dict create definition $definition display_samples 257]] object_token]
        ::GX::native2DGeometryCall $scene affine [dict create object_tokens [list $object] matrix [_nativeCanvasSiiFigureFrameMatrix $scene $frameId] copy 0]
        scan [string range [dict get $a color] 1 end] %2x%2x%2x r g b
        set color [list [expr {$r/255.0}] [expr {$g/255.0}] [expr {$b/255.0}] 1]
        set style [dict create visible 1 selectable 1 locked 0 order 0 line_style 0 marker 0 line_width [dict get $a stroke] color $color]
        ::GX::native2DGeometryCall $scene style [dict create object_token $object properties $style]
        set canvas [dict create logical_id $logical kind $kind]
        if {$kind eq {text}} {
            dict set canvas text [dict get $a text]
            # A family may contain spaces. Keep it one Tcl/Tk font descriptor
            # element; original validated image-pixel size remains separate.
            dict set canvas font [list [dict get $a font_family] 12]
            dict set canvas font_size [dict get $a size];dict set canvas anchor nw;dict set canvas fill $color
            # Preserve original font-unit declarations, not a second geometry.
            set font {};foreach key {font_unit font_value font_dpi} {if {[dict exists $a $key]} {dict set font $key [dict get $a $key]}}
            geometryAttribute $scene $object gx.sii.annotation_font $font
        }
        geometryAttribute $scene $object gx.canvas $canvas
        if {$kind eq {arrow}} {::GX::native2DGeometryCall $scene direction [dict create object_token $object properties [dict create present 1 visible 1 forward 1 fraction 1 offset_px 0 length_px 20 color $color]]}
        _nativeCanvasSiiFigureMark $scene $object $logical $layer annotation
        set reference [geometryStore $scene $object]
    } finally {
        ::GX::native2DGeometryClose $scene
    }
    if {$old eq {}} {set old [dict create logical_id $logical style $style layer_logical_id $layer]}
    dict set old resource $reference;dict set old style $style
    dict set old name [::GX::datasetPublicationV2DictDefault $a name {Figure annotation}]
    return $old
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureChange {handle held action payload} {
    _nativeCanvasSiiModule
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    set next [heldSnapshot $handle $held]
    _nativeCanvasSiiFigureLayer $next 1
    set state [_nativeCanvasSiiFigureState $next diagnostics]
    set layer [dict get $next active_layer]
    switch -- $action {
        settings_set {dict set state settings [_nativeCanvasSiiFigureSettings $payload [dict get $state panels]]}
        panel_add {
            fields $payload object object
            if {[llength [dict get $state panels]]>=12} {error {Figure supports at most12 panels}}
            set item [_nativeCanvasSiiFigureCopy $handle $next [dict get $payload object]]
            set next [_nativeCanvasSiiFigureReplace $next $item]
            dict lappend state panels [dict get $item logical_id]
            _nativeCanvasSiiFigureSettings [dict get $state settings] [dict get $state panels]
        }
        panel_replace {
            fields $payload {object replacement} {object replacement}
            set logical [dict get $payload object]
            if {$logical ni [dict get $state panels]} {error {Object is not a created panel of this figure}}
            set original [_nativeCanvasSiiFigureMember $next $logical $layer panel]
            _nativeCanvasSiiFigureEditable $next $original
            set item [_nativeCanvasSiiFigureCopy $handle $next [dict get $payload replacement]]
            ::GX::SII::CanvasApplication::appEditCurrent $handle $held
            set row [::GX::SII::CanvasApplication::appRecord $handle]
            set scene [::GX::native2DGeometryOpen [dict get $row document]]
            try {
                set old [geometryRestore $scene [dict get $original resource]]
                set pose [geometryImageState $scene $old]
                if {[dict get $pose length_unit] ne {px}} {error {Normalize the panel through the original pixel-projection or working-unit owner before replacement; physical units cannot be relabelled as pixels}}
                set reference [dict get $item resource]
                set object [geometryRestore $scene $reference]
                set image [geometryImageState $scene $object]
                foreach key {scale rotation translation opacity visible locked} {dict set image $key [dict get $pose $key]}
                # Keep the current pixel pose, never old source calibration or
                # ROIs. Intrinsic dimensions and pixel attributes are fresh.
                dict set image length_unit px;dict set image calibrated 0
                dict set image calibration {{0 0} {0 0}};dict set image calibrated_distance 0
                set changes {};foreach key {scale rotation translation opacity visible locked} {dict set changes $key [dict get $image $key]}
                ::GX::native2DGeometryCall $scene image_pixel_projection [dict create object_token $object changes $changes reset_calibration 1]
                ::GX::native2DGeometryCall $scene style [dict create object_token $object properties [dict get $original style]]
                _nativeCanvasSiiFigureMark $scene $object $logical $layer panel
                set attributes [geometryAttributes $scene $object]
                dict set attributes gx.canvas name [dict get $original name]
                geometryAttribute $scene $object gx.canvas [dict get $attributes gx.canvas]
                dict set item resource [geometryStore $scene $object [dict get $reference metadata]]
            } finally {
                ::GX::native2DGeometryClose $scene
            }
            foreach key {logical_id layer_logical_id style name} {dict set item $key [dict get $original $key]}
            # Same identity replaces in place: catalog ordinal, selection and
            # object paint order stay with the original native snapshot.
            set next [_nativeCanvasSiiFigureReplace $next $item]
        }
        panel_remove - annotation_remove {
            fields $payload object object
            set role [expr {$action eq {panel_remove} ? {panel} : {annotation}}]
            set key [expr {$role eq {panel} ? {panels} : {annotations}}]
            set logical [dict get $payload object]
            if {$logical ni [dict get $state $key]} {error {Object is not a created member of this figure}}
            if {[dict create object $logical role $role] ni [dict get $diagnostics missing]} {
                set item [_nativeCanvasSiiFigureMember $next $logical $layer $role]
                _nativeCanvasSiiFigureEditable $next $item
                set next [_nativeCanvasSiiFigureRemove $next $logical]
            }
            dict set state $key [lmap id [dict get $state $key] {if {$id eq $logical} continue;set id}]
        }
        annotation_add - annotation_update {
            if {$action eq {annotation_add}} {
                fields $payload annotation annotation
                set logical [_nativeCanvasSiiFigureIdentity $next annotation];set old {}
            } else {
                fields $payload {object annotation} {object annotation}
                set logical [dict get $payload object]
                if {$logical ni [dict get $state annotations]} {error {Object is not a created annotation of this figure}}
                set old [_nativeCanvasSiiFigureMember $next $logical $layer annotation]
                _nativeCanvasSiiFigureEditable $next $old
            }
            set item [_nativeCanvasSiiFigureAnnotation $handle $next $state [dict get $payload annotation] $logical $old]
            set next [_nativeCanvasSiiFigureReplace $next $item]
            if {$old eq {}} {dict lappend state annotations $logical}
        }
        reconcile {
            fields $payload {}
            foreach absent [dict get $diagnostics missing] {
                set logical [dict get $absent object]
                switch -- [dict get $absent role] {
                    panel {dict set state panels [lmap id [dict get $state panels] {if {$id eq $logical} continue;set id}]}
                    annotation {dict set state annotations [lmap id [dict get $state annotations] {if {$id eq $logical} continue;set id}]}
                    frame {dict set state frame_object {}}
                }
            }
        }
        reset {
            fields $payload {}
            foreach role {panel annotation frame} members [list [dict get $state panels] [dict get $state annotations] [expr {[dict get $state frame_object] eq {} ? {} : [list [dict get $state frame_object]]}]] {
                foreach logical $members {
                    if {[dict create object $logical role $role] in [dict get $diagnostics missing]} continue
                    set item [_nativeCanvasSiiFigureMember $next $logical $layer $role]
                    _nativeCanvasSiiFigureEditable $next $item [expr {$role eq {frame}}]
                    set next [_nativeCanvasSiiFigureRemove $next $logical]
                }
            }
            set state [dict create schema gxtxt.sii.native_figure.v1 settings [_nativeCanvasSiiFigureSettings {}] panels {} annotations {} frame_object {}]
        }
        default {error {Unknown closed native figure action}}
    }
    set next [_nativeCanvasSiiFigurePut $next $state]
    ::GX::native2DCanvasSnapshotValidate $next
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return $next
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureFrameCheck {handle held proof state} {
    fields $proof {job_id raster provenance document_guard request} {job_id raster provenance document_guard request}
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    set guard [dict get $proof document_guard]
    ::GX::scientificExecutionPublicationGuard $guard
    if {$guard ne [_nativeCanvasSiiGuard $row]} {error {Figure frame guard is outside the exact current Canvas Document}}
    set raster [dict get $proof raster];set provenance [dict get $proof provenance]
    foreach reference [list $raster $provenance] {
        ::GX::interactiveDocumentResourceInfo $reference
        if {[dict get $reference document_id] ne [dict get $row document] || [dict get $reference owner_generation] ne [dict get $row receipt generation]} {error {Foreign figure frame Resource}}
    }
    set producing [_nativeCanvasSiiResourceJob $raster]
    if {$producing eq {}} {error {Figure frame has no original completed producing Job}}
    set job [dict get $producing job]
    set request [dict get $job scientific_request image_recipe]
    if {[dict get $job id] ne [dict get $proof job_id] || [dict get $request kind] ne {figure} || $request ne [dict get $proof request]} {error {Figure frame is outside its exact producing request}}
    set workspace [dict get $job scientific_request source_identities workspace]
    foreach source {id generation revision sha256} target {document_id generation revision sha256} {
        if {[dict get $workspace $source] ne [dict get $guard $target]} {error {Figure Job did not capture the exact current Canvas guard}}
    }
    if {[dict get $request settings] ne [dict get $state settings]} {error {Figure frame settings changed}}
    set panels {}
    foreach logical [dict get $state panels] {
        set model [_nativeCanvasSiiImageModelFor $handle $logical 0]
        lappend panels [dict create source [dict get $model source] steps [dict get $model image steps]]
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    }
    if {$panels ne [dict get $request panels]} {error {Figure frame panel sources or recipes changed}}
    foreach role {raster provenance} reference [list $raster $provenance] {
        set resourceProof [_nativeCanvasSiiResourceJob $reference]
        if {$resourceProof eq {} || [dict get $resourceProof job id] ne [dict get $job id]} {error {Figure frame/provenance Job mismatch}}
        set observed [_nativeCanvasSiiResourceObserve $reference]
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
        if {[llength [dict get $observed outputs]]!=1} {error {Ambiguous figure output}}
        set output [lindex [dict get $observed outputs] 0]
        foreach key {sha256 size_bytes} {if {[dict get $output $key] ne [dict get $reference $key]} {error {Figure Resource differs from its exact held output bytes}}}
        if {[dict get $output role] ne $role || [dict get $output token] ne [dict get $reference metadata source_output_token] || [dict get $output source_generation] ne [dict get $reference metadata source_generation]} {error {Figure output role/token/generation changed}}
    }
    lassign [_nativeCanvasSiiImageDimensions $raster] width height
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    if {$width ne [dict get $state settings width] || $height ne [dict get $state settings height]} {error {Figure output dimensions differ from the original settings}}
    # Job annotations are authenticated producer input, never substituted for
    # current independently editable native annotation geometry.
    return [dict create raster $raster provenance $provenance width $width height $height frame_only 1 pixel_equivalence 0]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureLayout {handle held frameProof} {
    _nativeCanvasSiiModule
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    set next [heldSnapshot $handle $held]
    _nativeCanvasSiiFigureLayer $next 1
    set state [_nativeCanvasSiiFigureState $next diagnostics]
    if {[llength [dict get $diagnostics missing]]} {error {Reconcile missing figure associations before laying out native members}}
    set panels [dict get $state panels]
    set settings [dict get $state settings]
    set slots [::GX::SII::figurePlan $panels [dict get $settings width] [dict get $settings height] [dict get $settings margin] [dict get $settings gutter] [dict get $settings layout]]
    set checked [_nativeCanvasSiiFigureFrameCheck $handle $held $frameProof $state]
    set layer [dict get $next active_layer]
    set frameLayer $layer
    set logical [dict get $state frame_object]
    if {$logical eq {}} {set logical [_nativeCanvasSiiFigureIdentity $next frame]} else {
        # A regenerated frame must not silently move already edited native
        # annotations. The frame is identity pixel/world; annotations persist.
        set old [_nativeCanvasSiiFigureMember $next $logical $layer frame]
        _nativeCanvasSiiFigureEditable $next $old 1
        set frameLayer [dict get $old layer_logical_id]
        set next [_nativeCanvasSiiFigureRemove $next $logical]
    }
    set scene [::GX::native2DGeometryOpen [dict get $row document]]
    try {
        set image [dict create width [dict get $checked width] height [dict get $checked height] scale 1 rotation 0 translation {0 0} opacity 1 visible 0 locked 1 length_unit px resource_id [dict get $checked raster sha256]]
        set frame [dict get [::GX::native2DGeometryCall $scene image_attach [dict create resource [dict get $checked raster] working_unit px state $image]] object_token]
        geometryAttribute $scene $frame gx.canvas [dict create logical_id $logical kind image]
        _nativeCanvasSiiFigureMark $scene $frame $logical $layer frame
        set reference [geometryStore $scene $frame [dict create dependencies [list [dict get $checked provenance]]]]
        set style {visible 0 selectable 0 locked 1 order 0 line_style 0 marker 0 line_width 1 color {1 1 1 1}}
        set next [_nativeCanvasSiiFigureReplace $next [dict create logical_id $logical name {Verified figure coordinate frame (hidden)} resource $reference style $style layer_logical_id $frameLayer]]
        dict set state frame_object $logical
        foreach slot $slots {
            set id [dict get $slot panel]
            set item [_nativeCanvasSiiFigureMember $next $id $layer panel]
            _nativeCanvasSiiFigureEditable $next $item
            set original [dict get $item resource]
            set object [geometryRestore $scene $original]
            _nativeCanvasSiiFigurePlace $scene $frame $object $slot [dict get $checked height]
            dict set item resource [geometryStore $scene $object [dict get $original metadata]]
            set next [_nativeCanvasSiiFigureReplace $next $item]
        }
    } finally {
        ::GX::native2DGeometryClose $scene
    }
    foreach reference [list [dict get $checked raster] [dict get $checked provenance]] {
        if {$reference ni [dict get $next retained_outputs]} {dict lappend next retained_outputs $reference}
    }
    set next [_nativeCanvasSiiFigurePut $next $state]
    ::GX::native2DCanvasSnapshotValidate $next
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return $next
}
