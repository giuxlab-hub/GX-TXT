#!/usr/bin/env python3
"""Private fixed original-SII LOD byte auxiliary; parent owns all GUI authority.

The actual parent supplies lod_plan_v1's unchanged plan/argv. This helper validates
that finite grammar, pins bytes/lease, and streams the SAME ImageMagick PNG into
its existing allocation. It is neither a renderer registry nor a scientific API.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import configparser
import hashlib
import os
from pathlib import Path
import re
import selectors
import stat
import struct
import subprocess
import sys
import time
import zlib

__all__ = ()
SCHEMA = 'scientific_image_inspector.lod_render.v1'
MAX_FRAME = 49152
MAX_DIAGNOSTICS = 10000  # Original lod.tcl literal bound, now counted in bytes.
RENDER_SECONDS = 20
CACHE_BYTES = 768 * 1024 * 1024
LIMITS = ('-limit', 'memory', '192MiB', '-limit', 'map', '384MiB',
          '-limit', 'disk', '768MiB', '-limit', 'time', '30',
          '-limit', 'thread', '2', '-limit', 'list-length', '64')
FIELDS = {'schema', 'parent_pid', 'parent_identity', 'reservation', 'session',
          'source_path', 'source_sha256', 'source_bytes', 'image_dimensions',
          'source_rect', 'display', 'tool_path', 'tool_sha256', 'output_file', 'argv'}


class Refused(ValueError):
    pass


def absolute(value):
    if (not isinstance(value, str) or not value.startswith('/') or '\0' in value or
            any(part in ('.', '..') for part in value.split('/'))):
        raise Refused('LOD requires original absolute owner paths')
    return Path(value)


def bootstrap(runtime_directory):
    if not sys.platform.startswith('linux') or not Path('/proc/self/fd').is_dir():
        raise Refused('Held-source LOD requires the supported Linux descriptor backend')
    runtime_directory = absolute(runtime_directory)
    # Validate the bootstrap path before importing existing shared CORE owners.
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in runtime_directory.parts[1:]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        if not stat.S_ISREG(os.stat('gxtxt_scientific_image_runtime_v1.py', dir_fd=fd, follow_symlinks=False).st_mode):
            raise Refused('Public image auxiliary runtime is unavailable')
    finally:
        os.close(fd)
    # Independently installed SII modules need not reside beneath CORE_ROOT.
    # Descriptor consistency is not a grant; actual parent/module/source closure
    # and the Resource lease supply authority, never a self-written module.ini.
    own = absolute(os.path.abspath(__file__))
    if own.name != 'lod_render_v1.py' or own.parent.name != 'runtime':
        raise Refused('Unexpected original SII auxiliary location')
    descriptor = own.parent.parent / 'module.ini'
    config = configparser.ConfigParser(interpolation=None)
    with descriptor.open(encoding='utf-8') as stream:
        config.read_file(stream)
    if config.get('meta', 'id', fallback='') != 'viewer.scientific_image_inspector':
        raise Refused('Original SII module descriptor differs')
    sys.path.insert(0, str(runtime_directory))
    from gxtxt_scientific_image_runtime_v1 import (
        API_ID, API_VERSION, decode_client_value, ResourceManager, require_parent,
        open_directory, open_source, file_signature, encode_tcl_value,
    )
    if API_ID != 'SCIENTIFIC_IMAGE_AUXILIARY_RUNTIME_v1' or API_VERSION != 1:
        raise Refused('Public image auxiliary runtime contract differs')
    return (decode_client_value, ResourceManager, require_parent, open_directory,
            open_source, file_signature, encode_tcl_value)


def exact_integer(value, minimum=0):
    if type(value) is not int or not minimum <= value < 2**63:
        raise Refused('LOD plan requires exact bounded integers')
    return value


def tuple_integers(value, length, minimum=0):
    if not isinstance(value, list) or len(value) != length:
        raise Refused('LOD plan tuple differs')
    return [exact_integer(item, minimum) for item in value]


def validate(request):
    if not isinstance(request, dict) or set(request) != FIELDS or request['schema'] != SCHEMA:
        raise Refused('Invalid fixed original-SII LOD envelope')
    exact_integer(request['parent_pid'], 1)
    exact_integer(request['source_bytes'], 1)
    for key in ('source_sha256', 'tool_sha256'):
        if not isinstance(request[key], str) or not re.fullmatch('[a-f0-9]{64}', request[key]):
            raise Refused('LOD requires complete source and configured-tool digests')
    for key in ('source_path', 'tool_path', 'output_file', 'session'):
        absolute(request[key])
    iw, ih = tuple_integers(request['image_dimensions'], 2, 1)
    x, y, sw, sh = tuple_integers(request['source_rect'], 4)
    if sw < 1 or sh < 1 or x + sw > iw or y + sh > ih:
        raise Refused('LOD crop lies outside the original image')
    dw, dh, px, py = tuple_integers(request['display'], 4, -(2**63))
    if not 10 <= dw <= 4096 or not 10 <= dh <= 4096 or dw * dh > 8500000:
        raise Refused('LOD display exceeds original dimension/pixel bounds')
    # Validate supplied original lodRenderArgv DATA, not new viewport math.
    expected = [request['tool_path'], *LIMITS, request['source_path'] + '[0]',
                '-crop', f'{sw}x{sh}+{x}+{y}', '+repage', '-filter', 'Lanczos',
                '-resize', f'{dw}x{dh}!', '-depth', '8', 'PNG:' + request['output_file']]
    if request['argv'] != expected:
        raise Refused('LOD accepts only the exact original fixed render argv')
    return dw, dh, 5 * dw * dh + 65536


def hash_fd(fd, signature, expected_size=None):
    initial = os.fstat(fd)
    original = signature(initial)
    if expected_size is not None and initial.st_size != expected_size:
        raise Refused('LOD held file size differs from the pinned source size')
    # One finite sentinel byte detects growth without following a growing EOF.
    # The pre/post signature includes physical identity, size and timestamps.
    remaining = initial.st_size + 1
    os.lseek(fd, 0, os.SEEK_SET)
    digest = hashlib.sha256()
    count = 0
    while remaining:
        chunk = os.read(fd, min(1048576, remaining))
        if not chunk:
            break
        remaining -= len(chunk)
        count += len(chunk)
        if count > initial.st_size:
            raise Refused('LOD held file grew beyond its pinned initial size')
        digest.update(chunk)
    if count != initial.st_size or signature(os.fstat(fd)) != original:
        raise Refused('LOD held file changed during verification')
    os.lseek(fd, 0, os.SEEK_SET)
    return digest.hexdigest(), count, original


def unlink_created(directory, name, identity):
    if identity is None:
        return
    try:
        current = os.stat(name, dir_fd=directory, follow_symlinks=False)
        if stat.S_ISREG(current.st_mode) and (current.st_dev, current.st_ino) == identity:
            os.unlink(name, dir_fd=directory)
    except FileNotFoundError:
        pass


def tool_stream(argv, source_fd, output_fd, output_limit, directory, parent_check):
    # No own process group: original ScriptJobAsync retains helper/renderer and
    # delegates in its captured group until the actual managed terminal callback.
    environment = dict(os.environ)
    environment['MAGICK_TEMPORARY_PATH'] = str(directory)
    environment['TMPDIR'] = str(directory)
    child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             cwd=directory, env=environment, pass_fds=(source_fd,))
    selector = selectors.DefaultSelector()
    written = diagnostic_count = 0
    deadline = time.monotonic() + RENDER_SECONDS
    try:
        for pipe, kind in ((child.stdout, 'png'), (child.stderr, 'diagnostic')):
            os.set_blocking(pipe.fileno(), False)
            selector.register(pipe, selectors.EVENT_READ, kind)
        while selector.get_map():
            parent_check()
            if time.monotonic() >= deadline:
                raise Refused('Original viewport render exceeded 20 seconds')
            for key, _ in selector.select(min(.05, max(0, deadline - time.monotonic()))):
                chunk = os.read(key.fileobj.fileno(), 65536)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if key.data == 'diagnostic':
                    diagnostic_count += len(chunk)
                    if diagnostic_count > MAX_DIAGNOSTICS:
                        raise Refused('Viewport renderer diagnostics exceeded the original 10000-byte bound')
                else:
                    if written + len(chunk) > output_limit:
                        raise Refused('Viewport PNG including profile/text metadata exceeds its explicit display allocation; no truncated tile accepted')
                    view = memoryview(chunk)
                    while view:
                        amount = os.write(output_fd, view)
                        if amount <= 0:
                            raise Refused('Viewport output write could not complete')
                        view = view[amount:]
                    written += len(chunk)
        code = child.wait(timeout=max(.001, deadline - time.monotonic()))
        if code:
            raise Refused('Original configured viewport renderer failed')
        return written
    finally:
        selector.close()
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=.5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        child.stdout.close()
        child.stderr.close()


def render(request, dependencies):
    _, ResourceManager, parent, directory_open, source_open, signature, _ = dependencies
    dw, dh, output_limit = validate(request)
    parent_check = lambda: parent(request['parent_pid'], request['parent_identity'])
    parent_check()
    manager = ResourceManager(root=os.environ.get('GXTXT_RESOURCE_ROOT'),
                              storage_root=os.environ.get('GXTXT_RESOURCE_STORAGE'))
    directory = source_fd = tool_fd = output_fd = None
    created = None
    output = absolute(request['output_file'])
    success = False
    try:
        reservation = manager.inspect(request['reservation'])
        if (reservation.get('subsystem') != 'scientific_image_lod' or reservation.get('kind') != 'directory' or
                not reservation.get('managed') or not reservation.get('descendant_lease') or
                reservation.get('released') or reservation.get('removed') or
                reservation.get('owner_pid') != request['parent_pid'] or
                reservation.get('owner_identity') != request['parent_identity'] or
                reservation.get('session') != request['session'] or
                int(reservation.get('expected_bytes', 0)) < CACHE_BYTES + output_limit or
                os.environ.get('GXTXT_RESOURCE_LEASE') != reservation['id'] or
                output.parent != absolute(reservation['path']) or output.name != 'lod.png'):
            raise Refused('LOD lacks its original live reserved owner lease')
        directory = directory_open(output.parent, private=True)
        info = os.fstat(directory)
        if [info.st_dev, info.st_ino] != reservation['identity']:
            raise Refused('LOD allocation identity changed')
        source_fd = source_open(request['source_path'])
        if os.fstat(source_fd).st_size != request['source_bytes']:
            raise Refused('LOD source size differs from the pinned original source')
        source_sha, source_size, source_identity = hash_fd(source_fd, signature, request['source_bytes'])
        if source_sha != request['source_sha256'] or source_size != request['source_bytes']:
            raise Refused('LOD source bytes differ from the held original source')
        # Preserve actual configured-loader spelling/__file__ semantics. A held
        # FD+SHA and immediate path identity checks are not an atomic guarantee
        # against privileged concurrent replacement/restoration across exec.
        tool_fd = os.open(request['tool_path'], os.O_RDONLY | os.O_NONBLOCK)
        if not stat.S_ISREG(os.fstat(tool_fd).st_mode):
            raise Refused('Configured viewport runtime is not an ordinary file')
        tool_sha, _, tool_identity = hash_fd(tool_fd, signature)
        if tool_sha != request['tool_sha256']:
            raise Refused('Configured viewport runtime digest changed')
        parent_check()
        if signature(os.stat(request['tool_path'])) != tool_identity:
            raise Refused('Configured viewport runtime identity changed before execution')
        output_fd = os.open(output.name, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                            0o600, dir_fd=directory)
        info = os.fstat(output_fd)
        created = (info.st_dev, info.st_ino)
        argv = list(request['argv'])
        argv[19] = f'/proc/self/fd/{source_fd}[0]'
        argv[-1] = 'PNG:-'
        count = tool_stream(argv, source_fd, output_fd, output_limit, output.parent, parent_check)
        parent_check()
        if (signature(os.fstat(source_fd)) != source_identity or
                signature(os.fstat(tool_fd)) != tool_identity or
                signature(os.stat(request['tool_path'])) != tool_identity):
            raise Refused('LOD source or configured runtime changed during rendering')
        # Rehash the held source after the renderer, never a reopened alias.
        if hash_fd(source_fd, signature, request['source_bytes'])[:2] != (source_sha, source_size):
            raise Refused('LOD source changed during rendering')
        os.fsync(output_fd)
        digest, size, _ = hash_fd(output_fd, signature)
        info = os.fstat(output_fd)
        linked = os.stat(output.name, dir_fd=directory, follow_symlinks=False)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size != count or
                size != count or (linked.st_dev, linked.st_ino) != created or
                not stat.S_ISREG(linked.st_mode) or linked.st_nlink != 1):
            raise Refused('Viewport output identity or exact byte count changed')
        header = os.read(output_fd, 33)
        if (len(header) != 33 or header[:8] != b'\x89PNG\r\n\x1a\n' or
                header[8:16] != b'\0\0\0\rIHDR' or
                zlib.crc32(header[12:29]) != struct.unpack('>I', header[29:33])[0]):
            raise Refused('Viewport output lacks a complete original PNG header')
        width, height = struct.unpack('>II', header[16:24])
        if (width, height) != (dw, dh):
            raise Refused('Viewport PNG dimensions differ from the original plan')
        parent_check()
        success = True
        return {'source_sha256': source_sha, 'source_bytes': source_size,
                'output_sha256': digest, 'output_bytes': count, 'width': width,
                'height': height, 'source_rect': request['source_rect'], 'display': request['display']}
    finally:
        if output_fd is not None:
            os.close(output_fd)
        if directory is not None:
            if not success:
                unlink_created(directory, output.name, created)
            os.close(directory)
        for fd in (source_fd, tool_fd):
            if fd is not None:
                os.close(fd)
        manager.close()


def main():
    encoder = None
    try:
        if len(sys.argv) != 2:
            raise Refused('Fixed viewport auxiliary requires its public image runtime directory')
        dependencies = bootstrap(sys.argv[1])
        decoder, *_, encoder = dependencies
        raw = sys.stdin.buffer.readline(MAX_FRAME + 2)
        if not raw.endswith(b'\n') or len(raw) > MAX_FRAME + 1:
            raise Refused('Viewport request exceeds the original bounded frame')
        request = decoder(raw[:-1].decode('utf-8', 'strict'), lambda message, code: Refused(message))
        outcome = {'ok': True, 'result': render(request, dependencies)}
    except Refused as error:
        outcome = {'ok': False, 'error': str(error)}
    except BaseException:
        outcome = {'ok': False, 'error': 'Original viewport byte runtime or owned input/output is unavailable'}
    print(encoder(outcome) if encoder is not None else 'ok 0 error {Original viewport shared runtime is unavailable}', flush=True)
    # Parent stores ONE outcome with original Drain, then cancels(closed) and
    # waits for its original managed group callback before adoption/release.
    acknowledgement = sys.stdin.buffer.readline(65)
    if acknowledgement not in (b'', b'GXTXT_SII_LOD_ACK\n'):
        return 1
    return 0 if outcome['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
