# Fixed trusted entry into the SAME original SII engine, inside its managed Job.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII {}
proc ::GX::SII::sourceInfo {id} {tailcall ::GX::__siiCapturedSource $id}
proc ::GX::SII::_managedWorkerOwnedMiffInput {actual} {
    # Captured sources are immutable Job inputs. Only a byte-verified private
    # copy may acquire the original engine's intermediate-file ownership.
    set path [dict get $actual path]
    set channel [open $path rb]
    try {set signature [read $channel 14]} finally {close $channel}
    if {$signature ne {id=ImageMagick}} {return {}}
    if {[get $actual _sii_source_guard_kind {}] ne {document_resource}} {
        error {Captured MIFF input requires its sealed Document Resource owner}
    }
    set size [dict get $actual size_bytes];set sha [dict get $actual sha256]
    if {[file size $path] != $size || [::GX::sha256File $path] ne $sha} {
        error {Captured MIFF input bytes differ}
    }
    set owned [tempFile .miff]
    try {
        file copy -- $path $owned
        if {[file size $owned] != $size || [::GX::sha256File $owned] ne $sha} {
            error {Owned MIFF input copy differs}
        }
        return $owned
    } on error {message options} {
        catch {releaseResult $owned}
        return -options $options $message
    }
}
proc ::GX::SII::managedWorker {request output {capturedSources {}}} {
    set request [_processingNormalize $request $capturedSources]
    if {[string first HDRI [magickVersion]]<0} {error {Original SII precision processing needs configured ImageMagick HDRI}}
    set kind [dict get $request kind]
    if {$kind eq {figure}} {
        set panels {}
        foreach panel [dict get $request panels] {
            set source [dict get $panel source];set id [dict get $source dataset_id]
            set actual [sourceInfo $id]
            foreach {field expected} {sha256 source_sha256 source_revision source_revision} {
                if {[dict get $actual $field] ne [dict get $source $expected]} {error {Captured figure source association differs}}
            }
            lappend panels [dict create source_id $id source_sha [dict get $source source_sha256] steps [dict get $panel steps]]
        }
        set format [dict get $request format];set ext [expr {$format eq {png16}?{.png}:{.tif}}]
        set result [tempFile $ext]
        set facts [figureCreate $panels [dict get $request settings] [dict get $request annotations] $result $format]
        file copy -- $result [file join $output result$ext]
        previewFile $result [file join $output preview.png] 2400 2400
        return [dict create kind figure operation figure format $format result_file result$ext display_file preview.png \
            info [inspectFile $result] panel_count [dict get $facts panel_count] annotation_count [dict get $facts annotation_count]]
    }
    if {$kind ne {image}} {error {Unknown managed SII request kind}}
    set source [dict get $request source];set id [dict get $source dataset_id]
    set actual [sourceInfo $id]
    foreach {field expected} {sha256 source_sha256 source_revision source_revision} {
        if {[dict get $actual $field] ne [dict get $source $expected]} {error {Captured source association differs}}
    }
    set original [dict get $actual path]
    set ownedInput [_managedWorkerOwnedMiffInput $actual]
    if {$ownedInput ne {}} {set original $ownedInput}
    try {
        set steps [validateSteps [dict get $request steps]]
        set operation [dict get $request operation]
        if {$operation eq {process}} {
            set format [dict get $request format]
            set ext [expr {$format eq {miff}?{.miff}:($format eq {png16}?{.png}:{.tif})}]
            set result [tempFile $ext]
            processFile $original $steps $result $format
            file copy -- $result [file join $output result$ext]
            previewFile $result [file join $output preview.png] 2400 2400
            return [dict create kind image operation process format $format result_file result$ext display_file preview.png info [inspectFile $result]]
        }
        set working $original
        if {[llength $steps]} {set working [tempFile .miff];processFile $original $steps $working miff}
        set analysis [dict get $request analysis]
        set data {};set display {}
        switch -- $operation {
            inspect {set data [inspectFile $working]}
            statistics {set data [stats $working [get $analysis roi {}] [get $analysis channel All]]}
            histogram {set data [histogram $working [get $analysis channel Gray] [get $analysis roi {}]]}
            palette {set data [palette $working [get $analysis roi {}] [get $analysis colors 16]]}
            pixel {set data [pixel $working [dict get $analysis x] [dict get $analysis y]]}
            channel_preview {
                channelPreviewFile $working [file join $output channel.png] [get $analysis channel All]
                set display channel.png
            }
            default {error {Unknown original SII managed operation}}
        }
        return [dict create kind image operation $operation analysis_target [dict get $request analysis_target] \
            info [inspectFile $working] data $data display_file $display]
    } finally {
        if {$ownedInput ne {}} {releaseResult $ownedInput}
    }
}
