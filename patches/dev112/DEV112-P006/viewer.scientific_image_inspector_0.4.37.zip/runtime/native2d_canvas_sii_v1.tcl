# SII application implementation; registered by its approved public module API.
# Original SII controller within existing Canvas/Resource/History ownership.
# SPDX-License-Identifier: GPL-3.0-or-later
# Private helpers below grant no caller path, pointer, profile or metadata trust.
namespace eval ::GX::SII::CanvasApplication {variable siiSerial 0}
namespace eval ::GX::SII::CanvasApplication {variable siiLodTasks {}}
namespace eval ::GX::SII::CanvasApplication {variable extensionId viewer.scientific_image_inspector.canvas}
namespace eval ::GX::SII::CanvasApplication {
    variable stateByContext {};variable currentContext {}
    variable viewerStateByLifetime {}
}
proc ::GX::SII::CanvasApplication::fields {value allowed {required {}}} {
    if {[catch {dict size $value}]} {error {Canvas request must be a dictionary}}
    foreach key [dict keys $value] {if {$key ni $allowed} {error "Unknown Canvas field: $key"}}
    foreach key $required {if {![dict exists $value $key]} {error "Missing Canvas field: $key"}}
}
proc ::GX::SII::CanvasApplication::number {value minimum maximum label} {
    return [::GX::uiFieldNormalize [dict create type number min $minimum max $maximum] $value]
}
proc ::GX::SII::CanvasApplication::extent {width height} {
    # Same original captured-Canvas bounds; no domain/size/tolerance widening.
    foreach value [list $width $height] {
        if {![string is double -strict $value] || [catch {expr {abs($value)<Inf && $value==floor($value) && $value>=1 && $value<=16384}} valid] || !$valid} {error {Canvas dimensions must be integers from1 to16384}}
    }
    if {$width*$height>16777216} {error {Canvas exceeds the existing16777216-pixel composition limit}}
    return [list [expr {wide($width)}] [expr {wide($height)}]]
}
proc ::GX::SII::CanvasApplication::viewerRecord {window} {
    set context [::GX::viewerGuiContext $window]
    return [dict create mode [dict get $context mode] module [dict get $context module_id] \
        actor_module [dict get $context actor_module_id] provider [dict get $context provider_id] \
        context_epoch [dict get $context context_epoch] token [dict get $context session_token] \
        incarnation [dict get $context window_id] design [dict get $context design] canvas_slots [dict get $context canvas_slots]]
}
proc ::GX::SII::CanvasApplication::viewerOwns {window component handle token {incarnation {}}} {
    if {[catch {
        set viewer [viewerRecord $window]
        if {[dict get $viewer token] ne $token || ![dict exists $viewer canvas_slots $component] ||
            [dict get $viewer canvas_slots $component] ne $handle ||
            ($incarnation ne {} && [dict get $viewer incarnation] ne $incarnation)} {error stale}
        set canvas [::GX::native2DCanvasContext $handle]
        if {[dict get $canvas session] ne $token || [dict get $canvas module_id] ne [dict get $viewer module] ||
            [dict get $canvas provider_id] ne [dict get $viewer provider]} {error stale}
    }]} {return 0}
    return 1
}
proc ::GX::SII::CanvasApplication::viewerStateKey {window} {
    if {![::GX::viewerGuiDesignGuard $window]} {error {Inspector Viewer lifetime changed}}
    return [list $window [winfo id $window] [::GX::interactiveDocumentSessionToken]]
}
proc ::GX::SII::CanvasApplication::viewerStateRead {window} {
    variable viewerStateByLifetime
    set key [viewerStateKey $window]
    if {![dict exists $viewerStateByLifetime $key]} {dict set viewerStateByLifetime $key {}}
    return [dict get $viewerStateByLifetime $key]
}
proc ::GX::SII::CanvasApplication::viewerStateWrite {window path value} {
    variable viewerStateByLifetime
    if {![regexp {^sii_[a-z0-9_]+$} [lindex $path 0]]} {error {Inspector state cannot write a generic Viewer field}}
    set key [viewerStateKey $window]
    dict set viewerStateByLifetime $key {*}$path $value
    return $value
}
proc ::GX::SII::CanvasApplication::viewerState {operation window args} {
    variable viewerStateByLifetime
    switch -- $operation {
        get {return [dict get [viewerStateRead $window] {*}$args]}
        exists {
            if {[catch {set values [viewerStateRead $window]}]} {return 0}
            return [dict exists $values {*}$args]
        }
        set {return [viewerStateWrite $window [lrange $args 0 end-1] [lindex $args end]]}
        unset {
            if {![regexp {^sii_[a-z0-9_]+$} [lindex $args 0]]} {error {Inspector state cannot remove a generic Viewer field}}
            set key [viewerStateKey $window]
            if {[dict exists $viewerStateByLifetime $key {*}$args]} {dict unset viewerStateByLifetime $key {*}$args}
            return
        }
        default {error {Unknown Inspector Viewer state operation}}
    }
}
proc ::GX::SII::CanvasApplication::stateRead {handle} {
    variable stateByContext;variable currentContext
    set context [::GX::native2DCanvasContext $handle]
    set key [list $handle $context]
    if {![dict exists $stateByContext $key]} {
        dict set stateByContext $key [dict create pending {} raster_status [dict create status idle]]
    }
    # Replacement/receipt/sequence changes cannot resurrect an old pending
    # operation. Old entries remain available ONLY for their owned cleanup.
    dict set currentContext $handle $context
    return [dict create context $context values [dict get $stateByContext $key]]
}
proc ::GX::SII::CanvasApplication::stateWrite {handle path value} {
    variable stateByContext
    set record [stateRead $handle];set context [dict get $record context]
    set field [lindex $path 0]
    if {$field ni {pending raster_status} && ![regexp {^sii_[a-z0-9_]+$} $field]} {
        error {Application state cannot write a CORE-owned field}
    }
    ::GX::native2DCanvasContextCurrent $handle $context
    if {$path eq {pending}} {::GX::native2DCanvasOperationUpdate $handle $context $value}
    dict set stateByContext [list $handle $context] {*}$path $value
    return $value
}
proc ::GX::SII::CanvasApplication::stateUnset {handle path} {
    variable stateByContext
    set record [stateRead $handle];set context [dict get $record context]
    set field [lindex $path 0]
    if {$field ni {pending raster_status} && ![regexp {^sii_[a-z0-9_]+$} $field]} {
        error {Application state cannot remove a CORE-owned field}
    }
    ::GX::native2DCanvasContextCurrent $handle $context
    if {$path eq {pending}} {::GX::native2DCanvasOperationUpdate $handle $context {}}
    if {[dict exists $stateByContext [list $handle $context] {*}$path]} {
        dict unset stateByContext [list $handle $context] {*}$path
    }
}
proc ::GX::SII::CanvasApplication::stateRebind {handle before after {committed 0}} {
    variable stateByContext;variable currentContext
    ::GX::native2DCanvasContextCurrent $handle $after
    foreach key {handle canvas_id module_id provider_id document_id session} {
        if {[dict get $before $key] ne [dict get $after $key]} {error {Application state cannot move to another Canvas owner}}
    }
    if {[dict get $before document_receipt generation] ne [dict get $after document_receipt generation]} {error {Application state cannot move to a replaced Document}}
    set oldKey [list $handle $before];set newKey [list $handle $after]
    if {![dict exists $stateByContext $oldKey]} {error {Original application state is unavailable}}
    set values [dict get $stateByContext $oldKey]
    if {$committed} {
        # A new accepted native presentation cannot reuse the old scene/photo
        # caches. Durable recipes remain in the original Document snapshot.
        # The accepted candidate belongs to the predecessor context. Keeping it
        # here falsely blocks the next editor action after a successful commit.
        foreach key {sii_lod_ready sii_display_cache sii_navigation_pan sii_candidate} {dict unset values $key}
        dict set values pending {}
    }
    dict set stateByContext $newKey $values
    dict set currentContext $handle $after
    # Old entries remain available for their original outstanding cleanup.
    return $after
}
proc ::GX::SII::CanvasApplication::commitSnapshot {handle held snapshot description {options {}}} {
    set before [dict get [stateRead $handle] context]
    set result [::GX::native2DCanvasCommitSnapshot $handle $held $snapshot $description $options]
    stateRebind $handle $before [::GX::native2DCanvasContext $handle] 1
    return $result
}
proc ::GX::SII::CanvasApplication::retainOutputs {handle references} {
    set before [dict get [stateRead $handle] context]
    set after [::GX::native2DCanvasRetainResources $handle $before $references]
    if {$after ne $before} {stateRebind $handle $before $after 1}
    return $after
}
proc ::GX::SII::CanvasApplication::retireOperation {handle} {
    set before [dict get [stateRead $handle] context]
    set after [::GX::native2DCanvasOperationRetire $handle $before]
    stateRebind $handle $before $after
    return $after
}
proc ::GX::SII::CanvasApplication::stateCaptured {handle context} {
    variable stateByContext
    set key [list $handle $context]
    if {![dict exists $stateByContext $key]} {error {Unknown application lifetime}}
    return [dict get $stateByContext $key]
}
proc ::GX::SII::CanvasApplication::stateOwns {handle context} {
    variable stateByContext
    if {[catch {::GX::native2DCanvasContextCurrent $handle $context}]} {return 0}
    return [dict exists $stateByContext [list $handle $context]]
}
proc ::GX::SII::CanvasApplication::stateForget {handle context} {
    # ONLY after this application's actual owned cleanup has completed. No
    # Resource/Job release, success or global drain is inferred by this helper.
    variable stateByContext;variable currentContext
    set key [list $handle $context]
    if {[dict exists $stateByContext $key]} {dict unset stateByContext $key}
    if {[dict exists $currentContext $handle] && [dict get $currentContext $handle] eq $context} {
        dict unset currentContext $handle
    }
}
proc ::GX::SII::CanvasApplication::appRecord {handle {active 1}} {
    # Local APP data assembled ONLY from public immutable context metadata and
    # the module lifetime map. NO native/geometry/UI/scheduler/CORE-row fields.
    variable currentContext
    if {$active} {
        set state [stateRead $handle];set context [dict get $state context]
        ::GX::native2DCanvasContextCurrent $handle $context
        set values [dict get $state values]
    } else {
        if {![dict exists $currentContext $handle]} {error {Unknown application lifetime}}
        set context [dict get $currentContext $handle]
        set values [stateCaptured $handle $context]
    }
    return [dict merge [dict create context $context document [dict get $context document_id] \
        receipt [dict get $context document_receipt] session [dict get $context session] \
        module [dict get $context module_id] provider [dict get $context provider_id] \
        sequence [dict get $context sequence] canvas_generation [dict get $context canvas_generation]] $values]
}
proc ::GX::SII::CanvasApplication::canvasStamp {handle} {
    return [::GX::native2DCanvasContext $handle]
}
proc ::GX::SII::CanvasApplication::stampContext {stamp} {
    return [dict remove $stamp sii_source sii_target sii_layer]
}
proc ::GX::SII::CanvasApplication::canvasCurrent {handle stamp {allowViewOnlyPan 0}} {
    ::GX::native2DCanvasOperationCurrent $handle [stampContext $stamp] $allowViewOnlyPan
    return [appRecord $handle]
}
proc ::GX::SII::CanvasApplication::canvasOwnerSame {handle stamp} {
    if {[catch {set actual [::GX::native2DCanvasContext $handle]}]} {return 0}
    set expected [stampContext $stamp]
    # Admission cancellation retires sequence, but cannot cross a native
    # incarnation or Document receipt even if the public handle is reused.
    return [expr {[dict remove $actual sequence] eq [dict remove $expected sequence]}]
}
proc ::GX::SII::CanvasApplication::geometryRestore {geometry reference} {
    return [dict get [::GX::native2DGeometryCall $geometry restore_resource [dict create resource $reference]] object_token]
}
proc ::GX::SII::CanvasApplication::geometryStore {geometry object {metadata {}}} {
    return [::GX::native2DGeometryCall $geometry export_resource [dict create object_token $object metadata $metadata]]
}
proc ::GX::SII::CanvasApplication::geometryAttributes {geometry object} {
    return [dict get [::GX::native2DGeometryCall $geometry identity [dict create object_token $object]] attributes]
}
proc ::GX::SII::CanvasApplication::geometryAttribute {geometry object key value} {
    return [::GX::native2DGeometryCall $geometry identity [dict create object_token $object key $key value $value]]
}
proc ::GX::SII::CanvasApplication::geometryImageState {geometry object} {
    return [dict get [::GX::native2DGeometryCall $geometry image_get [dict create object_token $object]] image_state]
}
proc ::GX::SII::CanvasApplication::geometryImageMap {geometry object point {inverse 0}} {
    return [dict get [::GX::native2DGeometryCall $geometry image_map [dict create object_token $object point $point inverse $inverse]] point]
}
proc ::GX::SII::CanvasApplication::geometryDevice {geometry point} {
    return [dict get [::GX::native2DGeometryCall $geometry world_to_device [dict create point $point]] point]
}
proc ::GX::SII::CanvasApplication::geometryWorld {geometry point} {
    return [dict get [::GX::native2DGeometryCall $geometry device_to_world [dict create point $point]] point]
}
proc ::GX::SII::CanvasApplication::appEditCurrent {handle held} {
    ::GX::native2DCanvasEditCurrent $handle $held
    return [appRecord $handle]
}
proc ::GX::SII::CanvasApplication::canvasState {operation handle args} {
    switch -- $operation {
        get {return [dict get [dict get [stateRead $handle] values] {*}$args]}
        exists {
            if {[catch {set state [stateRead $handle]}]} {return 0}
            return [dict exists [dict get $state values] {*}$args]
        }
        set {
            if {[llength $args]<2} {error {Application state requires a field and value}}
            return [stateWrite $handle [lrange $args 0 end-1] [lindex $args end]]
        }
        unset {stateUnset $handle $args;return}
        default {error {Unknown application state operation}}
    }
}
proc ::GX::SII::CanvasApplication::viewerHandle {window component} {
    set context [::GX::viewerGuiCanvasContext $window $component]
    return [dict get $context handle]
}
proc ::GX::SII::CanvasApplication::heldSnapshot {handle held} {
    # Held is an opaque CORE capability. Do not unpack, amend or refresh it.
    ::GX::native2DCanvasEditCurrent $handle $held
    set snapshot [::GX::native2DCanvasSnapshot $handle]
    ::GX::native2DCanvasEditCurrent $handle $held
    return $snapshot
}
proc ::GX::SII::CanvasApplication::snapshotLeaf {snapshot logical} {
    foreach item [dict get $snapshot objects] {if {[dict get $item logical_id] eq $logical} {return $item}}
    error {Canvas raster target is not an owned leaf object}
}
proc ::GX::SII::CanvasApplication::snapshotEditable {snapshot item} {
    # Exact original inert-snapshot predicate; commit remains original CORE.
    set style [dict get $item style]
    if {[dict get $style locked] || ![dict get $style visible] || ![dict get $style selectable]} {error {Canvas raster object is locked, hidden or unselectable}}
    foreach layer [dict get $snapshot layers] {
        if {[dict get $layer logical_id] ne [dict get $item layer_logical_id]} continue
        set properties [dict get $layer properties]
        if {[dict get $properties locked] || ![dict get $properties visible] || ![dict get $properties selectable]} {error {Canvas raster layer is locked, hidden or unselectable}}
        return
    }
    error {Canvas raster object has no owned layer}
}
proc ::GX::SII::CanvasApplication::canvasParameters {} {
    # App-owned defaults reproduce ORIGINAL direct Flatten's explicit fixed
    # {kind figure format tiff32f}; generic CORE now supplies {} for Flatten.
    # Publish's existing explicit format remains restricted to the same choices.
    return [dict create kind {type choice default figure values {figure}} \
        format {type choice default tiff32f values {png16 tiff16 tiff32f}}]
}
proc ::GX::SII::CanvasApplication::imageCanvasRecipe {request capture purpose} {
    if {$purpose ni {publish flatten}} {error {Unknown original Canvas recipe purpose}}
    if {[lsort [dict keys $request]] ne {format kind} ||
        [dict get $request kind] ne {figure} ||
        [dict get $request format] ni {png16 tiff16 tiff32f}} {
        error {Scientific Canvas requires its fixed original figure output format}
    }
    if {[lsort [dict keys $capture]] ne {canonical_sources projection resources}} {
        error {Scientific Canvas requires its complete original capture}
    }
    # EXACT original inert recipe construction from f387's owning preparation.
    # The generic CORE retains capture/currentness/lineage/byte/CAS authority.
    return [dict create kind figure format [dict get $request format] \
        settings [dict get $capture projection settings] panels {} annotations {}]
}
proc ::GX::SII::CanvasApplication::captureProjection {owner held frame} {
    # Capture is the ORIGINAL owning capability, never a new edit or a client
    # recipe. The app only assembles its existing projection/schema from facts.
    ::GX::viewerGuiCanvasOwnerCurrent $owner $held
    set result [_nativeCanvasSiiCaptureLiveProjection [dict get $owner handle] $held $frame]
    ::GX::viewerGuiCanvasOwnerCurrent $owner $held
    return $result
}
proc ::GX::SII::CanvasApplication::commandContracts {} {
    set commands {}
    foreach action [_nativeCanvasSiiEditorVerbs] {
        set effect presentation;set grants {}
        if {$action in {open_local source_changed preview grayscale invert run_analysis publish accept reset_image remove_step reset_figure upsert_entity remove_entity annotation_paste restore_original image_undo image_redo figure_undo figure_redo}} {
            set effect submit
        }
        if {$action eq {cancel}} {dict set grants SCIENTIFIC_EXECUTION_API_v1 cancel}
        if {$action eq {publish}} {set effect publish}
        if {$action in {image_undo image_redo figure_undo figure_redo}} {
            dict set grants SCIENTIFIC_RECIPE_API_v1 scientificHistoryViewerNavigate
        }
        dict set commands $action [dict create arguments {record {}} \
            result {record {status text ready bool retry_allowed bool submission_id text job_id text}} \
            effect $effect required_grants $grants \
            command [list ::GX::SII::CanvasApplication::command $action]]
    }
    return $commands
}
proc ::GX::SII::CanvasApplication::command {action window component arguments} {
    if {[dict size $arguments]} {error {Inspector commands use their declared Viewer field roles}}
    set result [_viewerGuiSiiEditor $window $component [dict create action $action]]
    # The old owning Host ignored the controller's rich return value. Generic
    # extension transport has this finite summary; full original reports and
    # SII's separately registered processing results remain under their owners.
    set summary {}
    foreach key {status ready retry_allowed submission_id job_id} {
        if {[dict exists $result $key]} {dict set summary $key [dict get $result $key]}
    }
    return $summary
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiModule {} {
    variable extensionId
    set registered [::GX::native2DCanvasExtensionDescribe $extensionId]
    if {[dict get $registered module_id] ne {viewer.scientific_image_inspector} ||
        [dict get $registered api_id] ne {SCIENTIFIC_IMAGE_INSPECTOR_API_v1} ||
        [dict get $registered api_version] ne {1}} {
        error {The original activated Inspector extension is unavailable}
    }
    return $extensionId
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCropRequire {} {
    set actual [::GX::native2DEnsure]
    if {{source_cropped_display_assets} ni [dict get $actual capabilities]} {
        error {The loaded Native2D adapter cannot present source-cropped SII LOD. Restart with the matching installed CORE adapter; a reduced preview cannot replace source pixels}
    }
    return $actual
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiEditorVerbs {} {
    return {open_local source_changed grayscale invert editor_changed page_changed value_changed validate preview status accept discard cancel reset_image remove_step publish upsert_entity remove_entity run_analysis reset_figure figure_undo figure_redo refresh_sources copy_report close annotation_select_all annotation_select_none annotation_copy annotation_paste image_undo image_redo comparison_toggle grid_toggle history_toggle pending_toggle actual_pixels basic_editor advanced_editor figure_studio edit_source annotation_mode annotation_tools restore_original sidebar_settings viewer_settings}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentationActions {} {
    return {grid_toggle history_toggle comparison_toggle pending_toggle actual_pixels sidebar_settings viewer_settings}
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiRoles {window component} {
    if {![::GX::viewerGuiDesignGuard $window]} {error {Inspector Viewer lifetime changed}}
    _nativeCanvasSiiModule
    set canvas [::GX::viewerGuiDesignComponent $window $component]
    if {[dict get $canvas type] ne {native2d} ||
        [::GX::datasetPublicationV2DictDefault [dict get $canvas properties] source_kind {}] ne {canvas}} {
        error {Inspector requires its declared Native2D source_kind canvas component}
    }
    set roles {sii_mode choice sii_item choice sii_parameter_page choice sii_value1 string sii_value2 string sii_value3 string sii_value4 string sii_schema1 label sii_schema2 label sii_schema3 label sii_schema4 label sii_report log sii_scope choice sii_step_index string sii_format choice sii_output_id string sii_entity_id string sii_analysis_target choice sii_analysis_channel choice sii_analysis choice sii_palette_colors choice sii_pixel_x string sii_pixel_y string}
    dict for {id kind} $roles {
        set definition [::GX::viewerGuiDesignComponent $window $id]
        if {$kind in {label log}} {
            if {[dict get $definition type] ne $kind} {error "SII editor role $id requires its declared $kind component"}
        } elseif {[dict get $definition type] ne {field} || [::GX::datasetPublicationV2DictDefault [dict get $definition properties] datatype string] ne $kind} {error "SII editor role $id has a different declared field datatype"}
    }
    return $roles
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiGrant {window api operations} {
    tailcall ::GX::viewerGuiExtensionRequire $window $api $operations
}
# Source availability is a pure veto for the EXISTING command owner. It does
# not recover a root, query a service, prepare work or grant admission.
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSourceApplicable {window action} {
    if {$action ne {bind_source} || [catch {set instance [viewerRecord $window]}] ||
        [catch {::GX::viewerGuiExtensionRequire $window VIEWER_GUI_HOST_API_v1 canvas_command}]} {return 0}
    return [expr {[dict get $instance mode] eq {runtime} &&
        [::GX::datasetPublicationV2DictDefault [dict get $instance design requirements] SCIENTIFIC_IMAGE_INSPECTOR_API_v1 0]==1}]
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSourceActionEnabled {window action} {
    if {![_viewerGuiSiiSourceApplicable $window $action]} {return {}}
    set instance [viewerRecord $window]
    if {![dict exists $instance canvas_slots] || ![dict size [dict get $instance canvas_slots]]} {return 0}
    # The shared Source command must not advertise an unready Canvas target.
    # The actual explicit command still repeats all original scientific guards.
    dict for {component handle} [dict get $instance canvas_slots] {
        if {[catch {set row [appRecord $handle]}]} {return 0}
        if {[dict get $row pending] ne {} || [dict exists $row sii_candidate] || [dict exists $row sii_source_starting] ||
            ![dict exists $row sii_readiness state] || [dict get $row sii_readiness state] ne {READY} ||
            ![_nativeCanvasSiiReadinessOwns [dict get $row sii_readiness context]]} {return 0}
    }
    return 1
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSourceControlsRefresh {window} {
    if {![_viewerGuiSiiSourceApplicable $window bind_source] || ![::GX::viewerGuiDesignGuard $window]} return
    # Use the original command owner, including authored availability, menus
    # and keyboard predicates; never directly grant a widget an action.
    ::GX::viewerCommandWidgetsRefresh $window
    ::GX::viewerCommandMenusRefresh $window
    set instance [viewerRecord $window]
    if {[catch {::GX::viewerGuiComponentHost $window sii_report}] || ![dict exists $instance canvas_slots]} return
    dict for {component handle} [dict get $instance canvas_slots] {
        if {[catch {::GX::native2DCanvasContext $handle}]} continue
        set row [appRecord $handle]
        # Metadata availability must not replace an actual scientific
        # completion/analysis report already owned by this live Canvas.
        if {[dict exists $row sii_job job] && [dict get $row sii_job job] ne {}} continue
        if {![dict exists $row sii_readiness]} {
            if {[dict exists $row raster_status status] && [dict get $row raster_status status] eq {recovery_unknown}} {
                ::GX::viewerGuiDesignTextSet $window sii_report "Source owner unavailable:\n[dict get $row raster_status]"
            } else {::GX::viewerGuiDesignTextSet $window sii_report {Source owner: preparing original metadata. Place image is unavailable until the current owner is ready.}}
        } elseif {[dict get $row sii_readiness state] in {PENDING UNKNOWN RECOVERY_REQUIRED RETIRED}} {
            if {[dict get $row sii_readiness state] eq {PENDING}} {
                set status {status recovery_pending ready 0 retry_allowed 0}
            } else {set status [::GX::datasetPublicationV2DictDefault $row raster_status {status recovery_unknown ready 0 retry_allowed 0}]}
            ::GX::viewerGuiDesignTextSet $window sii_report "Source owner [dict get $row sii_readiness state] (no science started by readiness):\n$status"
        } elseif {[dict get $row sii_readiness state] eq {READY} && [dict get $row pending] eq {} && ![dict exists $row sii_candidate]} {
            ::GX::viewerGuiDesignTextSet $window sii_report {Source owner ready. Place image uses the current selection and repeats the original source and Document guards.}
        }
    }
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSourceAttach {window {acknowledgedJob {}} {finishedSerial {}}} {
    if {![_viewerGuiSiiSourceApplicable $window bind_source] || ![::GX::viewerGuiDesignGuard $window]} return
    _viewerGuiSiiSourceControlsRefresh $window
    set instance [viewerRecord $window]
    if {![dict exists $instance canvas_slots]} return
    dict for {component handle} [dict get $instance canvas_slots] {
        set row [::GX::SII::CanvasApplication::appRecord $handle]
        if {[dict exists $row sii_source_starting]} continue
        if {[dict exists $row sii_source_attach]} {
            set prior [dict get $row sii_source_attach context]
            if {[dict get $prior window] eq $window && [dict get $prior component] eq $component &&
                [dict get $prior handle] eq $handle && [dict get $prior token] eq [dict get $instance token] &&
                [dict get $prior incarnation] eq [dict get $instance incarnation]} continue
            after cancel [dict get $row sii_source_attach timer]
            ::GX::SII::CanvasApplication::canvasState unset $handle sii_source_attach
        }
        if {[dict exists $row sii_candidate] || ([dict get $row pending] ne {} && ![dict exists [dict get $row pending] recovery])} continue
        if {[dict exists $row sii_readiness]} {
            set saved [dict get $row sii_readiness]
            set owns [_nativeCanvasSiiReadinessOwns [dict get $saved context]]
            if {[dict get $saved state] eq {PENDING} &&
                $finishedSerial ne [dict get $saved context serial]} continue
            if {$owns && [dict get $saved state] in {READY UNKNOWN RECOVERY_REQUIRED RETIRED ACKNOWLEDGING}} continue
            if {[dict get $saved state] eq {CONSUMED} && [dict exists $row sii_job job] &&
                [dict get $row sii_job job] ne {} &&
                ![::GX::datasetPublicationV2DictDefault [dict get $row sii_job] handled 0] &&
                $acknowledgedJob ne [dict get $row sii_job job]} continue
        }
        # Only an ownership tuple is deferred. No action, selected Dataset,
        # request, model or scientific continuation is captured/replayed.
        set context [dict create window $window component $component handle $handle token [dict get $instance token] incarnation [dict get $instance incarnation]]
        set timer [after 0 [list ::GX::SII::CanvasApplication::_viewerGuiSiiSourceAttached $context]]
        ::GX::SII::CanvasApplication::canvasState set $handle sii_source_attach [dict create context $context timer $timer]
    }
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSourceAttached {context} {
    dict with context {}
    if {![::GX::SII::CanvasApplication::canvasState exists $handle sii_source_attach context] ||
        [::GX::SII::CanvasApplication::canvasState get $handle sii_source_attach context] ne $context} return
    ::GX::SII::CanvasApplication::canvasState unset $handle sii_source_attach
    if {![viewerOwns $window $component $handle $token [dict get $context incarnation]]} return
    if {[catch {
        _viewerGuiSiiRoles $window $component
        _viewerGuiSiiGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
        _viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
        _nativeCanvasSiiModule
        _nativeCanvasSiiReadiness $window $component $handle
    } message]} {
        if {[viewerOwns $window $component $handle $token [dict get $context incarnation]]} {
            ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status recovery_unknown ready 0 retry_allowed 0 error $message]
            ::GX::viewerGuiDesignTextSet $window sii_report "Source owner unavailable:\n$message"
            ::GX::viewerGuiTraceEmit $window $component source_owner [dict create status failed message $message]
        }
    }
    _viewerGuiSiiSourceControlsRefresh $window
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSourceAttachmentFinished {context} {
    dict with context {}
    if {![::GX::SII::CanvasApplication::canvasState exists $handle sii_readiness context serial] ||
        [::GX::SII::CanvasApplication::canvasState get $handle sii_readiness context serial] ne $serial ||
        ![viewerOwns $window $component $handle $token [dict get $context incarnation]]} return
    # A completed stale metadata callback may refresh the NEW attachment,
    # without applying its stale READY or starting any scientific action.
    if {![_nativeCanvasSiiReadinessOwns $context]} {_viewerGuiSiiSourceAttach $window {} $serial}
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiEditor {window component request} {
    fields $request action action
    set action [dict get $request action]
    if {$action ni [_nativeCanvasSiiEditorVerbs]} {error {Unknown fixed SII editor action}}
    if {![::GX::viewerGuiDesignGuard $window]} {error {SII editor Viewer or Session lifetime ended}}
    _viewerGuiSiiRoles $window $component
    _viewerGuiSiiGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    if {$action in {open_local source_changed preview grayscale invert run_analysis publish accept reset_image remove_step reset_figure upsert_entity remove_entity annotation_paste restore_original image_undo image_redo figure_undo figure_redo}} {
        _viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    }
    if {$action eq {cancel}} {_viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 cancel}
    if {$action eq {publish}} {_viewerGuiSiiGrant $window DATASET_FILE_PUBLICATION_API_v1 datasetFilePublicationPublish}
    if {$action in {image_undo image_redo figure_undo figure_redo}} {_viewerGuiSiiGrant $window SCIENTIFIC_RECIPE_API_v1 scientificHistoryViewerNavigate}
    _nativeCanvasSiiModule
    set handle [viewerHandle $window $component]
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {![dict exists $row sii_readiness] && [dict get $row pending] eq {} && ![dict exists $row sii_candidate]} {
        _nativeCanvasSiiReadiness $window $component $handle
        set row [::GX::SII::CanvasApplication::appRecord $handle]
    }
    if {[dict exists [dict get $row pending] recovery] && $action ni {status cancel discard source_changed} && $action ni [_nativeCanvasSiiPresentationActions]} {
        return [dict merge [dict get $row raster_status] {ready 0 retry_allowed 0}]
    }
    set candidateAnalysis [expr {$action eq {run_analysis} && [_nativeCanvasSiiCandidateAnalysis $row]}]
    if {([dict get $row pending] ne {} || [dict exists $row sii_candidate]) && !$candidateAnalysis && $action ni {source_changed status accept discard cancel close copy_report} && $action ni [_nativeCanvasSiiPresentationActions]} {
        error {Accept, discard or cancel the current SII preview before changing its editor or scientific state}
    }
    if {$action in {editor_changed page_changed value_changed validate basic_editor advanced_editor figure_studio annotation_mode annotation_tools}} {
        set result [_viewerGuiSiiEditorFields $window $handle $action]
    } else {set result [_nativeCanvasSiiEditorAction $window $component $handle $action]}
    if {[::GX::viewerGuiDesignGuard $window]} {
        ::GX::viewerGuiCanvasCapture $window
        set status [expr {$action eq {source_changed} && [dict exists $result ready] && ![dict get $result ready] ? {pending} : {completed}}]
        ::GX::viewerGuiTraceEmit $window $component canvas_command [dict create status $status operation sii_editor action $action]
    }
    return $result
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiSchema {mode item} {
    switch -- $mode {
        Operation {return [dict get [::GX::SII::catalogGet $item] params]}
        Preset {
            if {$item eq {Manual adjustments}} {return {{brightness number 0 -100 100} {contrast number 0 -100 100} {gamma number 1 0.1 4} {degrees number 0 -180 180}}}
            foreach preset [::GX::SII::basicPresetCatalog] {if {[lindex $preset 0] eq $item} {return {}}}
            error {Unknown original SII preset}
        }
        {Figure settings} {return {{width int 2400 120 12000} {height int 1600 120 12000} {margin int 32 0 1000} {gutter int 24 0 1000} {layout enum grid {} {} {grid horizontal vertical}} {background color #FFFFFF}}}
        Panel {return {}}
        Annotation {
            if {$item ni {text line arrow rectangle ellipse}} {error {Unknown original annotation kind}}
            set fields {{x1 int 0} {y1 int 0}}
            if {$item ne {text}} {lappend fields {x2 int 100} {y2 int 100}}
            lappend fields {color color #FFCC00} {stroke int 4}
            if {$item eq {text}} {
                lappend fields {text text A} {size int 46} {font_family text DejaVu-Sans} {font_unit enum px {} {} {px pt}} {font_value number 46} {font_dpi optional_int {}} {box_width optional_int {}} {box_height optional_int {}}
            }
            lappend fields {rotation number 0} {pivot_x optional_number {}} {pivot_y optional_number {}} {name text {}}
            return $fields
        }
        default {error {Unknown original SII editor mode}}
    }
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiTextFontDraft {before values} {
    # Synchronize only an explicit edit of the mounted text controls. Existing
    # Workspace/annotation declarations are never rewritten on hydration.
    set changed {}
    foreach key {size font_unit font_value font_dpi} {
        if {[dict get $before $key] ne [dict get $values $key]} {lappend changed $key}
    }
    if {![llength $changed]} {return $values}
    set unit [dict get $values font_unit]
    if {$unit ni {px pt}} {error {Font unit must be px or pt}}
    set dpi [dict get $values font_dpi]
    if {$dpi eq {}} {set dpi [::GX::SII::annotationFontDpi]}
    set dpi [::GX::SII::figureValidInt $dpi 36 2400 {Font rendering DPI}]
    # A unit switch preserves the existing pixel size. The numeric value in
    # the selected unit changes, as in the original on-image text toolbar.
    if {{font_unit} in $changed} {
        if {{size} in $changed || {font_value} in $changed || {font_dpi} in $changed} {
            error {Change the font unit separately from its size or resolution}
        }
        set pixels [::GX::SII::figureValidInt [dict get $before size] 8 1200 {Font size in image pixels}]
        set value [expr {$unit eq {pt} ? [format %.17g [expr {$pixels*72.0/$dpi}]] : $pixels}]
    } elseif {{size} in $changed} {
        if {{font_value} in $changed || {font_dpi} in $changed} {
            error {Change pixel size separately from font value or resolution}
        }
        set pixels [::GX::SII::figureValidInt [dict get $values size] 8 1200 {Font size in image pixels}]
        set value [expr {$unit eq {pt} ? [format %.17g [expr {$pixels*72.0/$dpi}]] : $pixels}]
    } elseif {$unit eq {px} && $changed eq {font_dpi}} {
        # Old records may declare a display value independent of their actual
        # pixel size. A DPI-only pixel edit preserves that actual size and
        # normalizes the display declaration only for this explicit user edit.
        set pixels [::GX::SII::figureValidInt [dict get $before size] 8 1200 {Font size in image pixels}]
        set value $pixels
    } else {
        # Editing points keeps the declared physical size; a DPI edit changes
        # its pixel size. Pixel units remain independent of the DPI setting.
        set value [dict get $values font_value]
        if {![string is double -strict $value] || ![expr {double($value)>=1 && double($value)<=1200}]} {
            error {Font display size out of bounds}
        }
        set pixels [expr {round(double($value)*($unit eq {pt} ? $dpi/72.0 : 1.0))}]
        set pixels [::GX::SII::figureValidInt $pixels 8 1200 {Font size in image pixels}]
    }
    if {![expr {double($value)>=1 && double($value)<=1200}]} {error {Font display size out of bounds}}
    dict set values size $pixels
    # Keep accepted user precision on value/DPI edits. Derived point values
    # above use round-trip-safe formatting before their pixel size is retained.
    dict set values font_value $value
    dict set values font_dpi $dpi
    return $values
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiEditorFields {window handle action} {
    set values [::GX::viewerGuiDesignValues $window]
    set draft [::GX::datasetPublicationV2DictDefault [viewerStateRead $window] sii_editor {}]
    # GUI values have already been restored by the original Workspace owner.
    # Retire only the lifetime-local editor projection, never a saved recipe.
    if {$action eq {restore_editor}} {set draft {}}
    set hydrate [expr {$draft eq {} && $action in {restore_editor value_changed}}]
    # Commit the PREVIOUS page before changing schema/page. This is inert
    # editor draft state, not a scientific recipe or a second image store.
    if {$draft ne {}} {
        set previousValues [dict get $draft values]
        set start [expr {4*([dict get $draft page]-1)}]
        for {set slot 1} {$slot<=4} {incr slot} {
            set definition [lindex [dict get $draft schema] [expr {$start+$slot-1}]]
            if {$definition ne {}} {dict set draft values [lindex $definition 0] [dict get $values sii_value$slot]}
        }
        if {[dict get $draft mode] eq {Annotation} && [dict get $draft item] eq {text}} {
            dict set draft values [_viewerGuiSiiTextFontDraft $previousValues [dict get $draft values]]
        }
    }
    if {$action in {basic_editor advanced_editor figure_studio annotation_mode annotation_tools}} {
        set mode [dict get {basic_editor Preset advanced_editor Operation figure_studio {Figure settings} annotation_mode Annotation annotation_tools Annotation} $action]
        ::GX::viewerGuiDesignValueSet $window sii_mode $mode
        dict set values sii_mode $mode
        set action editor_changed
    }
    set mode [dict get $values sii_mode];set item [dict get $values sii_item]
    set choices {}
    switch -- $mode {
        Operation {set choices [dict keys $::GX::SII::catalog]}
        Preset {set choices [linsert [lmap preset [::GX::SII::basicPresetCatalog] {lindex $preset 0}] 0 {Manual adjustments}]}
        Annotation {set choices {text line arrow rectangle ellipse}}
        {Figure settings} {set choices settings}
        Panel {set choices panel}
        default {error {Unknown original SII editor mode}}
    }
    ::GX::viewerGuiDesignChoicesSet $window sii_item $choices
    if {$item ni $choices} {set item [lindex $choices 0];::GX::viewerGuiDesignValueSet $window sii_item $item}
    if {$draft eq {} || [dict get $draft mode] ne $mode || [dict get $draft item] ne $item} {
        set schema [_viewerGuiSiiSchema $mode $item];set parameters {}
        foreach definition $schema {dict set parameters [lindex $definition 0] [lindex $definition 2]}
        set page 1
        if {$hydrate} {
            set page [::GX::uiFieldNormalize {type integer min 1 max 6} [dict get $values sii_parameter_page]]
            set start [expr {4*($page-1)}]
            for {set slot 1} {$slot<=4} {incr slot} {
                set definition [lindex $schema [expr {$start+$slot-1}]]
                if {$definition ne {}} {dict set parameters [lindex $definition 0] [dict get $values sii_value$slot]}
            }
        }
        set draft [dict create mode $mode item $item schema $schema values $parameters page $page]
        ::GX::viewerGuiDesignValueSet $window sii_parameter_page $page
    } elseif {$action eq {page_changed}} {
        set page [dict get $values sii_parameter_page]
        if {![string is entier -strict $page] || $page<1 || $page>6} {error {Choose an existing SII parameter page}}
        dict set draft page $page
    }
    viewerStateWrite $window sii_editor $draft
    if {$action eq {validate}} {
        set value [_viewerGuiSiiEditorValue $window]
        ::GX::viewerGuiDesignTextSet $window sii_report "Original SII validator accepted $mode/$item\n$value"
        return [dict create status validated mode $mode item $item]
    }
    set start [expr {4*([dict get $draft page]-1)}]
    for {set slot 1} {$slot<=4} {incr slot} {
        set definition [lindex [dict get $draft schema] [expr {$start+$slot-1}]]
        set label {};set value {}
        if {$definition ne {}} {
            lassign $definition name type default low high enum
            set label "$name ($type)"
            if {$low ne {} || $high ne {}} {append label " $low .. $high"}
            if {$enum ne {}} {append label " [join $enum { / }]"}
            set value [dict get $draft values $name]
        }
        ::GX::viewerGuiDesignValueSet $window sii_schema$slot $label
        ::GX::viewerGuiDesignValueSet $window sii_value$slot $value
    }
    set report "$mode / $item\nParameter page [dict get $draft page]. Full original validators run before preview or commit."
    if {$mode eq {Operation}} {append report "\n[::GX::SII::operationStatus $item]\n[dict get [::GX::SII::catalogGet $item] about]"}
    ::GX::viewerGuiDesignTextSet $window sii_report $report
    return [dict create status ready mode $mode item $item page [dict get $draft page]]
}
proc ::GX::SII::CanvasApplication::_viewerGuiSiiEditorValue {window} {
    set draft [viewerState get $window sii_editor]
    set mode [dict get $draft mode];set item [dict get $draft item];set values [dict get $draft values]
    switch -- $mode {
        Operation {return [::GX::SII::validate $item $values]}
        Preset {
            if {$item eq {Manual adjustments}} {
                set steps {}
                foreach pair [::GX::SII::quickAdjustmentOperations $values] {
                    lassign $pair op parameters
                    lappend steps [dict create op $op params $parameters]
                }
                return [::GX::SII::validateSteps $steps]
            }
            foreach preset [::GX::SII::basicPresetCatalog] {
                if {[lindex $preset 0] ne $item} continue
                set steps {};foreach pair [lindex $preset 2] {lassign $pair op parameters;lappend steps [dict create op $op params $parameters]}
                return [::GX::SII::validateSteps $steps]
            }
            error {Unknown original SII preset}
        }
        Annotation {
            set annotation [dict create kind $item]
            dict for {name value} $values {if {$value ne {} || $name in {text name}} {dict set annotation $name $value}}
            return $annotation
        }
        default {return $values}
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPersistedReference {reference owner} {
    set document [dict get $reference document_id]
    if {[dict get $owner id] ne $document || [dict get $owner generation] ne [dict get $reference owner_generation]} {error {SII Resource owner generation changed}}
    # Use the SAME authoritative graph scanner as native Workspace portability
    # and Resource collection. Never parse a marker out of an arbitrary string.
    foreach stored [::GX::interactiveDocumentResourceReferences [dict get $owner payload] $document] {
        set equal 1
        foreach field {api_id document_id owner_generation sha256 size_bytes} {
            if {![dict exists $stored $field] || [dict get $stored $field] ne [dict get $reference $field]} {set equal 0;break}
        }
        if {!$equal} continue
        foreach field {source_job_id source_output_token source_generation} {
            if {![dict exists $stored metadata $field] || ![dict exists $reference metadata $field] ||
                [dict get $stored metadata $field] ne [dict get $reference metadata $field]} {set equal 0;break}
        }
        if {$equal} {return 1}
    }
    return 0
}
# Read-only application projection. These inert producer facts are never a
# CORE Job, admission capsule, output envelope or publication authority.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiProducerProjection {context} {
    if {$context eq {} || [dict get $context provider_id] ne {viewer.scientific_image_inspector.processing}} {return {}}
    set id [dict get $context job_id]
    set status [::GX::scientificExecutionStatus $id]
    if {[dict get $status job_id] ne $id || [dict get $status provider_id] ne [dict get $context provider_id] ||
        [dict get $status state] ne {COMPLETED} || [dict get $context state] ne {COMPLETED}} {error {SII producer changed during provenance observation}}
    set identities [dict get $status source_identities]
    if {[::GX::datasetPublicationV2DictDefault $identities workspace {}] ne [dict get $context workspace_guard]} {error {SII producing Workspace guard changed}}
    set request [dict create provider_id [dict get $context provider_id] image_profile image_resource_files_v1 \
        image_recipe [dict get $context recipe] image_resource_sources [dict get $context input_sources] \
        image_capture_options [dict create image_sources [dict get $context canonical_sources]] source_identities $identities]
    if {[dict get $context native_projection] ne {}} {
        dict set request image_source_profile native_canvas_document_v1
        dict set request image_native_projection [dict get $context native_projection]
        dict set request image_native_projection_sha256 [dict get $context native_projection_sha256]
        dict set request image_native_canonical_sources [dict get $context canonical_sources]
    }
    return [dict create id $id state COMPLETED scientific_request $request]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCurrentJob {id} {
    set context [::GX::scientificExecutionImageJobContext $id]
    set projected [_nativeCanvasSiiProducerProjection $context]
    if {$projected eq {}} {error {SII publication has a foreign producing provider}}
    if {[::GX::scientificExecutionImageJobContext $id] ne $context} {error {SII publication context changed}}
    return $projected
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiResourceJob {reference} {
    set context [::GX::scientificExecutionImageResourceContext $reference]
    if {$context eq {}} {return {}}
    set owner [::GX::interactiveDocumentRead [dict get $reference document_id]]
    set token [::GX::interactiveDocumentSessionToken]
    set projected [_nativeCanvasSiiProducerProjection $context]
    if {$projected eq {}} {return {}}
    if {[::GX::scientificExecutionImageResourceContext $reference] ne $context ||
        [::GX::interactiveDocumentRead [dict get $reference document_id]] ne $owner ||
        [::GX::interactiveDocumentSessionToken] ne $token} {error {SII retained producer changed while projecting provenance}}
    return [dict create job $projected owner $owner reference $reference session_token $token context $context]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiResourceObserve {reference {selection reference}} {
    set observed [::GX::scientificExecutionImageResourceObserve $reference $selection]
    if {$selection eq {outputs}} {return $observed}
    set output [dict get $observed output]
    if {[string match input-* [dict get $reference metadata source_output_token]]} {
        return [dict create original_input $output summary [dict get $observed summary]]
    }
    return [dict create outputs [list $output] summary [dict get $observed summary]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiInputAlias {job token} {
    set id [dict get $job id]
    set aliases [dict merge [dict get $job scientific_request image_capture_options image_sources] [dict get $job scientific_request image_resource_sources]]
    dict for {alias source} $aliases {
        if {[::GX::nativeWorkspaceMetadataDigest "$id:$alias"] eq [string range $token 6 end]} {return $alias}
    }
    error {SII original input token is outside its actual captured alias set}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiImageDimensions {reference} {
    # Closed SII only. Ordinary Resources continue through exact legacy PIL.
    if {![dict exists $reference metadata source_job_id] || ![dict exists $reference metadata source_output_token]} {return {}}
    set proof [_nativeCanvasSiiResourceJob $reference]
    if {$proof eq {}} {return {}}
    _nativeCanvasSiiModule
    set job [dict get $proof job];set token [dict get $reference metadata source_output_token]
    if {[string match input-* $token]} {
        set recipe [dict get $job scientific_request image_recipe]
        if {[dict get $recipe kind] ne {image} || [dict get $recipe operation] ne {process} || [llength [dict get $recipe steps]]} {error {Original Source display must come from its unmodified source-load Job}}
        set alias [_nativeCanvasSiiInputAlias $job $token]
        set original [dict get [_nativeCanvasSiiResourceObserve $reference] original_input]
        foreach field {sha256 size_bytes} {if {[dict get $original $field] ne [dict get $reference $field]} {error {SII original image differs from its exact held input bytes}}}
        if {[dict get $original token] ne $token || [dict get $original source_generation] ne [dict get $reference metadata source_generation]} {error {SII original image observation token or generation changed}}
        if {[dict exists $job scientific_request image_capture_options image_sources $alias]} {
            set expected [dict get $job scientific_request image_capture_options image_sources $alias]
            set source [::GX::SII::sourceInfo [dict get $expected dataset_id]]
            if {[dict get $source sha256] ne [dict get $reference sha256] || [dict get $source size_bytes]!=[dict get $reference size_bytes] ||
                ![dict exists $reference metadata source_dataset_id] || [dict get $reference metadata source_dataset_id] ne [dict get $expected dataset_id]} {error {SII original image Resource differs from its actual canonical byte source}}
        } else {
            set captured [dict get $job scientific_request image_resource_sources $alias]
            foreach field {document_id owner_generation sha256 size_bytes} {if {[dict get $captured $field] ne [dict get $reference $field]} {error {SII original local image differs from its actual captured Resource}}}
            set outputs [_nativeCanvasSiiResourceObserve $reference outputs]
            set info [dict get $outputs summary info]
            return [list [dict get $info width] [dict get $info height]]
        }
    } else {
        set outputs [_nativeCanvasSiiResourceObserve $reference]
        if {[llength [dict get $outputs outputs]]!=1} {error {SII image output observation is ambiguous}}
        set output [lindex [dict get $outputs outputs] 0]
        if {[dict get $output role] ne {raster} || [dict get $output sha256] ne [dict get $reference sha256] || [dict get $output size_bytes]!=[dict get $reference size_bytes]} {error {SII image Resource is not its actual completed high-depth raster}}
        # The ORIGINAL inspector ran inside this exact producing Job. Its
        # summary is part of the same held manifest checked above. Resource
        # filenames intentionally carry no format suffix; do not pretend they
        # are plugin-owned MIFF temporary paths or weaken inspectFile's rule.
        set info [dict get $outputs summary info]
        foreach field {width height} {if {![string is entier -strict [dict get $info $field]] || [dict get $info $field]<1} {error {SII completed manifest has invalid image dimensions}}}
        return [list [dict get $info width] [dict get $info height]]
    }
    # Original bounded metadata-only ImageMagick inspector; no decoder/math
    # implementation or caller-provided width/height is introduced here.
    set path [dict get $source path]
    set info [::GX::SII::inspectFile $path]
    ::GX::interactiveDocumentResourceInfo $reference
    set current [_nativeCanvasSiiResourceJob $reference]
    if {$current eq {} || [dict get $current job scientific_request] ne [dict get $proof job scientific_request]} {error {SII original canonical source changed while inspecting dimensions}}
    if {[dict get $proof session_token] ne [::GX::interactiveDocumentSessionToken] || [::GX::interactiveDocumentRead [dict get $reference document_id]] ne [dict get $proof owner]} {error {SII Document changed while inspecting image dimensions}}
    return [list [dict get $info width] [dict get $info height]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiProjection {row reference image} {
    set handle [dict get $row context handle]
    if {![dict exists $reference metadata source_job_id] || ![dict exists $reference metadata source_output_token]} {return {}}
    if {[dict exists $row sii_lod_ready]} {
        set ready [dict get $row sii_lod_ready]
        set currentKey [list [dict get $reference sha256] $image [dict get [::GX::native2DCanvasViewInfo $handle] view_state] [dict get $row receipt]]
        if {[dict get $ready key] eq $currentKey && [dict get $ready reference] eq $reference && ![catch {image type [dict get $ready photo]}]} {
            ::GX::interactiveDocumentResourceInfo $reference
            return $ready
        }
    }
    set key [list [dict get $row session] [dict get $row document] [dict get $row receipt] [dict get $reference sha256]]
    if {[dict exists $row sii_display_cache $key]} {
        set projection [dict get $row sii_display_cache $key]
        ::GX::interactiveDocumentResourceInfo [dict get $projection reference]
        return $projection
    }
    set proof [_nativeCanvasSiiResourceJob $reference]
    if {$proof eq {}} {return {}}
    set job [dict get $proof job];set id [dict get $job id]
    set outputs [_nativeCanvasSiiResourceObserve $reference outputs]
    set display {}
    foreach output [dict get $outputs outputs] {
        if {[dict get $output role] eq {display_preview}} {
            if {$display ne {}} {error {SII completed display projection is ambiguous}}
            set display $output
        }
    }
    if {$display eq {}} {error {SII image has no original completed display projection}}
    set preview {}
    foreach item [::GX::datasetPublicationV2DictDefault $row retained_outputs {}] {
        if {![dict exists $item metadata source_job_id] || [dict get $item metadata source_job_id] ne $id} continue
        if {[dict get $item sha256] eq [dict get $display sha256] && [dict get $item size_bytes]==[dict get $display size_bytes] &&
            [dict get $item metadata source_output_token] eq [dict get $display token] && [dict get $item metadata source_generation]==[dict get $display source_generation]} {
            if {$preview ne {} && $preview ne $item} {error {SII display Resource association is ambiguous}}
            set preview $item
        }
    }
    if {$preview eq {} || [dict get $preview document_id] ne [dict get $row document] || [dict get $preview owner_generation] ne [dict get $row receipt generation]} {error {SII display projection has not been adopted by this Canvas Document}}
    ::GX::interactiveDocumentResourceInfo $preview
    # The original PNG metadata helper retains its64MP protection. The
    # original native photo budgets remain stricter and are checked below.
    set dimensions [::GX::native2DResourceRasterInfo $preview]
    set width [dict get $dimensions width];set height [dict get $dimensions height]
    if {$width<1 || $height<1 || wide($width)*$height>16777216} {error {SII display projection exceeds the original native photo budget}}
    if {[dict get $image width]<1 || [dict get $image height]<1} {error {SII full image geometry is invalid}}
    _nativeCanvasSiiResourceJob $reference
    set projection [dict create reference $preview resource $preview width $width height $height \
        source_rect [list 0 0 [dict get $image width] [dict get $image height]] projection_sha256 [dict get $preview sha256]]
    # This is a presentation cache on the actual Canvas lifetime. Scientific
    # Resource/geometry/History stay in their original owners. Never hash or
    # invoke the original tool once per paint.
    ::GX::native2DCanvasContextCurrent $handle [dict get $row context]
    canvasState set $handle sii_display_cache $key $projection
    return $projection
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiGuard {row} {
    return [dict create document_id [dict get $row document] generation [dict get $row receipt generation] revision [dict get $row receipt revision] sha256 [dict get $row receipt sha256]]
}
# Original SII LOD rendering on the existing managed auxiliary request owner.
# These records are ephemeral display work, never scientific Resource identity.
proc ::GX::SII::CanvasApplication::imageProjection {context reference image presentation} {
    fields $presentation {schema retained_outputs} {schema retained_outputs}
    if {[dict get $presentation schema] ne {gxtxt.native2d.image_projection_context.v1}} {error {Unsupported image projection context}}
    set handle [dict get $context handle]
    ::GX::native2DCanvasContextCurrent $handle $context
    set row [appRecord $handle]
    dict set row retained_outputs [dict get $presentation retained_outputs]
    set projection [_nativeCanvasSiiProjection $row $reference $image]
    if {$projection eq {}} {return {}}
    set result {}
    foreach field {width height source_rect projection_sha256 photo resource} {
        if {[dict exists $projection $field]} {dict set result $field [dict get $projection $field]}
    }
    return $result
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLodCancel {handle} {
    if {[catch {::GX::native2DCanvasContext $handle}]} return
    set row [appRecord $handle]
    if {[dict exists $row sii_lod_timer]} {after cancel [dict get $row sii_lod_timer];canvasState unset $handle sii_lod_timer}
    catch {canvasState unset $handle sii_lod_again}
    if {[dict exists $row sii_lod_ready]} {
        set photo [dict get $row sii_lod_ready photo]
        if {![::GX::native2DCanvasPhotoInUse $handle $photo]} {catch {image delete $photo}}
        ::GX::SII::CanvasApplication::canvasState unset $handle sii_lod_ready
    }
    if {[dict exists $row sii_lod_task]} {
        set ticket [dict get $row sii_lod_task]
        if {[dict exists $::GX::SII::CanvasApplication::siiLodTasks $ticket]} {
            dict set ::GX::SII::CanvasApplication::siiLodTasks $ticket cancelled 1
            set request [dict get $::GX::SII::CanvasApplication::siiLodTasks $ticket request]
            if {$request ne {}} {::GX::scriptJobRequestCancel $request cancelled}
        }
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLodSchedule {handle} {
    if {[catch {::GX::native2DCanvasContext $handle}]} return
    set row [appRecord $handle]
    if {![dict get [::GX::native2DCanvasContext $handle] mounted]} return
    if {[dict exists $row sii_lod_timer]} {after cancel [dict get $row sii_lod_timer]}
    # The original SII delay coalesces viewport movement. There is one active
    # request and at most this latest desired view, not a render queue.
    ::GX::SII::CanvasApplication::canvasState set $handle sii_lod_timer [after 160 [list ::GX::SII::CanvasApplication::_nativeCanvasSiiLodStart $handle]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLodCurrent {task {sourceBoundary 0}} {
    ::GX::parallelExecutionProcessPreparedCurrent [dict get $task execution]
    dict with task {}
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {![dict exists $row sii_lod_task] || [dict get $row sii_lod_task] ne $ticket || $cancelled} {error {SII LOD operation ended}}
    ::GX::native2DCanvasPresentationCurrent $presentation
    if {$sourceBoundary} {
        if {[::GX::SII::magickPath] ne [dict get $payload tool_path]} {error {SII LOD configured runtime changed}}
        dict for {path hash} $source_files {if {[::GX::sha256File $path] ne $hash} {error {SII LOD owning source or runtime changed}}}
    }
    return $row
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLodStart {handle} {
    if {[catch {::GX::native2DCanvasContext $handle}]} return
    catch {canvasState unset $handle sii_lod_timer}
    set allocation {};set request {};set ticket {}
    set code [catch {
        set row [::GX::SII::CanvasApplication::appRecord $handle]
        if {[dict exists $row sii_lod_task]} {::GX::SII::CanvasApplication::canvasState set $handle sii_lod_again 1;return}
        set viewport [::GX::native2DCanvasViewInfo $handle]
        if {![dict get [dict get $viewport context] mounted] || [dict get $viewport viewport] eq {}} return
        set object {};set reference {};set projection {};set presentation {}
        set snapshot [::GX::native2DCanvasSnapshot $handle]
        set paint [::GX::native2DCanvasPaintOrder $handle]
        foreach descriptor [dict get $paint objects] {
            if {[dict get $descriptor kind] ne {image}} continue
            set logical [dict get $descriptor logical_id]
            set item [snapshotLeaf $snapshot $logical];set style [dict get $item style]
            if {![dict get $style visible]} continue
            set visible 1
            foreach layer [dict get $snapshot layers] {
                if {[dict get $layer logical_id] eq [dict get $item layer_logical_id] && ![dict get $layer properties visible]} {set visible 0;break}
            }
            foreach group [dict get $snapshot groups] {
                if {$logical in [dict get $group members] && ![dict get $group style visible]} {set visible 0;break}
            }
            if {!$visible} continue
            set facts [::GX::native2DCanvasImageInfo $handle $logical]
            set candidateImage [dict get $facts image state];set candidateReference [dict get $facts image resource]
            dict set row retained_outputs [dict get $snapshot retained_outputs]
            set candidateProjection [_nativeCanvasSiiProjection $row $candidateReference $candidateImage]
            if {$candidateProjection eq {}} continue
            set presentation [::GX::native2DCanvasPresentationCapture $handle $logical]
            set object [dict get $presentation object_token];set geometry [dict get $presentation geometry]
            set reference [dict get $presentation reference];set image [dict get $presentation image];set projection $candidateProjection
            break
        }
        if {$object eq {}} return
        _nativeCanvasSiiCropRequire
        # Original SII view is axis aligned. Native Canvas affine image edits
        # retain their ordinary projection; this renderer does not invent a
        # second transformed viewport/crop algorithm.
        if {[dict get $image rotation]!=0} return
        set width [dict get $image width];set height [dict get $image height]
        foreach dimension [list $width $height] {if {$dimension<1 || $dimension!=floor($dimension)} {error {SII LOD requires its actual whole source dimensions}}}
        # The original native image owner represents dimensions as doubles;
        # preserve their exact whole value in the existing typed-int frame.
        set width [expr {entier($width)}];set height [expr {entier($height)}]
        lassign [dict get $presentation viewport] cw ch
        set first [geometryImageMap $geometry $object [geometryWorld $geometry [list 0 $ch]] 1]
        set last [geometryImageMap $geometry $object [geometryWorld $geometry [list $cw 0]] 1]
        set crop [::GX::SII::lodCropPlan $width $height $cw $ch $first $last]
        if {$crop eq {}} return
        lassign $crop x y sw sh
        set first [geometryDevice $geometry [geometryImageMap $geometry $object [list $x [expr {$height-$y}]] 0]]
        set last [geometryDevice $geometry [geometryImageMap $geometry $object [list [expr {$x+$sw}] [expr {$height-$y-$sh}]] 0]]
        set path [dict get [::GX::interactiveDocumentResourceLocalFileInfo $reference] path]
        set plan [::GX::SII::lodDevicePlan $path $crop $first $last]
        if {$plan eq {}} return
        set view [dict get $presentation view_state]
        set key [list [dict get $reference sha256] $image $view [dict get $row receipt]]
        if {[dict exists $row sii_lod_ready] && [dict get $row sii_lod_ready key] eq $key && ![catch {image type [dict get $row sii_lod_ready photo]}]} return
        lassign [lrange $plan 5 end] dw dh px py
        set maximum [expr {5*wide($dw)*$dh+65536}]
        set allocation [::GX::resourceManagementAllocate scientific_image_lod [dict create kind directory lifetime operation session [::GX::sessionInspectionCurrentSession] owner_pid [pid] expected_bytes [expr {768*1024*1024+$maximum+16384}] descendant_lease 1]]
        if {![dict get $allocation managed] || [dict get $allocation subsystem] ne {scientific_image_lod} || [dict get $allocation owner_pid]!=[pid]} {error {SII LOD reservation has another owner}}
        set output [file join [dict get $allocation path] lod.png]
        set tool [::GX::SII::magickPath]
        set payload [dict create schema scientific_image_inspector.lod_render.v1 parent_pid [pid] parent_identity [dict get $allocation owner_identity] reservation [dict get $allocation id] session [dict get $allocation session] \
            source_path $path source_sha256 [dict get $reference sha256] source_bytes [dict get $reference size_bytes] image_dimensions [list $width $height] source_rect $crop display [list $dw $dh $px $py] \
            tool_path $tool tool_sha256 [::GX::sha256File $tool] output_file $output argv [::GX::SII::lodRenderArgv $plan $output]]
        set shape {record {schema text parent_pid int parent_identity text reservation text session text source_path text source_sha256 text source_bytes int image_dimensions {array int} source_rect {array int} display {array int} tool_path text tool_sha256 text output_file text argv {array text}}}
        set wire [::GX::nativeWorkspaceTransportJson $shape $payload]
        if {[string length [encoding convertto utf-8 $wire]]>49152} {error {SII LOD control frame exceeds the original transport bound}}
        set helper [file join $::GX::SII::root runtime lod_render_v1.py]
        set runtime [::GX::scientificExecutionImageRuntimeInfo]
        set arguments [list [dict get $runtime python] -I -B $helper [dict get $runtime python_directory]]
        set execution [::GX::parallelExecutionProcessPrepare $allocation $arguments {}]
        set ticket sii-lod-[incr ::GX::SII::CanvasApplication::siiSerial]
        set sourceFiles [dict merge [dict get $runtime source_files] [dict create $tool [dict get $payload tool_sha256]]]
        foreach file [list [file join $::GX::SII::root runtime native2d_canvas_sii_v1.tcl] [file join $::GX::SII::root runtime lod_plan_v1.tcl] $helper] {dict set sourceFiles $file [::GX::sha256File $file]}
        set task [dict create ticket $ticket handle $handle key $key presentation $presentation reference $reference image $image view $view \
            allocation $allocation output $output maximum $maximum payload $payload source_files $sourceFiles execution $execution request {} outcome {} cancelled 0]
        dict set ::GX::SII::CanvasApplication::siiLodTasks $ticket $task
        ::GX::SII::CanvasApplication::canvasState set $handle sii_lod_task $ticket
        _nativeCanvasSiiLodCurrent $task 1
        set request [::GX::parallelExecutionProcessPreparedAsync $execution "$wire\n" [list ::GX::SII::CanvasApplication::_nativeCanvasSiiLodDone $ticket] \
            {duplex 1 timeout_ms 25000 max_bytes 65536 send_pending_bytes 65536 process_group 1 ui_lifetime 0 label {Original SII source-pixel LOD}}]
        dict set ::GX::SII::CanvasApplication::siiLodTasks $ticket request $request
        after 1 [list ::GX::SII::CanvasApplication::_nativeCanvasSiiLodStep $ticket]
    } message]
    if {$code==1} {
        if {$ticket ne {} && [dict exists $::GX::SII::CanvasApplication::siiLodTasks $ticket]} {
            if {$request ne {}} {dict set ::GX::SII::CanvasApplication::siiLodTasks $ticket error $message;::GX::scriptJobRequestCancel $request cancelled} else {_nativeCanvasSiiLodDone $ticket [dict create ok 0 error $message]}
        } elseif {$allocation ne {}} {catch {::GX::resourceManagementRelease [dict get $allocation id]};catch {::GX::resourceManagementCleanup [list [dict get $allocation id]]}}
        ::GX::native2DCanvasStatus $handle $message
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLodStep {ticket} {
    if {![dict exists $::GX::SII::CanvasApplication::siiLodTasks $ticket]} return
    if {[catch {
        set task [dict get $::GX::SII::CanvasApplication::siiLodTasks $ticket]
        _nativeCanvasSiiLodCurrent $task
        set drained [::GX::scriptJobRequestDrain [dict get $task request] 1]
        if {![dict exists $::GX::SII::CanvasApplication::siiLodTasks $ticket]} return
        if {![dict get $drained active] || [dict get $drained cancelled] ne {}} {error {SII LOD reader ended before its verified outcome}}
        foreach outcome [dict get $drained messages] {
            if {[dict get $task outcome] ne {}} {error {SII LOD emitted more than one outcome}}
            fields $outcome {ok result error} ok
            if {![string is boolean -strict [dict get $outcome ok]] || ![dict get $outcome ok]} {error {Original SII LOD renderer refused its source or output}}
            set result [dict get $outcome result]
            fields $result {source_sha256 source_bytes output_sha256 output_bytes width height source_rect display} {source_sha256 source_bytes output_sha256 output_bytes width height source_rect display}
            foreach name {source_sha256 source_bytes source_rect display} {if {[dict get $result $name] ne [dict get $task payload $name]} {error {SII LOD returned another source or viewport}}}
            lassign [dict get $result display] dw dh
            if {![regexp {^[a-f0-9]{64}$} [dict get $result output_sha256]] || ![string is entier -strict [dict get $result output_bytes]] || [dict get $result output_bytes]<33 || [dict get $result output_bytes]>[dict get $task maximum] || [dict get $result width]!=$dw || [dict get $result height]!=$dh} {error {SII LOD returned invalid output identity}}
            dict set task outcome $outcome
        }
        dict set ::GX::SII::CanvasApplication::siiLodTasks $ticket $task
        if {[dict get $task outcome] ne {}} {
            # The managed terminal callback, after its owned group drains,
            # alone may read the image and release its actual allocation.
            ::GX::scriptJobRequestCancel [dict get $task request] closed
        } else {after 1 [list ::GX::SII::CanvasApplication::_nativeCanvasSiiLodStep $ticket]}
    } message]} {
        if {[dict exists $::GX::SII::CanvasApplication::siiLodTasks $ticket]} {
            dict set ::GX::SII::CanvasApplication::siiLodTasks $ticket error $message
            ::GX::scriptJobRequestCancel [dict get $::GX::SII::CanvasApplication::siiLodTasks $ticket request] cancelled
        }
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLodDone {ticket response} {
    if {![dict exists $::GX::SII::CanvasApplication::siiLodTasks $ticket]} return
    set task [dict get $::GX::SII::CanvasApplication::siiLodTasks $ticket]
    set handle [dict get $task handle];set photo {};set result {};set failure {}
    if {[catch {
        if {[dict exists $task error]} {error [dict get $task error]}
        _nativeCanvasSiiLodCurrent $task 1
        if {[dict get $task outcome] eq {} || ![dict exists $response error_type] || [dict get $response error_type] ne {closed}} {error {SII LOD did not finish through the original drained close}}
        set result [dict get $task outcome result]
        file lstat [dict get $task output] before
        if {$before(type) ne {file} || $before(nlink)!=1 || $before(size)!=[dict get $result output_bytes]} {error {SII LOD output file identity differs}}
        set photo [image create photo -file [dict get $task output] -format png]
        file lstat [dict get $task output] after
        foreach name {dev ino size mtime ctime mode uid nlink} {if {$before($name) ne $after($name)} {error {SII LOD output changed during photo capture}}}
        if {[image width $photo]!=[dict get $result width] || [image height $photo]!=[dict get $result height]} {error {SII LOD photo has another extent}}
        _nativeCanvasSiiLodCurrent $task
    } reason]} {set failure $reason}
    # This callback is reached only after original ScriptJobAsync drain. The
    # photo has already copied verified pixels before temporary-byte cleanup.
    if {[catch {
        ::GX::resourceManagementRelease [dict get $task allocation id]
        ::GX::resourceManagementCleanup [list [dict get $task allocation id]]
    } cleanup]} {set failure "SII LOD allocation remains protected: $cleanup"}
    dict unset ::GX::SII::CanvasApplication::siiLodTasks $ticket
    if {![catch {::GX::native2DCanvasContext $handle}] && [::GX::SII::CanvasApplication::canvasState exists $handle sii_lod_task] && [::GX::SII::CanvasApplication::canvasState get $handle sii_lod_task] eq $ticket} {
        ::GX::SII::CanvasApplication::canvasState unset $handle sii_lod_task
        if {$failure eq {} && $photo ne {}} {
            set row [appRecord $handle]
            if {[dict exists $row sii_lod_ready]} {
                set previous [dict get $row sii_lod_ready photo]
                if {![::GX::native2DCanvasPhotoInUse $handle $previous]} {catch {image delete $previous}}
            }
            ::GX::SII::CanvasApplication::canvasState set $handle sii_lod_ready [dict create key [dict get $task key] source_sha256 [dict get $task reference sha256] reference [dict get $task reference] photo $photo width [dict get $result width] height [dict get $result height] source_rect [dict get $result source_rect] projection_sha256 [dict get $result output_sha256]]
            set photo {}
            ::GX::native2DCanvasSchedule $handle
        } elseif {$failure ne {}} {::GX::native2DCanvasStatus $handle $failure}
        if {[::GX::SII::CanvasApplication::canvasState exists $handle sii_lod_again]} {canvasState unset $handle sii_lod_again;_nativeCanvasSiiLodSchedule $handle}
    }
    if {$photo ne {}} {catch {image delete $photo}}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiSource {window} {
    set definition [::GX::viewerGuiDesignComponent $window source_raster]
    if {[dict get $definition type] ne {dataset_selector} || [::GX::datasetPublicationV2DictDefault [dict get $definition properties] content_kind {}] ne {raster}} {error {SII requires its actual declared canonical raster selector}}
    set id [dict get [::GX::viewerGuiDesignValues $window] source_raster]
    if {$id eq {}} {
        if {[viewerState exists $window sii_local_source]} {return [_nativeCanvasSiiResourceSource [viewerState get $window sii_local_source]]}
        set handle [viewerHandle $window canvas_scene]
        set snapshot [::GX::native2DCanvasCapture $handle];set matches {}
        foreach item [dict get $snapshot objects] {
            if {![dict exists $item resource metadata sketch_attributes gx.image.sii]} continue
            set model [dict get $item resource metadata sketch_attributes gx.image.sii]
            if {[dict get $model role] ne {source} || ![string match resource:* [dict get $model source dataset_id]]} continue
            set reference [dict get $item resource metadata image_resource]
            if {![_nativeCanvasSiiPersistedReference $reference [::GX::interactiveDocumentRead [dict get $snapshot document_id]]]} {error {Retained local Source is outside its actual native Resource graph}}
            if {[dict get $model source] ne [_nativeCanvasSiiResourceSource $reference]} {error {Retained local Source correlation differs from its actual Resource}}
            lappend matches $reference
        }
        if {[llength $matches]!=1} {error {Choose one canonical source or explicitly open a local image}}
        viewerState set $window sii_local_source [lindex $matches 0]
        return [_nativeCanvasSiiResourceSource [lindex $matches 0]]
    }
    set current [::GX::quantitativeRasterSourceIdentity $id]
    return [dict create dataset_id $id source_sha256 [dict get $current source_sha256] source_revision [dict get $current source_revision]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiResourceSource {reference} {
    ::GX::interactiveDocumentResourceInfo $reference
    if {![dict exists $reference owner_generation] || [dict get $reference owner_generation] eq {}} {error {Local SII Source requires its complete Resource owner generation}}
    return [dict create dataset_id resource:[dict get $reference sha256] source_sha256 [dict get $reference sha256] source_revision [dict get $reference owner_generation]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCapturedSources {window handle request {preferred {}}} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set owner [::GX::interactiveDocumentRead [dict get $row document]]
    set references [::GX::interactiveDocumentResourceReferences [dict get $owner payload] [dict get $owner id]]
    if {[viewerState exists $window sii_local_source]} {
        set references [linsert $references 0 [viewerState get $window sii_local_source]]
    }
    # Pending preview Resources are owner-issued results retained by this exact
    # Canvas lifetime, not selectable paths or new persistent source aliases.
    if {[dict exists $row sii_candidate]} {set references [concat $references [dict get $row sii_candidate snapshot retained_outputs]]}
    foreach reference [lreverse $preferred] {
        set key [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $reference]]
        set found 0
        foreach stored $references {
            if {$key eq [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $stored]]} {set found 1;break}
        }
        if {!$found} {error {Current selected image input is outside its actual authoritative Resource graph}}
        set references [linsert $references 0 $reference]
    }
    set sources {};set canonical {};set resources {};set ids {};set index 0;set private 0
    foreach source [::GX::SII::_processingSources $request] {
        ::GX::SII::_processingFields $source {dataset_id source_sha256 source_revision}
        set id [dict get $source dataset_id]
        if {[dict exists $sources $id]} {if {[dict get $sources $id] ne $source} {error {Conflicting actual SII source associations}};continue}
        dict set sources $id $source
        set alias source[incr index]
        if {![string match resource:* $id]} {
            ::GX::SII::_processingSource $source
            dict set canonical $alias $source;lappend ids $id
            continue
        }
        set private 1;set found {}
        foreach reference $references {
            if {[dict get $reference document_id] ne [dict get $row document] || ![dict exists $reference owner_generation] || [dict get $reference owner_generation] ne [dict get $row receipt generation]} continue
            if {[dict get $reference sha256] ne [dict get $source source_sha256] || [dict get $reference owner_generation] ne [dict get $source source_revision]} continue
            if {[_nativeCanvasSiiResourceSource $reference] eq $source} {set found $reference;break}
        }
        if {$found eq {}} {error {SII Resource source is outside the actual current Canvas Document or its completed candidate}}
        dict set resources $alias $found
    }
    ::GX::scientificExecutionPublicationGuard [_nativeCanvasSiiGuard $row]
    return [dict create private $private identities $sources canonical $canonical resources $resources ids $ids]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiTarget {handle} {
    return [_nativeCanvasSiiTargetFor $handle {} 1]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiTargetFor {handle logical requireSelected} {
    if {$requireSelected ni {0 1}} {error {Invalid private SII selection context}}
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set snapshot [::GX::native2DCanvasCapture $handle]
    set selected [dict get $snapshot selection]
    if {$requireSelected} {
        if {[llength $selected]!=1} {error {Select exactly one owned Canvas image for SII processing}}
        if {$logical eq {}} {set logical [lindex $selected 0]}
        if {$selected ne [list $logical]} {error {SII target is not the exact selected image}}
    } elseif {$logical eq {}} {error {Private SII image capture requires its actual owned logical identity}}
    set item [snapshotLeaf $snapshot $logical]
    if {![dict exists $item resource metadata reference_image] || ![dict exists $item resource metadata image_resource]} {error {The selected Canvas object is not an owned image}}
    set reference [dict get $item resource metadata image_resource]
    ::GX::interactiveDocumentResourceInfo $reference
    if {[dict get $reference document_id] ne [dict get $row document] || ![dict exists $reference owner_generation] || [dict get $reference owner_generation] ne [dict get $row receipt generation]} {error {Selected SII image belongs to another Document generation}}
    ::GX::native2DCanvasSourcesCurrent $handle [dict get $row context]
    return [dict create object $logical layer [dict get $item layer_logical_id] resource $reference]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCanonicalSource {item reference} {
    if {![dict exists $item source dataset_id]} {error {Selected image has no canonical binding or completed SII provenance}}
    set sourceBinding [dict get $item source]
    ::GX::viewerGuiRasterSourceCurrent $sourceBinding
    set dataset [dict get $sourceBinding dataset_id]
    if {![dict exists $reference metadata source_kind] || [dict get $reference metadata source_kind] ne {canonical_dataset} ||
        ![dict exists $reference metadata source_dataset_id] || [dict get $reference metadata source_dataset_id] ne $dataset ||
        [dict get $reference sha256] ne [dict get $sourceBinding source_sha256]} {error {Selected canonical image differs from its original bound Resource}}
    return [dict remove [::GX::quantitativeRasterSourceIdentity $dataset] source_stamp]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiImageModel {handle} {
    return [_nativeCanvasSiiImageModelFor $handle {} 1]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiImageModelFor {handle logical {requireSelected 1}} {
    set target [_nativeCanvasSiiTargetFor $handle $logical $requireSelected]
    set item [snapshotLeaf [::GX::native2DCanvasCapture $handle] [dict get $target object]]
    set metadata [dict get $item resource metadata]
    set nativeDerived 0;set realizedFigure 0;set realizedImage 0
    if {[dict exists $target resource metadata source_job_id]} {
        set producerStatus [::GX::scientificExecutionStatus [dict get $target resource metadata source_job_id]]
        set producer [dict create scientific_request [dict create provider_id [dict get $producerStatus provider_id]]]
        if {[dict get $producerStatus provider_id] eq {viewer.scientific_image_inspector.processing}} {
            set proof [_nativeCanvasSiiResourceJob [dict get $target resource]]
            if {$proof eq {}} {error {Selected SII image has no verified producing owner}}
            set producer [dict get $proof job]
        }
        set nativeDerived [expr {[dict get $producer scientific_request provider_id] eq {core.native2d.raster}}]
        set realizedFigure [expr {[dict get $producer scientific_request provider_id] eq {viewer.scientific_image_inspector.processing} && [dict get $producer scientific_request image_recipe kind] eq {figure}}]
        set realizedImage [expr {[dict get $producer scientific_request provider_id] eq {viewer.scientific_image_inspector.processing} &&
            [dict get $producer scientific_request image_recipe kind] eq {image} && [dict get $producer scientific_request image_recipe operation] eq {process} &&
            ![dict exists $metadata sketch_attributes gx.image.sii]}]
    }
    if {$realizedFigure || $realizedImage} {
        set dimensions [_nativeCanvasSiiImageDimensions [dict get $target resource]]
        set image [dict get $metadata reference_image]
        if {$dimensions ne [list [expr {wide([dict get $image width])}] [expr {wide([dict get $image height])}]] || [dict get $image resource_id] ne [dict get $target resource sha256]} {error {Selected completed Figure differs from its actual current raster}}
        set model [_nativeCanvasSiiInitialModel [_nativeCanvasSiiResourceSource [dict get $target resource]]]
        dict set model pixel_stage [expr {$realizedFigure ? {completed_sii_figure_raster} : {completed_sii_image_raster}}]
        dict set model original_geometry [dict get $item resource]
        dict set model original_binding {}
    } elseif {$nativeDerived} {
        # Native filter/flatten has already realized THESE pixels. A copied
        # SII marker or old item.source cannot turn them back into Raw bytes.
        set proof [_nativeCanvasSiiCaptureNativeInputProof [dict get $target resource]]
        set dimensions [::GX::native2DResourceImageDimensions [dict get $target resource]]
        set image [dict get $metadata reference_image]
        if {$dimensions ne [list [expr {wide([dict get $image width])}] [expr {wide([dict get $image height])}]] || [dict get $image resource_id] ne [dict get $target resource sha256]} {error {Native derived image geometry differs from its current raster}}
        set model [_nativeCanvasSiiInitialModel [_nativeCanvasSiiResourceSource [dict get $target resource]]]
        dict set model role derived
        dict set model pixel_stage derived_rgba8_sRGB
        dict set model native_operation [dict get $proof operation]
    } elseif {[dict exists $metadata sketch_attributes gx.image.sii]} {
        set model [dict get $metadata sketch_attributes gx.image.sii]
        if {[dict get $model schema] ne {gxtxt.sii.canvas_model.v1} || [dict get $model role] ni {source working figure}} {error {Selected image has an unsupported SII model}}
        # A copied marker is not image provenance. Reuse the original completed
        # Resource/manifest admission, including token, generation and dimensions.
        if {[dict get $model role] eq {source} && [::GX::datasetPublicationV2DictDefault [dict get $target resource metadata] source_kind {}] eq {canonical_dataset}} {
            if {[dict get $model source] ne [_nativeCanvasSiiCanonicalSource $item [dict get $target resource]]} {error {Selected original image model differs from its canonical Resource}}
        } elseif {[llength [_nativeCanvasSiiImageDimensions [dict get $target resource]]]!=2} {error {Selected SII image has no verified completed image Resource}}
        if {[dict get $model role] eq {working}} {
            set proof [_nativeCanvasSiiResourceJob [dict get $target resource]]
            set recipe [dict get $proof job scientific_request image_recipe]
            if {[dict get $recipe kind] ne {image} || [dict get $recipe operation] ne {process} || [dict get $recipe source] ne [dict get $model source] || [dict get $recipe steps] ne [dict get $model image steps]} {error {Selected Working model differs from its exact completed processing recipe}}
        } elseif {[dict get $model role] eq {figure}} {error {Selected Figure marker differs from its actual producing Job}}
        if {[dict get $model role] eq {source} && [::GX::datasetPublicationV2DictDefault [dict get $target resource metadata] source_kind {}] ne {canonical_dataset}} {
            if {[dict get $model image steps] ne {}} {error {Current Resource baseline cannot carry an unverified applied recipe}}
            if {[dict get $model source] ne [_nativeCanvasSiiResourceSource [dict get $target resource]]} {
                set actual [_nativeCanvasSiiResourceJob [dict get $target resource]]
                set recipe [dict get $actual job scientific_request image_recipe]
                if {[dict get $recipe kind] ne {image} || [dict get $recipe operation] ne {process} || [dict get $recipe steps] ne {} || [dict get $recipe source] ne [dict get $model source]} {error {Original Source model differs from its actual source-load Job}}
            }
        }
    } else {
        # Normal canonical Canvas imports need no SII-specific loading route.
        # Their original Dataset binding and exact Resource bytes remain the
        # authority; the global Source selector never retargets this image.
        set model [_nativeCanvasSiiInitialModel [_nativeCanvasSiiCanonicalSource $item [dict get $target resource]]]
    }
    if {[string match resource:* [dict get $model source dataset_id]]} {
        if {[_nativeCanvasSiiResourceSource [dict get $target resource]] eq [dict get $model source]} {
            dict set model current_resource [dict get $target resource]
        } elseif {[dict get $model role] eq {working}} {
            set found {}
            dict for {alias reference} [dict get $proof job scientific_request image_resource_sources] {
                if {[_nativeCanvasSiiResourceSource $reference] ne [dict get $model source]} continue
                if {$found ne {} && $found ne $reference} {error {Working source has ambiguous actual Resource inputs}}
                set found $reference
            }
            if {$found eq {}} {error {Working source is outside its actual captured Resource inputs}}
            dict set model current_resource $found
        }
    }
    if {[_nativeCanvasSiiTargetFor $handle [dict get $target object] $requireSelected] ne $target} {error {SII target changed during its image proof}}
    dict set model object [dict get $target object]
    return $model
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiInitialModel {source} {
    set image [dict create steps {} image_annotations {}]
    set figure [dict create panels {} figure_annotations {} figure_settings {width 2400 height 1600 margin 32 gutter 24 layout grid background #FFFFFF}]
    # The complete per-object recipe is part of the one Canvas snapshot. Its
    # original document History owns Undo/Redo, together with layers/geometry.
    return [dict create schema gxtxt.sii.canvas_model.v1 role source source $source image $image figure $figure]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiJobCurrent {window component handle token stamp} {
    if {[catch {set viewer [viewerRecord $window]}] || [dict get $viewer token] ne $token ||
        [viewerHandle $window $component] ne $handle} {error {SII producing Viewer lifetime ended}}
    if {[dict exists $stamp sii_source] && [_nativeCanvasSiiSource $window] ne [dict get $stamp sii_source]} {error {SII source selector changed during its managed operation}}
    set row [canvasCurrent $handle $stamp 1]
    if {[dict exists $row sii_job tracked] && [dict get $row sii_job tracked] && [dict get $row sii_job stamp] eq $stamp} {
        set tracked [dict get $row sii_job];set pending [dict get $row pending]
        if {[_nativeCanvasSiiAdmissionPendingOwns $tracked] || ([dict exists $pending sii_candidate] && [dict get $pending sii_candidate] eq [dict get $tracked job])} {_nativeCanvasSiiTrackedRootCurrent $tracked}
    }
    if {[dict exists $stamp sii_target] && [_nativeCanvasSiiTarget $handle] ne [dict get $stamp sii_target]} {error {SII selected image or owned layer changed during its managed operation}}
    if {[dict exists $stamp sii_layer] && [dict get [::GX::native2DCanvasCapture $handle] active_layer] ne [dict get $stamp sii_layer]} {error {SII import destination layer changed during its managed operation}}
    return $row
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCandidateAnalysis {row} {
    if {![dict exists $row sii_candidate context] || [dict get $row sii_candidate context intent] eq {source}} {return 0}
    set pending [dict get $row pending]
    return [expr {$pending eq {} || ([dict exists $pending sii_candidate] && [dict get $pending sii_candidate] eq [dict get $row sii_candidate context job])}]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiReadiness {window component handle {refresh 0} {cancelAccepted 0}} {
    if {![::GX::viewerGuiDesignGuard $window] || [viewerHandle $window $component] ne $handle} {error {SII readiness Viewer lifetime ended}}
    _viewerGuiSiiRoles $window $component
    _viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set scope [::GX::scientificExecutionTrackedOwnerScope [dict get $row document] viewer.scientific_image_inspector.processing]
    set previous [::GX::datasetPublicationV2DictDefault $row sii_readiness {}]
    # Restore/replacement can retain inert row metadata but replaces the actual
    # native/Document receipt. Such cached readiness is not an attachment grant.
    if {$previous ne {} && ![_nativeCanvasSiiReadinessOwns [dict get $previous context]]} {set previous {}}
    if {$previous ne {} && [dict get $previous owner_scope] eq $scope} {
        if {[dict get $previous state] eq {PENDING}} {
            if {$cancelAccepted} {::GX::SII::CanvasApplication::canvasState set $handle sii_readiness want_cancel 1}
            return [dict create status recovery_pending recovery_id [dict get $previous recovery_id] ready 0 retry_allowed 0]
        }
        if {[dict get $previous state] eq {ACKNOWLEDGING}} {
            return [dict create status acknowledging_prior_outcomes recovery_id [dict get $previous recovery_id] ready 0 retry_allowed 0]
        }
        if {!$refresh} {
            if {[dict get $previous state] eq {READY}} {return [dict create status owner_ready recovery_id [dict get $previous recovery_id] ready 1 retry_allowed 0]}
            if {[dict get $previous state] in {UNKNOWN RECOVERY_REQUIRED ACKNOWLEDGING}} {return [dict merge [dict get $row raster_status] {ready 0 retry_allowed 0}]}
        }
    }
    set pending [dict get $row pending]
    if {$pending ne {} && ![dict exists $pending recovery] && ![dict exists $pending sii_candidate]} {error {Reconcile the current SII admission before refreshing owner readiness}}
    set restorePending $pending
    if {[dict exists $restorePending recovery]} {set restorePending {}}
    set context [dict create window $window component $component handle $handle token [dict get [viewerRecord $window] token] \
        incarnation [dict get [viewerRecord $window] incarnation] stamp [canvasStamp $handle] owner_scope $scope serial [incr ::GX::SII::CanvasApplication::siiSerial] prior_pending $restorePending]
    set readiness [dict create owner_scope $scope state PENDING recovery_id {} context $context]
    ::GX::SII::CanvasApplication::canvasState set $handle sii_readiness $readiness
    _viewerGuiSiiSourceControlsRefresh $window
    if {[catch {set receipt [::GX::scientificExecutionRecoverTracked $scope [list ::GX::SII::CanvasApplication::_nativeCanvasSiiReadinessDone $context] $cancelAccepted]} reason]} {
        return [_nativeCanvasSiiReadinessUnknown $context $reason]
    }
    if {[catch {dict get $receipt recovery_id} recovery] || [dict get $receipt owner_scope] ne $scope || [dict exists $receipt submission_id] || [dict exists $receipt job_id]} {
        return [_nativeCanvasSiiReadinessUnknown $context {Original readiness returned no matching metadata-owner receipt}]
    }
    if {[_nativeCanvasSiiReadinessOwns $context]} {
        ::GX::SII::CanvasApplication::canvasState set $handle sii_readiness recovery_id $recovery
        ::GX::SII::CanvasApplication::canvasState set $handle pending [dict create recovery $recovery]
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status recovery_pending recovery_id $recovery ready 0 retry_allowed 0]
    }
    return [dict create status recovery_pending recovery_id $recovery ready 0 retry_allowed 0]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiReadinessOwns {context} {
    set handle [dict get $context handle]
    if {![canvasState exists $handle sii_readiness context serial] ||
        [canvasState get $handle sii_readiness context serial] ne [dict get $context serial]} {return 0}
    if {![viewerOwns [dict get $context window] [dict get $context component] $handle [dict get $context token] [dict get $context incarnation]]} {return 0}
    return [canvasOwnerSame $handle [dict get $context stamp]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiReadinessUnknown {context message} {
    set status [dict create status recovery_unknown ready 0 retry_allowed 0 error $message]
    if {[_nativeCanvasSiiReadinessOwns $context]} {
        set handle [dict get $context handle]
        set recovery [::GX::SII::CanvasApplication::canvasState get $handle sii_readiness recovery_id]
        if {$recovery ne {}} {dict set status recovery_id $recovery}
        ::GX::SII::CanvasApplication::canvasState set $handle sii_readiness state UNKNOWN
        ::GX::SII::CanvasApplication::canvasState set $handle pending [dict create recovery $recovery]
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
        catch {::GX::native2DCanvasNotify $handle raster_pending}
        _viewerGuiSiiSourceControlsRefresh [dict get $context window]
    }
    return $status
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiReadinessDone {context response} {
    if {![_nativeCanvasSiiReadinessOwns $context]} {_viewerGuiSiiSourceAttachmentFinished $context;return}
    set handle [dict get $context handle];set window [dict get $context window]
    set saved [::GX::SII::CanvasApplication::canvasState get $handle sii_readiness]
    if {[catch {
        if {![::GX::viewerGuiDesignGuard $window] || [dict get [viewerRecord $window] token] ne [dict get $context token] ||
            [::GX::scientificExecutionTrackedOwnerScope [dict get $context stamp document_id] viewer.scientific_image_inspector.processing] ne [dict get $context owner_scope]} {error {Original readiness Session/Document/Viewer binding changed}}
        if {[dict get $response ok]} {
            set record [dict get $response result]
        } else {
            # UNKNOWN carries no acknowledged locator revision or admission
            # page. Preserve its original error and remain fail-closed.
            if {[dict get $response recovery_state] ne {RECOVERY_REQUIRED}} {
                error [::GX::datasetPublicationV2DictDefault $response error {Original owner readiness is unknown}]
            }
            set record $response
        }
        foreach key {recovery_id owner_scope locator_revision admissions has_more retry_allowed} {dict get $record $key}
        set revision [dict get $record locator_revision]
        if {![regexp {^[1-9][0-9]*$} $revision] || [string length $revision]>19 || $revision>9223372036854775807} {error {Readiness requires an acknowledged canonical positive signed64 locator revision}}
        if {![string is boolean -strict [dict get $record has_more]] || [dict get $record retry_allowed] ne {0} ||
            [dict get $record recovery_id] ne [dict get $saved recovery_id] || [dict get $record owner_scope] ne [dict get $context owner_scope] ||
            [dict exists $record submission_id] || [dict exists $record job_id]} {error {Readiness is not its matching original metadata owner}}
        if {[dict get $response ok] && [dict get $record ready] eq {1}} {set state READY} elseif {![dict get $response ok] && [dict get $record recovery_state] eq {RECOVERY_REQUIRED}} {set state RECOVERY_REQUIRED} else {error [::GX::datasetPublicationV2DictDefault $response error {Original owner readiness is unknown}]}
        set rows [dict get $record admissions]
        foreach item $rows {
            if {[lsort [dict keys $item]] ne [lsort {submission_id admission_state job_id job_state handled}]} {error {Recovered admission row differs from its closed original contract}}
            if {$state eq {READY} && [dict get $item admission_state] eq {ACCEPTED} && ![dict get $item handled]} {error {Original readiness still reports unhandled accepted work}}
        }
    } reason]} {return [_nativeCanvasSiiReadinessUnknown $context $reason]}
    set retired [::GX::datasetPublicationV2DictDefault $saved retired 0]
    dict set saved state [expr {$retired ? {RETIRED} : $state}]
    dict set saved admissions $rows
    dict set saved has_more [dict get $record has_more]
    ::GX::SII::CanvasApplication::canvasState set $handle sii_readiness $saved
    set status [dict create status [expr {$state eq {READY} ? {owner_ready} : {recovery_required}}] recovery_id [dict get $record recovery_id] ready [expr {!$retired && $state eq {READY}}] admissions $rows has_more [dict get $record has_more] retry_allowed 0]
    if {$state eq {READY}} {
        # This callback NEVER Prepare/Submit/replays a saved science action.
        set pending [dict get $context prior_pending]
        if {[dict exists $pending sii_candidate] && (![::GX::SII::CanvasApplication::canvasState exists $handle sii_candidate context job] ||
            [::GX::SII::CanvasApplication::canvasState get $handle sii_candidate context job] ne [dict get $pending sii_candidate])} {set pending {}}
        ::GX::SII::CanvasApplication::canvasState set $handle pending $pending
    }
    ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
    catch {::GX::native2DCanvasNotify $handle raster_pending}
    _viewerGuiSiiSourceControlsRefresh $window
    if {[::GX::datasetPublicationV2DictDefault $saved want_cancel 0] && $state eq {RECOVERY_REQUIRED}} {
        _nativeCanvasSiiReadiness $window [dict get $context component] $handle 1 1
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiRecoveryDiscard {window component handle} {
    set row [::GX::SII::CanvasApplication::appRecord $handle];set saved [dict get $row sii_readiness]
    if {[dict get $saved state] ne {RECOVERY_REQUIRED}} {return [dict merge [dict get $row raster_status] {ready 0 retry_allowed 0}]}
    set queue {}
    foreach item [dict get $saved admissions] {
        if {[dict get $item admission_state] ne {ACCEPTED} || [dict get $item handled]} continue
        if {[dict get $item job_state] ni {COMPLETED FAILED CANCELLED INTERRUPTED}} {error {Cancel and reconcile the actual prior Job to terminal before discarding its outcome}}
        lappend queue $item
    }
    if {![llength $queue]} {return [_nativeCanvasSiiReadiness $window $component $handle 1]}
    dict set saved state ACKNOWLEDGING
    ::GX::SII::CanvasApplication::canvasState set $handle sii_readiness $saved
    ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status acknowledging_prior_outcomes recovery_id [dict get $saved recovery_id] ready 0 retry_allowed 0]
    _nativeCanvasSiiRecoveryDiscardNext [dict get $saved context] $queue
    return [dict create status acknowledging_prior_outcomes recovery_id [dict get $saved recovery_id] ready 0 retry_allowed 0]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiRecoveryDiscardNext {context queue} {
    if {![_nativeCanvasSiiReadinessOwns $context]} return
    if {![llength $queue]} {
        canvasState set [dict get $context handle] sii_readiness state RECONCILED
        return [_nativeCanvasSiiReadiness [dict get $context window] [dict get $context component] [dict get $context handle] 1]
    }
    set item [lindex $queue 0]
    if {[catch {::GX::scientificExecutionAcknowledgeTracked [dict get $context owner_scope] [dict get $item submission_id] [dict get $item job_id] \
        [list ::GX::SII::CanvasApplication::_nativeCanvasSiiRecoveryDiscarded $context [lrange $queue 1 end] $item]} reason]} {_nativeCanvasSiiReadinessUnknown $context $reason}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiRecoveryDiscarded {context queue item response} {
    if {[catch {
        if {![dict get $response ok]} {error [::GX::datasetPublicationV2DictDefault $response error {Original outcome acknowledgment is unknown}]}
        set result [dict get $response result]
        if {[dict get $result admission_state] ne {ACCEPTED} || [dict get $result handled] ne {1} ||
            [dict get $result submission_id] ne [dict get $item submission_id] || [dict get $result job_id] ne [dict get $item job_id]} {error {Original outcome acknowledgment differs from its actual prior Job}}
    } reason]} {return [_nativeCanvasSiiReadinessUnknown $context $reason]}
    # Native rechecks actual TERMINAL atomically; a cancel request never enters
    # this path. The explicit Discard leaves scientific Job/history intact.
    _nativeCanvasSiiRecoveryDiscardNext $context $queue
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiOutcomeHandled {context} {
    if {![dict exists $context submission_id] || ![dict exists $context admission_owner] || [dict get $context job] eq {}} return
    set owner [dict get $context admission_owner]
    if {[lsort [dict keys $owner]] ne [lsort {schema submission_id binding command supervisor_sha256 scope authority_epoch owner_scope locator_revision}]} {return}
    if {[catch {::GX::scientificExecutionAcknowledgeTracked [dict get $owner owner_scope] [dict get $context submission_id] [dict get $context job] \
        [list ::GX::SII::CanvasApplication::_nativeCanvasSiiOutcomeAcknowledged $context]} reason]} {puts stderr "SII handled outcome acknowledgment remains unknown for actual Job [dict get $context job]: $reason"}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiOutcomeAcknowledged {context response} {
    if {[catch {
        if {![dict get $response ok]} {error [::GX::datasetPublicationV2DictDefault $response error {Original outcome acknowledgment unavailable}]}
        set result [dict get $response result]
        if {[dict get $result admission_state] ne {ACCEPTED} || [dict get $result handled] ne {1} ||
            [dict get $result job_id] ne [dict get $context job] || [dict get $result submission_id] ne [dict get $context submission_id]} {error {Original outcome acknowledgment has no matching handled Job}}
    } reason]} {puts stderr "SII handled outcome acknowledgment remains unknown for actual Job [dict get $context job]: $reason";return}
    if {[_nativeCanvasSiiAdmissionOwns $context]} {canvasState set [dict get $context handle] sii_job handled 1}
    set window [dict get $context window];set handle [dict get $context handle]
    if {[viewerOwns $window [dict get $context component] $handle [dict get $context token]] &&
        [::GX::SII::CanvasApplication::canvasState exists $handle sii_job job] &&
        [::GX::SII::CanvasApplication::canvasState get $handle sii_job job] eq [dict get $context job]} {
        set row [appRecord $handle]
        set same 1
        set actual [dict get $row context];set expected [stampContext [dict get $context stamp]]
        foreach key {handle document_id session module_id provider_id} {if {[dict get $actual $key] ne [dict get $expected $key]} {set same 0}}
        if {[dict get $actual document_receipt generation] ne [dict get $expected document_receipt generation]} {set same 0}
        # Accepting this Job advances the Canvas generation. Its verified
        # acknowledgment may attach fresh metadata to that SAME Document;
        # it cannot reuse old READY, admit work or replay the completed action.
        # Admission ownership above still requires the original exact stamp.
        if {$same} {_viewerGuiSiiSourceAttach $window [dict get $context job]}
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiStart {window component handle request intent model} {
    # A chooser continuation is only IO consent. Every actual scientific start
    # rechecks the exact captured compiled Viewer grant, including after idle.
    _viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {[dict exists $row sii_job admitting_sequence] && [dict get $row sii_job job] eq {} &&
        [dict get $row sii_job admitting_sequence]==[dict get $row sequence]} {error {Wait for the current SII admission or cancel it first}}
    if {[dict get $row pending] eq {} || [dict exists [dict get $row pending] recovery] || [_nativeCanvasSiiCandidateAnalysis $row]} {
        set readiness [_nativeCanvasSiiReadiness $window $component $handle]
        if {![dict get $readiness ready]} {return $readiness}
    }
    set parent {}
    set candidateAnalysis [expr {$intent eq {analysis} && [_nativeCanvasSiiCandidateAnalysis $row]}]
    if {([dict get $row pending] ne {} || [dict exists $row sii_candidate]) && !$candidateAnalysis} {error {Accept, discard or cancel the current SII preview first}}
    if {$candidateAnalysis} {
        set parent [dict get $row sii_candidate context]
        _nativeCanvasSiiJobCurrent $window $component $handle [dict get $parent token] [dict get $parent stamp]
    }
    set view [::GX::native2DCanvasViewInfo $handle]
    if {[dict get $view gesture] || [dict get $view roi_gesture_active]} {error {Finish or cancel the provisional Canvas gesture before SII processing}}
    set editHeld [::GX::native2DCanvasEditCapture $handle]
    if {$intent eq {resource_publish}} {
        ::GX::SII::CanvasApplication::appEditCurrent $handle [dict get $model publication_held]
        if {[_nativeCanvasSiiTarget $handle] ne [dict get $model publication_target]} {error {Selected publication image changed during capture}}
        set editHeld [dict get $model publication_held]
        dict unset model publication_held
    }
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set initialStamp [canvasStamp $handle]
    if {$intent eq {source}} {
        dict set initialStamp sii_source [dict get $model source]
        dict set initialStamp sii_layer [dict get [::GX::native2DCanvasCapture $handle] active_layer]
    } elseif {$intent in {figure native_publish}} {
        # Figure layout belongs to the current Document and active catalog,
        # independently of whether an annotation or image is selected.
        dict set initialStamp sii_layer [dict get [heldSnapshot $handle $editHeld] active_layer]
    } else {
        set selected [_nativeCanvasSiiTarget $handle]
        if {[dict get $selected object] ne [dict get $model object]} {error {SII model is not the currently selected image}}
        if {$intent ni {analysis publish resource_publish}} {snapshotEditable [::GX::native2DCanvasCapture $handle] [snapshotLeaf [::GX::native2DCanvasCapture $handle] [dict get $model object]]}
        dict set initialStamp sii_target $selected
    }
    set token [dict get [viewerRecord $window] token]
    # Consume only after this NEW explicit action passed fresh owner/source
    # guards. A readiness callback itself never reaches preparation.
    set sourceAttachSerial [incr ::GX::SII::CanvasApplication::siiSerial]
    ::GX::SII::CanvasApplication::canvasState set $handle sii_source_starting $sourceAttachSerial
    try {
    ::GX::SII::CanvasApplication::canvasState set $handle sii_readiness state CONSUMED
    _viewerGuiSiiSourceControlsRefresh $window
    if {$intent eq {native_publish}} {
        # Only the original GUI/Document owner may issue this private native
        # profile. The request has no selected image, seed panels or markers.
        set preparation [::GX::scientificExecutionCanvasPrepare $window $component $handle $request publish]
        set submit [list ::GX::scientificExecutionSubmitTracked $preparation]
    } else {
        set preferred {}
        if {$intent ne {source} && [dict exists $model current_resource]} {lappend preferred [dict get $model current_resource]}
        set captured [_nativeCanvasSiiCapturedSources $window $handle $request $preferred]
        if {$intent eq {resource_publish}} {
            if {![dict get $captured private] || [dict get $captured resources] ne [dict create source1 [dict get $model publication_source resource]]} {error {Selected publication input differs from its exact captured Resource}}
            dict set captured ids [lmap source [dict get $model publication_source lineage sources] {dict get $source dataset_id}]
        }
        if {[dict get $captured private]} {
            set request [::GX::SII::_processingNormalize $request [dict get $captured identities]]
            if {[::GX::scientificExecutionDestination] ne {local}} {error {Select the local Scientific Execution destination for original SII processing; remote image admission is unavailable}}
            set provider [::GX::SII::_processingProvider]
            if {[string first HDRI [::GX::SII::magickVersion]]<0} {error {Original SII precision processing requires configured ImageMagick HDRI}}
            set guard [_nativeCanvasSiiGuard $row]
            set preparation [::GX::scientificExecutionPrepare $provider {} [dict get $captured resources] \
                [dict create node_id local document_id [dict get $guard document_id] expected_generation [dict get $guard generation] expected_revision [dict get $guard revision] expected_sha256 [dict get $guard sha256] dataset_sources [dict get $captured ids] image_sources [dict get $captured canonical] image_recipe $request]]
            set submit [list ::GX::scientificExecutionSubmitTracked $preparation]
        } else {
            set prepared [::GX::SII::_processingPrepareData $request]
            set submit [list ::GX::SII::_processingSubmit $prepared [_nativeCanvasSiiGuard $row]]
            lappend submit {} 1
        }
    }
    # Only the original async admission owner may supply an accepted Job ID.
    # Keep its response pipe alive across Cancel/Dispose so late IDs are drained
    # and canceled, rather than killing the only owner that can discover them.
    try {
        _nativeCanvasSiiJobCurrent $window $component $handle $token $initialStamp
        ::GX::SII::CanvasApplication::appEditCurrent $handle $editHeld
    } on error {message options} {
        if {[info exists preparation]} {catch {::GX::scientificExecutionDiscard $preparation}}
        return -options $options $message
    }
    set stamp $initialStamp
    set admission sii-admission-[pid]-[incr ::GX::SII::CanvasApplication::siiSerial]
    set context [dict create window $window component $component handle $handle token $token stamp $stamp job {} \
        intent $intent model $model edit_held $editHeld before [heldSnapshot $handle $editHeld] admission $admission \
        module [dict get $row module] provider [dict get $row provider] cancel_prefix [::GX::scriptJobCommand cancel] \
        admitting_sequence [dict get $initialStamp sequence] prior_pending [dict get $row pending] admission_phase preflight tracked 1]
    if {$parent ne {}} {dict set context analysis_parent $parent}
    # Native publication preflight requires its ORIGINAL sequence and no pending
    # operation. This in-flight context rejects overlapping starts without
    # changing that owner contract; Cancel still retires it by sequence.
    ::GX::SII::CanvasApplication::canvasState set $handle sii_job $context
    try {
        set callback [list ::GX::SII::CanvasApplication::_nativeCanvasSiiSubmitted $context]
        if {[lindex $submit 0] eq {::GX::SII::_processingSubmit}} {
            set submit [lreplace $submit 3 3 $callback]
            set submission [{*}$submit]
        } else {set submission [{*}$submit $callback]}
    } on error {message options} {
        # Coordinated tracked contract: only pre-ID local refusal throws;
        # post-ID startup/transport failures remain owned and callback UNKNOWN.
        # This is not a global nonadmission certificate or permission to retry.
        if {[info exists preparation]} {catch {::GX::scientificExecutionDiscard $preparation}}
        set failed $context;dict set failed stamp $initialStamp
        if {[_nativeCanvasSiiAdmissionOwns $context]} {::GX::SII::CanvasApplication::canvasState set $handle sii_readiness state UNKNOWN}
        _nativeCanvasSiiFailed $failed $message
        return [dict create status submission_unavailable ready 0 retry_allowed 0 error $message]
    }
    if {[catch {
        dict set context submission_id [dict get $submission submission_id]
        dict set context admission_owner [dict get $submission admission_owner]
        if {[lsort [dict keys [dict get $context admission_owner]]] ne [lsort {schema submission_id binding command supervisor_sha256 scope authority_epoch owner_scope locator_revision}] ||
            [dict get $context admission_owner schema] ne {gxtxt.script_job_admission.v1} || [dict get $context admission_owner submission_id] ne [dict get $context submission_id]} {error {Tracked owner correlation mismatch}}
    } reason]} {return [_nativeCanvasSiiAdmissionUnknown $context $reason]}
    # Preparation/preflight may yield through original owners. Never recreate a
    # disposed handle or overwrite cancellation/replacement during that work.
    set current 0
    if {![catch {::GX::native2DCanvasContextCurrent $handle [stampContext $initialStamp]}]} {
        set live [appRecord $handle]
        set current [expr {[dict exists $live sii_job admission] && [dict get $live sii_job admission] eq $admission &&
            ![::GX::datasetPublicationV2DictDefault [dict get $live sii_job] retired 0] &&
            [dict get $live pending] eq [dict get $context prior_pending]}]
    }
    if {!$current} {
        dict set context retired 1
        _nativeCanvasSiiAdmissionResolve $context 1 1
        return [dict create status retired_submission submission_id [dict get $submission submission_id] retry_allowed 0]
    }
    # CORE alone advances the sequence and reissues the opaque held edit.
    # The original pending record is a CAS expectation, never cleared early.
    set early [::GX::datasetPublicationV2DictDefault [dict get $live sii_job] early_responses {}]
    if {[catch {
        set admitted [::GX::native2DCanvasOperationBegin $handle [stampContext $initialStamp] \
            [dict create admission $admission] $editHeld [dict get $context prior_pending]]
        stateRebind $handle [stampContext $initialStamp] [dict get $admitted context]
    } message]} {
        dict set context retired 1
        _nativeCanvasSiiAdmissionResolve $context 1 1
        return [dict create status retired_submission submission_id [dict get $context submission_id] retry_allowed 0 error $message]
    }
    set stamp [dict merge $initialStamp [dict get $admitted context]]
    dict set context stamp $stamp
    dict set context edit_held [dict get $admitted held]
    dict set context admission_phase admitted
    canvasState set $handle sii_job $context
    canvasState set $handle pending [dict create admission $admission]
    canvasState set $handle raster_status [dict create status pending operation sii_editor submission_id [dict get $submission submission_id]]
    ::GX::native2DCanvasNotify $handle raster_pending
    foreach response $early {_nativeCanvasSiiSubmitted $context $response}
    return [dict create status pending submission_id [dict get $submission submission_id]]
    } finally {
        if {[::GX::SII::CanvasApplication::canvasState exists $handle sii_source_starting] &&
            [::GX::SII::CanvasApplication::canvasState get $handle sii_source_starting] eq $sourceAttachSerial} {
            ::GX::SII::CanvasApplication::canvasState unset $handle sii_source_starting
            if {![catch {set viewer [viewerRecord $window]}] && [dict get $viewer token] eq $token &&
                [catch {_viewerGuiSiiSourceControlsRefresh $window} sourceUiError]} {
                if {[canvasOwnerSame $handle $initialStamp]} {canvasState set $handle sii_notification_error $sourceUiError}
            }
        }
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiTrackedRootCurrent {context} {
    set owner [dict get $context admission_owner]
    if {[dict get $owner submission_id] ne [dict get $context submission_id]} {error {SII tracked correlation changed}}
    ::GX::scientificExecutionTrackedOwnerCurrent $owner
    return [dict get $owner binding root]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionPendingOwns {context} {
    if {![_nativeCanvasSiiAdmissionOwns $context]} {return 0}
    set pending [canvasState get [dict get $context handle] pending]
    if {[dict exists $pending recovery] || [dict exists $pending sii_candidate]} {return 0}
    if {[dict exists $pending admission] && [dict get $pending admission] eq [dict get $context admission]} {return 1}
    return [expr {[dict get $context job] ne {} && [dict exists $pending job] && [dict get $pending job] eq [dict get $context job]}]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionCurrent {context} {
    if {[::GX::datasetPublicationV2DictDefault $context retired 0]} {error {SII admission was retired by its original owner}}
    dict with context {}
    set row [_nativeCanvasSiiJobCurrent $window $component $handle $token $stamp]
    _viewerGuiSiiRoles $window $component
    _viewerGuiSiiGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    _viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    if {$intent in {publish native_publish resource_publish}} {_viewerGuiSiiGrant $window DATASET_FILE_PUBLICATION_API_v1 datasetFilePublicationPublish}
    if {[dict get $row module] ne $module || [dict get $row provider] ne $provider || ![::GX::moduleIsEnabled $module]} {error {SII admission module/provider lifetime changed}}
    ::GX::SII::CanvasApplication::appEditCurrent $handle $edit_held
    _nativeCanvasSiiTrackedRootCurrent $context
    set pending [dict get $row pending]
    if {$job eq {}} {
        if {![dict exists $pending admission] || [dict get $pending admission] ne $admission} {error {SII admission was canceled or replaced}}
    } elseif {![dict exists $pending job] || [dict get $pending job] ne $job} {error {SII accepted Job was canceled or replaced}}
    return $row
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiSubmitted {context response} {
    set handle [dict get $context handle]
    if {[canvasState exists $handle sii_job admission] &&
        [canvasState get $handle sii_job admission] eq [dict get $context admission] &&
        [::GX::datasetPublicationV2DictDefault [canvasState get $handle sii_job] admission_phase {}] eq {preflight}} {
        set early [::GX::datasetPublicationV2DictDefault [canvasState get $handle sii_job] early_responses {}]
        lappend early $response
        canvasState set $handle sii_job early_responses $early
        return
    }

    # Original tracked owner always attaches correlation to ACCEPTED/CLOSED/
    # UNKNOWN. Retain a matching live capsule even if its transport is malformed.
    set context [_nativeCanvasSiiAdmissionContext $context $response]
    if {[_nativeCanvasSiiAdmissionClosed $context $response]} {return}
    if {[catch {
        if {![dict get $response ok]} {
            error [::GX::datasetPublicationV2DictDefault $response error {SII admission outcome is unknown}]
        }
        set accepted [dict get $response result]
        if {[dict get $accepted admission_state] ne {ACCEPTED} || ![dict exists $accepted admission_owner] ||
            ![dict exists $context admission_owner] || [dict get $accepted admission_owner submission_id] ne [dict get $context submission_id] ||
            [dict get $accepted submission_id] ne [dict get $context submission_id]} {error {SII admission has no matched original accepted correlation}}
        set job [dict get $accepted job_id]
        if {$job eq {} || [dict get $accepted provider_id] ne {viewer.scientific_image_inspector.processing}} {error {SII admission lacks its actual original-provider Job}}
        if {[dict get $context job] ne {} && [dict get $context job] ne $job} {
            dict set context conflicting_job_ids [lsort -unique [list [dict get $context job] $job]]
            error {Original admission reported contradictory nonempty Job identities}
        }
        if {[dict exists $context conflicting_job_ids]} {error {Original admission Job identity remains contradictory}}
    } message]} {
        _nativeCanvasSiiAdmissionUnknown $context $message
        return
    }
    if {[catch {
        _nativeCanvasSiiAdmissionCurrent $context
        dict set context job $job
        if {[dict get $context intent] eq {resource_publish}} {dict set context model publication_source job_id $job}
        set handle [dict get $context handle]
        ::GX::SII::CanvasApplication::canvasState set $handle pending [list job $job]
        ::GX::SII::CanvasApplication::canvasState set $handle sii_job $context
        _nativeCanvasSiiAdmissionCurrent $context
    } message]} {
        dict set context job $job
        dict set context retired 1
        _nativeCanvasSiiAdmissionResolve $context 1 1
        return
    }
    # The original tracked owner binds every observation to its captured
    # physical root/DB generation. Never launch the old path-only waiter here.
    if {[catch {set watcher [::GX::scientificExecutionTrackedWait [dict get $context admission_owner] $job \
        [list ::GX::SII::CanvasApplication::_nativeCanvasSiiCompleted $context]]} reason]} {
        # Auxiliary observation failure does not revoke a valid admission.
        # Retain its real ID and normal Cancel/Status ownership; never retry it.
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status watcher_failed job_id $job retry_allowed 0 error $reason]
        catch {::GX::native2DCanvasNotify $handle raster_pending}
        return [dict create status watcher_failed job_id $job retry_allowed 0 error $reason]
    }
    ::GX::SII::CanvasApplication::canvasState set $handle pending [list job $job waiter $watcher]
    ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status pending operation sii_editor job_id $job]
    ::GX::native2DCanvasNotify $handle raster_pending
    return [dict create status pending job_id $job]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionContext {context response} {
    set handle [dict get $context handle]
    if {[::GX::SII::CanvasApplication::canvasState exists $handle sii_job admission] &&
        [::GX::SII::CanvasApplication::canvasState get $handle sii_job admission] eq [dict get $context admission]} {
        foreach key {submission_id admission_owner retired job stamp edit_held before admission_phase} {
            if {![::GX::SII::CanvasApplication::canvasState exists $handle sii_job $key]} continue
            set value [::GX::SII::CanvasApplication::canvasState get $handle sii_job $key]
            if {$key eq {job} && [dict get $context job] ne {}} {
                if {$value ne {} && $value ne [dict get $context job]} {
                    dict set context conflicting_job_ids [lsort -unique [list [dict get $context job] $value]]
                }
                continue
            }
            if {$key eq {retired} && [::GX::datasetPublicationV2DictDefault $context retired 0]} continue
            dict set context $key $value
        }
    }
    set record $response
    if {![catch {dict get $response ok} ok] && [string is boolean -strict $ok] && $ok && [dict exists $response result]} {set record [dict get $response result]}
    if {![catch {dict get $record submission_id} id] && [dict exists $record admission_owner] &&
        (![dict exists $context submission_id] || [dict get $context submission_id] eq $id)} {
        set owner [dict get $record admission_owner]
        if {![catch {dict get $owner submission_id} ownerId] && $ownerId eq $id &&
            [dict exists $owner schema] && [dict get $owner schema] eq {gxtxt.script_job_admission.v1} && [lsort [dict keys $owner]] eq [lsort {schema submission_id binding command supervisor_sha256 scope authority_epoch owner_scope locator_revision}]} {
            dict set context submission_id $id
            dict set context admission_owner $owner
        }
    }
    return $context
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionOwns {context} {
    set handle [dict get $context handle]
    if {![canvasState exists $handle sii_job admission] ||
        [canvasState get $handle sii_job admission] ne [dict get $context admission]} {return 0}
    return [canvasOwnerSame $handle [dict get $context stamp]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionUnknown {context message} {
    set context [_nativeCanvasSiiAdmissionContext $context {}]
    set status [dict create status admission_unknown operation sii_editor retry_allowed 0 error $message]
    if {[dict exists $context submission_id]} {dict set status submission_id [dict get $context submission_id]}
    if {[dict get $context job] ne {}} {dict set status job_id [dict get $context job];dict set status admission_state ACCEPTED}
    set ownsPending [_nativeCanvasSiiAdmissionPendingOwns $context]
    if {!$ownsPending && [dict exists $context conflicting_job_ids] && [_nativeCanvasSiiAdmissionOwns $context]} {
        set handle [dict get $context handle]
        set live [appRecord $handle]
        set pending [dict get $live pending]
        if {![dict exists $pending recovery] && ![dict exists $pending sii_candidate] && [dict exists $pending job] &&
            [dict get $pending job] eq [dict get $live sii_job job]} {set ownsPending 1}
    }
    if {$ownsPending} {
        set handle [dict get $context handle]
        if {[dict exists $context conflicting_job_ids]} {
            set status [::GX::SII::CanvasApplication::canvasState get $handle raster_status]
            dict set status status admission_unknown
            dict set status conflicting_job_ids [dict get $context conflicting_job_ids]
            dict set status admission_diagnostic $message
            dict set status retry_allowed 0
            ::GX::SII::CanvasApplication::canvasState set $handle sii_job conflicting_job_ids [dict get $context conflicting_job_ids]
            ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
            return $status
        }
        if {[dict get $context job] ne {}} {
            # A later unavailable/malformed observation cannot revoke an
            # already authoritative accepted ID or retire its live watcher.
            set status [::GX::SII::CanvasApplication::canvasState get $handle raster_status]
            if {[::GX::SII::CanvasApplication::canvasState get $handle sii_job job] eq {}} {
                ::GX::SII::CanvasApplication::canvasState set $handle sii_job $context
                dict set status status admission_retired
            }
            dict set status job_id [dict get $context job]
            dict set status admission_state ACCEPTED
            dict set status admission_diagnostic $message
            dict set status retry_allowed 0
            ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
            return $status
        }
        ::GX::SII::CanvasApplication::canvasState set $handle sii_job $context
        ::GX::SII::CanvasApplication::canvasState set $handle pending [list admission [dict get $context admission]]
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
        catch {::GX::native2DCanvasNotify $handle raster_pending}
    }
    # Disposed/replaced state is never recreated. Original CORE retains the
    # durable admission; cold/fresh starts must recover through that same owner.
    return $status
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionClosed {context response} {
    if {[catch {dict get $response ok} ok] || ![string is boolean -strict $ok] || $ok ||
        [catch {dict get $response admission_state} state] || $state ne {CLOSED} || ![dict exists $response admission_owner] ||
        ![dict exists $context admission_owner] || ![dict exists $context submission_id] || [dict get $context job] ne {} ||
        ![dict exists $response submission_id] || [dict get $response submission_id] ne [dict get $context submission_id] ||
        [catch {dict get $response admission_owner submission_id} ownerId] || $ownerId ne [dict get $context submission_id] ||
        ![dict exists $response closed_before_admission] || [dict get $response closed_before_admission] ne {1} ||
        ![dict exists $response retry_allowed] || [dict get $response retry_allowed] ne {1}} {return 0}
    if {[_nativeCanvasSiiAdmissionPendingOwns $context]} {
        set handle [dict get $context handle]
        # CLOSED is the original DB's atomic certificate. No transport error,
        # list absence, canceled request or vanished process can take this path.
        if {![::GX::datasetPublicationV2DictDefault $context retired 0]} {
            set failed $context
            if {[dict get [::GX::native2DCanvasContext $handle] sequence]==[dict get $context admitting_sequence]} {
                dict set failed stamp sequence [dict get $context admitting_sequence]
            }
            _nativeCanvasSiiFailed $failed [::GX::datasetPublicationV2DictDefault $response error {Admission closed before acceptance}]
        } else {
            ::GX::SII::CanvasApplication::canvasState set $handle pending {}
            catch {canvasState unset $handle sii_job}
        }
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status admission_closed admission_state CLOSED submission_id [dict get $context submission_id] retry_allowed 1 closed_before_admission 1]
        catch {::GX::native2DCanvasNotify $handle raster_rejected}
    }
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiTrackedStatus {context} {
    set handle [dict get $context handle]
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set status [::GX::datasetPublicationV2DictDefault $row raster_status {status idle}]
    set metadata [dict create observation_state PENDING retry_allowed 0]
    if {[dict exists $context submission_id]} {dict set metadata submission_id [dict get $context submission_id]}
    if {[dict get $context job] ne {}} {dict set metadata job_id [dict get $context job];dict set metadata admission_state ACCEPTED}
    dict set status job $metadata
    set serial [incr ::GX::SII::CanvasApplication::siiSerial]
    ::GX::SII::CanvasApplication::canvasState set $handle sii_status_serial $serial
    ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
    set observation [dict create context $context serial $serial pending [dict get $row pending] status $status]
    if {[catch {
        ::GX::scientificExecutionTrackedResolve [dict get $context admission_owner] [list ::GX::SII::CanvasApplication::_nativeCanvasSiiStatusObserved $observation] 0 0
    } reason]} {_nativeCanvasSiiStatusObserved $observation [dict create ok 0 error $reason]}
    if {[_nativeCanvasSiiAdmissionOwns $context] && [::GX::SII::CanvasApplication::canvasState get $handle sii_status_serial] eq $serial} {
        return [::GX::SII::CanvasApplication::canvasState get $handle raster_status]
    }
    return $status
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiStatusObserved {observation response} {
    set context [dict get $observation context];set handle [dict get $context handle]
    # Status cannot promote admission, start another observer, retire a Job,
    # clear pending, adopt outputs or acknowledge handling. Its only write is
    # matching current display metadata; newer state always wins.
    if {![_nativeCanvasSiiAdmissionOwns $context] ||
        ![::GX::SII::CanvasApplication::canvasState exists $handle sii_status_serial] ||
        [::GX::SII::CanvasApplication::canvasState get $handle sii_status_serial] ne [dict get $observation serial]} {return}
    set row [appRecord $handle]
    set window [dict get $context window]
    if {![viewerOwns $window [dict get $context component] $handle [dict get $context token]] ||
        [dict get $row pending] ne [dict get $observation pending] || [dict get $row raster_status] ne [dict get $observation status] ||
        [dict get $row sii_job job] ne [dict get $context job]} {return}
    set metadata [dict create observation_state UNKNOWN retry_allowed 0]
    if {[dict exists $context submission_id]} {dict set metadata submission_id [dict get $context submission_id]}
    if {[dict get $context job] ne {}} {dict set metadata job_id [dict get $context job];dict set metadata admission_state ACCEPTED}
    if {[catch {
        if {![dict get $response ok]} {error [::GX::datasetPublicationV2DictDefault $response error {Original tracked status is unavailable}]}
        set result [dict get $response result]
        if {[dict get $result admission_state] ne {ACCEPTED} || ![dict exists $context submission_id] ||
            [dict get $result submission_id] ne [dict get $context submission_id] || [dict get $result job_id] eq {} ||
            ([dict get $context job] ne {} && [dict get $result job_id] ne [dict get $context job]) ||
            [dict get $result state] ni {QUEUED PREPARING RUNNING FINALIZING COMPLETED FAILED CANCELLED INTERRUPTED}} {error {Original tracked status has no matching actual accepted Job}}
        set metadata [dict create observation_state OBSERVED submission_id [dict get $context submission_id] admission_state ACCEPTED \
            job_id [dict get $result job_id] state [dict get $result state] retry_allowed 0]
        foreach key {cancel_requested diagnostic handled} {if {[dict exists $result $key]} {dict set metadata $key [dict get $result $key]}}
    } reason]} {dict set metadata error $reason}
    set status [dict get $row raster_status];dict set status job $metadata
    ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
    catch {::GX::viewerGuiDesignTextSet $window sii_report $status}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionResolve {context close cancel} {
    if {![dict exists $context admission_owner]} {
        return [_nativeCanvasSiiAdmissionUnknown $context {Original tracked admission correlation is unavailable; retry remains prohibited}]
    }
    if {[catch {
        ::GX::scientificExecutionTrackedResolve [dict get $context admission_owner] [list ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionResolved $context] $close $cancel
    } reason]} {_nativeCanvasSiiAdmissionUnknown $context $reason}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionResolved {context response} {
    set context [_nativeCanvasSiiAdmissionContext $context $response]
    if {[_nativeCanvasSiiAdmissionClosed $context $response]} {return}
    if {![::GX::datasetPublicationV2DictDefault $context retired 0]} {return [_nativeCanvasSiiSubmitted $context $response]}
    if {[catch {
        if {![dict get $response ok]} {error [::GX::datasetPublicationV2DictDefault $response error {Admission resolution is unknown}]}
        set result [dict get $response result]
        if {[dict get $result admission_state] ne {ACCEPTED} || ![dict exists $context submission_id] ||
            [dict get $result submission_id] ne [dict get $context submission_id]} {error {Admission resolution lacks its original correlation}}
        set job [dict get $result job_id]
        if {$job eq {}} {error {Admission resolution lacks its actual Job ID}}
        if {[dict get $context job] ne {} && [dict get $context job] ne $job} {
            dict set context conflicting_job_ids [lsort -unique [list [dict get $context job] $job]]
        }
        if {[dict exists $context conflicting_job_ids]} {error {Original admission Job identity remains contradictory}}
    } reason]} {return [_nativeCanvasSiiAdmissionUnknown $context $reason]}
    if {[_nativeCanvasSiiAdmissionPendingOwns $context]} {
        set handle [dict get $context handle]
        dict set context job $job
        ::GX::SII::CanvasApplication::canvasState set $handle sii_job $context
        # Authoritative ACCEPTED releases only this retired UI marker, not the
        # Job/history/correlation. Next explicit science must recover afresh.
        ::GX::SII::CanvasApplication::canvasState set $handle pending {}
        if {[::GX::SII::CanvasApplication::canvasState exists $handle sii_readiness]} {::GX::SII::CanvasApplication::canvasState set $handle sii_readiness state CONSUMED}
        set status [dict create status admission_retired admission_state ACCEPTED job_id $job submission_id [dict get $context submission_id] retry_allowed 0]
        foreach key {cancel_requested diagnostic} {if {[dict exists $result $key]} {dict set status $key [dict get $result $key]}}
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
        catch {::GX::native2DCanvasNotify $handle raster_pending}
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdmissionRetire {handle} {
    set row [appRecord $handle]
    if {[dict exists [dict get $row pending] recovery] && [dict exists $row sii_readiness]} {
        retireOperation $handle
        canvasState set $handle sii_readiness retired 1
        canvasState set $handle raster_status [dict create status recovery_retired ready 0 retry_allowed 0 error {Metadata owner was retired; original prior work remains protected until authoritative recovery}]
        return 1
    }
    if {![dict exists $row sii_job tracked] || ![dict get $row sii_job tracked]} {return 0}
    set context [dict get $row sii_job]
    set preflight [expr {[::GX::datasetPublicationV2DictDefault $context admission_phase {}] eq {preflight} &&
        [dict get $context admitting_sequence]==[dict get $row sequence]}]
    if {!$preflight && ![_nativeCanvasSiiAdmissionPendingOwns $context]} {return 0}
    if {[dict exists [dict get $row pending] waiter]} {catch {::GX::scriptJobRequestCancel [dict get $row pending waiter] canceled}}
    dict set context retired 1
    retireOperation $handle
    canvasState set $handle sii_job $context
    _nativeCanvasSiiAdmissionUnknown $context {Cancellation requested; original admission resolution is pending, not proof of nonadmission}
    if {[dict exists $context admission_owner]} {_nativeCanvasSiiAdmissionResolve $context 1 1}
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLateCancel {context job} {
    # Reuse the captured original Supervisor/root even after a Session switch.
    # Never resolve a late ID against the replacement Viewer's current root.
    if {[catch {
        ::GX::scriptJobAsync [list {*}[dict get $context cancel_prefix] $job] {} \
            [list ::GX::SII::CanvasApplication::_nativeCanvasSiiLateCanceled $job] \
            {timeout_ms 10000 max_bytes 65536 process_group 0 ui_lifetime 0 label {Cancel retired SII admission}}
    } message]} {puts stderr "SII could not request cancellation of actual Job $job: $message"}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiLateCanceled {job response} {
    if {[catch {dict get $response ok} ok] || !$ok} {puts stderr "SII cancellation of actual Job $job was not confirmed: $response"}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFailed {context message} {
    set handle [dict get $context handle]
    if {[catch {canvasCurrent $handle [dict get $context stamp]}]} return
    set row [appRecord $handle]
    set pending [dict get $row pending]
    if {[dict exists $context admission]} {
        # An accepted-ID validation failure can still own the admission nonce.
        # Never clear an unrelated accepted Job or a newer admission.
        set ownsPreparation [expr {[dict get $context job] eq {} &&
            [dict get $row sequence]==[dict get $context admitting_sequence] &&
            [dict exists $row sii_job admission] && [dict get $row sii_job admission] eq [dict get $context admission] &&
            $pending eq [dict get $context prior_pending]}]
        if {!$ownsPreparation && (![dict exists $pending admission] || [dict get $pending admission] ne [dict get $context admission])} {
            if {[dict get $context job] eq {} || ![dict exists $pending job] || [dict get $pending job] ne [dict get $context job]} return
        }
    }
    if {[dict exists $context analysis_parent] && [_nativeCanvasSiiAnalysisParentRestore $context]} {
        catch {canvasState unset $handle sii_import}
        set status [dict create status analysis_rejected operation sii_editor parent_job_id [dict get $context analysis_parent job] error $message]
        if {[dict get $context job] ne {}} {dict set status job_id [dict get $context job]}
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
        ::GX::native2DCanvasStatus $handle $message
        catch {::GX::native2DCanvasNotify $handle raster_rejected}
        return
    }
    ::GX::SII::CanvasApplication::canvasState set $handle pending {}
    if {[dict get $context job] eq {}} {catch {canvasState unset $handle sii_job}}
    catch {canvasState unset $handle sii_import}
    set status [dict create status rejected operation sii_editor error $message]
    if {[dict get $context job] ne {}} {dict set status job_id [dict get $context job]}
    ::GX::SII::CanvasApplication::canvasState set $handle raster_status $status
    ::GX::native2DCanvasStatus $handle $message
    catch {::GX::native2DCanvasNotify $handle raster_rejected}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAnalysisParentRestore {context} {
    if {![dict exists $context analysis_parent]} {return 0}
    dict with context {}
    # Failure can be a worker/analysis error without changing the accepted
    # candidate. Cancellation/source/lifetime changes must NEVER rebase it.
    if {[catch {_nativeCanvasSiiJobCurrent $window $component $handle $token $stamp}]} {return 0}
    set current [::GX::SII::CanvasApplication::appRecord $handle]
    if {![dict exists $current sii_candidate context]} {return 0}
    set candidate [dict get $current sii_candidate]
    if {[dict get $candidate context job] ne [dict get $analysis_parent job]} {return 0}
    set parent [dict get $candidate context]
    if {$parent ne $analysis_parent && !([dict get $parent stamp] eq $stamp &&
        [dict get $parent edit_held] eq $edit_held)} {return 0}
    if {[catch {
        if {[dict get $parent edit_held] eq $edit_held} {
            ::GX::native2DCanvasEditCurrent $handle $edit_held
            set continued $edit_held
        } else {
            set continued [::GX::native2DCanvasOperationContinuation $handle [dict get $parent edit_held] $edit_held]
        }
    }]} {return 0}
    dict set candidate context stamp $stamp
    dict set candidate context edit_held $continued
    ::GX::SII::CanvasApplication::canvasState set $handle sii_candidate $candidate
    ::GX::SII::CanvasApplication::canvasState set $handle sii_job [dict get $candidate context]
    ::GX::SII::CanvasApplication::canvasState set $handle pending [dict create sii_candidate [dict get $candidate context job]]
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCompleted {context response} {
    if {[catch {
        dict with context {}
        _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
        if {![dict get $response ok]} {error [::GX::datasetPublicationV2DictDefault $response error {Original SII Job completion failed}]}
        set observed [dict get $response result]
        if {[lsort [dict keys $observed]] ne [lsort {id state}] || [dict get $observed id] ne $job ||
            [dict get $observed state] ni {COMPLETED FAILED CANCELLED INTERRUPTED}} {error {Original SII observer returned no matching actual terminal Job}}
        if {[dict get $observed state] ne {COMPLETED}} {error "Original SII Job $job ended [dict get $observed state]; no result was adopted"}
        set result [::GX::scientificExecutionImageOutputs $job]
        set queue {}
        if {$intent eq {source}} {lappend queue [list original_source [::GX::scientificExecutionImageOriginal $job source1] source1]}
        foreach output [dict get $result outputs] {lappend queue [list [dict get $output role] $output {}]}
        dict set context result $result
        dict set context queue $queue
        dict set context imported {}
        _nativeCanvasSiiImportNext $context
    } message]} {_nativeCanvasSiiFailed $context $message}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiImportNext {context} {
    dict with context {}
    _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
    if {![llength $queue]} {return [_nativeCanvasSiiAdopt $context]}
    lassign [lindex $queue 0] role output alias
    dict set context queue [lrange $queue 1 end]
    set request [::GX::scientificExecutionImageImport $job $output [_nativeCanvasSiiGuard [::GX::SII::CanvasApplication::appRecord $handle]] \
        [list ::GX::SII::CanvasApplication::_nativeCanvasSiiImported $context $role] $alias]
    ::GX::SII::CanvasApplication::canvasState set $handle sii_import $request
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiImported {context role response} {
    if {[catch {
        dict with context {}
        _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
        if {![dict get $response ok]} {error [dict get $response error]}
        dict set context imported $role [dict get $response result]
        _nativeCanvasSiiImportNext $context
    } message]} {_nativeCanvasSiiFailed $context $message}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiGeometry {handle image provenance model logical {old {}}} {
    set original {}
    set removed {}
    if {$old ne {}} {
        set original [dict get $old logical_id]
        # The app owns the geometry-step rule. Preserve the original reset of
        # pixel-coordinate annotations when its crop/rotate/flip mapping changes.
        foreach key {gx.image.rois gx.image.annotations} {
            if {![dict exists $old resource metadata sketch_attributes $key]} {lappend removed $key}
        }
    }
    return [::GX::native2DCanvasSnapshotImage $handle $image $provenance $original 1 $logical [dict create gx.image.sii $model] $removed]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAdopt {context} {
    dict with context {}
    set row [_nativeCanvasSiiJobCurrent $window $component $handle $token $stamp]
    if {$intent in {native_publish resource_publish}} {
        # Publication consumes the completed output through its original
        # owner; it does not replace, flatten or commit the editable Canvas.
        set output [dict get $imported raster]
        if {$intent eq {resource_publish}} {
            set published [::GX::SII::_processingResourcePublish $job [dict get $output metadata source_output_token] [dict get $model publication] [list ::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationCurrent $context]]
        } else {set published [::GX::SII::_processingNativePublish $job [dict get $output metadata source_output_token] [dict get $model publication] [list ::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationCurrent $context]]}
        ::GX::SII::CanvasApplication::canvasState set $handle sii_analysis [dict create job_id $job result $result imported $imported publication $published]
        ::GX::SII::CanvasApplication::canvasState set $handle pending {}
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status completed job_id $job operation native_publish]
        ::GX::viewerGuiDesignTextSet $window sii_report "Native Document publication completed\n$published"
        catch {canvasState unset $handle sii_import}
        ::GX::native2DCanvasNotify $handle raster_completed
        _nativeCanvasSiiOutcomeHandled $context
        return [dict create status published job_id $job publication $published]
    }
    # Every imported Resource is original-owner verified. Retain the complete
    # dependency graph in the existing Canvas snapshot, never in an opaque
    # marker or a competing file store.
    set next $before
    foreach reference [dict values $imported] {dict lappend next retained_outputs $reference}
    if {$intent eq {source} && [dict get [::GX::native2DCanvasViewInfo $handle] gesture]} {
        # The original raster guard admitted only the actual pending pan.
        # Keep completed Resources in the existing candidate lifetime until its
        # normal pan-up scheduler callback. Atomic commit never adopts mid-drag.
        ::GX::SII::CanvasApplication::canvasState set $handle sii_candidate [dict create context $context snapshot $next]
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status completed_waiting_for_pan job_id $job operation source]
        ::GX::native2DCanvasNotify $handle raster_completed
        return [dict create status waiting_for_pan job_id $job]
    }
    if {$intent eq {source}} {
        # Like the original flatten owner, combine the operation sequence with
        # a fresh clock identity; a cold Canvas starts its live sequence at0.
        set logical sii_source_[dict get $stamp sequence]-[clock clicks]
        set geometry [_nativeCanvasSiiGeometry $handle [dict get $imported original_source] [dict get $imported provenance] $model $logical]
        set layer [dict get $next active_layer]
        set source [dict get $model source]
        set item [dict create logical_id $logical name {Raw Source / initial Working} resource $geometry \
            style {visible 1 selectable 1 locked 0 order 0 line_style 0 marker 0 line_width 1 color {1 1 1 1}} layer_logical_id $layer]
        if {![string match resource:* [dict get $source dataset_id]]} {dict set item source [_nativeCanvasSiiSourceBinding [dict get $source dataset_id]]}
        dict lappend next objects $item
        dict set next selection [list $logical]
        set held [dict get $context edit_held]
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
        dict set next selection [list $logical]
        _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
        # Source framing belongs to the same accepted snapshot as the image.
        # CORE fits its existing private staging scene, so refusal/cancellation
        # cannot change the old visible camera or leave an unpersisted fit.
        lassign [::GX::native2DResourceImageDimensions [dict get $imported original_source]] width height
        ::GX::SII::CanvasApplication::commitSnapshot $handle $held $next {Load original SII source} \
            [dict create fit_bounds [list 0 0 $width $height]]
        ::GX::native2DCanvasViewChanged $handle
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status completed job_id $job operation source]
    } elseif {$intent in {analysis publish}} {
        ::GX::SII::CanvasApplication::canvasState set $handle sii_analysis [dict create job_id $job result $result imported $imported]
        if {$intent eq {publish}} {
            set output [dict get $imported raster]
            set published [::GX::SII::_processingPublish $job [dict get $output metadata source_output_token] [dict get $model publication]]
            ::GX::viewerGuiDesignTextSet $window sii_report "Original SII publication completed\n$published"
        } else {::GX::viewerGuiDesignTextSet $window sii_report [dict get $result summary]}
        if {[dict exists $row sii_candidate]} {
            # Read-only Pending analysis does not commit/replace its parent
            # Canvas or invalidate the original accepted/candidate recipes.
            if {![_nativeCanvasSiiAnalysisParentRestore $context]} {error {Pending analysis no longer belongs to its original candidate}}
            set candidate [::GX::SII::CanvasApplication::canvasState get $handle sii_candidate]
            dict set candidate snapshot retained_outputs [concat [dict get $candidate snapshot retained_outputs] [dict values $imported]]
            ::GX::SII::CanvasApplication::canvasState set $handle sii_candidate $candidate
        } else {
            ::GX::SII::CanvasApplication::canvasState set $handle pending {}
            retainOutputs $handle [dict values $imported]
        }
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status completed job_id $job operation $intent]
    } else {
        # A completed candidate is NOT an accepted scientific edit. Its exact
        # Resources and recipe remain under the same actual Canvas lifetime.
        ::GX::SII::CanvasApplication::canvasState set $handle pending [list sii_candidate $job]
        ::GX::SII::CanvasApplication::canvasState set $handle sii_candidate [dict create context $context snapshot $next]
        # Comparison creation can yield to a real Discard/close. The verified
        # terminal outcome is already owned by this candidate; acknowledge it
        # through the original authority before presentation can be interrupted.
        _nativeCanvasSiiOutcomeHandled $context
        _nativeCanvasSiiCompare $handle
        ::GX::SII::CanvasApplication::canvasState set $handle raster_status [dict create status preview_ready job_id $job operation $intent]
        ::GX::viewerGuiDesignTextSet $window sii_report {Preview ready. Compare accepted Working on the left and this candidate on the right; Accept or Discard.}
    }
    catch {canvasState unset $handle sii_import}
    ::GX::native2DCanvasNotify $handle raster_completed
    if {$intent in {source analysis publish}} {_nativeCanvasSiiOutcomeHandled $context}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationCurrent {context} {
    dict with context {}
    if {$intent ni {native_publish resource_publish}} {error {Image publication requires its original captured operation}}
    _viewerGuiSiiRoles $window $component
    _viewerGuiSiiGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    _viewerGuiSiiGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    _viewerGuiSiiGrant $window DATASET_FILE_PUBLICATION_API_v1 datasetFilePublicationPublish
    set row [_nativeCanvasSiiJobCurrent $window $component $handle $token $stamp]
    ::GX::SII::CanvasApplication::appEditCurrent $handle $edit_held
    if {![dict exists $row pending job] || [dict get $row pending job] ne $job ||
        ![dict exists $row sii_job] || [dict get $row sii_job intent] ne $intent} {error {Native publication operation ended}}
    foreach key {job token stamp edit_held model} {
        if {[dict get $row sii_job $key] ne [dict get $context $key]} {error {Native publication context changed}}
    }
    if {$intent eq {resource_publish}} {
        set capture [dict get $model publication_source]
        if {[dict get $capture job_id] ne $job || [dict get $capture input_alias] ne {source1} ||
            [_nativeCanvasSiiTarget $handle] ne [dict get $model publication_target]} {error {Selected publication image or captured receipt changed}}
        set request [dict get [_nativeCanvasSiiCurrentJob $job] scientific_request]
        if {[dict get $request image_resource_sources] ne [dict create source1 [dict get $capture resource]] ||
            [dict get $request image_recipe] ne [dict create kind image source [_nativeCanvasSiiResourceSource [dict get $capture resource]] operation process steps {} format [dict get $model publication format]]} {error {Selected publication Job differs from its original current-pixel capture}}
        ::GX::scientificExecutionSourcesCurrent [dict get $request source_identities]
        dict set row sii_resource_publication $capture
        return $row
    }
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPublicationPrecision {reference} {
    set status [::GX::scientificExecutionStatus [dict get $reference metadata source_job_id]]
    set provider [dict get $status provider_id]
    set job [dict create id [dict get $status job_id]]
    if {$provider eq {core.native2d.raster}} {
        set proof [_nativeCanvasSiiCaptureNativeInputProof $reference]
        set descriptor [dict get $proof output]
        set summary [dict get [::GX::scientificExecutionOutputs [dict get $job id]] summary]
        set stage derived_rgba8_sRGB
    } else {
        set proof [_nativeCanvasSiiResourceJob $reference]
        if {$proof eq {}} {error {Selected publication raster has no original producing owner}}
        set job [dict get $proof job]
        set observed [_nativeCanvasSiiResourceObserve $reference]
        if {[llength [dict get $observed outputs]]!=1} {error {Selected publication raster is ambiguous}}
        set descriptor [lindex [dict get $observed outputs] 0]
        set summary [dict get $observed summary]
        set stage [expr {[dict get $job scientific_request image_recipe kind] eq {figure} ? {completed_sii_figure_raster} : {completed_sii_image_raster}}]
    }
    if {[dict get $descriptor role] ne {raster} || [dict get $descriptor sha256] ne [dict get $reference sha256] ||
        [dict get $descriptor size_bytes]!=[dict get $reference size_bytes] || [dict get $descriptor source_generation] ne [dict get $reference metadata source_generation]} {error {Selected raster precision record is outside its actual immutable output}}
    set output {};foreach key {role format token source_generation sha256 size_bytes live} {dict set output $key [dict get $descriptor $key]}
    return [dict create schema scientific_image_inspector.current_resource_precision.v1 pixel_stage $stage provider_id $provider producing_job_id [dict get $job id] \
        resource_sha256 [dict get $reference sha256] resource_generation [dict get $reference owner_generation] output_receipt $output owner_summary $summary]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiResourcePublicationModel {handle model publication} {
    set held [::GX::native2DCanvasEditCapture $handle]

    set target [_nativeCanvasSiiTarget $handle]
    set item [snapshotLeaf [heldSnapshot $handle $held] [dict get $target object]]
    set reference [dict get $target resource]
    set lineage [_nativeCanvasSiiCaptureLineage $item $reference]
    if {![llength [dict get $lineage sources]]} {error {Import the local source through Acquisition before publication}}
    set precision [_nativeCanvasSiiPublicationPrecision $reference]
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    if {[_nativeCanvasSiiTarget $handle] ne $target} {error {Selected image changed during publication capture}}
    dict set model source [_nativeCanvasSiiResourceSource $reference]
    dict set model image steps {}
    dict set model current_resource $reference
    dict set model publication $publication
    dict set model publication_target $target
    dict set model publication_held $held
    dict set model publication_source [dict create schema scientific_image_inspector.selected_resource_publication.v1 job_id {} input_alias source1 \
        resource $reference lineage $lineage selected_item $item precision $precision]
    return $model
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiSourceBinding {dataset} {
    # Same existing canonical raster binding fields; all values come from the
    # original Session owners, not a request or a derived byte/readstamp hash.
    set payload [::GX::sessionInspectionDatasetPayload $dataset]
    set binding [dict create dataset_id $dataset dataset_identity [::GX::sessionInspectionDataset $dataset] \
        variable_schema [::GX::datasetVariableSchemaV3 $dataset] source_sha256 [dict get $payload sha256] origin [::GX::datasetOriginRead $dataset]]
    ::GX::viewerGuiRasterSourceCurrent $binding
    return $binding
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCompareClose {handle} {
    if {![canvasState exists $handle sii_comparison]} return
    set comparison [canvasState get $handle sii_comparison]
    set temporary [dict get $comparison handle]
    _nativeCanvasSiiLodCancel $temporary
    ::GX::native2DCanvasReadOnlyViewDispose $handle $temporary
    canvasState unset $handle sii_comparison
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCompare {handle} {
    _nativeCanvasSiiCompareClose $handle
    if {[catch {set host [::GX::native2DCanvasPresentationHost $handle]}]} {return {status unmounted}}
    set row [appRecord $handle];set candidate [dict get $row sii_candidate]
    set context [dict get $candidate context];set temporary {}
    try {
        set temporary [::GX::native2DCanvasReadOnlyViewCreate $handle [dict get $context imported raster] \
            [dict get $candidate snapshot retained_outputs] {Pending candidate — Accept or Discard}]
        canvasState set $handle sii_comparison [dict create handle $temporary parent [dict get $host frame]]
        set association [_nativeCanvasSiiPreferencesForHandle $handle]
        if {$association ne {}} {
            if {[dict get $association window] ne [dict get $context window] || [dict get $association component] ne [dict get $context component]} {error {Pending presentation belongs to another actual Viewer}}
            _nativeCanvasSiiPresentationApply [dict get $association window] [dict get $association component] $handle [dict get $association prefs]
        }
        ::GX::native2DCanvasSchedule $temporary
    } on error {message options} {
        if {$temporary ne {}} {catch {::GX::native2DCanvasReadOnlyViewDispose $handle $temporary}}
        catch {canvasState unset $handle sii_comparison}
        return -options $options $message
    }
    return {status compared}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiResumeSourceAdoption {handle} {
    if {![::GX::SII::CanvasApplication::canvasState exists $handle sii_candidate context]} {return 0}
    set row [appRecord $handle]
    set context [dict get $row sii_candidate context]
    if {[dict get $context intent] ne {source} || [dict get [::GX::native2DCanvasViewInfo $handle] gesture]} {return 0}
    if {[catch {_nativeCanvasSiiAdopt $context} message]} {
        catch {canvasState unset $handle sii_candidate}
        _nativeCanvasSiiFailed $context $message
    }
    return 1
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiGeometrySteps {steps} {
    set result {}
    foreach step $steps {
        if {[dict get [::GX::SII::catalogGet [dict get $step op]] family] eq {Geometry}} {lappend result $step}
    }
    return $result
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiImageSnapshot {handle held model imported} {
    set next [heldSnapshot $handle $held]
    set logical [dict get $model object]
    set original [snapshotLeaf $next $logical]
    snapshotEditable $next $original
    set proof [_nativeCanvasSiiResourceJob [dict get $imported raster]]
    if {$proof eq {}} {error {Selected Working image requires its owned completed processing Job}}
    set recipe [dict get $proof job scientific_request image_recipe]
    if {[dict get $recipe kind] ne {image} || [dict get $recipe operation] ne {process} ||
        [dict get $recipe source] ne [dict get $model source] || [dict get $recipe steps] ne [dict get $model image steps]} {error {Selected Working model differs from its exact completed processing recipe}}
    set metadata [dict get $original resource metadata]
    set previous [::GX::datasetPublicationV2DictDefault [::GX::datasetPublicationV2DictDefault $metadata sketch_attributes {}] gx.image.sii [_nativeCanvasSiiInitialModel [dict get $model source]]]
    set working [dict replace [dict remove $model object] role working canvas_mode image]
    if {[dict get $model role] eq {derived}} {
        # The old copied marker is not the current processing recipe. Only a
        # proven same-object canonical ancestor can supply original geometry.
        set previous $model
        dict set previous original_binding {}
        if {[dict get $model native_operation] eq {canvas_filter}} {
            set ancestor [_nativeCanvasSiiCanonicalAncestor $handle $held $logical]
            if {$ancestor ne {}} {
                dict set previous original_geometry [dict get $ancestor item resource]
                dict set previous original_binding [dict get $ancestor item source]
                dict set working original_source [dict get $ancestor source]
            }
        }
    }
    if {[dict exists $previous original_geometry]} {
        dict set working original_geometry [dict get $previous original_geometry]
    } else {dict set working original_geometry [dict get $original resource]}
    if {[dict exists $previous original_binding]} {
        dict set working original_binding [dict get $previous original_binding]
    } elseif {[dict exists $original source]} {dict set working original_binding [dict get $original source]}
    set dimensions [_nativeCanvasSiiImageDimensions [dict get $imported raster]]
    set oldDimensions [list [expr {wide([dict get $metadata reference_image width])}] [expr {wide([dict get $metadata reference_image height])}]]
    set seed $original
    if {$dimensions ne $oldDimensions || [_nativeCanvasSiiGeometrySteps [dict get $previous image steps]] ne [_nativeCanvasSiiGeometrySteps [dict get $model image steps]]} {
        # Crop/rotate/flip mappings cannot inherit old pixel coordinates merely
        # because two output dimensions happen to match. Original-source ROIs
        # remain in the real retained original geometry and document History.
        foreach key {gx.image.rois gx.image.annotations} {dict unset seed resource metadata sketch_attributes $key}
    }
    set geometry [_nativeCanvasSiiGeometry $handle [dict get $imported raster] [dict get $imported provenance] $working $logical $seed]
    set objects {}
    foreach item [dict get $next objects] {
        if {[dict get $item logical_id] eq $logical} {dict set item resource $geometry}
        lappend objects $item
    }
    foreach reference [concat [list [dict get $original resource metadata image_resource]] [dict values $imported]] {dict lappend next retained_outputs $reference}
    dict set next objects $objects
    dict set next selection [list $logical]
    return $next
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiOriginalSnapshot {handle held model} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set next [heldSnapshot $handle $held]
    set logical [dict get $model object]
    set current [snapshotLeaf $next $logical]
    snapshotEditable $next $current
    if {[dict get $model role] eq {derived}} {
        if {[dict get $model native_operation] ne {canvas_filter}} {error {Use original Canvas Undo to restore the complete pre-flatten composition}}
        set ancestor [_nativeCanvasSiiCanonicalAncestor $handle $held $logical]
        if {$ancestor eq {}} {error {No proven same-object canonical Raw ancestor remains; use original Canvas Undo}}
        dict set model original_geometry [dict get $ancestor item resource]
        dict set model original_binding [dict get $ancestor item source]
        dict set model original_source [dict get $ancestor source]
    }
    set originalSource [::GX::datasetPublicationV2DictDefault $model original_source [dict get $model source]]
    if {[dict exists $model original_geometry]} {set reference [dict get $model original_geometry]} elseif {[dict get $model role] eq {source}} {
        set reference [dict get $current resource]
    } else {error {This accepted image has no retained original geometry; use original Canvas Undo}}
    ::GX::interactiveDocumentResourceInfo $reference
    if {[dict get $reference document_id] ne [dict get $row document] || ![dict exists $reference owner_generation] || [dict get $reference owner_generation] ne [dict get $row receipt generation]} {error {Original image geometry belongs to another Document generation}}
    set raw [dict get $reference metadata image_resource]
    ::GX::interactiveDocumentResourceInfo $raw
    set binding [::GX::datasetPublicationV2DictDefault $model original_binding [::GX::datasetPublicationV2DictDefault $current source {}]]
    set original [dict replace $current resource $reference]
    if {$binding ne {}} {
        dict set original source $binding
        ::GX::viewerGuiRasterSourceCurrent $binding
        if {[dict get $raw sha256] ne [dict get $binding source_sha256] || $originalSource ne [dict remove [::GX::quantitativeRasterSourceIdentity [dict get $binding dataset_id]] source_stamp]} {error {Retained original image differs from its current canonical source}}
    } else {dict unset original source}
    set dimensions [_nativeCanvasSiiImageDimensions $raw]
    if {$dimensions eq {}} {
        if {$binding eq {}} {error {Local original image lacks its completed sealed-input provenance}}
        set dimensions [::GX::native2DResourceImageDimensions $raw]
    }
    set state [dict get $reference metadata reference_image]
    if {[list [expr {wide([dict get $state width])}] [expr {wide([dict get $state height])}]] ne $dimensions || [dict get $state resource_id] ne [dict get $raw sha256]} {error {Retained original geometry differs from its verified full image}}
    set reset [_nativeCanvasSiiInitialModel $originalSource]
    dict set reset original_geometry $reference
    if {$binding ne {}} {dict set reset original_binding $binding}
    set currentImage [::GX::native2DCanvasImageInfo $handle $logical]
    set scene [::GX::native2DGeometryOpen [dict get $row document]]
    try {
        set object [geometryRestore $scene $reference]
        ::GX::native2DGeometryCall $scene image_copy_presentation [dict create object_token $object source_geometry [dict get $currentImage geometry] source_object_token [dict get $currentImage object_token]]
        geometryAttribute $scene $object gx.image.sii $reset
        set geometry [geometryStore $scene $object [dict get $reference metadata]]
    } finally {::GX::native2DGeometryClose $scene}
    dict set original resource $geometry
    set objects {}
    foreach item [dict get $next objects] {if {[dict get $item logical_id] eq $logical} {set item $original};lappend objects $item}
    dict set next objects $objects
    return $next
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCanonicalAncestor {handle held logical} {
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    set current [snapshotLeaf [heldSnapshot $handle $held] $logical]
    if {[catch {set lineage [_nativeCanvasSiiCaptureLineage $current [dict get $current resource metadata image_resource]]} message options]} {
        if {[::GX::datasetPublicationV2DictDefault $options -errorcode {}] ne {GXTXT SII NO_CANONICAL_ORIGIN}} {return -options $options $message}
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
        return {}
    }
    set origins {};foreach source [dict get $lineage sources] {dict set origins [dict get $source dataset_id] $source}
    set history [dict get $row history]
    scientificHistoryValidate framework.native2d.canvas $history
    set state [dict get $history base];set candidate {}
    for {set index 0} {$index<=[dict get $history cursor]} {incr index} {
        foreach item [dict get $state objects] {
            if {[dict get $item logical_id] ne $logical || ![dict exists $item source] || ![dict exists $item resource metadata image_resource]} continue
            set reference [dict get $item resource metadata image_resource]
            if {[::GX::datasetPublicationV2DictDefault [dict get $reference metadata] source_kind {}] eq {canonical_dataset} &&
                [dict get $reference sha256] eq [dict get $item source source_sha256] &&
                [dict exists $origins [dict get $item source dataset_id]]} {set candidate $item}
        }
        if {$index<[dict get $history cursor]} {set state [::GX::scientificRecipeApplyPatch $state [dict get [lindex [dict get $history steps] $index] patch]]}
    }
    if {$candidate eq {}} {::GX::SII::CanvasApplication::appEditCurrent $handle $held;return {}}
    set source [_nativeCanvasSiiCanonicalSource $candidate [dict get $candidate resource metadata image_resource]]
    if {$source ne [dict get $origins [dict get $source dataset_id]]} {error {Historical Raw image is outside the actual producing input lineage}}
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return [dict create item $candidate source $source]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiHistoryContent {snapshot presentation} {
    # Selection/navigation alone is not a later scientific edit. Every content
    # field, active layer and Resource association remains structurally exact.
    foreach key {view_state tool selection} {dict set snapshot $key [dict get $presentation $key]}
    return [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {named canvas_snapshot} $snapshot]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiUndoFlatten {handle model} {
    set target [_nativeCanvasSiiTargetFor $handle [dict get $model object] 1]
    set held [::GX::native2DCanvasEditCapture $handle]

    set proof [_nativeCanvasSiiCaptureNativeInputProof [dict get $target resource]]
    if {[dict get $proof operation] ne {canvas_flatten}} {error {Selected image has no actual flatten transition}}
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    set history [dict get $row history]
    scientificHistoryValidate framework.native2d.canvas $history
    set cursor [dict get $history cursor]
    set refusal {Restore Original cannot undo a later or copied image edit. Use Canvas Undo explicitly to return to the pre-flatten composition}
    if {$cursor<1} {error $refusal}
    set before [::GX::scientificHistoryState $history [expr {$cursor-1}]]
    set after [::GX::scientificHistoryState $history $cursor]
    set original [dict get $proof manifest snapshot]
    if {[_nativeCanvasSiiHistoryContent $before $original] ne [_nativeCanvasSiiHistoryContent $original $original] ||
        [_nativeCanvasSiiHistoryContent [heldSnapshot $handle $held] $after] ne [_nativeCanvasSiiHistoryContent $after $after] ||
        [llength [dict get $after objects]]!=1 || [llength [dict get $after layers]]!=1 || [dict get $after groups] ne {} || [dict get $after background] ne {0 0 0 0}} {error $refusal}
    set only [lindex [dict get $after objects] 0]
    if {[dict get $only logical_id] ne [dict get $target object] ||
        [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} [dict get $only resource metadata image_resource]]] ne
        [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} [dict get $target resource]]]} {error $refusal}
    if {[_nativeCanvasSiiTargetFor $handle [dict get $target object] 1] ne $target} {error {Selected flatten target changed}}
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return [::GX::native2DCanvasCommand $handle undo]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiAccept {window handle} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {![dict exists $row sii_candidate]} {error {No completed SII candidate to accept}}
    set candidate [dict get $row sii_candidate];set context [dict get $candidate context]
    dict with context {}
    _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
    if {$intent eq {source}} {return [_nativeCanvasSiiAdopt $context]}
    set held [dict get $context edit_held]
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    set next [heldSnapshot $handle $held]
    foreach reference [dict values $imported] {dict lappend next retained_outputs $reference}
    if {$intent eq {image}} {
        set logical [dict get $model object]
        set next [_nativeCanvasSiiImageSnapshot $handle $held $model $imported]
        _nativeCanvasSiiCompareClose $handle
        _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
        ::GX::SII::CanvasApplication::commitSnapshot $handle $held $next {Accept selected SII image preview}
        return [dict create status accepted job_id $job object $logical]
    }
    if {$intent eq {figure}} {
        set actual [_nativeCanvasSiiCurrentJob $job]
        set proof [dict create job_id $job raster [dict get $imported raster] provenance [dict get $imported provenance] document_guard [_nativeCanvasSiiGuard $row] request [dict get $actual scientific_request image_recipe]]
        set next [_nativeCanvasSiiFigureLayout $handle $held $proof]
        foreach reference [dict values $imported] {
            if {$reference ni [dict get $next retained_outputs]} {dict lappend next retained_outputs $reference}
        }
        _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
        _nativeCanvasSiiCompareClose $handle
        _nativeCanvasSiiJobCurrent $window $component $handle $token $stamp
        ::GX::SII::CanvasApplication::commitSnapshot $handle $held $next {Accept editable native Figure layout}
        return [dict create status accepted job_id $job frame_only 1 pixel_equivalence 0]
    }
    error {Unsupported SII candidate intent; no Canvas state adopted}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiInputLocked {handle kind {data {}}} {
    set row [appRecord $handle]
    if {![dict exists $row sii_candidate] && !([dict exists $row sii_job] && [dict get $row pending] ne {})} {return 0}
    # Resize, pan/zoom and metadata reads keep their original owner paths.
    # Editing may not reach the ROI early dispatcher before this guard.
    if {$kind in {resize wheel}} {return 0}
    set view [::GX::native2DCanvasViewInfo $handle]
    set tool [dict get $view tool]
    if {$tool eq {pan} && $kind in {down move up}} {return 0}
    if {$tool eq {pan} && $kind eq {key} && [::GX::datasetPublicationV2DictDefault $data key {}] eq {Escape} && [dict get $view gesture]} {return 0}
    return [expr {$kind in {down move up key}}]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiModelSnapshot {handle held model} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    set next [heldSnapshot $handle $held]
    set logical [dict get $model object]
    set original [snapshotLeaf $next $logical]
    snapshotEditable $next $original
    set scene [::GX::native2DGeometryOpen [dict get $row document]]
    try {
        set reference [dict get $original resource]
        set object [geometryRestore $scene $reference]
        geometryAttribute $scene $object gx.image.sii [dict remove $model object]
        set replacement [geometryStore $scene $object [dict get $reference metadata]]
    } finally {
        ::GX::native2DGeometryClose $scene
    }
    set objects {}
    foreach item [dict get $next objects] {
        if {[dict get $item logical_id] eq $logical} {dict set item resource $replacement}
        lappend objects $item
    }
    dict set next objects $objects
    return $next
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiModelStore {handle model description} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {[dict get $row pending] ne {} || [dict exists $row sii_candidate]} {error {Accept, discard or cancel the pending SII operation before editing its model}}
    set target [_nativeCanvasSiiTarget $handle]
    if {[dict get $target object] ne [dict get $model object]} {error {SII model no longer targets the selected image}}
    set held [::GX::native2DCanvasEditCapture $handle]

    set next [_nativeCanvasSiiModelSnapshot $handle $held $model]
    ::GX::SII::CanvasApplication::commitSnapshot $handle $held $next $description
    return {status accepted}
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiSelectedRoi {handle model} {
    set selection [dict get [::GX::native2DCanvasDescribe $handle] selection]
    if {[llength $selection]!=1} {error {Select exactly the Working image and a retained rectangle ROI}}
    set logical [lindex $selection 0]
    if {$logical ne [dict get $model object]} {error {SII ROI belongs to the exact selected Canvas image}}
    if {[llength [dict get $model image steps]] && [dict get $model role] ne {working}} {error {Processing ROI requires the selected accepted Working image}}
    set context [_nativeCanvasRoiContext $handle $logical]
    set roi [_nativeCanvasRoiSelected $context]
    if {$roi eq {}} {error {Select a retained Working rectangle ROI first}}
    # Same native ROI geometry/half-open pixel-cell clipping owner, without
    # weakening the separate canonical quantitative source guard.
    set result [_quantitativeCanvasRoi $context [dict create roi_id $roi]]
    return [list [dict get $result x] [dict get $result y] [dict get $result width] [dict get $result height]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureRequest {model format} {
    return [dict create kind figure panels [dict get $model figure panels] settings [dict get $model figure figure_settings] \
        annotations [dict get $model figure figure_annotations] format $format]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiNativeFigureSeed {handle format} {
    set held [::GX::native2DCanvasEditCapture $handle]

    set state [_nativeCanvasSiiFigureGet $handle]
    if {[llength [dict get $state diagnostics missing]]} {error {Reconcile missing native Figure members before preparing a layout}}
    set panels {};set model {}
    foreach logical [dict get $state panels] {
        set actual [_nativeCanvasSiiImageModelFor $handle $logical 0]
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
        if {$model eq {}} {set model $actual}
        lappend panels [dict create source [dict get $actual source] steps [dict get $actual image steps]]
    }
    if {![llength $panels]} {error {Select an owned Canvas image and add a native Figure panel first}}
    # This original recipe creates only a hidden coordinate/layout frame.
    # Publication captures all actual Document paint through the Root binder.
    set request [dict create kind figure panels $panels settings [dict get $state settings] annotations {} format $format]
    dict set model figure [dict create panels $panels figure_settings [dict get $state settings] figure_annotations {}]
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return [dict create request $request model $model]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiEditorAction {window component handle action} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {$action eq {open_local}} {
        if {[dict get $row pending] ne {} || [dict exists $row sii_candidate]} {error {Accept, discard or cancel the current SII preview before choosing a local image}}
        set context [dict create window $window component $component handle $handle token [dict get [viewerRecord $window] token] \
            stamp [canvasStamp $handle] selected [dict get [::GX::viewerGuiDesignValues $window] source_raster]]
        after idle [list ::GX::SII::CanvasApplication::_nativeCanvasSiiChooseLocal $context]
        return {status awaiting_user_choice}
    }
    if {$action eq {source_changed}} {
        if {[dict exists [dict get $row pending] recovery]} {return [dict merge [dict get $row raster_status] {ready 0 retry_allowed 0}]}
        if {[dict get $row pending] ne {} || [dict exists $row sii_candidate]} {
            if {[dict exists $row sii_job stamp sii_source]} {
                set prior [dict get $row sii_job stamp sii_source dataset_id]
                ::GX::viewerGuiDesignValueSet $window source_raster [expr {[string match resource:* $prior]?{}:$prior}]
            }
            error {Accept, discard or cancel the current SII preview before changing Source}
        }
        set source [_nativeCanvasSiiSource $window]
        if {![string match resource:* [dict get $source dataset_id]]} {catch {viewerState unset $window sii_local_source}}
        set model [_nativeCanvasSiiInitialModel $source]
        return [_nativeCanvasSiiStart $window $component $handle [dict create kind image source $source operation process steps {} format miff] source $model]
    }
    if {$action eq {status}} {
        # Native Figure commits advance the receipt/Canvas generation while
        # retaining inert scientific readiness. Resolve a noncurrent attachment
        # through original metadata recovery; never restamp cached READY.
        if {[dict exists [dict get $row pending] recovery] || ([dict exists $row sii_readiness state] &&
            ([dict get $row sii_readiness state] in {UNKNOWN RETIRED CONSUMED} ||
             ([dict exists $row sii_readiness context] &&
              ![_nativeCanvasSiiReadinessOwns [dict get $row sii_readiness context]])) &&
            [dict get $row pending] eq {} && ![dict exists $row sii_source_starting])} {
            return [_nativeCanvasSiiReadiness $window $component $handle 1]
        }
        if {[dict exists $row sii_job tracked] && [dict get $row sii_job tracked]} {
            return [_nativeCanvasSiiTrackedStatus [dict get $row sii_job]]
        }
        if {[dict exists [dict get $row pending] admission] && [dict exists $row sii_job]} {
            _nativeCanvasSiiAdmissionResolve [dict get $row sii_job] 0 0
            return [::GX::SII::CanvasApplication::canvasState get $handle raster_status]
        }
        set status [::GX::datasetPublicationV2DictDefault $row raster_status {status idle}]
        if {[dict exists $status job_id]} {dict set status job [::GX::scientificExecutionStatus [dict get $status job_id]]}
        ::GX::viewerGuiDesignTextSet $window sii_report $status
        return $status
    }
    if {$action in {cancel discard}} {
        if {[dict exists [dict get $row pending] recovery]} {
            if {$action eq {discard}} {return [_nativeCanvasSiiRecoveryDiscard $window $component $handle]}
            ::GX::native2DCanvasOperationCancel $handle
            return [_nativeCanvasSiiReadiness $window $component $handle 1 1]
        }
        if {[dict exists $row sii_candidate context] && [dict get $row sii_candidate context intent] eq {source}} {
            # A completed source waiting for pan-up has no presentation/commit
            # yet. Explicit discard still handles that exact terminal outcome.
            _nativeCanvasSiiOutcomeHandled [dict get $row sii_candidate context]
        }
        if {[dict exists $row sii_import]} {::GX::scientificExecutionImageImportCancel [dict get $row sii_import]}
        ::GX::native2DCanvasOperationCancel $handle
        _nativeCanvasSiiCompareClose $handle
        catch {canvasState unset $handle sii_candidate}
        if {$action eq {discard} && [dict exists $row sii_candidate]} {
            ::GX::viewerGuiDesignTextSet $window sii_report {Preview discarded. The accepted Canvas is unchanged.}
        }
        return [dict create status [expr {$action eq {discard}?{discarded}:{canceled}}]]
    }
    if {$action eq {accept}} {return [_nativeCanvasSiiAccept $window $handle]}
    if {$action eq {refresh_sources}} {
        set widget [dict get [::GX::viewerGuiComponentHost $window source_raster] widget]
        ::GX::datasetSelectorRefresh $widget.entry
        return {status refreshed}
    }
    if {$action eq {copy_report}} {
        set widget [dict get [::GX::viewerGuiComponentHost $window sii_report] widget]
        clipboard clear -displayof $window;clipboard append -displayof $window [$widget get 1.0 end-1c]
        return {status copied}
    }
    if {$action eq {close}} {
        # The same normal owner used by WM_DELETE_WINDOW handles draft review,
        # Workspace save/discard/cancel and captured library request draining.
        ::GX::viewerGuiDesignClose $window
        return [dict create status [expr {[winfo exists $window]?{close_review_retained}:{closed}}]]
    }
    if {$action in {image_undo image_redo figure_undo figure_redo}} {
        return [::GX::native2DCanvasCommand $handle [expr {$action in {image_undo figure_undo}?{undo}:{redo}}]]
    }
    if {$action in {upsert_entity remove_entity reset_figure annotation_select_all annotation_select_none annotation_copy annotation_paste}} {
        return [_nativeCanvasSiiFigureEdit $window $handle $action]
    }
    if {$action in [_nativeCanvasSiiPresentationActions]} {return [_nativeCanvasSiiPresentation $window $component $handle $action {}]}
    set values [::GX::viewerGuiDesignValues $window]
    if {$action eq {publish} && [dict get $values sii_mode] in {{Figure settings} Panel Annotation}} {
        set format [dict get $values sii_format]
        if {$format ni {png16 tiff16 tiff32f}} {error {Native Document publication requires an original high-depth publication format}}
        ::GX::datasetPublicationV2ValidateId dataset [dict get $values sii_output_id]
        set model [dict create publication [dict create dataset_id [dict get $values sii_output_id] format $format]]
        return [_nativeCanvasSiiStart $window $component $handle [dict create kind figure format $format] native_publish $model]
    }
    if {$action eq {preview} && [dict get $values sii_mode] in {{Figure settings} Panel Annotation}} {
        set seed [_nativeCanvasSiiNativeFigureSeed $handle tiff32f]
        return [_nativeCanvasSiiStart $window $component $handle [dict get $seed request] figure [dict get $seed model]]
    }
    set model [_nativeCanvasSiiImageModel $handle]
    set source [dict get $model source]
    if {$action in {reset_image restore_original}} {
        if {[::GX::datasetPublicationV2DictDefault $model native_operation {}] eq {canvas_flatten}} {
            return [_nativeCanvasSiiUndoFlatten $handle $model]
        }
        set held [::GX::native2DCanvasEditCapture $handle]

        set next [_nativeCanvasSiiOriginalSnapshot $handle $held $model]
        return [::GX::SII::CanvasApplication::commitSnapshot $handle $held $next {Restore selected original image}]
    }
    set values [::GX::viewerGuiDesignValues $window]
    if {$action in {preview grayscale invert reset_image restore_original remove_step publish run_analysis}} {
        if {$action ni {publish run_analysis} && ([dict get $row pending] ne {} || [dict exists $row sii_candidate])} {error {Accept, discard or cancel the current preview first}}
        set steps [dict get $model image steps]
        if {$action in {preview grayscale invert}} {
            if {$action eq {preview}} {
                _viewerGuiSiiEditorFields $window $handle value_changed
                set draft [viewerState get $window sii_editor]
                set mode [dict get $draft mode]
                if {$mode in {{Figure settings} Panel Annotation}} {
                    return [_nativeCanvasSiiStart $window $component $handle [_nativeCanvasSiiFigureRequest $model tiff32f] figure $model]
                }
                if {$mode eq {Preset}} {set additions [_viewerGuiSiiEditorValue $window]} else {
                    set additions [list [dict create op [dict get $draft item] params [_viewerGuiSiiEditorValue $window]]]
                }
                if {![llength $additions]} {
                    ::GX::viewerGuiDesignTextSet $window sii_report {Manual adjustments are unchanged; no processing step or preview was created.}
                    return {status unchanged}
                }
            } elseif {$action eq {grayscale}} {set additions [list [dict create op colorspace params {space Gray}]]} else {set additions [list [dict create op negate params {}]]}
            set roi {};set scope all
            if {[dict get $values sii_scope] eq {selected ROI}} {set roi [_nativeCanvasSiiSelectedRoi $handle $model];set scope roi}
            foreach step $additions {dict set step scope $scope;dict set step roi $roi;lappend steps $step}
            set steps [::GX::SII::validateSteps $steps]
        } elseif {$action in {reset_image restore_original}} {
            dict set model image reset_previous [dict get $model image]
            set steps {}
        } elseif {$action eq {remove_step}} {
            set index [dict get $values sii_step_index]
            if {![string is entier -strict $index] || $index<1 || $index>[llength $steps]} {error {Choose an existing one-based processing step index}}
            set steps [lreplace $steps [expr {$index-1}] [expr {$index-1}]]
        }
        if {$action eq {run_analysis}} {
            set operation [dict get {Statistics statistics Histogram histogram {Dominant palette} palette Pixel pixel {Preview channel} channel_preview {Image information} inspect} [dict get $values sii_analysis]]
            set target [dict get $values sii_analysis_target]
            if {$target eq {Source}} {set steps {}}
            if {$target eq {Preview}} {
                if {![dict exists $row sii_candidate]} {error {There is no actual completed pending preview to analyze}}
                set candidateModel [dict get $row sii_candidate context model]
                set steps [dict get $candidateModel image steps]
            }
            set analysis {}
            if {$operation in {statistics histogram channel_preview}} {dict set analysis channel [dict get $values sii_analysis_channel]}
            if {$operation in {statistics histogram palette} && $target eq {Working} && [dict get $values sii_scope] eq {selected ROI}} {dict set analysis roi [_nativeCanvasSiiSelectedRoi $handle $model]}
            if {$operation eq {palette}} {dict set analysis colors [dict get $values sii_palette_colors]}
            if {$operation eq {pixel}} {dict set analysis x [dict get $values sii_pixel_x];dict set analysis y [dict get $values sii_pixel_y]}
            set request [dict create kind image source $source operation $operation steps $steps analysis_target $target analysis $analysis]
            return [_nativeCanvasSiiStart $window $component $handle $request analysis $model]
        }
        if {$action eq {publish}} {
            set format [dict get $values sii_format]
            if {$format ni {png16 tiff16 tiff32f}} {error {Image publication requires an original high-depth publication format}}
            ::GX::datasetPublicationV2ValidateId dataset [dict get $values sii_output_id]
            set target [_nativeCanvasSiiTarget $handle]
            if {[dict get $model role] ne {source} || [dict get $model image steps] ne {} ||
                [::GX::datasetPublicationV2DictDefault [dict get $target resource metadata] source_kind {}] ne {canonical_dataset}} {
                set publication [dict create dataset_id [dict get $values sii_output_id] format $format]
                set model [_nativeCanvasSiiResourcePublicationModel $handle $model $publication]
                return [_nativeCanvasSiiStart $window $component $handle [dict create kind image source [dict get $model source] operation process steps {} format $format] resource_publish $model]
            }
            dict set model publication [dict create dataset_id [dict get $values sii_output_id] format $format]
            set mode [dict get $values sii_mode]
            if {$mode in {{Figure settings} Panel Annotation}} {set request [_nativeCanvasSiiFigureRequest $model $format]} else {set request [dict create kind image source $source operation process steps $steps format $format]}
            return [_nativeCanvasSiiStart $window $component $handle $request publish $model]
        }
        dict set model image steps $steps
        return [_nativeCanvasSiiStart $window $component $handle [dict create kind image source $source operation process steps $steps format miff] image $model]
    }
    return [_nativeCanvasSiiPresentation $window $component $handle $action $model]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiPresentation {window component handle action model} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    switch -- $action {
        grid_toggle {
            set prefs [_nativeCanvasSiiPreferencesGet $window $component]
            return [_nativeCanvasSiiPreferencesSet $window $component [dict create grid [expr {![dict get $prefs grid]}]]]
        }
        history_toggle {
            if {[catch {::GX::scientificHistoryViewerStripGet $window}]} {error {Open this Viewer through its original Workspace/History owner to show the Description strip}}
            ::GX::scientificHistoryViewerStripToggle $window
            return {status presented}
        }
        comparison_toggle {
            set prefs [_nativeCanvasSiiPreferencesGet $window $component]
            return [_nativeCanvasSiiPreferencesSet $window $component [dict create sync [expr {![dict get $prefs sync]}]]]
        }
        pending_toggle {
            set prefs [_nativeCanvasSiiPreferencesGet $window $component]
            return [_nativeCanvasSiiPreferencesSet $window $component [dict create pending_visible [expr {![dict get $prefs pending_visible]}]]]
        }
        actual_pixels {
            set targets [list $handle]
            if {[dict exists $row sii_comparison]} {lappend targets [dict get $row sii_comparison handle]}
            foreach target $targets {
                set current [appRecord $target];set images {}
                foreach item [dict get [::GX::native2DCanvasRetainedInfo $target] objects] {
                    if {[dict get $item kind] eq {image}} {dict set images [dict get $item logical_id] 1}
                }
                foreach descriptor [dict get [::GX::native2DCanvasPaintOrder $target] objects] {
                    set logical [dict get $descriptor logical_id]
                    if {![dict exists $images $logical]} continue
                    set facts [::GX::native2DCanvasImageInfo $target $logical]
                    set geometry [dict get $facts geometry];set object [dict get $facts object_token]
                    set image [dict get $facts image state];set reference [dict get $facts image resource]
                    if {![dict get [::GX::native2DGeometryCall $geometry describe [dict create object_token $object]] style visible]} continue
                    # Original regular display preview width, never an LOD tile.
                    set projection [_nativeCanvasSiiProjection [dict remove $current sii_lod_ready] $reference $image]
                    if {$projection eq {}} continue
                    set first [geometryDevice $geometry [geometryImageMap $geometry $object [list 0 [dict get $image height]]]]
                    set last [geometryDevice $geometry [geometryImageMap $geometry $object [list [dict get $image width] 0]]]
                    set span [expr {abs([lindex $last 0]-[lindex $first 0])}]
                    if {$span>=1} {
                        lassign [dict get [::GX::native2DCanvasViewInfo $target] viewport] width height
                        ::GX::native2DGeometryCall $geometry zoom [dict create factor [expr {$span/double([dict get $projection width])}] point [list [expr {$width/2}] [expr {$height/2}]]]
                    }
                    break
                }
                ::GX::native2DCanvasViewChanged $target
            }
            ::GX::native2DCanvasStatus $handle {1:1 display preview pixels. Full-resolution source pixels may differ from this reduced preview.}
            return {status presented scale original_display_preview_pixels}
        }
        edit_source {
            # Shared Canvas edits the actual selected image; there are no
            # magic Source/Working/Figure sibling objects to hide or retarget.
            set current [_nativeCanvasSiiTarget $handle]
            if {[dict get $current object] ne [dict get $model object]} {error {Selected image changed before opening its editor}}
            _viewerGuiSiiEditorFields $window $handle advanced_editor
            return [dict create status presented mode image object [dict get $model object]]
        }
        sidebar_settings - viewer_settings {
            return [_nativeCanvasSiiPreferencesCommand $window $component $handle $action]
        }
        default {error {Unknown original SII presentation action}}
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiChooserCurrent {context} {
    dict with context {}
    if {![viewerOwns $window $component $handle $token] ||
        [dict get [::GX::viewerGuiDesignValues $window] source_raster] ne $selected} {error {SII chooser's actual Viewer/source lifetime changed}}
    return [canvasCurrent $handle $stamp]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiChooseLocal {context} {
    if {[catch {
        set row [_nativeCanvasSiiChooserCurrent $context]
        dict with context {}
        # Runs after the original compiled event restored its module context.
        # Do not clear or borrow DatasetPrivate::activeContext here.
        set owner [::GX::interactiveDocumentRead [dict get $row document]]
        set operation [::GX::scientificIoChooseImageResource $window [_nativeCanvasSiiGuard $row] [dict get $owner module_id] [list ::GX::SII::CanvasApplication::_nativeCanvasSiiChosen $context]]
        if {[viewerOwns $window $component $handle $token]} {::GX::SII::CanvasApplication::canvasState set $handle sii_chooser $operation}
    } message]} {
        if {[dict exists $context handle] && ![catch {::GX::native2DCanvasContext [dict get $context handle]}]} {::GX::native2DCanvasStatus [dict get $context handle] $message}
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiChosen {context response} {
    if {[catch {
        dict with context {}
        set row [_nativeCanvasSiiChooserCurrent $context]
        catch {canvasState unset $handle sii_chooser}
        if {![dict get $response ok]} {
            # Cancellation/refusal leaves the original selected Dataset,
            # Source/Working geometry and scientific state exactly unchanged.
            ::GX::native2DCanvasStatus $handle [dict get $response error]
            return
        }
        set reference [dict get $response result]
        if {[dict get $reference document_id] ne [dict get $row document] || [dict get $reference owner_generation] ne [dict get $row receipt generation]} {error {Chosen image Resource has another actual Canvas owner}}
        ::GX::interactiveDocumentResourceInfo $reference
        # Original format/header validator, not metadata supplied by chooser.
        ::GX::SII::inspectFile [dict get [::GX::interactiveDocumentResourceLocalFileInfo $reference] path]
        _nativeCanvasSiiChooserCurrent $context
        # Only a VERIFIED accepted user choice clears the old canonical
        # selector. Local objects never inherit that old Dataset/source stamp.
        viewerState set $window sii_local_source $reference
        ::GX::viewerGuiDesignValueSet $window source_raster {}
        _nativeCanvasSiiEditorAction $window $component $handle source_changed
    } message]} {
        if {[dict exists $context handle] && ![catch {::GX::native2DCanvasContext [dict get $context handle]}]} {::GX::native2DCanvasStatus [dict get $context handle] $message}
    }
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureTagPasted {handle held pasted} {
    set next [dict get $pasted snapshot]
    set state [_nativeCanvasSiiFigureState $next]
    set layer [dict get $next active_layer]
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    foreach logical [dict get $pasted new_objects] {
        set item [snapshotLeaf $next $logical]
        set reference [dict get $item resource]
        if {![dict exists $reference metadata sketch_attributes gx.canvas kind] ||
            [dict get $reference metadata sketch_attributes gx.canvas kind] ni {text line arrow rectangle ellipse} ||
            [dict exists $reference metadata image_resource]} {error {Annotation Paste requires the original supported annotation kinds; use the Native Canvas Paste action for other objects}}
        set scene [::GX::native2DGeometryOpen [dict get $row document]]
        try {
            set object [geometryRestore $scene $reference]
            _nativeCanvasSiiFigureMark $scene $object $logical $layer annotation
            dict set item resource [geometryStore $scene $object [dict get $reference metadata]]
        } finally {::GX::native2DGeometryClose $scene}
        set next [_nativeCanvasSiiFigureReplace $next $item]
        dict lappend state annotations $logical
    }
    set next [_nativeCanvasSiiFigurePut $next $state]
    ::GX::native2DCanvasSnapshotValidate $next
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return $next
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiFigureEdit {window handle action} {
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {[dict get $row pending] ne {} || [dict exists $row sii_candidate]} {error {Accept, discard or cancel the pending SII operation before editing its Figure}}
    set held [::GX::native2DCanvasEditCapture $handle]

    set state [_nativeCanvasSiiFigureGet $handle]
    set snapshot [heldSnapshot $handle $held]
    if {$action in {annotation_select_all annotation_select_none}} {
        set selected {}
        if {$action eq {annotation_select_all}} {
            foreach logical [dict get $state annotations] {
                if {[dict create object $logical role annotation] ni [dict get $state diagnostics missing]} {lappend selected $logical}
            }
        }
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
        ::GX::native2DCanvasCommand $handle selection_set [dict create objects $selected]
        return [dict create status selected count [llength $selected]]
    }
    if {$action eq {annotation_copy}} {
        set selected {}
        foreach logical [dict get $snapshot selection] {if {$logical in [dict get $state annotations]} {lappend selected $logical}}
        if {![llength $selected]} {error {Select native Figure annotations to copy; use Native Canvas Copy for mixed objects or groups}}
        _nativeCanvasClipboardCopy $handle [dict create objects $selected]
        ::GX::SII::CanvasApplication::appEditCurrent $handle $held
        return [dict create status copied count [llength $selected]]
    }
    if {$action eq {annotation_paste}} {
        set next [_nativeCanvasSiiFigureTagPasted $handle $held [::GX::native2DCanvasClipboardPasteSnapshot $handle $held {}]]
    } elseif {$action eq {reset_figure}} {
        set next [_nativeCanvasSiiFigureChange $handle $held reset {}]
    } else {
        _viewerGuiSiiEditorFields $window $handle value_changed
        set draft [viewerState get $window sii_editor]
        set values [::GX::viewerGuiDesignValues $window]
        set mode [dict get $draft mode];set entity [dict get $values sii_entity_id]
        switch -- $mode {
            {Figure settings} {
                if {$action ne {upsert_entity}} {error {Figure settings cannot be removed}}
                set next [_nativeCanvasSiiFigureChange $handle $held settings_set [_viewerGuiSiiEditorValue $window]]
                set settings [_nativeCanvasSiiFigureState $next]
                scan [string range [dict get $settings settings background] 1 end] %2x%2x%2x r g b
                dict set next background [list [expr {$r/255.0}] [expr {$g/255.0}] [expr {$b/255.0}] 1]
            }
            Panel {
                set panels [dict get $state panels]
                if {$entity eq {}} {set ordinal [expr {[llength $panels]+1}]} elseif {[string is entier -strict $entity]} {
                    set ordinal $entity
                } else {set ordinal [expr {[lsearch -exact $panels $entity]+1}]}
                if {$ordinal<1 || $ordinal>[llength $panels]+($action eq {upsert_entity})} {error {Choose an existing native panel logical ID/one-based index, or the append position}}
                if {$action eq {remove_entity}} {
                    set next [_nativeCanvasSiiFigureChange $handle $held panel_remove [dict create object [lindex $panels [expr {$ordinal-1}]]]]
                } else {
                    set selected [_nativeCanvasSiiTarget $handle]
                    set payload [dict create object [dict get $selected object]]
                    if {$ordinal<=[llength $panels]} {
                        set next [_nativeCanvasSiiFigureChange $handle $held panel_replace [dict create object [lindex $panels [expr {$ordinal-1}]] replacement [dict get $selected object]]]
                    } else {set next [_nativeCanvasSiiFigureChange $handle $held panel_add $payload]}
                }
            }
            Annotation {
                set annotations [dict get $state annotations]
                if {[string is entier -strict $entity] && $entity>=1 && $entity<=[llength $annotations]} {set entity [lindex $annotations [expr {$entity-1}]]}
                if {$action eq {remove_entity}} {
                    if {$entity ni $annotations} {error {Choose an existing native annotation logical ID or one-based index}}
                    set next [_nativeCanvasSiiFigureChange $handle $held annotation_remove [dict create object $entity]]
                } elseif {$entity eq {}} {
                    set next [_nativeCanvasSiiFigureChange $handle $held annotation_add [dict create annotation [_viewerGuiSiiEditorValue $window]]]
                } else {
                    if {$entity ni $annotations} {error {Choose an existing native annotation logical ID or leave the entity empty to append}}
                    set next [_nativeCanvasSiiFigureChange $handle $held annotation_update [dict create object $entity annotation [_viewerGuiSiiEditorValue $window]]]
                }
            }
            default {error {Choose Figure settings, Panel or Annotation mode for this edit}}
        }
    }
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    ::GX::SII::CanvasApplication::commitSnapshot $handle $held $next "SII native $action"
    ::GX::viewerGuiDesignTextSet $window sii_report [_nativeCanvasSiiFigureGet $handle]
    return [dict create status committed action $action]
}

# Source-defined output-pixel basis, over the same original Native image_map.
# These private coordinate helpers grant no Resource or GUI authority.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureImageMatrix {scene source frame} {
    set image [geometryImageState $scene $source]
    set reference [geometryImageState $scene $frame]
    if {$image eq {} || $reference eq {} || [dict get $image length_unit] ne [dict get $reference length_unit]} {
        error {Normalize image and figure frame to the same explicit working unit before publication}
    }
    set height [dict get $image height];set frameHeight [dict get $reference height]
    set points {}
    foreach pixel [list [list 0 $height] [list 1 $height] [list 0 [expr {$height-1}]]] {
        set world [geometryImageMap $scene $source $pixel 0]
        lassign [geometryImageMap $scene $frame $world 1] x y
        lappend points [list $x [expr {$frameHeight-$y}]]
    }
    lassign [lindex $points 0] x y
    lassign [lindex $points 1] xx xy
    lassign [lindex $points 2] yx yy
    return [list [expr {$xx-$x}] [expr {$xy-$y}] [expr {$yx-$x}] [expr {$yy-$y}] $x $y]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureFrameMatrix {scene frame} {
    set image [geometryImageState $scene $frame]
    if {$image eq {}} {error {Publication requires its actual retained native image frame}}
    set height [dict get $image height];set points {}
    foreach world {{0 0} {1 0} {0 1}} {
        lassign [geometryImageMap $scene $frame $world 1] x y
        lappend points [list $x [expr {$height-$y}]]
    }
    lassign [lindex $points 0] x y
    lassign [lindex $points 1] xx xy
    lassign [lindex $points 2] yx yy
    return [list [expr {$xx-$x}] [expr {$xy-$y}] [expr {$yx-$x}] [expr {$yy-$y}] $x $y]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureDocumentImageMatrix {scene source frame} {
    # The same original image_map three-point basis, composed with the
    # original Native owner's actual Document frame (independent of live view).
    set image [geometryImageState $scene $source]
    if {$image eq {} || [dict get $frame kind] ne {native_document_extent}} {error {Document image projection requires its actual Native image and frame}}
    lassign [dict get $frame world_to_frame] a b c d e f
    set height [dict get $image height];set points {}
    foreach pixel [list [list 0 $height] [list 1 $height] [list 0 [expr {$height-1}]]] {
        lassign [geometryImageMap $scene $source $pixel 0] x y
        lappend points [list [expr {$a*$x+$c*$y+$e}] [expr {$b*$x+$d*$y+$f}]]
    }
    lassign [lindex $points 0] x y
    lassign [lindex $points 1] xx xy
    lassign [lindex $points 2] yx yy
    return [list [expr {$xx-$x}] [expr {$xy-$y}] [expr {$yx-$x}] [expr {$yy-$y}] $x $y]
}

# Private capture for the original prepared-token binder. These data do not
# grant submit/publication authority and cannot be supplied by the public API.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureDigest {text} {
    return [::GX::nativeWorkspaceMetadataDigest $text]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureLineage {item reference} {
    set queue [list [list $item $reference]];set nodes {};set root {};set steps {}
    while {[llength $queue]} {
        lassign [lindex $queue 0] currentItem currentReference;set queue [lrange $queue 1 end]
        set key [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $currentReference]]
        if {$root eq {}} {set root $key}
        if {[dict exists $nodes $key]} continue
        set node [_nativeCanvasSiiCaptureLineageNode $currentItem $currentReference]
        if {$key eq $root} {set steps [dict get $node steps]}
        set children {}
        foreach child [::GX::datasetPublicationV2DictDefault $node children {}] {
            lassign $child childItem childReference
            set childKey [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $childReference]]
            lappend children $childKey;lappend queue $child
        }
        dict set nodes $key [dict create children [lsort -unique $children] sources [dict get $node sources]]
    }
    # Resolve the actual immutable producer DAG iteratively. Every input must
    # resolve independently; a canonical sibling cannot hide a cycle/local leaf.
    set resolved {};set todo $nodes
    while {[dict size $todo]} {
        set progress 0
        dict for {key node} $todo {
            set ready 1;set sources [dict get $node sources]
            foreach child [dict get $node children] {
                if {![dict exists $resolved $child]} {set ready 0;break}
                set sources [concat $sources [dict get $resolved $child]]
            }
            if {!$ready} continue
            set byId {}
            foreach source $sources {
                set id [dict get $source dataset_id]
                if {[dict exists $byId $id] && [dict get $byId $id] ne $source} {error {Conflicting actual producer input lineage}}
                dict set byId $id $source
            }
            if {![dict size $byId]} {return -code error -errorcode {GXTXT SII NO_CANONICAL_ORIGIN} {Every painted image requires its own canonical input lineage; import a local/constructed source through Acquisition first}}
            dict set resolved $key [dict values $byId];dict unset todo $key;set progress 1
        }
        if {!$progress} {error {Scientific image producer input lineage is cyclic or incomplete}}
    }
    return [dict create sources [dict get $resolved $root] steps $steps]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureLineageNode {item reference} {
    ::GX::interactiveDocumentResourceInfo $reference
    set proof [_nativeCanvasSiiResourceJob $reference]
    if {$proof eq {}} {
        if {[dict exists $reference metadata source_job_id]} {return [_nativeCanvasSiiCaptureLineageInputs $reference]}
        if {$item eq {}} {
            if {[::GX::datasetPublicationV2DictDefault [dict get $reference metadata] source_kind {}] ne {canonical_dataset}} {return -code error -errorcode {GXTXT SII NO_CANONICAL_ORIGIN} {Original producer input has no owned canonical binding}}
            set source [dict remove [::GX::quantitativeRasterSourceIdentity [dict get $reference metadata source_dataset_id]] source_stamp]
            if {[dict get $source source_sha256] ne [dict get $reference sha256]} {error {Original producer canonical input bytes changed}}
        } else {set source [_nativeCanvasSiiCanonicalSource $item $reference]}
        return [dict create sources [list $source] steps {}]
    }
    # A metadata job marker alone is not a producing-output identity, including
    # when this Resource is a recursive Native filter/flatten input.
    if {[llength [_nativeCanvasSiiImageDimensions $reference]]!=2} {error {Image lineage lacks its actual completed output/input identity}}
    set request [dict get $proof job scientific_request]
    set recipe [dict get $request image_recipe]
    switch -- [dict get $recipe kind] {
        image {set sources [list [dict get $recipe source]];set steps [dict get $recipe steps]}
        figure {
            set sources {};set steps {}
            if {[dict exists $request image_source_profile]} {
                set sources [_nativeCanvasSiiCaptureNativeFigureSources $proof]
            } else {foreach panel [dict get $recipe panels] {lappend sources [dict get $panel source]}}
        }
        default {error {Current image producer has no verified original source-lineage projection}}
    }
    set clean {};set seen {};set children {}
    foreach source $sources {
        # Never borrow another painted image's origin, or relabel current
        # Working bytes as the old canonical payload. Local transient sources
        # still use the original Acquisition-before-publication prerequisite.
        set id [dict get $source dataset_id]
        if {[string match resource:* $id]} {
            set input {}
            dict for {alias reference} [dict get $request image_resource_sources] {
                if {[_nativeCanvasSiiResourceSource $reference] ne $source} continue
                if {$input ne {} && $input ne $reference} {error {Ambiguous actual processing Resource input}}
                set input $reference
            }
            if {$input eq {}} {error {Processing source differs from its actual sealed Resource inputs}}
            lappend children [list {} $input]
            continue
        }
        ::GX::SII::_processingSource $source
        set current [dict remove [::GX::quantitativeRasterSourceIdentity $id] source_stamp]
        if {$current ne $source} {error {Painted image canonical lineage changed}}
        if {[dict exists $seen $id]} {
            if {[dict get $seen $id] ne $source} {error {Conflicting painted image lineage}}
            continue
        }
        dict set seen $id $source;lappend clean $source
    }
    if {![llength $clean] && ![llength $children]} {return -code error -errorcode {GXTXT SII NO_CANONICAL_ORIGIN} {Every painted image requires its own verified canonical source lineage}}
    return [dict create sources $clean children $children steps $steps]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureNativeFigureSources {proof} {
    set job [dict get $proof job];set request [dict get $job scientific_request]
    if {[dict get $request image_source_profile] ne {native_canvas_document_v1}} {error {Unknown original image source profile}}
    set projection [dict get $request image_native_projection]
    set digest [_nativeCanvasSiiCaptureDigest [binary encode base64 -maxlen 0 [encoding convertto utf-8 $projection]]]
    if {$digest ne [dict get $request image_native_projection_sha256] || [dict get $projection schema] ne {gxtxt.sii.native_canvas_projection.v1}} {error {Original native figure projection digest changed}}
    set reference [dict get $proof reference]
    set observed [_nativeCanvasSiiResourceObserve $reference]
    if {[llength [dict get $observed outputs]]!=1} {error {Ambiguous native figure output}}
    set output [lindex [dict get $observed outputs] 0]
    foreach field {sha256 size_bytes} {if {[dict get $output $field] ne [dict get $reference $field]} {error {Native figure output differs from its actual Resource}}}
    if {[dict get $output role] ne {raster} || [dict get $output source_generation] ne [dict get $reference metadata source_generation]} {error {Native figure output role/generation changed}}
    set actual [dict get $observed summary native_canvas]
    if {[dict get $actual projection_schema] ne [dict get $projection schema]} {error {Native figure output projection schema changed}}
    foreach field {document_id generation revision sha256} {
        if {[dict get $actual document_guard $field] ne [dict get $projection document_guard $field]} {error {Native figure output Document guard changed}}
    }
    foreach field {id generation revision sha256} projected {document_id generation revision sha256} {
        if {[dict get $request source_identities workspace $field] ne [dict get $projection document_guard $projected]} {error {Native figure projection is outside its actual producing Workspace capture}}
    }
    foreach field {projection_sha256 canvas_id sequence source_snapshot_sha256} expected [list $digest [dict get $projection canvas_id] [dict get $projection sequence] [dict get $projection snapshot_sha256]] {
        if {[dict get $actual $field] ne $expected} {error {Native figure result summary differs from its actual captured projection}}
    }
    set canonical [dict get $request image_native_canonical_sources]
    if {[lsort [dict keys [dict get $actual canonical_sources]]] ne [lsort [dict keys $canonical]] ||
        [lsort [dict keys [dict get $actual actual_resource_refs]]] ne [lsort [dict keys [dict get $request image_resource_sources]]]} {error {Native figure input membership changed}}
    dict for {id source} $canonical {
        foreach field {dataset_id source_sha256 source_revision} {if {[dict get $actual canonical_sources $id $field] ne [dict get $source $field]} {error {Native figure canonical association changed}}}
    }
    dict for {alias ref} [dict get $request image_resource_sources] {
        if {[::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} [dict get $actual actual_resource_refs $alias]]] ne
            [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $ref]]} {error {Native figure realized input Resource changed}}
    }
    set sources {};set painted {}
    foreach object [dict get $projection objects] {
        if {[dict get $object disposition] ne {paint_image}} continue
        set logical [dict get $object object];set ids [dict get $object canonical_source_ids]
        if {![llength $ids] || $ids ne [dict get $actual image_lineage $logical]} {error {Native figure painted image lineage changed}}
        lappend painted $logical
        foreach id $ids {lappend sources [dict get $canonical $id]}
    }
    if {[lsort $painted] ne [lsort [dict keys [dict get $actual image_lineage]]] || [dict get $actual object_count]!=[llength [dict get $projection objects]]} {error {Native figure output omitted actual captured objects}}
    return $sources
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureNativeInputProof {reference} {
    return [::GX::native2DCanvasRasterProvenance $reference]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureLineageInputs {reference} {
    set proof [_nativeCanvasSiiCaptureNativeInputProof $reference]
    set manifest [dict get $proof manifest];set bindings [dict get $proof source_bindings]
    set children {}
    switch -- [dict get $proof operation] {
        canvas_filter {
            if {![dict exists $manifest source_resource]} {error {Historical Native filter lacks an exact source Resource association; import its derived image as a canonical Dataset before publication}}
            set input [dict get $manifest source_resource];set alias [dict get $manifest source_alias]
            if {$input ne [dict get $bindings resources $alias]} {error {Native filter source Resource identity changed}}
            if {[dict get $input sha256] ne [dict get $manifest source_sha256]} {error {Native filter input SHA differs from its manifest}}
            lappend children [list {} $input]
        }
        canvas_flatten {
            set snapshot [dict get $manifest snapshot];::GX::native2DCanvasSnapshotValidate $snapshot 0
            foreach item [dict get $snapshot objects] {
                if {![dict exists $item resource metadata image_resource]} continue
                set logical [dict get $item logical_id];set input [dict get $item resource metadata image_resource]
                set alias [dict get $manifest aliases $logical image]
                if {$input ne [dict get $bindings resources $alias]} {error {Native flattened image input identity changed}}
                lappend children [list $item $input]
            }
        }
        default {error {Original Native producing operation needs its exact input-graph projection before canonical publication}}
    }
    return [dict create sources {} children $children steps {}]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureFrame {handle held} {
    set snapshot [heldSnapshot $handle $held];set candidates {};set preferred {}
    foreach item [dict get $snapshot objects] {
        if {![dict exists $item resource metadata sketch_attributes gx.sii.figure]} continue
        set marker [dict get $item resource metadata sketch_attributes gx.sii.figure]
        if {![dict exists $marker schema] || [dict get $marker schema] ne {gxtxt.sii.native_figure_member.v1} ||
            ![dict exists $marker role] || [dict get $marker role] ne {frame}} continue
        if {![dict exists $item resource metadata image_resource]} {error {Native figure frame is not an image}}
        dict set candidates [dict get $item logical_id] $item
    }
    if {![dict size $candidates]} {
        set actual [_nativeCanvasSiiCaptureDocumentFrame $handle $held]
        return [dict create document_frame $actual settings [dict create width [dict get $actual width] height [dict get $actual height]]]
    }
    # The catalog chooses an existing coordinate frame; it never chooses which
    # layers or leaves are painted. Legal moves keep its creation association.
    foreach layer [dict get $snapshot layers] {
        if {[dict get $layer logical_id] ne [dict get $snapshot active_layer] ||
            ![dict exists $layer attributes gx.sii.figure frame_object]} continue
        set logical [dict get $layer attributes gx.sii.figure frame_object]
        if {[dict exists $candidates $logical]} {set preferred $logical}
    }
    if {$preferred eq {}} {
        foreach logical [dict get $snapshot selection] {
            if {![dict exists $candidates $logical]} continue
            if {$preferred ne {}} {error {Select one unambiguous native Figure coordinate frame}}
            set preferred $logical
        }
    }
    if {$preferred eq {}} {
        if {[dict size $candidates]!=1} {error {Create or select an unambiguous native Figure coordinate frame before publication}}
        set preferred [lindex [dict keys $candidates] 0]
    }
    set item [dict get $candidates $preferred];set reference [dict get $item resource metadata image_resource]
    set proof [_nativeCanvasSiiResourceJob $reference]
    if {$proof eq {} || [dict get $proof job scientific_request image_recipe kind] ne {figure}} {error {Native Figure frame lacks its original completed figure Job}}
    lassign [_nativeCanvasSiiImageDimensions $reference] width height
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    set settings [dict get $proof job scientific_request image_recipe settings]
    foreach layer [dict get $snapshot layers] {
        if {![dict exists $layer attributes gx.sii.figure frame_object] || [dict get $layer attributes gx.sii.figure frame_object] ne $preferred} continue
        set settings [dict get $layer attributes gx.sii.figure settings]
    }
    if {$width ne [dict get $settings width] || $height ne [dict get $settings height]} {error {Figure settings require a current matching coordinate frame}}
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    set facts [::GX::native2DCanvasImageInfo $handle $preferred];set image [dict get $facts image state]
    if {[dict get $image width]!=$width || [dict get $image height]!=$height} {error {Native Figure frame dimensions differ from its verified raster}}
    return [dict create item $item reference $reference geometry [dict get $facts geometry] object_token [dict get $facts object_token] width $width height $height settings $settings]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureLiveProjection {handle held framePolicy} {
    if {$framePolicy ni {auto document}} {error {Unknown private scientific Canvas frame policy}}
    _nativeCanvasSiiModule
    ::GX::native2DCanvasEditCurrent $handle $held
    set row [::GX::SII::CanvasApplication::appRecord $handle]
    if {[dict get $row pending] ne {} || [dict get [::GX::native2DCanvasViewInfo $handle] gesture]} {error {Finish or cancel the current Canvas operation before publication}}

    set snapshot [heldSnapshot $handle $held]
    if {$framePolicy eq {document}} {
        set actual [_nativeCanvasSiiCaptureDocumentFrame $handle $held]
        set frame [dict create document_frame $actual settings [dict create width [dict get $actual width] height [dict get $actual height]]]
    } else {
        set frame [_nativeCanvasSiiCaptureFrame $handle $held]
    }
    set row [::GX::SII::CanvasApplication::appEditCurrent $handle $held]
    set paint [::GX::native2DCanvasPaintOrder $handle]
    set frameId {};set frameLogical {}
    if {[dict exists $frame document_frame]} {
        set frameRecord [dict get $frame document_frame]
    } else {
        set frameId [dict get $frame object_token];set frameItem [dict get $frame item]
        set frameLogical [dict get $frameItem logical_id]
        set frameRecord [dict create object $frameLogical layer [dict get $frameItem layer_logical_id] geometry [dict get $frameItem resource] image_resource [dict get $frame reference] width [dict get $frame width] height [dict get $frame height] matrix_convention native_source_topdown_to_frame_topdown_v1]
        dict set frameRecord world_to_frame [_nativeCanvasSiiCaptureFrameMatrix [dict get $frame geometry] $frameId]
    }
    set layers {};set layerIndex {};set order 0
    # Exact original layer order/native-ID tie remains inside CORE.
    foreach logical [dict get $paint layers] {
        foreach layer [dict get $snapshot layers] {
            if {[dict get $layer logical_id] ne $logical} continue
            set output [dict create logical_id $logical paint_order $order properties [dict get $layer properties] blend [dict get $layer blend]]
            lappend layers $output;dict set layerIndex $logical $output
        }
        incr order
    }
    set groups {};set groupIndex {};set members {}
    foreach group [dict get $snapshot groups] {
        set logical [dict get $group logical_id]
        set output [dict create logical_id $logical layer [dict get $group layer_logical_id] members [dict get $group members] style [dict get $group style]]
        lappend groups $output;dict set groupIndex $logical $output
        foreach member [dict get $group members] {dict set members $member $logical}
    }
    set objects {};set resources {};set aliases {};set canonical {};set resourceSerial 0
    foreach descriptor [dict get $paint objects] {
        set logical [dict get $descriptor logical_id]
        set item [snapshotLeaf $snapshot $logical];set style [dict get $item style];set layer [dict get $item layer_logical_id]
        set group [::GX::datasetPublicationV2DictDefault $members $logical {}]
        set record [dict create object $logical layer $layer group $group paint_order [dict get $descriptor paint_order] geometry [dict get $item resource] style $style native_kind [dict get $descriptor kind] disposition invisible reason {Original native visibility}]
        set visible [expr {[dict get $style visible] && [lindex [dict get $style color] 3]>0 && [dict get $layerIndex $layer properties visible] && [dict get $layerIndex $layer properties opacity]>0}]
        if {$group ne {}} {set visible [expr {$visible && [dict get $groupIndex $group style visible] && [lindex [dict get $groupIndex $group style color] 3]>0}]}
        if {$logical eq $frameLogical && !$visible} {
            dict set record disposition coordinate_frame;dict set record reason {Original coordinate reference is effectively hidden by its native object/layer/group visibility}
        } elseif {$visible} {
            set image {};set imageFacts {}
            if {[dict exists $item resource metadata image_resource]} {set imageFacts [::GX::native2DCanvasImageInfo $handle $logical];set image [dict get $imageFacts image state]}
            if {$image ne {}} {
                if {![dict exists $item resource metadata image_resource]} {error "Canvas image $logical has no original Resource binding"}
                set reference [dict get $item resource metadata image_resource]
                ::GX::interactiveDocumentResourceInfo $reference
                if {[dict get $reference document_id] ne [dict get $snapshot document_id] || [dict get $reference owner_generation] ne [dict get $snapshot generation]} {error {Painted image belongs to another Document generation}}
                set dimensions [_nativeCanvasSiiImageDimensions $reference]
                ::GX::SII::CanvasApplication::appEditCurrent $handle $held
                if {$dimensions eq {}} {
                    set dimensions [::GX::native2DResourceImageDimensions $reference]
                    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
                }
                if {[dict get $image width]!=[lindex $dimensions 0] || [dict get $image height]!=[lindex $dimensions 1]} {error {Painted native image dimensions differ from its producing raster}}
                set lineage [_nativeCanvasSiiCaptureLineage $item $reference]
                ::GX::SII::CanvasApplication::appEditCurrent $handle $held
                set ids {}
                foreach source [dict get $lineage sources] {
                    set sourceId [dict get $source dataset_id];lappend ids $sourceId
                    if {[dict exists $canonical $sourceId] && [dict get $canonical $sourceId] ne $source} {error {Conflicting original Dataset lineage across Canvas images}}
                    dict set canonical $sourceId $source
                }
                set key [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $reference]]
                if {![dict exists $aliases $key]} {set alias image[incr resourceSerial];dict set aliases $key $alias;dict set resources $alias $reference}
                set alias [dict get $aliases $key]
                dict set record disposition paint_image;dict set record reason {}
                dict set record image_resource $reference
                dict set record width [expr {wide([dict get $image width])}];dict set record height [expr {wide([dict get $image height])}]
                if {$frameId eq {}} {
                    dict set record matrix [_nativeCanvasSiiCaptureDocumentImageMatrix [dict get $imageFacts geometry] [dict get $imageFacts object_token] $frameRecord]
                } else {
                    if {[dict get $imageFacts geometry] ne [dict get $frame geometry]} {error {Painted image belongs to another original Geometry owner}}
                    dict set record matrix [_nativeCanvasSiiCaptureImageMatrix [dict get $imageFacts geometry] [dict get $imageFacts object_token] $frameId]
                }
                dict set record image_state $image
                dict set record pixel_stage current_resource_already_realized
                dict set record input_alias $alias;dict set record canonical_source_ids $ids
                if {[llength $ids]==1} {dict set record canonical_origin [dict get $canonical [lindex $ids 0]]}
                dict set record accepted_recipe [dict get $lineage steps]
            } elseif {[llength [info commands ::GX::SII::CanvasApplication::_nativeCanvasSiiCaptureAnnotation]]} {
                set annotation [_nativeCanvasSiiCaptureAnnotation $handle $held $logical $frameLogical]
                ::GX::SII::CanvasApplication::appEditCurrent $handle $held
                if {[dict exists $annotation text_glyph]} {
                    set glyph [dict get $annotation text_glyph]
                    fields $glyph {resource width height matrix coverage_stage} {resource width height matrix coverage_stage}
                    if {[dict get $glyph coverage_stage] ne {original_native_tk_glyph_alpha8_v1}} {error {Unknown original Native glyph coverage stage}}
                    set reference [dict get $glyph resource];::GX::interactiveDocumentResourceInfo $reference
                    if {[dict get $reference document_id] ne [dict get $snapshot document_id] || [dict get $reference owner_generation] ne [dict get $snapshot generation] ||
                        [dict get $reference metadata role] ne {native_tk_glyph_alpha} || [dict get $reference metadata encoding] ne {png-alpha8} ||
                        [dict get $reference metadata scientific_authority] || [dict get $reference metadata width]!=[dict get $glyph width] || [dict get $reference metadata height]!=[dict get $glyph height]} {error {Original glyph coverage Resource association changed}}
                    set key [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {resource {named resource_metadata}} $reference]]
                    if {![dict exists $aliases $key]} {set alias image[incr resourceSerial];dict set aliases $key $alias;dict set resources $alias $reference}
                    dict set annotation text_glyph input_alias [dict get $aliases $key]
                }
                set record [dict merge $record $annotation]
                dict set record disposition paint_annotation;dict set record reason {}
            } else {
                dict set record disposition unimplemented
                dict set record reason {Original Native annotation projection owner is not installed; whole publication must refuse}
            }
        }
        lappend objects $record
    }
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    set projection [dict create schema gxtxt.sii.native_canvas_projection.v1 document_guard [_nativeCanvasSiiGuard $row] canvas_id [dict get $snapshot canvas_id] sequence [dict get [::GX::native2DCanvasContext $handle] sequence] snapshot_sha256 [_nativeCanvasSiiCaptureDigest [::GX::SII::_processingCanonicalNode [::GX::nativeWorkspaceEncode {named canvas_snapshot} $snapshot]]] settings [dict get $frame settings] frame $frameRecord background [dict get $snapshot background] layers $layers groups $groups objects $objects]
    ::GX::SII::CanvasApplication::appEditCurrent $handle $held
    return [dict create projection $projection resources $resources canonical_sources $canonical]
}

# Required installed original-owner helpers; component-only manual sourcing is insufficient.
source [file join [file dirname [info script]] native2d_canvas_sii_figure_v1.tcl]
source [file join [file dirname [info script]] native2d_canvas_sii_projection_v1.tcl]
