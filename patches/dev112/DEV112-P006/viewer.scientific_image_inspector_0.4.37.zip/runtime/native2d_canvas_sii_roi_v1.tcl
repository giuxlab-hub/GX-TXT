# SII application implementation; registered by its approved public module API.
# SPDX-License-Identifier: GPL-3.0-or-later
# Raw operation admission: native2d_canvas_api_v1.script_bridge_policy.json.
# Private native-context helpers below add no raw operation or public API.
# Private Working/local source admission for the ORIGINAL Canvas ROI owner.
# No public SII9/canonical source_info extension, geometry or image store.
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiRoiImageContext {handle logical {selected 1}} {
    set info [::GX::native2DCanvasImageInfo $handle $logical]
    set owner [dict get $info context]
    # Original CORE checks actual selection before/after each hook. Public
    # ImageInfo is provisional held-reader metadata, not a full-hash Snapshot.
    set geometry [dict get $info geometry];set token [dict get $info object_token]
    set attributes [dict get $info attributes]
    if {[dict get $info canonical_binding] ne {}} {return {}}
    if {![dict exists $attributes gx.image.sii]} {return {}}
    set model [dict get $attributes gx.image.sii]
    if {![dict exists $model schema] || [dict get $model schema] ne {gxtxt.sii.canvas_model.v1}} {error {ROI requires the original SII image model}}
    set role [dict get $model role]
    if {$role eq {source} && [dict get $info canonical_binding] ne {}} {
        # NEVER rescue any canonical RawSource failure via a Resource branch.
        return {}
    }
    if {$role ni {source working}} {error {Only original Source or accepted Working images admit SII ROI}}
    set image [dict get $info image]
    set reference [dict get $image resource]
    if {[dict get $reference document_id] ne [dict get $owner document_id] ||
        ![dict exists $reference owner_generation] || [dict get $reference owner_generation] ne [dict get $owner document_receipt generation]} {error {SII ROI Resource belongs to a different Document lifetime}}
    foreach field {source_job_id source_output_token source_generation} {
        if {![dict exists $reference metadata $field]} {error {SII provisional ROI lacks its complete producing receipt}}
    }
    # This is a private noncanonical Resource context. The empty Dataset ID is
    # intentional: no old Dataset identity is borrowed for Working/local bytes.
    # ONLY provisional pointer/drawing geometry is admitted here. The original
    # held Resource reader checks physical identity without full hashing or a
    # Supervisor process per mouse frame. This context has NO source_info and
    # cannot authorize a retained edit, public source identity or processing.
    # Full Job/recipe/manifest/raster verification is exclusively below.
    set stamp [list [dict get $owner session] [dict get $owner document_id] [dict get $owner document_receipt] \
        [dict get $owner canvas_generation] $geometry $token \
        $reference $model]
    set source [dict create dataset_id {} source_kind sii_completed_resource source_stamp $stamp]
    ::GX::native2DCanvasContextCurrent $handle $owner
    return [dict create source_kind sii_completed_resource source $source \
        extension_data [dict create sii_model $model]]
}
proc ::GX::SII::CanvasApplication::_nativeCanvasSiiRoiContext {handle logical selected context} {
    set reference [dict get $context image resource]
    foreach command {_nativeCanvasSiiResourceJob _nativeCanvasSiiImageDimensions} {
        if {![llength [info commands ::GX::SII::CanvasApplication::$command]]} {error {Original SII completed-image owner is unavailable}}
    }
    set proof [_nativeCanvasSiiResourceJob $reference]
    if {$proof eq {}} {error {SII ROI requires its actual owned COMPLETED image Job}}
    set model [dict get $context extension_data sii_model]
    set job [dict get $proof job]
    set recipe [dict get $job scientific_request image_recipe]
    if {[dict get $recipe kind] ne {image} || [dict get $recipe operation] ne {process} ||
        [dict get $recipe source] ne [dict get $model source]} {error {SII ROI model differs from its original image recipe}}
    set output [dict get $reference metadata source_output_token]
    if {[dict get $model role] eq {working}} {
        if {[string match input-* $output] || [dict get $recipe steps] ne [dict get $model image steps]} {error {SII Working ROI requires its matching completed raster recipe}}
    } else {
        if {![string match input-* $output] || [llength [dict get $recipe steps]]} {error {Local Source ROI requires its original unmodified sealed input}}
    }
    # ResourceJob alone is NOT raster authority: this original reader checks
    # full output/input token/generation/SHA/size and excludes display_preview.
    set dimensions [_nativeCanvasSiiImageDimensions $reference]
    set output [dict get $reference metadata source_output_token]
    set current [_nativeCanvasSiiRoiImageContext $handle $logical $selected]
    if {![dict exists $current source_kind] || [dict get $current source_kind] ne {sii_completed_resource} ||
        [dict get $current source source_stamp] ne [dict get $context source source_stamp] ||
        [dict get $current extension_data sii_model] ne $model} {error {SII ROI source or image changed during full admission}}
    if {[llength $dimensions]!=2 || [lindex $dimensions 0] != [dict get $context image state width] ||
        [lindex $dimensions 1] != [dict get $context image state height]} {error {SII ROI native dimensions differ from its complete original raster}}
    # CORE compares actual image/Resource/collection/attrs/selection again and
    # retains its own internal geometry/row. APP cannot replace those fields.
    set revision [list [dict get $reference owner_generation] [dict get $reference metadata source_generation] $output]
    return [dict create source_info [dict create dataset_id {} source_sha256 [dict get $reference sha256] source_revision $revision] \
        extension_data [dict create sii_model $model]]
}
