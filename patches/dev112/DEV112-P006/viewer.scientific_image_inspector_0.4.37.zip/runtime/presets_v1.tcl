# Exact original SII basic preset data; shared by GUI and managed clients.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX::SII {}
proc ::GX::SII::basicPresetCatalog {} {
    return [list \
        [list {Photo | Balance tonal range} {Automatically span the available tones; use for flat photographs.} {{auto_level {}}}] \
        [list {Photo | Gentle contrast} {Add moderate midtone contrast without automatic histogram stretching.} {{sigmoidal {contrast 4 midpoint 50}}}] \
        [list {Photo | Sharpen details} {Enhance fine boundaries; may amplify noise and compression artifacts.} {{unsharp {radius 0 sigma 1 gain 0.8 threshold 0.04}}}] \
        [list {Photo | Soften grain} {Slight Gaussian smoothing; fine texture is intentionally reduced.} {{gaussian_blur {radius 0 sigma 0.8}}}] \
        [list {Color | More saturated} {Increase saturation by 20 percent; not appropriate for quantitative color measurements.} {{modulate {brightness 100 saturation 120 hue 100}}}] \
        [list {Color | Less saturated} {Reduce saturation by 25 percent without converting to grayscale.} {{modulate {brightness 100 saturation 75 hue 100}}}] \
        [list {Color | Convert to grayscale} {Convert to grayscale. This is a display conversion, not a measured intensity calibration.} {{colorspace {space Gray}}}] \
        [list {Scan | Remove small specks} {Use ImageMagick despeckling on scanning artifacts; tiny legitimate marks may disappear.} {{despeckle {}}}] \
        [list {Scan | Dark text on white} {Create a high-contrast black-and-white scan. Continuous tone information will be lost.} {{colorspace {space Gray}} {threshold {threshold 60}}}] \
        [list {Scan | Clarify faint writing} {Extend the tonal range and apply a moderate unsharp filter.} {{auto_level {}} {unsharp {radius 0 sigma 0.8 gain 0.5 threshold 0.05}}}] \
        [list {Microscopy | Gentle sharpening} {Light edge enhancement for visual preparation, never calibrated feature measurement.} {{unsharp {radius 0 sigma 0.7 gain 0.35 threshold 0.06}}}] \
        [list {Microscopy | Show edges} {Edge-detection visualization; output is not an unaltered micrograph.} {{edge {radius 1}}}] \
        [list {Diagram | Increase contrast} {Strengthen midtone separation for line art and diagrams.} {{sigmoidal {contrast 7 midpoint 50}}}] \
        [list {Diagram | Invert colors} {Swap light and dark foreground/background using the negative operation.} {{negate {}}}] \
        [list {Diagram | Sharpen strokes} {Accent printed lines and symbols; may cause edge halos.} {{unsharp {radius 0 sigma 0.85 gain 1 threshold 0.05}}}] \
    ]
}
