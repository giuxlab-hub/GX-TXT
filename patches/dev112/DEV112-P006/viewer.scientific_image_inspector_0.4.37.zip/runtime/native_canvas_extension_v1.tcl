# SPDX-License-Identifier: GPL-3.0-or-later
# SII application hooks registered in the existing public CORE Canvas owner.
proc ::GX::SII::CanvasApplication::inputLockReason {handle kind data} {
    if {[_nativeCanvasSiiInputLocked $handle $kind $data]} {return {Finish or cancel the pending Inspector operation before editing}}
    return {}
}
proc ::GX::SII::CanvasApplication::pendingView {handle kind data} {
    set row [appRecord $handle]
    return [expr {[dict get $row pending] ne {} && ([dict exists $row sii_job] || [dict exists $row sii_candidate]) &&
        [dict get [::GX::native2DCanvasViewInfo $handle] tool] eq {pan}}]
}
proc ::GX::SII::CanvasApplication::cancelPending {handle} {
    _nativeCanvasSiiLodCancel $handle
    _nativeCanvasSiiCompareClose $handle
    return [_nativeCanvasSiiAdmissionRetire $handle]
}
proc ::GX::SII::CanvasApplication::ownerAdmit {handle owner} {
    _viewerGuiSiiRoles [dict get $owner window] [dict get $owner component]
    set row [appRecord $handle]
    if {[dict get $row pending] ne {} || [dict exists $row sii_candidate]} {error {Finish or cancel the pending Inspector operation before scientific Canvas capture}}
    return 1
}
proc ::GX::SII::CanvasApplication::quiescentMetadata {values} {
    if {[catch {dict size $values}] || ![dict exists $values pending] || ![dict exists $values raster_status]} {return 0}
    if {[dict get $values pending] ne {}} {return 0}
    set keys [lsort [dict keys $values]]
    if {$keys eq {pending raster_status}} {
        return [expr {[dict get $values raster_status] eq {status idle}}]
    }
    foreach key $keys {if {$key ni {pending raster_status sii_readiness sii_display_cache}} {return 0}}
    if {![dict exists $values sii_readiness]} {return 0}
    set ready [dict get $values sii_readiness];set status [dict get $values raster_status]
    if {[catch {dict size $ready}] || [catch {dict size $status}] || ![dict exists $ready context prior_pending]} {return 0}
    if {[lsort [dict keys $ready]] ne {admissions context has_more owner_scope recovery_id state} ||
        [lsort [dict keys $status]] ne {admissions has_more ready recovery_id retry_allowed status}} {return 0}
    if {[dict get $ready state] ne {READY} || [dict get $ready has_more] ne {0} ||
        [dict get $status status] ne {owner_ready} || [dict get $status ready] ne {1} ||
        [dict get $status has_more] ne {0} || [dict get $status retry_allowed] ne {0} ||
        [dict get $ready recovery_id] ne [dict get $status recovery_id] ||
        [dict get $ready admissions] ne [dict get $status admissions] ||
        [dict get $ready context prior_pending] ne {}} {return 0}
    set admissions [dict get $ready admissions]
    if {[catch {llength $admissions}]} {return 0}
    foreach item $admissions {
        if {[catch {dict size $item}]} {return 0}
        if {[lsort [dict keys $item]] ne {admission_state handled job_id job_state submission_id}} {return 0}
        if {[dict get $item submission_id] eq {}} {return 0}
        switch -- [dict get $item admission_state] {
            CLOSED {if {[dict get $item job_id] ne {} || [dict get $item job_state] ne {} || [dict get $item handled] ni {0 1}} {return 0}}
            ACCEPTED {
                if {[dict get $item handled] ne {1} || [dict get $item job_id] eq {} ||
                    [dict get $item job_state] ni {COMPLETED FAILED CANCELLED INTERRUPTED}} {return 0}
            }
            default {return 0}
        }
    }
    return 1
}
proc ::GX::SII::CanvasApplication::canvasDispose {handle} {
    # Cancellation is not a drain certificate. Original outstanding contexts
    # remain available to their owned completion/cleanup callbacks.
    _nativeCanvasSiiLodCancel $handle
    _nativeCanvasSiiCompareClose $handle
    # Drop only empty or fully acknowledged ready metadata. This releases no
    # Job/Resource and certifies no global drain. Unknown, pending, import, LOD
    # and other callback custody remain with their original owners.
    variable stateByContext
    foreach key [dict keys $stateByContext] {
        if {[lindex $key 0] ne $handle} continue
        set values [dict get $stateByContext $key]
        if {[quiescentMetadata $values]} {
            stateForget $handle [lindex $key 1]
        }
    }
}
proc ::GX::SII::CanvasApplication::viewerInitialize {window payload} {
    viewerStateRead $window
    _nativeCanvasSiiPreferencesRestore $window [::GX::datasetPublicationV2DictDefault $payload domain_state {}]
    _viewerGuiSiiSourceAttach $window
    # All declared widgets exist here. Saved values are applied later by the
    # original restore hook; a fresh runtime editor can show its defaults now.
    set viewer [viewerRecord $window]
    if {$payload eq {} && [dict get $viewer mode] eq {runtime} &&
        ![catch {::GX::viewerGuiComponentHost $window sii_mode}]} {
        variable extensionId
        dict for {component handle} [::GX::datasetPublicationV2DictDefault $viewer canvas_slots {}] {
            if {![dict exists $viewer design extensions $component] || [dict get $viewer design extensions $component] ne $extensionId} continue
            _viewerGuiSiiRoles $window $component
            _viewerGuiSiiEditorFields $window $handle initialize_editor
            break
        }
    }
}
proc ::GX::SII::CanvasApplication::viewerEvent {window component event} {
    _viewerGuiSiiSourceControlsRefresh $window
    # A committed Canvas edit replaces the current context just as restore or
    # History navigation does. Reattach its original metadata-only readiness
    # owner; never reuse readiness from the previous Document receipt.
    if {$event in {committed document_changed history_navigated}} {_viewerGuiSiiSourceAttach $window}
}
proc ::GX::SII::CanvasApplication::viewerCapture {window domain} {
    set presentation [_nativeCanvasSiiPreferencesCapture $window]
    if {$presentation ne {}} {dict set domain sii_presentation $presentation}
    return $domain
}
proc ::GX::SII::CanvasApplication::viewerRestore {window domain} {
    _nativeCanvasSiiPreferencesRestore $window $domain
    _viewerGuiSiiSourceAttach $window
    set viewer [viewerRecord $window]
    if {[dict get $viewer mode] eq {runtime} && ![catch {::GX::viewerGuiComponentHost $window sii_mode}]} {
        variable extensionId
        dict for {component handle} [::GX::datasetPublicationV2DictDefault $viewer canvas_slots {}] {
            if {![dict exists $viewer design extensions $component] || [dict get $viewer design extensions $component] ne $extensionId} continue
            _viewerGuiSiiRoles $window $component
            _viewerGuiSiiEditorFields $window $handle restore_editor
            break
        }
    }
}
proc ::GX::SII::CanvasApplication::viewerDispose {window} {
    variable viewerStateByLifetime
    # Destroy runs after the active Viewer guard has ended. A live or reused
    # pathname is not this retired lifetime and must never be cleared here.
    if {[winfo exists $window]} return
    foreach key [dict keys $viewerStateByLifetime] {
        if {[lindex $key 0] eq $window} {dict unset viewerStateByLifetime $key}
    }
}
proc ::GX::SII::CanvasApplication::registerExtension {} {
    variable extensionId
    set prefix ::GX::SII::CanvasApplication
    set native [dict create navigation ${prefix}::_nativeCanvasSiiNavigation \
        input_cancel ${prefix}::_nativeCanvasSiiInputCancel input_locked ${prefix}::inputLockReason \
        input_accepted ${prefix}::_nativeCanvasSiiInputAccepted pending_view ${prefix}::pendingView \
        before_present ${prefix}::_nativeCanvasSiiResumeSourceAdoption after_present ${prefix}::_nativeCanvasSiiPresentationRefresh \
        view_changed ${prefix}::_nativeCanvasSiiLodSchedule cancel_pending ${prefix}::cancelPending \
        image_projection_context ${prefix}::imageProjection image_dimensions ${prefix}::_nativeCanvasSiiImageDimensions \
        roi_image_context ${prefix}::_nativeCanvasSiiRoiImageContext roi_context ${prefix}::_nativeCanvasSiiRoiContext \
        capture_projection ${prefix}::captureProjection owner_admit ${prefix}::ownerAdmit dispose ${prefix}::canvasDispose]
    set viewer [dict create initialize ${prefix}::viewerInitialize event ${prefix}::viewerEvent \
        action_enabled ${prefix}::_viewerGuiSiiSourceActionEnabled capture_visibility ${prefix}::_nativeCanvasSiiPreferencesCaptureVisibility \
        capture ${prefix}::viewerCapture restore_check ${prefix}::_nativeCanvasSiiPreferencesRestoreCheck \
        restore ${prefix}::viewerRestore dispose ${prefix}::viewerDispose]
    set files {runtime/native2d_canvas_sii_v1.tcl runtime/native2d_canvas_sii_preferences_v1.tcl runtime/native2d_canvas_sii_figure_v1.tcl \
        runtime/native2d_canvas_sii_projection_v1.tcl runtime/native2d_canvas_sii_roi_v1.tcl runtime/native_canvas_extension_v1.tcl}
    return [::GX::native2DCanvasExtensionRegister $extensionId [dict create schema gxtxt.native2d.extension.v1 \
        module_id viewer.scientific_image_inspector api_id SCIENTIFIC_IMAGE_INSPECTOR_API_v1 api_version 1 \
        commands [commandContracts] native_hooks $native viewer_hooks $viewer runtime_files $files \
        scientific_provider viewer.scientific_image_inspector.processing projection_schema gxtxt.sii.native_canvas_projection.v1]]
}
