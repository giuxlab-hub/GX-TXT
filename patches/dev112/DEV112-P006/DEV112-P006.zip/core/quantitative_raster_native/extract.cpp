// SPDX-License-Identifier: GPL-3.0-or-later
// Trusted original-source decoding/extraction only. NUMERIC_API_v1 owns all math.
#include <json-c/json.h>
#include <openssl/evp.h>
#include <openssl/crypto.h>
#include <png.h>
#include <tiffio.h>
#include <zlib.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <climits>
#include <cmath>
#include <csetjmp>
#include <csignal>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <functional>
#include <limits>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace {
constexpr std::uint64_t MAX_ENCODED=64ULL*1024*1024, MAX_DECODED=128ULL*1024*1024;
constexpr std::uint64_t MAX_PIXELS=16777216, MAX_ROW=1048576;
constexpr std::uint32_t MAX_DIMENSION=16384;
constexpr std::size_t MAX_METADATA=32768;
volatile std::sig_atomic_t cancelled=0;
const auto started=std::chrono::steady_clock::now();
void on_signal(int) { cancelled=1; }
double seconds() { return std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count(); }
struct Failure:std::runtime_error {
    std::string code;
    Failure(const char* c,const char* message):std::runtime_error(message),code(c) {}
};
void require(bool condition,const char* code,const char* message) { if(!condition)throw Failure(code,message); }
void deadline() {
    require(!cancelled,"CANCELLED","Extraction was cancelled");
    require(seconds()<120.0,"TIMEOUT","Cooperative extraction elapsed limit reached");
}
struct Descriptor {
    int value=-1;
    explicit Descriptor(int fd=-1):value(fd) {}
    ~Descriptor() { if(value>=0)::close(value); }
    Descriptor(const Descriptor&)=delete;Descriptor& operator=(const Descriptor&)=delete;
};
bool same_file(const struct stat& a,const struct stat& b) {
    return a.st_dev==b.st_dev && a.st_ino==b.st_ino && a.st_size==b.st_size &&
        a.st_mode==b.st_mode && a.st_nlink==b.st_nlink && a.st_uid==b.st_uid && a.st_gid==b.st_gid &&
        a.st_mtim.tv_sec==b.st_mtim.tv_sec && a.st_mtim.tv_nsec==b.st_mtim.tv_nsec &&
        a.st_ctim.tv_sec==b.st_ctim.tv_sec && a.st_ctim.tv_nsec==b.st_ctim.tv_nsec;
}
class Source {
public:
    Descriptor fd;std::string path;struct stat original{};
    explicit Source(const std::string& name):fd(::open(name.c_str(),O_RDONLY|O_NOFOLLOW|O_CLOEXEC|O_NONBLOCK)),path(name) {
        require(fd.value>=0,"SOURCE","Original source cannot be opened without following links");
        require(::fstat(fd.value,&original)==0 && S_ISREG(original.st_mode) && original.st_nlink==1 &&
                original.st_size>0 && std::uint64_t(original.st_size)<=MAX_ENCODED,
                "SOURCE","Original source must be a single-link regular file within64MiB");
        stable();
    }
    void stable() const {
        struct stat current{},named{};
        require(::fstat(fd.value,&current)==0 && ::lstat(path.c_str(),&named)==0 &&
                same_file(original,current) && same_file(original,named),"SOURCE_SHA","Original source identity changed");
    }
    void read(std::uint64_t offset,void* output,std::size_t count) const {
        require(offset<=std::uint64_t(original.st_size) && count<=std::uint64_t(original.st_size)-offset,
                "FORMAT","Original source read exceeds admitted bytes");
        auto* target=static_cast<unsigned char*>(output);
        while(count) {
            deadline();ssize_t got=::pread(fd.value,target,count,static_cast<off_t>(offset));
            if(got<0 && errno==EINTR)continue;
            require(got>0,"FORMAT","Original source is truncated or unreadable");
            target+=got;offset+=static_cast<std::size_t>(got);count-=static_cast<std::size_t>(got);
        }
    }
    std::string sha() const {
        std::unique_ptr<EVP_MD_CTX,decltype(&EVP_MD_CTX_free)> context(EVP_MD_CTX_new(),EVP_MD_CTX_free);
        require(bool(context) && EVP_DigestInit_ex(context.get(),EVP_sha256(),nullptr)==1,"BACKEND","SHA256 initialization failed");
        std::array<unsigned char,MAX_ROW> block{};
        for(std::uint64_t offset=0;offset<std::uint64_t(original.st_size);) {
            auto count=static_cast<std::size_t>(std::min<std::uint64_t>(block.size(),original.st_size-offset));
            read(offset,block.data(),count);
            require(EVP_DigestUpdate(context.get(),block.data(),count)==1,"BACKEND","SHA256 update failed");offset+=count;
        }
        std::array<unsigned char,EVP_MAX_MD_SIZE> hash{};unsigned length=0;
        require(EVP_DigestFinal_ex(context.get(),hash.data(),&length)==1 && length==32,"BACKEND","SHA256 finalization failed");
        std::string result;result.reserve(64);constexpr char digits[]="0123456789abcdef";
        for(unsigned i=0;i<length;++i) { result+=digits[hash[i]>>4];result+=digits[hash[i]&15]; }
        return result;
    }
};
std::uint32_t be32(const unsigned char* p) { return (std::uint32_t(p[0])<<24)|(std::uint32_t(p[1])<<16)|(std::uint32_t(p[2])<<8)|p[3]; }
bool little_host() { std::uint16_t one=1;return *reinterpret_cast<unsigned char*>(&one)==1; }
struct Layout {
    std::uint32_t width=0,height=0;unsigned depth=0;
    std::string format,dtype,photometric,alpha,decoder,version;
    std::vector<std::string> channels;
    unsigned compression=0;bool source_little=false;
    std::size_t item_size() const { return depth/8; }
    std::size_t row_bytes() const { return std::size_t(width)*channels.size()*item_size(); }
    void admit() const {
        require(width>=1 && height>=1 && width<=MAX_DIMENSION && height<=MAX_DIMENSION &&
                std::uint64_t(width)*height<=MAX_PIXELS,"LIMIT","Original raster dimensions exceed admitted bounds");
        require(!channels.empty() && channels.size()<=4 && row_bytes()<=MAX_ROW &&
                std::uint64_t(row_bytes())*height<=MAX_DECODED,"LIMIT","Decoded raster exceeds native byte bounds");
    }
};
Layout png_header(const Source& source) {
    Layout shape;shape.format="PNG";shape.decoder="libpng_native_scanline";shape.version=png_get_libpng_ver(nullptr);
    std::array<unsigned char,8> signature{};source.read(0,signature.data(),signature.size());
    require(png_sig_cmp(signature.data(),0,8)==0,"FORMAT","PNG signature differs");
    std::array<unsigned char,MAX_ROW> data{};std::uint64_t offset=8;unsigned chunks=0;
    bool found_data=false,closed_data=false,ended=false;
    while(offset<std::uint64_t(source.original.st_size)) {
        deadline();require(++chunks<=65536,"LIMIT","PNG chunk count exceeds its bound");
        std::array<unsigned char,8> header{};source.read(offset,header.data(),header.size());
        std::uint32_t length=be32(header.data());std::string kind(reinterpret_cast<char*>(header.data()+4),4);
        require(length<=MAX_ENCODED && offset+std::uint64_t(length)+12<=std::uint64_t(source.original.st_size),"FORMAT","Invalid PNG chunk bounds");
        require(std::all_of(kind.begin(),kind.end(),[](unsigned char c){return (c>='A'&&c<='Z')||(c>='a'&&c<='z');}),"FORMAT","Invalid PNG chunk name");
        require(kind!="acTL" && kind!="fcTL" && kind!="fdAT" && kind!="tRNS" && kind!="eXIf" && kind!="PLTE" && kind!="iCCP",
                "UNSUPPORTED","PNG animation palette transparency-key EXIF or ICC is not admitted");
        require((header[4]&32) || kind=="IHDR" || kind=="IDAT" || kind=="IEND","UNSUPPORTED","Unknown critical PNG chunk");
        if(chunks==1)require(kind=="IHDR" && length==13,"FORMAT","PNG IHDR must be first");
        else require(kind!="IHDR","FORMAT","Duplicate PNG IHDR");
        uLong crc=crc32(0L,header.data()+4,4);
        for(std::uint64_t done=0;done<length;) {
            auto count=static_cast<std::size_t>(std::min<std::uint64_t>(data.size(),length-done));
            source.read(offset+8+done,data.data(),count);crc=crc32(crc,data.data(),static_cast<uInt>(count));
            if(kind=="IHDR") {
                shape.width=be32(data.data());shape.height=be32(data.data()+4);shape.depth=data[8];unsigned color=data[9];
                require((color==0||color==2||color==6) && (shape.depth==8||shape.depth==16) &&
                        data[10]==0 && data[11]==0 && data[12]==0,"UNSUPPORTED","PNG depth color compression filtering or interlace is not admitted");
                shape.channels=color==0?std::vector<std::string>{"Gray"}:color==2?std::vector<std::string>{"R","G","B"}:std::vector<std::string>{"R","G","B","A"};
                shape.dtype=shape.depth==8?"uint8":"uint16";shape.photometric=color==0?"Gray_stored_codes":"RGB_stored_codes";
                shape.alpha=color==6?"straight_stored":"absent";shape.admit();
            }
            done+=count;
        }
        std::array<unsigned char,4> expected{};source.read(offset+8+length,expected.data(),4);
        require(std::uint32_t(crc)==be32(expected.data()),"FORMAT","PNG chunk CRC differs");
        if(kind=="IDAT") { require(!closed_data,"FORMAT","PNG IDAT chunks must be consecutive");found_data=true; }
        else if(found_data)closed_data=true;
        offset+=std::uint64_t(length)+12;
        if(kind=="IEND") {require(length==0 && found_data && offset==std::uint64_t(source.original.st_size),"FORMAT","Invalid final PNG IEND or image data");ended=true;}
    }
    require(ended && offset==std::uint64_t(source.original.st_size),"FORMAT","PNG final IEND is missing");
    return shape;
}

class PngDecoder {
    struct alignas(std::max_align_t) Allocation { std::size_t bytes; };
    Source& source_;png_structp png_=nullptr;png_infop info_=nullptr;
    std::uint64_t offset_=0;std::size_t allocated_=0;
    static void fail(png_structp p,png_const_charp) { longjmp(png_jmpbuf(p),1); }
    static png_voidp allocate(png_structp p,png_alloc_size_t size) {
        auto* self=static_cast<PngDecoder*>(png_get_mem_ptr(p));
        if(size>32ULL*1024*1024 || size>MAX_DECODED-self->allocated_)return nullptr;
        auto* block=static_cast<Allocation*>(std::malloc(sizeof(Allocation)+size));
        if(!block)return nullptr;
        block->bytes=size;self->allocated_+=size;return block+1;
    }
    static void release(png_structp p,png_voidp value) {
        if(!value)return;
        auto* self=static_cast<PngDecoder*>(png_get_mem_ptr(p));auto* block=static_cast<Allocation*>(value)-1;
        self->allocated_-=block->bytes;std::free(block);
    }
    static void read(png_structp p,png_bytep target,png_size_t count) {
        auto* self=static_cast<PngDecoder*>(png_get_io_ptr(p));
        if(cancelled || seconds()>=120 || self->offset_>std::uint64_t(self->source_.original.st_size) ||
                count>std::uint64_t(self->source_.original.st_size)-self->offset_)png_error(p,"Bounded source read failed");
        while(count) {
            ssize_t got=::pread(self->source_.fd.value,target,count,static_cast<off_t>(self->offset_));
            if(got<0 && errno==EINTR) { if(cancelled)png_error(p,"Read cancelled");continue; }
            if(got<=0)png_error(p,"Source read failed");
            self->offset_+=static_cast<std::size_t>(got);target+=got;count-=static_cast<std::size_t>(got);
        }
    }
public:
    Layout shape;std::vector<unsigned char> row;double native_seconds=0;
    explicit PngDecoder(Source& source):source_(source),shape(png_header(source)) {
        png_=png_create_read_struct_2(PNG_LIBPNG_VER_STRING,this,fail,fail,this,allocate,release);
        require(png_!=nullptr,"BACKEND","Bounded libpng reader allocation failed");
    }
    ~PngDecoder() { if(png_)png_destroy_read_struct(&png_,&info_,nullptr); }
    void initialize() {
        if(setjmp(png_jmpbuf(png_))) {deadline();throw Failure("DECODE","Original PNG header or decode failed");}
        info_=png_create_info_struct(png_);require(info_!=nullptr,"BACKEND","PNG info allocation failed");
        png_set_read_fn(png_,this,read);png_set_crc_action(png_,PNG_CRC_ERROR_QUIT,PNG_CRC_ERROR_QUIT);
        png_set_user_limits(png_,MAX_DIMENSION,MAX_DIMENSION);
        png_set_chunk_malloc_max(png_,32ULL*1024*1024);png_set_chunk_cache_max(png_,128);
        // Text is not part of sample semantics; avoid inflating compressed text.
        const png_byte text_chunks[]={ 't','E','X','t',0,'z','T','X','t',0,'i','T','X','t',0 };
        png_set_keep_unknown_chunks(png_,PNG_HANDLE_CHUNK_NEVER,text_chunks,3);
        png_set_keep_unknown_chunks(png_,PNG_HANDLE_CHUNK_NEVER,nullptr,0);
        png_read_info(png_,info_);png_read_update_info(png_,info_);
        require(png_get_image_width(png_,info_)==shape.width && png_get_image_height(png_,info_)==shape.height &&
                png_get_bit_depth(png_,info_)==shape.depth && png_get_channels(png_,info_)==shape.channels.size() &&
                png_get_rowbytes(png_,info_)==shape.row_bytes(),"DECODE","PNG native sample shape changed");
        row.resize(shape.row_bytes());
    }
    void rows(const std::function<void(std::uint32_t,const unsigned char*)>& receive) {
        if(setjmp(png_jmpbuf(png_))) {deadline();throw Failure("DECODE","Original PNG scanline decode failed");}
        for(std::uint32_t y=0;y<shape.height;++y) {
            deadline();double start=seconds();png_read_row(png_,row.data(),nullptr);native_seconds+=seconds()-start;receive(y,row.data());
        }
        double start=seconds();png_read_end(png_,info_);native_seconds+=seconds()-start;
    }
};

class TiffDecoder {
    Source& source_;TIFF* tiff_=nullptr;bool native_error_=false;
    static int error(TIFF*,void* value,const char*,const char*,va_list) {static_cast<TiffDecoder*>(value)->native_error_=true;return 1;}
    static int warning(TIFF*,void*,const char*,const char*,va_list) {return 1;}
    template<class T>T field(std::uint32_t tag) {
        T value{};require(TIFFGetFieldDefaulted(tiff_,tag,&value)==1,"FORMAT","Missing required native TIFF field");return value;
    }
public:
    Layout shape;std::vector<unsigned char> row;double native_seconds=0;
    explicit TiffDecoder(Source& source):source_(source) {}
    ~TiffDecoder() {if(tiff_)TIFFClose(tiff_);}
    void initialize() {
        TIFFOpenOptions* options=TIFFOpenOptionsAlloc();require(options!=nullptr,"BACKEND","TIFF options allocation failed");
        TIFFOpenOptionsSetMaxSingleMemAlloc(options,32*1024*1024);TIFFOpenOptionsSetMaxCumulatedMemAlloc(options,MAX_DECODED);
        TIFFOpenOptionsSetErrorHandlerExtR(options,error,this);TIFFOpenOptionsSetWarningHandlerExtR(options,warning,nullptr);
        int fd=::fcntl(source_.fd.value,F_DUPFD_CLOEXEC,0);
        if(fd<0) {TIFFOpenOptionsFree(options);throw Failure("SOURCE","TIFF source descriptor duplication failed");}
        tiff_=TIFFFdOpenExt(fd,"managed-original","r",options);TIFFOpenOptionsFree(options);
        if(!tiff_) {::close(fd);throw Failure("FORMAT","Original TIFF header cannot be admitted");}
        require(!native_error_,"FORMAT","Original TIFF directory is invalid");
        require(TIFFLastDirectory(tiff_) && !TIFFIsBigTIFF(tiff_),"UNSUPPORTED","Only a single classic TIFF frame is admitted");
        require(!TIFFIsTiled(tiff_) && field<std::uint16_t>(TIFFTAG_PLANARCONFIG)==PLANARCONFIG_CONTIG,"UNSUPPORTED","Only contiguous strip TIFF is admitted");
        require(field<std::uint16_t>(TIFFTAG_ORIENTATION)==ORIENTATION_TOPLEFT,"ORIENTATION","Only stored top-left TIFF orientation is admitted");
        shape.width=field<std::uint32_t>(TIFFTAG_IMAGEWIDTH);shape.height=field<std::uint32_t>(TIFFTAG_IMAGELENGTH);
        shape.depth=field<std::uint16_t>(TIFFTAG_BITSPERSAMPLE);auto sample=field<std::uint16_t>(TIFFTAG_SAMPLEFORMAT);
        if(shape.depth==8 && sample==SAMPLEFORMAT_UINT)shape.dtype="uint8";
        else if(shape.depth==16 && sample==SAMPLEFORMAT_UINT)shape.dtype="uint16";
        else if(shape.depth==16 && sample==SAMPLEFORMAT_INT)shape.dtype="int16";
        else if(shape.depth==32 && sample==SAMPLEFORMAT_IEEEFP)shape.dtype="float32";
        else throw Failure("UNSUPPORTED","TIFF native sample type is not admitted");
        auto count=field<std::uint16_t>(TIFFTAG_SAMPLESPERPIXEL);auto photo=field<std::uint16_t>(TIFFTAG_PHOTOMETRIC);
        shape.compression=field<std::uint16_t>(TIFFTAG_COMPRESSION);
        require((shape.compression==1 || shape.compression==5 || shape.compression==8) && TIFFIsCODECConfigured(shape.compression),"UNSUPPORTED","TIFF compression is not qualified");
        std::uint16_t extra_count=0;std::uint16_t* extras=nullptr;
        int has_extra=TIFFGetField(tiff_,TIFFTAG_EXTRASAMPLES,&extra_count,&extras);
        require(!has_extra || extra_count<=4,"UNSUPPORTED","TIFF extra sample count is unsupported");
        if((photo==PHOTOMETRIC_MINISWHITE || photo==PHOTOMETRIC_MINISBLACK) && count==1) {
            require(!has_extra || extra_count==0,"UNSUPPORTED","Unexpected grayscale extra samples");shape.channels={"Gray"};shape.alpha="absent";
        } else if(photo==PHOTOMETRIC_RGB && (count==3 || count==4)) {
            shape.channels={"R","G","B"};shape.alpha="absent";
            if(count==4) {
                require(has_extra && extra_count==1 && extras && (extras[0]==EXTRASAMPLE_ASSOCALPHA || extras[0]==EXTRASAMPLE_UNASSALPHA),"UNSUPPORTED","RGBA TIFF requires declared stored alpha association");
                shape.channels.push_back("A");shape.alpha=extras[0]==EXTRASAMPLE_ASSOCALPHA?"associated_stored":"straight_stored";
            } else require(!has_extra || extra_count==0,"UNSUPPORTED","Unexpected RGB extra samples");
        } else throw Failure("UNSUPPORTED","TIFF photometric or channel layout is unsupported");
        shape.photometric=photo==PHOTOMETRIC_MINISWHITE?"WhiteIsZero_stored_codes":photo==PHOTOMETRIC_MINISBLACK?"BlackIsZero_stored_codes":"RGB_stored_codes";
        shape.format="TIFF";shape.decoder="libtiff_native_scanline";shape.version=std::string(TIFFGetVersion()).substr(0,256);shape.source_little=little_host();shape.admit();
        require(TIFFScanlineSize64(tiff_)==shape.row_bytes(),"FORMAT","TIFF scanline size differs from its native sample shape");row.resize(shape.row_bytes());
    }
    void admit_full_f32_facts() {
        require(shape.dtype=="float32","UNSUPPORTED","Full source facts require original IEEEfloat32 TIFF words");
        // The original last-directory check covers the main IFD chain only.
        // This new complete-frame receipt must not hide an unreviewed SubIFD/volume.
        std::uint16_t sub_count=0;toff_t* sub_offsets=nullptr;
        int has_sub=TIFFGetField(tiff_,TIFFTAG_SUBIFD,&sub_count,&sub_offsets);
        require(!has_sub || sub_count==0,"UNSUPPORTED","Full source facts do not qualify TIFF SubIFDs");
        std::uint32_t image_depth=1;
        int has_depth=TIFFGetField(tiff_,TIFFTAG_IMAGEDEPTH,&image_depth);
        require(!has_depth || image_depth==1,"UNSUPPORTED","Full source facts do not qualify TIFF image depth");
        require(!native_error_,"FORMAT","TIFF full-frame layout facts could not be read");
    }
    void rows(std::uint32_t last,const std::function<void(std::uint32_t,const unsigned char*)>& receive) {
        // Compressed strips require preceding rows; never jump into codec state.
        for(std::uint32_t y=0;y<last;++y) {
            deadline();double start=seconds();int result=TIFFReadScanline(tiff_,row.data(),y,0);native_seconds+=seconds()-start;
            require(result==1 && !native_error_,"DECODE","Native TIFF scanline decode failed");receive(y,row.data());
        }
    }
};

// Representation facts, not Numeric statistics: inspect IEEE words as integers.
// No float is loaded, compared, normalized, or evaluated (including signaling NaNs).
struct F32Facts {
    std::array<std::uint64_t,7> counts{};
    std::uint64_t total=0;bool finite=false;
    std::uint32_t minimum=0,maximum=0,min_key=0,max_key=0;
    std::unique_ptr<EVP_MD_CTX,decltype(&EVP_MD_CTX_free)> digest{EVP_MD_CTX_new(),EVP_MD_CTX_free};
    F32Facts() {
        require(bool(digest) && EVP_DigestInit_ex(digest.get(),EVP_sha256(),nullptr)==1,"BACKEND","Word SHA256 initialization failed");
    }
    void observe(std::uint32_t word) {
        const auto exponent=(word>>23)&255U, fraction=word&0x7fffffU;const bool negative=(word>>31)!=0;
        unsigned category;
        if(exponent==255U)category=fraction?6U:(negative?5U:4U);
        else if(exponent==0U)category=fraction?1U:(negative?3U:2U);
        else category=0U;
        ++total;++counts[category];
        if(category<4U) {
            // Integer order is numeric for finite binary32, with -0 strictly before +0.
            const auto key=negative?~word:(word|0x80000000U);
            if(!finite || key<min_key) {minimum=word;min_key=key;}
            if(!finite || key>max_key) {maximum=word;max_key=key;}
            finite=true;
        }
    }
    void words(const unsigned char* bytes,std::size_t size) {
        require(EVP_DigestUpdate(digest.get(),bytes,size)==1,"BACKEND","Word SHA256 update failed");
    }
    std::string sha() {
        std::array<unsigned char,EVP_MAX_MD_SIZE> bytes{};unsigned size=0;
        require(EVP_DigestFinal_ex(digest.get(),bytes.data(),&size)==1 && size==32,"BACKEND","Word SHA256 finalization failed");
        std::string result;result.reserve(64);constexpr char digits[]="0123456789abcdef";
        for(unsigned i=0;i<size;++i) {result+=digits[bytes[i]>>4];result+=digits[bytes[i]&15];}
        return result;
    }
};
std::string word_hex(std::uint32_t word) {
    std::string result(8,'0');constexpr char digits[]="0123456789abcdef";
    for(unsigned i=0;i<8;++i)result[7-i]=digits[(word>>(i*4))&15U];
    return result;
}

struct Roi { std::uint32_t x,y,width,height; };
std::uint32_t integer(const char* raw,std::uint32_t low,std::uint32_t high) {
    require(raw && *raw,"PARAMETER","Missing exact integer parameter");std::uint64_t value=0;
    for(const unsigned char* p=reinterpret_cast<const unsigned char*>(raw);*p;++p) {
        require(*p>='0' && *p<='9',"PARAMETER","ROI and frame require exact bounded integers");
        value=value*10+(*p-'0');require(value<=high,"PARAMETER","ROI or frame exceeds its bound");
    }
    require(value>=low,"PARAMETER","ROI or frame is below its bound");return static_cast<std::uint32_t>(value);
}
int directory(const std::string& path) {
    require(!path.empty() && path[0]=='/',"OUTPUT","Private output directory must be absolute");
    Descriptor fd(::open("/",O_RDONLY|O_DIRECTORY|O_CLOEXEC));require(fd.value>=0,"OUTPUT","Root directory cannot be opened");
    std::size_t offset=1;
    while(offset<path.size()) {
        auto end=path.find('/',offset);if(end==std::string::npos)end=path.size();auto part=path.substr(offset,end-offset);
        require(!part.empty() && part!="." && part!="..","OUTPUT","Unsafe output directory path");
        int next=::openat(fd.value,part.c_str(),O_RDONLY|O_DIRECTORY|O_CLOEXEC|O_NOFOLLOW);
        require(next>=0,"OUTPUT","Output directory ancestor is not a real directory");::close(fd.value);fd.value=next;offset=end+1;
    }
    struct stat info{};require(::fstat(fd.value,&info)==0 && S_ISDIR(info.st_mode) && info.st_uid==::getuid() && !(info.st_mode&0077),"OUTPUT","Output directory must be private and owned by this account");
    int result=fd.value;fd.value=-1;return result;
}
struct Output {
    int fd;std::string name;struct stat original{};
};
class Outputs {
    Descriptor directory_;std::vector<Output> files_;bool committed_=false;
public:
    explicit Outputs(const std::string& path):directory_(directory(path)) {}
    ~Outputs() {
        for(auto& item:files_) {
            if(item.fd>=0)::close(item.fd);
            if(!committed_) {
                struct stat named{};
                if(::fstatat(directory_.value,item.name.c_str(),&named,AT_SYMLINK_NOFOLLOW)==0 && named.st_dev==item.original.st_dev && named.st_ino==item.original.st_ino)
                    ::unlinkat(directory_.value,item.name.c_str(),0);
            }
        }
    }
    void add(unsigned index) {
        std::string name="samples-"+std::to_string(index)+".bin";
        int fd=::openat(directory_.value,name.c_str(),O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
        require(fd>=0,"OUTPUT","Exclusive sample output already exists or cannot be created");
        struct stat info{};
        if(::fstat(fd,&info)!=0 || !S_ISREG(info.st_mode) || info.st_nlink!=1 || ::fchmod(fd,0600)!=0) {
            ::close(fd);::unlinkat(directory_.value,name.c_str(),0);throw Failure("OUTPUT","Sample output is not a private regular file");
        }
        try {files_.push_back({fd,name,info});}catch(...) {::close(fd);::unlinkat(directory_.value,name.c_str(),0);throw;}
    }
    void append(std::size_t index,const unsigned char* data,std::size_t size) {
        while(size) {
            deadline();ssize_t count=::write(files_.at(index).fd,data,size);
            if(count<0 && errno==EINTR)continue;
            require(count>0,"OUTPUT","Sample output write failed");data+=count;size-=static_cast<std::size_t>(count);
        }
    }
    void verify(std::uint64_t expected) {
        for(auto& item:files_) {
            struct stat info{},named{};
            require(::fsync(item.fd)==0 && ::fstat(item.fd,&info)==0 &&
                    ::fstatat(directory_.value,item.name.c_str(),&named,AT_SYMLINK_NOFOLLOW)==0 &&
                    S_ISREG(info.st_mode) && info.st_nlink==1 && (info.st_mode&0777)==0600 &&
                    info.st_dev==item.original.st_dev && info.st_ino==item.original.st_ino &&
                    named.st_dev==info.st_dev && named.st_ino==info.st_ino && named.st_nlink==1 &&
                    std::uint64_t(info.st_size)==expected,"OUTPUT","Sample output shape identity or mode changed");
        }
    }
    void sync() {require(::fsync(directory_.value)==0,"OUTPUT","Output directory sync failed");}
    void commit() {committed_=true;}
};

using Json=std::unique_ptr<json_object,decltype(&json_object_put)>;
void attach(json_object* object,const char* key,json_object* value) {
    require(object && value,"BACKEND","Metadata allocation failed");
    require(json_object_object_add(object,key,value)==0,"BACKEND","Metadata field allocation failed");
}
void append_json(json_object* array,json_object* value) {
    require(array && value,"BACKEND","Metadata allocation failed");
    require(json_object_array_add(array,value)==0,"BACKEND","Metadata array allocation failed");
}
void text(json_object* object,const char* key,const std::string& value) {attach(object,key,json_object_new_string_len(value.data(),static_cast<int>(value.size())));}
void number(json_object* object,const char* key,std::uint64_t value) {attach(object,key,json_object_new_uint64(value));}
void flag(json_object* object,const char* key,bool value) {attach(object,key,json_object_new_boolean(value));}
json_object* metadata(const Layout& layout) {
    auto* value=json_object_new_object();text(value,"format",layout.format);number(value,"width",layout.width);number(value,"height",layout.height);
    text(value,"dtype",layout.dtype);number(value,"sample_depth",layout.depth);auto* channels=json_object_new_array();
    for(const auto& channel:layout.channels)append_json(channels,json_object_new_string(channel.c_str()));
    attach(value,"channels",channels);
    number(value,"frame",0);number(value,"frame_count",1);text(value,"photometric",layout.photometric);text(value,"alpha_association",layout.alpha);
    text(value,"orientation","top_left");number(value,"orientation_tag",1);text(value,"decoder",layout.decoder);text(value,"decoder_version",layout.version);
    if(layout.format=="TIFF")number(value,"compression",layout.compression);else flag(value,"profile_conversion",false);
    text(value,"intensity_unit","raw_sample");text(value,"spatial_unit","source_pixel");text(value,"origin","top_left");text(value,"bounds","half_open_strict_containment");
    flag(value,"color_conversion",false);flag(value,"luminance_conversion",false);text(value,"normalization","none");flag(value,"alpha_weighting",false);
    flag(value,"physical_calibration_inferred",false);flag(value,"native_precision_preserved",true);return value;
}
json_object* source_facts(const Layout& layout,const Source& source,const std::string& expected,
                          const std::array<std::unique_ptr<F32Facts>,4>& facts,std::uint32_t rows) {
    const std::uint64_t pixels=std::uint64_t(layout.width)*layout.height;
    require(rows==layout.height,"INTERNAL","Full source row coverage is incomplete");
    auto* value=json_object_new_object();
    auto* binding=json_object_new_object();text(binding,"encoded_sha256",expected);number(binding,"encoded_size_bytes",static_cast<std::uint64_t>(source.original.st_size));
    text(binding,"scope","decoder_input_only_managed_owner_identity_bound_by_provider");text(binding,"stability","descriptor_and_path_same_before_after_full_sha");
    auto* stamp=json_object_new_object();number(stamp,"device",source.original.st_dev);number(stamp,"inode",source.original.st_ino);number(stamp,"mode",source.original.st_mode);number(stamp,"links",source.original.st_nlink);
    attach(stamp,"mtime_seconds",json_object_new_int64(source.original.st_mtim.tv_sec));number(stamp,"mtime_nanoseconds",source.original.st_mtim.tv_nsec);
    attach(stamp,"ctime_seconds",json_object_new_int64(source.original.st_ctim.tv_sec));number(stamp,"ctime_nanoseconds",source.original.st_ctim.tv_nsec);attach(binding,"source_file_stamp",stamp);attach(value,"source_binding",binding);
    auto* coverage=json_object_new_object();number(coverage,"frame",0);number(coverage,"admitted_frame_count",1);number(coverage,"x",0);number(coverage,"y",0);number(coverage,"width",layout.width);number(coverage,"height",layout.height);number(coverage,"pixels_per_channel",pixels);number(coverage,"rows_scanned",rows);flag(coverage,"complete",true);
    auto* names=json_object_new_array();for(const auto& name:layout.channels)append_json(names,json_object_new_string(name.c_str()));attach(coverage,"channels",names);attach(value,"coverage",coverage);
    text(value,"word_basis","losslessly_decoded_IEEE_binary32_before_float_evaluation_or_color_alpha_photometric_transform");
    text(value,"word_digest_order","row_major_per_channel_canonical_little_endian_words");text(value,"finite_order","numeric_order_negative_zero_before_positive_zero");
    auto* channels=json_object_new_array();constexpr std::array<const char*,7> classes{{"normal","subnormal","positive_zero","negative_zero","positive_inf","negative_inf","nan"}};
    for(std::size_t i=0;i<layout.channels.size();++i) {
        auto& fact=*facts[i];std::uint64_t sum=0;for(auto count:fact.counts)sum+=count;
        require(fact.total==pixels && sum==pixels,"INTERNAL","Full source channel class coverage differs");
        auto* channel=json_object_new_object();text(channel,"channel",layout.channels[i]);number(channel,"total_count",fact.total);
        std::uint64_t finite=0;for(unsigned c=0;c<classes.size();++c) {number(channel,classes[c],fact.counts[c]);if(c<4)finite+=fact.counts[c];}
        number(channel,"finite_count",finite);text(channel,"word_sha256",fact.sha());
        if(fact.finite) {text(channel,"finite_minimum_word",word_hex(fact.minimum));text(channel,"finite_maximum_word",word_hex(fact.maximum));}
        else {require(json_object_object_add(channel,"finite_minimum_word",nullptr)==0 && json_object_object_add(channel,"finite_maximum_word",nullptr)==0,"BACKEND","Unavailable word metadata allocation failed");}
        text(channel,"nan_payload_status",fact.counts[6]?"digest_bound_not_enumerated":"absent");append_json(channels,channel);
    }
    attach(value,"channels",channels);auto* logical=json_object_new_object();text(logical,"status","not_computed");attach(value,"logical_values",logical);
    // The source import owner has not yet supplied a reviewed profile/tag contract.
    // Existing effective decoder admission metadata is not complete profile evidence.
    auto* profile=json_object_new_object();text(profile,"status","unknown");text(profile,"provenance","reviewed_import_tag_contract_not_supplied");attach(profile,"facts",json_object_new_object());attach(value,"profile_facts",profile);
    auto* profile_coverage=json_object_new_object();text(profile_coverage,"status","unknown");text(profile_coverage,"reviewed_tag_set","not_supplied");text(profile_coverage,"import_route_revision","not_supplied");attach(value,"profile_coverage",profile_coverage);
    return value;
}
int run(int argc,char** argv) {
    if(argc==2 && std::string(argv[1])=="--version") {
        std::string tiff=TIFFGetVersion();tiff=tiff.substr(0,tiff.find('\n'));
        std::printf("gxtxt_quantitative_extract 1.1.0; libpng %s; %s; %s; json-c %s\n",png_get_libpng_ver(nullptr),tiff.c_str(),OpenSSL_version(OPENSSL_VERSION),json_c_version());return 0;
    }
    require(argc==11,"PARAMETER","Expected SOURCE SHA OUTPUT_DIR OP X Y WIDTH HEIGHT CHANNELS FRAME");
    std::string expected=argv[2];require(expected.size()==64 && std::all_of(expected.begin(),expected.end(),[](char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');}),"SOURCE_SHA","Expected lowercase full SHA256 is required");
    std::string operation=argv[4];const bool facts_mode=operation=="source_facts";require(operation=="describe"||operation=="pixel"||operation=="statistics"||operation=="histogram"||facts_mode,"OPERATION","Unknown finite extraction operation");
    Roi roi{integer(argv[5],0,MAX_DIMENSION-1),integer(argv[6],0,MAX_DIMENSION-1),integer(argv[7],1,MAX_DIMENSION),integer(argv[8],1,MAX_DIMENSION)};
    integer(argv[10],0,0);
    if(facts_mode)require(roi.x==0 && roi.y==0 && roi.width==1 && roi.height==1 && std::string(argv[9])=="all","PARAMETER","Source facts require exact full-source sentinel 0 0 1 1 all 0");
    Source source(argv[1]);require(source.sha()==expected,"SOURCE_SHA","Original source SHA256 differs");Outputs output(argv[3]);
    std::array<unsigned char,8> magic{};source.read(0,magic.data(),magic.size());
    double init_start=seconds();std::unique_ptr<PngDecoder> png;std::unique_ptr<TiffDecoder> tiff;Layout layout;
    if(png_sig_cmp(magic.data(),0,8)==0) {png=std::make_unique<PngDecoder>(source);png->initialize();layout=png->shape;}
    else if((magic[0]=='I'&&magic[1]=='I'&&magic[2]==42&&magic[3]==0)||(magic[0]=='M'&&magic[1]=='M'&&magic[2]==0&&magic[3]==42)) {tiff=std::make_unique<TiffDecoder>(source);tiff->initialize();layout=tiff->shape;}
    else throw Failure("UNSUPPORTED","Only admitted original PNG and classic TIFF are supported");
    double initialization_ms=(seconds()-init_start)*1000;
    if(facts_mode) {require(bool(tiff),"UNSUPPORTED","Source facts require original IEEEfloat32 TIFF");tiff->admit_full_f32_facts();}
    if(operation=="describe" || facts_mode)roi={0,0,layout.width,layout.height};else if(operation=="pixel")roi.width=roi.height=1;
    require(roi.x<=layout.width && roi.y<=layout.height && roi.width<=layout.width-roi.x && roi.height<=layout.height-roi.y,"ROI","Source pixel rectangle must lie strictly within original bounds");
    std::string selection=argv[9];require(!selection.empty() && selection.size()<=256,"CHANNEL","Channel selection is missing or oversized");
    std::vector<std::string> names;std::vector<std::size_t> indexes;
    if(selection=="all")names=layout.channels;else {std::size_t offset=0;while(offset<=selection.size()) {auto end=selection.find(',',offset);if(end==std::string::npos)end=selection.size();names.push_back(selection.substr(offset,end-offset));offset=end+1;}}
    std::set<std::string> unique;
    for(const auto& name:names) {auto found=std::find(layout.channels.begin(),layout.channels.end(),name);require(found!=layout.channels.end() && unique.insert(name).second,"CHANNEL","Original channel is absent duplicated or unsupported");indexes.push_back(found-layout.channels.begin());}
    require(operation!="histogram"||names.size()==1,"CHANNEL","Histogram extraction requires one original channel");
    if(operation!="describe" && !facts_mode)for(std::size_t i=0;i<names.size();++i)output.add(static_cast<unsigned>(i));
    std::array<std::unique_ptr<F32Facts>,4> facts{};std::uint32_t rows_seen=0;
    if(facts_mode)for(std::size_t i=0;i<names.size();++i)facts[i]=std::make_unique<F32Facts>();
    std::vector<unsigned char> selected(std::size_t(roi.width)*layout.item_size());
    double extract_start=seconds();
    auto receive=[&](std::uint32_t y,const unsigned char* row) {
        if(operation=="describe" || y<roi.y || y>=roi.y+roi.height)return;
        if(facts_mode) {require(y==rows_seen,"INTERNAL","Full source row sequence differs");++rows_seen;}
        auto size=layout.item_size();
        for(std::size_t channel=0;channel<indexes.size();++channel) {
            for(std::size_t x=0;x<roi.width;++x) {
                const auto* input=row+((std::size_t(roi.x)+x)*layout.channels.size()+indexes[channel])*size;
                auto* target=selected.data()+x*size;
                if(size==1 || layout.source_little)std::memcpy(target,input,size);else for(std::size_t byte=0;byte<size;++byte)target[byte]=input[size-1-byte];
            }
            if(facts_mode) {
                for(std::size_t x=0;x<roi.width;++x) {
                    const auto* bytes=selected.data()+x*4;
                    const std::uint32_t word=std::uint32_t(bytes[0])|(std::uint32_t(bytes[1])<<8)|(std::uint32_t(bytes[2])<<16)|(std::uint32_t(bytes[3])<<24);
                    facts[channel]->observe(word);
                }
                facts[channel]->words(selected.data(),selected.size());
            } else output.append(channel,selected.data(),selected.size());
        }
    };
    if(png)png->rows(receive);else if(operation!="describe")tiff->rows(roi.y+roi.height,receive);
    output.verify(operation=="describe" || facts_mode?0:std::uint64_t(roi.width)*roi.height*layout.item_size());
    double extraction_ms=(seconds()-extract_start)*1000;double native_ms=(png?png->native_seconds:tiff->native_seconds)*1000;
    require(std::isfinite(initialization_ms) && std::isfinite(extraction_ms) && std::isfinite(native_ms) && initialization_ms>=0 && extraction_ms>=0 && native_ms>=0,"INTERNAL","Extraction phase timings are invalid");
    source.stable();require(source.sha()==expected,"SOURCE_SHA","Original source changed during extraction");source.stable();deadline();
    Json result(json_object_new_object(),json_object_put);require(bool(result),"BACKEND","Metadata allocation failed");text(result.get(),"schema","gxtxt.quantitative_raster.extract.v1");
    attach(result.get(),"metadata",metadata(layout));auto* region=json_object_new_object();number(region,"x",roi.x);number(region,"y",roi.y);number(region,"width",roi.width);number(region,"height",roi.height);attach(result.get(),"roi",region);
    auto* buffers=json_object_new_array();
    if(operation!="describe" && !facts_mode)for(std::size_t i=0;i<names.size();++i) {auto* item=json_object_new_object();text(item,"channel",names[i]);text(item,"dtype",layout.dtype);number(item,"elements",std::uint64_t(roi.width)*roi.height);number(item,"size_bytes",std::uint64_t(roi.width)*roi.height*layout.item_size());text(item,"file","samples-"+std::to_string(i)+".bin");append_json(buffers,item);}
    attach(result.get(),"buffers",buffers);auto* timing=json_object_new_object();attach(timing,"decoder_initialization",json_object_new_double(initialization_ms));attach(timing,"native_scanline_decode",json_object_new_double(native_ms));attach(timing,"extraction",json_object_new_double(extraction_ms));attach(result.get(),"timings_ms",timing);
    if(facts_mode) {text(result.get(),"facts_profile","stored_f32_full_v1");attach(result.get(),"source_facts",source_facts(layout,source,expected,facts,rows_seen));}
    const char* wire=json_object_to_json_string_ext(result.get(),JSON_C_TO_STRING_PLAIN);require(wire && std::strlen(wire)+1<=MAX_METADATA,"LIMIT","Extraction metadata exceeds32KiB");
    output.sync();require(std::printf("%s\n",wire)>0 && std::fflush(stdout)==0,"OUTPUT","Metadata output write failed");output.commit();return 0;
}
} // namespace
int main(int argc,char** argv) {
    static_assert(CHAR_BIT==8 && sizeof(float)==4 && std::numeric_limits<float>::is_iec559,"Native extraction requires IEEEfloat32 and8-bit bytes");
    std::signal(SIGTERM,on_signal);std::signal(SIGINT,on_signal);std::signal(SIGPIPE,SIG_IGN);
    try {return run(argc,argv);}catch(const Failure& error) {std::fprintf(stderr,"GXTXT:QuantitativeRaster:%s: %s\n",error.code.c_str(),error.what());}
    catch(const std::bad_alloc&) {std::fprintf(stderr,"GXTXT:QuantitativeRaster:LIMIT: Native allocation failed\n");}
    catch(...) {std::fprintf(stderr,"GXTXT:QuantitativeRaster:DECODE: Native extraction failed\n");}
    return 2;
}
