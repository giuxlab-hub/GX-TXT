# Original scientific raster extraction

This trusted C++17 helper decodes original sample bytes and copies a source-pixel ROI into per-channel buffers. The four legacy modes perform no statistics, reductions, histograms, mathematical summaries, nonfinite classification, display conversion or publication. The additive `source_facts` mode classifies original IEEE binary32 words as representation facts using byte/integer access only; it computes no scientific statistics or processing eligibility. Public NUMERIC_API_v1 owns computations. MAIN's fixed RuntimeTool and existing ScientificExecution Job own authorization, source materialization, execution and scratch lifetime; the CLI is not a public caller-path capability or security sandbox.

The prebuilt Linux x86-64 executable is `gxtxt_quantitative_extract`. Executable version 1.1.0 adds the private `source_facts` mode while retaining `extract.v1` and the four legacy extraction modes. Runtime compilation is unnecessary. CMake source and BUILD_PROVENANCE.json identify the tested compiler, installed dependencies, source hashes and exact bundled binary. Other platforms require an explicitly qualified build; no Windows ABI claim is made.

```text
gxtxt_quantitative_extract SOURCE EXPECTED_SHA OUTPUT_DIR OP X Y WIDTH HEIGHT CHANNELS FRAME
gxtxt_quantitative_extract --version
```

Exactly ten fixed arguments follow the executable. Legacy OP is describe/pixel/statistics/histogram; these are extraction labels only. The additive finite `source_facts` mode is specified below. Describe reports the full source extent and writes no buffers. Pixel forces 1x1 at explicit X/Y. Other ROIs are strictly contained half-open integer rectangles in original top-left stored pixel coordinates. Incoming W/H must still be positive bounded integers. FRAME is exactly 0. CHANNELS is all or a comma-separated unique subset of Gray/R/G/B/A in requested output order. Histogram extraction requires one channel but computes no bins/counts. Unknown operations, channels, modes or frames refuse.

SOURCE must be a bounded nonempty regular single-link file opened read-only/O_NOFOLLOW. Full SHA256 must equal the exact 64-character lowercase expected hash before and after extraction, with stable descriptor/path identity. Encoded bytes<=64MiB, pixels<=16,777,216, each dimension<=16384, decoded declared raster<=128MiB and row<=1MiB. Sources are never modified. Output directory must already exist, be absolute, real (no symlink ancestors), owned by this account and private 0700. No output directory is created by the helper.

Supported native encodings:

- PNG Gray/RGB/RGBA unsigned 8/16, noninterlaced. Full chunk bounds/order/CRC, IHDR/data/IEND structure and decoder row shape are checked. Palette, sub-8-bit, gray-alpha, transparency-key, EXIF, ICC, animation, unknown critical chunks and interlace refuse. Raw codes are read with full libpng scanline API without gamma, normalization, alpha or significant-bit transforms. Source gAMA/sRGB declarations do not transform samples. Unneeded text chunks are discarded after source CRC checking, avoiding compressed-text inflation. No simplified linear/premultiplied image API is used.
- Classic single-frame, strip-contiguous, stored top-left TIFF Gray/RGB/RGBA with uint8/uint16/int16/IEEEfloat32. Compression 1/5/8 only, with installed-codec admission. Tiled, planar-separate, multiple frames, BigTIFF, other photometric/sample/compression/orientation layouts refuse. WhiteIsZero returns stored codes without inversion. RGBA requires exactly one explicit associated/unassociated alpha declaration; associated component codes remain associated, without unpremultiplication. Native TIFF OpenOptions cap single allocations 32MiB and cumulative allocations 128MiB. Rows before a cropped compressed ROI are decoded sequentially, retaining one row.

For each selected channel, `samples-INDEX.bin` is created exclusively/O_NOFOLLOW at mode 0600 and contains contiguous row-major little-endian original dtype samples. In these legacy extraction buffers, integer values and float32 bits (including nonfinite payloads and signed zero) are not converted to binary64 or classified. Existing files are never overwritten. Caught errors/cancellation remove only this invocation's own created files; pre-existing output content remains. SIGTERM/SIGINT request cooperative cancellation. An abrupt SIGKILL or blocked native call can bypass cleanup/cooperative 120s checks; existing Job guardian and Resource ownership retain final disposal authority.

Successful extraction prints one finite JSON object<=32KiB, with no success stderr:

```text
{
 schema: "gxtxt.quantitative_raster.extract.v1",
 metadata: {format,width,height,dtype,sample_depth,channels,frame,frame_count,
            photometric,alpha_association,orientation,orientation_tag,
            decoder,decoder_version,[compression/profile_conversion],
            intensity_unit:"raw_sample",spatial_unit:"source_pixel",origin:"top_left",
            bounds:"half_open_strict_containment",color_conversion:false,
            luminance_conversion:false,normalization:"none",alpha_weighting:false,
            physical_calibration_inferred:false,native_precision_preserved:true},
 roi: {x,y,width,height},
 buffers: [{channel,dtype,elements,size_bytes,file}],
 timings_ms: {decoder_initialization,native_scanline_decode,extraction}
}
```

PNG decoder is truthfully `libpng_native_scanline`; TIFF remains `libtiff_native_scanline`. Dtypes are uint8/uint16/int16/float32. Buffers carry filenames only; no numeric values or classifications appear in JSON. Describe has an empty buffer array. Decoder initialization includes header admission; native scanline timing counts decoder calls; extraction includes streamed copying/output validation and overlapping native decode time. These are not additive independent phases or end-to-end Job/GUI timings. Source SHA guards and caller orchestration are outside these phase timings. TIFF describe admits its full directory but does not decode pixel payload; PNG describe validates full scanlines/end structure while producing no buffers.

Caught failures print one bounded `GXTXT:QuantitativeRaster:CODE: message` stderr line, no success JSON, and exit nonzero. Ordinary --version returns one short tool/runtime-library version line for fixed RuntimeTool discovery.

Decoder capability is distinct from installed Viewer/Canvas admission: a source supported here can still be refused by an existing display or source-dimension owner. No scientific precision, actual C++ reachability, resource cancellation, latency or release acceptance beyond the separately pinned integration/independent evidence is implied by this component alone.

## Full-source Float32 representation facts

`source_facts` uses the same Source, libtiff header admission and scanline decoder. Its exact control arguments are:

```text
gxtxt_quantitative_extract SOURCE EXPECTED_SHA OUTPUT_DIR source_facts 0 0 1 1 all 0
```

The six controls are a fixed sentinel, never a caller assertion of dimensions or a one-pixel ROI. Every other sentinel refuses before source access. The original admitted header supplies the full width/height; every stored channel of every pixel in its admitted single classic main IFD/frame 0 is scanned once. This mode accepts only the original decoder's IEEE Float32 TIFF layouts and additionally refuses unqualified SubIFDs and image depth other than one. All existing encoding, allocation, source-identity, SHA, pixel, row, dimension, cancellation and deadline limits remain. Legacy four modes and their guards remain unchanged. Broader formats/layouts/100MP processing remain separate original SII requirements, not scientific exclusions introduced by this fact receipt.

No sample buffers or new files are written. Output retains the finite `gxtxt.quantitative_raster.extract.v1` envelope, original effective admission metadata, full observed ROI, empty `buffers`, phase timings and the 32KiB JSON limit. Additive fields are `facts_profile:"stored_f32_full_v1"` and `source_facts`:

- `source_binding` records the observed encoded SHA/size and original descriptor/path file stamp verified before/after hashing. This binds decoder input only; it invents no Dataset revision, Resource generation, Document CAS or Session authority. The existing managed owner must supply those identities and production reservations before exposure.
- `coverage` records frame 0, admitted frame count 1, observed full width/height, all stored channel names/order, pixels per channel, rows scanned and `complete:true`. Complete applies only to this admitted layout, never unknown additional image structures or universal all-frame formats.
- Each `channels` record has exact integer `total_count`, `normal`, `subnormal`, `positive_zero`, `negative_zero`, `positive_inf`, `negative_inf`, `nan` and `finite_count`. Seven disjoint classes sum to the full per-channel pixel count. Finite count is the first four classes. No sample is loaded or evaluated as a float, including signaling NaNs.
- `word_sha256` includes every reconstructed original word, in row-major order per channel, serialized little-endian before photometric/color/alpha conversion. Sign, signed zero and all NaN payload bits are digest-bound. `nan_payload_status` is `absent` only for verified count zero, otherwise `digest_bound_not_enumerated`.
- `finite_minimum_word` / `finite_maximum_word` are eight lowercase hexadecimal original words, or JSON null if no finite sample exists. Integer monotonic binary32 ordering implements ordinary finite numeric order with negative zero strictly before positive zero. These bounds are representation witnesses, not an eligibility heuristic.
- `logical_values.status` is `not_computed`. WhiteIsZero stored codes, associated alpha and raw units are not silently reinterpreted.
- `profile_facts.status` and `profile_coverage.status` are explicitly `unknown`: a reviewed SII import-route/tag-set contract has not been supplied. Empty facts do not assert absent ICC, transfer/color/min/max declarations or complete profile knowledge. Original effective decoder admission metadata is distinct from raw-profile completeness.

This private fixed-tool primitive grants no new public operation by itself. Matching source/build pins, existing managed production budgets, canonical/Resource/Document currentness, result ownership and the reviewed scientific import contract remain necessary for integration. Facts alone are never `precision_pass`, a universal scale-1 theorem or permission to narrow original scientific processing requirements. No alternate decoder, statistics engine or frontend repair is introduced.
