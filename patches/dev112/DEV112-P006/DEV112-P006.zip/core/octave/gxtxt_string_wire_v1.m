function value=gxtxt_string_wire_v1(action,input)
% Canonical String codec shared by CORE clients and retained control results.
% Optional UTF8 Base64 avoids Octave JSON NUL truncation; String stays String.
% SPDX-License-Identifier: GPL-3.0-or-later
  switch(action)
    case 'pack'
      if(!ischar(input)),error('GXTXT:ScriptBridge:InvalidArguments','String payload must be text');endif
      if(!any(input(:)==char(0)))
        value=struct('kind','string','value',input);return;
      endif
      text_vector(input);bytes=unicode2native(input,'UTF-8');valid_utf8(bytes);
      value=struct('kind','string','data_encoding','utf8-base64','data',char(matlab.net.base64encode(bytes)));
    case 'unpack'
      if(!isstruct(input)||numel(input)!=1||!isfield(input,'kind')||!ischar(input.kind)||!strcmp(input.kind,'string'))
        error('GXTXT:ScriptBridge:Transport','Expected a String wire node');
      endif
      if(!isfield(input,'data_encoding'))
        if(isfield(input,'data')||!isfield(input,'value')||!ischar(input.value))
          error('GXTXT:ScriptBridge:Transport','Invalid plain String payload');
        endif
        value=input.value;return;
      endif
      if(!isequal(sort(fieldnames(input)),sort({'kind';'data_encoding';'data'}))||!ischar(input.data_encoding)||!strcmp(input.data_encoding,'utf8-base64')||!ischar(input.data))
        error('GXTXT:ScriptBridge:Transport','Invalid or unknown String data encoding');
      endif
      encoded=input.data;text_vector(encoded);
      if(!isempty(encoded)&&isempty(regexp(encoded,'^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$','once')))
        error('GXTXT:ScriptBridge:Transport','Invalid String Base64 payload');
      endif
      bytes=uint8([]);
      if(!isempty(encoded))
        try bytes=uint8(matlab.net.base64decode(encoded));
        catch,error('GXTXT:ScriptBridge:Transport','Invalid String Base64 payload');end_try_catch
      endif
      canonical='';if(!isempty(bytes)),canonical=char(matlab.net.base64encode(bytes));endif
      if(!strcmp(canonical,encoded)),error('GXTXT:ScriptBridge:Transport','Noncanonical String Base64 payload');endif
      valid_utf8(bytes);value=char(bytes(:)');
    case 'quote'
      % Keep stdlib escaping for every NUL-free part. This is String quoting,
      % never a replacement JSON parser or marker decoder for arbitrary dicts.
      text_vector(input);bytes=unicode2native(input,'UTF-8');valid_utf8(bytes);
      boundaries=[0 find(input==char(0)) numel(input)+1];parts=cell(1,numel(boundaries)-1);
      for k=1:numel(parts)
        encoded=jsonencode(input(boundaries(k)+1:boundaries(k+1)-1));parts{k}=encoded(2:end-1);
      endfor
      % A cell delimiter avoids strjoin interpreting backslash escapes itself.
      value=['"' strjoin(parts,{[char(92) 'u0000']}) '"'];
    otherwise,error('GXTXT:ScriptBridge:InvalidArguments','Unknown String codec action');
  endswitch
endfunction

function text_vector(value)
  if(!ischar(value)||(!isempty(value)&&rows(value)!=1))
    error('GXTXT:ScriptBridge:Transport','Encoded String must be a character row vector');
  endif
endfunction

function valid_utf8(bytes)
  % Validate bytes explicitly: no replacement characters, overlong sequences,
  % surrogate codepoints, truncated sequences or codepoints above U+10FFFF.
  bytes=double(bytes(:)');i=1;n=numel(bytes);
  while(i<=n)
    b=bytes(i);count=0;low=128;high=191;
    if(b<=127),i+=1;continue;
    elseif(b>=194&&b<=223),count=1;
    elseif(b>=224&&b<=239),count=2;if(b==224),low=160;elseif(b==237),high=159;endif
    elseif(b>=240&&b<=244),count=3;if(b==240),low=144;elseif(b==244),high=143;endif
    else,error('GXTXT:ScriptBridge:Transport','Invalid UTF-8 String payload');endif
    if(i+count>n||bytes(i+1)<low||bytes(i+1)>high||any(bytes(i+2:i+count)<128|bytes(i+2:i+count)>191))
      error('GXTXT:ScriptBridge:Transport','Invalid UTF-8 String payload');
    endif
    i+=count+1;
  endwhile
endfunction
