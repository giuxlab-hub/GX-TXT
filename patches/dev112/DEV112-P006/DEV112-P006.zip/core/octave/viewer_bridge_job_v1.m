% CORE generic frontend through the ordinary Octave Script Job Bridge.
% SPDX-License-Identifier: GPL-3.0-or-later
1;

function viewer_bridge_job_main()
  context=gxtxt_context();
  global GXTXT_SCRIPT_BRIDGE_STATE;
  internal=which('gxtxt_script_bridge_internal');
  root=fileparts(fileparts(fileparts(fileparts(internal))));
  helper=fullfile(root,'core','python','viewer_bridge_control_v1.py');
  cfg=gxtxt_ini_read(fullfile(context.output_dir,'runtime.ini'));
  python=strtrim(gxtxt_ini_get(cfg,'runtime.python_cmd','python3'));
  temporary={};fd=-1;
  unwind_protect
    [fd,parameter,message]=mkstemp(fullfile(context.output_dir,'viewer_parameter_XXXXXX'),false);
    if(fd<0),error('GXTXT:ViewerBridge:Input','Cannot stage owned request: %s',message);endif
    temporary{end+1}=parameter;
    bytes=unicode2native(context.parameters.request_json,'UTF-8');
    if(fwrite(fd,bytes,'uint8')!=numel(bytes)),error('GXTXT:ViewerBridge:Input','Short request stage write');endif
    fclose(fd);fd=-1;
    [fd,plan_path,message]=mkstemp(fullfile(context.output_dir,'viewer_packets_XXXXXX'),false);
    if(fd<0),error('GXTXT:ViewerBridge:Input','Cannot stage owned packet plan: %s',message);endif
    temporary{end+1}=plan_path;fclose(fd);fd=-1;
    command=[gxtxt_shell_quote_v1(python) ' -B ' gxtxt_shell_quote_v1(helper) ' octave_packets ' ...
      gxtxt_shell_quote_v1(context.output_dir) ' ' gxtxt_shell_quote_v1(GXTXT_SCRIPT_BRIDGE_STATE.buffer_scope) ...
      ' < ' gxtxt_shell_quote_v1(parameter) ' > ' gxtxt_shell_quote_v1(plan_path)];
    if(system(command)!=0),error('GXTXT:ViewerBridge:Input','Original managed request encoder refused');endif
    plan=jsondecode(fileread(plan_path),'makeValidName',false);
    if(!isstruct(plan)||numel(plan)!=1||!isequal(sort(fieldnames(plan)),sort({'schema';'action';'parameter_sha256';'packets'})) ...
       ||!strcmp(plan.schema,'gxtxt.viewer_bridge_packets.v1')||!any(strcmp(plan.action,{'list','describe','require','call'})) ...
       ||!ischar(plan.parameter_sha256)||isempty(regexp(plan.parameter_sha256,'^[0-9a-f]{64}$','once')) ...
       ||!isstruct(plan.packets)||numel(plan.packets)!=(1+strcmp(plan.action,'call')))
      error('GXTXT:ViewerBridge:Input','Invalid fixed CORE packet plan');
    endif
    % Forward original canonical packets and retain original terminal JSON.
    % Native Octave conversion would collapse null and scalar array dtypes.
    for k=1:numel(plan.packets)
      response=gxtxt_script_bridge_internal('request_transport',plan.packets(k));
    endfor
    [fd,response_path,message]=mkstemp(fullfile(context.output_dir,'viewer_response_XXXXXX'),false);
    if(fd<0),error('GXTXT:ViewerBridge:Output','Cannot stage original response: %s',message);endif
    temporary{end+1}=response_path;
    bytes=uint8(response);
    if(fwrite(fd,bytes,'uint8')!=numel(bytes)),error('GXTXT:ViewerBridge:Output','Short response stage write');endif
    fclose(fd);fd=-1;
    command=[gxtxt_shell_quote_v1(python) ' -B ' gxtxt_shell_quote_v1(helper) ' retain_octave ' ...
      gxtxt_shell_quote_v1(context.output_dir) ' ' gxtxt_shell_quote_v1(GXTXT_SCRIPT_BRIDGE_STATE.buffer_scope) ' ' ...
      gxtxt_shell_quote_v1(parameter) ' ' gxtxt_shell_quote_v1(plan.parameter_sha256) ' ' ...
      gxtxt_shell_quote_v1(context.module_id) ' ' gxtxt_shell_quote_v1(context.run_id) ...
      ' < ' gxtxt_shell_quote_v1(response_path)];
    if(system(command)!=0),error('GXTXT:ViewerBridge:Output','Original managed response retention refused');endif
  unwind_protect_cleanup
    if(fd>=0),fclose(fd);endif
    for k=1:numel(temporary)
      if(exist(temporary{k},'file')==2),unlink(temporary{k});endif
    endfor
  end_unwind_protect
  fprintf('@@GXTXT_PROGRESS_V1@@\tfraction=1\tstage=Viewer Script Bridge operation completed\n');
endfunction

viewer_bridge_job_main();
