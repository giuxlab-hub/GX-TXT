# Script Bridge operation policy: resource_management_api_v1.script_bridge_policy.json (exact operation scope; no runtime registration).
# SPDX-License-Identifier: GPL-3.0-or-later
# Framework-wide accounting only. Session, Publication and managed-document
# authorities retain their scientific ownership and recovery decisions.
namespace eval ::GX::ResourceManagement {variable requests {}; variable serial 0}

proc ::GX::resourceManagementApiInfo {} {
    return [dict create api_id RESOURCE_MANAGEMENT_API_v1 api_version 1 scope framework \
        operations {allocate observe release inspect inventory reconcile cleanup policy} \
        external_cleanup 0 legacy_cleanup 0]
}
proc ::GX::resourceManagementRoot {} {
    if {[info exists ::env(GXTXT_RESOURCE_ROOT)] && $::env(GXTXT_RESOURCE_ROOT) ne ""} {return $::env(GXTXT_RESOURCE_ROOT)}
    return [file join [file dirname [configurationPath]] resource-management]
}
proc ::GX::resourceManagementCommand {} {
    if {[llength [info commands ::GX::runtimeToolRequired]]} {set python [runtimeToolRequired python]} else {set python [auto_execok python3]}
    set command [list $python -B [file join $::GX::scriptDir core python gxtxt_resource_manager.py] \
        --root [resourceManagementRoot] --caller-pid [pid] --tcl]
    if {[info exists ::env(GXTXT_RESOURCE_STORAGE)] && $::env(GXTXT_RESOURCE_STORAGE) ne ""} {
        lappend command --storage-root $::env(GXTXT_RESOURCE_STORAGE)
    } elseif {[llength [info commands ::GX::configurationTempDirectory]]} {
        lappend command --storage-root [file join [configurationTempDirectory] resources-v1]
    }
    return $command
}
proc ::GX::resourceManagementCall {operation args} {
    return [exec -- {*}[resourceManagementCommand] $operation {*}$args]
}
proc ::GX::resourceManagementAllocate {subsystem {options {}}} {
    return [resourceManagementCall allocate subsystem $subsystem {*}$options]
}
proc ::GX::resourceManagementObserve {path subsystem {options {}}} {
    return [resourceManagementCall observe path $path subsystem $subsystem {*}$options]
}
proc ::GX::resourceManagementRelease {id {state verified_orphan} {retention ""}} {
    set options [list resource_id $id state $state]
    if {$retention ne ""} {lappend options retention_seconds $retention}
    return [resourceManagementCall release {*}$options]
}
proc ::GX::resourceManagementInventory {{rescan 0}} {return [resourceManagementCall inventory rescan $rescan]}
proc ::GX::resourceManagementInspect {id} {return [resourceManagementCall inspect resource_id $id]}
proc ::GX::resourceManagementCleanup {ids} {return [resourceManagementCall cleanup {*}$ids]}
proc ::GX::resourceManagementPolicy {{options {}}} {return [resourceManagementCall policy {*}$options]}

# Legacy inventory is explicit and read-only. Filename patterns never grant
# deletion rights. The current Session is just one reporting association.
proc ::GX::resourceManagementLegacyPaths {} {
    set rows {}
    set root [configurationCacheDirectory]
    foreach {relative subsystem category} {
        gx3de_viewer native3d cache_reusable
    } {
        set path [file join $root $relative]
        if {[file exists $path]} {lappend rows [dict create path $path subsystem $subsystem category $category recovery_required 0]}
    }
    foreach configuredRoot [lsort -unique [list $root [configurationTempDirectory]]] {
        foreach path [glob -nocomplain -directory $configuredRoot * .*] {
            if {[file tail $path] in {. .. gx3de_viewer resources-v1}} continue
            # A registered allocation root has exact records already. Unknown
            # historical files remain visible but never become cleanup targets.
            if {[file normalize $path] eq [file normalize [resourceManagementRoot]]} continue
            lappend rows [dict create path $path subsystem legacy_storage category unknown_legacy]
        }
    }
    if {[info exists ::GX::previewBinaryTaskDir] && $::GX::previewBinaryTaskDir ne ""} {
        lappend rows [dict create path $::GX::previewBinaryTaskDir subsystem dataset_preview category active]
    }
    foreach key [array names ::GX::DatasetViewer::state *,temp] {
        set path $::GX::DatasetViewer::state($key)
        if {$path ne "" && [file exists $path]} {lappend rows [dict create path $path subsystem native3d_preview category active]}
    }
    if {[info exists ::GX::currentSession] && $::GX::currentSession ne ""} {
        set session [file normalize $::GX::currentSession]
        foreach {relative subsystem category} {
            cache/dataset_materializations dataset_materialization cache_reusable
            metadata/interactive_document_resources managed_document protected_authoritative
            datasets datasets protected_authoritative
            analysis analysis_outputs protected_authoritative
        } {
            set path [file join $session $relative]
            if {[file exists $path]} {lappend rows [dict create path $path subsystem $subsystem category $category session $session]}
        }
    }
    return $rows
}

# Long rescans run in a separate local helper with fileevents, never in the Tk
# callback. The response is a Tcl dictionary as data; it is never evaluated.
proc ::GX::resourceManagementAsync {operation arguments callback} {
    variable ::GX::ResourceManagement::requests
    variable ::GX::ResourceManagement::serial
    set token "resource-request#[incr serial]"
    set pipe [open [concat [list |] [resourceManagementCommand] [list $operation] $arguments [list 2>@1]] r]
    fconfigure $pipe -blocking 0 -encoding utf-8 -translation lf
    dict set requests $token [dict create pipe $pipe output {} callback $callback]
    fileevent $pipe readable [list ::GX::resourceManagementReadable $token]
    return $token
}
proc ::GX::resourceManagementReadable {token} {
    variable ::GX::ResourceManagement::requests
    if {![dict exists $requests $token]} return
    if {[dict exists $requests $token bounded]} {return [_resourceManagementBoundedReadable $token]}
    set request [dict get $requests $token]
    set pipe [dict get $request pipe]
    dict append request output [read $pipe]
    dict set requests $token $request
    if {![eof $pipe]} return
    fileevent $pipe readable {}
    # At EOF closing the process channel cannot wait on ongoing computation.
    fconfigure $pipe -blocking 1
    set code [catch {close $pipe} problem]
    set output [string trim [dict get $request output]]
    dict unset requests $token
    if {$code && $output eq ""} {set output $problem}
    uplevel #0 [list {*}[dict get $request callback] $code $output]
}

# HOST_ONLY: fixed original Resource CLI lifecycle for an already-owned import
# allocation. No caller-selected code, PID/group signal, Resource grant or Job.
# Public resourceManagementAsync and its two-argument callback remain unchanged.
proc ::GX::_resourceManagementMonotonicMs {} {
    if {$::tcl_platform(os) ne {Linux}} {error {Bounded Resource helper needs Linux boot-time identity}}
    set f [open /proc/uptime rb]
    try {set data [read $f 257]} finally {close $f}
    if {[string length $data]>256 || ![regexp {^([0-9]+)\.([0-9][0-9]) } $data -> seconds fraction]} {error {Resource boot-time clock is unavailable}}
    scan $fraction %d hundredths
    set value [expr {$seconds*1000+$hundredths*10}]
    if {[info exists ::GX::ResourceManagement::lastBootMs] && $value<$::GX::ResourceManagement::lastBootMs} {error {Resource boot-time clock moved backwards}}
    set ::GX::ResourceManagement::lastBootMs $value
    return $value
}
proc ::GX::_resourceManagementChildIdentity {child} {
    if {![string is entier -strict $child] || $child<=1} {return [dict create state unknown identity {}]}
    # Only disappearance while observing THIS child proves it is gone. Missing
    # boot/self-UID proof must never turn a known-live child into "dead".
    set code [catch {
        set f [open /proc/$child/stat rb];try {set data [read $f 16385]} finally {close $f}
        file stat /proc/$child childStat
    } reason context]
    if {$code} {
        if {[dict exists $context -errorcode] && [lindex [dict get $context -errorcode] 0] eq {POSIX} && [lindex [dict get $context -errorcode] 1] in {ENOENT ESRCH}} {return [dict create state dead identity {}]}
        return [dict create state unknown identity {}]
    }
    set code [catch {
        if {[string length $data]>16384 || [set end [string last ) $data]]<1} {error {Invalid child stat}}
        set fields [regexp -all -inline {\S+} [string range $data [expr {$end+2}] end]]
        if {[llength $fields]<20 || ![string is entier -strict [lindex $fields 19]]} {error {Invalid child start}}
        set f [open /proc/sys/kernel/random/boot_id rb];try {set boot [string trim [read $f 129]]} finally {close $f}
        if {![regexp {^[a-f0-9-]{36}$} $boot]} {error {Invalid boot identity}}
        file stat /proc/[pid] ownStat
        if {$childStat(uid)!=$ownStat(uid)} {error {Foreign child UID}}
        set result [dict create state [expr {[lindex $fields 0] eq {Z}?{dead}:{live}}] identity $boot:[lindex $fields 19] parent [lindex $fields 1]]
    } reason context]
    if {!$code} {return $result}
    return [dict create state unknown identity {}]
}
proc ::GX::_resourceManagementAbsolutePath {path} {
    if {[file pathtype $path] ne {absolute}} {set path [file join [pwd] $path]}
    # Lexical abspath only. Resolving a symlink here could bypass the original
    # Resource authority's no-alias path admission.
    set parts {}
    foreach part [file split $path] {
        if {$part in {/ . {}}} continue
        if {$part eq {..}} {set parts [lrange $parts 0 end-1]} else {lappend parts $part}
    }
    return [file join / {*}$parts]
}
proc ::GX::_resourceManagementFreezeCommand {command} {
    if {[llength $command] ni {8 10} || [lindex $command 1] ne {-B} || [lindex $command 3] ne {--root} ||
        [lindex $command 5] ne {--caller-pid} || [lindex $command 6] ne [pid] || [lindex $command 7] ne {--tcl} ||
        ([llength $command]==10 && [lindex $command 8] ne {--storage-root}) || [file pathtype [lindex $command 0]] ne {absolute}} {error {Original Resource command scope is unavailable}}
    foreach index {2 4} {lset command $index [_resourceManagementAbsolutePath [lindex $command $index]]}
    if {[llength $command]==10} {lset command 9 [_resourceManagementAbsolutePath [lindex $command 9]]}
    return $command
}
proc ::GX::_resourceManagementPathProof {path type uid} {
    if {[file pathtype $path] ne {absolute}} {error {Original Resource scope path is not absolute}}
    set current /
    foreach part [lrange [file split $path] 1 end] {
        set current [file join $current $part];file lstat $current s
        if {$current ne $path && $s(type) ne {directory}} {error {Original Resource scope has an aliased ancestor}}
    }
    if {$s(type) ne $type || $s(uid)!=$uid || ($s(mode)&0022)} {error {Original Resource scope identity is unavailable}}
    if {$type eq {file} && $s(nlink)!=1} {error {Original Resource registry is shared}}
    return [list $s(dev) $s(ino)]
}
proc ::GX::_resourceManagementCaptureScope {command allocation} {
    set scope [dict create available 0 command $command]
    set code [catch {
        set command [_resourceManagementFreezeCommand $command]
        set self [_resourceManagementChildIdentity [pid]]
        if {[dict get $self state] ne {live} || [dict get $self identity] eq {} || [dict get $allocation owner_pid] ne [pid] ||
            [dict get $allocation owner_identity] ne [dict get $self identity] || ![dict get $allocation managed] || [dict get $allocation recovery_required] || [dict get $allocation kind] ne {directory}} {error {Original Resource caller/allocation ownership is unproven}}
        file stat /proc/[pid] own
        set root [lindex $command 4];set envelope [dict get $allocation envelope];set storage [file dirname $envelope]
        if {[dict get $allocation path] ne $envelope || [file tail $envelope] ne [dict get $allocation id]} {error {Original Resource allocation path differs}}
        set rootIdentity [_resourceManagementPathProof $root directory $own(uid)]
        set databaseIdentity [_resourceManagementPathProof [file join $root registry.sqlite3] file $own(uid)]
        set storageIdentity [_resourceManagementPathProof $storage directory $own(uid)]
        set allocationIdentity [_resourceManagementPathProof $envelope directory $own(uid)]
        if {$allocationIdentity ne [dict get $allocation identity]} {error {Original Resource allocation identity differs}}
        set allocationCommand $command
        # Pin the storage actually selected by the original registry, including
        # the no-option case. A later ambient storage preference cannot retarget.
        if {[llength $command]==8} {lappend command --storage-root $storage} else {lset command 9 $storage}
        set scope [dict create available 1 allocation_command $allocationCommand command $command root $root root_identity $rootIdentity registry_identity $databaseIdentity \
            storage $storage storage_identity $storageIdentity envelope $envelope allocation_id [dict get $allocation id] allocation_identity $allocationIdentity \
            owner_pid [pid] owner_identity [dict get $self identity] uid $own(uid)]
    } reason]
    if {$code} {dict set scope error $reason}
    return $scope
}
proc ::GX::_resourceManagementAllocateScoped {subsystem options} {
    if {$subsystem ne {scientific_execution_image_import}} {error {Private Resource scope is only for original image imports}}
    set command [_resourceManagementFreezeCommand [resourceManagementCommand]]
    set allocation [exec -- {*}$command allocate subsystem $subsystem {*}$options]
    return [dict create allocation $allocation scope [_resourceManagementCaptureScope $command $allocation]]
}
proc ::GX::_resourceManagementScopeGuard {scope id phase} {
    if {![dict exists $scope available] || ![dict get $scope available] || [dict get $scope allocation_id] ne $id || [dict get $scope owner_pid] ne [pid]} {error {Original Resource ownership scope is unavailable}}
    set self [_resourceManagementChildIdentity [pid]]
    if {[dict get $self state] ne {live} || [dict get $self identity] ne [dict get $scope owner_identity]} {error {Original Resource caller identity changed}}
    set command [dict get $scope command]
    if {[_resourceManagementFreezeCommand $command] ne $command || [lindex $command 4] ne [dict get $scope root] ||
        [llength $command]!=10 || [lindex $command 9] ne [dict get $scope storage]} {error {Original Resource command changed}}
    foreach {path identity type} [list [dict get $scope root] [dict get $scope root_identity] directory \
        [file join [dict get $scope root] registry.sqlite3] [dict get $scope registry_identity] file \
        [dict get $scope storage] [dict get $scope storage_identity] directory] {
        if {[_resourceManagementPathProof $path $type [dict get $scope uid]] ne $identity} {error {Original Resource registry/storage scope was replaced}}
    }
    if {$phase ne {removed}} {
        set path [dict get $scope envelope]
        if {[catch {file lstat $path allocationStat} reason context]} {
            if {$phase ne {cleanup} || ![dict exists $context -errorcode] || [lrange [dict get $context -errorcode] 0 1] ne {POSIX ENOENT}} {error {Original Resource allocation scope is unavailable}}
            # After confirmed Release, only the original cleanup authority may
            # decide already_removed. Absence is not a new deletion grant.
        } elseif {[_resourceManagementPathProof $path directory [dict get $scope uid]] ne [dict get $scope allocation_identity]} {error {Original Resource allocation was replaced}}
    }
    return $scope
}
proc ::GX::_resourceManagementBoundedBootstrap {} {
    return {
import os,sys,time,threading,select,hashlib,stat,traceback
sys.dont_write_bytecode=True
deadline=int(sys.argv[1]);root=sys.argv[2];storage=sys.argv[7];path=sys.argv[10];args=sys.argv[10:]
if not hasattr(time,'CLOCK_BOOTTIME'):os._exit(126)
now=lambda:int(time.clock_gettime(time.CLOCK_BOOTTIME)*1000)
if now()>=deadline:os._exit(124)
class Limited:
    total=0
    def write(self,text):
        raw=text.encode('utf-8','strict')
        if Limited.total+len(raw)>16384:os._exit(125)
        Limited.total+=len(raw)
        while raw:
            n=os.write(1,raw);raw=raw[n:]
        return len(text)
    def flush(self):pass
sys.stdout=sys.stderr=Limited()
fields=open('/proc/self/stat').read(16385).rsplit(')',1)[1].split()
boot=open('/proc/sys/kernel/random/boot_id').read(129).strip()
print('GXTXT_RESOURCE_CHILD_V1',os.getpid(),os.getppid(),boot+':'+fields[19],now(),flush=True)
def watchdog():
    pending=b''
    while True:
        left=deadline-25-now()
        if left<=0:os._exit(124)
        ready,_,_=select.select([0],[],[],min(.01,left/1000))
        if ready:
            data=os.read(0,16)
            if not data:os._exit(124)
            pending+=data
            if pending==b'CANCEL\n':os._exit(124)
            if len(pending)>7 or not b'CANCEL\n'.startswith(pending):os._exit(126)
threading.Thread(target=watchdog,daemon=True).start()
status=0
try:
    # Same captured original physical registry/storage, never a recomputed or
    # replacement root. Original Resource code remains the sole row authority.
    for p,dev,ino,kind in [(root,int(sys.argv[3]),int(sys.argv[4]),'directory'),
            (os.path.join(root,'registry.sqlite3'),int(sys.argv[5]),int(sys.argv[6]),'file'),
            (storage,int(sys.argv[8]),int(sys.argv[9]),'directory')]:
        current='/'
        for part in p.split('/')[1:]:
            current=os.path.join(current,part);s=os.lstat(current)
            if current!=p and not stat.S_ISDIR(s.st_mode):raise ValueError('Original Resource scope alias')
        if (s.st_dev,s.st_ino)!=(dev,ino) or s.st_uid!=os.getuid() or s.st_mode&0o022:raise ValueError('Original Resource scope changed')
        if kind=='directory' and not stat.S_ISDIR(s.st_mode):raise ValueError('Original Resource directory changed')
        if kind=='file' and (not stat.S_ISREG(s.st_mode) or s.st_nlink!=1):raise ValueError('Original Resource registry changed')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or not 0<st.st_size<=1048576:raise ValueError('Original Resource CLI file refused')
        raw=b''
        while len(raw)<=1048576:
            b=os.read(fd,min(65536,1048577-len(raw)))
            if not b:break
            raw+=b
        if len(raw)!=st.st_size or hashlib.sha256(raw).hexdigest()!='b9c27b108142d5bb6a53e128bd1a14edc439be101c40bb77a75e30dd02e0d1f5':raise ValueError('Original Resource CLI source identity changed')
    finally:os.close(fd)
    if now()>=deadline-25:os._exit(124)
    print('GXTXT_RESOURCE_CLI_V1',now(),flush=True)
    sys.argv=args
    exec(compile(raw,path,'exec'),dict(__name__='__main__',__file__=path))
except SystemExit as exc:
    status=exc.code if type(exc.code)is int else (0 if exc.code is None else 1)
except BaseException:
    traceback.print_exc();status=1
os._exit(status if 0<=status<=255 else 1)
}
}
proc ::GX::_resourceManagementBoundedAsync {operation arguments callback {timeoutMs 1000} {scope {}} {admissionDeadline {}}} {
    variable ::GX::ResourceManagement::requests;variable ::GX::ResourceManagement::serial
    # Original Resource CLI uses SQLite timeout=10 seconds PER busy operation. The import
    # may select that allowance plus its original1000ms startup/completion cap.
    # This is a finite private bound, not a guarantee for repeated lock waits.
    if {$operation ni {release cleanup} || ![string is entier -strict $timeoutMs] || $timeoutMs<1 || $timeoutMs>11000} {error {Fixed bounded Resource operation refused}}
    if {$operation eq {release}} {
        if {[llength $arguments]!=4 || [lindex $arguments 0] ne {resource_id} || [lindex $arguments 2] ne {state} || [lindex $arguments 3] ne {verified_orphan}} {error {Fixed original Release arguments required}}
        set id [lindex $arguments 1]
    } else {if {[llength $arguments]!=1} {error {One owned Resource cleanup required}};set id [lindex $arguments 0]}
    if {![regexp {^resource-[a-f0-9]{32}$} $id]} {error {Invalid owned Resource identity}}
    if {$admissionDeadline ne {} && (![string is entier -strict $admissionDeadline] || $admissionDeadline<1)} {error {Invalid original Resource admission deadline}}
    _resourceManagementScopeGuard $scope $id $operation
    set start [_resourceManagementMonotonicMs];set deadline [expr {$start+$timeoutMs}]
    # The repeated ownership proof and process startup consume the SAME original
    # import budget, never a fresh helper allowance beyond that absolute bound.
    if {$admissionDeadline ne {}} {set deadline [expr {min($deadline,$admissionDeadline)}]}
    if {$deadline<=$start} {error {Original Resource admission deadline expired}}
    set base [dict get $scope command]
    if {[lindex $base 1] ne {-B}} {error {Original Resource CLI invocation changed}}
    set command [list [lindex $base 0] -I -B -c [_resourceManagementBoundedBootstrap] $deadline [dict get $scope root] \
        {*}[dict get $scope root_identity] {*}[dict get $scope registry_identity] [dict get $scope storage] {*}[dict get $scope storage_identity] \
        {*}[lrange $base 2 end] $operation {*}$arguments]
    set pipe [open [list | {*}$command 2>@1] r+]
    fconfigure $pipe -blocking 0 -buffering none -encoding binary -translation binary
    set children [pid $pipe];set child [lindex $children 0];set captured [_resourceManagementChildIdentity $child]
    set good [expr {[llength $children]==1 && [dict get $captured identity] ne {} && [dict exists $captured parent] && [dict get $captured parent]==[pid]}]
    set token resource-bounded#[incr serial]
    dict set requests $token [dict create bounded 1 pipe $pipe output {} callback $callback child $child identity [dict get $captured identity] capture_verified $good \
        started_ms $start deadline_ms $deadline admission_deadline_ms $admissionDeadline cap_ms $timeoutMs child_ready_ms {} cli_started_ms {} header 0 cli_header 0 eof 0 notified 0 reason {} timer {} poll {} received_bytes 0 resource_id $id operation $operation]
    # Opening/capturing the helper consumes its same absolute boot-time budget.
    if {[catch {set left [expr {max(0,$deadline-[_resourceManagementMonotonicMs])}]}]} {set left 0;dict set requests $token reason clock_unverified}
    dict set requests $token timer [after $left [list ::GX::_resourceManagementBoundedTimeout $token]]
    fileevent $pipe readable [list ::GX::resourceManagementReadable $token]
    if {!$good} {_resourceManagementBoundedCancel $token identity_unverified}
    return $token
}
proc ::GX::_resourceManagementBoundedCancel {token {reason cancelled}} {
    variable ::GX::ResourceManagement::requests
    if {![dict exists $requests $token] || ![dict exists $requests $token bounded]} return
    if {[dict get $requests $token reason] eq {}} {dict set requests $token reason $reason}
    set pipe [dict get $requests $token pipe]
    # Control targets this already-owned pipe, never a PID/group which can reuse.
    if {$pipe ne {}} {catch {puts -nonewline $pipe "CANCEL\n";flush $pipe}}
}
proc ::GX::_resourceManagementBoundedTimeout {token} {
    if {![dict exists $::GX::ResourceManagement::requests $token]} return
    _resourceManagementBoundedCancel $token timeout
    _resourceManagementBoundedRetire $token 1
}
proc ::GX::_resourceManagementBoundedReadable {token} {
    variable ::GX::ResourceManagement::requests
    if {![dict exists $requests $token]} return
    set entry [dict get $requests $token];set pipe [dict get $entry pipe]
    if {$pipe eq {}} return
    if {[catch {read $pipe 4096} part]} {
        _resourceManagementBoundedCancel $token read_error
        catch {fileevent $pipe readable {}}
    } else {
        dict incr entry received_bytes [string length $part]
        dict append entry output $part
        dict set requests $token $entry
        if {[dict get $requests $token received_bytes]>16384} {
            dict set requests $token output [string range [dict get $requests $token output] 0 16383]
            _resourceManagementBoundedCancel $token output_limit
        }
    }
    set entry [dict get $requests $token]
    if {![dict get $entry header] && [set newline [string first \n [dict get $entry output]]]>=0} {
        set line [string range [dict get $entry output] 0 [expr {$newline-1}]]
        if {![regexp {^GXTXT_RESOURCE_CHILD_V1 ([0-9]+) ([0-9]+) ([a-f0-9-]{36}:[0-9]+) ([0-9]+)$} $line -> headerPid headerParent headerIdentity readyMs] || $headerPid ne [dict get $entry child] || $headerParent ne [pid] || $headerIdentity ne [dict get $entry identity] || ![dict get $entry capture_verified] || $readyMs<[dict get $entry started_ms] || $readyMs>=[dict get $entry deadline_ms]} {
            _resourceManagementBoundedCancel $token identity_unverified
        } else {
            dict set requests $token header 1
            dict set requests $token child_ready_ms $readyMs
            dict set requests $token output [string range [dict get $entry output] [expr {$newline+1}] end]
        }
    }
    set entry [dict get $requests $token]
    if {[dict get $entry header] && ![dict get $entry cli_header] && [set newline [string first \n [dict get $entry output]]]>=0} {
        set line [string range [dict get $entry output] 0 [expr {$newline-1}]]
        if {![regexp {^GXTXT_RESOURCE_CLI_V1 ([0-9]+)$} $line -> cliMs] || $cliMs<[dict get $entry child_ready_ms] || $cliMs>=[dict get $entry deadline_ms]} {
            _resourceManagementBoundedCancel $token cli_unverified
        } else {
            dict set requests $token cli_header 1
            dict set requests $token cli_started_ms $cliMs
            dict set requests $token output [string range [dict get $entry output] [expr {$newline+1}] end]
        }
    }
    if {![catch {eof $pipe} ended] && $ended} {dict set requests $token eof 1;catch {fileevent $pipe readable {}}}
    if {[dict get $requests $token eof] || [dict get $requests $token reason] ne {}} {_resourceManagementBoundedRetire $token}
}
proc ::GX::_resourceManagementBoundedRetire {token {force 0}} {
    variable ::GX::ResourceManagement::requests
    if {![dict exists $requests $token]} return
    set entry [dict get $requests $token]
    set child [_resourceManagementChildIdentity [dict get $entry child]]
    set retired [expr {[dict get $entry capture_verified] && [dict get $child state] eq {dead}}]
    if {[dict get $child identity] ne {} && [dict get $child identity] ne [dict get $entry identity]} {set retired 0;_resourceManagementBoundedCancel $token identity_changed}
    if {[dict get $child state] eq {unknown}} {_resourceManagementBoundedCancel $token identity_unverified}
    set clockVerified 1
    if {[catch {set now [_resourceManagementMonotonicMs]}]} {set clockVerified 0;set force 1;_resourceManagementBoundedCancel $token clock_unverified;set now [dict get $entry deadline_ms]}
    if {$now>=[dict get $entry deadline_ms]} {_resourceManagementBoundedCancel $token timeout}
    if {!$retired && !$force && $now<[dict get $entry deadline_ms]} {
        if {[dict get $entry poll] eq {}} {dict set requests $token poll [after 10 [list ::GX::_resourceManagementBoundedPoll $token]]}
        return
    }
    set entry [dict get $requests $token];set pipe [dict get $entry pipe];set code 1;set closeError {};set closeContext {};set terminal 0
    if {$retired && [dict get $entry eof] && $pipe ne {}} {
        # Positive original identity retirement precedes any blocking close/reap.
        fconfigure $pipe -blocking 1
        set code [catch {close $pipe} closeError closeContext];set pipe {};set terminal 1
    } elseif {$force && $pipe ne {} && [dict get $entry eof]} {catch {close $pipe};set pipe {}}
    set reason [dict get $entry reason];set exitStatus [expr {$code?{}:0}]
    if {[dict exists $closeContext -errorcode] && [lindex [dict get $closeContext -errorcode] 0] eq {CHILDSTATUS}} {
        set exit [lindex [dict get $closeContext -errorcode] 2]
        set exitStatus $exit
        if {$exit==124} {set reason timeout} elseif {$exit==125} {set reason output_limit}
    }
    if {$code && $exitStatus ne {1} && $reason eq {}} {set reason exit_unverified}
    if {!$retired} {if {$reason eq {}} {set reason retirement_unverified};set code 1}
    if {![dict get $entry header]} {if {$reason eq {}} {set reason identity_unverified};set code 1}
    if {![dict get $entry cli_header]} {if {$reason eq {}} {set reason cli_unverified};set code 1}
    if {$reason ne {}} {set code 1}
    if {[catch {set output [string trim [encoding convertfrom utf-8 [dict get $entry output]]]}]} {set output {};set reason invalid_utf8;set code 1}
    if {$code && $output eq {}} {set output [expr {$closeError ne {}?$closeError:$reason}]}
    # The deadline fallback above is ONLY for finite protected drain. It is not
    # an observed clock reading and cannot establish elapsed time or lateness.
    set finishedMs {};set observedMs {};set lateMs {}
    if {$clockVerified} {set finishedMs $now;set observedMs [expr {$now-[dict get $entry started_ms]}];set lateMs [expr {max(0,$now-[dict get $entry deadline_ms])}]}
    set lifecycle [dict create request $token resource_id [dict get $entry resource_id] operation [dict get $entry operation] pid [dict get $entry child] \
        identity [dict get $entry identity] capture_verified [dict get $entry capture_verified] retirement_verified $retired terminal_verified $terminal eof_observed [dict get $entry eof] reason $reason \
        started_ms [dict get $entry started_ms] clock_verified $clockVerified finished_ms $finishedMs deadline_ms [dict get $entry deadline_ms] admission_deadline_ms [dict get $entry admission_deadline_ms] \
        cap_ms [dict get $entry cap_ms] budget_ms [expr {[dict get $entry deadline_ms]-[dict get $entry started_ms]}] child_ready_ms [dict get $entry child_ready_ms] cli_started_ms [dict get $entry cli_started_ms] \
        observed_ms $observedMs observation_late_ms $lateMs \
        output_bytes [dict get $entry received_bytes] exit_status $exitStatus protected [expr {$code!=0 && ($reason ne {} || !$retired)}]]
    foreach key {timer poll} {if {[dict get $entry $key] ne {}} {after cancel [dict get $entry $key]}}
    set notify [expr {![dict get $entry notified]}]
    if {$retired && $pipe eq {} && $notify} {dict unset requests $token} else {
        dict set entry pipe $pipe;dict set entry notified 1;dict set entry timer {};dict set entry poll {};dict set entry lifecycle $lifecycle
        dict set requests $token $entry
    }
    if {$notify && [dict get $entry callback] ne {}} {uplevel #0 [list {*}[dict get $entry callback] $code $output $lifecycle]}
}
proc ::GX::_resourceManagementBoundedPoll {token} {
    if {![dict exists $::GX::ResourceManagement::requests $token]} return
    dict set ::GX::ResourceManagement::requests $token poll {}
    _resourceManagementBoundedRetire $token
}
