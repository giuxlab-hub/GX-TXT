# SPDX-License-Identifier: GPL-3.0-or-later
# Fixed quantitative I/O adapter; Script Job owns this managed auxiliary process.
lassign $argv quantitativeFramework
set quantitativeEnvelope [read stdin]
set argv0 __quantitative_managed_request__
# The fixed adapter only reads scientific owners. Its normal request-preparer
# and computational Job inherit this restricted access, while the GUI keeps
# the existing exclusive writer and live accepted state.
set ::env(GXTXT_NATIVE_WORKSPACE_ACCESS) read_only
source [file join $quantitativeFramework gxtxt_pipeline.tcl]
set quantitativeCreatedJob {}
try {
    ::GX::_nativeCanvasFields $quantitativeEnvelope {session origin document_id canvas_id canvas_instance owner_pid operation arguments} {session origin document_id canvas_id canvas_instance owner_pid operation arguments}
    ::GX::defaults
    ::GX::loadModuleCatalog
    set quantitativeSession [dict get $quantitativeEnvelope session]
    set ::GX::currentSession $quantitativeSession
    ::GX::loadManifest [file join $quantitativeSession metadata manifest.ini]
    set ::GX::currentSession $quantitativeSession
    ::GX::loadDatasetRegistry $quantitativeSession
    if {[::GX::sessionOriginRead $quantitativeSession] ne [dict get $quantitativeEnvelope origin]} {::GX::_quantitativeError OWNER {Session origin changed during quantitative admission}}
    set quantitativeDocument [dict get $quantitativeEnvelope document_id]
    set quantitativeOperation [dict get $quantitativeEnvelope operation]
    set quantitativeArguments [dict get $quantitativeEnvelope arguments]
    if {$quantitativeOperation eq {source_info}} {
        ::GX::_nativeCanvasFields $quantitativeArguments {dataset_id resource} {dataset_id resource}
        set quantitativeResource [dict get $quantitativeArguments resource]
        ::GX::interactiveDocumentResourceInfo $quantitativeResource
        if {[dict get $quantitativeResource document_id] ne $quantitativeDocument} {::GX::_quantitativeError OWNER {Original image belongs to another Document}}
        set quantitativeResult [::GX::quantitativeRasterSourceInfo [dict get $quantitativeArguments dataset_id]]
        if {[dict get $quantitativeResource sha256] ne [dict get $quantitativeResult source_sha256]} {::GX::_quantitativeError STALE_SOURCE {Original image binding differs from canonical source SHA}}
    } elseif {$quantitativeOperation eq {submit}} {
        if {[llength $quantitativeArguments]!=7} {error {Invalid managed quantitative submit arguments}}
        lassign $quantitativeArguments quantitativeDataset quantitativeSha quantitativeRevision quantitativeResource quantitativeParameters quantitativeGuard quantitativeExpectedReceipt
        if {[dict get $quantitativeGuard canvas_id] ne [dict get $quantitativeEnvelope canvas_id]} {::GX::_quantitativeError OWNER {Quantitative admission belongs to another logical Canvas}}
        set quantitativeCurrent [::GX::interactiveDocumentMetadata $quantitativeDocument]
        foreach key {generation revision sha256} {if {[dict get $quantitativeCurrent $key] ne [dict get $quantitativeExpectedReceipt $key]} {::GX::_quantitativeError STALE_ROI {Canvas Document changed during quantitative admission}}}
        set quantitativeOwner [::GX::_quantitativeProposedOwner $quantitativeEnvelope]
        dict set quantitativeGuard canvas_instance [dict get $quantitativeOwner instance]
        dict set quantitativeGuard owner_pid [dict get $quantitativeOwner pid]
        dict set quantitativeGuard owner_process [dict get $quantitativeOwner process]
        set quantitativeSubmission [::GX::quantitativeRasterSubmit $quantitativeDocument $quantitativeDataset $quantitativeSha $quantitativeRevision $quantitativeResource $quantitativeParameters $quantitativeGuard]
        set quantitativeCreatedJob [dict get $quantitativeSubmission job_id]
        ::GX::scriptJobCall client_owner_claim $quantitativeCreatedJob null [::GX::_quantitativeOwnerJson $quantitativeOwner]
        set quantitativeResult [dict create value [::GX::_quantitativeRecord {record {job_id text state text}} $quantitativeSubmission] job_id $quantitativeCreatedJob state [dict get $quantitativeSubmission state] guard $quantitativeGuard]
    } elseif {$quantitativeOperation eq {cancel_admission}} {
        ::GX::_nativeCanvasFields $quantitativeArguments {admission_id} admission_id
        set quantitativeView [::GX::scriptJobViewDefault]
        dict set quantitativeView scope [file normalize $quantitativeSession]
        dict set quantitativeView filter Active
        dict set quantitativeView show_hidden 1
        set quantitativeSnapshot [::GX::scriptJobViewList $quantitativeView]
        set quantitativeCancelled {}
        # The existing owner returns all active lifecycle identities separately
        # from its paged presentation rows. No new Job index is maintained.
        foreach quantitativeEntry [dict get $quantitativeSnapshot lifecycle] {
            if {[dict get $quantitativeEntry session] ne [file normalize $quantitativeSession]} continue
            set quantitativeId [dict get $quantitativeEntry id]
            if {[catch {set quantitativeRow [::GX::_quantitativeJob $quantitativeId 0]}]} continue
            set quantitativeGuard [dict get $quantitativeRow scientific_request parameters request_guard]
            if {![dict exists $quantitativeGuard admission_id] || [dict get $quantitativeGuard admission_id] ne [dict get $quantitativeArguments admission_id]} continue
            if {[dict get $quantitativeGuard document_id] ne $quantitativeDocument || [dict get $quantitativeGuard canvas_id] ne [dict get $quantitativeEnvelope canvas_id]} {::GX::_quantitativeError OWNER {Admission cleanup has a foreign Canvas owner}}
            ::GX::scriptJobCancel $quantitativeId
            lappend quantitativeCancelled $quantitativeId
        }
        set quantitativeResult [dict create cancelled_jobs $quantitativeCancelled]
    } else {
        if {$quantitativeOperation ni {status cancel result histogram_page reconnect claim_owner}} {error {Unknown managed quantitative operation}}
        set quantitativeJob [dict get $quantitativeArguments job_id]
        set quantitativeJobRow [::GX::_quantitativeJob $quantitativeJob 0]
        set quantitativeGuard [dict get $quantitativeJobRow scientific_request parameters request_guard]
        if {![dict exists $quantitativeGuard document_id] || [dict get $quantitativeGuard document_id] ne $quantitativeDocument || ![dict exists $quantitativeGuard canvas_id] || [dict get $quantitativeGuard canvas_id] ne [dict get $quantitativeEnvelope canvas_id]} {::GX::_quantitativeError OWNER {Quantitative Job belongs to another logical Canvas}}
        set quantitativeExpectedOwner [::GX::datasetPublicationV2DictDefault $quantitativeJobRow client_owner {}]
        set quantitativeOwner $quantitativeExpectedOwner
        if {$quantitativeOwner eq {}} {set quantitativeOwner [dict create pid [dict get $quantitativeGuard owner_pid] process [dict get $quantitativeGuard owner_process] instance [dict get $quantitativeGuard canvas_instance]]}
        set quantitativeProposed [::GX::_quantitativeProposedOwner $quantitativeEnvelope]
        if {$quantitativeOperation ni {reconnect claim_owner}} {
            foreach quantitativeKey {pid process instance} {
                if {[dict get $quantitativeOwner $quantitativeKey] ne [dict get $quantitativeProposed $quantitativeKey]} {::GX::_quantitativeError OWNER {Quantitative Job belongs to another Canvas view; reconnect after its owner closes}}
            }
        }
        if {$quantitativeOperation eq {claim_owner}} {
            ::GX::_quantitativeJob $quantitativeJob
            set quantitativeClaim [::GX::scriptJobCall client_owner_claim $quantitativeJob [::GX::_quantitativeOwnerJson [dict get $quantitativeArguments expected_owner]] [::GX::_quantitativeOwnerJson $quantitativeProposed]]
            set quantitativeOwner [dict get $quantitativeClaim client_owner]
        }
        switch -- $quantitativeOperation {
            status - reconnect - claim_owner {set quantitativeStatus [::GX::quantitativeRasterStatus $quantitativeJob]}
            cancel {set quantitativeStatus [::GX::quantitativeRasterCancel $quantitativeJob]}
            result {set quantitativeValue [::GX::quantitativeRasterResult $quantitativeJob]}
            histogram_page {set quantitativeValue [::GX::quantitativeRasterHistogramPage $quantitativeJob [dict get $quantitativeArguments token] [dict get $quantitativeArguments generation] [dict get $quantitativeArguments offset] [dict get $quantitativeArguments count]]}
        }
        if {$quantitativeOperation in {status cancel reconnect claim_owner}} {set quantitativeValue [::GX::_quantitativeRecord {record {job_id text state text source_current bool diagnostic text progress_stage text progress_percent real}} $quantitativeStatus]}
        set quantitativeResult [dict create value $quantitativeValue job_id $quantitativeJob state [dict get $quantitativeJobRow state] guard $quantitativeGuard]
        if {$quantitativeOperation in {status cancel reconnect claim_owner}} {dict set quantitativeResult state [dict get $quantitativeStatus state]}
        if {$quantitativeOperation eq {reconnect}} {
            dict set quantitativeResult owner $quantitativeOwner
            dict set quantitativeResult expected_owner $quantitativeExpectedOwner
            dict set quantitativeResult owner_alive [expr {[::GX::scriptJobCall process_identity [dict get $quantitativeOwner pid]] eq [dict get $quantitativeOwner process]}]
        }
    }
    puts [dict create ok 1 result $quantitativeResult]
    flush stdout
    exit 0
} on error {message options} {
    # A failed reply after admission must not leave this adapter's new Job active.
    if {$quantitativeCreatedJob ne {}} {catch {::GX::scriptJobCancel $quantitativeCreatedJob}}
    catch {puts [dict create ok 0 error $message code [dict get $options -errorcode]];flush stdout}
    exit 1
}
