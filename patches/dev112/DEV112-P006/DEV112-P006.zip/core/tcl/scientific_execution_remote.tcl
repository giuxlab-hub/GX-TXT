# SPDX-License-Identifier: GPL-3.0-or-later
# Remote dispatch is a Configuration-backed reference, never another executor.
namespace eval ::GX::ScientificExecution {variable remoteMetrics {};variable remotePrepared {};variable remoteSerial 0;variable remoteListeners {}}
proc ::GX::scientificExecutionNodesInit {} {
    foreach {id label default} {execution.nodes {Compute nodes} {} execution.destination {Execution destination} local} {
        if {![dict exists [configurationFields] $id]} {configurationRegister $id [dict create group Execution label $label type string default $default scope user]}
    }
}
proc ::GX::scientificExecutionNodeRegister {id descriptor} {
    scientificExecutionNodesInit
    if {![regexp {^[A-Za-z][A-Za-z0-9_.-]*$} $id]} {error {Invalid compute node ID}}
    foreach field {endpoint ca_file client_cert client_key session_id} {if {![dict exists $descriptor $field] || [dict get $descriptor $field] eq {}} {error "Compute node requires '$field'"}}
    if {![regexp {^https://[^/@?#[:space:]]+(/[^?#[:space:]]*)?$} [dict get $descriptor endpoint]]} {error {Compute nodes require authenticated HTTPS}}
    if {![regexp {^[A-Za-z0-9_.-]+$} [dict get $descriptor session_id]]} {error {Invalid logical remote Session ID}}
    dict set descriptor node_id $id
    if {![dict exists $descriptor enabled]} {dict set descriptor enabled 1}
    set nodes [configurationGet execution.nodes];dict set nodes $id $descriptor
    configurationSet execution.nodes $nodes;configurationSave
    return $id
}
proc ::GX::scientificExecutionNodes {} {scientificExecutionNodesInit;return [configurationGet execution.nodes]}
proc ::GX::scientificExecutionNodeList {} {
    set result {}
    dict for {id node} [scientificExecutionNodes] {lappend result [dict create node_id $id endpoint [dict get $node endpoint] session_id [dict get $node session_id] enabled [dict get $node enabled]]}
    return $result
}
proc ::GX::scientificExecutionDestination {{destination {}}} {
    scientificExecutionNodesInit
    if {$destination ne {}} {
        if {$destination ni {local auto} && ![dict exists [scientificExecutionNodes] $destination]} {error {Unknown execution destination}}
        configurationSet execution.destination $destination;configurationSave
    }
    return [configurationGet execution.destination]
}
proc ::GX::_scientificExecutionRemoteRequest {node session operation args} {
    set nodes [scientificExecutionNodes]
    if {![dict exists $nodes $node] || ![dict get $nodes $node enabled]} {error {Compute node is unknown or disabled}}
    set request [dict create node [dict get $nodes $node] session_id $session operation $operation arguments $args]
    if {$operation eq "scientific.submit"} {dict set request nonce [lindex $args 1];dict set request arguments [list [lindex $args 0]]}
    if {$operation eq "resource.append"} {dict set request payload_base64 [lindex $args 2];dict set request arguments [lrange $args 0 1]}
    if {$operation eq "dataset.preview"} {dict set request artifact_directory [lindex $args 3];dict set request arguments [lrange $args 0 2]}
    return $request
}
proc ::GX::_scientificExecutionRemoteCommand {} {
    return [list [runtimeToolResolve python] -B [file join $::GX::scriptDir core python gxtxt_remote_transport.py]]
}
proc ::GX::scientificExecutionRemoteCall {node session operation args} {
    variable ::GX::ScientificExecution::remoteMetrics
    set request [_scientificExecutionRemoteRequest $node $session $operation {*}$args]
    set command [_scientificExecutionRemoteCommand]
    if {[catch {exec {*}$command << $request} response] || [catch {dict get $response ok} ok]} {return -code error -errorcode {GX REMOTE UNAVAILABLE} {Compute node transport is unavailable}}
    if {!$ok} {return -code error -errorcode [dict get $response error_code] [dict get $response error]}
    set remoteMetrics [dict get $response metrics]
    return [dict get $response result]
}
# The same authenticated transport, managed by the existing auxiliary request
# owner. Cancelling this client request never cancels the durable remote Job.
proc ::GX::scientificExecutionRemoteCallAsync {node session operation arguments callback} {
    set request [_scientificExecutionRemoteRequest $node $session $operation {*}$arguments]
    return [scriptJobAsync [_scientificExecutionRemoteCommand] $request \
        [list ::GX::_scientificExecutionRemoteAsyncReady $callback] \
        {timeout_ms 20000 max_bytes 67108864 ui_lifetime 1 label {Compute node request}}]
}
proc ::GX::_scientificExecutionRemoteAsyncReady {callback response} {
    if {[dict get $response ok] && [dict exists $response metrics]} {
        set ::GX::ScientificExecution::remoteMetrics [dict get $response metrics]
    }
    if {$callback ne {}} {uplevel #0 [list {*}$callback $response]}
}
proc ::GX::_scientificExecutionRemoteHostContracts {} {
    set parameters {}
    foreach {name type description} {
        node NodeID {Existing enabled Execution Configuration node ID; no implicit fallback.}
        session RemoteSessionID {Exact logical remote Session identity from the original receipt.}
        operation RemoteOperation {An operation already implemented by the authenticated compute-node protocol.}
        arguments ArgumentList {One inert Tcl list of operation arguments, not executable source or variadic parameters.}
        callback CommandPrefix {Prefix receiving the existing ok/result/metrics or ok/error response dictionary.}
    } {dict set parameters $name [dict create type $type description $description]}
    return [dict create scientificExecutionRemoteCallAsync [dict create \
        command ::GX::scientificExecutionRemoteCallAsync \
        arguments {node session operation arguments callback} parameters $parameters \
        result [dict create type AuxiliaryRequestID description {Existing Script Job client token, bounded to 20 seconds and 64 MiB. Node validation or startup errors raise before a token exists. Cancelling the client does not cancel the durable Job.}] \
        context {Trusted Tcl host only. Uses existing configured authenticated transport. No Script Bridge or C++ SDK grant is implied.}]]
}
proc ::GX::scientificExecutionNodeInspect {node} {
    set nodes [scientificExecutionNodes]
    if {![dict exists $nodes $node]} {error {Unknown compute node}}
    return [scientificExecutionRemoteCall $node [dict get $nodes $node session_id] capabilities]
}
proc ::GX::scientificExecutionRemoteId {id} {return [regexp {^remote/([A-Za-z][A-Za-z0-9_.-]*)/([A-Za-z0-9_.-]+)/([^/]+)$} $id]}
proc ::GX::_scientificRemoteRoute {id} {
    if {![regexp {^remote/([A-Za-z][A-Za-z0-9_.-]*)/([A-Za-z0-9_.-]+)/([^/]+)$} $id -> node session job]} {error {Invalid remote Job identity}}
    return [list $node $session $job]
}
proc ::GX::_scientificExecutionRemoteStatusRoute {id status} {
    lassign [_scientificRemoteRoute $id] node session job
    # Status is node-local. Correlate the authenticated reply before adding the
    # host-selected route required by the retained native build-pair guard.
    if {![dict exists $status job_id] || [dict get $status job_id] ne $job} {error {Remote status Job identity changed}}
    foreach {field expected} [list node_id $node remote_session_id $session] {
        if {[dict exists $status $field] && [dict get $status $field] ne $expected} {error {Remote status route identity changed}}
    }
    dict set status job_id $id;dict set status node_id $node;dict set status remote_session_id $session
    return $status
}
proc ::GX::scientificExecutionRemoteJob {id operation args} {
    lassign [_scientificRemoteRoute $id] node session job
    if {$operation ne {status}} {
        set status [_scientificExecutionRemoteStatusRoute $id [scientificExecutionRemoteCall $node $session scientific.status $job]]
        _scientificExecutionRemoteNativeOriginGuard $status
    }
    set result [scientificExecutionRemoteCall $node $session scientific.$operation $job {*}$args]
    if {$operation in {status cancel}} {
        set result [_scientificExecutionRemoteStatusRoute $id $result]
        _scientificExecutionRemoteNativeOriginGuard $result
    }
    return $result
}
proc ::GX::scientificExecutionRemoteJobRecord {id operation args} {
    lassign [_scientificRemoteRoute $id] node session job
    set description [scientificExecutionRemoteCall $node $session job.describe $job]
    if {![dict exists $description id] || [dict get $description id] ne $job} {error {Remote Job record identity changed}}
    if {[datasetPublicationV2DictDefault $description reference {}] in {session:gx-core-scientific-execution core-service:scientific-provider}} {
        _scientificExecutionRemoteNativeOriginGuard [_scientificExecutionRemoteStatusRoute $id [scientificExecutionRemoteCall $node $session scientific.status $job]]
    }
    if {$operation eq {describe}} {set result $description} else {set result [scientificExecutionRemoteCall $node $session job.$operation $job {*}$args]}
    if {$operation eq "describe"} {dict set result id $id;dict set result backend remote;dict set result node_id $node;dict set result remote_session_id $session}
    return $result
}
# Script Bridge exposure: HOST_ONLY_JUSTIFIED. Exact helper operations
# scientificExecutionRemoteNativeDescribe, scientificExecutionRemoteNativePrepare
# and scientificExecutionRemoteNativeResult bind a configured authenticated node
# and host-local source lifetime. They are internal routing adapters; the public
# nativeJobDescribe/Prepare/Result operations remain the shared script-safe API.
# Direct exposure would grant node configuration routing rather than a Viewer
# entrypoint/Job reference and bypass the caller's native owner adapter.
proc ::GX::_scientificExecutionNativeIdentity {descriptor} {
    set result {}
    foreach key {module_id entrypoint artifact_sha256 source_sha256 abi dependencies runtime_dependencies} {
        if {![dict exists $descriptor $key]} {error {Native remote identity is incomplete}}
        set value [dict get $descriptor $key]
        if {$key in {abi dependencies runtime_dependencies}} {
            set sorted {};foreach name [lsort [dict keys $value]] {dict set sorted $name [dict get $value $name]}
            set value $sorted
        }
        dict set result $key $value
    }
    return $result
}
# Script Bridge exposure: HOST_ONLY_JUSTIFIED. Fixed installed-source metadata
# projection binds normal native project parameters/selected sources to the
# owning client/target build; scripts cannot select a module root or executable.
proc ::GX::_scientificExecutionNativeBuildMetadata {module entrypoint} {
    set descriptor [moduleField $module descriptor {}]
    if {$descriptor eq {} || ![file isfile $descriptor]} {error {Native build requires an installed module}}
    set root [file normalize [file dirname $descriptor]]
    set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_compute_node.py] --native-build-metadata $root $module $entrypoint]
    if {[catch {exec {*}$command} response] || ![dict get $response ok]} {
        if {![catch {dict get $response error} message]} {error $message}
        error {Installed native build metadata is unavailable}
    }
    return [dict get $response result]
}
proc ::GX::_scientificExecutionNativeParameterIdentity {parameters} {
    set result {}
    foreach name [lsort [dict keys $parameters]] {
        set schema {};foreach key [lsort [dict keys [dict get $parameters $name]]] {dict set schema $key [dict get $parameters $name $key]}
        dict set result $name $schema
    }
    return $result
}
proc ::GX::_scientificExecutionNativeBuildIdentity {module entrypoint descriptor} {
    set identity [_scientificExecutionNativeIdentity $descriptor]
    if {[dict get $identity module_id] ne $module || [dict get $identity entrypoint] ne $entrypoint} {error {Native build module/entrypoint identity mismatch}}
    set metadata [_scientificExecutionNativeBuildMetadata $module $entrypoint]
    if {[_scientificExecutionNativeParameterIdentity [dict get $descriptor parameters]] ne [_scientificExecutionNativeParameterIdentity [dict get $metadata parameters]]} {error {Native descriptor parameter schema differs from its installed source project}}
    foreach field {project_source_sha256 build_contract_sha256} {
        if {![regexp {^[0-9a-f]{64}$} [dict get $metadata $field]]} {error {Native build metadata SHA is invalid}}
        dict set identity $field [dict get $metadata $field]
    }
    return $identity
}
proc ::GX::_scientificExecutionNativeBuildProjection {descriptor} {
    if {[lsort [dict keys $descriptor]] ne {abi artifact_sha256 build_contract_sha256 dependencies entrypoint module_id project_source_sha256 runtime_dependencies source_sha256}} {error {Native build identity requires exact fields}}
    set identity [_scientificExecutionNativeIdentity $descriptor]
    foreach field {project_source_sha256 build_contract_sha256} {
        if {![regexp {^[0-9a-f]{64}$} [dict get $descriptor $field]]} {error {Native build metadata SHA is invalid}}
        dict set identity $field [dict get $descriptor $field]
    }
    return $identity
}
proc ::GX::_scientificExecutionNativeBuildCompatible {client target} {
    set client [_scientificExecutionNativeBuildProjection $client]
    set target [_scientificExecutionNativeBuildProjection $target]
    foreach field {module_id entrypoint artifact_sha256 source_sha256 project_source_sha256 build_contract_sha256 abi dependencies} {
        if {![dict exists $client $field] || ![dict exists $target $field] || [dict get $client $field] ne [dict get $target $field]} {error "Native paired build $field contract mismatch"}
    }
}
proc ::GX::_scientificExecutionRemoteSessionFingerprint {} {
    set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_remote_transport.py] --session-identity]
    _interactiveDocumentRequireSession
    # Preserve raw spelling until the identity primitive can reject symlinks;
    # file normalize would otherwise erase alias evidence before admission.
    set request [dict create session $::GX::currentSession]
    if {[catch {exec {*}$command << $request} response] || ![dict get $response ok]} {error {Native remote Session identity is unavailable}}
    return [dict get $response result]
}
proc ::GX::_scientificExecutionRemoteClientOrigin {module entrypoint document datasets} {
    set identities {}
    if {$document ne {}} {
        set workspace {}
        foreach field {id generation revision sha256} {
            if {![dict exists $document $field]} {error {Native remote source Document identity is incomplete}}
            dict set workspace $field [dict get $document $field]
        }
        dict set identities workspace $workspace
    }
    if {$datasets ne {}} {dict set identities datasets $datasets}
    return [dict create schema gxtxt.native_client_origin.v1 module_id $module entrypoint $entrypoint session_origin [sessionOriginRead [_interactiveDocumentRequireSession]] session_fingerprint [_scientificExecutionRemoteSessionFingerprint] source_identities $identities]
}
proc ::GX::_scientificExecutionRemoteClientOriginCurrent {origin {module {}}} {
    if {[catch {dict size $origin}] || [lsort [dict keys $origin]] ne {entrypoint module_id schema session_fingerprint session_origin source_identities} || [dict get $origin schema] ne {gxtxt.native_client_origin.v1}} {error {Native remote Job lacks durable client origin; readmit from its originating Session}}
    if {$module ne {} && [dict get $origin module_id] ne $module} {error {Native remote Job belongs to another Viewer}}
    if {[dict get $origin session_origin] ne [sessionOriginRead [_interactiveDocumentRequireSession]] || [dict get $origin session_fingerprint] ne [_scientificExecutionRemoteSessionFingerprint]} {error {Native remote Job belongs to a different local Session; explicit readmission required}}
    set identities [dict get $origin source_identities]
    if {[lsort [dict keys $identities]] ni {{} datasets workspace {datasets workspace}}} {error {Invalid native remote source identity scope}}
    _scientificExecutionSourcesCurrent $identities
    return 1
}
proc ::GX::_scientificExecutionRemoteNativeOriginGuard {status {module {}}} {
    if {![string match native.* [datasetPublicationV2DictDefault $status provider_id {}]]} {return 1}
    if {![dict exists $status native_owner client_origin]} {error {Native remote Job lacks durable client origin; explicit readmission required}}
    set origin [dict get $status native_owner client_origin]
    _scientificExecutionRemoteClientOriginCurrent $origin $module
    set current [nativeJobDescribe [dict get $origin module_id] [dict get $origin entrypoint]]
    if {[dict exists $status native_owner remote_build]} {
        set pair [dict get $status native_owner remote_build]
        if {[lsort [dict keys $pair]] ne {client_identity node_id schema target_identity} || [dict get $pair schema] ne {gxtxt.native_remote_build.v1} || ![dict exists $status node_id] || [dict get $pair node_id] ne [dict get $status node_id]} {error {Native remote build pair/node identity changed}}
        set client [dict get $pair client_identity];set target [dict get $pair target_identity]
        _scientificExecutionNativeBuildCompatible $client $target
        if {[_scientificExecutionNativeBuildIdentity [dict get $origin module_id] [dict get $origin entrypoint] $current] ne [_scientificExecutionNativeBuildProjection $client]} {error {Native local client build changed; explicit readmission required}}
        foreach field {artifact_sha256 source_sha256} {
            if {![dict exists $status source_identities native_artifact $field] || [dict get $target $field] ne [dict get $status source_identities native_artifact $field]} {error {Native remote target build/result identity changed}}
        }
        return 1
    }
    foreach field {artifact_sha256 source_sha256} {
        if {![dict exists $status source_identities native_artifact $field] || [dict get $current $field] ne [dict get $status source_identities native_artifact $field]} {error {Native local Viewer source/artifact changed since remote admission; explicit readmission required}}
    }
    return 1
}
proc ::GX::scientificExecutionRemoteNativeDescribe {node module entrypoint} {
    set nodes [scientificExecutionNodes]
    if {![dict exists $nodes $node]} {error {Unknown compute node}}
    return [scientificExecutionRemoteCall $node [dict get $nodes $node session_id] native.describe $module $entrypoint]
}
proc ::GX::scientificExecutionRemoteNativePrepare {node module entrypoint identity parameters options {resources {}}} {
    if {[lsort [dict keys $identity]] eq {abi artifact_sha256 dependencies entrypoint module_id runtime_dependencies source_sha256}} {
        # Explicit legacy Host input retains exact7 behavior. Normal public
        # nativeJobPrepare supplies its complete verified descriptor and takes
        # the build-pair path; a failed build.v1 request never falls back here.
        set identity [_scientificExecutionNativeIdentity $identity]
    } else {
        set identity [_scientificExecutionNativeBuildIdentity $module $entrypoint $identity]
    }
    if {[dict get $identity module_id] ne $module || [dict get $identity entrypoint] ne $entrypoint} {error {Native remote module/entrypoint identity mismatch}}
    return [scientificExecutionRemotePrepare $node native.$module.$entrypoint $parameters $resources $options $identity]
}
proc ::GX::scientificExecutionRemoteNativeResult {id module} {
    lassign [_scientificRemoteRoute $id] node session job
    _scientificExecutionRemoteNativeOriginGuard [scientificExecutionRemoteJob $id status] $module
    set result [scientificExecutionRemoteCall $node $session native.result $job $module]
    dict set result job_id $id;dict set result node_id $node;dict set result remote_session_id $session
    return $result
}
# Script Bridge exposure: HOST_ONLY_JUSTIFIED, exact helper
# _scientificExecutionRemoteClientOwnerClaim. Only an owning GUI can attest
# client process/window liveness; serializable worker scripts cannot assert a
# Host lifetime. Existing native/source guards and Supervisor CAS still own the
# authorization/journal. This helper grants no scientific operation or queue.
proc ::GX::_scientificExecutionRemoteClientOwnerClaim {id module expected proposed} {
    lassign [_scientificRemoteRoute $id] node session job
    set status [scientificExecutionRemoteJob $id status]
    if {![string match native.* [dict get $status provider_id]]} {error {Remote Viewer ownership requires an admitted native Job}}
    _scientificExecutionRemoteNativeOriginGuard $status $module
    return [scientificExecutionRemoteCall $node $session native.client_owner_claim $job $module $expected $proposed]
}
proc ::GX::scientificExecutionRemotePrepare {node provider parameters resources options {nativeIdentity {}}} {
    variable ::GX::ScientificExecution::remotePrepared;variable ::GX::ScientificExecution::remoteSerial
    set nodes [scientificExecutionNodes];set descriptor [dict get $nodes $node]
    set session [datasetPublicationV2DictDefault $options remote_session_id [dict get $descriptor session_id]]
    set localDocument {}
    if {[dict exists $options document_id]} {
        set localDocument [dict remove [interactiveDocumentRead [dict get $options document_id]] payload]
        foreach {option field} {expected_revision revision expected_generation generation expected_sha256 sha256} {
            if {[dict exists $options $option] && [dict get $options $option] ne [dict get $localDocument $field]} {error {Scientific Workspace generation, revision or source SHA changed}}
        }
    }
    set options [dict remove $options node_id remote_session_id backend document_id expected_revision expected_generation expected_sha256]
    set localDatasets {}
    set nativeTargetIdentity {}
    if {$nativeIdentity ne {}} {
        foreach id [datasetPublicationV2DictDefault $options dataset_sources {}] {dict set localDatasets $id [datasetRevisionToken $id [_interactiveDocumentRequireSession]]}
        set options [dict remove $options dataset_sources]
        dict set options client_origin [_scientificExecutionRemoteClientOrigin [dict get $nativeIdentity module_id] [dict get $nativeIdentity entrypoint] $localDocument $localDatasets]
        if {[dict exists $nativeIdentity project_source_sha256]} {
            set nativeTargetIdentity [scientificExecutionRemoteCall $node $session native.describe [dict get $nativeIdentity module_id] [dict get $nativeIdentity entrypoint] build.v1]
            # Compare canonical ABI order, preserving strict equality of every
            # field while allowing independently verified target runtime hashes.
            set canonical [_scientificExecutionNativeIdentity $nativeTargetIdentity]
            foreach field {project_source_sha256 build_contract_sha256} {dict set canonical $field [dict get $nativeTargetIdentity $field]}
            set nativeTargetIdentity $canonical
            _scientificExecutionNativeBuildCompatible $nativeIdentity $nativeTargetIdentity
            dict set options client_identity $nativeIdentity
        }
    }
    set staged {}
    dict for {alias reference} $resources {dict set staged $alias [scientificExecutionStageResource $node $session $reference]}
    if {$nativeIdentity eq {}} {
        set token [scientificExecutionRemoteCall $node $session scientific.prepare $provider $parameters $staged $options]
    } else {
        set expected [expr {$nativeTargetIdentity eq {} ? $nativeIdentity : $nativeTargetIdentity}]
        set token [scientificExecutionRemoteCall $node $session native.prepare [dict get $nativeIdentity module_id] [dict get $nativeIdentity entrypoint] $expected $parameters $options $staged]
    }
    set handle remote-prepare#[pid]-[incr remoteSerial]
    set nonce [format %s-%s-%s [installationIdentityCurrent] [pid] [clock clicks]]
    dict set remotePrepared $handle [dict create node $node session $session token $token nonce $nonce provider_id $provider resources $resources local_document $localDocument local_datasets $localDatasets native_identity $nativeIdentity native_target_identity $nativeTargetIdentity client_origin [datasetPublicationV2DictDefault $options client_origin {}] session_token [interactiveDocumentSessionToken]]
    return $handle
}
proc ::GX::_scientificExecutionRemoteAccepted {token response} {
    if {![dict get $response ok]} {return $response}
    if {![dict exists $::GX::ScientificExecution::remotePrepared $token]} {return [dict create ok 0 error {Remote preparation was discarded during admission; recover the original nonce before retrying}]}
    set p [dict get $::GX::ScientificExecution::remotePrepared $token]
    set result [dict get $response result]
    if {![dict exists $result job_id] || [dict get $result job_id] eq {}} {return [dict create ok 0 error {Remote admission returned no authoritative Job ID}]}
    dict set result job_id remote/[dict get $p node]/[dict get $p session]/[dict get $result job_id]
    dict set result backend remote;dict set result node_id [dict get $p node]
    dict set result remote_session_id [dict get $p session]
    dict set ::GX::ScientificExecution::remotePrepared $token receipt $result
    return [dict replace $response result $result]
}
proc ::GX::_scientificExecutionRemoteSubmitReady {token callback response} {
    uplevel #0 [list {*}$callback [_scientificExecutionRemoteAccepted $token $response]]
}
proc ::GX::scientificExecutionRemoteSubmit {token {callback {}}} {
    variable ::GX::ScientificExecution::remotePrepared
    if {![dict exists $remotePrepared $token]} {error {Unknown remote preparation}}
    set p [dict get $remotePrepared $token]
    if {[dict get $p session_token] ne [interactiveDocumentSessionToken]} {error {Remote preparation belongs to a previous Session lifetime}}
    if {[dict get $p local_document] ne {}} {
        set previous [dict get $p local_document];set current [interactiveDocumentRead [dict get $previous id]]
        if {[dict get $previous revision] ne [dict get $current revision] || [dict get $previous sha256] ne [dict get $current sha256]} {error {Scientific Workspace changed after preparation}}
    }
    dict for {alias reference} [dict get $p resources] {interactiveDocumentResourceInfo $reference}
    dict for {id revision} [datasetPublicationV2DictDefault $p local_datasets {}] {
        if {[datasetRevisionToken $id [_interactiveDocumentRequireSession]] ne $revision} {error {Native remote Dataset source changed after preparation}}
    }
    set identity [datasetPublicationV2DictDefault $p native_identity {}]
    if {$identity ne {}} {_scientificExecutionRemoteClientOriginCurrent [dict get $p client_origin] [dict get $identity module_id]}
    if {$identity ne {}} {
        set current [nativeJobDescribe [dict get $identity module_id] [dict get $identity entrypoint]]
        if {[dict exists $identity project_source_sha256]} {set current [_scientificExecutionNativeBuildIdentity [dict get $identity module_id] [dict get $identity entrypoint] $current]} else {set current [_scientificExecutionNativeIdentity $current]}
        set expected $identity
        if {[dict exists $identity project_source_sha256]} {set expected [_scientificExecutionNativeBuildProjection $identity]}
        if {$current ne $expected} {error {Native local artifact/source identity changed after remote preparation}}
    }
    if {$callback ne {}} {
        set request [scientificExecutionRemoteCallAsync [dict get $p node] [dict get $p session] scientific.submit [list [dict get $p token] [dict get $p nonce]] [list ::GX::_scientificExecutionRemoteSubmitReady $token $callback]]
        return [dict create submission_id $request state PENDING node_id [dict get $p node]]
    }
    set result [scientificExecutionRemoteCall [dict get $p node] [dict get $p session] scientific.submit [dict get $p token] [dict get $p nonce]]
    # Retain the nonce receipt until explicit discard: a transport retry must
    # return the same durable supervisor Job, never repeat an admission.
    set response [_scientificExecutionRemoteAccepted $token [dict create ok 1 result $result]]
    if {![dict get $response ok]} {error [dict get $response error]}
    return [dict get $response result]
}

# Script Bridge exposure: HOST_ONLY_JUSTIFIED, operations remote_subscribe and
# remote_unsubscribe. They retain trusted Tcl callback prefixes/channel handles
# in the host event loop. Native/Script Job clients use their public typed Job
# subscription adapter, which calls this same transport owner.
proc ::GX::scientificExecutionRemoteSubscribe {id callback {afterSequence 0}} {
    variable ::GX::ScientificExecution::remoteListeners;variable ::GX::ScientificExecution::remoteSerial
    if {$callback eq {} || ![string is entier -strict $afterSequence] || $afterSequence<0} {error {Remote subscription requires callback and nonnegative cursor}}
    if {[dict size $remoteListeners]>=128} {error {Remote event subscription limit reached}}
    lassign [_scientificRemoteRoute $id] node session job
    set origin {}
    set status [scientificExecutionRemoteJob $id status]
    if {[string match native.* [dict get $status provider_id]]} {
        if {![dict exists $status native_owner client_origin]} {error {Native remote Job lacks durable client origin; explicit readmission required}}
        set origin [dict get $status native_owner client_origin]
        _scientificExecutionRemoteClientOriginCurrent $origin
    }
    set request [_scientificExecutionRemoteRequest $node $session scientific.events $job $afterSequence 128 1000]
    set pipe [open [list | {*}[_scientificExecutionRemoteCommand] events] r+]
    fconfigure $pipe -blocking 0 -buffering line -encoding utf-8 -translation lf
    puts $pipe $request;flush $pipe;chan close $pipe write
    set token remote-job-listener#[incr remoteSerial]
    dict set remoteListeners $token [dict create pipe $pipe callback $callback job_id $id local_job_id $job node_id $node sequence $afterSequence session_token [interactiveDocumentSessionToken] client_origin $origin buffer {}]
    fileevent $pipe readable [list ::GX::_scientificExecutionRemoteReadable $token]
    return $token
}
proc ::GX::scientificExecutionRemoteUnsubscribe {token} {
    variable ::GX::ScientificExecution::remoteListeners
    if {![dict exists $remoteListeners $token]} {return 0}
    if {[dict exists $remoteListeners $token native_watch]} {return [_scientificExecutionRemoteNativeRetire $token [dict get $remoteListeners $token]]}
    set pipe [dict get $remoteListeners $token pipe]
    dict unset remoteListeners $token
    catch {fileevent $pipe readable {}};catch {close $pipe}
    return 1
}
proc ::GX::_scientificExecutionRemoteNativeRetire {token expected} {
    variable ::GX::ScientificExecution::remoteListeners
    if {[dict exists $remoteListeners $token]} {dict unset remoteListeners $token}
    # Close the captured owned transport, never a callback-substituted pipe.
    # Channel names may be recycled after disposal, so require its original
    # pipe PID list too; a newly created listener keeps its own exact token.
    set transport [dict get $expected native_transport];set pipe [dict get $transport channel]
    if {$pipe ne {} && ![catch {pid $pipe} current] && $current eq [dict get $transport pids]} {
        catch {fileevent $pipe readable {}};catch {close $pipe}
    }
    return 1
}
# HOST_ONLY_JUSTIFIED: only the existing Native pending-event validator may
# receive these raw frames. This constructor has no callback argument or public
# bypass flag. Its reply comes from the completed trusted Native worker; full
# current native/origin/CAS adoption still occurs asynchronously before CPP.
proc ::GX::_scientificExecutionRemoteNativeAdmission {id context reply} {
    lassign [_scientificRemoteRoute $id] node session job
    foreach key {module runtime_module_root project validated_snapshot native_client_package_snapshot lifetime session session_token session_directory session_origin request_id} {if {![dict exists $context $key]} {error {Native watcher context is incomplete}}}
    foreach key {job_id remote_admission admission_request_id source_guard resource_sources} {if {![dict exists $reply $key]} {error {Native watcher requires its actual admitted worker reply}}}
    if {[dict get $reply job_id] ne $id || [dict get $reply admission_request_id] ne [dict get $context request_id]} {error {Native watcher worker request/Job correlation changed}}
    set status [dict get $reply remote_admission]
    if {[dict get $status job_id] ne $id || [dict get $status node_id] ne $node || [dict get $status remote_session_id] ne $session} {error {Native watcher admitted route changed}}
    set owner [dict get $status native_owner];set module [dict get $context module];set entrypoint [dict get $owner entrypoint]
    if {[dict get $owner module_id] ne $module || ![regexp {^[A-Za-z][A-Za-z0-9_]*$} $entrypoint] || [dict get $status provider_id] ne "native.$module.$entrypoint"} {error {Native watcher admitted provider/module changed}}
    set origin [dict get $owner client_origin]
    if {[lsort [dict keys $origin]] ne {entrypoint module_id schema session_fingerprint session_origin source_identities} || [dict get $origin schema] ne {gxtxt.native_client_origin.v1} || [dict get $origin module_id] ne $module || [dict get $origin entrypoint] ne $entrypoint || [dict get $origin session_origin] ne [dict get $context session_origin] || ![regexp {^[0-9a-f]{64}$} [dict get $origin session_fingerprint]]} {error {Native watcher originating client/source correlation changed}}
    if {[dict get $reply source_guard source_identities] ne [dict get $origin source_identities]} {error {Native watcher source guard differs from admitted origin}}
    set pair [dict get $owner remote_build]
    if {[lsort [dict keys $pair]] ne {client_identity node_id schema target_identity} || [dict get $pair schema] ne {gxtxt.native_remote_build.v1} || [dict get $pair node_id] ne $node} {error {Native watcher runtime pair/node changed}}
    set client [_scientificExecutionNativeBuildProjection [dict get $pair client_identity]]
    set target [_scientificExecutionNativeBuildProjection [dict get $pair target_identity]]
    _scientificExecutionNativeBuildCompatible $client $target
    if {[dict get $client module_id] ne $module || [dict get $client entrypoint] ne $entrypoint} {error {Native watcher runtime pair owner changed}}
    foreach field {artifact_sha256 source_sha256} {if {[dict get $status source_identities native_artifact $field] ne [dict get $target $field]} {error {Native watcher target source/artifact changed}}}
    return $origin
}
proc ::GX::_scientificExecutionRemoteNativeWatchCurrent {token expected} {
    variable ::GX::ScientificExecution::remoteListeners
    if {![dict exists $remoteListeners $token]} {error {Native watcher was retired}}
    set entry [dict get $remoteListeners $token]
    foreach key {pipe callback job_id local_job_id node_id session_token client_origin sequence buffer native_watch native_transport} {if {![dict exists $entry $key] || [dict get $entry $key] ne [dict get $expected $key]} {error {Native watcher callback/capsule changed}}}
    set transport [dict get $entry native_transport]
    if {[lsort [dict keys $transport]] ne {channel pids} || [dict get $transport channel] ne [dict get $entry pipe]} {error {Native watcher transport changed}}
    if {[dict get $entry pipe] ne {} && ([catch {pid [dict get $entry pipe]} pids] || $pids ne [dict get $transport pids])} {error {Native watcher transport lifetime ended}}
    set capsule [dict get $entry native_watch]
    if {[lsort [dict keys $capsule]] ne {context reply schema window} || [dict get $capsule schema] ne {gxtxt.native_remote_watch.v1}} {error {Native watcher capsule is invalid}}
    set window [dict get $capsule window];set context [dict get $capsule context];set reply [dict get $capsule reply];set id [dict get $entry job_id]
    if {[dict get $entry callback] ne [list ::GX::_viewerNativeJobAdmittedEvent $window $context $reply]} {error {Native watcher requires its fixed pending validator}}
    if {![llength [info commands winfo]] || ![winfo exists $window] || ![dict exists $::GX::ViewerDevelopment::windows $window]} {error {Native watcher window was disposed}}
    set current [dict get $::GX::ViewerDevelopment::windows $window]
    foreach key {module runtime_module_root project validated_snapshot native_client_package_snapshot lifetime} {if {![dict exists $current $key] || [dict get $current $key] ne [dict get $context $key]} {error {Native watcher live context changed}}}
    _viewerNativeJobBinding $window [dict get $context lifetime] $id
    if {![dict exists $current native_job_watch_requests $id] || [dict get $current native_job_watch_requests $id] ne [dict get $context request_id]} {error {Native watcher was superseded}}
    if {$::GX::currentSession ne [dict get $context session] || [interactiveDocumentSessionToken] ne [dict get $context session_token] || $::GX::DocumentSessionScope::identity ne [dict get $context session_directory] || [sessionOriginRead $::GX::currentSession] ne [dict get $context session_origin]} {error {Native watcher Session directory/origin changed}}
    if {[dict get $entry session_token] ne [dict get $context session_token]} {error {Native watcher Session token changed}}
    _scientificExecutionRemoteNativeAdmission $id $context $reply
    return 1
}
proc ::GX::_scientificExecutionRemoteNativeSubscribeAdmitted {id window context reply {afterSequence 0}} {
    variable ::GX::ScientificExecution::remoteListeners;variable ::GX::ScientificExecution::remoteSerial
    if {![string is entier -strict $afterSequence] || $afterSequence<0} {error {Native watcher requires a nonnegative cursor}}
    if {[dict size $remoteListeners]>=128} {error {Remote event subscription limit reached}}
    set origin [_scientificExecutionRemoteNativeAdmission $id $context $reply]
    lassign [_scientificRemoteRoute $id] node session job
    set callback [list ::GX::_viewerNativeJobAdmittedEvent $window $context $reply]
    # Validate the live context before creating a transport process. The same
    # immutable capsule is checked again for every frame and after callbacks.
    set capsule [dict create schema gxtxt.native_remote_watch.v1 window $window context $context reply $reply]
    set entry [dict create pipe {} callback $callback job_id $id local_job_id $job node_id $node sequence $afterSequence session_token [dict get $context session_token] client_origin $origin buffer {} native_watch $capsule native_transport {channel {} pids {}}]
    set token remote-job-listener#[incr remoteSerial]
    dict set remoteListeners $token $entry
    if {[catch {_scientificExecutionRemoteNativeWatchCurrent $token $entry} message options]} {dict unset remoteListeners $token;return -options $options $message}
    dict unset remoteListeners $token
    set request [_scientificExecutionRemoteRequest $node $session scientific.events $job $afterSequence 128 1000]
    set pipe [open [list | {*}[_scientificExecutionRemoteCommand] events] r+]
    try {
        fconfigure $pipe -blocking 0 -buffering line -encoding utf-8 -translation lf
        puts $pipe $request;flush $pipe;chan close $pipe write
        dict set entry pipe $pipe;dict set entry native_transport [dict create channel $pipe pids [pid $pipe]];dict set remoteListeners $token $entry
        fileevent $pipe readable [list ::GX::_scientificExecutionRemoteReadable $token]
    } on error {message options} {catch {close $pipe};dict unset remoteListeners $token;return -options $options $message}
    return $token
}
proc ::GX::_scientificExecutionRemoteReadable {token} {
    variable ::GX::ScientificExecution::remoteListeners
    if {![dict exists $remoteListeners $token]} return
    set entry [dict get $remoteListeners $token];set pipe [dict get $entry pipe]
    set native [dict exists $entry native_watch]
    if {$native && [catch {_scientificExecutionRemoteNativeWatchCurrent $token $entry}]} {_scientificExecutionRemoteNativeRetire $token $entry;return}
    if {[dict get $entry session_token] ne [interactiveDocumentSessionToken] || [catch {set chunk [read $pipe 65536]}]} {scientificExecutionRemoteUnsubscribe $token;return}
    if {!$native && [dict get $entry client_origin] ne {} && [catch {_scientificExecutionRemoteClientOriginCurrent [dict get $entry client_origin]}]} {scientificExecutionRemoteUnsubscribe $token;return}
    set data [dict get $entry buffer]$chunk
    if {[string length $data]>2097152} {scientificExecutionRemoteUnsubscribe $token;return}
    while {[set newline [string first \n $data]]>=0} {
        if {$native} {
            if {[catch {_scientificExecutionRemoteNativeWatchCurrent $token $entry}]} {_scientificExecutionRemoteNativeRetire $token $entry;return}
        } elseif {[dict get $entry client_origin] ne {} && [catch {_scientificExecutionRemoteClientOriginCurrent [dict get $entry client_origin]}]} {scientificExecutionRemoteUnsubscribe $token;return}
        set line [string range $data 0 [expr {$newline-1}]];set data [string range $data [expr {$newline+1}] end]
        if {$line eq {}} continue
        if {[catch {set event [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [encoding convertfrom utf-8 [binary decode base64 -strict $line]]]]}]} {scientificExecutionRemoteUnsubscribe $token;return}
        if {![dict exists $event job_id] || ![dict exists $event node_id] || [dict get $event job_id] ne [dict get $entry local_job_id] || [dict get $event node_id] ne [dict get $entry node_id]} {scientificExecutionRemoteUnsubscribe $token;return}
        set transportError [expr {[dict exists $event event] && [dict get $event event] eq {transport_error}}]
        if {!$transportError} {
            if {![dict exists $event sequence] || ![string is entier -strict [dict get $event sequence]] || [dict get $event sequence]<=[dict get $entry sequence]} continue
            dict set entry sequence [dict get $event sequence]
        }
        dict set event job_id [dict get $entry job_id]
        if {[dict exists $event result_ref job_id]} {dict set event result_ref job_id [dict get $entry job_id]}
        dict set entry buffer $data;dict set remoteListeners $token $entry
        catch {uplevel #0 [list {*}[dict get $entry callback] $event]}
        if {![dict exists $remoteListeners $token]} return
        if {$native && [catch {_scientificExecutionRemoteNativeWatchCurrent $token $entry}]} {_scientificExecutionRemoteNativeRetire $token $entry;return}
        if {$transportError} {scientificExecutionRemoteUnsubscribe $token;return}
    }
    dict set entry buffer $data;dict set remoteListeners $token $entry
    if {[eof $pipe]} {scientificExecutionRemoteUnsubscribe $token}
}
proc ::GX::scientificExecutionStageResource {node session reference} {
    interactiveDocumentResourceInfo $reference
    set size [dict get $reference size_bytes]
    if {$size>8388608} {error {Remote managed input exceeds 8 MiB}}
    set metadata [dict create format gxtxt.remote.staged_input.v1 source_sha256 [dict get $reference sha256] source_document [dict get $reference document_id] source_generation [dict get [interactiveDocumentRead [dict get $reference document_id]] generation] source_origin [sessionOriginRead $::GX::currentSession] source_installation [installationIdentityCurrent] staged_input 1]
    # Preserve admitted original-dtype descriptor semantics while the existing
    # authenticated Resource owner stages its exact bytes. No storage pathname
    # or authority is transferred, and native admission validates the schema.
    foreach field {binary_descriptor unit units} {
        if {[dict exists $reference metadata $field]} {dict set metadata $field [dict get $reference metadata $field]}
    }
    set existing [scientificExecutionRemoteCall $node $session resource.lookup $metadata [dict get $reference sha256] $size]
    if {$existing ne {}} {return $existing}
    set token [scientificExecutionRemoteCall $node $session resource.open $metadata [dict get $reference sha256] $size]
    try {
        for {set offset 0} {$offset<$size} {incr offset 1048576} {
            set bytes [interactiveDocumentResourceReadChunk $reference $offset [expr {min(1048576,$size-$offset)}]]
            scientificExecutionRemoteCall $node $session resource.append $token $offset [binary encode base64 -maxlen 0 $bytes]
        }
        return [scientificExecutionRemoteCall $node $session resource.finalize $token]
    } on error {message options} {
        catch {scientificExecutionRemoteCall $node $session resource.abort $token}
        return -options $options $message
    }
}
