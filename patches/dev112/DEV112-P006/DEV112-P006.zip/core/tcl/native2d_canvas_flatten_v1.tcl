# SPDX-License-Identifier: GPL-3.0-or-later
# Live high-depth flatten: original Native2D/History/Resource/scientific owners.
# No public projection, file path, source string, worker or capability issuer.
proc ::GX::_nativeCanvasFlattenButtonCommand {handle} {
    set row [_nativeCanvasRequire $handle]
    set callback [datasetPublicationV2DictDefault $row callback {}]
    if {[llength $callback]==3 && [lindex $callback 0] eq {::GX::_viewerCanvasEvent}} {
        lassign $callback prefix window component
        if {![dict exists $::GX::ViewerGui::instances $window]} {
            return [list ::GX::_nativeCanvasInspectorFlatten $handle $window $component {}]
        }
        set instance [dict get $::GX::ViewerGui::instances $window]
        set extension {};if {[dict exists $instance design extensions $component]} {set extension [_viewerGuiCanvasExtensionFor $window $component]}
        if {$extension ne {} && [dict exists [_nativeCanvasExtensionDefinition $extension] contract scientific_provider]} {
            # Selection of this private command is not authority. The actual
            # captured slot/module/grants/token are validated on invocation.
            return [list ::GX::_nativeCanvasInspectorFlatten $handle $window $component [dict get $instance token]]
        }
    }
    return [list ::GX::_nativeCanvasSafe $handle flatten]
}
proc ::GX::_nativeCanvasInspectorFlatten {handle window component token} {
    if {[catch {
        if {![dict exists $::GX::ViewerGui::instances $window] || ![viewerGuiDesignGuard $window] ||
            [dict get $::GX::ViewerGui::instances $window token] ne $token || [_viewerCanvasHandle $window $component] ne $handle} {error {Scientific flatten captured Viewer binding ended}}
        _nativeCanvasCancelGesture $handle
        _nativeCanvasFlattenCommand $handle {}
    } result]} {
        catch {_nativeCanvasStatus $handle $result}
        return [dict create status error message $result]
    }
    _nativeCanvasStatus $handle {Scientific flatten pending}
    return $result
}
proc ::GX::_nativeCanvasFlattenOwner {handle} {
    set row [_nativeCanvasRequire $handle]
    set found {}
    if {[info exists ::GX::ViewerGui::instances]} {
        dict for {window instance} $::GX::ViewerGui::instances {
            if {![dict exists $instance canvas_slots]} continue
            dict for {component actual} [dict get $instance canvas_slots] {
                if {$actual ne $handle} continue
                if {$found ne {}} {error {Scientific flatten requires one unambiguous mounted Viewer Canvas binding}}
                if {[dict get $instance module] ne [dict get $row module] || [dict get $instance provider] ne [dict get $row provider]} {error {Scientific flatten Viewer module/provider differs from its Canvas}}
                set found [list $window $component]
            }
        }
    }
    if {$found eq {}} {error {Scientific flatten requires its actual mounted registered Viewer binding; explicit RGBA8 remains a separate derivative request}}
    lassign $found window component
    if {[dict exists $::GX::ViewerDevelopment::windows $window validated_snapshot]} {
        set compiled [dict get $::GX::ViewerDevelopment::windows $window]
        if {[_viewerDevelopmentSnapshot [dict get $compiled project]] ne [dict get $compiled validated_snapshot]} {error {Scientific flatten compiled source changed; reopen the current Viewer}}
    }
    return [viewerGuiCanvasOwnerCapture $window $component flatten]
}
proc ::GX::_nativeCanvasFlattenCurrent {context} {
    dict with context {}
    if {![dict exists $::GX::ViewerGui::instances $window] || ![viewerGuiDesignGuard $window] ||
        [winfo id $window] ne [dict get $owner window_id] || [dict get $::GX::ViewerGui::instances $window token] ne $token || [_viewerCanvasHandle $window $component] ne $handle} {error {Scientific flatten Viewer lifetime or binding changed}}
    _viewerGuiCanvasDefinition $window $component
    _viewerGuiExtensionGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    _viewerGuiExtensionGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    _viewerGuiExtensionGrant $window DATASET_FILE_PUBLICATION_API_v1 datasetFilePublicationPublish
    if {[_viewerGuiCanvasExtensionFor $window $component] ne [dict get $owner extension]} {error {Scientific flatten extension owner changed}}
    set definition [_nativeCanvasExtensionDefinition [dict get $owner extension]]
    foreach key {scientific_provider projection_schema} {if {[dict get $definition contract $key] ne [dict get $owner $key]} {error {Scientific flatten registered capture contract changed}}}
    set row [_nativeCanvasRasterCurrent $handle $stamp]
    if {[dict get $row module] ne $module || [dict get $row provider] ne $provider || ![moduleIsEnabled $module]} {error {Scientific flatten module/provider lifetime changed}}
    if {[dict exists $::GX::ViewerDevelopment::windows $window validated_snapshot]} {
        set compiled [dict get $::GX::ViewerDevelopment::windows $window]
        if {[_viewerDevelopmentSnapshot [dict get $compiled project]] ne [dict get $compiled validated_snapshot]} {error {Scientific flatten compiled source changed; reopen the current Viewer}}
    }
    _nativeCanvasEditCurrent $handle $held
    set pending [dict get $row pending]
    if {$job eq {}} {
        if {![dict exists $pending admission] || [dict get $pending admission] ne $admission} {error {Scientific flatten admission was canceled or replaced}}
    } elseif {![dict exists $pending job] || [dict get $pending job] ne $job} {error {Scientific flatten accepted Job was canceled or replaced}}
    return $row
}
proc ::GX::_nativeCanvasFlattenCommand {handle request} {
    _nativeCanvasFields $request {layers}
    set row [_nativeCanvasRequire $handle]
    if {[dict get $row pending] ne {}} {error {Finish or cancel the pending Canvas operation before scientific flatten}}
    set owner [_nativeCanvasFlattenOwner $handle]
    set initial [native2DCanvasContext $handle]
    set held [native2DCanvasEditCapture $handle]
    [dict get $row native] command cancel {}
    _nativeCanvasAdmitSources $row
    set before [native2DCanvasCapture $handle]
    set all [lmap layer [dict get $before layers] {dict get $layer logical_id}]
    set selected [datasetPublicationV2DictDefault $request layers $all]
    if {[lsort -unique $selected] ne [lsort $all] || [llength $selected]!=[llength $all]} {error {Flatten the complete document; partial backdrop blends cannot be preserved}}
    foreach layer [dict get $before layers] {
        if {[dict get $layer properties locked] || ![dict get $layer properties visible]} {error {Show and unlock all layers before flattening the complete Canvas}}
    }
    foreach item [dict get $before objects] {_nativeCanvasRasterEditable $before $item}
    foreach group [dict get $before groups] {
        if {[dict get $group style locked] || ![dict get $group style visible]} {error {Hidden or locked groups cannot be flattened}}
    }
    set window [dict get $owner window];set component [dict get $owner component]
    set prepared {};set job {};set waiter {}
    try {
        # This fixed private purpose captures the full DOCUMENT frame twice.
        # The registered provider supplies its declared typed defaults/recipe;
        # the existing scientific owner validates full source/Resource lineage.
        set prepared [scientificExecutionCanvasPrepare $window $component $handle {} flatten]
        _nativeCanvasEditCurrent $handle $held
        set sequence [expr {[dict get $row sequence]+1}]
        set stamp [_nativeCanvasRasterStamp $handle];dict set stamp sequence $sequence
        dict set held sequence $sequence
        set admission flatten-admission-[pid]-[incr ::GX::NativeCanvas::serial]
        set context [dict create handle $handle window $window component $component token [dict get $owner token] \
            module [dict get $row module] provider [dict get $row provider] stamp $stamp held $held before $before job {} \
            admission $admission owner $owner cancel_prefix [scriptJobCommand cancel]]
        # Keep the existing response owner alive even if Cancel/Dispose clears
        # this admission. A real accepted ID must be received, then canceled.
        set submission [scientificExecutionSubmit $prepared [list ::GX::_nativeCanvasFlattenSubmitted $context]]
        set prepared {}
        # Begin checks the original held sequence, then CORE binds it once to
        # the admitted sequence. Callback context contains the same CORE value.
        set admitted [native2DCanvasOperationBegin $handle $initial [list admission $admission] [dict replace $held sequence [dict get $initial sequence]]]
        if {[dict get $admitted held] ne $held} {error {Scientific flatten admission sequence differs from its captured callback}}
        dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status pending operation flatten submission_id [dict get $submission submission_id] precision tiff32f]
        _nativeCanvasNotify $handle raster_pending
        return [dict create status pending operation flatten submission_id [dict get $submission submission_id]]
    } on error {message options} {
        if {$prepared ne {}} {catch {scientificExecutionDiscard $prepared}}
        if {$job ne {}} {catch {scientificExecutionCancel $job}}
        if {$waiter ne {}} {catch {scriptJobRequestCancel $waiter cancelled}}
        if {[info exists context]} {_nativeCanvasFlattenFailed $context $message}
        return -options $options $message
    }
}
proc ::GX::_nativeCanvasFlattenSubmitted {context response} {
    set job {}
    if {[catch {
        if {![dict get $response ok]} {error [datasetPublicationV2DictDefault $response error {Scientific flatten admission failed}]}
        set accepted [dict get $response result]
        set job [dict get $accepted job_id]
        if {$job eq {} || [dict get $accepted provider_id] ne [dict get $context owner scientific_provider]} {error {Scientific flatten admission lacks its actual registered-provider Job}}
        # This checks the PRE-accepted nonce, not an echoed request ID.
        _nativeCanvasFlattenCurrent $context
        dict set context job $job
        set handle [dict get $context handle]
        dict set ::GX::NativeCanvas::instances $handle pending [list job $job]
        _nativeCanvasFlattenCurrent $context
        set command [list [info nameofexecutable] [file join $::GX::scriptDir core tcl native2d_canvas_raster_wait_v1.tcl] $::GX::scriptDir [scriptJobRoot] $job]
        set waiter [scriptJobAsync $command {} [list ::GX::_nativeCanvasFlattenCompleted $context] \
            {timeout_ms 190000 max_bytes 65536 process_group 1 ui_lifetime 1 label {Scientific Native Canvas flatten completion}}]
        dict set ::GX::NativeCanvas::instances $handle pending [list job $job waiter $waiter]
        dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status pending operation flatten job_id $job precision tiff32f]
        _nativeCanvasNotify $handle raster_pending
    } message]} {
        if {$job ne {}} {_nativeCanvasFlattenLateCancel $context $job}
        _nativeCanvasFlattenFailed $context $message
    }
}
proc ::GX::_nativeCanvasFlattenLateCancel {context job} {
    # Frozen existing CORE command/root, never a frontend path or current
    # replacement Session's owner. Original Supervisor owns group drain.
    if {[catch {
        scriptJobAsync [list {*}[dict get $context cancel_prefix] $job] {} \
            [list ::GX::_nativeCanvasFlattenLateCanceled $job] \
            {timeout_ms 10000 max_bytes 65536 process_group 0 ui_lifetime 0 label {Cancel retired scientific flatten admission}}
    } message]} {puts stderr "Scientific flatten could not request cancellation of actual Job $job: $message"}
}
proc ::GX::_nativeCanvasFlattenLateCanceled {job response} {
    if {[catch {dict get $response ok} ok] || !$ok} {
        puts stderr "Scientific flatten cancellation of actual Job $job was not confirmed: $response"
    }
}
proc ::GX::_nativeCanvasFlattenFailed {context message} {
    set handle [dict get $context handle]
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    foreach key {native document receipt session sequence} {
        if {[dict get $row $key] ne [dict get $context stamp $key]} return
    }
    set pending [dict get $row pending]
    set job [dict get $context job]
    if {$job eq {}} {
        if {![dict exists $pending admission] || [dict get $pending admission] ne [dict get $context admission]} return
    } elseif {![dict exists $pending job] || [dict get $pending job] ne $job} return
    # Never clear a replacement operation, mutate History, or restore old pixels.
    dict set ::GX::NativeCanvas::instances $handle pending {}
    catch {dict unset ::GX::NativeCanvas::instances $handle raster_import}
    dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status rejected operation flatten job_id [dict get $context job] error $message]
    catch {_nativeCanvasStatus $handle $message}
    catch {_nativeCanvasNotify $handle raster_rejected}
}
proc ::GX::_nativeCanvasFlattenCompleted {context response} {
    if {[catch {
        _nativeCanvasFlattenCurrent $context
        if {![dict get $response ok]} {error [datasetPublicationV2DictDefault $response error {Scientific flatten completion failed}]}
        _scientificExecutionImageOutputsAsync [dict get $context job] [list ::GX::_nativeCanvasFlattenOutputs $context]
    } message]} {_nativeCanvasFlattenFailed $context $message}
}
proc ::GX::_nativeCanvasFlattenOutputs {context response} {
    if {[catch {
        _nativeCanvasFlattenCurrent $context
        if {![dict get $response ok]} {error [datasetPublicationV2DictDefault $response error {Scientific flatten immutable output verification failed}]}
        set result [dict get $response result];set queue {};set raster {}
        foreach output [dict get $result outputs] {
            if {[dict get $output role] eq {raster}} {if {$raster ne {}} {error {Ambiguous scientific flatten raster}};set raster $output}
            lappend queue [list [dict get $output role] $output]
        }
        if {$raster eq {} || [dict get $raster format] ne {tiff32f} || [dict get $raster live]} {error {Scientific flatten requires its actual immutable high-depth raster}}
        set job [_scientificExecutionPublicationJob [dict get $context job]]
        if {[dict get $job state] ne {COMPLETED}} {error {Scientific flatten Job is not COMPLETED}}
        # Reuse original full-stack identity, lineage and actual-output validator.
        scientificExecutionCanvasResultValidate [dict get $context owner scientific_provider] [dict get $job scientific_request] [dict get $result summary] $raster
        _nativeCanvasFlattenCurrent $context
        dict set context result $result;dict set context queue $queue;dict set context imported {}
        _nativeCanvasFlattenImportNext $context
    } message]} {_nativeCanvasFlattenFailed $context $message}
}
proc ::GX::_nativeCanvasFlattenImportNext {context} {
    if {[catch {
        set row [_nativeCanvasFlattenCurrent $context]
        set queue [dict get $context queue]
        if {![llength $queue]} {
            _nativeCanvasFlattenAdopt $context
        } else {
            lassign [lindex $queue 0] role output
            dict set context queue [lrange $queue 1 end]
            set receipt [dict get $row receipt]
            set guard [dict create document_id [dict get $row document] generation [dict get $receipt generation] revision [dict get $receipt revision] sha256 [dict get $receipt sha256]]
            set ticket [scientificExecutionImageImport [dict get $context job] $output $guard \
                [list ::GX::_nativeCanvasFlattenImported $context $role]]
            _nativeCanvasFlattenCurrent $context
            dict set ::GX::NativeCanvas::instances [dict get $context handle] raster_import $ticket
        }
    } message]} {_nativeCanvasFlattenFailed $context $message}
}
proc ::GX::_nativeCanvasFlattenImported {context role response} {
    if {[catch {
        _nativeCanvasFlattenCurrent $context
        if {![dict get $response ok]} {error [datasetPublicationV2DictDefault $response error {Scientific flatten Resource import failed}]}
        dict set context imported $role [dict get $response result]
        _nativeCanvasFlattenImportNext $context
    } message]} {_nativeCanvasFlattenFailed $context $message}
}
proc ::GX::_nativeCanvasFlattenAdopt {context} {
    dict with context {}
    set row [_nativeCanvasFlattenCurrent $context]
    foreach role {raster provenance} {if {![dict exists $imported $role]} {error {Scientific flatten omitted its actual raster/provenance Resources}}}
    set raster [dict get $imported raster];set provenance [dict get $imported provenance]
    set dimensions [_native2DImageDimensions $raster]
    _nativeCanvasFlattenCurrent $context
    if {$dimensions ne [dict get $before extent]} {error {Scientific flatten output differs from full Document extent}}
    set suffix [dict get $stamp sequence]-[clock clicks]
    set logical canvas_scientific_flatten_object_$suffix;set layer canvas_scientific_flatten_layer_$suffix
    set reference [_nativeCanvasRasterGeometry $handle $raster $provenance {} $logical 1]
    _nativeCanvasFlattenCurrent $context
    set next $before
    foreach ref [dict values $imported] {dict lappend next retained_outputs $ref}
    dict set next layers [list [dict create logical_id $layer name Flattened attributes [dict create gx.canvas [dict create logical_id $layer kind layer name Flattened blend Over]] \
        properties {visible 1 selectable 1 locked 0 order 0 opacity 1} blend Over]]
    dict set next objects [list [dict create logical_id $logical name {Scientific flattened Canvas} resource $reference \
        style {visible 1 selectable 1 locked 0 order 0 line_style 0 marker 0 line_width 1 color {1 1 1 1}} layer_logical_id $layer]]
    dict set next groups {};dict set next selection [list $logical];dict set next active_layer $layer
    # Original Document background is already included in the actual raster.
    dict set next background {0 0 0 0}
    _nativeCanvasFlattenCurrent $context
    # The original owner stages/yields before its final held check. Keep
    # pending.job until that owner commits or refuses; Cancel must still own it.
    set committed [_nativeCanvasCommitSnapshot $handle $held $next {Canvas flatten accepted (registered high-depth full Document)}]
    if {[datasetPublicationV2DictDefault $committed status {}] eq {unchanged}} {error {Scientific flatten did not commit its generated output snapshot}}
    return [_nativeCanvasFlattenAfterCommit $context $next $committed]
}
proc ::GX::_nativeCanvasFlattenAfterCommit {context next committed} {
    # A successful original swap is already durable. Never re-enter the OLD
    # held guard or classify a later presentation/lifetime error as rejection.
    set outcome [dict create status committed operation flatten job_id [dict get $context job] notification_current 0]
    if {[dict exists $committed presentation_error]} {dict set outcome presentation_error [dict get $committed presentation_error]}
    try {
        dict with context {}
        if {![dict exists $::GX::NativeCanvas::instances $handle] ||
            ![dict exists $::GX::ViewerGui::instances $window] || ![viewerGuiDesignGuard $window] ||
            [dict get $::GX::ViewerGui::instances $window token] ne $token || [_viewerCanvasHandle $window $component] ne $handle} {return $outcome}
        # Fresh original Require checks actual Document receipt SHA/generation/
        # revision and native alive state; no saved dictionary grants this.
        set current [_nativeCanvasRequire $handle]
        if {[dict get $current document] ne [dict get $stamp document] ||
            [dict get $current session] ne [dict get $stamp session] ||
            [dict get $current module] ne $module || [dict get $current provider] ne $provider ||
            ![moduleIsEnabled $module] || [dict get $current native] eq [dict get $stamp native]} {return $outcome}
        set expectedRevision [expr {[dict get $stamp receipt revision]+1}]
        set receipt [dict get $current receipt]
        if {[dict get $receipt generation] ne [dict get $stamp receipt generation] ||
            [dict get $receipt revision]!=$expectedRevision ||
            [dict get $current sequence]!=[dict get $stamp sequence]+1 || [dict get $current pending] ne {}} {return $outcome}
        if {[dict get $committed document_id] ne [dict get $current document]} {return $outcome}
        if {[dict exists $committed receipt]} {
            if {[dict get $committed receipt] ne $receipt} {return $outcome}
        } else {
            if {[dict get $committed api_id] ne {NATIVE2D_API_v1} ||
                [dict get $committed generation] ne [dict get $receipt generation] ||
                [dict get $committed revision]!=$expectedRevision ||
                [dict get $committed canvas_id] ne [dict get $next canvas_id]} {return $outcome}
        }
        if {[dict remove [dict get $current snapshot] view_state tool] ne [dict remove $next view_state tool]} {return $outcome}
        set actual [[dict get $current native] state]
        if {[dict get $actual canvas_id] ne [dict get $next canvas_id]} {return $outcome}
        set actualObjects [lsort [lmap item [dict get $actual objects] {dict get $item logical_id}]]
        set expectedObjects [lsort [lmap item [dict get $next objects] {dict get $item logical_id}]]
        if {$actualObjects ne $expectedObjects} {return $outcome}
        set status [dict get $current raster_status]
        if {![dict exists $status job_id] || [dict get $status job_id] ne $job ||
            [dict get $status operation] ne {flatten} || [dict get $status status] ni {pending canceled}} {return $outcome}
        set status [dict create status completed operation flatten job_id $job precision tiff32f \
            raster_sha256 [dict get $imported raster sha256] provenance_sha256 [dict get $imported provenance sha256] publication {}]
        if {[dict exists $committed presentation_error]} {dict set status presentation_error [dict get $committed presentation_error]}
        # All checks above are non-yielding owner reads. No unconditional
        # cleanup can erase a later import or recreate a disposed handle.
        dict set ::GX::NativeCanvas::instances $handle raster_status $status
        dict set outcome notification_current 1
        dict set outcome receipt $receipt
        # This is LAST: actual owner callbacks may dispose or start newer work.
        _nativeCanvasNotify $handle raster_completed
        return $outcome
    } on error {message options} {
        dict set outcome postcommit_diagnostic $message
        return $outcome
    }
}
