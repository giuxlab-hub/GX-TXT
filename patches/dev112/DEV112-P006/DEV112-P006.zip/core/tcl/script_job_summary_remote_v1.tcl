# SPDX-License-Identifier: GPL-3.0-or-later
# Private delegate of script_job_summary_v1.script_bridge_policy.json; no public operation.
namespace eval ::GX::RemoteJobSummary {variable serial 0;variable subscriptions {}}

# HOST_ONLY_JUSTIFIED: cross-Session operational metadata and a real widget's
# callback/pipe lifetime belong to the trusted GUI, never an untrusted Script.
proc ::GX::_scriptJobSummaryRemoteSubscribe {widget callback {afterSequence 0}} {
    if {![llength [info commands winfo]] || ![winfo exists $widget] || $callback eq {} || ![string is entier -strict $afterSequence] || $afterSequence<0} {error {Remote summary requires a live widget, callback and nonnegative cursor}}
    set token remote-job-summary#[incr ::GX::RemoteJobSummary::serial]
    set nodes [scientificExecutionNodes]
    set tags [bindtags $widget]
    set destroyTag ::GX::RemoteJobSummary::destroy#[incr ::GX::RemoteJobSummary::serial]
    while {[llength [bind $destroyTag]] || $destroyTag in $tags} {set destroyTag ::GX::RemoteJobSummary::destroy#[incr ::GX::RemoteJobSummary::serial]}
    dict set ::GX::RemoteJobSummary::subscriptions $token [dict create widget $widget callback $callback configured $nodes routes {} configuration_subscription {} destroy_tag $destroyTag]
    set subscription [configurationSubscribe [list ::GX::_scriptJobSummaryRemoteConfigurationChanged $token]]
    dict set ::GX::RemoteJobSummary::subscriptions $token configuration_subscription $subscription
    bind $destroyTag <Destroy> [list ::GX::_scriptJobSummaryRemoteDestroyed $token $widget %W]
    set at [lsearch -exact $tags $widget]
    set at [expr {$at<0?0:$at+1}]
    bindtags $widget [linsert $tags $at $destroyTag]
    _scriptJobSummaryRemoteStart $token $nodes $afterSequence
    return $token
}
proc ::GX::_scriptJobSummaryRemoteStart {token nodes {afterSequence 0}} {
    if {![dict exists $::GX::RemoteJobSummary::subscriptions $token]} return
    dict set ::GX::RemoteJobSummary::subscriptions $token configured $nodes
    dict set ::GX::RemoteJobSummary::subscriptions $token routes {}
    set generation [incr ::GX::RemoteJobSummary::serial]
    dict for {id node} $nodes {
        set pipe {}
        set route [dict create node_id $id availability PENDING pipe {} buffer {} generation $generation sequence 0 scope_key {} revision {} established 0 lost_connection 0]
        if {![dict get $node enabled]} {
            dict set route availability DISABLED
        } elseif {[catch {
            set request [_scientificExecutionRemoteRequest $id {} jobs.summary_events $afterSequence {} 1000]
            set command [concat [_scientificExecutionRemoteCommand] summary-events]
            set pipe [open [list | {*}$command] r+]
            fconfigure $pipe -blocking 0 -buffering none -encoding ascii -translation lf
            puts $pipe $request;flush $pipe
            dict set route pipe $pipe
            fileevent $pipe readable [list ::GX::_scriptJobSummaryRemoteReadable $token $id $generation $pipe]
        }]} {
            if {$pipe ne {}} {catch {close $pipe}}
            dict set route availability UNKNOWN
        }
        dict set ::GX::RemoteJobSummary::subscriptions $token routes $id $route
    }
    # Initial zero/pending coverage is asynchronous even without any Nodes.
    after 0 [list ::GX::_scriptJobSummaryRemoteDeliver $token]
}
proc ::GX::_scriptJobSummaryRemoteConfigurationChanged {token field} {
    if {$field ni {{} execution.nodes} || ![dict exists $::GX::RemoteJobSummary::subscriptions $token]} return
    set entry [dict get $::GX::RemoteJobSummary::subscriptions $token]
    if {![winfo exists [dict get $entry widget]]} {_scriptJobSummaryRemoteUnsubscribe $token;return}
    set nodes [scientificExecutionNodes]
    if {$nodes eq [dict get $entry configured]} return
    dict for {id route} [dict get $entry routes] {
        set pipe [dict get $route pipe]
        if {$pipe ne {}} {catch {fileevent $pipe readable {}};catch {close $pipe}}
    }
    # Same external token, fresh route incarnation. Previously queued readable
    # callbacks carry an expected pipe and cannot retarget these replacements.
    _scriptJobSummaryRemoteStart $token $nodes
    _scriptJobSummaryRemoteDeliver $token
}

# HOST_ONLY_JUSTIFIED: this transient monitor token closes client pipes only;
# it cannot cancel/adopt/modify any local or remote durable Job.
proc ::GX::_scriptJobSummaryRemoteUnsubscribe {token} {
    if {![dict exists $::GX::RemoteJobSummary::subscriptions $token]} {return 0}
    set entry [dict get $::GX::RemoteJobSummary::subscriptions $token]
    dict unset ::GX::RemoteJobSummary::subscriptions $token
    if {[dict exists $entry destroy_tag]} {
        set destroyTag [dict get $entry destroy_tag];set widget [dict get $entry widget]
        catch {
            if {[winfo exists $widget]} {
                set keep {};foreach tag [bindtags $widget] {if {$tag ne $destroyTag} {lappend keep $tag}}
                bindtags $widget $keep
            }
        }
        catch {bind $destroyTag <Destroy> {}}
    }
    if {[dict get $entry configuration_subscription] ne {}} {catch {configurationUnsubscribe [dict get $entry configuration_subscription]}}
    dict for {id route} [dict get $entry routes] {
        set pipe [dict get $route pipe]
        if {$pipe ne {}} {catch {fileevent $pipe readable {}};catch {close $pipe}}
    }
    return 1
}
proc ::GX::_scriptJobSummaryRemoteDestroyed {token widget destroyed} {
    if {$widget eq $destroyed} {_scriptJobSummaryRemoteUnsubscribe $token}
}
proc ::GX::_scriptJobSummaryRemoteCurrent {token} {
    if {![dict exists $::GX::RemoteJobSummary::subscriptions $token]} {return 0}
    set entry [dict get $::GX::RemoteJobSummary::subscriptions $token]
    if {![winfo exists [dict get $entry widget]]} {_scriptJobSummaryRemoteUnsubscribe $token;return 0}
    # Registry changes retire this exact snapshot. Never retarget old pipe
    # replies to new endpoint/grant/configuration under the same Node name.
    if {[dict get $entry configured] ne [scientificExecutionNodes]} {
        _scriptJobSummaryRemoteUnsubscribe $token
        return 0
    }
    return 1
}
proc ::GX::_scriptJobSummaryRemoteDeliver {token} {
    if {![_scriptJobSummaryRemoteCurrent $token]} return
    set entry [dict get $::GX::RemoteJobSummary::subscriptions $token]
    set total [dict create running 0 queued 0 failed 0 interrupted 0 unknown_jobs 0]
    set known 0;set unknown 0;set lost 0;set cursors {};set nodes {}
    dict for {id route} [dict get $entry routes] {
        set state [dict get $route availability]
        dict set nodes $id [dict remove $route pipe buffer generation]
        dict set cursors $id [dict create sequence [dict get $route sequence] scope_key [dict get $route scope_key] revision [dict get $route revision]]
        if {$state eq {AVAILABLE}} {
            incr known
            foreach field {running queued failed interrupted} {dict incr total $field [dict get $route $field]}
            dict incr total unknown_jobs [dict get $route unknown]
        } else {
            incr unknown
            if {[dict get $route lost_connection]} {incr lost}
        }
    }
    set available [expr {$unknown==0}]
    # Partial totals are explicitly confirmed subtotals; when no route was
    # observed they are unknown, except authoritative zero CONFIGURED routes.
    if {$unknown && !$known} {foreach field {running queued failed interrupted unknown_jobs} {dict set total $field {}}}
    set message {}
    if {$unknown} {set message "$unknown compute node summary route(s) pending, denied or unavailable"}
    set result [dict merge $total [dict create schema gxtxt.remote_job_summary.v1 available $available complete $available coverage configured_authorized_routes sequence $cursors unknown_nodes $unknown unavailable_routes $unknown diagnostic $message nodes $nodes confirmed_nodes $known lost_connections $lost]]
    catch {uplevel #0 [list {*}[dict get $entry callback] [dict create ok 1 result $result]]}
}
proc ::GX::_scriptJobSummaryRemoteFailure {token id availability {transportFailure 0}} {
    if {![_scriptJobSummaryRemoteCurrent $token] || ![dict exists $::GX::RemoteJobSummary::subscriptions $token routes $id]} return
    set route [dict get $::GX::RemoteJobSummary::subscriptions $token routes $id]
    set pipe [dict get $route pipe]
    if {$pipe ne {}} {catch {fileevent $pipe readable {}};catch {close $pipe}}
    # Retain only correlation, never stale successful counts presented as live.
    set established [dict get $route established]
    set lost [expr {$established && $transportFailure && $availability eq {UNAVAILABLE}}]
    dict set ::GX::RemoteJobSummary::subscriptions $token routes $id [dict create node_id $id availability $availability pipe {} buffer {} generation [dict get $route generation] sequence [dict get $route sequence] scope_key [dict get $route scope_key] revision [dict get $route revision] established $established lost_connection $lost]
    _scriptJobSummaryRemoteDeliver $token
}
proc ::GX::_scriptJobSummaryRemoteReadable {token id generation expectedPipe} {
    if {![_scriptJobSummaryRemoteCurrent $token] || ![dict exists $::GX::RemoteJobSummary::subscriptions $token routes $id]} return
    set route [dict get $::GX::RemoteJobSummary::subscriptions $token routes $id];set pipe [dict get $route pipe]
    if {$pipe eq {} || $pipe ne $expectedPipe || [dict get $route generation] ne $generation} return
    if {[catch {set chunk [read $pipe 16384]}]} {_scriptJobSummaryRemoteFailure $token $id UNAVAILABLE 1;return}
    set data [dict get $route buffer];append data $chunk
    if {[string length $data]>65536} {_scriptJobSummaryRemoteFailure $token $id UNKNOWN;return}
    set latest {};set failure {};set transportFailure 0
    while {[set newline [string first \n $data]]>=0} {
        set line [string range $data 0 [expr {$newline-1}]];set data [string range $data [expr {$newline+1}] end]
        if {$line eq {}} continue
        if {[string length $line]>24576 || [catch {
            set value [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [encoding convertfrom utf-8 [binary decode base64 -strict $line]]]]
            if {[dict get $value node_id] ne $id} {error {Foreign summary route}}
            if {[dict get $value schema] eq {gxtxt.job_summary_transport_error.v1}} {
                if {[dict get $value availability] ni {DENIED UNAVAILABLE UNSUPPORTED UNKNOWN}} {error {Invalid summary error availability}}
                set failure [dict get $value availability]
                set transportFailure [expr {$failure eq {UNAVAILABLE}}]
            } else {
                if {[dict get $value schema] ne {gxtxt.job_summary.v1} || [dict get $value coverage] ne {granted_node_sessions}} {error {Invalid summary schema}}
                foreach field {scope_key revision} {if {![regexp {^[0-9a-f]{64}$} [dict get $value $field]]} {error {Missing summary scope identity}}}
                set sequence [dict get $value sequence]
                if {![string is entier -strict $sequence] || $sequence<0} {error {Invalid summary cursor}}
                if {[dict get $route scope_key] eq [dict get $value scope_key] && $sequence<[dict get $route sequence]} {error {Summary cursor regressed}}
                set state [dict get $value availability]
                if {$state ni {AVAILABLE UNINITIALIZED INITIALIZING DENIED UNKNOWN}} {error {Invalid summary availability}}
                if {$state eq {AVAILABLE}} {
                    if {![dict get $value complete]} {error {Available summary is incomplete}}
                    foreach field {running queued failed interrupted unknown} {
                        if {![string is entier -strict [dict get $value $field]] || [dict get $value $field]<0} {error {Invalid summary counts}}
                    }
                } else {
                    foreach field {running queued failed interrupted unknown} {if {[dict get $value $field] ne {}} {error {Unavailable summary fabricated counts}}}
                }
                set latest $value
                if {$state eq {AVAILABLE}} {
                    # A validated authoritative frame establishes this exact
                    # stream even if an error follows in the same read chunk.
                    dict set route established 1
                    dict set ::GX::RemoteJobSummary::subscriptions $token routes $id established 1
                }
            }
        }]} {set failure UNKNOWN;break}
        if {$failure ne {}} break
    }
    if {$failure ne {}} {_scriptJobSummaryRemoteFailure $token $id $failure $transportFailure;return}
    dict set route buffer $data
    if {$latest ne {}} {
        set route [dict merge $route $latest]
        if {[dict get $latest availability] eq {AVAILABLE}} {dict set route established 1;dict set route lost_connection 0}
        # Only closed metadata enters the GUI; transport-only receipt members
        # stay inert and no descriptor/credentials enter the callback.
    }
    dict set ::GX::RemoteJobSummary::subscriptions $token routes $id $route
    if {$latest ne {}} {_scriptJobSummaryRemoteDeliver $token}
    # A callback may unsubscribe or replace configuration/window. Re-fetch its
    # exact route; never resurrect a captured entry after callback mutation.
    if {![_scriptJobSummaryRemoteCurrent $token] || ![dict exists $::GX::RemoteJobSummary::subscriptions $token routes $id] || [dict get $::GX::RemoteJobSummary::subscriptions $token routes $id pipe] ne $pipe || [dict get $::GX::RemoteJobSummary::subscriptions $token routes $id generation] ne $generation} return
    if {[eof $pipe]} {_scriptJobSummaryRemoteFailure $token $id UNAVAILABLE 1}
}
