# Script Bridge operation policy: script_job_summary_v1.script_bridge_policy.json.
# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted operational metadata across Sessions; not an untrusted module grant.
namespace eval ::GX::JobSummary {variable subscriptions {};variable serial 0;variable suspensions {}}

# HOST_ONLY_JUSTIFIED: cross-Session counts require trusted operational observer
# authority. This one-shot snapshot is LOCAL only. The Tcl callback belongs to
# this interpreter, not a script worker; combined GUI state is the subscription.
proc ::GX::scriptJobSummary {callback} {
    if {$callback eq {}} {error {Job summary requires a trusted callback}}
    return [scriptJobAsync [scriptJobCommand summary] {} $callback [dict create timeout_ms 12000 max_bytes 16384 label {Job summary}]]
}

# HOST_ONLY_JUSTIFIED: a real GUI widget owns this channel/callback incarnation;
# global observation does not grant Job detail, cancellation or output access.
proc ::GX::scriptJobSummarySubscribe {widget callback {afterSequence 0}} {
    if {![llength [info commands winfo]] || ![winfo exists $widget] || $callback eq {} || ![string is entier -strict $afterSequence] || $afterSequence<0} {error {Job summary subscription requires a live widget, callback and nonnegative cursor}}
    set token job-summary-listener#[incr ::GX::JobSummary::serial]
    set tags [bindtags $widget]
    set destroyTag ::GX::JobSummary::destroy#[incr ::GX::JobSummary::serial]
    while {[llength [bind $destroyTag]] || $destroyTag in $tags} {set destroyTag ::GX::JobSummary::destroy#[incr ::GX::JobSummary::serial]}
    dict set ::GX::JobSummary::subscriptions $token [dict create pipe {} transport_generation 0 widget $widget callback $callback buffer {} remote_token {} destroy_tag $destroyTag after_sequence $afterSequence \
        local [dict create available 0 complete 0 availability PENDING established 0 running {} queued {} failed {} interrupted {} unknown {} sequence 0 diagnostic {Local Job summary pending} lost_connections 0] \
        remote [dict create available 0 complete 0 running {} queued {} failed {} interrupted {} unknown_jobs {} unknown_nodes {} unavailable_routes {} lost_connections 0 sequence {} diagnostic {Remote Job coverage pending}]]
    # A private per-monitor tag can be retired without editing a foreign widget
    # script or retaining inert callbacks until that widget is destroyed.
    bind $destroyTag <Destroy> [list ::GX::_scriptJobSummaryDestroyed $token $widget %W]
    set at [lsearch -exact $tags $widget];set at [expr {$at<0?0:$at+1}]
    bindtags $widget [linsert $tags $at $destroyTag]
    if {[catch {_scriptJobSummaryStart $token} message options]} {
        scriptJobSummaryUnsubscribe $token
        return -options $options $message
    }
    return $token
}

# Private host transport lifecycle. A suspended widget keeps its exact opaque
# subscription, but no observer pipe can restart until the outer transaction
# finishes. These leases never change a durable Job or the plugin safety gate.
proc ::GX::_scriptJobSummaryStart {token} {
    if {[dict size $::GX::JobSummary::suspensions] || ![dict exists $::GX::JobSummary::subscriptions $token]} return
    set entry [dict get $::GX::JobSummary::subscriptions $token]
    if {![winfo exists [dict get $entry widget]]} {scriptJobSummaryUnsubscribe $token;return}
    if {[dict get $entry pipe] ne {}} return
    set pipe [open [list | {*}[scriptJobCommand summary_watch [dict get $entry after_sequence]]] r+]
    if {[catch {fconfigure $pipe -blocking 0 -buffering line -encoding ascii -translation lf} message options]} {
        catch {close $pipe};return -options $options $message
    }
    dict set ::GX::JobSummary::subscriptions $token pipe $pipe
    set generation [incr ::GX::JobSummary::serial]
    dict set ::GX::JobSummary::subscriptions $token transport_generation $generation
    dict set ::GX::JobSummary::subscriptions $token buffer {}
    fileevent $pipe readable [list ::GX::_scriptJobSummaryReadable $token $pipe $generation]
    set widget [dict get $entry widget]
    if {[llength [info commands ::GX::_scriptJobSummaryRemoteSubscribe]]} {
        if {[catch {set remote [_scriptJobSummaryRemoteSubscribe $widget [list ::GX::_scriptJobSummaryRemoteReady $token $generation] 0]} failure]} {
            _scriptJobSummaryRemoteReady $token $generation [dict create ok 0 error $failure]
        } elseif {[dict exists $::GX::JobSummary::subscriptions $token]} {
            dict set ::GX::JobSummary::subscriptions $token remote_token $remote
        } else {catch {_scriptJobSummaryRemoteUnsubscribe $remote}}
    }
}

# Capture only processes from this owner's actual open channels. These
# identities are used to WAIT for EOF retirement, never to exempt a child from
# pluginRuntimeCheckQuiescent's unchanged all-child refusal.
proc ::GX::_scriptJobSummaryProcess {process} {
    set path /proc/$process/stat
    if {![file exists $path]} {return {}}
    set f [open $path];try {set stat [read $f]} finally {close $f}
    set fields [string range $stat [expr {[string last {)} $stat]+2}] end]
    return [dict create state [lindex $fields 0] start [lindex $fields 19]]
}
proc ::GX::_scriptJobSummaryStop {token} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} {return {}}
    set entry [dict get $::GX::JobSummary::subscriptions $token]
    set pipes [list [dict get $entry pipe]];set remote [dict get $entry remote_token]
    if {$remote ne {} && [dict exists $::GX::RemoteJobSummary::subscriptions $remote]} {
        dict for {id route} [dict get $::GX::RemoteJobSummary::subscriptions $remote routes] {lappend pipes [dict get $route pipe]}
    }
    set processes {}
    if {$::tcl_platform(os) eq {Linux}} {
        foreach pipe $pipes {
            if {$pipe eq {}} continue
            foreach process [pid $pipe] {
                set identity [_scriptJobSummaryProcess $process]
                if {$identity ne {}} {dict set processes $process [dict get $identity start]}
            }
        }
    }
    # Invalidate the transport before closing it, including queued read events.
    dict set ::GX::JobSummary::subscriptions $token pipe {}
    dict set ::GX::JobSummary::subscriptions $token transport_generation [incr ::GX::JobSummary::serial]
    dict set ::GX::JobSummary::subscriptions $token remote_token {}
    dict set ::GX::JobSummary::subscriptions $token buffer {}
    set pipe [dict get $entry pipe]
    if {$pipe ne {}} {catch {fileevent $pipe readable {}};catch {close $pipe}}
    if {$remote ne {}} {_scriptJobSummaryRemoteUnsubscribe $remote}
    return $processes
}
proc ::GX::_scriptJobSummarySuspend {} {
    set lease job-summary-suspension#[incr ::GX::JobSummary::serial]
    set outer [expr {![dict size $::GX::JobSummary::suspensions]}]
    dict set ::GX::JobSummary::suspensions $lease 1
    if {!$outer} {return $lease}
    try {
        set processes {}
        foreach token [dict keys $::GX::JobSummary::subscriptions] {
            set processes [dict merge $processes [_scriptJobSummaryStop $token]]
            if {![dict exists $::GX::JobSummary::subscriptions $token]} continue
            dict set ::GX::JobSummary::subscriptions $token remote [dict create available 0 complete 0 running {} queued {} failed {} interrupted {} unknown_jobs {} unknown_nodes {} unavailable_routes {} lost_connections 0 sequence {} diagnostic {Job observation paused during plugin transaction}]
            _scriptJobSummaryLocalReady $token [dict create ok 0 error {Job observation paused during plugin transaction} error_type summary_paused]
        }
        set deadline [expr {[clock milliseconds]+2000}]
        while {[dict size $processes]} {
            dict for {process start} $processes {
                set now [_scriptJobSummaryProcess $process]
                if {$now eq {} || [dict get $now start] ne $start || [dict get $now state] in {Z X}} {dict unset processes $process}
            }
            if {![dict size $processes]} break
            if {[clock milliseconds]>=$deadline} {error {Job observation is still retiring; retry plugin management after it closes.}}
            # Bounded retirement wait only, not a polling observer/scheduler.
            after 10
        }
    } on error {message options} {
        _scriptJobSummaryResume $lease
        return -options $options $message
    }
    return $lease
}
proc ::GX::_scriptJobSummaryResume {lease} {
    if {![dict exists $::GX::JobSummary::suspensions $lease]} return
    dict unset ::GX::JobSummary::suspensions $lease
    if {[dict size $::GX::JobSummary::suspensions]} return
    foreach token [dict keys $::GX::JobSummary::subscriptions] {
        if {[catch {_scriptJobSummaryStart $token} failure]} {
            catch {_scriptJobSummaryLocalReady $token [dict create ok 0 error $failure error_type summary_transport]}
        }
    }
}

# HOST_ONLY_JUSTIFIED: token ownership is this interpreter's exact monitor;
# unsubscribe closes its pipe only and cannot alter any durable Job state.
proc ::GX::scriptJobSummaryUnsubscribe {token} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} {return 0}
    set pipe [dict get $::GX::JobSummary::subscriptions $token pipe]
    set remote [dict get $::GX::JobSummary::subscriptions $token remote_token]
    set widget [dict get $::GX::JobSummary::subscriptions $token widget]
    set destroyTag [dict get $::GX::JobSummary::subscriptions $token destroy_tag]
    dict unset ::GX::JobSummary::subscriptions $token
    catch {
        if {[winfo exists $widget]} {
            set keep {};foreach tag [bindtags $widget] {if {$tag ne $destroyTag} {lappend keep $tag}}
            bindtags $widget $keep
        }
    }
    catch {bind $destroyTag <Destroy> {}}
    catch {fileevent $pipe readable {}};catch {close $pipe}
    if {$remote ne {}} {catch {_scriptJobSummaryRemoteUnsubscribe $remote}}
    return 1
}

proc ::GX::_scriptJobSummaryDestroyed {token widget destroyed} {
    if {$widget eq $destroyed} {scriptJobSummaryUnsubscribe $token}
}

proc ::GX::_scriptJobSummaryDeliver {token response} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} return
    set entry [dict get $::GX::JobSummary::subscriptions $token]
    if {![winfo exists [dict get $entry widget]]} {scriptJobSummaryUnsubscribe $token;return}
    catch {uplevel #0 [list {*}[dict get $entry callback] $response]}
}

proc ::GX::_scriptJobSummaryLocalReady {token response} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} return
    if {[dict get $response ok]} {
        set value [dict get $response result]
        dict set value available [expr {[dict get $value availability] eq {AVAILABLE} && [dict get $value complete]}]
        dict set value established [dict get $value available]
        dict set value lost_connections 0;dict set value diagnostic {}
    } else {
        set established [dict get $::GX::JobSummary::subscriptions $token local established]
        set lost [expr {$established && [dict exists $response error_type] && [dict get $response error_type] eq {summary_transport}}]
        set value [dict create available 0 complete 0 availability UNKNOWN established $established running {} queued {} failed {} interrupted {} unknown {} sequence 0 diagnostic [dict get $response error] lost_connections $lost]
    }
    dict set ::GX::JobSummary::subscriptions $token local $value
    _scriptJobSummaryCompose $token
}

proc ::GX::_scriptJobSummaryRemoteReady {token expectedGeneration response} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} return
    if {[dict get $::GX::JobSummary::subscriptions $token transport_generation]!=$expectedGeneration} return
    if {[dict get $response ok]} {set value [dict get $response result]} else {
        set value [dict create available 0 complete 0 running {} queued {} failed {} interrupted {} unknown_jobs {} unknown_nodes {} unavailable_routes {} lost_connections 0 sequence {} diagnostic [dict get $response error]]
    }
    dict set ::GX::JobSummary::subscriptions $token remote $value
    _scriptJobSummaryCompose $token
}

proc ::GX::_scriptJobSummaryCompose {token} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} return
    set entry [dict get $::GX::JobSummary::subscriptions $token]
    set local [dict get $entry local];set remote [dict get $entry remote]
    set failed 0;set interrupted 0
    foreach value [list $local $remote] {
        foreach key {failed interrupted} {if {[dict exists $value $key] && [string is entier -strict [dict get $value $key]]} {incr $key [dict get $value $key]}}
    }
    set lost [dict get $local lost_connections]
    if {[dict exists $remote lost_connections] && [string is entier -strict [dict get $remote lost_connections]]} {incr lost [dict get $remote lost_connections]}
    set unknown 0
    if {[string is entier -strict [dict get $local unknown]]} {incr unknown [dict get $local unknown]}
    if {[dict exists $remote unknown_jobs] && [string is entier -strict [dict get $remote unknown_jobs]]} {incr unknown [dict get $remote unknown_jobs]}
    set unavailable [expr {![dict get $local available]}]
    if {[dict exists $remote unavailable_routes] && [string is entier -strict [dict get $remote unavailable_routes]]} {incr unavailable [dict get $remote unavailable_routes]}
    set diagnostic {}
    foreach value [list $local $remote] {if {[dict exists $value diagnostic] && [dict get $value diagnostic] ne {}} {lappend diagnostic [dict get $value diagnostic]}}
    set complete [expr {[dict get $local available] && [dict get $remote available]}]
    set result [dict create schema gxtxt.operational_job_summary.v1 sequence [dict create local [dict get $local sequence] remote [dict get $remote sequence]] \
        local $local remote $remote attention [dict create failed $failed interrupted $interrupted unknown_jobs $unknown unavailable_routes $unavailable lost_connections $lost complete $complete diagnostic [join $diagnostic {; }]]]
    _scriptJobSummaryDeliver $token [dict create ok 1 result $result]
}

proc ::GX::_scriptJobSummaryReadable {token expectedPipe expectedGeneration} {
    if {![dict exists $::GX::JobSummary::subscriptions $token]} return
    set entry [dict get $::GX::JobSummary::subscriptions $token];set pipe [dict get $entry pipe]
    if {$pipe eq {} || $pipe ne $expectedPipe || [dict get $entry transport_generation]!=$expectedGeneration} return
    set failure {};set failureType summary_protocol
    if {[catch {set chunk [read $pipe 16384]}]} {set failure {Job summary transport read failed};set failureType summary_transport} else {
        dict append entry buffer $chunk
        if {[string length [dict get $entry buffer]]>65536} {set failure {Job summary transport exceeded its byte bound}}
    }
    set latest {}
    if {$failure eq {}} {
        set data [dict get $entry buffer]
        while {[set newline [string first \n $data]]>=0} {
            set line [string range $data 0 [expr {$newline-1}]];set data [string range $data [expr {$newline+1}] end]
            if {$line eq {}} continue
            if {[string length $line]>16384 || [catch {
                set value [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [encoding convertfrom utf-8 [binary decode base64 -strict $line]]]]
                if {[dict get $value schema] ne {gxtxt.job_summary.v1} || [dict get $value node_id] ne {local} || [dict get $value availability] ne {AVAILABLE}} {error {Invalid Job summary envelope}}
                foreach key {sequence total active running queued failed interrupted unknown attention} {
                    if {![string is entier -strict [dict get $value $key]] || [dict get $value $key]<0} {error {Invalid Job summary count}}
                }
            }]} {set failure {Invalid Job summary transport frame};break}
            set latest $value
        }
        dict set entry buffer $data
        dict set ::GX::JobSummary::subscriptions $token $entry
        if {$latest ne {}} {_scriptJobSummaryLocalReady $token [dict create ok 1 result $latest]}
        if {![dict exists $::GX::JobSummary::subscriptions $token] || [dict get $::GX::JobSummary::subscriptions $token pipe] ne $pipe || [dict get $::GX::JobSummary::subscriptions $token transport_generation]!=$expectedGeneration} return
        # A callback can dispose/recreate the widget or its own monitor. Never
        # restore the captured entry after callback mutation.
        if {$failure eq {} && [eof $pipe]} {set failure {Job summary transport closed; retained counts require reconnection};set failureType summary_transport}
    }
    if {$failure ne {}} {
        # Retain the composite monitor/remote coverage while retiring only the
        # failed local stream. Explicit disposal still closes both listeners.
        catch {fileevent $pipe readable {}};catch {close $pipe}
        dict set ::GX::JobSummary::subscriptions $token pipe {}
        _scriptJobSummaryLocalReady $token [dict create ok 0 error $failure error_type $failureType]
    }
}
source [file join [file dirname [info script]] script_job_summary_remote_v1.tcl]
