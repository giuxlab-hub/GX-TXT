# SPDX-License-Identifier: GPL-3.0-or-later
# Generic frontend adapter to the existing Script Project, Bridge and Job owners.
# Host-only admission below reads installed package sources and binds the actual
# GUI lifetime. Scripts receive no source paths, credentials or private Tcl eval.
namespace eval ::GX::ViewerScriptBridge {variable serial 0;variable listeners {};variable clientIdentity {};variable clientPid 0}

proc ::GX::viewerScriptBridgeApiInfo {} {
    # Script Bridge exposure: HOST_ONLY_JUSTIFIED. Exact adapter operations:
    # list, describe, require, call, run, status, cancel, result, read_resource,
    # subscribe, unsubscribe, reconnect. These entrypoints bind an actual
    # admitted Tk Viewer window/lifetime and dispatch on its owning event loop;
    # a worker-script context has neither GUI window authority nor Host callback
    # lifetime. Safe script clients already use gxtxt_api_list/describe/require/
    # call directly on the SAME provider registry and ordinary Script Job APIs;
    # this Host adapter must not export GUI handles or recursive Host invocation.
    # request_bytes_max retains the legacy inline endpoint metadata only.
    # Host::script_bridge automatically uses the original Resource/Job owners
    # for larger control values; no API/provider operation gets another cap.
    return [dict create api_id VIEWER_SCRIPT_BRIDGE_API_v1 api_version 1 host_only 1 admission_owner SCRIPT_BRIDGE_PROVIDER execution_owner SCRIPT_JOB_API_v1 project_owner SCRIPT_EXECUTION_API_v1 operations {list describe require call run status cancel result read_resource subscribe unsubscribe reconnect} callback __script_bridge_event__ request_bytes_max 49152 request_bytes_max_scope inline_only resource_transport 1 request_inline_bytes_max 49152 request_resource_owner RESOURCE_MANAGEMENT_API_v1 result_retention_owner SCRIPT_JOB_API_v1 generic_api_operation_whitelist 0]
}
# Fixed captured CORE scope for the existing trusted broker. Application
# argument markers never create this scope or select resource transport.
proc ::GX::_viewerBridgeControlScope {context} {
    set fields {}
    foreach key {module session lifetime client_identity session_directory session_origin} {dict set fields $key [list text [dict get $context $key]]}
    dict set fields client_pid [list int [dict get $context client_pid]]
    file stat [dict get $context session] info
    foreach {key value} [list session_device $info(dev) session_inode $info(ino)] {dict set fields $key [list int $value]}
    dict set fields resource_root [list text [resourceManagementRoot]]
    if {[info exists ::env(GXTXT_RESOURCE_STORAGE)] && $::env(GXTXT_RESOURCE_STORAGE) ne {}} {set storage $::env(GXTXT_RESOURCE_STORAGE)} else {set storage [file join [configurationTempDirectory] resources-v1]}
    dict set fields resource_storage [list text $storage]
    return [nativeWorkspaceJsonEncode [list object $fields]]
}
proc ::GX::_viewerBridgeJson {typed} {return [nativeWorkspaceJsonEncode $typed]}
proc ::GX::_viewerBridgeString {value} {return [list text $value]}
proc ::GX::_viewerBridgeReceipt {action status fields} {
    dict set fields schema {text gxtxt.viewer_bridge_receipt.v1}
    dict set fields operation [list text $action]
    dict set fields status [list text $status]
    return [list object $fields]
}
proc ::GX::_viewerBridgeNotify {window lifetime typed} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime || ![viewerGuiDesignGuard $window]} return
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    set pending [datasetPublicationV2DictDefault $r script_bridge_pending_events {}]
    lappend pending $typed
    if {[llength $pending]>512} {
        # Journal replay/status is the recovery authority for an overrun. Never
        # overwrite a terminal result with a fabricated successful callback.
        set pending [list [_viewerBridgeReceipt event recovery_required [dict create error {text {Viewer callback backlog exceeded; reconnect by retained sequence}}]]]
    }
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_pending_events $pending
    viewerScriptBridgeDrain $window
}
proc ::GX::viewerScriptBridgeDrain {window} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict get $r busy] ne {} || ![llength [datasetPublicationV2DictDefault $r script_bridge_pending_events {}]] || [datasetPublicationV2DictDefault $r script_bridge_dispatch_scheduled 0]} return
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_dispatch_scheduled 1
    after idle [list ::GX::_viewerBridgeCallback $window [dict get $r lifetime]]
}
proc ::GX::_viewerBridgeCallback {window lifetime} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime || ![viewerGuiDesignGuard $window]} return
    if {[dict get $::GX::ViewerDevelopment::windows $window busy] ne {}} {
        # Existing Host event completion calls Drain; no status or busy timer.
        dict set ::GX::ViewerDevelopment::windows $window script_bridge_dispatch_scheduled 0
        return
    }
    set pending [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] script_bridge_pending_events {}]
    if {![llength $pending]} {dict set ::GX::ViewerDevelopment::windows $window script_bridge_dispatch_scheduled 0;return}
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_result [lindex $pending 0]
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_pending_events [lrange $pending 1 end]
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_dispatch_scheduled 0
    viewerDevelopmentInvoke $window __script_bridge_event__
}
proc ::GX::_viewerBridgeCurrent {window} {
    set r [_viewerNativeClientBase $window]
    if {[_viewerDevelopmentSnapshot [dict get $r project]] ne [dict get $r validated_snapshot] || [_viewerNativeClientPackageSnapshot [dict get $r runtime_module_root]] ne [dict get $r native_client_package_snapshot]} {error {Viewer Script Bridge package/source changed; reopen the updated module}}
    return $r
}
# Host-only captured metadata for the existing managed auxiliary request owner.
# It grants no window authority to the child and contains no caller-selected code.
proc ::GX::_viewerBridgeContext {window r {action {}} {typed {}}} {
    set context {}
    foreach key {module project runtime_module_root validated_snapshot native_client_package_snapshot lifetime open_context} {dict set context $key [dict get $r $key]}
    dict set context session $::GX::currentSession
    dict set context session_token [interactiveDocumentSessionToken]
    dict set context session_directory $::GX::DocumentSessionScope::identity
    dict set context session_origin [sessionOriginRead $::GX::currentSession]
    dict set context job_root [scriptJobRoot]
    dict set context module_selection [join [selectedModuleIds] ,]
    set moduleConfig {};foreach module {analysis.python_script analysis.octave_script} {foreach key [array names ::GX::moduleCfg "$module,*"] {dict set moduleConfig $key $::GX::moduleCfg($key)}}
    dict set context module_config $moduleConfig
    dict set context client_pid [pid]
    dict set context client_identity [expr {$::GX::ViewerScriptBridge::clientPid==[pid]?$::GX::ViewerScriptBridge::clientIdentity:{}}]
    set live {};dict for {other candidate} $::GX::ViewerDevelopment::windows {if {[dict exists $candidate lifetime]} {lappend live [dict get $candidate lifetime]}}
    dict set context live_instances $live
    dict set context request_id "viewer-bridge-request#[pid]-[incr ::GX::ViewerScriptBridge::serial]"
    set open [dict get $r open_context]
    if {[dict exists $open document_id] && [dict get $open document_id] ne {}} {dict set context document_identity [interactiveDocumentMetadata [dict get $open document_id]]}
    set inputs {}
    if {$action in {list describe require call run}} {
        set request [nativeWorkspaceDecode $typed]
        set inputs [datasetPublicationV2DictDefault $request inputs {}]
        if {[dict exists $open dataset_id] && [dict get $open dataset_id] ne {} && ![dict size $inputs]} {dict set inputs source [dict create dataset_id [dict get $open dataset_id]]}
        # Capture the same actual host review revision before asynchronous work.
        if {[dict size $inputs]} {set inputs [scriptJobInputsResolve $::GX::currentSession $inputs]}
    }
    dict set context inputs_snapshot $inputs
    dict set context script_bridge_context_abi [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $r compiled_service_receipt {}] script_bridge_context_abi 1]
    return $context
}
proc ::GX::_viewerBridgeContextCurrent {window context} {
    set r [_viewerBridgeCurrent $window]
    if {[dict get $r lifetime] ne [dict get $context lifetime] || [dict get $r module] ne [dict get $context module] || [dict get $r runtime_module_root] ne [dict get $context runtime_module_root] || [dict get $r validated_snapshot] ne [dict get $context validated_snapshot] || [dict get $r native_client_package_snapshot] ne [dict get $context native_client_package_snapshot] || $::GX::currentSession ne [dict get $context session] || [interactiveDocumentSessionToken] ne [dict get $context session_token]} {error {Viewer Script Bridge lifetime or admitted source changed during its managed request}}
    if {[dict exists $context document_identity]} {
        set expected [dict get $context document_identity];set current [interactiveDocumentMetadata [dict get $expected id]]
        foreach key {generation revision sha256} {if {[dict get $current $key] ne [dict get $expected $key]} {error {Viewer Script Bridge source Document changed during its managed request}}}
    }
    return $r
}
proc ::GX::_viewerBridgeCapturedClaim {job context row reconnect} {
    if {$reconnect && [dict exists $row client_owner]} {
        set owner [dict get $row client_owner]
        if {[dict get $owner pid]==[dict get $context client_pid] && [dict get $owner process] eq [dict get $context client_identity] && [dict get $owner instance] ne [dict get $context lifetime] && [dict get $owner instance] ni [dict get $context live_instances]} {
            # Absence from an old snapshot does not prove disposal: a new View
            # may have opened after dispatch. The real GUI must review this
            # exact current owner before the child may transfer it.
            set reviewed [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $context owner_reviews {}] $job {}]
            set same [expr {$reviewed ne {}}]
            foreach key {pid process instance} {if {!$same || ![dict exists $reviewed $key] || [dict get $reviewed $key] ne [dict get $owner $key]} {set same 0}}
            if {!$same} {return -code error -errorcode [list GXTXT VIEWER OWNER_REFRESH $job $owner] {Viewer ownership requires a current live-instance review}}
        }
    }
    return [_viewerJobClientClaimCaptured $job [dict get $context module] [dict get $context client_pid] [dict get $context client_identity] [dict get $context lifetime] [dict get $context live_instances] $row $reconnect]
}
proc ::GX::_viewerBridgeRequest {window context mode action typed callback} {
    if {[dict get $context client_identity] eq {}} {
        # Capture the immutable parent identity while its actual GUI is alive.
        # Computing a new identity for a stale captured PID in the child would
        # permit PID reuse to change the proposed client authority.
        set command [scriptJobCommand process_identity [dict get $context client_pid]]
        set token [scriptJobAsync $command {} [list ::GX::_viewerBridgeIdentityReady $window $context $mode $action $typed $callback] {timeout_ms 15000 max_bytes 8192 ui_lifetime 1 label {Viewer client identity}}]
    } else {
    set request [dict create schema gxtxt.viewer_bridge_request.v1 context $context mode $mode action $action typed $typed]
    set command [list [auto_execok tclsh] [file join $::GX::scriptDir core tcl viewer_script_bridge_request_v1.tcl] $::GX::scriptDir]
    set group [auto_execok setsid]
    if {$group eq {}} {error {Managed Viewer admission requires its owned process group}}
    set command [list {*}$group {*}$command]
    if {[dict exists $context control_source]} {
        set source [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [dict get $context control_source]]]
        set command [list env GXTXT_RESOURCE_LEASE=[dict get $source descriptor resource_id] GXTXT_RESOURCE_ROOT=[resourceManagementRoot] {*}$command]
    }
    set token [scriptJobAsync $command $request [list ::GX::_viewerBridgeRequestResult $window $context $mode $action $typed $callback] {timeout_ms 60000 max_bytes 4194304 process_group 1 ui_lifetime 1 label {Viewer Script Bridge admission}}]
    }
    if {[dict exists $::GX::ViewerDevelopment::windows $window]} {
        set active {};foreach prior [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] script_bridge_requests {}] {if {[dict exists $::GX::scriptJobRequests $prior]} {lappend active $prior}}
        dict set ::GX::ViewerDevelopment::windows $window script_bridge_requests [concat $active [list $token]]
    }
    return $token
}
proc ::GX::_viewerBridgeRequestResult {window context mode action typed callback response} {
    set code [datasetPublicationV2DictDefault $response error_code {}]
    if {![dict get $response ok] && [llength $code]==5 && [lrange $code 0 2] eq {GXTXT VIEWER OWNER_REFRESH}} {
        if {![dict exists $::GX::ViewerDevelopment::windows $window] || [catch {_viewerBridgeContextCurrent $window $context}]} return
        set job [lindex $code 3];set owner [lindex $code 4]
        if {$mode eq {lifecycle_control}} {
            set fields {}
            if {[dict exists $context control_job_id]} {dict set fields job_id [dict get $context control_job_id]}
        } else {set fields [nativeWorkspaceDecode $typed]}
        set valid [expr {$action eq {reconnect} && [dict exists $fields job_id] && [dict get $fields job_id] eq $job && [dict get $owner pid]==[dict get $context client_pid] && [dict get $owner process] eq [dict get $context client_identity]}]
        set live {};dict for {other candidate} $::GX::ViewerDevelopment::windows {if {[dict exists $candidate lifetime]} {lappend live [dict get $candidate lifetime]}}
        if {!$valid || [dict get $owner instance] in $live} {
            set response [dict create ok 0 error {Job belongs to another live Viewer instance}]
        } elseif {[datasetPublicationV2DictDefault $context owner_refreshes 0]>=2} {
            set response [dict create ok 0 error {Job ownership changed during admission; explicitly reconnect again}]
        } else {
            dict set context live_instances $live
            dict set context owner_reviews $job $owner
            dict incr context owner_refreshes
            if {[catch {_viewerBridgeRequest $window $context $mode $action $typed $callback} message]} {uplevel #0 [list {*}$callback [dict create ok 0 error $message]]}
            return
        }
    }
    uplevel #0 [list {*}$callback $response]
}
proc ::GX::_viewerBridgeIdentityReady {window context mode action typed callback response} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [catch {_viewerBridgeContextCurrent $window $context}]} return
    if {![dict get $response ok] || [dict get $response result] eq {}} {
        uplevel #0 [list {*}$callback [dict create ok 0 error {Viewer client process identity is unavailable}]]
        return
    }
    set ::GX::ViewerScriptBridge::clientPid [pid]
    set ::GX::ViewerScriptBridge::clientIdentity [dict get $response result]
    dict set context client_identity $::GX::ViewerScriptBridge::clientIdentity
    if {[catch {_viewerBridgeRequest $window $context $mode $action $typed $callback} message]} {uplevel #0 [list {*}$callback [dict create ok 0 error $message]]}
}
# Only the fixed CORE bootstrap calls this finite data operation. It restores
# the captured live Module/Session context, never a fake GUI window/interpreter.
proc ::GX::viewerScriptBridgeWorker {request} {
    set context [dict get $request context];set action [dict get $request action];set typed [dict get $request typed]
    interactiveDocumentSessionToken
    if {$::GX::DocumentSessionScope::identity ne [dict get $context session_directory]} {error {Viewer Script Bridge Session directory changed before managed admission}}
    if {[sessionOriginRead $::GX::currentSession] ne [dict get $context session_origin]} {error {Viewer Script Bridge originating Session changed before managed admission}}
    set module [dict get $context module]
    if {![moduleIsEnabled $module] || [file normalize [file dirname [moduleField $module descriptor {}]]] ne [file normalize [dict get $context runtime_module_root]]} {error {Viewer Script Bridge actual module changed}}
    if {[_viewerDevelopmentSnapshot [dict get $context project]] ne [dict get $context validated_snapshot] || [_viewerNativeClientPackageSnapshot [dict get $context runtime_module_root]] ne [dict get $context native_client_package_snapshot]} {error {Viewer Script Bridge source/package changed before managed admission}}
    if {[dict get $request mode] eq {lifecycle_control}} {
        set helper [file join $::GX::scriptDir core python viewer_bridge_control_v1.py]
        set typed [nativeWorkspaceJsonDecode [exec [runtimeToolRequired python] -B $helper packet << [dict get $context control_source]]]
        set controlFields [nativeWorkspaceDecode $typed]
        if {![dict exists $context control_job_id] || ![dict exists $controlFields job_id] || [dict get $controlFields job_id] ne [dict get $context control_job_id]} {error {Lifecycle control Job differs from its authenticated captured header}}
        dict set request mode lifecycle
    }
    if {[dict get $request mode] eq {native}} {return [viewerNativeJobWorker $context $action $typed]}
    if {[dict get $request mode] eq {prepare_control}} {
        # Full control bytes remain in the original trusted Python preparer;
        # Tcl receives source/ref/input metadata, never the large argument tree.
        return [viewerScriptBridgeInvocationPrepare $context $action {object {}}]
    }
    if {[dict get $request mode] eq {prepare}} {return [viewerScriptBridgeInvocationPrepare $context $action $typed]}
    if {[dict get $request mode] ni {event lifecycle accepted}} {error {Unknown Viewer Script Bridge managed request mode}}
    set fields [nativeWorkspaceDecode $typed];set job [dict get $fields job_id]
    set row [viewerScriptBridgeOwnedRecord $job $module]
    _viewerBridgeCapturedClaim $job $context $row [expr {$action eq {reconnect}}]
    set invocation [dict get $row execution_inputs provided_api]
    set common [dict create job_id $job state [dict get $row state] inputs [dict get $row inputs] source_guard [dict get $invocation guard]]
    if {[dict get $request mode] in {event accepted}} {return $common}
    switch -- $action {
        status {set receipt [_viewerBridgeReceipt $action completed [lindex [_viewerBridgeStatusTyped $row] 1]]}
        cancel {scriptJobCancel $job;set receipt [_viewerBridgeReceipt $action requested [dict create job_id [list text $job]]]}
        subscribe - reconnect {set receipt [_viewerBridgeReceipt $action subscribed [dict create job_id [list text $job]]]}
        unsubscribe {set receipt [_viewerBridgeReceipt $action unsubscribed [dict create job_id [list text $job]]]}
        result - read_resource {
            if {[dict get $row state] ne {COMPLETED}} {error {Only a Completed Job has an accepted result}}
            set helper [file join $::GX::scriptDir core python viewer_bridge_control_v1.py]
            set payload [dict create output [list text [dict get $row output_dir]] action [list text $action] job_id [list text $job] request_id [list text [dict get $context request_id]] scope [nativeWorkspaceJsonDecode [_viewerBridgeControlScope $context]] request_json [list text [dict get $invocation request_json]] control_input [list bool [dict exists $invocation request_control]]]
            if {[dict exists $invocation request_control]} {dict set payload manifest_sha256 [list text [dict get $row execution_inputs viewer_control_snapshot manifest_sha256]]}
            dict set payload context_abi [list int [dict get $context script_bridge_context_abi]]
            if {$action eq {read_resource}} {dict set payload page $typed}
            set receipt [nativeWorkspaceJsonDecode [exec [runtimeToolRequired python] -B $helper receipt << [nativeWorkspaceJsonEncode [list object $payload]]]]
        }
        default {error {Unknown generic Script Bridge frontend action}}
    }
    dict set common receipt $receipt
    return $common
}
proc ::GX::_viewerBridgeReplyCurrent {window context reply} {
    _viewerBridgeContextCurrent $window $context
    if {[dict exists $reply source_guard source_identities]} {
        set identities [dict get $reply source_guard source_identities]
        if {[dict exists $identities workspace]} {
            set expected [dict get $identities workspace];set current [interactiveDocumentMetadata [dict get $expected id]]
            foreach key {generation revision sha256} {if {[dict get $current $key] ne [dict get $expected $key]} {error {Viewer Script Bridge originating Document changed before callback}}}
        }
        if {[dict exists $identities datasets]} {_scientificExecutionSourcesCurrent [dict create datasets [dict get $identities datasets]]}
    }
    if {[dict exists $reply inputs]} {
        dict for {alias binding} [dict get $reply inputs] {
            set id [dict get $binding dataset_id]
            if {[dict get $binding revision] ne [datasetRevisionToken $id $::GX::currentSession] || [dict get $binding namespace] ne [datasetNamespaceGet $::GX::currentSession $id]} {error {Viewer Script Bridge bound Dataset changed before callback}}
        }
    }
}
proc ::GX::viewerScriptBridgeProjectAdmission {invocation} {
    foreach key {kind module_id action request_json guard} {if {![dict exists $invocation $key]} {error {Incomplete Viewer Script Project invocation}}}
    if {[dict get $invocation kind] ne {viewer_project}} {error {Unknown Viewer Script Project kind}}
    set module [dict get $invocation module_id]
    if {![moduleIsEnabled $module] || [moduleField $module descriptor {}] eq {}} {error {Viewer Script Bridge module is not installed and enabled}}
    set root [file dirname [moduleField $module descriptor]]
    if {[file normalize $root] ne [file normalize [file join $::GX::scriptDir plugins modules $module]]} {error {Viewer Script Bridge requires its normal installed module root}}
    set guard [dict get $invocation guard]
    if {[dict get $guard module_id] ne $module || [dict get $guard session_origin] ne [sessionOriginRead $::GX::currentSession]} {error {Viewer Script Bridge Session/module changed before admission}}
    if {![dict exists $guard session_identity] || [dict get $guard session_identity] ne [_scientificExecutionRemoteSessionFingerprint]} {error {Viewer Script Bridge Session directory was replaced or relocated}}
    if {[dict exists $guard source_identities]} {_scientificExecutionSourcesCurrent [dict get $guard source_identities]}
    set adapter [file join $::GX::scriptDir core python viewer_bridge_request_v1.py]
    if {[dict exists $invocation request_control_snapshot]} {
        set result [exec [runtimeToolRequired python] -B $adapter admit_frozen $root $module [dict get $invocation action] << [dict get $invocation request_control_snapshot]]
    } elseif {[dict exists $invocation request_control]} {
        set result [exec [runtimeToolRequired python] -B $adapter admit_control $root $module [dict get $invocation action] << [dict get $invocation request_control]]
    } else {
    set result [exec [runtimeToolRequired python] -B $adapter admit $root $module [dict get $invocation action] << [dict get $invocation request_json]]
    }
    if {[dict get $result pins source_tree_sha256] ne [dict get $guard source_tree_sha256]} {error {Viewer Script Bridge source changed after submission}}
    if {[dict get $result input_references] ne [datasetPublicationV2DictDefault $invocation input_references {}]} {error {Viewer Script Bridge input references changed after submission}}
    dict set result module_info [dict create version [moduleField $module version {}]]
    set schema [scriptSourceParametersMerge [dict get $result parameters] [dict get $result source_parameters] [dict get $result project_sha256]]
    dict set result parameters $schema
    return $result
}
proc ::GX::_viewerBridgeInvocation {window action typed} {
    set r [_viewerBridgeCurrent $window]
    return [viewerScriptBridgeInvocationPrepare [_viewerBridgeContext $window $r $action $typed] $action $typed]
}
proc ::GX::viewerScriptBridgeInvocationPrepare {r action typed} {
    set module [dict get $r module]
    set request [nativeWorkspaceDecode $typed]
    set guard [dict create module_id $module session_origin [sessionOriginRead $::GX::currentSession] session_identity [_scientificExecutionRemoteSessionFingerprint] source_tree_sha256 {}]
    set context [dict get $r open_context]
    if {[dict exists $r document_identity]} {
        dict set guard source_identities workspace [dict get $r document_identity]
        _scientificExecutionSourcesCurrent [dict get $guard source_identities]
    }
    # The trusted project owner recomputes the exact source closure; a caller
    # cannot submit an arbitrary script body, path or entrypoint declaration.
    set adapter [file join $::GX::scriptDir core python viewer_bridge_request_v1.py]
    if {[dict exists $r control_source]} {
        set admission [exec [runtimeToolRequired python] -B $adapter admit_control [dict get $r runtime_module_root] $module $action << [dict get $r control_source]]
        if {[dict exists $admission control_inputs]} {dict set r inputs_snapshot [scriptJobInputsResolve $::GX::currentSession [dict get $admission control_inputs]]}
    } else {
    set admission [exec [runtimeToolRequired python] -B $adapter admit [dict get $r runtime_module_root] $module $action << [_viewerBridgeJson $typed]]
    }
    dict set guard source_tree_sha256 [dict get $admission pins source_tree_sha256]
    set invocation [dict create kind viewer_project module_id $module action $action request_json [_viewerBridgeJson $typed] guard $guard expected [dict get $admission pins]]
    if {[dict exists $r control_source]} {
        dict set invocation request_control [dict get $r control_source]
        dict set invocation request_json {{}}
    }
    dict set invocation invocation_id [dict get $r request_id]
    dict set invocation input_references [dict get $admission input_references]
    foreach reference [dict get $admission input_references] {
        set source [viewerScriptBridgeInputSource [dict get $reference job_id] $module]
        _viewerBridgeCapturedClaim [dict get $reference job_id] $r $source 0
        if {[dict get $source state] ne {COMPLETED}} {error {Managed input requires a Completed retained Job}}
    }
    set parameters {}
    if {$action eq {run}} {
        set parameters [datasetPublicationV2DictDefault $request parameters {}]
    } else {
        set payload [list object [dict create action [list text $action] request $typed]]
        dict set parameters request_json [exec [runtimeToolRequired python] -B $adapter encode_wire [dict get $admission language] << [_viewerBridgeJson $payload]]
    }
    if {[dict exists $r control_source]} {
        if {$action eq {run}} {set parameters {}} else {set parameters [dict create request_json __GXTXT_FROZEN_CONTROL__]}
    }
    set inputs [dict get $r inputs_snapshot]
    set inputs [scriptJobInputsResolve $::GX::currentSession $inputs]
    return [dict create invocation $invocation parameters $parameters inputs $inputs]
}
proc ::GX::viewerScriptBridgeOwnedRecord {job module} {
    set row [scriptJobDescribe $job]
    if {![dict exists $row execution_inputs provided_api]} {error {Job has no Viewer Script Bridge invocation}}
    set invocation [dict get $row execution_inputs provided_api]
    if {[dict get $invocation kind] ne {viewer_project} || [dict get $invocation module_id] ne $module || [file normalize [dict get $row session]] ne [file normalize $::GX::currentSession]} {error {Job belongs to another Viewer or Session}}
    if {[dict exists $invocation request_control]} {
        # After capture acknowledgment the temporary upload may be released.
        # Retained readmission uses this Job's original immutable input SHA,
        # never a previous GUI's transient allocation or process lifetime.
        dict set invocation request_control_snapshot [nativeWorkspaceJsonEncode [list object [dict create output [list text [dict get $row output_dir]] manifest_sha256 [list text [dict get $row execution_inputs viewer_control_snapshot manifest_sha256]]]]]
    }
    set admission [viewerScriptBridgeProjectAdmission $invocation]
    if {[dict get $admission pins] ne [dict get $invocation expected]} {error {Retained Job source/package changed}}
    scriptJobInputsResolve $::GX::currentSession [dict get $row inputs]
    return $row
}
proc ::GX::_viewerBridgeJob {window job {reconnect 0}} {
    set r [_viewerBridgeCurrent $window]
    set row [viewerScriptBridgeOwnedRecord $job [dict get $r module]]
    viewerJobClientClaim $window $job $reconnect
    return $row
}
proc ::GX::viewerScriptBridgeInputSource {job module} {
    set row [scriptJobDescribe $job]
    if {[dict exists $row execution_inputs provided_api] && [datasetPublicationV2DictDefault [dict get $row execution_inputs provided_api] kind {}] eq {viewer_project}} {
        return [viewerScriptBridgeOwnedRecord $job $module]
    }
    # Native computations project their validated retained bytes through the
    # same binary descriptor and Job retention. Their existing owner enforces
    # module/Session/Document/source/artifact guards before any input snapshot.
    set row [_nativeJobOwned $job $module]
    if {![dict exists $row output_dir]} {error {Materialize remote native buffers through the registered read_buffer operation before local reuse}}
    return $row
}
proc ::GX::viewerScriptBridgeFreezeInputs {invocation output} {
    if {[dict exists $invocation request_control]} {
        set args {array {}}
    } else {
        set request [nativeWorkspaceJsonDecode [dict get $invocation request_json]]
        set args [dict get [lindex $request 1] args]
    }
    set sources {}
    foreach reference [dict get $invocation input_references] {
        set job [dict get $reference job_id]
        set row [viewerScriptBridgeInputSource $job [dict get $invocation module_id]]
        if {[dict get $row state] ne {COMPLETED}} {error {Managed input source is not a Completed retained Job}}
        dict set sources $job [list object [dict create output_dir [list text [dict get $row output_dir]]]]
    }
    set payload [list object [dict create args $args sources [list object $sources]]]
    set adapter [file join $::GX::scriptDir core python viewer_bridge_request_v1.py]
    if {[dict exists $invocation request_control]} {
        set fields [lindex $payload 1];dict set fields control [nativeWorkspaceJsonDecode [dict get $invocation request_control]]
        return [exec [runtimeToolRequired python] -B $adapter freeze_control_inputs $output << [nativeWorkspaceJsonEncode [list object $fields]]]
    }
    return [exec [runtimeToolRequired python] -B $adapter freeze_inputs $output << [nativeWorkspaceJsonEncode $payload]]
}
proc ::GX::_viewerBridgeStatusTyped {row} {
    set fields {}
    foreach key {id state error} {dict set fields [expr {$key eq {id}?{job_id}:$key}] [list text [datasetPublicationV2DictDefault $row $key {}]]}
    dict set fields terminal [list bool [expr {[dict get $row state] in {COMPLETED FAILED CANCELLED INTERRUPTED}}]]
    dict set fields node_id {text local}
    return [list object $fields]
}
proc ::GX::_viewerBridgeSubscribe {window job {after 0}} {
    variable ::GX::ViewerScriptBridge::listeners
    set lifetime [dict get $::GX::ViewerDevelopment::windows $window lifetime]
    set key [list $window $lifetime $job]
    if {[dict exists $listeners $key]} {scriptJobUnsubscribe [dict get $listeners $key]}
    dict set listeners $key [_scriptJobSubscribeAdmitted $job [list ::GX::_viewerBridgeEvent $window $lifetime $job] $after]
}
proc ::GX::_viewerBridgeEvent {window lifetime job event} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict exists $r script_bridge_status_terminal $job] && ![dict get $event terminal]} return
    set previous [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $r script_bridge_event_heads {}] $job {}]
    if {$previous ne {} && ([dict get $event sequence]<=[dict get $previous sequence] || [dict get $previous terminal])} return
    set pending [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $r script_bridge_validation_pending {}] $job {}]
    if {$pending ne {} && ([dict get $event sequence]<=[dict get $pending sequence] || [dict get $pending terminal])} return
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_validation_pending $job $event
    _viewerBridgeEventValidate $window $lifetime $job
}
proc ::GX::_viewerBridgeEventValidate {window lifetime job} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict get $r lifetime] ne $lifetime || [dict exists $r script_bridge_validating $job] || ![dict exists $r script_bridge_validation_pending $job]} return
    set event [dict get $r script_bridge_validation_pending $job]
    dict unset ::GX::ViewerDevelopment::windows $window script_bridge_validation_pending $job
    if {[catch {
        set context [_viewerBridgeContext $window [_viewerBridgeCurrent $window]]
        dict set ::GX::ViewerDevelopment::windows $window script_bridge_validating $job 1
        _viewerBridgeRequest $window $context event event [list object [dict create job_id [list text $job]]] [list ::GX::_viewerBridgeEventReady $window $lifetime $job $context $event]
    }]} {catch {dict unset ::GX::ViewerDevelopment::windows $window script_bridge_validating $job}}
}
proc ::GX::_viewerBridgeEventReady {window lifetime job context event response} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    catch {dict unset ::GX::ViewerDevelopment::windows $window script_bridge_validating $job}
    if {![dict get $response ok] || [catch {_viewerBridgeReplyCurrent $window $context [dict get $response result]}]} {
        # No unvalidated scientific/event receipt is admitted. Retire this
        # listener; retained status/result remains guarded by its owner.
        set key [list $window $lifetime $job]
        if {[dict exists $::GX::ViewerScriptBridge::listeners $key]} {catch {scriptJobUnsubscribe [dict get $::GX::ViewerScriptBridge::listeners $key]};dict unset ::GX::ViewerScriptBridge::listeners $key}
        catch {dict unset ::GX::ViewerDevelopment::windows $window script_bridge_validation_pending $job}
        return
    }
    set current [dict get $::GX::ViewerDevelopment::windows $window]
    set pending [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $current script_bridge_validation_pending {}] $job {}]
    # A terminal already queued behind this validation supersedes an old
    # progress sample. The terminal still passes its own full owner guard.
    if {$pending eq {} || ![dict get $pending terminal] || [dict get $event terminal]} {_viewerBridgeEventDeliver $window $lifetime $job $event}
    _viewerBridgeEventValidate $window $lifetime $job
}
proc ::GX::_viewerBridgeEventDeliver {window lifetime job event} {
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    set previous [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $r script_bridge_event_heads {}] $job {}]
    if {$previous ne {} && ([dict get $event sequence]<=[dict get $previous sequence] || [dict get $previous terminal])} return
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_event_heads $job [dict create sequence [dict get $event sequence] terminal [dict get $event terminal]]
    set fields [dict create job_id [list text $job] node_id {text local} module_id [list text [dict get $r module]] terminal [list bool [dict get $event terminal]]]
    foreach key {state stage event diagnostic source_sha256} {if {[dict exists $event $key]} {dict set fields $key [list text [dict get $event $key]]}}
    foreach key {sequence} {if {[dict exists $event $key]} {dict set fields $key [list int [dict get $event $key]]}}
    if {[dict exists $event progress fraction]} {
        set fraction [dict get $event progress fraction]
        if {[string is double -strict $fraction] && ![catch {expr {double($fraction)>=0.0 && double($fraction)<=1.0}} finite] && $finite} {
            dict set fields progress [list real $fraction]
            dict set fields progress_indeterminate {bool 0}
        } else {dict set fields progress_indeterminate {bool 1}}
    } else {dict set fields progress_indeterminate {bool 1}}
    _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt event delivered $fields]
}
proc ::GX::viewerScriptBridgeDispose {window} {
    variable ::GX::ViewerScriptBridge::listeners
    dict for {key token} $listeners {
        if {[lindex $key 0] eq $window} {catch {scriptJobUnsubscribe $token};dict unset listeners $key}
    }
    if {[dict exists $::GX::ViewerDevelopment::windows $window]} {foreach token [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] script_bridge_requests {}] {catch {scriptJobRequestCancel $token viewer_closed}}}
    # The existing Supervisor retains work/result and ownership for explicit
    # guarded reconnect. Disposal never cancels a retained computation.
}
proc ::GX::_viewerBridgePrepared {window context action submission response} {
    if {![dict get $response ok] || ![dict exists $::GX::ViewerDevelopment::windows $window]} {_viewerBridgeControlRelease $context}
    set lifetime [dict get $context lifetime]
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    if {![dict get $response ok] || [catch {_viewerBridgeContextCurrent $window $context}]} {
        set message [datasetPublicationV2DictDefault $response error {Viewer source or lifetime changed during preparation}]
        _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action failed [dict create submission_id [list text $submission] error [list text [_viewerNativeClientPublicMessage $message]]]]
        return
    }
    set prepared [dict get $response result]
    set options [dict create session [dict get $context session] package_invocation [dict get $prepared invocation] inputs [dict get $prepared inputs]]
    set leaseSaved {}
    if {[dict exists $context control_source]} {
        foreach key {GXTXT_RESOURCE_LEASE GXTXT_RESOURCE_ROOT} {dict set leaseSaved $key [list [info exists ::env($key)] [expr {[info exists ::env($key)]?$::env($key):{}}]]}
        set source [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [dict get $context control_source]]]
        set ::env(GXTXT_RESOURCE_LEASE) [dict get $source descriptor resource_id]
        set ::env(GXTXT_RESOURCE_ROOT) [resourceManagementRoot]
    }
    try {
    set failed [catch {scriptJobSubmit package:[dict get $context module] [dict get $prepared parameters] $options [list ::GX::_viewerBridgeAccepted $window $context $action $submission]} message]
    } finally {
        dict for {key saved} $leaseSaved {if {[lindex $saved 0]} {set ::env($key) [lindex $saved 1]} else {unset -nocomplain ::env($key)}}
    }
    if {$failed} {
        _viewerBridgeControlRelease $context
        _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action failed [dict create submission_id [list text $submission] error [list text [_viewerNativeClientPublicMessage $message]]]]
    }
}
proc ::GX::_viewerBridgeControlRelease {context} {
    if {![dict exists $context control_source]} return
    set source [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [dict get $context control_source]]]
    set id [dict get $source descriptor resource_id]
    if {![catch {resourceManagementRelease $id verified_orphan}]} {catch {resourceManagementCleanup [list $id]}}
}
proc ::GX::_viewerBridgeAccepted {window context action submission response} {
    _viewerBridgeControlRelease $context
    set lifetime [dict get $context lifetime]
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    if {![dict get $response ok]} {
        _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action failed [dict create submission_id [list text $submission] error [list text [_viewerNativeClientPublicMessage [dict get $response error]]]]]
        return
    }
    set row [dict get $response result]
    set job [dict get $row id]
    if {[catch {
        _viewerBridgeContextCurrent $window $context
        set current [_viewerBridgeContext $window [_viewerBridgeCurrent $window]]
        _viewerBridgeRequest $window $current accepted $action [list object [dict create job_id [list text $job]]] [list ::GX::_viewerBridgeAdmitted $window $current $action $submission]
    } message]} {
        _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action failed [dict create job_id [list text $job] error [list text [_viewerNativeClientPublicMessage $message]]]]
        return
    }
}
proc ::GX::_viewerBridgeAdmitted {window context action submission response} {
    set lifetime [dict get $context lifetime]
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    if {![dict get $response ok] || [catch {_viewerBridgeReplyCurrent $window $context [dict get $response result]} message]} {
        if {![dict get $response ok]} {set message [dict get $response error]}
        _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action failed [dict create submission_id [list text $submission] error [list text [_viewerNativeClientPublicMessage $message]]]]
        return
    }
    set result [dict get $response result];set job [dict get $result job_id]
    if {[dict get $result state] in {COMPLETED FAILED CANCELLED INTERRUPTED}} {dict set ::GX::ViewerDevelopment::windows $window script_bridge_status_terminal $job 1}
    _viewerBridgeSubscribe $window $job
    _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action accepted [dict create submission_id [list text $submission] job_id [list text $job] state [list text [dict get $result state]] node_id {text local}]]
}
proc ::GX::_viewerBridgeActionReady {window context action typed response} {
    _viewerBridgeControlRelease $context
    set lifetime [dict get $context lifetime]
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    set request [nativeWorkspaceDecode $typed];set job [dict get $request job_id]
    if {![dict get $response ok] || [catch {_viewerBridgeReplyCurrent $window $context [dict get $response result]} message]} {
        if {![dict get $response ok]} {set message [dict get $response error]}
        _viewerBridgeNotify $window $lifetime [_viewerBridgeReceipt $action failed [dict create job_id [list text $job] error [list text [_viewerNativeClientPublicMessage $message]]]]
        return
    }
    if {$action in {subscribe reconnect}} {_viewerBridgeSubscribe $window $job [datasetPublicationV2DictDefault $request after_sequence 0]}
    if {$action eq {unsubscribe}} {
        set key [list $window $lifetime $job]
        if {[dict exists $::GX::ViewerScriptBridge::listeners $key]} {scriptJobUnsubscribe [dict get $::GX::ViewerScriptBridge::listeners $key];dict unset ::GX::ViewerScriptBridge::listeners $key}
    }
    _viewerBridgeNotify $window $lifetime [dict get $response result receipt]
}
# Script Bridge exposure: HOST_ONLY_JUSTIFIED. This transport entry consumes
# only the existing compiled broker's sealed descriptor on the actual owning
# Tk event loop, captures live GUI/Session/source/Document identity and invokes
# the original managed Script Job preparer. Script workers have no Viewer
# window/lifetime authority and may not attest these Host bootstrap metadata.
# Their safe equivalent remains ordinary gxtxt_api_require/call on the SAME
# registry. Payload markers never select this CORE-only transport branch.
proc ::GX::viewerScriptBridgeControlCommand {window action descriptorJson headerJson} {
    set r [_viewerBridgeCurrent $window]
    if {$action ni {list describe require call run status cancel result read_resource reconnect subscribe unsubscribe}} {error {Unknown ordinary Bridge lifecycle verb}}
    _viewerNativeClientScope $window
    set context [_viewerBridgeContext $window $r $action [nativeWorkspaceJsonDecode $headerJson]]
    if {[dict get $context client_identity] eq {}} {error {Resource control requires the actual captured GUI process identity}}
    set descriptor [nativeWorkspaceJsonDecode $descriptorJson]
    set scope [nativeWorkspaceJsonDecode [_viewerBridgeControlScope $context]]
    set payload [list object [dict create descriptor $descriptor scope $scope action [list text $action]]]
    dict set context control_source [nativeWorkspaceJsonEncode $payload]
    if {$action in {list describe require call run}} {
        set submission "viewer-bridge-submit#[pid]-[incr ::GX::ViewerScriptBridge::serial]"
        _viewerBridgeRequest $window $context prepare_control $action $descriptor [list ::GX::_viewerBridgePrepared $window $context $action $submission]
        set receipt [_viewerBridgeReceipt $action pending [dict create submission_id [list text $submission]]]
    } else {
        set typed [nativeWorkspaceJsonDecode $headerJson]
        set fields [nativeWorkspaceDecode $typed]
        if {![dict exists $fields job_id]} {error {Lifecycle control requires the original Job identity}}
        dict set context control_job_id [dict get $fields job_id]
        _viewerBridgeRequest $window $context lifecycle_control $action $descriptor [list ::GX::_viewerBridgeActionReady $window $context $action $typed]
        set receipt [_viewerBridgeReceipt $action pending [dict create job_id [list text [dict get $fields job_id]]]]
    }
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_result $receipt
    return $receipt
}
proc ::GX::viewerScriptBridgeCommand {window action typedRequest} {
    set r [_viewerBridgeCurrent $window]
    if {[lindex $typedRequest 0] ne {object} || [string length [encoding convertto utf-8 [_viewerBridgeJson $typedRequest]]]>49152} {error {Script Bridge frontend requires a bounded typed object}}
    set request [nativeWorkspaceDecode $typedRequest]
    if {$action in {list describe require call run}} {
        _viewerNativeClientScope $window
        set submission "viewer-bridge-submit#[pid]-[incr ::GX::ViewerScriptBridge::serial]"
        set context [_viewerBridgeContext $window $r $action $typedRequest]
        _viewerBridgeRequest $window $context prepare $action $typedRequest [list ::GX::_viewerBridgePrepared $window $context $action $submission]
        set receipt [_viewerBridgeReceipt $action pending [dict create submission_id [list text $submission]]]
    } else {
        if {![dict exists $request job_id]} {error {Script Bridge lifecycle requires authoritative job_id}}
        set job [dict get $request job_id]
        set context [_viewerBridgeContext $window $r]
        _viewerBridgeRequest $window $context lifecycle $action $typedRequest [list ::GX::_viewerBridgeActionReady $window $context $action $typedRequest]
        set receipt [_viewerBridgeReceipt $action pending [dict create request_id [list text [dict get $context request_id]] job_id [list text $job]]]
    }
    dict set ::GX::ViewerDevelopment::windows $window script_bridge_result $receipt
    return $receipt
}
