# Script Bridge source contract scope: script_job_api_v1.script_bridge_policy.json (exact operations; no added runtime authority).
# SPDX-License-Identifier: GPL-3.0-or-later
# CORE local durable Job API. UI callbacks use nonblocking fileevents only.
namespace eval ::GX {variable scriptJobRequests {};variable scriptJobCounter 0;variable scriptJobShutdownHook 0}
proc ::GX::scriptJobApiInfo {} {
    return [dict create api_name SCRIPT_JOB_API_v1 api_version 1 scope {local remote_references} authority core operations {submit wait list describe inspect log_read inspect_run run_log_read run_summaries cancel recover configure policy_read debug_submit debug_read debug_control debug_capabilities stream_read stream_publish view_list history_hide history_restore history_candidates workspace_save workspace_open workspace_rename workspace_delete view_remember summary summary_subscribe summary_unsubscribe} persistence durable gui_lifetime independent presentation_scope user_configuration summary_authority trusted_host_counts_only auxiliary_operations {scriptJobAsync scriptJobRequestCancel scriptJobRequestExchange scriptJobRequestSend scriptJobRequestDrain} auxiliary_limits {timeout_ms max_bytes process_group ui_lifetime label duplex separate_stderr send_pending_bytes} auxiliary_exchange_timeout_ms {default 12000 min 1 max 120000} auxiliary_send_pending_bytes {default 65536 min 1024 max 2097152} auxiliary_drain_maximum {default 16 min 1 max 16}]
}
source [file join [file dirname [info script]] script_job_summary_v1.tcl]
proc ::GX::scriptJobRoot {} {
    if {[info exists ::env(GXTXT_JOB_ROOT)]} {return [file normalize $::env(GXTXT_JOB_ROOT)]}
    return [file join [file dirname [configurationPath]] script-jobs-v1]
}
proc ::GX::scriptJobCommand {operation args} {
    return [list [runtimeToolResolve python] -B [file join $::GX::scriptDir core python gxtxt_job_supervisor.py] --root [scriptJobRoot] $operation {*}$args]
}
proc ::GX::scriptJobCall {operation args} {
    if {[llength [info commands ::GX::stderrDiagnosticsProducerEnvironment]]} {stderrDiagnosticsProducerEnvironment}
    set rc [catch {exec {*}[scriptJobCommand $operation {*}$args]} response]
    if {[catch {dict get $response ok} ok]} {error $response}
    if {!$ok} {error [dict get $response error]}
    return [dict get $response result]
}
# REGISTERED_TYPED_ADAPTER: fixed zero-argument same-admitted LOCAL policy read.
# SCRIPT_JOB_API_v1/script_job policy_read has no caller root or remote grant.
# Read-time policy is neither an admission CAS nor a resource reservation lease.
proc ::GX::scriptJobPolicyRead {} {return [scriptJobCall policy_read]}
proc ::GX::scriptJobAsync {command payload callback {options {}}} {
    tailcall ::GX::_scriptJobAsyncOwned $command $payload $callback $options 0
}
proc ::GX::_scriptJobAsyncTracked {command payload callback options} {
    tailcall ::GX::_scriptJobAsyncOwned $command $payload $callback $options 1
}
proc ::GX::_scriptJobAsyncOwned {command payload callback options tracked} {
    variable scriptJobRequests;variable scriptJobCounter
    if {[llength [info commands ::GX::stderrDiagnosticsProducerEnvironment]]} {stderrDiagnosticsProducerEnvironment}
    foreach key [dict keys $options] {if {$key ni {timeout_ms max_bytes process_group ui_lifetime label duplex separate_stderr send_pending_bytes}} {error {Unknown managed request option.}}}
    set options [dict merge {timeout_ms 0 max_bytes 0 process_group 0 ui_lifetime 0 label {Managed request} duplex 0 separate_stderr 0 send_pending_bytes 65536} $options]
    if {![string is entier -strict [dict get $options send_pending_bytes]] || [dict get $options send_pending_bytes]<1024 || [dict get $options send_pending_bytes]>2097152} {error {Managed request send budget must be1024..2097152 bytes}}
    foreach key {timeout_ms max_bytes} {if {![string is integer -strict [dict get $options $key]] || [dict get $options $key]<0} {error {Managed request limits must be nonnegative integers.}}}
    foreach key {process_group ui_lifetime duplex separate_stderr} {if {![string is boolean -strict [dict get $options $key]]} {error {Managed request lifetime options must be boolean.}}}
    if {[dict get $options process_group] && [auto_execok kill] eq {}} {error {Owned process-group cancellation is unavailable on this host.}}
    if {[dict get $options separate_stderr] && [dict get $options duplex]} {error {Separate diagnostics require a non-duplex managed request}}
    set request job-request-[incr scriptJobCounter]
    set pipe {};set diagnostics {};set diagnosticWrite {}
    if {$tracked} {
        dict set scriptJobRequests $request [dict create pipe {} callback $callback data {} options $options pids {} started_ms [clock milliseconds] timer {} kill_timer {} cancelled {} \
            stderr_pipe {} stderr_eof 1 stderr_bytes 0 stderr_data {} tracked_identities {} tracked_capture_done 0]
    }
    try {
        if {[dict get $options separate_stderr]} {
            lassign [chan pipe] diagnostics diagnosticWrite
            fconfigure $diagnostics -blocking 0 -buffering none -encoding utf-8 -translation lf
            set pipe [open [list | {*}$command 2>@ $diagnosticWrite] r+]
            close $diagnosticWrite;set diagnosticWrite {}
        } else {set pipe [open [list | {*}$command 2>@1] r+]}
        if {$tracked} {dict set scriptJobRequests $request pipe $pipe;dict set scriptJobRequests $request pids [pid $pipe];_scriptJobTrackedCapture $request}
        fconfigure $pipe -blocking 0 -buffering none -encoding utf-8 -translation lf
        puts -nonewline $pipe $payload
        if {![dict get $options duplex]} {chan close $pipe write}
    } on error {message context} {
        if {!$tracked} {foreach channel [list $pipe $diagnostics $diagnosticWrite] {if {$channel ne {}} {catch {close $channel}}};return -options $context $message}
        # The genuine original request ID survives every startup boundary. Its
        # one notification is uncertainty, never a non-admission certificate.
        dict set scriptJobRequests $request callback {}
        if {$pipe eq {}} {
            foreach channel [list $diagnostics $diagnosticWrite] {if {$channel ne {}} {catch {close $channel}}}
            dict unset scriptJobRequests $request
        } else {
            dict set scriptJobRequests $request pipe $pipe
            catch {dict set scriptJobRequests $request pids [pid $pipe]}
            _scriptJobTrackedCapture $request
            catch {fconfigure $pipe -blocking 0 -buffering none -encoding utf-8 -translation lf}
            if {[catch {fileevent $pipe readable [list ::GX::scriptJobReadable $request]}]} {dict set scriptJobRequests $request eof 1}
            dict set scriptJobRequests $request stderr_pipe $diagnostics
            dict set scriptJobRequests $request stderr_eof [expr {$diagnostics eq {}}]
            if {$diagnostics ne {}} {catch {fileevent $diagnostics readable [list ::GX::_scriptJobStderrReadable $request]}}
            if {$diagnosticWrite ne {}} {catch {close $diagnosticWrite}}
            scriptJobRequestCancel $request write_error
        }
        if {$callback ne {}} {after 0 [list {*}$callback [dict create ok 0 error $message error_type startup_unknown request_id $request]]}
        return $request
    }
    set captures {};if {$tracked} {set captures [dict get $scriptJobRequests $request tracked_identities]}
    dict set scriptJobRequests $request [dict create pipe $pipe callback $callback data {} options $options pids [pid $pipe] started_ms [clock milliseconds] timer {} kill_timer {} cancelled {} stderr_pipe $diagnostics stderr_eof [expr {$diagnostics eq {}}] stderr_bytes 0 stderr_data {}]
    if {$tracked} {dict set scriptJobRequests $request tracked_identities $captures;dict set scriptJobRequests $request tracked_capture_done 1}
    set timeout [dict get $options timeout_ms]
    if {$timeout>0} {dict set scriptJobRequests $request timer [after $timeout [list ::GX::scriptJobRequestCancel $request timeout]]}
    if {[dict get $options ui_lifetime] && !$::GX::scriptJobShutdownHook && [llength [info commands winfo]] && [winfo exists .]} {
        bind . <Destroy> +[list ::GX::scriptJobRequestsShutdown %W]
        set ::GX::scriptJobShutdownHook 1
    }
    fileevent $pipe readable [list ::GX::scriptJobReadable $request]
    if {$diagnostics ne {}} {fileevent $diagnostics readable [list ::GX::_scriptJobStderrReadable $request]}
    return $request
}
proc ::GX::_scriptJobRequestReadResume {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request receive_paused]} return
    # Clear before touching the channel: a failed rearm uses ordinary Cancel,
    # which must not recursively try the same failed rearm.
    dict unset scriptJobRequests $request receive_paused
    set pipe [dict get $scriptJobRequests $request pipe]
    if {[catch {fileevent $pipe readable [list ::GX::scriptJobReadable $request]}]} {
        dict set scriptJobRequests $request eof 1
        scriptJobRequestCancel $request read_error
    }
}
proc ::GX::_scriptJobRequestReadPause {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request] || [dict get $scriptJobRequests $request cancelled] ne {}} return
    dict set scriptJobRequests $request receive_paused 1
    if {[catch {fileevent [dict get $scriptJobRequests $request pipe] readable {}}]} {
        dict set scriptJobRequests $request eof 1
        scriptJobRequestCancel $request read_error
    }
}
proc ::GX::_scriptJobRequestFrame {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request]} {return 0}
    set entry [dict get $scriptJobRequests $request]
    set data [dict get $entry data];set maximum [dict get $entry options max_bytes]
    if {$maximum>0} {
        # Read only after complete staged lines are consumed. The old bounded
        # prefix plus ONE existing 65536-character read bounds parked staging;
        # this is a character bound, not an assertion about UTF-8 byte width.
        set invalid [expr {[string length $data]>$maximum+65536}]
        if {!$invalid} {
            foreach line [split $data \n] {
                if {[string bytelength $line]>$maximum} {set invalid 1;break}
            }
        }
        if {$invalid} {
            dict set entry data [string range $data 0 [expr {max(0,$maximum/8-1)}]]
            dict set scriptJobRequests $request $entry
            scriptJobRequestCancel $request output_limit
            return 0
        }
    }
    # Do not consume the next frame without a slot. The exact suffix (including
    # empty frames) remains with this same owner until its consumer frees space.
    while {[llength [datasetPublicationV2DictDefault $entry messages {}]]<16 && [set newline [string first \n $data]]>=0} {
        dict lappend entry messages [string range $data 0 [expr {$newline-1}]]
        set data [string range $data [expr {$newline+1}] end]
    }
    dict set entry data $data
    dict set scriptJobRequests $request $entry
    return 1
}
# The same managed request owns both channels and their combined byte budget.
proc ::GX::_scriptJobStderrReadable {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request]} return
    set entry [dict get $scriptJobRequests $request]
    if {[dict get $entry stderr_eof]} return
    set pipe [dict get $entry stderr_pipe]
    set failed [catch {read $pipe 8192} chunk]
    if {$failed} {
        catch {fileevent $pipe readable {}}
        dict set entry stderr_eof 1
    } else {
        dict incr entry stderr_bytes [string bytelength $chunk]
        if {$chunk ne {} && [llength [info commands ::GX::stderrDiagnostics]] && $::GX::StderrDiagnostics::desired} {
            set children [dict get $entry pids]
            catch {stderrDiagnostics emit [dict create source managed_auxiliary component ScriptJob api_id SCRIPT_JOB_API_v1 operation request_stderr process_id [expr {[llength $children]==1?[lindex $children 0]:{unknown}}] stream stderr] [encoding convertto utf-8 $chunk]}
        }
        if {[dict get $entry cancelled] eq {}} {
            dict append entry stderr_data $chunk
            if {[string bytelength [dict get $entry stderr_data]]>8192} {dict set entry stderr_data [string range [dict get $entry stderr_data] end-2047 end]}
        }
        if {[eof $pipe]} {fileevent $pipe readable {};dict set entry stderr_eof 1}
    }
    dict set scriptJobRequests $request $entry
    set maximum [dict get $entry options max_bytes]
    if {$failed} {scriptJobRequestCancel $request read_error
    } elseif {$maximum>0 && [dict get $entry stderr_bytes]+[string bytelength [dict get $entry data]]>$maximum} {scriptJobRequestCancel $request output_limit}
    if {[dict exists $entry eof]} {after idle [list ::GX::scriptJobReadable $request]}
}
proc ::GX::scriptJobReadable {request} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request]} return
    set entry [dict get $scriptJobRequests $request];set pipe [dict get $entry pipe]
    set ended [dict exists $entry eof]
    set deferred 0
    if {!$ended && [dict get $entry options duplex] && [dict get $entry cancelled] eq {}} {
        if {![_scriptJobRequestFrame $request]} return
        set entry [dict get $scriptJobRequests $request]
        set deferred [expr {[llength [datasetPublicationV2DictDefault $entry messages {}]]>=16}]
        if {!$deferred} {
            _scriptJobRequestReadResume $request
            if {![dict exists $scriptJobRequests $request]} return
            set entry [dict get $scriptJobRequests $request];set ended [dict exists $entry eof]
        }
    }
    if {!$ended && !$deferred} {
        if {[catch {read $pipe 65536} chunk]} {
            # A failed/closed channel must still use the existing cancellation,
            # escalation and terminal callback owner, even without another EOF.
            catch {fileevent $pipe readable {}}
            scriptJobRequestCancel $request read_error
            dict set scriptJobRequests $request eof 1
            set entry [dict get $scriptJobRequests $request]
            set ended 1
        } else {dict append entry data $chunk}
    }
    set maximum [dict get $entry options max_bytes]
    if {[dict get $entry options duplex]} {
        if {[dict get $entry cancelled] ne {}} {
            # Drain the owned channel during normal cancellation without
            # retaining additional unsolicited native output.
            dict set entry data {}
        } else {
        dict set scriptJobRequests $request $entry
        if {![_scriptJobRequestFrame $request]} return
        set entry [dict get $scriptJobRequests $request]
        }
    }
    if {![dict get $entry options duplex] && $maximum>0 && [string bytelength [dict get $entry data]]+[dict get $entry stderr_bytes]>$maximum} {
        dict set entry data [string range [dict get $entry data] 0 [expr {max(0,$maximum/8-1)}]]
        dict set scriptJobRequests $request $entry
        scriptJobRequestCancel $request output_limit
        set entry [dict get $scriptJobRequests $request]
    }
    dict set scriptJobRequests $request $entry
    if {!$ended} {
        if {[catch {eof $pipe} atEOF]} {
            scriptJobRequestCancel $request read_error
            dict set scriptJobRequests $request eof 1
            set entry [dict get $scriptJobRequests $request]
        } elseif {!$atEOF} {
            if {[dict get $entry options duplex] && [dict get $entry cancelled] eq {} && [llength [datasetPublicationV2DictDefault $entry messages {}]]>=16} {
                _scriptJobRequestReadPause $request
            }
            return
        }
    }
    if {![dict get $entry stderr_eof]} {
        catch {fileevent $pipe readable {}}
        dict set scriptJobRequests $request eof 1
        return
    }
    if {[dict get $entry options duplex] && [dict get $entry cancelled] eq {}} {
        # A persistent native leader can crash after fork while a descendant
        # redirects stdout. Retain ownership until the whole group is reaped.
        scriptJobRequestCancel $request closed
        set entry [dict get $scriptJobRequests $request]
    }
    # A worker can exit before a descendant that redirected its stdout. Keep
    # the group identity until the escalation has run, even after pipe EOF.
    if {[dict get $entry cancelled] ne {} && ![dict exists $entry escalated]} {
        catch {fileevent $pipe readable {}}
        dict set scriptJobRequests $request eof 1
        return
    }
    catch {fileevent $pipe readable {}};catch {close $pipe}
    if {[dict get $entry stderr_pipe] ne {}} {catch {fileevent [dict get $entry stderr_pipe] readable {}};catch {close [dict get $entry stderr_pipe]}}
    foreach key {timer kill_timer} {if {[dict get $entry $key] ne {}} {after cancel [dict get $entry $key]}}
    dict unset scriptJobRequests $request
    set response [string trim [dict get $entry data]]
    if {[dict get $entry cancelled] ne {}} {set response [dict create ok 0 error "[dict get $entry options label]: [dict get $entry cancelled]" error_type [dict get $entry cancelled]]}
    if {[catch {dict get $response ok}]} {set response [dict create ok 0 error $response]}
    if {[dict get $entry stderr_data] ne {}} {
        set tail [datasetPublicationV2DictDefault $response diagnostic_tail {}]
        append tail \n [dict get $entry stderr_data]
        if {[string bytelength $tail]>8192} {set tail [string range $tail end-2047 end]}
        dict set response diagnostic_tail $tail
    }
    if {[dict get $entry callback] ne {}} {uplevel #0 [list {*}[dict get $entry callback] $response]}
}
proc ::GX::scriptJobRequestExchange {request payload {timeout_ms 12000}} {
    # Short native RPCs share the existing managed request/pipe/process-group
    # owner. Do not enter a nested Tk event loop: queued Canvas input must see
    # the completed local tool selection, never the previous tool.
    if {![string is integer -strict $timeout_ms] || $timeout_ms<1 || $timeout_ms>120000} {error {Managed exchange timeout is outside1..120000ms}}
    if {![dict exists $::GX::scriptJobRequests $request] || ![dict get $::GX::scriptJobRequests $request options duplex]} {error {Managed duplex request is no longer active}}
    set pipe [dict get $::GX::scriptJobRequests $request pipe]
    if {$payload ne {}} {puts $pipe $payload;flush $pipe}
    set deadline [expr {[clock milliseconds]+$timeout_ms}]
    while {[dict exists $::GX::scriptJobRequests $request]} {
        scriptJobReadable $request
        if {![dict exists $::GX::scriptJobRequests $request]} break
        set entry [dict get $::GX::scriptJobRequests $request]
        if {[dict get $entry cancelled] ne {}} {error {Managed compiled request was cancelled}}
        set messages [datasetPublicationV2DictDefault $entry messages {}]
        if {[llength $messages]} {
            dict set ::GX::scriptJobRequests $request messages [lrange $messages 1 end]
            _scriptJobRequestReadResume $request
            if {![dict exists $::GX::scriptJobRequests $request] || [dict get $::GX::scriptJobRequests $request cancelled] ne {}} {error {Managed compiled request was cancelled}}
            return [lindex $messages 0]
        }
        if {[clock milliseconds]>=$deadline} {scriptJobRequestCancel $request timeout;error {Compiled local event exceeded its bounded response time}}
        after 1
    }
    error {Compiled Viewer worker ended before responding}
}
proc ::GX::scriptJobRequestSend {request payload} {
    variable scriptJobRequests
    if {![dict exists $scriptJobRequests $request] || ![dict get $scriptJobRequests $request options duplex] || [dict get $scriptJobRequests $request cancelled] ne {}} {
        return -code error -errorcode {GXTXT SCRIPT_JOB INACTIVE} {Managed duplex request is no longer active}
    }
    if {[string first \x00 $payload]>=0 || [string first \r $payload]>=0 || [string first \n $payload]>=0} {
        return -code error -errorcode {GXTXT SCRIPT_JOB FRAME} {Managed duplex payload must not contain NUL, CR or LF}
    }
    # Count the actual Tcl channel encoding, including the single appended LF.
    # No write/flush is attempted until the entire pending-output budget fits.
    set bytes [string length [encoding convertto utf-8 $payload]]
    set pipe [dict get $scriptJobRequests $request pipe]
    if {[catch {chan pending output $pipe} pending]} {
        scriptJobRequestCancel $request write_error
        return -code error -errorcode {GXTXT SCRIPT_JOB WRITE_FAILED} {Managed duplex request write failed}
    }
    if {$bytes+1+$pending>[dict get $scriptJobRequests $request options send_pending_bytes]} {
        return -code error -errorcode {GXTXT SCRIPT_JOB BUSY} {Managed duplex pending-output budget exceeded}
    }
    if {[catch {puts $pipe $payload;flush $pipe}]} {
        # A partly written frame is never retried. The same owner retains the
        # pipe and child/group through its ordinary terminal escalation.
        scriptJobRequestCancel $request write_error
        return -code error -errorcode {GXTXT SCRIPT_JOB WRITE_FAILED} {Managed duplex request write failed}
    }
    return [dict create request_id $request accepted 1 payload_bytes $bytes]
}
proc ::GX::scriptJobRequestDrain {request {maximum 16}} {
    variable scriptJobRequests
    if {![string is integer -strict $maximum] || $maximum<1 || $maximum>16} {
        return -code error -errorcode {GXTXT SCRIPT_JOB MAXIMUM} {Managed duplex drain maximum is outside1..16}
    }
    set inactive [dict create request_id $request active 0 cancelled {} messages {}]
    if {![dict exists $scriptJobRequests $request]} {return $inactive}
    if {![dict get $scriptJobRequests $request options duplex]} {
        return -code error -errorcode {GXTXT SCRIPT_JOB INACTIVE} {Managed duplex request is no longer active}
    }
    # Blocking Exchange/Bridge callers do not pump the ordinary after timer.
    # Service only this already-cancelled request's captured escalation deadline.
    set entry [dict get $scriptJobRequests $request]
    if {[dict get $entry cancelled] ne {} && ![dict exists $entry escalated] && [dict exists $entry kill_deadline_ms] && [clock milliseconds]>=[dict get $entry kill_deadline_ms]} {
        _scriptJobRequestEscalate $request
        if {![dict exists $scriptJobRequests $request]} {return $inactive}
    }
    # Free existing FIFO capacity before ONE readable service. Held frames are
    # still subordinate to terminal/cancellation authority from that service.
    set entry [dict get $scriptJobRequests $request]
    set messages {}
    if {[dict get $entry cancelled] eq {}} {
        set queued [datasetPublicationV2DictDefault $entry messages {}]
        set messages [lrange $queued 0 [expr {$maximum-1}]]
        dict set scriptJobRequests $request messages [lrange $queued $maximum end]
        _scriptJobRequestReadResume $request
    }
    scriptJobReadable $request
    # Readable can terminalize and invoke arbitrary trusted host cleanup. Only
    # the actual surviving entry may supply messages or receive the residuals.
    if {![dict exists $scriptJobRequests $request]} {return $inactive}
    set entry [dict get $scriptJobRequests $request]
    set cancelled [dict get $entry cancelled]
    if {$cancelled eq {}} {
        set queued [datasetPublicationV2DictDefault $entry messages {}]
        set remaining [expr {$maximum-[llength $messages]}]
        if {$remaining>0} {
            lappend messages {*}[lrange $queued 0 [expr {$remaining-1}]]
            dict set scriptJobRequests $request messages [lrange $queued $remaining end]
            _scriptJobRequestReadResume $request
        }
        if {![dict exists $scriptJobRequests $request]} {return $inactive}
        set cancelled [dict get $scriptJobRequests $request cancelled]
    }
    if {$cancelled ne {}} {set messages {}}
    return [dict create request_id $request active 1 cancelled $cancelled messages $messages]
}
proc ::GX::_scriptJobRequestSignal {request signal} {
    if {![dict exists $::GX::scriptJobRequests $request]} return
    set entry [dict get $::GX::scriptJobRequests $request]
    set kill [auto_execok kill];if {$kill eq {}} return
    foreach child [dict get $entry pids] {
        if {![string is integer -strict $child] || $child<=1} continue
        if {[dict exists $entry tracked_identities]} {
            if {![dict exists $entry tracked_identities $child] || ![llength [info commands ::GX::_resourceManagementChildIdentity]]} continue
            set actual [_resourceManagementChildIdentity $child]
            if {[dict get $actual state] ne {live} || [dict get $actual identity] ne [dict get $entry tracked_identities $child] || ![dict exists $actual parent] || [dict get $actual parent] ne [pid]} continue
            # Only this positively captured leader; never a guessed/shared PGID.
            catch {exec {*}$kill -$signal -- $child 2>/dev/null}
            continue
        }
        set delivered 0
        if {[dict get $entry options process_group]} {set delivered [expr {![catch {exec {*}$kill -$signal -- -$child 2>/dev/null}]}]}
        # A successful group signal already includes its leader. Sending it
        # again to that PID can interrupt the worker's terminal cleanup handler.
        if {!$delivered} {catch {exec {*}$kill -$signal -- $child 2>/dev/null}}
    }
}
proc ::GX::scriptJobRequestCancel {request {reason cancelled}} {
    variable scriptJobRequests
    if {[dict exists $scriptJobRequests $request unlaunched]} {dict set scriptJobRequests $request cancelled $reason;return 1}
    if {[dict exists $scriptJobRequests $request tracked_readiness]} {
        _scriptJobTrackedReadyFinish $request UNKNOWN "Original owner readiness cancelled: $reason; no non-admission certificate"
        return 1
    }
    if {[dict exists $scriptJobRequests $request tracked_admission]} {
        _scriptJobTrackedResolve [dict get $scriptJobRequests $request capsule] {} 1 1
        return 1
    }
    if {$reason ni {cancelled timeout output_limit closed read_error write_error}} {error {Unknown managed request cancellation reason.}}
    if {![dict exists $scriptJobRequests $request] || [dict get $scriptJobRequests $request cancelled] ne {}} {return 0}
    dict set scriptJobRequests $request cancelled $reason
    dict set scriptJobRequests $request kill_deadline_ms [expr {[clock milliseconds]+500}]
    _scriptJobRequestSignal $request TERM
    dict set scriptJobRequests $request kill_timer [after 500 [list ::GX::_scriptJobRequestEscalate $request]]
    # A full receive window may have paused fileevents before EOF was known.
    # Cancellation must resume discard-reading or escalation cannot retire it.
    _scriptJobRequestReadResume $request
    return 1
}
proc ::GX::_scriptJobRequestEscalate {request} {
    if {![dict exists $::GX::scriptJobRequests $request] || [dict exists $::GX::scriptJobRequests $request escalated]} return
    dict set ::GX::scriptJobRequests $request escalated 1
    set timer [dict get $::GX::scriptJobRequests $request kill_timer]
    if {$timer ne {}} {after cancel $timer;dict set ::GX::scriptJobRequests $request kill_timer {}}
    _scriptJobRequestSignal $request KILL
    if {[dict exists $::GX::scriptJobRequests $request eof]} {scriptJobReadable $request}
}
proc ::GX::scriptJobRequestsShutdown {actual} {
    if {$actual ne {.}} return
    dict for {request entry} $::GX::scriptJobRequests {
        if {[dict get $entry options ui_lifetime]} {
            _scriptJobRequestSignal $request KILL
            # A rearmed full queue must discard, rather than pause again.
            # Enter the same Cancel/EOF/escalation owner; first reason wins.
            if {[dict get $entry options duplex]} {
                scriptJobRequestCancel $request closed
                _scriptJobRequestReadResume $request
            }
        }
    }
}
proc ::GX::scriptJobSubmit {reference parameters {options {}} {callback {}}} {
    if {[string match core-service:* $reference] || [dict exists $options core_service]} {error {Private CORE services cannot be submitted through user Script Job APIs}}
    tailcall ::GX::_scriptJobSubmit $reference $parameters $options $callback
}
proc ::GX::_scriptJobSubmitCore {service parameters {options {}} {callback {}}} {
    _scriptCoreServiceMetadata $service
    dict set options core_service $service
    tailcall ::GX::_scriptJobSubmit core-service:$service $parameters $options $callback
}
# Resolve each alias independently. The legacy namespace option is a default,
# never output write authority and never a reason to move the user's Current.
proc ::GX::scriptJobInputsResolve {session inputs {defaultNamespace {}}} {
    if {![datasetAuthorityActive $session]} {return [datasetAuthorityTransaction $session ::GX::scriptJobInputsResolve $session $inputs $defaultNamespace]}
    if {$defaultNamespace eq {}} {set defaultNamespace [datasetNamespaceCurrentGet $session]}
    set defaultNamespace [datasetNamespaceNormalize $defaultNamespace]
    set resolved {}
    dict for {alias binding} $inputs {
        if {![regexp {^[A-Za-z_][A-Za-z0-9_]*$} $alias]} {error "Invalid semantic input alias '$alias'"}
        if {![dict exists $binding dataset_id]} {error "Input '$alias' requires a Dataset ID"}
        set id [dict get $binding dataset_id]
        set namespace [datasetNamespaceNormalize [datasetPublicationV2DictDefault $binding namespace $defaultNamespace]]
        if {[datasetField $id id {}] eq {}} {error "Input '$alias' / '$id' in '$namespace' is no longer available"}
        if {[datasetNamespaceGet $session $id] ne $namespace} {error "Input '$alias' / '$id' is no longer in namespace '$namespace'"}
        set revision [datasetRevisionToken $id $session]
        if {[dict exists $binding revision] && [dict get $binding revision] ne $revision} {error "Input '$alias' / '$id' in '$namespace' changed since review; select it again"}
        dict set binding namespace $namespace
        dict set binding revision $revision
        dict set binding revision_base64 [binary encode base64 -maxlen 0 [encoding convertto utf-8 $revision]]
        dict set resolved $alias $binding
    }
    return $resolved
}

proc ::GX::_scriptJobSubmission {reference parameters options} {
    if {[llength [info commands ::GX::stderrDiagnosticsProducerEnvironment]]} {stderrDiagnosticsProducerEnvironment}
    set session [dict get [dict merge [dict create session $::GX::currentSession] $options] session]
    if {$session eq {} || ![file isdirectory $session]} {error {Open a Session before submitting a script.}}
    set moduleConfig {}
    if {$::GX::currentSession ne {} && [file normalize $::GX::currentSession] eq [file normalize $session]} {
        foreach module {analysis.python_script analysis.octave_script} {
            foreach key [array names ::GX::moduleCfg "$module,*"] {dict set moduleConfig $key $::GX::moduleCfg($key)}
        }
    }
    set request [dict merge [dict create module_config $moduleConfig inputs {} output {} runtime_template {} module_output {}] $options [dict create session [file normalize $session] reference $reference parameters $parameters root [scriptJobRoot]]]
    # Only the private original tracked owner can attach these internal fields.
    dict unset request _tracked_admission
    dict unset request _admission_session_identity
    dict unset request _admission_owner_scope
    # Live host authorization can differ from an older saved Manifest after a
    # normal Plugin Manager install/enable. Capture through the existing Module
    # owner for ALL Script Job frontends; never rewrite the Session Manifest or
    # silently grant a different Session the current GUI's module selection.
    dict unset request module_selection
    if {$::GX::currentSession ne {} && [file normalize $::GX::currentSession] eq [file normalize $session]} {
        dict set request module_selection [join [selectedModuleIds] ,]
    }
    # The GUI may run under wish: its executable would keep a hidden Tk event
    # loop alive after preparation, preventing the asynchronous pipe from EOF.
    set interpreter [auto_execok tclsh]
    if {$interpreter eq {}} {error {A local Tcl interpreter is required for job preparation.}}
    set command [list {*}$interpreter [file join $::GX::scriptDir core tcl script_job_request.tcl] $::GX::scriptDir]
    # Trusted Viewer auxiliary and LOCAL native Canvas flatten owners keep this
    # interpreter-only choice out of caller/worker environments and request fields.
    # The fresh preparer needs its own reader while the GUI owns the writer.
    # Unrelated ordinary Script Job callers keep their original argv.
    if {[info exists ::GX::_scriptJobAdmissionWorkspaceAccess] && $::GX::_scriptJobAdmissionWorkspaceAccess eq {read_only}} {
        lappend command --workspace-read-only
    }
    return [dict create request $request command $command]
}
proc ::GX::_scriptJobSubmit {reference parameters options callback} {
    set submission [_scriptJobSubmission $reference $parameters $options]
    set request [dict get $submission request];set command [dict get $submission command]
    if {$callback ne {}} {return [scriptJobAsync $command $request $callback]}
    set response [exec {*}$command << $request]
    if {![dict get $response ok]} {error [dict get $response error]}
    return [dict get $response result]
}

# HOST_ONLY: opt-in tracked Scientific admission through the SAME managed
# request owner and original Supervisor journal. No Script/SDK operation grant.
proc ::GX::_scriptJobTrackedScope {root} {
    if {![file exists $root] || ![file exists [file join $root jobs.sqlite]]} {return {}}
    foreach path [list $root [file join $root jobs.sqlite]] {
        set current /
        foreach part [lrange [file split $path] 1 end] {
            set current [file join $current $part];file lstat $current s
            if {$current ne $path && $s(type) ne {directory}} {error {Tracked Job scope has an aliased ancestor}}
        }
        if {$path eq $root} {set a [array get s]} else {set b [array get s]}
    }
    file stat /proc/[pid] own
    if {[dict get $a type] ne {directory} || [dict get $a uid]!=$own(uid) || ([dict get $a mode]&0077) ||
        [dict get $b type] ne {file} || [dict get $b nlink]!=1 || [dict get $b uid]!=$own(uid) || ([dict get $b mode]&0022)} {error {Original tracked Job scope is unavailable}}
    return [dict create root $root root_dev [dict get $a dev] root_ino [dict get $a ino] database_dev [dict get $b dev] database_ino [dict get $b ino] uid $own(uid)]
}
proc ::GX::_scriptJobTrackedCapsule {capsule {admit 0}} {
    if {[lsort [dict keys $capsule]] ne [lsort {schema submission_id binding command supervisor_sha256 scope authority_epoch owner_scope locator_revision}] || [dict get $capsule schema] ne {gxtxt.script_job_admission.v1} ||
        ![regexp {^job-admission-[a-f0-9]{32}$} [dict get $capsule submission_id]]} {error {Invalid original tracked admission capsule}}
    set id [dict get $capsule submission_id]
    if {![dict exists $::GX::scriptJobRequests $id trusted_owner] || ![dict get $::GX::scriptJobRequests $id trusted_owner]} {error {Cold admission data requires trusted original owner recovery}}
    set captured [dict get $::GX::scriptJobRequests $id capsule]
    if {![_scriptJobTrackedBindingMatch [dict get $captured binding] [dict get $capsule binding]]} {error {Original tracked binding changed}}
    foreach field {command supervisor_sha256 authority_epoch owner_scope locator_revision} {if {[dict get $captured $field] ne [dict get $capsule $field]} {error {Original tracked owner data changed}}}
    # A caller cannot upgrade its scope to a replacement generation. Only an
    # authenticated original-owner receipt may update the retained capsule.
    if {[dict get $captured scope] eq {} || ![_scriptJobTrackedScopeMatch [dict get $captured scope] [dict get $capsule scope]]} {error {Original retained admission database scope changed}}
    set command [dict get $capsule command];set binding [dict get $capsule binding]
    if {[llength $command]!=5 || [lindex $command 1] ne {-B} || [lindex $command 3] ne {--root} ||
        [file pathtype [lindex $command 0]] ne {absolute} || [file pathtype [lindex $command 2]] ne {absolute} ||
        [file tail [lindex $command 2]] ne {gxtxt_job_supervisor.py} || [lindex $command 4] ne [dict get $binding root] ||
        [sha256File [lindex $command 2]] ne [dict get $capsule supervisor_sha256]} {error {Captured original Supervisor command/source changed}}
    if {[dict get $capsule scope] ne {} && ![_scriptJobTrackedScopeMatch [_scriptJobTrackedScope [lindex $command 4]] [dict get $capsule scope]]} {error {Original tracked Job database changed}}
    if {![regexp {^[a-f0-9]{32}$} [dict get $capsule authority_epoch]]} {error {Original admission epoch missing}}
    if {$admit} {
        _scriptJobTrackedOwnerCurrent [dict get $capsule owner_scope]
        set receipt [_nativeWorkspaceAdmissionOwnersGet [dict get $capsule owner_scope]]
        if {[dict get $receipt revision] ne [dict get $capsule locator_revision]} {error {Original admission locator was superseded}}
        set found 0
        foreach locator [dict get [nativeWorkspaceDecode [dict get $receipt value]] locators] {
            if {[_scriptJobTrackedScopeMatch [dict get $locator supervisor_scope] [dict get $capsule scope]] && [dict get $locator authority_epoch] eq [dict get $capsule authority_epoch]} {set found 1}
        }
        if {!$found} {error {Original admission epoch is no longer the acknowledged Session authority}}
    }
    return $capsule
}
proc ::GX::_scriptJobTrackedScopeMatch {left right} {
    if {[dict size $left]!=6 || [dict size $right]!=6} {return 0}
    foreach key {root root_dev root_ino database_dev database_ino uid} {if {![dict exists $left $key] || ![dict exists $right $key] || [dict get $left $key] ne [dict get $right $key]} {return 0}}
    return 1
}
proc ::GX::_scriptJobTrackedBindingMatch {left right} {
    if {[dict size $left]!=[dict size $right]} {return 0}
    dict for {key value} $left {if {![dict exists $right $key] || [dict get $right $key] ne $value} {return 0}}
    return 1
}
proc ::GX::_scriptJobTrackedDiagnostic {id value} {
    set entry [dict get $::GX::scriptJobRequests $id];dict lappend entry diagnostics $value;dict set ::GX::scriptJobRequests $id $entry
}
proc ::GX::_scriptJobTrackedReceipt {id response} {
    if {![dict get $response ok]} {error {Original admission transport did not return certainty}}
    set result [dict get $response result]
    if {[dict get $result submission_id] ne $id || [dict get $result admission_state] ni {OPEN ACCEPTED CLOSED UNKNOWN}} {error {Invalid original admission receipt}}
    if {[dict get $result admission_state] ne {UNKNOWN}} {
        if {[dict size [dict get $result scope]]!=6} {error {Original admission scope is missing}}
        if {[dict get $result admission_state] eq {ACCEPTED} && [dict get $result job_id] eq {}} {error {Original accepted Job ID is missing}}
        if {[dict get $result admission_state] eq {CLOSED} && [dict get $result closed_before_admission] ne {1}} {error {Original closure certificate is missing}}
    }
    return $result
}
proc ::GX::_scriptJobTrackedPayload {capsule} {
    return [dict create submission_id [dict get $capsule submission_id] binding [dict get $capsule binding] scope [dict get $capsule scope] authority_epoch [dict get $capsule authority_epoch] supervisor_sha256 [dict get $capsule supervisor_sha256]]
}
proc ::GX::_scriptJobTrackedCanonicalOwner {scope} {
    if {[lsort [dict keys $scope]] ne [lsort {session session_dev session_ino uid document_id document_generation provider_id}]} {error {Invalid original admission owner scope}}
    set result {}
    foreach key {session session_dev session_ino uid document_id document_generation provider_id} {
        set value [dict get $scope $key]
        if {$key in {session_dev session_ino uid}} {
            if {![regexp {^(0|[1-9][0-9]*)$} $value] || $value>9223372036854775807 || ($key eq {session_ino} && $value==0)} {error {Original owner identity is not an exact signed64 integer}}
        } elseif {$value eq {} || [string bytelength $value]>[expr {$key eq {session}?4096:256}] || [regexp {[\x00-\x1f\x7f]} $value]} {error {Invalid original owner text}}
        dict set result $key $value
    }
    return $result
}
proc ::GX::_scriptJobTrackedOwnerCurrent {scope} {
    set scope [_scriptJobTrackedCanonicalOwner $scope]
    if {[dict get $scope session] ne [file normalize $::GX::currentSession]} {error {Original admission Session changed}}
    file lstat [dict get $scope session] s
    if {$s(type) ne {directory} || [list $s(dev) $s(ino) $s(uid)] ne [list [dict get $scope session_dev] [dict get $scope session_ino] [dict get $scope uid]]} {error {Original admission Session generation changed}}
    if {[dict get [interactiveDocumentMetadata [dict get $scope document_id]] generation] ne [dict get $scope document_generation]} {error {Original admission Document generation changed}}
    return $scope
}
proc ::GX::_scriptJobTrackedLocatorTyped {scope locators} {
    set rootShape {record {root text root_dev int root_ino int database_dev int database_ino int uid int}}
    set ownerShape {record {session text session_dev int session_ino int uid int document_id text document_generation text provider_id text}}
    set rows {};foreach locator $locators {lappend rows [list object [dict create supervisor_scope [nativeWorkspaceEncode $rootShape [dict get $locator supervisor_scope]] authority_epoch [list text [dict get $locator authority_epoch]]]]}
    return [list object [dict create schema [list text gxtxt.script_job_owner_locators.v1] owner_scope [nativeWorkspaceEncode $ownerShape $scope] locators [list array $rows]]]
}
proc ::GX::_scriptJobTrackedLocatorReceipt {scope receipt {positive 0}} {
    if {[lsort [dict keys $receipt]] ne {revision value}} {error {Original locator receipt is malformed}}
    set revision [dict get $receipt revision]
    if {![regexp {^(0|[1-9][0-9]*)$} $revision] || $revision>9223372036854775807 || ($positive && $revision==0)} {error {Original locator revision is not a positive exact signed64 receipt}}
    set value [dict get $receipt value]
    if {$revision==0} {
        if {[llength $value]!=2 || [lindex $value 0] ne {null}} {error {Original absent locator receipt is malformed}}
    } else {
        if {[lindex $value 0] ne {object}} {error {Original durable locator value is missing}}
        set record [nativeWorkspaceDecode $value]
        if {[dict get $record schema] ne {gxtxt.script_job_owner_locators.v1} || [_scriptJobTrackedCanonicalOwner [dict get $record owner_scope]] ne $scope || [llength [dict get $record locators]]<1 || [llength [dict get $record locators]]>64} {error {Original durable locator owner differs}}
    }
    return $receipt
}
proc ::GX::_scriptJobTrackedReadyFind {scope} {
    set scope [_scriptJobTrackedOwnerCurrent $scope]
    set receipt [_scriptJobTrackedLocatorReceipt $scope [_nativeWorkspaceAdmissionOwnersGet $scope]]
    dict for {id entry} $::GX::scriptJobRequests {
        if {![dict exists $entry tracked_readiness] || ![dict exists $entry ready] || ![dict get $entry ready]} continue
        if {[dict get $entry owner_scope] eq $scope && [dict get $entry locator_revision] eq [dict get $receipt revision]} {dict set entry readiness_id $id;return $entry}
    }
    error {Original admission owner readiness/recovery is required before submission}
}
proc ::GX::_scriptJobTrackedRecover {scope callback {cancel_accepted 0}} {
    if {$cancel_accepted ni {0 1} || $callback eq {}} {error {Original owner recovery requires callback and exact cancellation flag}}
    set scope [_scriptJobTrackedOwnerCurrent $scope]
    # New scientific readiness must own the original Session metadata writer
    # BEFORE any Supervisor epoch is fenced. Never unlock another GUI writer.
    _nativeWorkspaceWriteAllowed
    _nativeWorkspaceRequire
    set receipt [_scriptJobTrackedLocatorReceipt $scope [_nativeWorkspaceAdmissionOwnersGet $scope]]
    set locators {}
    if {[lindex [dict get $receipt value] 0] ne {null}} {
        set data [nativeWorkspaceDecode [dict get $receipt value]]
        if {[dict get $data schema] ne {gxtxt.script_job_owner_locators.v1} || [_scriptJobTrackedCanonicalOwner [dict get $data owner_scope]] ne $scope} {error {Original Session locator owner mismatch}}
        set locators [dict get $data locators]
    }
    set f [open /dev/urandom rb];try {set random [read $f 16]} finally {close $f}
    if {[string length $random]!=16} {error {Original readiness entropy unavailable}}
    set id owner-readiness-[binary encode hex $random]
    set prefix [lrange [scriptJobCommand admission_owner_open] 0 end-1]
    dict set ::GX::scriptJobRequests $id [dict create tracked_readiness 1 options {ui_lifetime 0} cancelled {} callback $callback notified 0 ready 0 \
        owner_scope $scope locators $locators locator_revision [dict get $receipt revision] index 0 prefix $prefix supervisor_sha256 [sha256File [lindex $prefix 2]] \
        cancel_accepted $cancel_accepted safe_to_start 1 rows {} has_more 0 lookup_queue {} lookup_index 0 current_locator {}]
    dict set ::GX::scriptJobRequests $id timer [after 120000 [list ::GX::_scriptJobTrackedReadyFinish $id UNKNOWN {Original owner recovery exceeded its finite metadata deadline}]]
    _scriptJobTrackedReadyNext $id
    return [dict create recovery_id $id state PENDING admission_phase OWNER_RECOVERY owner_scope $scope retry_allowed 0]
}
proc ::GX::_scriptJobTrackedReadyCall {id locator operation callback {flags {}}} {
    set entry [dict get $::GX::scriptJobRequests $id]
    if {[dict get $entry notified]} return
    set code [catch {
        _scriptJobTrackedOwnerCurrent [dict get $entry owner_scope]
        set prefix [dict get $entry prefix]
        if {[sha256File [lindex $prefix 2]] ne [dict get $entry supervisor_sha256]} {error {Trusted original Supervisor source changed}}
        set scope [dict get $locator supervisor_scope]
        if {![dict exists $locator uninitialized] && ![_scriptJobTrackedScopeMatch [_scriptJobTrackedScope [dict get $scope root]] $scope]} {error {Stored original Supervisor authority is missing or replaced}}
        lset prefix 4 [dict get $scope root]
        set payload [dict create owner_scope [dict get $entry owner_scope] scope $scope supervisor_sha256 [dict get $entry supervisor_sha256]]
        if {[dict exists $locator uninitialized]} {dict set payload scope [dict get $locator initial_scope]}
        if {$operation ne {admission_owner_open}} {dict set payload authority_epoch [dict get $locator authority_epoch]}
        if {[dict exists $locator submission_id]} {dict set payload submission_id [dict get $locator submission_id]}
        _scriptJobAsyncTracked [list {*}$prefix $operation {*}$flags] $payload $callback [dict create timeout_ms 12000 max_bytes 8388608 ui_lifetime 0 label {Original admission authority recovery}]
    } reason]
    if {$code} {_scriptJobTrackedReadyFinish $id UNKNOWN $reason} else {_scriptJobTrackedCapture $reason;dict set ::GX::scriptJobRequests $id helper $reason}
}
proc ::GX::_scriptJobTrackedReadyNext {id} {
    set entry [dict get $::GX::scriptJobRequests $id]
    if {[dict get $entry notified]} return
    set index [dict get $entry index];set locators [dict get $entry locators]
    if {$index<[llength $locators]} {
        set locator [lindex $locators $index]
        _scriptJobTrackedReadyCall $id $locator admission_recover [list ::GX::_scriptJobTrackedReadyRecovered $id $index] [list [dict get $entry cancel_accepted]]
        return
    }
    set root [lindex [dict get $entry prefix] 4]
    set code [catch {set initial [_scriptJobTrackedScope $root]} reason]
    if {$code} {_scriptJobTrackedReadyFinish $id UNKNOWN $reason;return}
    # Only trusted current configuration can establish a NEW root. Stored roots
    # were all validated/recovered above; a missing old root never falls back.
    set locator [dict create supervisor_scope [dict create root $root] initial_scope $initial uninitialized 1]
    _scriptJobTrackedReadyCall $id $locator admission_owner_open [list ::GX::_scriptJobTrackedReadyOpened $id]
}
proc ::GX::_scriptJobTrackedReadyResult {id response} {
    if {![dict get $response ok]} {error [dict get $response error]}
    set result [dict get $response result];set entry [dict get $::GX::scriptJobRequests $id]
    if {[_scriptJobTrackedCanonicalOwner [dict get $result owner_scope]] ne [dict get $entry owner_scope] || ![regexp {^[a-f0-9]{32}$} [dict get $result authority_epoch]] ||
        ![_scriptJobTrackedScopeMatch [_scriptJobTrackedScope [dict get $result scope root]] [dict get $result scope]]} {error {Original owner recovery receipt failed its exact physical binding}}
    return $result
}
proc ::GX::_scriptJobTrackedReadyRecovered {id index response} {
    if {[dict get $::GX::scriptJobRequests $id notified]} return
    if {[catch {set result [_scriptJobTrackedReadyResult $id $response];_scriptJobTrackedOwnerCurrent [dict get $::GX::scriptJobRequests $id owner_scope]} reason]} {_scriptJobTrackedReadyFinish $id UNKNOWN $reason;return}
    set entry [dict get $::GX::scriptJobRequests $id];set locators [dict get $entry locators]
    set locator [dict create supervisor_scope [dict get $result scope] authority_epoch [dict get $result authority_epoch]]
    if {$index<[llength $locators]} {lset locators $index $locator} else {lappend locators $locator}
    dict set entry locators $locators
    if {![dict get $result safe_to_start]} {dict set entry safe_to_start 0}
    if {[dict get $result has_more]} {dict set entry has_more 1}
    foreach row [dict get $result admissions] {
        dict lappend entry rows $row
        if {[dict get $row admission_state] eq {ACCEPTED} && (![dict get $row handled] || [dict get $row job_state] in {QUEUED PREPARING RUNNING FINALIZING})} {
            dict lappend entry lookup_queue [dict merge $locator [dict create submission_id [dict get $row submission_id]]]
        }
    }
    dict set ::GX::scriptJobRequests $id $entry
    if {[dict exists $entry opened_current]} {_scriptJobTrackedReadyCommit $id;return}
    dict set ::GX::scriptJobRequests $id index [expr {$index+1}]
    _scriptJobTrackedReadyNext $id
}
proc ::GX::_scriptJobTrackedReadyOpened {id response} {
    if {[dict get $::GX::scriptJobRequests $id notified]} return
    if {[catch {set result [_scriptJobTrackedReadyResult $id $response]} reason]} {_scriptJobTrackedReadyFinish $id UNKNOWN $reason;return}
    set entry [dict get $::GX::scriptJobRequests $id];set index 0
    foreach locator [dict get $entry locators] {
        if {[_scriptJobTrackedScopeMatch [dict get $locator supervisor_scope] [dict get $result scope]]} {
            if {[dict get $locator authority_epoch] ne [dict get $result authority_epoch]} {_scriptJobTrackedReadyFinish $id UNKNOWN {Original authority epoch changed during recovery};return}
            dict set ::GX::scriptJobRequests $id current_locator $locator
            _scriptJobTrackedReadyCommit $id;return
        }
        incr index
    }
    if {$index>=64} {_scriptJobTrackedReadyFinish $id UNKNOWN {Original Supervisor locator set reached its explicit64 limit};return}
    set locator [dict create supervisor_scope [dict get $result scope] authority_epoch [dict get $result authority_epoch]]
    dict set ::GX::scriptJobRequests $id opened_current 1
    dict set ::GX::scriptJobRequests $id current_locator $locator
    _scriptJobTrackedReadyCall $id $locator admission_recover [list ::GX::_scriptJobTrackedReadyRecovered $id $index] [list [dict get $entry cancel_accepted]]
}
proc ::GX::_scriptJobTrackedReadyCommit {id} {
    set entry [dict get $::GX::scriptJobRequests $id]
    if {[dict get $entry notified]} return
    if {[catch {
        _scriptJobTrackedOwnerCurrent [dict get $entry owner_scope]
        set receipt [_nativeWorkspaceAdmissionOwnersCAS [dict get $entry owner_scope] [dict get $entry locator_revision] [_scriptJobTrackedLocatorTyped [dict get $entry owner_scope] [dict get $entry locators]]]
        _scriptJobTrackedLocatorReceipt [dict get $entry owner_scope] $receipt 1
        dict set ::GX::scriptJobRequests $id locator_revision [dict get $receipt revision]
        set currentRoot [lindex [dict get $entry prefix] 4]
        foreach locator [dict get $entry locators] {if {[dict get $locator supervisor_scope root] eq $currentRoot} {dict set ::GX::scriptJobRequests $id current_locator $locator}}
    } reason]} {_scriptJobTrackedReadyFinish $id UNKNOWN $reason;return}
    # Each original DB has its own bounded projection. Compose one bounded
    # consumer page with unhandled work FIRST across ALL original generations;
    # readiness still comes only from their uncapped blocking counts and CAS.
    set entry [dict get $::GX::scriptJobRequests $id]
    set blocking {};set history {}
    foreach row [dict get $entry rows] {
        set pair [list [dict get $row submission_id] $row]
        if {[dict get $row admission_state] eq {ACCEPTED} && ![dict get $row handled]} {lappend blocking $pair} else {lappend history $pair}
    }
    set ordered [concat [lsort -index 0 $blocking] [lsort -index 0 $history]]
    if {[llength $ordered]>128} {dict set entry has_more 1}
    set rows {};set ids {}
    foreach pair [lrange $ordered 0 127] {lappend rows [lindex $pair 1];dict set ids [lindex $pair 0] 1}
    set queue {};foreach locator [dict get $entry lookup_queue] {if {[dict exists $ids [dict get $locator submission_id]]} {lappend queue $locator}}
    dict set entry rows $rows;dict set entry lookup_queue $queue
    dict set ::GX::scriptJobRequests $id $entry
    _scriptJobTrackedReadyLookup $id
}
proc ::GX::_scriptJobTrackedReadyLookup {id} {
    set entry [dict get $::GX::scriptJobRequests $id];if {[dict get $entry notified]} return
    set i [dict get $entry lookup_index]
    if {$i>=[llength [dict get $entry lookup_queue]]} {_scriptJobTrackedReadyFinish $id [expr {[dict get $entry safe_to_start]?{READY}:{RECOVERY_REQUIRED}}] {Prior accepted work requires original-owner handling};return}
    set locator [lindex [dict get $entry lookup_queue] $i]
    _scriptJobTrackedReadyCall $id $locator admission_lookup [list ::GX::_scriptJobTrackedReadyAttached $id $i]
}
proc ::GX::_scriptJobTrackedReadyAttached {id index response} {
    if {[dict get $::GX::scriptJobRequests $id notified]} return
    if {[catch {
        if {![dict get $response ok]} {error [dict get $response error]}
        set result [dict get $response result];set entry [dict get $::GX::scriptJobRequests $id];set locator [lindex [dict get $entry lookup_queue] $index]
        set sid [dict get $locator submission_id]
        if {[dict get $result submission_id] ne $sid || ![_scriptJobTrackedScopeMatch [dict get $locator supervisor_scope] [dict get $result scope]] ||
            [_scriptJobTrackedCanonicalOwner [dict get $result binding _admission_owner_scope]] ne [dict get $entry owner_scope] || ![regexp {^[a-f0-9]{32}$} [dict get $result authority_epoch]]} {error {Original recovery attachment differs}}
        set prefix [dict get $entry prefix];lset prefix 4 [dict get $result scope root]
        set capsule [dict create schema gxtxt.script_job_admission.v1 submission_id $sid binding [dict get $result binding] command $prefix \
            supervisor_sha256 [dict get $entry supervisor_sha256] scope [dict get $result scope] authority_epoch [dict get $result authority_epoch] owner_scope [dict get $entry owner_scope] locator_revision [dict get $entry locator_revision]]
        if {![dict exists $::GX::scriptJobRequests $sid tracked_admission]} {
            dict set ::GX::scriptJobRequests $sid [dict create tracked_admission 1 trusted_owner 1 capsule $capsule callback {} notified 1 state [dict get $result admission_state] \
                phase recovered options {ui_lifetime 0} cancelled {} stop_requested 1 diagnostics {}]
        } else {
            # Explicit authoritative recovery, unlike a cold-supplied capsule,
            # may attach the actual stored binding through trusted current CORE.
            if {![_scriptJobTrackedBindingMatch [dict get $::GX::scriptJobRequests $sid capsule binding] [dict get $capsule binding]]} {error {Original recovered binding conflicts with the retained owner}}
            dict set ::GX::scriptJobRequests $sid capsule $capsule
        }
        _scriptJobTrackedResolved $sid {} $response
    } reason]} {_scriptJobTrackedReadyFinish $id UNKNOWN $reason;return}
    dict set ::GX::scriptJobRequests $id lookup_index [expr {$index+1}]
    _scriptJobTrackedReadyLookup $id
}
proc ::GX::_scriptJobTrackedReadyFinish {id state error} {
    if {![dict exists $::GX::scriptJobRequests $id tracked_readiness] || [dict get $::GX::scriptJobRequests $id notified]} return
    set entry [dict get $::GX::scriptJobRequests $id]
    after cancel [dict get $entry timer]
    dict set entry notified 1;dict set entry ready [expr {$state eq {READY}}]
    if {$state eq {READY}} {
        set response [dict create ok 1 result [dict create ready 1 recovery_id $id owner_scope [dict get $entry owner_scope] locator_revision [dict get $entry locator_revision] \
            admissions [dict get $entry rows] has_more [dict get $entry has_more] retry_allowed 0]]
    } else {
        set response [dict create ok 0 error $error recovery_state $state recovery_id $id owner_scope [dict get $entry owner_scope] retry_allowed 0]
        if {$state eq {RECOVERY_REQUIRED}} {dict set response admissions [dict get $entry rows];dict set response has_more [dict get $entry has_more];dict set response locator_revision [dict get $entry locator_revision]}
    }
    dict set entry result $response;dict set ::GX::scriptJobRequests $id $entry
    if {[dict get $entry callback] ne {}} {uplevel #0 [list {*}[dict get $entry callback] $response]}
}
proc ::GX::_scriptJobTrackedOwner {id} {
    if {![dict exists $::GX::scriptJobRequests $id tracked_admission]} {error {Unknown original tracked admission}}
    return [dict get $::GX::scriptJobRequests $id capsule]
}
proc ::GX::_scriptJobTrackedCapture {request} {
    if {![dict exists $::GX::scriptJobRequests $request]} return
    if {[dict exists $::GX::scriptJobRequests $request tracked_capture_done] && [dict get $::GX::scriptJobRequests $request tracked_capture_done]} return
    set identities {}
    if {[llength [info commands ::GX::_resourceManagementChildIdentity]]} {
        foreach child [dict get $::GX::scriptJobRequests $request pids] {
            set actual [_resourceManagementChildIdentity $child]
            if {[dict get $actual identity] ne {} && [dict exists $actual parent] && [dict get $actual parent] eq [pid]} {dict set identities $child [dict get $actual identity]}
        }
    }
    # Empty proof forbids PID-only signals; it does not declare unknown dead.
    dict set ::GX::scriptJobRequests $request tracked_identities $identities
    dict set ::GX::scriptJobRequests $request tracked_capture_done 1
}
proc ::GX::_scriptJobSubmitCoreTracked {service parameters options callback} {
    if {$service ne {scientific-provider} || $callback eq {}} {error {Tracked submission requires the private LOCAL Scientific owner and callback}}
    _scriptCoreServiceMetadata $service
    set ready [_scriptJobTrackedReadyFind [dict get $options _admission_owner_scope]]
    dict set options core_service $service
    set submission [_scriptJobSubmission core-service:$service $parameters $options]
    set binding [dict get $submission request]
    dict set binding _admission_owner_scope [dict get $ready owner_scope]
    file lstat [dict get $binding session] s
    if {$s(type) ne {directory}} {error {Tracked Session must be an ordinary directory}}
    dict set binding _admission_session_identity [list $s(dev) $s(ino) $s(uid)]
    if {[string bytelength $binding]>4194304} {error {Tracked admission intent exceeds4MiB}}
    set command [dict get $ready prefix];set scope [dict get $ready current_locator supervisor_scope]
    if {[lindex $command 4] ne [dict get $binding root]} {error {Current destination changed; original owner recovery is required}}
    set sourceSha [dict get $ready supervisor_sha256]
    # This private LOCAL Scientific owner has checked its actual Document and
    # source binding. The fresh preparer reads committed Workspace state while
    # the GUI retains its writer; reuse the original fixed scoped reader mode.
    # Ordinary/untracked constructors and worker environments stay unchanged.
    set prepareCommand [dict get $submission command]
    if {[lindex $prepareCommand end] ne {--workspace-read-only}} {lappend prepareCommand --workspace-read-only}
    set f [open /dev/urandom rb];try {set random [read $f 16]} finally {close $f}
    if {[string length $random]!=16} {error {Original admission entropy unavailable}}
    set id job-admission-[binary encode hex $random]
    set capsule [dict create schema gxtxt.script_job_admission.v1 submission_id $id binding $binding command $command supervisor_sha256 $sourceSha scope $scope \
        authority_epoch [dict get $ready current_locator authority_epoch] owner_scope [dict get $ready owner_scope] locator_revision [dict get $ready locator_revision]]
    # The4MiB intent limit is not permission to overflow its encoded transport.
    # Python lookup serializes this exact binding as sorted Tcl key/value text.
    # Reserve64KiB for the compact scope/receipt around that binding, BEFORE
    # any tracked ID becomes issued. An oversized spelling stays caller-owned.
    set lookupBinding {};foreach key [lsort [dict keys $binding]] {dict set lookupBinding $key [dict get $binding $key]}
    set lookupWire [dict create ok 1 result [dict create binding $lookupBinding]]
    if {[string bytelength $lookupWire]>8323072 || [string bytelength [_scriptJobTrackedPayload $capsule]]>8323072} {error {Encoded tracked original-owner metadata exceeds8MiB; no admission ID issued}}
    # BEFORE even reservation-helper startup/write/close: the real owner ID and
    # original destination survive every later invocation/transport exception.
    dict set ::GX::scriptJobRequests $id [dict create tracked_admission 1 trusted_owner 1 capsule $capsule callback $callback notified 0 state REGISTERING phase REGISTERING \
        options {ui_lifetime 0} cancelled {} stop_requested 0 prepare_command $prepareCommand diagnostics {}]
    # One acknowledged metadata epoch authorizes ONE explicit invocation. An
    # UNKNOWN or lost response can never reuse this readiness for another Job.
    dict set ::GX::scriptJobRequests [dict get $ready readiness_id] ready 0
    _scriptJobTrackedLaunch $id reserve [list {*}$command admission_begin] [_scriptJobTrackedPayload $capsule] [list ::GX::_scriptJobTrackedReserved $id] 12000
    return [dict create submission_id $id state PENDING admission_phase REGISTERING admission_owner $capsule]
}
proc ::GX::_scriptJobTrackedLaunch {id phase command payload callback timeout} {
    dict set ::GX::scriptJobRequests $id phase $phase
    set code [catch {
        _scriptJobTrackedCapsule [_scriptJobTrackedOwner $id] [expr {$phase in {reserve prepare}}]
        _scriptJobAsyncTracked $command $payload $callback [dict create timeout_ms $timeout max_bytes 1048576 ui_lifetime 0 label {Tracked original Job admission}]
    } reason]
    if {$code} {
        _scriptJobTrackedDiagnostic $id [dict create phase $phase error $reason startup_unknown 1]
        after 0 [list {*}$callback [dict create ok 0 error $reason error_type startup_unknown]]
    } else {_scriptJobTrackedCapture $reason;dict set ::GX::scriptJobRequests $id ${phase}_request $reason}
}
proc ::GX::_scriptJobTrackedReserved {id response} {
    if {![dict exists $::GX::scriptJobRequests $id tracked_admission]} return
    set entry [dict get $::GX::scriptJobRequests $id]
    if {![catch {set result [_scriptJobTrackedReceipt $id $response]}] && [dict get $result admission_state] ne {UNKNOWN}} {
        set capsule [dict get $entry capsule];dict set capsule scope [dict get $result scope]
        if {![catch {_scriptJobTrackedCapsule $capsule}]} {
            dict set ::GX::scriptJobRequests $id capsule $capsule
            if {[dict get $result admission_state] eq {OPEN} && ![dict get $entry stop_requested]} {
                set request [dict get $capsule binding]
                dict set request _tracked_admission [_scriptJobTrackedPayload $capsule]
                _scriptJobTrackedLaunch $id prepare [dict get $entry prepare_command] $request [list ::GX::_scriptJobTrackedPrepared $id] 120000
                return
            }
        }
    }
    _scriptJobTrackedResolve [_scriptJobTrackedOwner $id] [list ::GX::_scriptJobTrackedComplete $id] 1 [dict get $entry stop_requested]
}
proc ::GX::_scriptJobTrackedPrepared {id response} {
    if {![dict exists $::GX::scriptJobRequests $id tracked_admission]} return
    _scriptJobTrackedDiagnostic $id [dict create phase prepare transport_response $response]
    # Always reconcile the original transaction; even valid-looking transport
    # is not a separate Job authority, and empty EOF is not non-admission proof.
    _scriptJobTrackedResolve [_scriptJobTrackedOwner $id] [list ::GX::_scriptJobTrackedComplete $id] 1 [dict get $::GX::scriptJobRequests $id stop_requested]
}
proc ::GX::_scriptJobTrackedResolve {capsule callback {close_before_admission 0} {cancel_accepted 0} {handled_job_id {}}} {
    foreach flag [list $close_before_admission $cancel_accepted] {if {$flag ni {0 1}} {error {Tracked resolution flags must be exact0/1}}}
    set id [dict get $capsule submission_id]
    if {![dict exists $::GX::scriptJobRequests $id tracked_admission]} {
        # A restored capsule is DATA, not executable/root authority. The trusted
        # Session/Supervisor recovery hook must attach it first. Until then no
        # supplied command/hash/path is run, and no absence becomes retryable.
        set response [dict create ok 0 error {Original admission owner requires authoritative Session recovery} admission_state UNKNOWN submission_id $id retry_allowed 0]
        if {$callback ne {}} {after 0 [list {*}$callback $response]}
        return [dict create submission_id $id state PENDING admission_phase RECOVERY_REQUIRED retry_allowed 0]
    } else {
        set stored [dict get $::GX::scriptJobRequests $id capsule]
        if {![_scriptJobTrackedBindingMatch [dict get $stored binding] [dict get $capsule binding]]} {error {Tracked admission binding mismatch}}
        foreach field {schema submission_id authority_epoch owner_scope} {if {[dict get $stored $field] ne [dict get $capsule $field]} {error {Tracked admission owner mismatch}}}
        # Prefer the original owner's acknowledged physical scope over an older
        # initial capsule, never replace it with a different supplied database.
        if {[dict get $capsule scope] ne {} && [dict get $stored scope] ne {} && ![_scriptJobTrackedScopeMatch [dict get $stored scope] [dict get $capsule scope]]} {error {Tracked admission database mismatch}}
        set capsule $stored
    }
    if {$close_before_admission} {dict set ::GX::scriptJobRequests $id stop_requested 1}
    set command [list {*}[dict get $capsule command] admission_resolve $close_before_admission $cancel_accepted]
    if {$handled_job_id ne {}} {lappend command $handled_job_id}
    _scriptJobTrackedLaunch $id resolve $command [_scriptJobTrackedPayload $capsule] [list ::GX::_scriptJobTrackedResolved $id $callback] 12000
    return [dict create submission_id $id state PENDING admission_phase RESOLVING admission_owner $capsule]
}
proc ::GX::_scriptJobTrackedAcknowledge {owner_scope id job_id callback} {
    set scope [_scriptJobTrackedOwnerCurrent $owner_scope]
    if {$callback eq {}} {error {Original handling acknowledgment needs a callback}}
    if {![dict exists $::GX::scriptJobRequests $id trusted_owner]} {
        after 0 [list {*}$callback [dict create ok 0 error {Original accepted owner must be recovered before acknowledgment} admission_state UNKNOWN submission_id $id retry_allowed 0]]
    } else {
        set capsule [_scriptJobTrackedOwner $id]
        if {[dict get $capsule owner_scope] ne $scope} {error {Original handling owner scope mismatch}}
        _scriptJobTrackedResolve $capsule $callback 0 0 $job_id
    }
    return [dict create submission_id $id state PENDING admission_phase ACKNOWLEDGING retry_allowed 0]
}
proc ::GX::_scriptJobTrackedResolved {id callback response} {
    if {![dict exists $::GX::scriptJobRequests $id tracked_admission]} return
    set capsule [_scriptJobTrackedOwner $id];set output [dict create ok 0 error {Original admission certainty is unavailable} admission_state UNKNOWN submission_id $id admission_owner $capsule retry_allowed 0]
    if {![catch {set result [_scriptJobTrackedReceipt $id $response]}]} {
        set state [dict get $result admission_state]
        set retainedState [dict get $::GX::scriptJobRequests $id state]
        if {$retainedState in {ACCEPTED CLOSED} && $retainedState ne $state} {set state UNKNOWN;dict set output error {Late resolution cannot replace retained original admission history}}
        if {$state in {OPEN ACCEPTED CLOSED}} {
            dict set capsule scope [dict get $result scope]
            if {![catch {_scriptJobTrackedCapsule $capsule}]} {
                dict set ::GX::scriptJobRequests $id capsule $capsule
                set current [dict get $::GX::scriptJobRequests $id state]
                if {$current ni {ACCEPTED CLOSED} || $current eq $state} {dict set ::GX::scriptJobRequests $id state $state}
                dict set output admission_owner $capsule
                if {$state eq {ACCEPTED}} {
                    set accepted [dict create submission_id $id admission_state ACCEPTED job_id [dict get $result job_id] state {} admission_owner $capsule retry_allowed 0]
                    if {[dict exists $result job state]} {dict set accepted state [dict get $result job state]}
                    foreach field {cancel_requested cancellation_delivery_error job_available handled} {if {[dict exists $result $field]} {dict set accepted $field [dict get $result $field]}}
                    set output [dict create ok 1 result $accepted]
                    dict set ::GX::scriptJobRequests $id accepted_job_id [dict get $result job_id]
                } elseif {$state eq {CLOSED} && [dict get $result closed_before_admission]} {
                    set output [dict create ok 0 error {Original admission was closed before acceptance} admission_state CLOSED submission_id $id admission_owner $capsule retry_allowed 1 closed_before_admission 1]
                } else {dict set output owner_state OPEN;dict set output error {Original admission remains open; no non-admission certificate}}
            }
        }
    } elseif {[dict exists $response error]} {dict set output error [dict get $response error]}
    if {![dict get $output ok] && [dict exists $::GX::scriptJobRequests $id accepted_job_id]} {
        # Preserve genuine acceptance even when a later observation cannot
        # establish its CURRENT state. Never turn it into CLOSED/non-admission.
        dict set output admission_state UNKNOWN;dict set output known_admission_state ACCEPTED
        dict set output known_job_id [dict get $::GX::scriptJobRequests $id accepted_job_id]
        dict set output retry_allowed 0;dict unset output closed_before_admission
    }
    dict set ::GX::scriptJobRequests $id last_resolution $output
    if {$callback ne {}} {uplevel #0 [list {*}$callback $output]}
}
proc ::GX::_scriptJobTrackedComplete {id response} {
    if {![dict exists $::GX::scriptJobRequests $id tracked_admission] || [dict get $::GX::scriptJobRequests $id notified]} return
    dict set ::GX::scriptJobRequests $id notified 1
    set callback [dict get $::GX::scriptJobRequests $id callback]
    if {$callback ne {}} {uplevel #0 [list {*}$callback $response]}
}
proc ::GX::_scriptJobUnlaunchedRequest {callback response} {
    variable scriptJobCounter;variable scriptJobRequests
    set request job-request-[incr scriptJobCounter]
    dict set scriptJobRequests $request [dict create unlaunched 1 options {ui_lifetime 0} cancelled {} callback $callback response $response]
    after 0 [list ::GX::_scriptJobUnlaunchedDone $request]
    return $request
}
proc ::GX::_scriptJobUnlaunchedDone {request} {
    if {![dict exists $::GX::scriptJobRequests $request unlaunched]} return
    set entry [dict get $::GX::scriptJobRequests $request];dict unset ::GX::scriptJobRequests $request
    set response [dict get $entry response]
    if {[dict get $entry cancelled] ne {}} {dict set response ok 0;dict set response error "Managed observer cancelled before launch: [dict get $entry cancelled]";dict set response error_type [dict get $entry cancelled]}
    if {[dict get $entry callback] ne {}} {uplevel #0 [list {*}[dict get $entry callback] $response]}
}
proc ::GX::_scriptJobTrackedWait {capsule job_id callback} {
    if {$callback eq {}} {error {Tracked observation requires a callback}}
    set notify [list ::GX::_scriptJobTrackedWaitDone $capsule $job_id $callback]
    if {[catch {
        _scriptJobTrackedCapsule $capsule
        if {![regexp {^[A-Za-z0-9][A-Za-z0-9_.-]{0,191}$} $job_id]} {error {Invalid actual tracked Job ID}}
        set command [list {*}[dict get $capsule command] admission_wait $job_id 180]
        set payload [_scriptJobTrackedPayload $capsule]
    } reason]} {return [_scriptJobUnlaunchedRequest $notify [dict create ok 0 error $reason error_type observation_unavailable]]}
    return [_scriptJobAsyncTracked $command $payload $notify {timeout_ms 190000 max_bytes 65536 ui_lifetime 0 label {Original tracked completion}}]
}
proc ::GX::_scriptJobTrackedWaitDone {capsule job_id callback response} {
    set valid [expr {![catch {
        _scriptJobTrackedCapsule $capsule
        if {![dict get $response ok] || [dict get $response result id] ne $job_id || [dict get $response result state] ni {COMPLETED FAILED CANCELLED INTERRUPTED} || [lsort [dict keys [dict get $response result]]] ne {id state}} {error {Original tracked terminal observation is unavailable}}
    } reason]}]
    if {$valid} {set response [dict create ok 1 result [dict create id $job_id state [dict get $response result state]]]
    } else {
        set diagnostic $reason;if {[dict exists $response error]} {set diagnostic [dict get $response error]}
        set response [dict create ok 0 error $diagnostic admission_state UNKNOWN retry_allowed 0 requested_job_id $job_id]
        if {[dict exists $capsule submission_id]} {
            set sid [dict get $capsule submission_id];dict set response submission_id $sid
            if {[dict exists $::GX::scriptJobRequests $sid accepted_job_id]} {dict set response known_job_id [dict get $::GX::scriptJobRequests $sid accepted_job_id];dict set response known_admission_state ACCEPTED}
        }
    }
    uplevel #0 [list {*}$callback $response]
}
proc ::GX::scriptJobList {} {scriptJobCall list}
proc ::GX::scriptJobDescribe {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJobRecord $id describe]};scriptJobCall describe $id}
proc ::GX::scriptJobInspect {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJobRecord $id inspect]};scriptJobCall inspect $id}
proc ::GX::scriptJobLogRead {id {offset 0} {count 65536} {tail 0}} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJobRecord $id log_read $offset $count $tail]};scriptJobCall log_read $id $offset $count $tail}
proc ::GX::scriptExecutionInspectRun {session runId} {scriptJobCall inspect_run $session $runId}
proc ::GX::scriptExecutionRunSummaries {session} {scriptJobCall run_summaries $session}
proc ::GX::scriptJobCancel {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJob $id cancel]};scriptJobCall cancel $id}
proc ::GX::scriptJobWait {id {timeoutSeconds 60} {cancelCommand {}}} {
    if {![string is integer -strict $timeoutSeconds]||$timeoutSeconds<1||$timeoutSeconds>86400} {error {Job wait timeout must be an integer from 1 to 86400 seconds}}
    set lease {};if {![scientificExecutionRemoteId $id]} {set lease [scriptJobCall wait_begin $id]};set started [clock milliseconds];set cancelled 0
    try {
        while {1} {
            set info [scriptJobDescribe $id]
            if {[dict get $info state] in {COMPLETED FAILED CANCELLED INTERRUPTED}} break
            set requested [expr {[clock milliseconds]-$started>=1000*$timeoutSeconds}]
            if {$cancelCommand ne {}&&[{*}$cancelCommand]} {set requested 1}
            if {$requested&&!$cancelled} {scriptJobCancel $id;set cancelled 1}
            # Keep host events/cancellation responsive while CORE alone owns
            # admission, descendant lifetimes and terminal resource recovery.
            after 100;update
        }
        dict set info wait_cancel_requested $cancelled
        return $info
    } on error {message options} {
        catch {scriptJobCancel $id}
        return -options $options $message
    } finally {
        # On process/transport failure the supervisor reaps the caller lease,
        # cancels the owned child and restores capacity without caller cleanup.
        if {$lease ne {}} {catch {scriptJobCall wait_end [dict get $lease token]}}
    }
}
proc ::GX::scriptJobRecover {} {scriptJobCall recover}
source [file join [file dirname [info script]] script_job_presentation_v1.tcl]
# FUTURE WINDOWS PORTING REQUIREMENT: GUI close only detaches this client.
# Use the same LOCAL CORE Job API with an independent Windows supervisor/tray:
# reopen GUI, inspect jobs, cancel selected/all (confirm all), safe supervisor exit.
# No remote dispatch or mandatory service; native Job Objects own child lifetime.

proc ::GX::scriptJobStreamRead {id role {offset 0} {count 65536} {tail 0}} {scriptJobCall stream_read $id $role $offset $count $tail}
proc ::GX::scriptJobStreamPublish {id role datasetId {session {}}} {
    if {$session eq {}} {set record [scriptJobInspect $id]} else {set record [scriptExecutionInspectRun $session $id]}
    if {[dict get $record origin] eq {core_service}} {error {Private CORE service streams cannot be published as user results}}
    if {$::GX::currentSession eq {} || [file normalize [dict get $record session]] ne [file normalize $::GX::currentSession]} {error {Activate the source Job Session before publication}}
    set page [expr {$session eq {} ? [scriptJobStreamRead $id $role 0 65536 0] : [scriptJobCall run_stream_read $session $id $role 0 65536 0]}]
    if {![dict get $page available]} {error [dict get $page diagnostic]}
    if {![dict get $page complete]} {error {Wait for a terminal Job before publishing an immutable complete stream}}
    set path [dict get $page path];set before [sha256File $path]
    set producer [scriptAnalysisModule [dict get $record language]]
    set request [dict create dataset_id $datasetId contract document.text format txt source_file $path storage_kind text media_type text/plain provenance "Script Job $id; stream $role; source SHA [dict get $record source_sha256]" structured_metadata [dict create script.job_id $id script.stream_role $role script.source_sha256 [dict get $record source_sha256] script.stream_sha256 $before script.complete 1 text.encoding UTF-8]]
    set receipt [datasetFilePublicationPublish $::GX::currentSession $producer $request]
    if {[sha256File $path] ne $before} {error {Retained stream changed unexpectedly during publication}}
    return $receipt
}

proc ::GX::scriptJobDebugSubmit {reference parameters {options {}} {callback {}}} {dict set options debug 1;tailcall ::GX::scriptJobSubmit $reference $parameters $options $callback}
proc ::GX::scriptJobDebugRead {id} {scriptJobCall debug_read $id}
proc ::GX::scriptJobDebugCapabilities {language} {scriptJobCall debug_capabilities $language}
proc ::GX::scriptJobDebugControl {id operation sourceSha {frame 0}} {
    if {$operation eq {stop}} {return [scriptJobCancel $id]}
    scriptJobCall debug_control $id $operation $sourceSha $frame
}
