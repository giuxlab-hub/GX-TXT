#!/usr/bin/env tclsh
# SPDX-License-Identifier: GPL-3.0-or-later
# Script Bridge exposure: HOST_ONLY_JUSTIFIED. This fixed one-shot bootstrap
# belongs to the existing Script Job auxiliary request owner. Only the trusted
# owning GUI captures Module/Session/source and client-window lifetimes; worker
# scripts receive no bootstrap grant, arbitrary command or GUI attestation API.
# Scientific execution, source admission and durable client CAS remain in their
# existing owners. Incoming dictionaries are data and are never evaluated.

if {[catch {
    if {[llength $argv]!=1} {error {Viewer Bridge worker requires its framework argument}}
    set framework [lindex $argv 0]
    fconfigure stdin -encoding binary -translation binary
    set raw [read stdin 2097153]
    if {[string length $raw]>2097152} {error {Viewer Bridge worker request exceeds 2 MiB}}
    set encoded [encoding convertfrom utf-8 $raw]
    if {[encoding convertto utf-8 $encoded] ne $raw} {error {Viewer Bridge worker request requires canonical UTF-8}}
    if {[catch {dict size $encoded}] || [llength $encoded]!=10 || [lsort [dict keys $encoded]] ne {action context mode schema typed}} {error {Viewer Bridge worker request requires its exact inert envelope}}
    set request $encoded
    if {[dict get $request schema] ne {gxtxt.viewer_bridge_request.v1}} {error {Unknown Viewer Bridge worker request schema}}
    foreach key {action mode} {
        set value [dict get $request $key]
        if {$value eq {} || [string bytelength $value]>128 || [regexp {[\x00\r\n]} $value]} {error {Viewer Bridge worker requires bounded inert operation identities}}
    }
    set context [dict get $request context]
    if {[catch {dict size $context}]} {error {Viewer Bridge worker requires captured Host context}}
    foreach key {session module_selection job_root module_config} {
        if {![dict exists $context $key]} {error {Viewer Bridge worker Host context is incomplete}}
    }
    if {[catch {dict size [dict get $context module_config]}]} {error {Viewer Bridge worker Module configuration must be a dictionary}}
    if {[catch {llength [dict get $request typed]}]} {error {Viewer Bridge worker typed request must be an inert list}}
    set session [dict get $context session]
    if {$session eq {} || ![file isdirectory $session]} {error {Viewer Bridge worker original Session is unavailable}}
    if {[dict get $context job_root] eq {}} {error {Viewer Bridge worker Job root is unavailable}}

    set argv0 __viewer_script_bridge_request__
    # This admission child reads the GUI writer's committed Workspace through
    # the existing native reader. Scope its initialization flag so subsequent
    # Supervisor/scientific processes retain the exact caller environment.
    set bridgeWorkspaceAccessPresent [info exists ::env(GXTXT_NATIVE_WORKSPACE_ACCESS)]
    if {$bridgeWorkspaceAccessPresent} {set bridgeWorkspaceAccessValue $::env(GXTXT_NATIVE_WORKSPACE_ACCESS)}
    try {
        set ::env(GXTXT_NATIVE_WORKSPACE_ACCESS) read_only
        source [file join $framework gxtxt_pipeline.tcl]
    } finally {
        if {$bridgeWorkspaceAccessPresent} {
            set ::env(GXTXT_NATIVE_WORKSPACE_ACCESS) $bridgeWorkspaceAccessValue
        } else {
            unset -nocomplain ::env(GXTXT_NATIVE_WORKSPACE_ACCESS)
        }
    }
    # HOST_ONLY_JUSTIFIED: the existing fixed Script Job preparer receives its
    # own scoped reader initialization, never an inherited worker ENV policy.
    set ::GX::_scriptJobAdmissionWorkspaceAccess read_only
    ::GX::defaults
    ::GX::loadModuleCatalog
    set ::GX::currentSession $session
    if {[file isfile [file join $session metadata manifest.ini]]} {::GX::loadManifest [file join $session metadata manifest.ini]}
    # A saved Manifest must not replace the actual submitting Host's grants.
    set ::GX::currentSession $session
    ::GX::applyModuleSelection [dict get $context module_selection]
    set ::env(GXTXT_JOB_ROOT) [dict get $context job_root]
    dict for {key value} [dict get $context module_config] {set ::GX::moduleCfg($key) $value}
    ::GX::loadDatasetRegistry $session
    set result [::GX::viewerScriptBridgeWorker $request]
} message options]} {
    set errorCode [expr {[dict exists $options -errorcode] ? [dict get $options -errorcode] : {NONE}}]
    puts [dict create ok 0 error $message error_code $errorCode]
} else {
    puts [dict create ok 1 result $result]
}
