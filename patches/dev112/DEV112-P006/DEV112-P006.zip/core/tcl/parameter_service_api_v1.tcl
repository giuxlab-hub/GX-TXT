# Script Bridge operation policy: parameter_service_api_v1.script_bridge_policy.json (exact operation scope; no runtime registration).
# SPDX-License-Identifier: GPL-3.0-or-later
# CORE owns scope identity and canonical persistence; C owns all expressions.
namespace eval ::GX::Parameters {variable declarations {};variable contexts {};variable listeners {};variable state {};variable sessionToken {};variable overrides {};variable publicationPhase {};variable deferredHistory {}}
proc ::GX::parameterServiceInfo {} {return [dict create api_id CORE_PARAMETER_SERVICE_v1 authority portable_c scopes {session module workspace} namespace_assignment framework script_policy scoped_context_reads_read_views_and_binding_cas]}
proc ::GX::_parameterEnsure {} {
    variable scriptDir
    if {![llength [info commands ::GX::Parameters::native]]} {load [file join $scriptDir core parameters gxparameters[info sharedlibextension]] Gxparameters}
    set token [interactiveDocumentSessionToken]
    if {![info exists ::GX::Parameters::workspaceMetadataToken] || $::GX::Parameters::workspaceMetadataToken ne $token} {set ::GX::Parameters::workspaceMetadata {};set ::GX::Parameters::workspaceMetadataToken $token}
    if {$token ne $::GX::Parameters::sessionToken} {
        set ::GX::Parameters::sessionToken $token;set ::GX::Parameters::state {};set ::GX::Parameters::contexts {};set ::GX::Parameters::listeners {};set ::GX::Parameters::readViews {}
        if {![info exists ::GX::Parameters::workspaceMetadataToken] || $::GX::Parameters::workspaceMetadataToken ne $token} {set ::GX::Parameters::workspaceMetadata {};set ::GX::Parameters::workspaceMetadataToken $token}
        if {$::GX::currentSession ne {}&&[file isfile [file join $::GX::currentSession metadata manifest.ini]]} {
            set ini [parseIni [file join $::GX::currentSession metadata manifest.ini]]
            set ::GX::Parameters::state [datasetPublicationV2DictDefault $ini core_parameters.state {}]
        }
    }
}
proc ::GX::_parameterOwner {capability} {
    if {![dict exists $::GX::DatasetPrivate::owners $capability]} {error {Invalid framework module capability}}
    set owner [dict get $::GX::DatasetPrivate::owners $capability]
    if {$::GX::DatasetPrivate::activeContext ne {} && [dict get [datasetPrivateMetadataContext] module_id] ne $owner} {error {Module cannot use another owner capability}}
    return $owner
}
proc ::GX::parameterModuleRegister {definitions} {
    set identity [datasetPrivateMetadataContext];set module [dict get $identity module_id]
    _parameterDefinitionsValidate $definitions
    dict set ::GX::Parameters::declarations $module $definitions
    return [dict get $identity capability]
}
proc ::GX::_parameterDefinitionsValidate {definitions} {
    if {[dict size $definitions]>4096} {error {Too many parameters}}
    dict for {name record} $definitions {
        if {![regexp {^[A-Za-z_][A-Za-z0-9_]*$} $name]} {error "Invalid parameter name '$name'"}
        foreach key [dict keys $record] {if {$key ni {formula label description unit type min max editable}} {error "Unsupported parameter field '$key'; namespaces are assigned by CORE"}}
        if {![dict exists $record formula]} {error "Parameter '$name' needs a formula or numeric value"}
        foreach key {min max} {if {[dict exists $record $key]&&![string is double -strict [dict get $record $key]]} {error "Invalid $key for '$name'"}}
        if {[dict exists $record editable]&&![string is boolean -strict [dict get $record editable]]} {error "Invalid editability for '$name'"}
        if {[dict exists $record type]&&[dict get $record type] ni {number integer}} {error "Unsupported parameter type for '$name'"}
    }
    return $definitions
}
proc ::GX::_parameterFormulas {definitions} {set out {};dict for {name record} $definitions {dict set out $name [dict get $record formula]};return $out}
proc ::GX::_parameterEvaluate {definitions session {expression {}}} {
    _parameterEnsure;_parameterDefinitionsValidate $definitions
    set values [::GX::Parameters::native [_parameterFormulas $definitions] [_parameterFormulas $session]]
    dict for {name receipt} $values {
        set definition [dict get $definitions $name];set value [dict get $receipt value]
        foreach {field op} {min < max >} {if {[dict exists $definition $field]&&[expr "$value $op [dict get $definition $field]"]} {error "Parameter '$name' violates $field"}}
        if {[datasetPublicationV2DictDefault $definition type number] eq "integer"&&$value!=floor($value)} {error "Parameter '$name' requires an integer"}
        dict set values $name [dict merge $definition $receipt]
    }
    if {$expression ne {}} {return [::GX::Parameters::native [_parameterFormulas $definitions] [_parameterFormulas $session] $expression]}
    return $values
}
proc ::GX::parameterSessionDefinitions {} {_parameterEnsure;return [datasetPublicationV2DictDefault $::GX::Parameters::state session {}]}
proc ::GX::parameterSessionList {} {return [_parameterEvaluate [parameterSessionDefinitions] {}]}
proc ::GX::parameterSessionEvaluate {expression} {return [_parameterEvaluate [parameterSessionDefinitions] {} $expression]}
proc ::GX::parameterContext {capability {workspace {}}} {
    _parameterEnsure;set module [_parameterOwner $capability]
    if {$workspace ne {}} {set doc [sessionWorkspaceMetadata $workspace];if {![dict get $doc native_workspace] || ![dict get $doc compatible]} {error {Parameters require a compatible native Workspace}};if {[dict get $doc module_id] ne $module} {error {Workspace belongs to another module}}}
    set key [list $module $workspace];set token parameter#[parallelOctaveRandomToken]
    dict set ::GX::Parameters::contexts $token [dict create module $module workspace $workspace session [interactiveDocumentSessionToken] key $key]
    return $token
}
proc ::GX::_parameterContext {token} {
    _parameterEnsure
    if {![dict exists $::GX::Parameters::contexts $token]} {error {Invalid or stale parameter context}}
    set context [dict get $::GX::Parameters::contexts $token]
    if {$::GX::DatasetPrivate::activeContext ne {} && [dict get [datasetPrivateMetadataContext] module_id] ne [dict get $context module]} {error {Module cannot use another parameter context}}
    set workspace [dict get $context workspace]
    if {$workspace ne {}&&[dict get [interactiveDocumentMetadata $workspace] module_id] ne [dict get $context module]} {error {Parameter owner changed}}
    return $context
}
namespace eval ::GX::Parameters {variable readViews {}}
proc ::GX::parameterReadView {token definitions {sessionDefinitions {}}} {
    _parameterContext $token;_parameterDefinitionsValidate $definitions
    dict set ::GX::Parameters::readViews $token [dict create definitions $definitions session $sessionDefinitions]
}
proc ::GX::parameterReadViewClose {token} {dict unset ::GX::Parameters::readViews $token}
proc ::GX::parameterDefinitions {token} {
    _parameterContext $token
    if {[dict exists $::GX::Parameters::readViews $token]} {return [dict get $::GX::Parameters::readViews $token definitions]}
    set context [_parameterContext $token];set module [dict get $context module];set workspace [dict get $context workspace]
    set defaults [datasetPublicationV2DictDefault $::GX::Parameters::declarations $module {}]
    if {$workspace ne {}} {set metadata [_parameterWorkspaceMetadata $workspace];set stored [datasetPublicationV2DictDefault $metadata parameters {}]} else {set stored [datasetPublicationV2DictDefault $::GX::Parameters::state module.$module {}]}
    return [dict merge $defaults $stored]
}
proc ::GX::parameterViewSessionDefinitions {token} {
    if {[dict exists $::GX::Parameters::readViews $token]} {return [dict get $::GX::Parameters::readViews $token session]}
    return [parameterSessionDefinitions]
}
proc ::GX::parameterList {token} {return [_parameterEvaluate [parameterDefinitions $token] [parameterViewSessionDefinitions $token]]}
proc ::GX::parameterEvaluate {token expression} {return [_parameterEvaluate [parameterDefinitions $token] [parameterViewSessionDefinitions $token] $expression]}
proc ::GX::parameterContextInfo {token} {set c [_parameterContext $token];dict set c namespace module/[dict get $c module];return [dict remove $c key session]}
proc ::GX::parameterSubscribe {token callback} {_parameterContext $token;dict set ::GX::Parameters::listeners $token $callback}
proc ::GX::parameterUnsubscribe {token} {dict unset ::GX::Parameters::listeners $token}
proc ::GX::_parameterPropertyWrite {workspace expected field value} {
    if {![_nativeWorkspaceExists $workspace]} {error {Parameters require a native Workspace; obsolete Workspace writers are unsupported}}
    # Notification needs the full scientific stamp; a valid caller CAS receipt
    # may contain only id/generation/revision. Never substitute this fresh
    # metadata for the unchanged caller-held expected at the native write.
    set before [nativeWorkspaceMetadata $workspace]
    set properties [lindex [nativeWorkspaceProperties $workspace] 1]
    switch -- $field {
        parameters {set shape {map {record {formula text label text description text unit text type text min scientific_real max scientific_real editable bool}}}}
        parameter_bindings {set shape {map text}}
        default {error {Unsupported Parameter Workspace property}}
    }
    set typed [nativeWorkspaceEncode $shape $value]
    dict set properties $field $typed
    set receipt [nativeWorkspaceSetProperties $expected [list object $properties]]
    _nativeWorkspaceMetadataAdvanced $before [nativeWorkspaceMetadata $workspace] {} [dict create $field $typed]
    return $receipt
}
proc ::GX::_parameterWrite {token definitions} {
    if {$::GX::Parameters::publicationPhase ne {}} {error {A Parameter publication is already being prepared}}
    if {[dict exists $::GX::Parameters::readViews $token]} {error {This parameter context is inspecting History and is read-only.}}
    _parameterDefinitionsValidate $definitions
    set definitions [nativeWorkspaceScientificDecode [nativeWorkspaceEncode {map {record {formula text label text description text unit text type text min scientific_real max scientific_real editable bool}}} $definitions]]
    set oldState $::GX::Parameters::state;set documents {};set applied {};set written {};set pendingWrite {}
    if {$token eq "session"} {
        _parameterEvaluate $definitions {}
        # Validate dependencies of every stored Workspace before accepting a
        # Session change, including providers whose UI is currently closed.
        foreach workspace [sessionWorkspaceList] {
            if {![_nativeWorkspaceExists [dict get $workspace id]]} continue
            set metadata [_parameterWorkspaceMetadata [dict get $workspace id]]
            set local [datasetPublicationV2DictDefault $metadata parameters {}]
            set defaults [datasetPublicationV2DictDefault $::GX::Parameters::declarations [dict get $workspace module_id] {}]
            set local [dict merge $defaults $local]
            _parameterEvaluate $local $definitions
            foreach expression [dict values [datasetPublicationV2DictDefault $metadata parameter_bindings {}]] {_parameterEvaluate $local $definitions $expression}
        }
        dict for {scope local} $::GX::Parameters::state {if {[string match module.* $scope]} {_parameterEvaluate $local $definitions}}
        dict set ::GX::Parameters::state session $definitions
        set targets [dict keys $::GX::Parameters::listeners]
    } else {
        set context [_parameterContext $token];_parameterEvaluate $definitions [parameterSessionDefinitions]
        set workspace [dict get $context workspace]
        if {$workspace eq {}} {dict set ::GX::Parameters::state module.[dict get $context module] $definitions} else {
            if {![_nativeWorkspaceExists $workspace]} {error {Obsolete Workspace parameters cannot be updated}}
            set receipt [nativeWorkspaceMetadata $workspace]
            set properties [nativeWorkspaceProperties $workspace]
            dict set documents $workspace [dict create receipt $receipt properties $properties]
            foreach expression [dict values [datasetPublicationV2DictDefault [nativeWorkspaceDecode $properties] parameter_bindings {}]] {_parameterEvaluate $definitions [parameterSessionDefinitions] $expression}
            set proposed [nativeWorkspaceDecode $properties];dict set proposed parameters $definitions
            set pendingWrite [list $workspace $receipt $proposed]
        }
        set targets {}
        dict for {candidate callback} $::GX::Parameters::listeners {if {[dict get [_parameterContext $candidate] key] eq [dict get $context key]} {lappend targets $candidate}}
    }
    set ::GX::Parameters::publicationPhase prepare;set ::GX::Parameters::deferredHistory {}
    if {$pendingWrite ne {}} {dict set ::GX::Parameters::overrides [lindex $pendingWrite 0] [lindex $pendingWrite 2]}
    try {
        foreach target $targets {
            if {![dict exists $::GX::Parameters::listeners $target]} continue
            set workspace [dict get [_parameterContext $target] workspace]
            set callback [dict get $::GX::Parameters::listeners $target]
            set rollback [uplevel #0 [list {*}$callback $target]];lappend applied $rollback
        }
        set ::GX::Parameters::publicationPhase commit
        if {$pendingWrite ne {}} {lassign $pendingWrite workspace receipt;dict set written $workspace [_parameterPropertyWrite $workspace $receipt parameters $definitions]}
        if {$::GX::currentSession ne {}} {writeManifest [file join $::GX::currentSession metadata manifest.ini]}
        foreach action $::GX::Parameters::deferredHistory {uplevel #0 $action}
    } on error {message options} {
        set ::GX::Parameters::state $oldState
        set ::GX::Parameters::publicationPhase rollback;set ::GX::Parameters::overrides {}
        set recoveryErrors {}
        foreach rollback [lreverse $applied] {if {$rollback ne {} && [catch {uplevel #0 $rollback} reason]} {lappend recoveryErrors $reason}}
        dict for {id receipt} $written {
            if {[catch {
                set before [nativeWorkspaceMetadata $id]
                nativeWorkspaceSetProperties $receipt [dict get $documents $id properties]
                set restored [nativeWorkspaceMetadata $id]
                set prior [lindex [dict get $documents $id properties] 1]
                set delta [dict create parameters [expr {[dict exists $prior parameters]?[dict get $prior parameters]:{@gxtxt.workspace.property.remove}}]]
                _nativeWorkspaceMetadataAdvanced $before $restored {} $delta
            } reason]} {lappend recoveryErrors $reason}
        }
        if {$::GX::currentSession ne {} && [catch {writeManifest [file join $::GX::currentSession metadata manifest.ini]} reason]} {lappend recoveryErrors $reason}
        if {$recoveryErrors ne {}} {dict set options -errorcode {GX PARAMETER RECOVERY_REQUIRED};append message "; parameter rollback requires recovery: [join $recoveryErrors {; }]"}
        return -options $options $message
    } finally {set ::GX::Parameters::publicationPhase {};set ::GX::Parameters::overrides {};set ::GX::Parameters::deferredHistory {}}
    return [expr {$token eq "session"?[parameterSessionList]:[parameterList $token]}]
}
proc ::GX::_parameterChange {token name definition remove} {
    _interactiveDocumentRequireSession
    set definitions [expr {$token eq "session"?[parameterSessionDefinitions]:[parameterDefinitions $token]}]
    if {[dict exists $definitions $name]&&![datasetPublicationV2DictDefault [dict get $definitions $name] editable 1]} {error "Parameter '$name' is read-only"}
    if {$remove && $token ne "session"} {set owner [dict get [_parameterContext $token] module];if {[dict exists $::GX::Parameters::declarations $owner $name]} {error {Declared module parameters cannot be deleted; update their permitted value instead}}}
    if {$remove} {if {![dict exists $definitions $name]} {error "Unknown parameter '$name'"};dict unset definitions $name} else {dict set definitions $name $definition}
    return [_parameterWrite $token $definitions]
}
proc ::GX::parameterSet {token name definition} {_parameterContext $token;return [_parameterChange $token $name $definition 0]}
proc ::GX::parameterDelete {token name} {_parameterContext $token;return [_parameterChange $token $name {} 1]}
# Session administration is host/UI-only, never an operation on module tokens.
proc ::GX::parameterSessionSet {name definition} {if {$::GX::DatasetPrivate::activeContext ne {}} {error {Module callbacks cannot administer Session parameters}};return [_parameterChange session $name $definition 0]}
proc ::GX::parameterSessionDelete {name} {if {$::GX::DatasetPrivate::activeContext ne {}} {error {Module callbacks cannot administer Session parameters}};return [_parameterChange session $name {} 1]}
rename ::GX::manifestStringV2 ::GX::manifestStringV2_before_parameters
proc ::GX::manifestStringV2 {} {
    _parameterEnsure;set out [manifestStringV2_before_parameters]
    append out "\n\[core_parameters\]\n";appendKV out api_version 1;appendKV out state $::GX::Parameters::state
    return $out
}
rename ::GX::loadManifestV2 ::GX::loadManifestV2_before_parameters
proc ::GX::loadManifestV2 {path} {
    set ini [parseIni $path];set state [datasetPublicationV2DictDefault $ini core_parameters.state {}]
    _parameterEvaluate [datasetPublicationV2DictDefault $state session {}] {}
    loadManifestV2_before_parameters $path
    set ::GX::Parameters::sessionToken [interactiveDocumentSessionToken];set ::GX::Parameters::state $state
    set ::GX::Parameters::contexts {};set ::GX::Parameters::listeners {};set ::GX::Parameters::readViews {}
}

# A reusable Native2D consumer adapter: modules supply bindings, never parsers.
proc ::GX::parameterApplyDimensions {token scene expressions} {
    set values {};dict for {id expression} $expressions {dict set values $id [parameterEvaluate $token $expression]}
    ::GX::Native2D::core interaction_constraint_values $scene $values
    return $values
}

# Read-only Bridge entry points do not return reusable administration tokens.
proc ::GX::parameterWorkspaceRead {workspace {expression {}}} {
    set doc [sessionWorkspaceMetadata $workspace];set metadata [_parameterWorkspaceMetadata $workspace]
    set defaults [datasetPublicationV2DictDefault $::GX::Parameters::declarations [dict get $doc module_id] {}]
    set definitions [dict merge $defaults [datasetPublicationV2DictDefault $metadata parameters {}]]
    return [_parameterEvaluate $definitions [parameterSessionDefinitions] $expression]
}

# Persist consumer expression dependencies alongside canonical Workspace state,
# allowing closed providers to participate in formula/deletion validation.
proc ::GX::parameterBindingsSet {token bindings {expected {}}} {
    set context [_parameterContext $token];set workspace [dict get $context workspace]
    if {$workspace eq {}} {error {Consumer bindings require a Workspace context}}
    # Retain the caller's held receipt through validation and the final native
    # CAS. Re-reading a receipt after evaluation must never absorb another edit.
    # Existing two-argument callers capture the same pre-validation precondition.
    set current [nativeWorkspaceMetadata $workspace]
    if {$expected eq {}} {set expected $current}
    foreach field {id generation revision} {
        if {![dict exists $expected $field] || [dict get $expected $field] ne [dict get $current $field]} {
            return -code error -errorcode {GX PARAMETER CONFLICT} {Stale or foreign Parameter Workspace CAS receipt}
        }
    }
    dict for {id expression} $bindings {parameterEvaluate $token $expression}
    # Check even the no-op path after original C evaluation. The unchanged held
    # receipt is also passed to save_properties for the final atomic native CAS.
    set current [nativeWorkspaceMetadata $workspace]
    foreach field {id generation revision} {
        if {[dict get $expected $field] ne [dict get $current $field]} {
            return -code error -errorcode {GX PARAMETER CONFLICT} {Stale or foreign Parameter Workspace CAS receipt}
        }
    }
    if {[datasetPublicationV2DictDefault [_parameterWorkspaceMetadata $workspace] parameter_bindings {}] eq $bindings} return
    return [_parameterPropertyWrite $workspace $expected parameter_bindings $bindings]
}

# Parameter definitions are a small independently owned Workspace metadata view.
# Cache by canonical Document revision; a geometry edit's RAM History does not
# alter those definitions and must not force History projection/hash/replay.
namespace eval ::GX::Parameters {variable workspaceMetadata {}}
proc ::GX::_parameterWorkspaceMetadata {workspace} {
    if {[dict exists $::GX::Parameters::overrides $workspace]} {return [dict get $::GX::Parameters::overrides $workspace]}
    set item [interactiveDocumentMetadata $workspace]
    set key [list [interactiveDocumentSessionToken] $workspace]
    set stamp [list [dict get $item generation] [dict get $item revision] [dict get $item sha256]]
    if {![dict exists $::GX::Parameters::workspaceMetadata $key] || [dict get $::GX::Parameters::workspaceMetadata $key stamp] ne $stamp} {
        if {![_nativeWorkspaceExists $workspace]} {error {Obsolete Workspace parameter metadata is unsupported}}
        set properties [nativeWorkspaceProperties $workspace]
        set metadata [nativeWorkspaceDecode $properties]
        if {[dict exists [lindex $properties 1] parameters]} {dict set metadata parameters [nativeWorkspaceScientificDecode [dict get [lindex $properties 1] parameters]]}
        dict set ::GX::Parameters::workspaceMetadata $key [dict create stamp $stamp value $metadata]
    }
    return [dict get $::GX::Parameters::workspaceMetadata $key value]
}

# Seed only from an already published or SHA-verified payload. This avoids a
# full History-bearing Document read on the first edit after explicit Save.
proc ::GX::_parameterWorkspaceMetadataSeed {session item payload} {
    if {![info exists ::GX::currentSession] || $::GX::currentSession eq {} || [file normalize $::GX::currentSession] ne $session} return
    set token [interactiveDocumentSessionToken]
    if {![info exists ::GX::Parameters::workspaceMetadataToken] || $::GX::Parameters::workspaceMetadataToken ne $token} {
        set ::GX::Parameters::workspaceMetadata {};set ::GX::Parameters::workspaceMetadataToken $token
    }
    set key [list $token [dict get $item id]]
    if {[catch {dict get $payload workspace_metadata} metadata]} {
        if {[dict exists $::GX::Parameters::workspaceMetadata $key]} {dict unset ::GX::Parameters::workspaceMetadata $key}
        return
    }
    set stamp [list [dict get $item generation] [dict get $item revision] [dict get $item sha256]]
    dict set ::GX::Parameters::workspaceMetadata $key [dict create stamp $stamp value $metadata]
}
