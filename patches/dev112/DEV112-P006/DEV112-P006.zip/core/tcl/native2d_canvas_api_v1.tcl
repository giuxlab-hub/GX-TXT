# Script Bridge operation policy: native2d_canvas_api_v1.script_bridge_policy.json (exact operation scope; no runtime registration).
# SPDX-License-Identifier: GPL-3.0-or-later
# Canvas bindings to existing Native2D, Document/Resource, History and Workspace.
# Scientific geometry and interaction remain in the native C/C++ owners.
namespace eval ::GX::NativeCanvas {
    variable instances {}
    variable serial 0
    variable clipboard {}
    variable extensions {}
}
# Trusted module contributions to this existing Canvas owner. Registration is
# not a Script Bridge/SDK operation and designs contain IDs, never Tcl prefixes.
proc ::GX::native2DCanvasExtensionRegister {id descriptor} {
    _nativeCanvasFields $descriptor {schema module_id api_id api_version commands native_hooks viewer_hooks transient_fields scientific_provider projection_schema runtime_files} {schema module_id api_id api_version commands native_hooks viewer_hooks}
    if {![regexp {^[a-zA-Z][a-zA-Z0-9_.-]{0,127}$} $id] || [dict get $descriptor schema] ne {gxtxt.native2d.extension.v1}} {error {Invalid Native2D extension contract}}
    set module [dict get $descriptor module_id];set api [dict get $descriptor api_id]
    set issued [datasetPrivateMetadataContext]
    if {[dict get $issued module_id] ne $module || ![dict exists $::GX::DatasetPrivate::owners [dict get $issued capability]] || [dict get $::GX::DatasetPrivate::owners [dict get $issued capability]] ne $module} {error {Extension registration requires its actual module-issued context}}
    if {![info exists ::GX::modulePublicApiActivated($module,$api)]} {error {Extension API has not entered original public activation}}
    set file [moduleField $module descriptor {}];set data [parseIni $file]
    if {$api ni [modulePublicApiIds $module] || [descriptorValue $data public_api.$api api_version {}] ne [dict get $descriptor api_version]} {error {Extension differs from its declared public API/version}}
    set ownerNamespace [descriptorValue $data public_api.$api namespace {}]
    if {![regexp {^::[A-Za-z][A-Za-z0-9_:]*$} $ownerNamespace]} {error {Extension API needs its declared owner namespace}}
    set callbacks {}
    dict for {command spec} [dict get $descriptor commands] {
        if {![regexp {^[a-zA-Z][a-zA-Z0-9_]{0,95}$} $command]} {error {Invalid registered extension command}}
        _nativeCanvasFields $spec {arguments result effect required_grants command} {arguments result effect required_grants command}
        if {[dict get $spec effect] ni {read presentation mutate submit publish}} {error {Extension command needs an explicit effect}}
        dict for {grant operations} [dict get $spec required_grants] {
            if {![regexp {^[A-Z][A-Z0-9_]*_v[0-9]+$} $grant]} {error {Invalid extension capability identity}}
            foreach operation $operations {if {![regexp {^[A-Za-z][A-Za-z0-9_]*$} $operation]} {error {Invalid extension capability operation}}}
        }
        lappend callbacks [dict get $spec command]
    }
    set nativeHooks {navigation input_cancel input_locked input_accepted pending_view before_present after_present view_changed cancel_pending image_projection image_projection_context image_dimensions roi_image_context roi_context capture_projection owner_admit dispose}
    set viewerHooks {initialize event action_enabled capture_visibility capture restore_check restore dispose}
    foreach {field allowed} [list native_hooks $nativeHooks viewer_hooks $viewerHooks] {
        dict for {hook prefix} [dict get $descriptor $field] {if {$hook ni $allowed} {error {Unknown extension hook}};lappend callbacks $prefix}
    }
    foreach prefix $callbacks {
        if {![llength $prefix] || ![string match ${ownerNamespace}::* [lindex $prefix 0]] || ![llength [info commands [lindex $prefix 0]]]} {error {Extension callbacks must be existing literal commands in the actual API namespace}}
    }
    foreach field [datasetPublicationV2DictDefault $descriptor transient_fields {}] {
        if {![regexp {^[a-z][a-z0-9_]*$} $field] || $field in {canvas_handle owner_generation native geometry document receipt session module provider canvas frame callback scheduler subscription photos resources history snapshot pending sequence operation_admission read_only presentation_parent presentation_parent_context companion_view companion_slot companion_slot_id companion_parent_frame_id companion_layout accepting extension_id extension_owner glyph_cache roi_tool roi_gesture}} {error {Extension cannot discard a CORE-owned state field}}
    }
    foreach field {scientific_provider projection_schema} {
        if {[dict exists $descriptor $field] && ![regexp {^[A-Za-z][A-Za-z0-9_.-]{0,159}$} [dict get $descriptor $field]]} {error {Invalid scientific extension contract identity}}
    }
    if {[dict exists $descriptor native_hooks capture_projection] && (![dict exists $descriptor scientific_provider] || ![dict exists $descriptor projection_schema])} {error {Scientific capture requires its registered provider and projection schema}}
    set entry [file normalize [file join [file dirname $file] [descriptorValue $data public_api.$api entrypoint {}]]]
    set owner [dict create module_id $module api_id $api api_version [dict get $descriptor api_version] descriptor [file normalize $file] descriptor_sha256 [sha256File $file] entrypoint $entry entrypoint_sha256 [sha256File $entry]]
    set sourceOwner [modulePublicApiCallbacksCapture $module $api $callbacks [datasetPublicationV2DictDefault $descriptor runtime_files {}]]
    set record [dict create owner $owner contract $descriptor source_owner $sourceOwner]
    if {[dict exists $::GX::NativeCanvas::extensions $id] && [dict get $::GX::NativeCanvas::extensions $id] ne $record} {error {Native2D extension owner/contract cannot change in this process}}
    dict set ::GX::NativeCanvas::extensions $id $record
    return $id
}
proc ::GX::native2DCanvasExtensionDescribe {id} {
    set record [_nativeCanvasExtensionDefinition $id]
    set contract [dict get $record contract]
    dict set contract native_hooks [dict keys [dict get $contract native_hooks]]
    dict set contract viewer_hooks [dict keys [dict get $contract viewer_hooks]]
    dict for {name command} [dict get $contract commands] {dict unset command command;dict set contract commands $name $command}
    return [dict merge [dict get $record owner] $contract [dict create extension_id $id]]
}
proc ::GX::_nativeCanvasExtensionDefinition {id} {
    if {![dict exists $::GX::NativeCanvas::extensions $id]} {error {Native2D extension is not registered by an activated public owner}}
    set record [dict get $::GX::NativeCanvas::extensions $id]
    set owner [dict get $record owner];set module [dict get $owner module_id];set api [dict get $owner api_id]
    if {![info exists ::GX::modulePublicApiActivated($module,$api)] || $::GX::modulePublicApiActivated($module,$api) ne [dict get $owner entrypoint]} {error {Native2D extension public activation has not completed successfully}}
    modulePublicApiCallbacksCurrent [dict get $record source_owner]
    return $record
}
proc ::GX::_nativeCanvasExtensionId {row} {return [datasetPublicationV2DictDefault $row extension_id {}]}
proc ::GX::_nativeCanvasExtensionTransient {row} {
    set id [_nativeCanvasExtensionId $row]
    if {$id eq {}} {return $row}
    return [dict remove $row {*}[datasetPublicationV2DictDefault [dict get [_nativeCanvasExtensionDefinition $id] contract] transient_fields {}]]
}
proc ::GX::_nativeCanvasContextFromRow {handle row} {
    return [dict create schema gxtxt.native2d.canvas_context.v1 handle $handle canvas_id [datasetPublicationV2DictDefault [dict get $row snapshot] canvas_id $handle] module_id [dict get $row module] provider_id [dict get $row provider] document_id [dict get $row document] document_receipt [dict get $row receipt] session [dict get $row session] sequence [dict get $row sequence] canvas_generation [dict get $row owner_generation] mounted [expr {[dict get $row canvas] ne {}}]]
}
proc ::GX::native2DCanvasContext {handle} {return [_nativeCanvasContextFromRow $handle [_nativeCanvasRequire $handle]]}
proc ::GX::native2DCanvasContextCurrent {handle context} {
    set current [native2DCanvasContext $handle]
    if {$current ne $context} {error {Canvas owner, Session, Document or operation changed}}
    return $current
}
proc ::GX::native2DCanvasSourcesCurrent {handle expected} {
    # Public source admission over the SAME Canvas/held-Resource owner.
    # This read guard grants no edit, asynchronous adoption or gesture policy.
    native2DCanvasContextCurrent $handle $expected
    _nativeCanvasAdmitSources [_nativeCanvasRequire $handle] 1
    return [native2DCanvasContextCurrent $handle $expected]
}
proc ::GX::native2DCanvasRetainResources {handle expected references} {
    # Retention is a generic Document operation over existing verified owned
    # Resources. Callers supply neither private History nor a replacement scene.
    native2DCanvasSourcesCurrent $handle $expected
    set row [_nativeCanvasRequire $handle]
    if {[dict get $row pending] ne {}} {error {Finish the current Canvas operation before retaining its outputs}}
    set snapshot [native2DCanvasCapture $handle]
    set retained [dict get $snapshot retained_outputs]
    foreach reference $references {if {$reference ni $retained} {lappend retained $reference}}
    # A new checkpoint also retains the prior outputs: validate that complete
    # proposed set through the same original Resource owner, not just additions.
    foreach reference $retained {
        if {[dict get $reference document_id] ne [dict get $expected document_id] ||
            [dict get $reference owner_generation] ne [dict get $expected document_receipt generation]} {error {Retained Canvas Resource belongs to a different Document owner}}
        interactiveDocumentResourceInfo $reference
    }
    set changed [expr {$retained ne [dict get $snapshot retained_outputs]}]
    if {$changed} {
        dict set snapshot retained_outputs $retained
        native2DCanvasSnapshotValidate $snapshot
    }
    native2DCanvasSourcesCurrent $handle $expected
    # Pending custody can change without changing this public context. Re-admit
    # it AFTER validation; never clear another operation in order to checkpoint.
    set row [_nativeCanvasRequire $handle]
    if {[dict get $row pending] ne {}} {error {Finish the current Canvas operation before retaining its outputs}}
    if {!$changed} {return [native2DCanvasContextCurrent $handle $expected]}
    _nativeCanvasStore $handle $snapshot [dict get $row history]
    return [native2DCanvasContext $handle]
}
proc ::GX::native2DCanvasEditCapture {handle} {
    set held [_nativeCanvasEditCapture $handle]
    dict set held sequence [dict get [_nativeCanvasRequire $handle] sequence]
    return $held
}
proc ::GX::native2DCanvasEditCurrent {handle held} {_nativeCanvasEditCurrent $handle $held;return 1}
proc ::GX::native2DCanvasOperationBegin {handle expected pending held {expectedPending {}}} {
    # The existing scientific preflight sees the OLD sequence/pending state.
    # Only after its async owner returns may CORE admit the new operation.
    native2DCanvasContextCurrent $handle $expected
    _nativeCanvasEditCurrent $handle $held
    native2DCanvasContextCurrent $handle $expected
    if {[catch {dict size $expectedPending}]} {error {Expected Canvas pending state must be a dictionary}}
    if {[dict get [_nativeCanvasRequire $handle] pending] ne $expectedPending} {error {Canvas pending state changed before operation admission}}
    if {[catch {dict size $pending}] || ![dict size $pending]} {error {Canvas operation requires its original pending ownership record}}
    dict set ::GX::NativeCanvas::instances $handle sequence [expr {[dict get $expected sequence]+1}]
    dict set ::GX::NativeCanvas::instances $handle pending $pending
    set beforeHeld $held
    dict set held sequence [dict get $::GX::NativeCanvas::instances $handle sequence]
    set current [native2DCanvasContext $handle]
    dict set ::GX::NativeCanvas::instances $handle operation_admission [dict create before_held $beforeHeld held $held context $current]
    return [dict create context $current held $held]
}
proc ::GX::native2DCanvasOperationContinuation {handle originalHeld admittedHeld} {
    # Only this owner's recorded Begin transition proves an unchanged parent
    # edit across a nested operation. A fresh capture after Cancel/Retire does
    # not renew an older capability. Return the already-issued held unchanged.
    _nativeCanvasEditCurrent $handle $admittedHeld
    set row [_nativeCanvasRequire $handle]
    if {![dict exists $row operation_admission]} {error {Canvas has no original admission continuation}}
    set origin [dict get $row operation_admission]
    native2DCanvasContextCurrent $handle [dict get $origin context]
    if {$admittedHeld ne [dict get $origin held]} {error {Canvas continuation is not its original admitted edit}}
    foreach field {native document receipt session history sequence} {
        if {[dict get $originalHeld $field] ne [dict get $origin before_held $field]} {error {Canvas parent edit differs from its actual admission origin}}
    }
    return $admittedHeld
}
proc ::GX::native2DCanvasOperationUpdate {handle expected pending} {
    native2DCanvasContextCurrent $handle $expected
    if {[catch {dict size $pending}]} {error {Canvas pending ownership must be a dictionary}}
    dict set ::GX::NativeCanvas::instances $handle pending $pending
    return [native2DCanvasContext $handle]
}
proc ::GX::native2DCanvasOperationRetire {handle expected} {
    # Invalidate adoption while retaining the original pending custody record.
    # Retirement proves neither cancellation, terminal state nor nonadmission.
    native2DCanvasContextCurrent $handle $expected
    dict set ::GX::NativeCanvas::instances $handle sequence [expr {[dict get $expected sequence]+1}]
    return [native2DCanvasContext $handle]
}
proc ::GX::native2DCanvasOperationCurrent {handle expected {allowViewOnlyPan 0}} {
    # The original raster adoption owner retains source and gesture policy.
    # Public callers carry only the CORE context, never a native engine stamp.
    native2DCanvasContextCurrent $handle $expected
    _nativeCanvasRasterCurrent $handle [_nativeCanvasRasterStamp $handle] $allowViewOnlyPan
    return [native2DCanvasContextCurrent $handle $expected]
}
proc ::GX::native2DCanvasOperationCancel {handle} {_nativeCanvasCancelPending $handle;return 1}
proc ::GX::native2DCanvasCommitSnapshot {handle held snapshot description {options {}}} {return [_nativeCanvasCommitSnapshot $handle $held $snapshot $description $options]}
proc ::GX::native2DCanvasSnapshot {handle} {return [native2DCanvasCapture $handle]}
proc ::GX::native2DCanvasRetainedInfo {handle} {
    # A closed metadata projection of the original retained scene; scoped
    # Geometry tokens replace native object IDs. No serialized Resource writes.
    set context [native2DCanvasContext $handle];set row [_nativeCanvasRequire $handle]
    set state [_nativeCanvasIndexedState [_nativeCanvasReconcile $handle]]
    set geometry [dict get $row geometry];set scene [_native2DGeometryRequire $geometry]
    set tokens {};dict for {token entry} [dict get $scene objects] {dict set tokens [dict get $entry native] $token}
    set objects {};set layers {};set selection {}
    foreach item [dict get $state layers] {lappend layers [dict remove $item id canvas_metadata]}
    foreach item [dict get $state objects] {
        set id [dict get $item id];set logical [dict get $item logical_id]
        if {![dict exists $tokens $id]} {error {Retained object is outside its public Geometry owner}}
        set token [dict get $tokens $id]
        set facts [native2DGeometryCall $geometry describe [dict create object_token $token]]
        lappend objects [dict create logical_id $logical kind [dict get $item kind] geometry $geometry object_token $token \
            layer_logical_id [_nativeCanvasLogicalFromId $state layers [dict get $item layer]] attributes [dict get $item attributes] bounds [dict get $facts bounds]]
        if {$id in [dict get $state selected_objects]} {lappend selection $logical}
    }
    native2DCanvasContextCurrent $handle $context
    return [dict create schema gxtxt.native2d.retained_info.v1 context $context layers $layers objects $objects selection $selection]
}
proc ::GX::native2DCanvasImageInfo {handle logical} {
    set before [native2DCanvasContext $handle]
    set row [_nativeCanvasRequire $handle];set snapshot [dict get $row snapshot]
    set leaf [_nativeCanvasRasterLeaf $snapshot $logical]
    set geometry [dict get $row geometry];set scene [_native2DGeometryRequire $geometry]
    set state [_nativeCanvasIndexedState [_nativeCanvasReconcile $handle]]
    set id [_nativeCanvasLogical $state objects $logical];set objectToken {}
    dict for {candidate entry} [dict get $scene objects] {if {[dict get $entry native]==$id} {set objectToken $candidate;break}}
    if {$objectToken eq {}} {error {Image is outside its public geometry owner}}
    set image [dict remove [_native2DRasterImage $scene $objectToken] id]
    # The original held Resource reader above verifies physical currentness.
    # This metadata facade is also used for provisional pointer geometry; it
    # does not hash full raster bytes or certify scientific Job/output lineage.
    set attributes [::GX::Native2D::core identity_attributes [dict get $scene native] $id]
    set canonical [datasetPublicationV2DictDefault [dict get $scene objects $objectToken metadata] raster_dataset {}]
    set collection [native2DGeometryCall $geometry raster_roi_get [dict create object_token $objectToken]]
    native2DCanvasContextCurrent $handle $before
    return [dict create context $before canvas_id [dict get $snapshot canvas_id] logical $logical geometry $geometry object_token $objectToken image $image leaf $leaf attributes $attributes canonical_binding $canonical collection $collection]
}
proc ::GX::native2DCanvasViewInfo {handle} {
    set row [_nativeCanvasRequire $handle]
    set state [[dict get $row native] state scalar]
    set result [dict create context [native2DCanvasContext $handle] viewport {} mount_incarnation {}]
    if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
        dict set result viewport [list [winfo width [dict get $row canvas]] [winfo height [dict get $row canvas]]]
        if {[dict exists $row frame] && [winfo exists [dict get $row frame]]} {dict set result mount_incarnation [winfo id [dict get $row frame]]}
    }
    foreach key {extent view_state tool gesture} {if {[dict exists $state $key]} {dict set result $key [dict get $state $key]}}
    set scene [dict get $state scene]
    dict set result roi_gesture_active [dict exists $row roi_gesture]
    dict set result view [::GX::Native2D::core view $scene]
    dict set result view_state [::GX::Native2D::core view_state $scene]
    dict set result bounds [::GX::Native2D::core scene_bounds $scene 0]
    return $result
}
proc ::GX::native2DCanvasSchedule {handle} {
    set row [_nativeCanvasRequire $handle]
    if {[dict get $row scheduler] ne {}} {guiUpdateSchedulerRequest [dict get $row scheduler]}
}
proc ::GX::native2DCanvasPresentationHost {handle} {
    # Trusted UI consumers get the real mounted host and an existing scoped
    # Geometry token, never the private native scene, scheduler or Canvas row.
    set row [_nativeCanvasRequire $handle]
    foreach field {frame canvas scheduler geometry} {
        if {![dict exists $row $field] || [dict get $row $field] eq {}} {error {Native2D presentation is not mounted}}
    }
    set frame [dict get $row frame];set canvas [dict get $row canvas]
    if {![winfo exists $frame] || ![winfo exists $canvas]} {error {Native2D presentation host has closed}}
    set geometry [_native2DGeometryRequire [dict get $row geometry]]
    set scene [dict get [[dict get $row native] state scalar] scene]
    if {[dict get $geometry native] ne $scene || ![dict exists $::GX::ViewportHost::hosts $canvas scene] ||
        [dict get $::GX::ViewportHost::hosts $canvas scene] ne $scene} {error {Native2D presentation has another viewport owner}}
    guiUpdateSchedulerDescribe [dict get $row scheduler]
    return [dict create context [native2DCanvasContext $handle] geometry [dict get $row geometry] frame $frame \
        frame_id [winfo id $frame] canvas_id [winfo id $canvas] toplevel [winfo toplevel $frame] \
        read_only [datasetPublicationV2DictDefault $row read_only 0] parent_handle [datasetPublicationV2DictDefault $row presentation_parent {}]]
}
proc ::GX::native2DCanvasViewChanged {handle} {_nativeCanvasRequire $handle;_nativeCanvasViewportChanged $handle;return 1}
proc ::GX::native2DCanvasPaintOrder {handle} {
    set context [native2DCanvasContext $handle]
    set row [_nativeCanvasRequire $handle];set native [dict get $row native]
    set state [_nativeCanvasIndexedState [$native state]]
    set scene [dict get $state scene];set layers {};set ordered {};set objects {}
    foreach layer [dict get $state layers] {lappend ordered [list [dict get $layer properties order] [dict get $layer id] [dict get $layer logical_id]]}
    foreach entry [lsort -integer -index 0 [lsort -integer -index 1 $ordered]] {lappend layers [lindex $entry 2]}
    foreach descriptor [$native presentation] {
        if {![dict exists $descriptor object]} continue
        set object [dict get $descriptor object]
        lappend objects [dict create logical_id [dict get $descriptor id] paint_order [dict get $descriptor z] kind [::GX::Native2D::core kind $scene $object]]
    }
    native2DCanvasContextCurrent $handle $context
    return [dict create context $context layers $layers objects $objects]
}
proc ::GX::native2DCanvasPresentationCapture {handle logical} {
    set context [native2DCanvasContext $handle]
    set facts [native2DCanvasImageInfo $handle $logical]
    set row [_nativeCanvasRequire $handle];set state [[dict get $row native] state scalar]
    set view [native2DCanvasViewInfo $handle]
    set admitted {}
    dict for {other stamp} [_nativeCanvasDisplayInstances $row [dict get $view mount_incarnation]] {
        set otherView [native2DCanvasViewInfo $other]
        dict set admitted $other [dict create context [native2DCanvasContext $other] mount_incarnation [dict get $otherView mount_incarnation]]
    }
    set capture [dict create schema gxtxt.native2d.presentation_capture.v1 context $context logical_id $logical \
        geometry [dict get $facts geometry] object_token [dict get $facts object_token] \
        image [dict get $facts image state] reference [dict get $facts image resource] \
        view_state [dict get $view view_state] viewport [dict get $view viewport] mount_incarnation [dict get $view mount_incarnation] \
        native_state_sha256 [_nativeCanvasBinaryIdentity [encoding convertto utf-8 $state]] admitted_contexts $admitted]
    native2DCanvasPresentationCurrent $capture
    return $capture
}
proc ::GX::native2DCanvasPresentationCurrent {capture} {
    _nativeCanvasFields $capture {schema context logical_id geometry object_token image reference view_state viewport mount_incarnation native_state_sha256 admitted_contexts} \
        {schema context logical_id geometry object_token image reference view_state viewport mount_incarnation native_state_sha256 admitted_contexts}
    if {[dict get $capture schema] ne {gxtxt.native2d.presentation_capture.v1}} {error {Unsupported Native2D presentation capture}}
    set context [dict get $capture context];set handle [dict get $context handle]
    native2DCanvasContextCurrent $handle $context
    set row [_nativeCanvasRequire $handle];set native [dict get $row native]
    set state [$native state scalar];set scene [dict get $state scene]
    set indexed [_nativeCanvasIndexedState [$native state]]
    set object [_nativeCanvasLogical $indexed objects [dict get $capture logical_id]]
    set geometry [dict get $row geometry];set owned [_native2DGeometryRequire $geometry]
    if {$geometry ne [dict get $capture geometry] || [_native2DGeometryObject $owned [dict get $capture object_token]] ne $object ||
        [_nativeCanvasBinaryIdentity [encoding convertto utf-8 $state]] ne [dict get $capture native_state_sha256] ||
        [::GX::Native2D::core image_get $scene $object] ne [dict get $capture image] ||
        ![dict exists $::GX::Native2DRaster::resources $scene $object] || [dict get $::GX::Native2DRaster::resources $scene $object] ne [dict get $capture reference]} {error {Native2D image presentation changed}}
    set view [native2DCanvasViewInfo $handle]
    foreach field {view_state viewport mount_incarnation} {if {[dict get $view $field] ne [dict get $capture $field]} {error {Native2D viewport presentation changed}}}
    set original [_nativeCanvasDisplayInstances $row [dict get $capture mount_incarnation]];set admitted {}
    if {[lsort [dict keys $original]] ne [lsort [dict keys [dict get $capture admitted_contexts]]]} {error {Native2D presentation capture omitted or replaced an admitted owner}}
    dict for {other expected} [dict get $capture admitted_contexts] {
        native2DCanvasContextCurrent $other [dict get $expected context]
        if {![dict exists $original $other] || [dict get [native2DCanvasViewInfo $other] mount_incarnation] ne [dict get $expected mount_incarnation]} {error {Native2D display admission changed}}
        dict set admitted $other [dict get $original $other]
    }
    _nativeCanvasDisplayCurrent $row $scene $object [dict get $capture reference] [dict get $capture image] $state \
        [dict get $capture view_state] [dict get $capture mount_incarnation] $admitted
    native2DCanvasContextCurrent $handle $context
    if {[$native state scalar] ne $state || [dict get [native2DCanvasViewInfo $handle] view_state] ne [dict get $capture view_state]} {error {Native2D presentation changed during source verification}}
    return 1
}
proc ::GX::native2DCanvasPhotoInUse {handle photo} {
    set row [_nativeCanvasRequire $handle]
    return [expr {$photo in [dict values [dict get $row photos]]}]
}
proc ::GX::native2DCanvasStatus {handle message} {_nativeCanvasRequire $handle;_nativeCanvasStatus $handle $message}
proc ::GX::native2DCanvasNotify {handle event} {_nativeCanvasRequire $handle;_nativeCanvasNotify $handle $event}
proc ::GX::native2DResourceImageDimensions {reference} {
    interactiveDocumentResourceInfo $reference
    set dimensions [_native2DImageDimensions $reference]
    interactiveDocumentResourceInfo $reference
    return $dimensions
}
proc ::GX::native2DResourceRasterInfo {reference} {
    # The original bounded display-raster inspector, independent of any
    # application's scientific output roles or numerical publication facts.
    set file [interactiveDocumentResourceLocalFileInfo $reference]
    set dimensions [_native2DRasterHelper info [dict get $file path]]
    if {[interactiveDocumentResourceLocalFileInfo $reference] ne $file} {error {Raster Resource changed during display metadata inspection}}
    return [dict create width [lindex $dimensions 0] height [lindex $dimensions 1]]
}
proc ::GX::native2DCanvasSnapshotImage {handle resource provenance originalLogical fullPrecision {targetLogical {}} {attributes {}} {removeAttributes {}}} {
    set context [native2DCanvasContext $handle]
    set snapshot [native2DCanvasCapture $handle]
    set original {}
    if {$originalLogical ne {}} {set original [_nativeCanvasRasterLeaf $snapshot $originalLogical]}
    if {$targetLogical eq {}} {set targetLogical $originalLogical}
    if {$targetLogical eq {}} {set targetLogical "canvas_image:[pid]:[incr ::GX::NativeCanvas::serial]"}
    # Same grammar as the original native Canvas logicalIdentity owner.
    if {![regexp {^[A-Za-z][A-Za-z0-9_.:#-]{0,127}$} $targetLogical]} {error {Image candidate requires an original bounded Canvas logical identity}}
    if {[catch {dict size $attributes}] || [dict exists $attributes gx.canvas]} {error {Image attributes must be inert data and cannot replace the CORE logical identity}}
    foreach key $removeAttributes {
        if {$key eq {gx.canvas} || [dict exists $attributes $key]} {error {Image attribute removal cannot replace the CORE identity or conflict with a supplied value}}
    }
    foreach kind {layers objects groups} {
        foreach item [dict get $snapshot $kind] {
            if {[dict get $item logical_id] eq $targetLogical && !($kind eq {objects} && $targetLogical eq $originalLogical)} {error {Image candidate target conflicts with the current Canvas snapshot}}
        }
    }
    foreach reference [list $resource $provenance] {
        if {$reference eq {} || ![dict exists $reference owner_generation] || [dict get $reference document_id] ne [dict get $context document_id] || [dict get $reference owner_generation] ne [dict get $context document_receipt generation]} {error {Image candidate Resource has a foreign Document owner}}
        interactiveDocumentResourceInfo $reference
    }
    native2DCanvasContextCurrent $handle $context
    set result [_nativeCanvasRasterGeometry $handle $resource $provenance $original $originalLogical $fullPrecision $targetLogical $attributes $removeAttributes]
    native2DCanvasContextCurrent $handle $context
    return $result
}
proc ::GX::native2DCanvasClipboardPasteSnapshot {handle held request} {return [_nativeCanvasClipboardPasteSnapshot $handle $held $request]}
proc ::GX::_nativeCanvasExtensionCall {handle hook args} {
    set retired [expr {$hook in {cancel_pending input_cancel dispose}}]
    set row [_nativeCanvasRequire $handle [expr {!$retired}]]
    set id [_nativeCanvasExtensionId $row]
    if {$id eq {}} {return {}}
    set contract [dict get [_nativeCanvasExtensionDefinition $id] contract]
    if {![dict exists $contract native_hooks $hook]} {return {}}
    set prefix [dict get $contract native_hooks $hook]
    # CORE supplies the real frontend ownership context. The backend's static
    # declaration is not a foreign Document/Resource issuer or caller callback.
    if {!$retired} {set before [native2DCanvasContext $handle]}
    set result [_datasetPrivateWithModule [dict get $row module] [list uplevel #0 [list {*}$prefix $handle {*}$args]]]
    _nativeCanvasExtensionDefinition $id
    if {!$retired && !($hook eq {before_present} && $result ne {} && [string is boolean -strict $result] && $result)} {native2DCanvasContextCurrent $handle $before}
    return $result
}
proc ::GX::_nativeCanvasExtensionProjection {row reference image} {
    set id [_nativeCanvasExtensionId $row]
    if {$id eq {}} {return {}}
    set contract [dict get [_nativeCanvasExtensionDefinition $id] contract]
    if {![dict exists $contract native_hooks image_projection] && ![dict exists $contract native_hooks image_projection_context]} {return {}}
    # A staging row may contain uncommitted Resources. The generic typed
    # context exposes only those exact Resource references, never the private
    # row/native scene. Legacy three-argument hooks remain compatible.
    set context [native2DCanvasContext [dict get $row canvas_handle]]
    if {[dict exists $contract native_hooks image_projection_context]} {
        set retained [datasetPublicationV2DictDefault $row retained_outputs {}]
        nativeWorkspaceEncode {array {resource {named resource_metadata}}} $retained
        set input [dict create schema gxtxt.native2d.image_projection_context.v1 retained_outputs $retained]
        set prefix [dict get $contract native_hooks image_projection_context]
        set invoke [list {*}$prefix $context $reference $image $input]
    } else {set invoke [list {*}[dict get $contract native_hooks image_projection] $context $reference $image]}
    set result [_datasetPrivateWithModule [dict get $row module] [list uplevel #0 $invoke]]
    _nativeCanvasExtensionDefinition $id
    native2DCanvasContextCurrent [dict get $context handle] $context
    if {$result ne {}} {
        _nativeCanvasFields $result {width height source_rect projection_sha256 path photo resource} {width height source_rect projection_sha256}
        foreach n [list [dict get $result width] [dict get $result height]] {if {![string is entier -strict $n] || $n<1 || $n>16384} {error {Projection dimensions exceed original display limits}}}
        if {[dict get $result width]*[dict get $result height]>16777216 || ![regexp {^[0-9a-f]{64}$} [dict get $result projection_sha256]] || [llength [dict get $result source_rect]]!=4} {error {Invalid original-owner display projection}}
        lassign [dict get $result source_rect] x y width height
        foreach n [list $x $y $width $height] {if {![string is double -strict $n] || [catch {expr {abs($n)<Inf}} finite] || !$finite} {error {Projection rectangle requires finite source coordinates}}}
        if {$x<0 || $y<0 || $width<=0 || $height<=0 || $x+$width>[dict get $image width] || $y+$height>[dict get $image height]} {error {Projection rectangle exceeds the original source image}}
        if {[dict exists $result resource]} {
            if {[dict exists $result path] || [dict exists $result photo]} {error {Resource projection cannot also select another display asset}}
            set asset [dict get $result resource]
            nativeWorkspaceEncode {resource {named resource_metadata}} $asset
            if {[dict get $asset document_id] ne [dict get $context document_id] ||
                ![dict exists $asset owner_generation] || [dict get $asset owner_generation] ne [dict get $context document_receipt generation] ||
                [dict get $asset sha256] ne [dict get $result projection_sha256]} {error {Projection asset belongs to another Document or byte identity}}
            set facts [native2DResourceRasterInfo $asset]
            if {[dict get $facts width]!=[dict get $result width] || [dict get $facts height]!=[dict get $result height]} {error {Projection extent differs from its actual Resource}}
            dict set result path [dict get [interactiveDocumentResourceLocalFileInfo $asset] path]
            dict unset result resource
            _nativeCanvasExtensionDefinition $id
            native2DCanvasContextCurrent [dict get $context handle] $context
        }
        if {![dict exists $result path] && ![dict exists $result photo]} {error {Projection lacks an owned display asset}}
    }
    return $result
}
proc ::GX::_nativeCanvasExtensionImageDimensions {resource} {
    set receipt [interactiveDocumentResourceInfo $resource]
    set document [interactiveDocumentMetadata [dict get $resource document_id]]
    set result {};set found 0;set visited {}
    dict for {id record} $::GX::NativeCanvas::extensions {
        if {![dict exists $record contract native_hooks image_dimensions]} continue
        set record [_nativeCanvasExtensionDefinition $id]
        set claim [list [dict get $record owner module_id] [dict get $record owner api_id] [dict get $record contract native_hooks image_dimensions]]
        if {[dict exists $visited $claim]} continue
        dict set visited $claim 1
        set candidate [_datasetPrivateWithModule [dict get $document module_id] [list uplevel #0 [list {*}[dict get $record contract native_hooks image_dimensions] $resource]]]
        _nativeCanvasExtensionDefinition $id
        if {[interactiveDocumentResourceInfo $resource] ne $receipt || [interactiveDocumentMetadata [dict get $resource document_id]] ne $document} {error {Image Resource or Document changed during dimension validation}}
        if {$candidate eq {}} continue
        if {$found} {error {Image has more than one claimed registered presentation owner}}
        if {[llength $candidate]!=2} {error {Image extension requires exact verified width/height}}
        foreach n $candidate {if {![string is entier -strict $n] || $n<1 || $n>100000000} {error {Invalid verified image metadata dimensions}}}
        if {[lindex $candidate 0]*[lindex $candidate 1]>100000000} {error {Verified image metadata exceeds original Native2D capacity}}
        set result $candidate;set found 1
    }
    return $result
}
proc ::GX::native2DCanvasCommands {} {
    return {new bind_source tool_set selection_set roi_create roi_update roi_delete roi_list roi_select object_create object_update object_delete object_affine object_duplicate object_group object_ungroup copy cut paste layer_create layer_update layer_delete layer_assign layer_select layer_reorder merge flatten filter undo redo fit zoom pan save open cancel dispose inspect publish}
}
proc ::GX::native2DCanvasApiInfo {} {
    return [dict create api_id NATIVE2D_API_v1 api_version 1 host_only 1 canvas_version 1 \
        canvas_format gxtxt.native2d.canvas_scene.v1 commands [native2DCanvasCommands] \
        host_commands {native2DCanvasCreate native2DCanvasMount native2DCanvasCommand native2DCanvasDescribe native2DCanvasCapture native2DCanvasRestore native2DCanvasDispose native2DCanvasExtensionRegister native2DCanvasExtensionDescribe native2DCanvasExtensionAttach native2DCanvasContext native2DCanvasContextCurrent native2DCanvasSourcesCurrent native2DCanvasRetainResources native2DCanvasEditCapture native2DCanvasEditCurrent native2DCanvasCommitSnapshot native2DCanvasSnapshot native2DCanvasImageInfo native2DCanvasViewInfo native2DCanvasSnapshotImage native2DCanvasClipboardPasteSnapshot native2DCanvasOperationBegin native2DCanvasOperationUpdate native2DCanvasOperationCancel native2DCanvasSchedule native2DCanvasStatus native2DCanvasNotify native2DCanvasCaptureAnnotation native2DCanvasCaptureDocumentFrame native2DCanvasCaptureImageFrame native2DCanvasRasterProvenance} \
        extension_contract gxtxt.native2d.extension.v1 extension_transport {canvas_command extension} extension_authority activated_module_public_api \
        authority Native2D.C_CPP persistence INTERACTIVE_DOCUMENT_API_v1 history SCIENTIFIC_RECIPE_API_v1 \
        multiple_instances 1 display_precision rgba8_sRGB raw_pointers 0]
}
proc ::GX::_nativeCanvasFields {value allowed {required {}}} {
    if {[catch {dict size $value}]} {error {Canvas request must be a dictionary}}
    foreach key [dict keys $value] {if {$key ni $allowed} {error "Unknown Canvas field: $key"}}
    foreach key $required {if {![dict exists $value $key]} {error "Missing Canvas field: $key"}}
}
proc ::GX::_nativeCanvasRequire {handle {guard 1}} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} {error {Canvas is unknown or disposed}}
    set row [dict get $::GX::NativeCanvas::instances $handle]
    if {!$guard} {return $row}
    if {[dict get $row session] ne [interactiveDocumentSessionToken]} {error {Canvas belongs to another Session lifetime}}
    set owner [interactiveDocumentMetadata [dict get $row document]]
    set held [dict get $row receipt]
    foreach key {generation revision sha256} {
        if {[dict get $owner $key] ne [dict get $held $key]} {error {Canvas document changed outside this instance; reopen its current state}}
    }
    if {![dict get [[dict get $row native] state scalar] alive]} {error {Canvas native source has closed}}
    if {[dict exists $row presentation_parent]} {
        set parent [dict get $row presentation_parent]
        set actual [native2DCanvasContext $parent]
        if {[dict remove $actual sequence] ne [dict remove [dict get $row presentation_parent_context] sequence]} {error {Read-only presentation parent changed}}
    }
    return $row
}
proc ::GX::_nativeCanvasNumber {value minimum maximum label} {
    return [uiFieldNormalize [dict create type number min $minimum max $maximum] $value]
}
proc ::GX::_nativeCanvasExtent {width height} {
    foreach value [list $width $height] {
        if {![string is double -strict $value] || [catch {expr {abs($value)<Inf && $value==floor($value) && $value>=1 && $value<=16384}} valid] || !$valid} {error {Canvas dimensions must be integers from1 to16384}}
    }
    if {$width*$height>16777216} {error {Canvas exceeds the existing16777216-pixel composition limit}}
    return [list [expr {wide($width)}] [expr {wide($height)}]]
}
proc ::GX::_nativeCanvasLogical {state kind value} {
    if {$value eq {} || [string is entier -strict $value]} {error {Canvas targets must be stable logical identities}}
    if {[dict exists $state _logical_index $kind]} {
        if {[dict exists $state _logical_index $kind $value]} {return [dict get $state _logical_index $kind $value]}
        error "Foreign or stale Canvas identity: $value"
    }
    foreach item [dict get $state $kind] {
        if {[dict get $item logical_id] eq $value} {return [dict get $item id]}
    }
    error "Foreign or stale Canvas identity: $value"
}
proc ::GX::_nativeCanvasLogicalFromId {state kind id} {
    if {!$id} {return {}}
    if {[dict exists $state _native_index $kind]} {
        if {[dict exists $state _native_index $kind $id]} {return [dict get $state _native_index $kind $id]}
        error {Native Canvas reference is outside its scene}
    }
    foreach item [dict get $state $kind] {if {[dict get $item id]==$id} {return [dict get $item logical_id]}}
    error {Native Canvas reference is outside its scene}
}
proc ::GX::_nativeCanvasIndexedState {state} {
    # Per-call serialization indexes over the authoritative native state.
    # These are never persisted or used as a competing identity registry.
    foreach kind {objects layers} {
        dict set state _logical_index $kind {}
        dict set state _native_index $kind {}
        foreach item [dict get $state $kind] {
            dict set state _logical_index $kind [dict get $item logical_id] [dict get $item id]
            dict set state _native_index $kind [dict get $item id] [dict get $item logical_id]
        }
    }
    return $state
}
proc ::GX::_nativeCanvasHistoryValidate {record} {
    native2DCanvasSnapshotValidate [dict get $record base] 0
    return 1
}
proc ::GX::native2DCanvasSnapshotValidate {snapshot {resources 1}} {
    _nativeCanvasFields $snapshot {schema document_id generation canvas_id extent background layers objects groups view_state selection active_layer tool retained_outputs} \
        {schema document_id generation canvas_id extent background layers objects groups view_state selection active_layer tool retained_outputs}
    if {[dict get $snapshot schema] ne {gxtxt.native2d.canvas_scene.v1} || [string bytelength $snapshot]>8388608} {error {Unsupported or oversized Canvas snapshot}}
    lassign [dict get $snapshot extent] width height
    if {[llength [dict get $snapshot extent]]!=2} {error {Canvas extent requires width and height}}
    _nativeCanvasExtent $width $height
    if {[llength [dict get $snapshot background]]!=4} {error {Canvas background requires normalized RGBA}}
    foreach n [dict get $snapshot background] {_nativeCanvasNumber $n 0 1 background}
    set ids {};set layerIds {};set objectIds {}
    if {[llength [dict get $snapshot layers]]+[llength [dict get $snapshot objects]]+[llength [dict get $snapshot groups]]>4000} {error {Canvas snapshot exceeds native identity capacity}}
    foreach layer [dict get $snapshot layers] {
        _nativeCanvasFields $layer {logical_id name attributes properties blend} {logical_id name attributes properties blend}
        set id [dict get $layer logical_id]
        if {$id eq {} || $id in $ids || [string is entier -strict $id]} {error {Duplicate or invalid Canvas layer identity}}
        lappend ids $id;lappend layerIds $id
        _nativeCanvasFields [dict get $layer properties] {visible selectable locked order opacity} {visible selectable locked order opacity}
        foreach key {visible selectable locked} {uiFieldNormalize {type boolean} [dict get $layer properties $key]}
        _nativeCanvasNumber [dict get $layer properties opacity] 0 1 opacity
        if {[dict get $layer blend] ni {Over Multiply Screen Overlay SoftLight}} {error {Unsupported Canvas layer blend}}
    }
    foreach object [dict get $snapshot objects] {
        _nativeCanvasFields $object {logical_id name resource style layer_logical_id source} {logical_id name resource style layer_logical_id}
        set id [dict get $object logical_id]
        if {$id eq {} || $id in $ids || [string is entier -strict $id]} {error {Duplicate or invalid Canvas object identity}}
        lappend ids $id;lappend objectIds $id
        if {[dict get $object layer_logical_id] ni $layerIds} {error {Canvas object refers to a missing layer}}
        if {[dict exists $object style layer]} {error {Canvas snapshot must not persist native layer numbers}}
        if {$resources} {
            set ref [dict get $object resource]
            if {[dict get $ref document_id] ne [dict get $snapshot document_id] || [dict get $ref owner_generation] ne [dict get $snapshot generation]} {error {Canvas leaf resource has a foreign owner}}
            interactiveDocumentResourceInfo $ref
            if {[dict exists $object source]} {_viewerGuiRasterSourceCheck [dict get $object source]}
        }
    }
    foreach group [dict get $snapshot groups] {
        _nativeCanvasFields $group {logical_id name members attributes style layer_logical_id} {logical_id name members attributes style layer_logical_id}
        set id [dict get $group logical_id]
        if {$id eq {} || $id in $ids || [string is entier -strict $id]} {error {Duplicate or invalid Canvas group identity}}
        lappend ids $id
        set members [dict get $group members]
        if {![llength $members] || [llength [lsort -unique $members]]!=[llength $members]} {error {Native Canvas groups require unique nongroup members}}
        foreach member $members {if {$member ni $objectIds} {error {Missing or nested Canvas group member}}}
        if {[dict get $group layer_logical_id] ni $layerIds} {error {Canvas group refers to a missing layer}}
    }
    foreach id [dict get $snapshot selection] {if {$id ni $ids || $id in $layerIds} {error {Canvas selection refers to a missing object}}}
    if {[dict get $snapshot active_layer] ne {} && [dict get $snapshot active_layer] ni $layerIds} {error {Canvas active layer is missing}}
    nativeWorkspaceEncode {named canvas_snapshot} $snapshot
    return $snapshot
}
proc ::GX::_nativeCanvasAdmitSources {row {verifyBytes 0}} {
    set token [dict get $row geometry]
    set scene [dict get $::GX::Native2DGeometry::scenes $token]
    dict for {object entry} [dict get $scene objects] {
        if {[dict exists $entry metadata image_resource]} {
            set image [_native2DRasterImage $scene $object]
            # Explicit source admission also verifies exact held bytes. The
            # existing provisional frame/pointer callers retain their fast
            # physical-reader check; it is not a full content-hash proof.
            if {$verifyBytes} {interactiveDocumentResourceInfo [dict get $image resource]}
        }
    }
}
proc ::GX::_nativeCanvasReconcile {handle} {
    set row [_nativeCanvasRequire $handle]
    set context [dict get $row native];set token [dict get $row geometry]
    set state [$context state];set native [dict get $state scene]
    set live {};foreach id [::GX::Native2D::core ids $native] {dict set live $id 1}
    set registered {};set images {}
    set scene [dict get $::GX::Native2DGeometry::scenes $token]
    dict for {object entry} [dict get $scene objects] {
        if {![dict exists $live [dict get $entry native]]} {
            if {[dict exists $scene raster_resource_readers $object]} {catch {interactiveDocumentResourceCloseReader [dict get $scene raster_resource_readers $object]};dict unset ::GX::Native2DGeometry::scenes $token raster_resource_readers $object}
            dict unset ::GX::Native2DGeometry::scenes $token objects $object
        } else {
            dict set registered [dict get $entry native] 1
            if {[dict exists $entry metadata image_resource] && ![dict exists $images [dict get $entry metadata image_resource sha256]]} {dict set images [dict get $entry metadata image_resource sha256] [dict get $entry metadata]}
        }
    }
    foreach item [dict get $state objects] {
        set id [dict get $item id]
        if {[dict get $item logical_id] eq {}} {$context command object_adopt [dict create object $id]}
        if {[dict exists $registered $id]} continue
        set metadata {}
        set image [::GX::Native2D::core image_get $native $id]
        if {$image ne {}} {
            set reference {}
            if {[dict exists $images [dict get $image resource_id]]} {set metadata [dict get $images [dict get $image resource_id]];set reference [dict get $metadata image_resource]}
            if {$reference eq {} && [dict exists $::GX::Native2DRaster::resources $native $id]} {set reference [dict get $::GX::Native2DRaster::resources $native $id];dict set metadata image_resource $reference}
            if {$reference eq {}} {error {Native Canvas image lacks its managed resource}}
            native2DReferenceImageBind $native $id $reference
        }
        _native2DGeometryAdopt $token $id $metadata
        dict set registered $id 1
    }
    return [$context state]
}
proc ::GX::native2DCanvasCreate {module provider {options {}}} {
    _nativeCanvasFields $options {width height background document_id extension} {}
    set extension [datasetPublicationV2DictDefault $options extension {}]
    if {$extension ne {}} {_nativeCanvasExtensionDefinition $extension}
    set extent [_nativeCanvasExtent [datasetPublicationV2DictDefault $options width 1024] [datasetPublicationV2DictDefault $options height 768]]
    set background [datasetPublicationV2DictDefault $options background {1 1 1 1}]
    if {[llength $background]!=4} {error {Canvas background requires RGBA}}
    foreach value $background {_nativeCanvasNumber $value 0 1 background}
    set created [expr {![dict exists $options document_id]}]
    if {$created} {
        set owner [interactiveDocumentCreate $module $provider gxtxt.native2d.canvas_scene.v1 1 {}]
    } else {
        set owner [interactiveDocumentRead [dict get $options document_id]]
        if {[dict get $owner format] ne {gxtxt.native2d.canvas_scene.v1} || [dict get $owner module_id] ne $module || [dict get $owner provider_id] ne $provider} {error {Canvas document format or author context differs}}
    }
    set geometry {};set context {};set handle {}
    try {
        set geometry [native2DGeometryOpen [dict get $owner id]]
        set scene [dict get $::GX::Native2DGeometry::scenes $geometry native]
        set context [::GX::Native2D::core canvas_create $scene]
        set handle "native2d-canvas#[pid]-[incr ::GX::NativeCanvas::serial]"
        dict set ::GX::NativeCanvas::instances $handle [dict create canvas_handle $handle owner_generation [incr ::GX::NativeCanvas::serial] extension_id $extension native $context geometry $geometry document [dict get $owner id] receipt [dict remove $owner payload] session [interactiveDocumentSessionToken] module $module provider $provider canvas {} scheduler {} subscription {} photos {} resources {} history {} snapshot {} pending {} sequence 0 accepting 0]
        if {$created} {
            $context command configure [dict create extent $extent background $background]
            $context command layer_create {name Background properties {visible 1 selectable 1 locked 0 order 0 opacity 1} blend Over}
            lassign $extent width height
            ::GX::Native2D::core fit_bounds $scene [list 0 0 $width $height]
            set snapshot [native2DCanvasCapture $handle]
            set history [scientificHistoryCreate framework.native2d.canvas $snapshot]
            _nativeCanvasStore $handle $snapshot $history
        } else {
            set payload [dict get $owner payload]
            _nativeCanvasFields $payload {schema snapshot history} {schema snapshot history}
            if {[dict get $payload schema] ne {gxtxt.native2d.canvas_document.v1}} {error {Unsupported Canvas document payload}}
            native2DCanvasRestore $handle [dict get $payload snapshot]
            scientificHistoryValidate framework.native2d.canvas [dict get $payload history]
            dict set ::GX::NativeCanvas::instances $handle history [dict get $payload history]
            dict set ::GX::NativeCanvas::instances $handle snapshot [dict get $payload snapshot]
        }
        return $handle
    } on error {message errorOptions} {
        if {$handle ne {}} {catch {native2DCanvasDispose $handle}} else {
            if {$context ne {}} {catch {$context dispose}}
            if {$geometry ne {}} {catch {native2DGeometryClose $geometry}}
        }
        if {$created} {catch {interactiveDocumentDelete [dict get $owner id]}}
        return -options $errorOptions $message
    }
}
proc ::GX::_nativeCanvasBinaryIdentity {bytes} {
    if {![llength [info commands ::GX::NativeDocument::snapshotCache]] && [llength [info commands ::GX::_interactiveDocumentCacheEnsure]]} {_interactiveDocumentCacheEnsure}
    if {[llength [info commands ::GX::NativeDocument::snapshotCache]] &&
        ![catch {::GX::NativeDocument::snapshotCache digest $bytes} sha] && [regexp {^[a-f0-9]{64}$} $sha]} {return $sha}
    return [datasetStorageSha256Bytes [_interactiveDocumentRequireSession] $bytes]
}
proc ::GX::_nativeCanvasResourceSignature {scene object attributes} {
    set definition [::GX::Native2D::core sketch_definition $scene $object]
    set image [::GX::Native2D::core image_get $scene $object]
    set signature [list $definition $image $attributes [::GX::Native2D::core direction_marker $scene $object]]
    # Retained definitions/images keep their original four-field identity.
    # Raw geometry instead owns every admitted vertex and native cut; display
    # LOD, counts alone and a new provenance timestamp cannot identify it.
    if {$definition eq {} && $image eq {}} {
        set kind [::GX::Native2D::core kind $scene $object]
        set count [::GX::Native2D::core count $scene $object]
        set pages {}
        for {set start 0} {$start<$count} {incr start 65536} {
            set n [expr {min(65536,$count-$start)}]
            set bytes [::GX::Native2D::core points_binary $scene $object $start $n]
            if {[string length $bytes]!=16*$n} {error {Native raw point export changed its exact row count}}
            lappend pages [_nativeCanvasBinaryIdentity $bytes]
        }
        set cuts {}
        if {$kind eq {curve}} {set cuts [::GX::Native2D::core breaks $scene $object]}
        lappend signature [list raw $kind $count $pages $cuts]
    }
    return $signature
}
proc ::GX::native2DCanvasCapture {handle} {
    set held [_nativeCanvasRequire $handle 0]
    if {[dict exists $held gesture_before]} {
        _nativeCanvasRequire $handle
        if {[dict get [[dict get $held native] state scalar] gesture]} {return [dict get $held gesture_before]}
    }
    set state [_nativeCanvasIndexedState [_nativeCanvasReconcile $handle]];set row [_nativeCanvasRequire $handle]
    lassign [_nativeCanvasCaptureState $row $state] snapshot cache
    dict set ::GX::NativeCanvas::instances $handle resources $cache
    return $snapshot
}
# The SAME capture implementation serves the live owner and its existing
# private transaction scene. Request spelling is not accepted native state.
proc ::GX::_nativeCanvasCaptureState {row state} {
    set scene [dict get $state scene];set document [dict get $row document]
    set layers {};set objects {};set groups {};set cache [dict get $row resources];set captureOrigin {}
    set sources {}
    dict for {token entry} [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects] {
        if {[dict exists $entry metadata raster_dataset]} {dict set sources [dict get $entry native] [dict get $entry metadata raster_dataset]}
    }
    foreach layer [dict get $state layers] {
        lappend layers [dict create logical_id [dict get $layer logical_id] name [dict get $layer name] attributes [dict get $layer attributes] properties [dict remove [dict get $layer properties] id] blend [dict get $layer blend]]
    }
    foreach object [dict get $state objects] {
        set id [dict get $object id];set logical [dict get $object logical_id]
        set style [dict remove [dict get $object style] layer selected]
        set layer [_nativeCanvasLogicalFromId $state layers [dict get $object layer]]
        set name [::GX::Native2D::core identity_name $scene $id]
        if {[dict get $object kind] eq {group}} {
            set members [lmap native [dict get $object members] {_nativeCanvasLogicalFromId $state objects $native}]
            lappend groups [dict create logical_id $logical name $name members $members attributes [dict get $object attributes] style $style layer_logical_id $layer]
            continue
        }
        set signature [_nativeCanvasResourceSignature $scene $id [dict get $object attributes]]
        if {[dict exists $cache $logical] && [dict get $cache $logical signature] eq $signature} {
            set resource [dict get $cache $logical reference]
        } else {
            if {$captureOrigin eq {}} {set captureOrigin [_scientificResourceOrigin $document managed_resource]}
            set resource [interactiveDocumentNative2DStore $document $scene $id [dict create origin $captureOrigin]]
            dict set cache $logical [dict create signature $signature reference $resource]
        }
        set item [dict create logical_id $logical name $name resource $resource style $style layer_logical_id $layer]
        if {[dict exists $sources $id]} {dict set item source [dict get $sources $id]}
        lappend objects $item
    }
    set selected [lmap id [dict get $state selected_objects] {_nativeCanvasLogicalFromId $state objects $id}]
    set snapshot [dict create schema gxtxt.native2d.canvas_scene.v1 document_id $document generation [dict get $row receipt generation] \
        canvas_id [dict get $state canvas_id] extent [_nativeCanvasExtent {*}[dict get $state extent]] background [dict get $state background] \
        layers $layers objects $objects groups $groups view_state [::GX::Native2D::core view_state $scene] selection $selected \
        active_layer [_nativeCanvasLogicalFromId $state layers [dict get $state active_layer]] tool [dict get $state tool] retained_outputs [datasetPublicationV2DictDefault $row retained_outputs {}]]
    native2DCanvasSnapshotValidate $snapshot 0
    return [list $snapshot $cache]
}
proc ::GX::_nativeCanvasStore {handle snapshot history} {
    set row [_nativeCanvasRequire $handle]
    set payload [dict create schema gxtxt.native2d.canvas_document.v1 snapshot $snapshot history $history]
    set receipt [native2DGeometryCheckpoint [dict get $row geometry] $payload]
    dict set ::GX::NativeCanvas::instances $handle receipt $receipt
    dict set ::GX::NativeCanvas::instances $handle snapshot $snapshot
    dict set ::GX::NativeCanvas::instances $handle retained_outputs [dict get $snapshot retained_outputs]
    dict set ::GX::NativeCanvas::instances $handle history $history
    return $receipt
}
proc ::GX::_nativeCanvasAccepted {handle description} {
    set row [_nativeCanvasRequire $handle]
    set snapshot [native2DCanvasCapture $handle];set history [dict get $row history]
    # Branch only the local value. A refused append/checkpoint must leave the
    # accepted timeline (including redo) untouched.
    set history [scientificHistoryBranch framework.native2d.canvas $history [dict get $history cursor]]
    set history [scientificHistoryAppend framework.native2d.canvas $history $snapshot $description]
    _nativeCanvasStore $handle $snapshot $history
    _nativeCanvasNotify $handle committed
    return [native2DCanvasDescribe $handle]
}
proc ::GX::_nativeCanvasEditCapture {handle} {
    if {[datasetPublicationV2DictDefault [_nativeCanvasRequire $handle] read_only 0]} {error {Read-only presentation cannot stage a scientific Canvas edit}}
    _nativeCanvasWorkspacePrepareEdit $handle
    set row [_nativeCanvasRequire $handle]
    if {[dict get [[dict get $row native] state scalar] gesture] || [dict exists $row roi_gesture]} {error {Finish or cancel the provisional Canvas gesture before staging an edit}}
    _nativeCanvasAdmitSources $row
    return [dict create native [dict get $row native] document [dict get $row document] receipt [dict get $row receipt] session [dict get $row session] history [dict get $row history] snapshot [native2DCanvasCapture $handle]]
}
proc ::GX::_nativeCanvasEditCurrent {handle held} {
    if {[datasetPublicationV2DictDefault [_nativeCanvasRequire $handle] read_only 0]} {error {Read-only presentation cannot adopt a scientific Canvas edit}}
    _nativeCanvasWorkspacePrepareEdit $handle
    set row [_nativeCanvasRequire $handle]
    foreach key {native document receipt session history} {
        if {[dict get $row $key] ne [dict get $held $key]} {error {Canvas changed while the edit was staged; no result adopted}}
    }
    if {[dict exists $held sequence]} {
        set sequence [dict get $held sequence]
        if {![string is entier -strict $sequence] || $sequence<0} {error {Canvas originating sequence must be a nonnegative integer}}
        if {$sequence!=[dict get $row sequence]} {error {Canvas operation was canceled or replaced while the edit was staged; no result adopted}}
    }
    if {[dict get [[dict get $row native] state scalar] gesture] || [dict exists $row roi_gesture]} {error {Canvas gesture is active; no staged edit adopted}}
    _nativeCanvasAdmitSources $row
    # Navigation/tool choice is presentation, not an image edit. Selection,
    # active layer and every serialized scientific/Resource field stay exact.
    if {[dict remove [native2DCanvasCapture $handle] view_state tool] ne [dict remove [dict get $held snapshot] view_state tool]} {error {Canvas selection or content changed while the edit was staged; no result adopted}}
    return $row
}
proc ::GX::_nativeCanvasCommitSnapshot {handle held snapshot description {options {}}} {
    _nativeCanvasFields $options {fit_bounds}
    _nativeCanvasEditCurrent $handle $held
    set current [native2DCanvasCapture $handle]
    foreach key {view_state tool} {dict set snapshot $key [dict get $current $key]}
    native2DCanvasSnapshotValidate $snapshot
    if {$snapshot eq $current && ![dict exists $options fit_bounds]} {return [dict merge [native2DCanvasDescribe $handle] {status unchanged}]}
    # Build the original History record from the complete state actually
    # accepted by the native staging scene, not the request's scalar spelling.
    return [_nativeCanvasRestoreSnapshot $handle $snapshot [dict merge [dict create held $held description $description event committed] $options]]
}
proc ::GX::native2DCanvasRestore {handle snapshot} {
    return [_nativeCanvasRestoreSnapshot $handle $snapshot]
}
proc ::GX::_nativeCanvasRestoreSnapshot {handle snapshot {edit {}}} {
    set row [_nativeCanvasRequire $handle]
    if {[datasetPublicationV2DictDefault $row read_only 0]} {error {Read-only presentation cannot replace its original staged snapshot}}
    if {[dict get $snapshot document_id] ne [dict get $row document] || [dict get $snapshot generation] ne [dict get $row receipt generation]} {error {Canvas snapshot belongs to another Document generation}}
    if {$edit ne {}} {
        _nativeCanvasEditCurrent $handle [dict get $edit held]
        set current [native2DCanvasCapture $handle]
        foreach key {view_state tool} {dict set snapshot $key [dict get $current $key]}
    }
    native2DCanvasSnapshotValidate $snapshot
    set geometry {};set context {};set swapped 0
    try {
        set geometry [native2DGeometryOpen [dict get $row document]]
        set scene [dict get $::GX::Native2DGeometry::scenes $geometry native]
        set context [::GX::Native2D::core canvas_create $scene]
        $context command configure [dict create extent [dict get $snapshot extent] background [dict get $snapshot background] canvas_id [dict get $snapshot canvas_id]]
        set layerIds {};set objectIds {};set cache {}
        foreach layer [dict get $snapshot layers] {
            set properties [dict replace [dict get $layer properties] locked 0]
            set result [$context command layer_create [dict create name [dict get $layer name] properties $properties blend [dict get $layer blend] logical_id [dict get $layer logical_id]]]
            set state [$context state]
            set id [_nativeCanvasLogical $state layers [dict get $layer logical_id]]
            dict set layerIds [dict get $layer logical_id] $id
            dict for {key value} [dict get $layer attributes] {::GX::Native2D::core identity_attribute $scene $id $key $value}
        }
        foreach object [dict get $snapshot objects] {
            set logical [dict get $object logical_id]
            set reference [dict get $object resource]
            set restored [native2DGeometryCall $geometry restore_resource [dict create resource $reference]]
            set token [dict get $restored object_token]
            set id [dict get $::GX::Native2DGeometry::scenes $geometry objects $token native]
            set style [dict get $object style];dict set style layer [dict get $layerIds [dict get $object layer_logical_id]]
            dict set style locked 0
            ::GX::Native2D::core object_style $scene $id $style
            if {[dict get $object name] ne {}} {::GX::Native2D::core identity_name $scene $id [dict get $object name]}
            $context command object_adopt [dict create object $id logical_id $logical layer [dict get $style layer]]
            if {[dict exists $reference metadata image_resource]} {
                dict set ::GX::Native2DGeometry::scenes $geometry objects $token metadata image_resource [dict get $reference metadata image_resource]
                if {[dict exists $object source]} {dict set ::GX::Native2DGeometry::scenes $geometry objects $token metadata raster_dataset [dict get $object source]}
            }
            dict set objectIds $logical $id
        }
        foreach group [dict get $snapshot groups] {
            set members [lmap logical [dict get $group members] {dict get $objectIds $logical}]
            $context command object_group [dict create objects $members layer [dict get $layerIds [dict get $group layer_logical_id]]]
            set newest 0
            foreach candidate [dict get [$context state] groups] {if {[dict get $candidate id]>$newest} {set newest [dict get $candidate id]}}
            if {!$newest} {error {Native Canvas group restoration produced no group}}
            dict for {key value} [dict get $group attributes] {::GX::Native2D::core identity_attribute $scene $newest $key $value}
            if {[dict get $group name] ne {}} {::GX::Native2D::core identity_name $scene $newest [dict get $group name]}
            ::GX::Native2D::core object_style $scene $newest [dict get $group style]
            dict set objectIds [dict get $group logical_id] $newest
        }
        # Rebuild membership before restoring locks. These objects are still
        # private; public edit guards remain in force for accepted scenes.
        foreach object [dict get $snapshot objects] {
            if {![dict get $object style locked]} continue
            set style [dict get $object style];dict set style layer [dict get $layerIds [dict get $object layer_logical_id]]
            ::GX::Native2D::core object_style $scene [dict get $objectIds [dict get $object logical_id]] $style
        }
        foreach layer [dict get $snapshot layers] {
            if {![dict get $layer properties locked]} continue
            $context command layer_update [dict create layer [dict get $layerIds [dict get $layer logical_id]] properties [dict get $layer properties]]
        }
        # Locks can update retained image state. Seed immutable Resource
        # receipts only after final object/layer restoration, so the first
        # capture cannot mistake that restoration for a new scientific edit.
        foreach object [dict get $snapshot objects] {
            set logical [dict get $object logical_id]
            set id [dict get $objectIds $logical]
            set signature [_nativeCanvasResourceSignature $scene $id [::GX::Native2D::core identity_attributes $scene $id]]
            dict set cache $logical [dict create signature $signature reference [dict get $object resource]]
        }
        ::GX::Native2D::core view_state $scene [dict get $snapshot view_state]
        if {[dict get $snapshot active_layer] ne {}} {$context command layer_select [dict create layer [dict get $layerIds [dict get $snapshot active_layer]] ]}
        $context command selection_set [dict create objects [lmap id [dict get $snapshot selection] {dict get $objectIds $id}] mode replace]
        $context command tool_set [dict create tool [dict get $snapshot tool]]
        set canvas [dict get $row canvas]
        if {$canvas ne {} && [winfo exists $canvas] && [winfo width $canvas]>1 && [winfo height $canvas]>1} {
            $context event resize [dict create width [winfo width $canvas] height [winfo height $canvas]]
        }
        if {[dict exists $edit fit_bounds]} {
            # An optional camera fit is data, applied by the original native
            # kernel ONLY on this existing private transaction staging scene.
            # Preserve the complete resulting view in the same Document/History
            # write; the mounted predecessor is untouched on any refusal.
            ::GX::Native2D::core fit_bounds $scene [dict get $edit fit_bounds]
            dict set snapshot view_state [::GX::Native2D::core view_state $scene]
        }
        set provisional [dict replace $row native $context owner_generation [incr ::GX::NativeCanvas::serial] geometry $geometry resources $cache photos [dict get $row photos] snapshot $snapshot retained_outputs [dict get $snapshot retained_outputs]]
        set provisional [dict remove $provisional gesture_before gesture_history]
        # Staging can pump events. Never resurrect contributed ephemeral state
        # after cancellation; the owning module declares its transient fields.
        set provisional [_nativeCanvasExtensionTransient $provisional]
        catch {dict unset provisional glyph_cache}
        if {[dict exists $edit description]} {
            lassign [_nativeCanvasCaptureState $provisional [_nativeCanvasIndexedState [$context state]]] snapshot cache
            dict set provisional snapshot $snapshot
            dict set provisional resources $cache
            dict set provisional retained_outputs [dict get $snapshot retained_outputs]
        }
        _nativeCanvasAdmitSources $provisional
        # Assets and native presentation are admitted on a private staging
        # surface before replacing a mounted valid scene.
        if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
            set provisional [_nativeCanvasStagePresentation $handle $provisional]
        }
        if {$edit ne {}} {
            # All allocations, Resource admission and native presentation were
            # staged before this held receipt check. No event-loop yield or
            # owner callback is introduced before the original Document write.
            _nativeCanvasEditCurrent $handle [dict get $edit held]
            if {[dict exists $edit description]} {
                set history [dict get $edit held history]
                set history [scientificHistoryBranch framework.native2d.canvas $history [dict get $history cursor]]
                set history [scientificHistoryAppend framework.native2d.canvas $history $snapshot [dict get $edit description]]
            } else {set history [dict get $edit history]}
            set payload [dict create schema gxtxt.native2d.canvas_document.v1 snapshot $snapshot history $history]
            set receipt [native2DGeometryCheckpoint [dict get $row geometry] $payload]
            dict set ::GX::Native2DGeometry::scenes $geometry revision [dict get $receipt revision]
            dict set provisional receipt $receipt
            dict set provisional history $history
            dict set ::GX::NativeCanvas::instances $handle $provisional
            set swapped 1
            _nativeCanvasCancelPending $handle
        } else {
            _nativeCanvasCancelPending $handle
            set canceled [_nativeCanvasRequire $handle 0]
            foreach key {sequence pending raster_status} {if {[dict exists $canceled $key]} {dict set provisional $key [dict get $canceled $key]}}
            dict set ::GX::NativeCanvas::instances $handle $provisional
            set swapped 1
        }
        if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
            native2DSpriteSceneDetach [dict get $row canvas]
            native2DSpriteSceneAttach [dict get $row canvas] $scene
            $context command configure [dict create presenter [native2DSpriteSceneCreate [dict get $row canvas]]]
            native2DViewportHostScene [dict get $row canvas] $scene
            guiUpdateSchedulerRequest [dict get $row scheduler]
            guiUpdateSchedulerFinish [dict get $row scheduler]
        }
        catch {[dict get $row native] dispose}
        catch {native2DGeometryClose [dict get $row geometry]}
        set kept [dict values [dict get $::GX::NativeCanvas::instances $handle photos]]
        dict for {key photo} [dict get $row photos] {if {$photo ni $kept} {catch {image delete $photo}}}
        if {$edit ne {}} {
            _nativeCanvasNotify $handle [dict get $edit event]
            return [native2DCanvasDescribe $handle]
        }
        _nativeCanvasNotify $handle restored
        return [dict create status restored document_id [dict get $row document] canvas_id [dict get $snapshot canvas_id]]
    } on error {message errorOptions} {
        if {!$swapped} {
            if {[info exists provisional]} {
                dict for {key photo} [dict get $provisional photos] {
                    if {![dict exists $row photos $key] || [dict get $row photos $key] ne $photo} {catch {image delete $photo}}
                }
            }
            if {$context ne {}} {catch {$context dispose}}
            if {$geometry ne {}} {catch {native2DGeometryClose $geometry}}
        } elseif {$edit ne {}} {
            # The Document and its History already committed together. A late
            # presentation/notification error cannot truthfully undo that
            # receipt or overwrite a later Document winner.
            if {[dict exists $::GX::NativeCanvas::instances $handle]} {
                dict set ::GX::NativeCanvas::instances $handle presentation_error $message
                catch {_nativeCanvasNotify $handle [dict get $edit event]}
            }
            catch {[dict get $row native] dispose}
            catch {native2DGeometryClose [dict get $row geometry]}
            return [dict create status committed document_id [dict get $row document] receipt $receipt presentation_error $message]
        }
        return -options $errorOptions $message
    }
}
proc ::GX::_nativeCanvasWorkspacePrepareEdit {handle} {
    set row [_nativeCanvasRequire $handle];set canvas [dict get $row canvas]
    if {$canvas ne {} && [winfo exists $canvas]} {
        set window [winfo toplevel $canvas]
        if {[dict exists $::GX::ScientificHistory::viewers $window]} {
            set adapter [_scientificHistoryGuard $window]
            if {![scientificHistoryViewerEditable $window]} {error {Workspace History browsing or restoration is read-only}}
            set record [dict get $adapter record]
            if {[dict get $record cursor]!=[llength [dict get $record steps]]} {error {Return to latest Workspace History or explicitly restart here before editing the Canvas}}
        }
    }
    return 1
}
proc ::GX::_nativeCanvasPrepareEdit {handle} {
    # Canvas History branches only when the validated edit is accepted. This
    # guard also serves selection/view actions: they never truncate the outer
    # Workspace archive merely because the user inspected an older state.
    return [_nativeCanvasWorkspacePrepareEdit $handle]
}
proc ::GX::_nativeCanvasCancelPending {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    set handled {}
    if {[catch {_nativeCanvasExtensionCall $handle cancel_pending} handled]} {
        puts stderr "Canvas extension cancellation could not be confirmed: $handled"
        set handled {}
    }
    if {$handled ne {} && $handled} {return}
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set current [dict get $::GX::NativeCanvas::instances $handle]
    foreach key {native document receipt session sequence pending} {if {[dict get $current $key] ne [dict get $row $key]} {return}}
    dict set ::GX::NativeCanvas::instances $handle sequence [expr {[dict get $row sequence]+1}]
    if {[dict get $row pending] ne {}} {
        foreach {kind id} [dict get $row pending] {
            switch $kind {
                preparation {catch {scientificExecutionDiscard $id}}
                job {if {[catch {scientificExecutionCancel $id}]} {catch {scriptJobCancel $id}}}
                waiter {catch {scriptJobRequestCancel $id canceled}}
            }
        }
        if {[dict exists $row raster_status]} {dict set ::GX::NativeCanvas::instances $handle raster_status [dict replace [dict get $row raster_status] status canceled]}
    }
    if {[dict exists $row raster_import]} {catch {_scientificExecutionImageImportCancel [dict get $row raster_import]};catch {dict unset ::GX::NativeCanvas::instances $handle raster_import}}
    dict set ::GX::NativeCanvas::instances $handle pending {}
}
proc ::GX::native2DCanvasDispose {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} {return 0}
    set row [_nativeCanvasRequire $handle 0]
    if {[dict exists $row companion_view]} {catch {native2DCanvasReadOnlyViewDispose $handle [dict get $row companion_view]}}
    _nativeCanvasCancelPending $handle
    if {[catch {_nativeCanvasExtensionCall $handle dispose} message]} {puts stderr "Canvas extension disposal could not be confirmed: $message"}
    # Release registry ownership before Destroy callbacks can reenter cleanup.
    dict unset ::GX::NativeCanvas::instances $handle
    if {[dict get $row scheduler] ne {}} {catch {guiUpdateSchedulerDispose [dict get $row scheduler]}}
    if {[dict get $row subscription] ne {}} {catch {interactiveDocumentLifecycleUnsubscribe [dict get $row subscription]}}
    catch {[dict get $row native] command cancel {}}
    set canvas [dict get $row canvas]
    if {$canvas ne {} && [winfo exists $canvas]} {
        catch {native2DSpriteSceneDispose $canvas}
        catch {native2DViewportDispose $canvas $canvas}
        if {[dict exists $row frame] && [winfo exists [dict get $row frame]]} {destroy [dict get $row frame]}
    }
    catch {[dict get $row native] dispose}
    catch {native2DGeometryClose [dict get $row geometry]}
    dict for {key photo} [dict get $row photos] {catch {image delete $photo}}
    foreach key [array names ::GX::NativeCanvas::ui "$handle,*"] {unset ::GX::NativeCanvas::ui($key)}
    return 1
}
proc ::GX::_nativeCanvasRequest {operation request} {
    set contracts [dict create \
        new {width height background} bind_source {source_selector dataset_id layer} tool_set {tool} selection_set {objects mode} \
        object_create {definition style layer kind text fill} object_update {object definition style text fill} object_delete {objects} \
        object_affine {objects matrix} object_duplicate {objects layer matrix} object_group {objects layer} object_ungroup {object} \
        copy {objects} cut {objects} paste {layer} layer_create {name properties blend} layer_update {layer properties name blend} \
        layer_delete {layer delete_objects} layer_assign {layer objects} layer_select {layer} layer_reorder {layer order} \
        merge {layers target} flatten {layers precision} filter {object name parameters} undo {} redo {} fit {} zoom {factor center} \
        pan {dx dy} save {} open {document_id} cancel {} dispose {} inspect {} publish {dataset_id name format precision}]
    dict for {name schema} [_nativeCanvasRoiSchemas] {dict set contracts $name [concat {*}$schema]}
    if {![dict exists $contracts $operation]} {error {Unknown finite Canvas operation}}
    _nativeCanvasFields $request [concat [dict get $contracts $operation] expected_revision]
    if {[string bytelength $request]>49152} {error {Canvas request exceeds48KiB}}
    set required [dict create new {width height} tool_set tool selection_set objects object_create definition object_update object \
        object_affine {objects matrix} object_duplicate objects object_group objects object_ungroup object layer_update layer \
        layer_delete layer layer_assign {layer objects} layer_select layer layer_reorder {layer order} merge layers filter name \
        zoom factor pan {dx dy} open document_id publish dataset_id]
    dict for {name schema} [_nativeCanvasRoiSchemas] {dict set required $name [lindex $schema 0]}
    foreach key [datasetPublicationV2DictDefault $required $operation {}] {if {![dict exists $request $key]} {error "Missing Canvas field: $key"}}
    if {$operation eq {bind_source} && ([dict exists $request dataset_id]+[dict exists $request source_selector])!=1} {error {Choose exactly one canonical source identity or declared selector}}
}
proc ::GX::native2DCanvasCommand {handle operation {request {}}} {
    _nativeCanvasRequest $operation $request
    set row [_nativeCanvasRequire $handle]
    if {[datasetPublicationV2DictDefault $row read_only 0] && $operation ni {inspect roi_list fit zoom pan dispose}} {error {Read-only presentation permits only camera navigation}}
    if {[dict exists $request expected_revision]} {
        if {![string is entier -strict [dict get $request expected_revision]] || [dict get $request expected_revision]!=[dict get $row receipt revision]} {error {Stale Canvas revision}}
        if {![dict exists [_nativeCanvasRoiSchemas] $operation]} {dict unset request expected_revision}
    }
    if {$operation eq {dispose}} {return [native2DCanvasDispose $handle]}
    if {$operation in {cancel save tool_set fit zoom pan undo redo open new}} {
        _nativeCanvasCancelGesture $handle
        set row [_nativeCanvasRequire $handle]
    } elseif {$operation ni {inspect roi_list} && ([dict get [[dict get $row native] state scalar] gesture] || [dict exists $row roi_gesture])} {
        error {Finish or cancel the provisional Canvas gesture before editing}
    }
    if {$operation ni {new open cancel inspect tool_set selection_set layer_select fit zoom pan}} {_nativeCanvasAdmitSources $row}
    if {$operation in {tool_set selection_set layer_select fit zoom pan undo redo open new} && ![datasetPublicationV2DictDefault $row read_only 0]} {
        if {![_nativeCanvasWorkspacePrepareEdit $handle]} {return {status canceled}}
        set row [_nativeCanvasRequire $handle]
    }
    set context [dict get $row native]
    if {$operation in {inspect cancel save tool_set fit zoom pan undo redo open new copy filter flatten publish}} {
        set state [$context state scalar]
    } else {set state [_nativeCanvasIndexedState [$context state]]}
    set scene [dict get $state scene]
    switch -- $operation {
        inspect {return [native2DCanvasDescribe $handle]}
        roi_list {return [_nativeCanvasRoiCommand $handle $operation $request]}
        cancel {_nativeCanvasCancelPending $handle;$context command cancel {};_nativeCanvasNotify $handle canceled;return {status canceled}}
        save {
            $context command cancel {}
            return [_nativeCanvasStore $handle [native2DCanvasCapture $handle] [dict get $row history]]
        }
        tool_set {
            if {[dict get $request tool] in [_nativeCanvasRoiTools]} {return [_nativeCanvasRoiToolSet $handle [dict get $request tool]]}
            catch {dict unset ::GX::NativeCanvas::instances $handle roi_tool}
            $context command tool_set $request;_nativeCanvasNotify $handle tool_changed;return [native2DCanvasDescribe $handle]
        }
        layer_select {
            dict set request layer [_nativeCanvasLogical $state layers [dict get $request layer]]
            $context command layer_select $request;_nativeCanvasNotify $handle layer_selected;return [native2DCanvasDescribe $handle]
        }
        selection_set {
            dict set request objects [lmap id [dict get $request objects] {_nativeCanvasLogical $state objects $id}]
            $context command selection_set $request;_nativeCanvasNotify $handle selected;return [native2DCanvasDescribe $handle]
        }
        fit - zoom - pan {
            $context command cancel {}
            switch $operation {
                fit {lassign [dict get $state extent] width height;::GX::Native2D::core fit_bounds $scene [list 0 0 $width $height]}
                zoom {
                    set factor [_nativeCanvasNumber [dict get $request factor] 0.01 100 factor]
                    set point [datasetPublicationV2DictDefault $request center {0 0}]
                    ::GX::Native2D::core zoom $scene $factor $point
                }
                pan {::GX::Native2D::core pan $scene [_nativeCanvasNumber [dict get $request dx] -1e9 1e9 dx] [_nativeCanvasNumber [dict get $request dy] -1e9 1e9 dy]}
            }
            _nativeCanvasNotify $handle view_changed;return [native2DCanvasDescribe $handle]
        }
        undo - redo {
            $context command cancel {};_nativeCanvasCancelPending $handle
            set history [dict get $row history]
            set index [expr {[dict get $history cursor]+($operation eq {undo}?-1:1)}]
            set history [scientificHistoryNavigate framework.native2d.canvas $history $index]
            set snapshot [scientificHistoryState $history]
            set held [_nativeCanvasEditCapture $handle]
            return [_nativeCanvasRestoreSnapshot $handle $snapshot [dict create held $held history $history event history_navigated]]
        }
        copy {return [_nativeCanvasClipboardCopy $handle $request]}
        open {return [_nativeCanvasOpen $handle [dict get $request document_id]]}
        new {return [_nativeCanvasNew $handle $request]}
        filter - flatten - publish {return [_nativeCanvasRasterCommand $handle $operation $request]}
    }
    if {[dict get $row pending] ne {}} {error {Cancel the pending Canvas operation before editing}}
    if {![_nativeCanvasPrepareEdit $handle]} {return {status canceled}}
    set before [native2DCanvasCapture $handle]
    set committed 0
    try {
        switch -- $operation {
            bind_source {
                if {[dict exists $request source_selector] || ![dict exists $request dataset_id]} {error {Resolve a declared Dataset selector through the Viewer Canvas host}}
                _nativeCanvasAdmitSources $row
                set result [native2DGeometryRasterDatasetBind [dict get $row geometry] [dict get $request dataset_id]]
                set object [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects [dict get $result object_token] native]
                set adopt [dict create object $object kind image layer [dict get $state active_layer]]
                if {[dict exists $request layer]} {dict set adopt layer [_nativeCanvasLogical $state layers [dict get $request layer]]}
                $context command object_adopt $adopt
            }
            roi_create - roi_update - roi_delete - roi_select {_nativeCanvasRoiCommand $handle $operation $request}
            cut {_nativeCanvasClipboardCopy $handle $request;set ids [datasetPublicationV2DictDefault $request objects [dict get [native2DCanvasDescribe $handle] selection]];$context command object_delete [dict create objects [lmap id $ids {_nativeCanvasLogical $state objects $id}]]}
            paste {_nativeCanvasClipboardPaste $handle $request}
            layer_reorder {$context command layer_update [dict create layer [_nativeCanvasLogical $state layers [dict get $request layer]] properties [dict create order [dict get $request order]]]}
            merge {_nativeCanvasMerge $handle $request}
            default {
                if {$operation eq {object_delete} && ![dict exists $request objects]} {dict set request objects [dict get [native2DCanvasDescribe $handle] selection]}
                foreach key {object layer} kind {objects layers} {if {[dict exists $request $key]} {dict set request $key [_nativeCanvasLogical $state $kind [dict get $request $key]]}}
                if {[dict exists $request objects]} {dict set request objects [lmap id [dict get $request objects] {_nativeCanvasLogical $state objects $id}]}
                set receipt [$context command $operation $request]
                if {$operation eq {object_duplicate}} {
                    # Native affine already returns the exact source/copy map.
                    # Equal image bytes do not imply the same Dataset lineage.
                    set metadataById {}
                    dict for {token entry} [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects] {dict set metadataById [dict get $entry native] [dict get $entry metadata]}
                    if {[llength [dict get $receipt source_ids]]!=[llength [dict get $receipt object_ids]]} {error {Native duplicate returned an incomplete source map}}
                    foreach original [dict get $receipt source_ids] copy [dict get $receipt object_ids] {
                        set metadata [dict get $metadataById $original]
                        if {[dict exists $metadata image_resource]} {native2DReferenceImageBind $scene $copy [dict get $metadata image_resource]}
                        _native2DGeometryAdopt [dict get $row geometry] $copy $metadata
                    }
                }
            }
        }
        set result [_nativeCanvasAccepted $handle [string map {_ { }} $operation]]
        set committed 1
        return $result
    } on error {message errorOptions} {
        if {!$committed && ![catch {_nativeCanvasRequire $handle}]} {
            if {[$context state] ne [dict remove $state _native_index _logical_index] && [catch {native2DCanvasRestore $handle $before} recovery]} {dict set ::GX::NativeCanvas::instances $handle recovery_failure $recovery;append message "; Canvas recovery failed: $recovery"}
            dict set ::GX::NativeCanvas::instances $handle history [dict get $row history]
        }
        return -options $errorOptions $message
    }
}
proc ::GX::native2DCanvasDescribe {handle} {
    set row [_nativeCanvasRequire $handle];set state [_nativeCanvasIndexedState [[dict get $row native] state]]
    set layers {};foreach item [dict get $state layers] {lappend layers [dict remove $item id attributes canvas_metadata]}
    set objects {};foreach item [dict get $state objects] {
        lappend objects [dict create logical_id [dict get $item logical_id] kind [dict get $item kind] layer [_nativeCanvasLogicalFromId $state layers [dict get $item layer]]]
    }
    set selected [lmap id [dict get $state selected_objects] {_nativeCanvasLogicalFromId $state objects $id}]
    set result [dict create api_id NATIVE2D_API_v1 canvas_version 1 document_id [dict get $row document] canvas_id [dict get $state canvas_id] \
        generation [dict get $row receipt generation] revision [dict get $row receipt revision] tool [datasetPublicationV2DictDefault $row roi_tool [dict get $state tool]] \
        active_layer [_nativeCanvasLogicalFromId $state layers [dict get $state active_layer]] selection $selected extent [_nativeCanvasExtent {*}[dict get $state extent]] background [dict get $state background] \
        layers $layers objects $objects history_cursor [dict get $row history cursor] history_steps [llength [dict get $row history steps]] pending [expr {[dict get $row pending] ne {}}] display_precision rgba8_sRGB]
    if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
        dict set result rendering [dict remove [native2DSpriteSceneDescribe [dict get $row canvas]] item]
        dict set result scheduling [dict remove [guiUpdateSchedulerDescribe [dict get $row scheduler]] owner config]
    }
    return $result
}
proc ::GX::_nativeCanvasNotify {handle event} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    if {[dict get $row scheduler] ne {}} {catch {guiUpdateSchedulerRequest [dict get $row scheduler]}}
    if {[dict exists $row callback] && [dict get $row callback] ne {}} {
        if {[catch {uplevel #0 [list {*}[dict get $row callback] $event]} message] && [dict exists $::GX::NativeCanvas::instances $handle]} {dict set ::GX::NativeCanvas::instances $handle notification_error $message}
    }
}

# Exact native Workspace types. Scientific arrays remain managed resources.
::GX::nativeWorkspaceShapeRegister canvas_layer {record {logical_id text name text attributes {map text} properties {record {visible bool selectable bool locked bool order int opacity real}} blend text}}
::GX::nativeWorkspaceShapeRegister canvas_leaf {record {logical_id text name text resource {resource {named resource_metadata}} style {named native_style} layer_logical_id text source {named raster_source}}}
::GX::nativeWorkspaceShapeRegister canvas_group {record {logical_id text name text members {array text} attributes {map text} style {named native_style} layer_logical_id text}}
::GX::nativeWorkspaceShapeRegister canvas_snapshot {record {
    schema text document_id text generation text canvas_id text extent {array int} background {array real}
    layers {array {named canvas_layer}} objects {array {named canvas_leaf}} groups {array {named canvas_group}}
    view_state {named view2d} selection {array text} active_layer text tool text retained_outputs {array {resource {named resource_metadata}}}
}}
::GX::scientificRecipeHostRegister framework.native2d.canvas [dict create capture ::GX::native2DCanvasApiInfo validate ::GX::_nativeCanvasHistoryValidate replay ::GX::scientificHistoryState]

# Same selected-image ROI facets use original Native2D geometry/Resource owners.
source [file join [file dirname [info script]] native2d_canvas_roi_v1.tcl]

# Shared original native facts/frame/glyph owner; application model assembly
# remains in the activated extension module.
source [file join [file dirname [info script]] native2d_canvas_projection_v1.tcl]
