# SPDX-License-Identifier: GPL-3.0-or-later
# Native tasks extend Scientific Execution; only the existing Supervisor owns
# admission, scheduling, process families, cancellation, resources and journals.
namespace eval ::GX::NativeJobs {variable subscriptions {};variable serial 0;variable viewerJobs {}}
proc ::GX::nativeJobApiInfo {} {
    return [dict create api_id NATIVE_JOB_API_v1 api_version 1 authority SCIENTIFIC_EXECUTION_API_v1 job_authority SCRIPT_JOB_API_v1 operations {info describe prepare submit status cancel result reconnect events read_buffer} host_only_operations {register subscribe unsubscribe} artifact_schema gxtxt.native_job_artifact.v1 event_schema gxtxt.job_event.v1]
}
proc ::GX::_nativeJobVerifyDescriptor {artifact} {
    set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_native_job.py] verify_tcl [dict get $artifact module_root]]
    if {[catch {exec {*}$command << $artifact} response] || ![dict get $response ok]} {
        if {![catch {dict get $response error} message]} {error $message}
        error $response
    }
    return [dict get $response result]
}
# Script Bridge exposure: HOST_ONLY_JUSTIFIED, operation register. Registration
# resolves an installed module's executable/source manifest and mutates the host
# provider registry. Worker scripts never select filesystem executables or issue
# trust grants; script-safe callers use prepare/submit of an admitted provider.
proc ::GX::nativeJobRegister {module entrypoint} {
    if {![regexp {^[A-Za-z][A-Za-z0-9_.-]*$} $module] || ![regexp {^[A-Za-z][A-Za-z0-9_]*$} $entrypoint]} {error {Invalid native module or entrypoint identity}}
    set descriptor [moduleField $module descriptor {}]
    if {$descriptor eq {} || ![file isfile $descriptor]} {error {Native task requires an installed Viewer module}}
    set root [file normalize [file dirname $descriptor]]
    set manifest [scriptModuleSafeRelative $root native/jobs/$entrypoint.json]
    set channel [open $manifest rb]
    try {set json [read $channel 1048577]} finally {close $channel}
    if {[string bytelength $json]>1048576} {error {Native artifact descriptor exceeds bound}}
    set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_native_job.py] verify $root]
    if {[catch {exec {*}$command << $json} response] || ![dict get $response ok]} {
        if {![catch {dict get $response error} message]} {error $message}
        error $response
    }
    set artifact [dict get $response result]
    dict set artifact module_id $module
    dict set artifact entrypoint $entrypoint
    set provider native.$module.$entrypoint
    scientificExecutionRegister $provider [dict create module_id $module version [moduleField $module version 1.0.0] worker core/python/gxtxt_native_job.py tools {} parameters [dict get $artifact parameters] native_artifact $artifact]
    return $provider
}
proc ::GX::nativeJobDescribe {module entrypoint} {
    set provider [nativeJobRegister $module $entrypoint]
    set artifact [dict get $::GX::ScientificExecution::providers $provider native_artifact]
    return [dict merge [dict remove $artifact module_root artifact] [dict create provider_id $provider module_id $module entrypoint $entrypoint]]
}
proc ::GX::_nativeJobPrepareOptions {options} {
    if {[dict exists $options source_guard]} {
        set guard [dict get $options source_guard]
        _scientificExecutionPublicationGuard $guard
        if {[dict exists $options document_id] && [dict get $options document_id] ne [dict get $guard document_id]} {error {Native Document guard and source ID disagree}}
        dict set options document_id [dict get $guard document_id]
        foreach {expected actual} {expected_revision revision expected_generation generation expected_sha256 sha256} {dict set options $expected [dict get $guard $actual]}
        dict unset options source_guard
    }
    if {[dict exists $options document_id]} {
        foreach key {expected_revision expected_generation expected_sha256} {if {![dict exists $options $key]} {error {Native Document binding requires exact generation/revision/SHA source guard}}}
    }
    return $options
}
proc ::GX::_nativeJobInputDescriptors {resources} {
    set descriptors {}
    dict for {alias reference} $resources {
        interactiveDocumentResourceInfo $reference
        if {![dict exists $reference metadata binary_descriptor]} {error {Native numeric resource requires original binary descriptor v2 metadata}}
        set descriptor [dict get $reference metadata binary_descriptor]
        if {![dict exists $descriptor byte_count] || [dict get $descriptor byte_count] ne [dict get $reference size_bytes]} {error {Native resource byte count and descriptor disagree}}
        dict set descriptors $alias $descriptor
    }
    if {$descriptors ne {}} {
        set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_native_job.py] validate_buffers]
        if {[catch {exec {*}$command << $descriptors} response] || ![dict get $response ok]} {
            if {![catch {dict get $response error} message]} {error $message};error $response
        }
    }
    return $descriptors
}
proc ::GX::nativeJobPrepare {module entrypoint parameters {options {}} {resources {}}} {
    set provider [nativeJobRegister $module $entrypoint]
    set options [_nativeJobPrepareOptions $options]
    set destination [datasetPublicationV2DictDefault $options node_id [scientificExecutionDestination]]
    if {$destination ni {local auto}} {
        return [scientificExecutionRemoteNativePrepare $destination $module $entrypoint [nativeJobDescribe $module $entrypoint] $parameters $options $resources]
    }
    if {$destination eq {auto}} {dict set options node_id local}
    set token [scientificExecutionPrepare $provider $parameters $resources $options]
    return $token
}
proc ::GX::nativeJobSubmit {token {callback {}}} {scientificExecutionSubmit $token $callback}
proc ::GX::nativeJobSubmitOwned {module token {callback {}}} {
    if {[string match remote-prepare#* $token]} {
        if {![dict exists $::GX::ScientificExecution::remotePrepared $token native_identity module_id] || [dict get $::GX::ScientificExecution::remotePrepared $token native_identity module_id] ne $module} {error {Native preparation belongs to another Viewer}}
    } elseif {![dict exists $::GX::ScientificExecution::prepared $token request native_owner module_id] || [dict get $::GX::ScientificExecution::prepared $token request native_owner module_id] ne $module} {error {Native preparation belongs to another Viewer}}
    return [nativeJobSubmit $token $callback]
}
proc ::GX::_nativeJobOwned {id {module {}}} {
    if {[scientificExecutionRemoteId $id]} {
        set status [scientificExecutionStatus $id]
        if {![string match native.* [dict get $status provider_id]]} {error {Job is not an admitted native task}}
        _scientificExecutionRemoteNativeOriginGuard $status $module
        if {$module ne {} && [dict get $status provider_id] ni [list native.$module.[datasetPublicationV2DictDefault $status entrypoint {}]] && ![string match native.$module.* [dict get $status provider_id]]} {error {Remote native Job belongs to another Viewer}}
        return $status
    }
    set job [_scientificExecutionJob $id $module]
    if {![dict exists $job scientific_request native_owner]} {error {Job is not an admitted native task}}
    return $job
}
proc ::GX::_nativeJobRecordGuard {job {module {}}} {
    set request [dict get $job scientific_request]
    if {![dict exists $request native_owner module_id] || ($module ne {} && [dict get $request native_owner module_id] ne $module)} {error {Native Job belongs to another Viewer}}
    if {![dict exists $request native_owner session_fingerprint] || [dict get $request native_owner session_fingerprint] ne [_scientificExecutionRemoteSessionFingerprint]} {error {Native Job belongs to another Session incarnation; explicit readmission required}}
    dict for {alias reference} [datasetPublicationV2DictDefault [dict get $request native_owner] resource_sources {}] {interactiveDocumentResourceInfo $reference}
    _scientificExecutionSourcesCurrent [dict get $request source_identities]
    set current [nativeJobDescribe [dict get $request native_owner module_id] [dict get $request native_owner entrypoint]]
    set retained [dict get $request native_artifact]
    if {[_scientificExecutionNativeIdentity $current] ne [_scientificExecutionNativeIdentity $retained]} {error {Native Viewer artifact/source/ABI/dependency identity changed; explicit readmission required}}
    if {[_scientificExecutionNativeParameterIdentity [dict get $current parameters]] ne [_scientificExecutionNativeParameterIdentity [dict get $retained parameters]]} {error {Native Viewer parameter schema changed; explicit readmission required}}
    # New host-derived metadata pins, when carried by an admitted artifact,
    # retain their exact contract. Legacy scalar descriptor ABI stays valid.
    # Paired remote_build metadata is additionally checked by its Node owner.
    set build {}
    foreach field {project_source_sha256 build_contract_sha256} {
        if {[dict exists $retained $field]} {
            if {$build eq {}} {set build [_scientificExecutionNativeBuildIdentity [dict get $request native_owner module_id] [dict get $request native_owner entrypoint] $current]}
            if {[dict get $build $field] ne [dict get $retained $field]} {error {Native Viewer installed project/build contract changed; explicit readmission required}}
        }
    }
    return $job
}
proc ::GX::nativeJobStatus {id {module {}}} {_nativeJobOwned $id $module;return [scientificExecutionStatus $id]}
proc ::GX::nativeJobCancel {id {module {}}} {_nativeJobOwned $id $module;return [scientificExecutionCancel $id]}
proc ::GX::nativeJobReconnect {id {module {}}} {_nativeJobOwned $id $module;return [scientificExecutionReconnect $id]}
proc ::GX::nativeJobResult {id {module {}}} {
    set owned [_nativeJobOwned $id $module]
    if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteNativeResult $id $module]}
    set status [scientificExecutionStatus $id]
    if {[dict get $status state] ne {COMPLETED}} {error {Native result requires a completed Job}}
    set outputs [scientificExecutionOutputs $id]
    if {![dict exists $outputs summary native_result]} {error {Native completed result is unavailable}}
    if {[scientificExecutionRemoteId $id]} {
        set resultTyped [_nativeJobReceiptTyped [dict get $outputs summary native_result]]
    } else {
        set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_native_job.py] result [dict get $owned output_dir]]
        if {[catch {exec {*}$command} encoded] || ![dict get $encoded ok]} {error {Retained native typed result is unavailable}}
        set resultTyped [nativeWorkspaceJsonDecode [dict get $encoded result json]]
    }
    return [dict create job_id $id state COMPLETED result_typed $resultTyped source_identities [dict get $status source_identities] artifact_sha256 [dict get $outputs summary artifact_sha256] source_sha256 [dict get $outputs summary source_sha256]]
}

# Script Bridge exposure: HOST_ONLY_JUSTIFIED, exact helpers scriptJobSubscribe
# and scriptJobUnsubscribe. They own trusted Tcl callback prefixes and a live
# interpreter/channel event lifetime; workers instead read the same Job journal.
# Host subscriptions retain transient callbacks only. The durable authority is
# jobs.sqlite, and a lost subscription never removes retained status or results.
proc ::GX::scriptJobSubscribe {id callback {afterSequence 0}} {
    if {![string is entier -strict $afterSequence] || $afterSequence<0 || $callback eq {}} {error {Subscription requires a callback and nonnegative journal sequence}}
    if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteSubscribe $id $callback $afterSequence]}
    scriptJobDescribe $id
    return [_scriptJobSubscribeAdmitted $id $callback $afterSequence]
}
# HOST_ONLY_JUSTIFIED: trusted CORE has already admitted the actual Job/source
# and client owner. No Script Bridge operation exposes this watcher constructor;
# public scriptJobSubscribe still performs its original describe validation.
# The same Supervisor watcher verifies the authoritative ID/journal on connect.
proc ::GX::_scriptJobSubscribeAdmitted {id callback {afterSequence 0}} {
    if {![string is entier -strict $afterSequence] || $afterSequence<0 || $callback eq {}} {error {Subscription requires a callback and nonnegative journal sequence}}
    if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteSubscribe $id $callback $afterSequence]}
    set pipe [open [list | {*}[scriptJobCommand watch $id $afterSequence]] r+]
    fconfigure $pipe -blocking 0 -buffering line -encoding ascii -translation lf
    set token native-job-listener#[incr ::GX::NativeJobs::serial]
    dict set ::GX::NativeJobs::subscriptions $token [dict create pipe $pipe callback $callback job_id $id sequence $afterSequence buffer {}]
    fileevent $pipe readable [list ::GX::_nativeJobReadable $token]
    return $token
}
proc ::GX::scriptJobUnsubscribe {token} {
    if {[string match remote-job-listener#* $token]} {return [scientificExecutionRemoteUnsubscribe $token]}
    if {![dict exists $::GX::NativeJobs::subscriptions $token]} {return 0}
    set pipe [dict get $::GX::NativeJobs::subscriptions $token pipe]
    dict unset ::GX::NativeJobs::subscriptions $token
    catch {fileevent $pipe readable {}};catch {close $pipe}
    return 1
}
proc ::GX::_nativeJobReadable {token} {
    if {![dict exists $::GX::NativeJobs::subscriptions $token]} return
    set entry [dict get $::GX::NativeJobs::subscriptions $token];set pipe [dict get $entry pipe]
    if {[catch {set chunk [read $pipe 65536]}]} {scriptJobUnsubscribe $token;return}
    dict append entry buffer $chunk
    if {[string length [dict get $entry buffer]]>2097152} {scriptJobUnsubscribe $token;return}
    set data [dict get $entry buffer]
    while {[set newline [string first \n $data]]>=0} {
        set line [string range $data 0 [expr {$newline-1}]];set data [string range $data [expr {$newline+1}] end]
        if {$line eq {}} continue
        if {[catch {set event [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [encoding convertfrom utf-8 [binary decode base64 -strict $line]]]]}]} {scriptJobUnsubscribe $token;return}
        if {[dict get $event job_id] ne [dict get $entry job_id] || [dict get $event sequence]<=[dict get $entry sequence]} continue
        dict set entry sequence [dict get $event sequence]
        dict set entry buffer $data
        dict set ::GX::NativeJobs::subscriptions $token $entry
        # fileevent already runs in this Tcl owning thread. Callback prefixes
        # are trusted host state, never text originating from the task worker.
        catch {uplevel #0 [list {*}[dict get $entry callback] $event]}
        if {![dict exists $::GX::NativeJobs::subscriptions $token]} return
    }
    dict set entry buffer $data
    dict set ::GX::NativeJobs::subscriptions $token $entry
    if {[eof $pipe]} {scriptJobUnsubscribe $token}
}
# Script Bridge exposure: HOST_ONLY_JUSTIFIED, operations subscribe/unsubscribe.
# subscribe stores a trusted Tcl callback prefix and channel in the owning GUI
# event loop; serializable Python/Octave workers cannot supply or own that host
# lifetime. unsubscribe retires that exact interpreter/channel token, not a Job.
# All frontends can instead read the same durable typed event journal by events.
proc ::GX::nativeJobSubscribe {id callback {afterSequence 0} {module {}}} {_nativeJobOwned $id $module;return [scriptJobSubscribe $id $callback $afterSequence]}
proc ::GX::nativeJobUnsubscribe {token} {scriptJobUnsubscribe $token}
proc ::GX::nativeJobEvents {id {afterSequence 0} {limit 256} {module {}}} {
    _nativeJobOwned $id $module
    if {[scientificExecutionRemoteId $id]} {
        if {![string is entier -strict $limit] || $limit<1 || $limit>512} {error {Event page exceeds bounds}}
        lassign [_scientificRemoteRoute $id] node session job
        set page [scientificExecutionRemoteCall $node $session scientific.events $job $afterSequence [expr {min(128,$limit)}] 0]
        set result {}
        foreach event [dict get $page events] {dict set event job_id $id;dict set event node_id $node;lappend result $event}
        return $result
    }
    return [scriptJobCall events $id $afterSequence $limit]
}

proc ::GX::_nativeJobReceiptTyped {receipt} {
    set fields {}
    dict for {key value} $receipt {
        if {$key eq {result_typed}} {dict set fields result $value
        } elseif {$key eq {sequence}} {dict set fields $key [list int $value]
        } elseif {$key in {timestamp fraction}} {dict set fields $key [list real $value]
        } elseif {$key in {terminal cancel_requested retired}} {dict set fields $key [list bool $value]
        } elseif {$key in {progress result_ref source_identities native_artifact workspace}} {dict set fields $key [_nativeJobReceiptTyped $value]
        } else {dict set fields $key [list text $value]}
    }
    return [list object $fields]
}
proc ::GX::_viewerNativeJobDeliver {window lifetime generation action receipt} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    set current [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict get $current lifetime] ne $lifetime} return
    if {[dict exists $current native_job_session_token] && [dict get $current native_job_session_token] ne [interactiveDocumentSessionToken]} return
    if {$action eq {event} && [dict exists $receipt sequence] && [dict exists $receipt job_id]} {
        set id [dict get $receipt job_id];set sequence [dict get $receipt sequence]
        if {[dict exists $current native_job_sequences $id] && $sequence<=[dict get $current native_job_sequences $id]} return
        if {[dict exists $current native_job_terminal $id]} return
        dict set ::GX::ViewerDevelopment::windows $window native_job_sequences $id $sequence
        if {[dict get $receipt terminal]} {dict set ::GX::ViewerDevelopment::windows $window native_job_terminal $id 1}
    }
    set queue [datasetPublicationV2DictDefault $current native_job_events {}]
    if {[llength $queue]>=1024} {
        # Never silently attach another Job's result or report fake completion.
        # A bounded overflow is an explicit recoverable notification failure.
        set queue [list [list object [dict create action {text event_gap} receipt [list object [dict create diagnostic {text {Native event queue overflow; reconnect by retained sequence}}]]]]]
    }
    lappend queue [list object [dict create action [list text $action] receipt [_nativeJobReceiptTyped $receipt]]]
    dict set ::GX::ViewerDevelopment::windows $window native_job_events $queue
    if {![datasetPublicationV2DictDefault $current native_job_drain_scheduled 0]} {
        dict set ::GX::ViewerDevelopment::windows $window native_job_drain_scheduled 1
        after idle [list ::GX::viewerNativeJobDrain $window]
    }
}
proc ::GX::viewerNativeJobDrain {window} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    dict set ::GX::ViewerDevelopment::windows $window native_job_drain_scheduled 0
    set current [dict get $::GX::ViewerDevelopment::windows $window]
    set queue [datasetPublicationV2DictDefault $current native_job_events {}]
    if {$queue eq {} || [datasetPublicationV2DictDefault $current busy {}] ne {} || [datasetPublicationV2DictDefault $current status {}] eq {RUNNING}} return
    dict set ::GX::ViewerDevelopment::windows $window native_job_result [lindex $queue 0]
    dict set ::GX::ViewerDevelopment::windows $window native_job_events [lrange $queue 1 end]
    viewerDevelopmentInvoke $window __native_job_event__
}
proc ::GX::_viewerNativeJobAccepted {window lifetime generation module response} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    if {![dict get $response ok]} {_viewerNativeJobDeliver $window $lifetime $generation submit [dict create error [dict get $response error]];return}
    set receipt [dict get $response result];set id [dict get $receipt job_id]
    viewerJobClientClaim $window $id 0
    dict set ::GX::NativeJobs::viewerJobs $id [dict create module $module window $window lifetime $lifetime generation $generation]
    set subscription [nativeJobSubscribe $id [list ::GX::_viewerNativeJobDeliver $window $lifetime $generation event] 0 $module]
    dict set ::GX::ViewerDevelopment::windows $window native_job_subscriptions [concat [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] native_job_subscriptions {}] [list $subscription]]
    _viewerNativeJobDeliver $window $lifetime $generation submit $receipt
}
# Host-only captured metadata for the existing guarded Job owner CAS. The GUI
# captures live lifetimes; an existing trusted request child can validate and
# claim without inventing a Tk window. No public Script Bridge operation exposes
# this host attestation, and local Supervisor liveness checks remain mandatory.
proc ::GX::_viewerJobClientClaimCaptured {id module clientPid clientIdentity instance liveInstances record {reconnect 0}} {
    if {![string is integer -strict $clientPid] || $clientPid<=0 || $clientIdentity eq {} || $instance eq {} || $instance ni $liveInstances || $module eq {}} {error {Viewer client capture is incomplete}}
    if {[scriptJobCall process_identity $clientPid] ne $clientIdentity} {error {Viewer client process identity is no longer current}}
    if {[dict exists $record id] && [dict get $record id] ne $id} {error {Viewer claim row belongs to another Job}}
    set remote [scientificExecutionRemoteId $id]
    set proposed [dict create pid [list int $clientPid] process [list text $clientIdentity] instance [list text $instance]]
    set expected null
    if {[dict exists $record client_owner]} {
        set owner [dict get $record client_owner]
        if {$remote && ([dict get $owner pid]!=$clientPid || [dict get $owner process] ne $clientIdentity) && [scriptJobCall process_identity [dict get $owner pid]] eq [dict get $owner process]} {error {Job belongs to another live client process}}
        if {[dict get $owner instance] ne $instance && [dict get $owner pid]==$clientPid && [dict get $owner process] eq $clientIdentity && [dict get $owner instance] in $liveInstances} {error {Job belongs to another live Viewer instance}}
        if {!$reconnect && [dict get $owner instance] ne $instance} {error {Job requires explicit guarded reconnect}}
        set fields {};foreach key {pid process instance} {dict set fields $key [list [expr {$key eq {pid}?{int}:{text}}] [dict get $owner $key]]}
        set expected [nativeWorkspaceJsonEncode [list object $fields]]
    }
    if {$remote} {
        return [_scientificExecutionRemoteClientOwnerClaim $id $module $expected [nativeWorkspaceJsonEncode [list object $proposed]]]
    }
    return [scriptJobCall client_owner_claim $id $expected [nativeWorkspaceJsonEncode [list object $proposed]]]
}
proc ::GX::viewerJobClientClaim {window id {reconnect 0}} {
    set state [dict get $::GX::ViewerDevelopment::windows $window]
    set liveInstances {}
    dict for {other candidate} $::GX::ViewerDevelopment::windows {
        if {[dict exists $candidate lifetime]} {lappend liveInstances [dict get $candidate lifetime]}
    }
    set identity [scriptJobCall process_identity [pid]]
    return [_viewerJobClientClaimCaptured $id [dict get $state module] [pid] $identity [dict get $state lifetime] $liveInstances [scriptJobDescribe $id] $reconnect]
}
proc ::GX::viewerNativeJobDispose {window} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} return
    set state [dict get $::GX::ViewerDevelopment::windows $window]
    foreach token [datasetPublicationV2DictDefault $state native_job_subscriptions {}] {catch {scriptJobUnsubscribe $token}}
    foreach token [dict keys [datasetPublicationV2DictDefault $state native_job_preparations {}]] {catch {scientificExecutionDiscard $token}}
    dict for {id owner} $::GX::NativeJobs::viewerJobs {
        if {[dict get $owner window] eq $window} {dict unset ::GX::NativeJobs::viewerJobs $id}
    }
}
# Called only by the fixed trusted auxiliary bootstrap after installed package,
# actual Module selection and originating Session admission. No Tk state exists
# in this child; the existing Supervisor alone schedules scientific work.
proc ::GX::viewerNativeJobWorker {context action typed} {
    if {[lindex $typed 0] ne {object}} {error {Native request requires a typed object}}
    if {![dict exists $context client_identity] || [dict get $context client_identity] eq {}} {error {Native auxiliary request lacks its captured parent process identity}}
    set fields [nativeWorkspaceDecode $typed];set module [dict get $context module]
    if {$action eq {transport_guard}} {
        # HOST_ONLY_JUSTIFIED: exact retained worker admission, never a public
        # C++ action or fresh remote-state/CAS claim while an endpoint is down.
        if {[dict keys $fields] ne {job_id} || ![dict exists $context native_remote_admission]} {error {Transport diagnostic lacks its admitted native context}}
        set id [dict get $fields job_id];set admission [dict get $context native_remote_admission]
        if {![scientificExecutionRemoteId $id] || [dict get $admission job_id] ne $id} {error {Transport diagnostic belongs to another Job}}
        lassign [_scientificRemoteRoute $id] node session remoteJob
        if {[dict get $admission node_id] ne $node || [dict get $admission remote_session_id] ne $session} {error {Transport diagnostic node/session changed}}
        _scientificExecutionRemoteNativeOriginGuard $admission $module
        return [dict create job_id $id remote_admission $admission admission_request_id [dict get $context request_id] source_guard [dict create source_identities [dict get $admission native_owner client_origin source_identities]] resource_sources {}]
    }
    if {$action eq {submit}} {
        if {[lsort [dict keys $fields]] ni {{entrypoint parameters} {entrypoint options parameters} {entrypoint parameters resources} {entrypoint options parameters resources}}} {error {Native submit requires entrypoint, parameters, optional source options and managed resources}}
        set prepared [nativeJobPrepare $module [dict get $fields entrypoint] [dict get $fields parameters] [datasetPublicationV2DictDefault $fields options {}] [datasetPublicationV2DictDefault $fields resources {}]]
        set receipt [nativeJobSubmitOwned $module $prepared]
        set id [dict get $receipt job_id]
    } else {
        if {![dict exists $fields job_id]} {error {Native lifecycle requires its Job ID}}
        set id [dict get $fields job_id]
    }
    set owned [_nativeJobOwned $id $module]
    _viewerBridgeCapturedClaim $id $context [scriptJobDescribe $id] [expr {$action eq {reconnect}}]
    if {[scientificExecutionRemoteId $id]} {
        set identities [dict get $owned native_owner client_origin source_identities];set resources {}
    } else {
        set identities [dict get $owned scientific_request source_identities]
        set resources [datasetPublicationV2DictDefault [dict get $owned scientific_request native_owner] resource_sources {}]
    }
    switch -- $action {
        submit {}
        status {set receipt [nativeJobStatus $id $module]}
        cancel {set receipt [nativeJobCancel $id $module]}
        result {set receipt [nativeJobResult $id $module]}
        reconnect {set receipt [nativeJobReconnect $id $module]}
        subscribe - event {set receipt [dict create job_id $id]}
        default {error {Unknown native managed lifecycle action}}
    }
    set reply [dict create job_id $id receipt $receipt source_guard [dict create source_identities $identities] resource_sources $resources admission_request_id [dict get $context request_id]]
    if {[scientificExecutionRemoteId $id]} {dict set reply remote_admission $owned}
    return $reply
}
# Purely transient Host binding check. Durable ownership/source checks occur in
# the trusted child and existing journal CAS, then the live binding is checked
# again before any returned receipt or listener enters this owning event loop.
proc ::GX::_viewerNativeJobBinding {window lifetime id {reconnect 0}} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} {error {Native Viewer lifetime ended}}
    if {!$reconnect && (![dict exists $::GX::NativeJobs::viewerJobs $id] || [dict get $::GX::NativeJobs::viewerJobs $id window] ne $window || [dict get $::GX::NativeJobs::viewerJobs $id lifetime] ne $lifetime)} {error {Native Job belongs to another Viewer instance; explicitly reconnect}}
    if {$reconnect && [dict exists $::GX::NativeJobs::viewerJobs $id]} {
        set owner [dict get $::GX::NativeJobs::viewerJobs $id]
        if {([dict get $owner window] ne $window || [dict get $owner lifetime] ne $lifetime) && [dict exists $::GX::ViewerDevelopment::windows [dict get $owner window] lifetime] && [dict get $::GX::ViewerDevelopment::windows [dict get $owner window] lifetime] eq [dict get $owner lifetime]} {error {Native Job belongs to another live Viewer instance}}
    }
}
# Reserve only the existing transient GUI binding while async CAS is in flight.
# This prevents a future same-process View, absent from an older captured live
# list, from claiming concurrently. The durable owner remains the SAME CAS.
proc ::GX::_viewerNativeJobReserveReconnect {window context id} {
    _viewerNativeJobBinding $window [dict get $context lifetime] $id 1
    if {[dict exists $::GX::NativeJobs::viewerJobs $id pending_request]} {error {Native reconnect is already pending}}
    dict set context native_reserved_job $id
    if {[dict exists $::GX::NativeJobs::viewerJobs $id]} {dict set context native_previous_owner [dict get $::GX::NativeJobs::viewerJobs $id]}
    dict set ::GX::NativeJobs::viewerJobs $id [dict create module [dict get $context module] window $window lifetime [dict get $context lifetime] generation 0 pending_request [dict get $context request_id]]
    return $context
}
proc ::GX::_viewerNativeJobReleaseReservation {window context} {
    if {![dict exists $context native_reserved_job]} return
    set id [dict get $context native_reserved_job]
    if {![dict exists $::GX::NativeJobs::viewerJobs $id]} return
    set owner [dict get $::GX::NativeJobs::viewerJobs $id]
    if {[dict get $owner window] ne $window || [dict get $owner lifetime] ne [dict get $context lifetime] || ![dict exists $owner pending_request] || [dict get $owner pending_request] ne [dict get $context request_id]} return
    if {[dict exists $context native_previous_owner]} {dict set ::GX::NativeJobs::viewerJobs $id [dict get $context native_previous_owner]} else {dict unset ::GX::NativeJobs::viewerJobs $id}
}
# Latest-issued watcher admission is transient existing-window metadata, not
# another Job owner. Old asynchronous replies cannot mutate a newer stream.
proc ::GX::_viewerNativeJobWatchCurrent {window context id} {
    _viewerNativeJobBinding $window [dict get $context lifetime] $id
    if {![dict exists $context request_id] || ![dict exists $::GX::ViewerDevelopment::windows $window native_job_watch_requests $id] || [dict get $::GX::ViewerDevelopment::windows $window native_job_watch_requests $id] ne [dict get $context request_id]} {error {Native watch admission was superseded or retired}}
}
proc ::GX::_viewerNativeJobIssueWatch {window context id} {
    dict set context native_watch_job $id
    dict set ::GX::ViewerDevelopment::windows $window native_job_watch_requests $id [dict get $context request_id]
    return $context
}
proc ::GX::_viewerNativeJobReleaseWatch {window context} {
    if {![dict exists $context native_watch_job]} return
    set id [dict get $context native_watch_job]
    if {![dict exists $::GX::ViewerDevelopment::windows $window native_job_watch_requests $id] || [dict get $::GX::ViewerDevelopment::windows $window native_job_watch_requests $id] ne [dict get $context request_id]} return
    # A superseded guard may already have finished. Never revive an old stamp
    # and its stale in-flight marker; a failed new admission retires the watch.
    dict unset ::GX::ViewerDevelopment::windows $window native_job_watch_requests $id
}
proc ::GX::_viewerNativeJobRemoteReplyCurrent {window context reply id} {
    _viewerNativeJobWatchCurrent $window $context $id
    _viewerBridgeReplyCurrent $window $context $reply
    # ReplyCurrent deliberately has no full remote-origin RPC; retain the cheap
    # manifest-origin check after async validation, including callback mutation.
    if {[dict exists $reply remote_admission] && [dict get $reply remote_admission native_owner client_origin session_origin] ne [sessionOriginRead $::GX::currentSession]} {error {Native remote manifest origin changed before callback}}
    dict for {alias reference} [dict get $reply resource_sources] {interactiveDocumentResourceInfo $reference}
    _viewerNativeJobWatchCurrent $window $context $id
}
proc ::GX::_viewerNativeJobTransportShape {event} {
    if {![dict exists $event schema] || [dict get $event schema] ne {gxtxt.job_transport_error.v1} || ![dict exists $event event] || [dict get $event event] ne {transport_error} || [dict exists $event sequence] || [dict exists $event state] || ![dict exists $event terminal] || [dict get $event terminal]} {error {Invalid native transport diagnostic shape}}
}
proc ::GX::_viewerNativeJobTransportReady {window context event response} {
    if {[catch {_viewerNativeJobTransportShape $event}]} return
    set id [dict get $event job_id]
    if {[catch {
        _viewerNativeJobWatchCurrent $window $context $id
        if {![dict get $response ok]} {error {Transport diagnostic local source validation failed}}
        set reply [dict get $response result]
        if {[dict get $reply job_id] ne $id || [dict get $reply admission_request_id] ne [dict get $context request_id] || [dict get $reply remote_admission] ne [dict get $context native_remote_admission]} {error {Transport diagnostic admission changed}}
        _viewerNativeJobRemoteReplyCurrent $window $context $reply $id
    }]} return
    # This diagnostic has no invented sequence/state and says nothing about
    # current node execution. Endpoint loss never becomes a fabricated failure.
    _viewerNativeJobDeliver $window [dict get $context lifetime] 0 event $event
}
# This is transient GUI backpressure only. The complete ordered stream remains
# in the same Supervisor journal. A raw socket burst never repeats full source
# guards synchronously for every line: one trusted validation per Job is active,
# progress waiting behind it coalesces, and the first terminal remains pinned.
proc ::GX::_viewerNativeJobAdmittedEvent {window context reply event} {
    set lifetime [dict get $context lifetime];set id [dict get $event job_id]
    if {[catch {_viewerNativeJobWatchCurrent $window $context $id}]} return
    if {[dict exists $event event] && [dict get $event event] eq {transport_error}} {
        if {![dict exists $reply remote_admission] || [catch {_viewerNativeJobTransportShape $event}]} return
        dict set context native_remote_admission [dict get $reply remote_admission]
        # Full LOCAL source/origin/native-build validation remains async and
        # succeeds independently of the unreachable node; no RPC/CAS here.
        catch {_viewerBridgeRequest $window $context native transport_guard [list object [dict create job_id [list text $id]]] [list ::GX::_viewerNativeJobTransportReady $window $context $event]}
        return
    }
    if {![dict exists $event sequence]} return
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict exists $r native_job_terminal $id] || ([dict exists $r native_job_sequences $id] && [dict get $event sequence]<=[dict get $r native_job_sequences $id])} return
    if {[dict exists $r native_job_event_pending $id] && [dict get $r native_job_event_pending $id context request_id] eq [dict get $context request_id]} {
        set previous [dict get $r native_job_event_pending $id event]
        if {[dict get $previous terminal] || [dict get $event sequence]<=[dict get $previous sequence]} return
    }
    dict set ::GX::ViewerDevelopment::windows $window native_job_event_pending $id [dict create context $context event $event]
    _viewerNativeJobEventValidate $window $lifetime $id
}
proc ::GX::_viewerNativeJobEventValidate {window lifetime id} {
    if {[catch {_viewerNativeJobBinding $window $lifetime $id}]} return
    set r [dict get $::GX::ViewerDevelopment::windows $window]
    if {![dict exists $r native_job_event_pending $id]} return
    set pending [dict get $r native_job_event_pending $id];set context [dict get $pending context];set stamp [dict get $context request_id]
    if {[catch {_viewerNativeJobWatchCurrent $window $context $id}]} return
    if {[dict exists $r native_job_event_validating $id] && [dict get $r native_job_event_validating $id] eq $stamp} return
    if {[dict exists $r native_job_terminal $id] || ([dict exists $r native_job_sequences $id] && [dict get $pending event sequence]<=[dict get $r native_job_sequences $id])} {dict unset ::GX::ViewerDevelopment::windows $window native_job_event_pending $id;return}
    dict unset ::GX::ViewerDevelopment::windows $window native_job_event_pending $id
    dict set ::GX::ViewerDevelopment::windows $window native_job_event_validating $id $stamp
    set event [dict get $pending event]
    if {[catch {_viewerBridgeRequest $window $context native event [list object [dict create job_id [list text $id]]] [list ::GX::_viewerNativeJobEventReady $window $context $event]}]} {
        if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_event_validating $id] && [dict get $::GX::ViewerDevelopment::windows $window native_job_event_validating $id] eq $stamp} {dict unset ::GX::ViewerDevelopment::windows $window native_job_event_validating $id}
    }
}
proc ::GX::_viewerNativeJobEventReady {window context event response} {
    set lifetime [dict get $context lifetime];set id [dict get $event job_id];set stamp [dict get $context request_id]
    # This return precedes every clear/unsubscribe/delivery: an old completion
    # must leave the newer in-flight validator and listener entirely untouched.
    if {[catch {_viewerNativeJobWatchCurrent $window $context $id}]} return
    if {![dict exists $::GX::ViewerDevelopment::windows $window native_job_event_validating $id] || [dict get $::GX::ViewerDevelopment::windows $window native_job_event_validating $id] ne $stamp} return
    dict unset ::GX::ViewerDevelopment::windows $window native_job_event_validating $id
    if {[catch {
        if {![dict get $response ok]} {error [dict get $response error]}
        set reply [dict get $response result]
        _viewerNativeJobRemoteReplyCurrent $window $context $reply $id
    }]} {
        if {[catch {_viewerNativeJobWatchCurrent $window $context $id}]} return
        foreach token [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] native_job_subscriptions {}] {
            if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_subscription_watches $token] && [dict get $::GX::ViewerDevelopment::windows $window native_job_subscription_watches $token job_id] eq $id && [dict get $::GX::ViewerDevelopment::windows $window native_job_subscription_watches $token request_id] eq $stamp} {catch {scriptJobUnsubscribe $token}}
        }
        if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_event_pending $id context request_id] && [dict get $::GX::ViewerDevelopment::windows $window native_job_event_pending $id context request_id] eq $stamp} {dict unset ::GX::ViewerDevelopment::windows $window native_job_event_pending $id}
        return
    }
    _viewerNativeJobDeliver $window $lifetime 0 event $event
    _viewerNativeJobEventValidate $window $lifetime $id
}
proc ::GX::_viewerNativeJobAsyncDone {window context action request response} {
    # The first request may have captured identity asynchronously after this
    # callback prefix was created. Retain that exact immutable GUI identity for
    # subsequent event admission; do not recompute a possibly reused PID.
    if {[info exists ::GX::ViewerScriptBridge::clientPid] && $::GX::ViewerScriptBridge::clientPid==[pid] && $::GX::ViewerScriptBridge::clientIdentity ne {}} {dict set context client_identity $::GX::ViewerScriptBridge::clientIdentity}
    set lifetime [dict get $context lifetime]
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime} return
    if {$action in {subscribe reconnect} && [catch {_viewerNativeJobWatchCurrent $window $context [dict get $request job_id]}]} return
    if {[catch {
        if {![dict get $response ok]} {error [dict get $response error]}
        set reply [dict get $response result]
        _viewerBridgeReplyCurrent $window $context $reply
        if {$action in {subscribe reconnect}} {_viewerNativeJobWatchCurrent $window $context [dict get $request job_id]}
        dict for {alias reference} [dict get $reply resource_sources] {interactiveDocumentResourceInfo $reference}
        set id [dict get $reply job_id]
        if {$action ni {submit reconnect}} {_viewerNativeJobBinding $window $lifetime $id}
        set receipt [dict get $reply receipt]
        if {$action in {submit reconnect}} {
            dict set ::GX::ViewerDevelopment::windows $window native_job_session_token [interactiveDocumentSessionToken]
            dict set ::GX::NativeJobs::viewerJobs $id [dict create module [dict get $context module] window $window lifetime $lifetime generation 0]
        }
        if {$action in {submit reconnect subscribe}} {
            if {$action eq {submit}} {dict set ::GX::ViewerDevelopment::windows $window native_job_watch_requests $id [dict get $context request_id]}
            _viewerNativeJobWatchCurrent $window $context $id
            set cursor [datasetPublicationV2DictDefault $request after_sequence 0]
            if {[scientificExecutionRemoteId $id] && [dict exists $reply remote_admission native_owner remote_build]} {
                # Actual paired admission uses only the fixed pending validator.
                # A present invalid pair/private validation failure never falls
                # back to a less strict path or another target.
                set subscription [_scientificExecutionRemoteNativeSubscribeAdmitted $id $window $context $reply $cursor]
            } else {
                # Actual legacy no-pair remote admissions retain the original
                # public per-frame guards and their explicit latency qualifier.
                set subscription [_scriptJobSubscribeAdmitted $id [list ::GX::_viewerNativeJobAdmittedEvent $window $context $reply] $cursor]
            }
            if {[catch {_viewerNativeJobWatchCurrent $window $context $id}]} {catch {scriptJobUnsubscribe $subscription};return}
            dict set ::GX::ViewerDevelopment::windows $window native_job_subscription_watches $subscription [dict create job_id $id request_id [dict get $context request_id]]
            set listeners [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] native_job_subscriptions {}]
            dict set ::GX::ViewerDevelopment::windows $window native_job_subscriptions [concat $listeners [list $subscription]]
            if {$action eq {subscribe}} {dict set receipt subscription_id $subscription}
        }
    } problem]} {
        if {$action in {subscribe reconnect} && [catch {_viewerNativeJobWatchCurrent $window $context [dict get $request job_id]}]} return
        _viewerNativeJobReleaseWatch $window $context
        _viewerNativeJobReleaseReservation $window $context
        set receipt [dict create submission_id [dict get $context request_id] error [_viewerNativeClientPublicMessage $problem]]
    }
    _viewerNativeJobDeliver $window $lifetime 0 $action $receipt
}
proc ::GX::viewerNativeJobCommand {window action typedRequest} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window] || [lindex $typedRequest 0] ne {object}} {error {Native task requires a live Viewer and typed object}}
    set state [_viewerNativeClientBase $window]
    foreach key {module runtime_module_root lifetime generation} {if {![dict exists $state $key] || [dict get $state $key] eq {}} {error {Native tasks require a normally installed Viewer}}}
    set request [nativeWorkspaceDecode $typedRequest];set module [dict get $state module]
    set lifetime [dict get $state lifetime];set generation [dict get $state generation]
    # Interpreter-local explicit preparations retain their existing parent path.
    # Ordinary submission and guarded lifecycle work use the existing auxiliary
    # request owner; pending IDs never impersonate accepted scientific Job IDs.
    if {$action ni {prepare unsubscribe} && !($action eq {submit} && [dict keys $request] eq {prepared_token})} {
        if {$action eq {submit}} {
            if {[lsort [dict keys $request]] ni {{entrypoint parameters} {entrypoint options parameters} {entrypoint parameters resources} {entrypoint options parameters resources}}} {error {Native submit requires entrypoint, parameters, optional source options and managed resources}}
        } else {
            if {![dict exists $request job_id]} {error {Native lifecycle operation requires a Job ID}}
            if {$action in {status cancel result} && [dict keys $request] ne {job_id}} {error {Native lifecycle operation requires only its Job ID}}
            if {$action in {reconnect subscribe} && [lsort [dict keys $request]] ni {job_id {after_sequence job_id}}} {error {Native reconnect/subscribe requires Job ID and optional sequence}}
            if {$action ni {status cancel result reconnect subscribe}} {error {Unknown native Job lifecycle operation}}
            _viewerNativeJobBinding $window $lifetime [dict get $request job_id] [expr {$action eq {reconnect}}]
        }
        set context [_viewerBridgeContext $window $state]
        if {$action eq {reconnect}} {set context [_viewerNativeJobReserveReconnect $window $context [dict get $request job_id]]}
        if {$action in {subscribe reconnect}} {set context [_viewerNativeJobIssueWatch $window $context [dict get $request job_id]]}
        if {[catch {_viewerBridgeRequest $window $context native $action $typedRequest [list ::GX::_viewerNativeJobAsyncDone $window $context $action $request]} failure options]} {
            _viewerNativeJobReleaseWatch $window $context
            _viewerNativeJobReleaseReservation $window $context
            return -options $options $failure
        }
        set pending [dict create submission_id [dict get $context request_id] state PENDING]
        _viewerNativeJobDeliver $window $lifetime $generation $action $pending
        return $pending
    }
    if {$action in {prepare submit}} {
        dict set ::GX::ViewerDevelopment::windows $window native_job_session_token [interactiveDocumentSessionToken]
        if {[dict keys $request] eq {prepared_token} && $action eq {submit}} {
            set prepared [dict get $request prepared_token]
            if {![dict exists $state native_job_preparations $prepared] || [dict get $state native_job_preparations $prepared] ne [interactiveDocumentSessionToken]} {error {Native preparation belongs to another Viewer or Session lifetime}}
        } else {
            if {[lsort [dict keys $request]] ni {{entrypoint parameters} {entrypoint options parameters} {entrypoint parameters resources} {entrypoint options parameters resources}}} {error {Native prepare/submit requires entrypoint, parameters, optional source options and managed resources}}
            set options [datasetPublicationV2DictDefault $request options {}]
            set prepared [nativeJobPrepare $module [dict get $request entrypoint] [dict get $request parameters] $options [datasetPublicationV2DictDefault $request resources {}]]
        }
        if {$action eq {prepare}} {
            dict set ::GX::ViewerDevelopment::windows $window native_job_preparations $prepared [interactiveDocumentSessionToken]
            set receipt [dict create prepared_token $prepared state PREPARED]
        } else {
            set receipt [nativeJobSubmitOwned $module $prepared [list ::GX::_viewerNativeJobAccepted $window $lifetime $generation $module]]
            if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_preparations $prepared]} {dict unset ::GX::ViewerDevelopment::windows $window native_job_preparations $prepared}
        }
    } elseif {$action eq {unsubscribe}} {
        if {[dict keys $request] ne {subscription_id}} {error {Native unsubscribe requires its subscription ID}}
        set token [dict get $request subscription_id]
        set listeners [datasetPublicationV2DictDefault $state native_job_subscriptions {}]
        if {$token ni $listeners} {error {Native listener belongs to another Viewer}}
        if {[dict exists $state native_job_subscription_watches $token]} {
            set watch [dict get $state native_job_subscription_watches $token];set id [dict get $watch job_id];set stamp [dict get $watch request_id]
            if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_watch_requests $id] && [dict get $::GX::ViewerDevelopment::windows $window native_job_watch_requests $id] eq $stamp} {dict unset ::GX::ViewerDevelopment::windows $window native_job_watch_requests $id}
            if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_event_validating $id] && [dict get $::GX::ViewerDevelopment::windows $window native_job_event_validating $id] eq $stamp} {dict unset ::GX::ViewerDevelopment::windows $window native_job_event_validating $id}
            if {[dict exists $::GX::ViewerDevelopment::windows $window native_job_event_pending $id context request_id] && [dict get $::GX::ViewerDevelopment::windows $window native_job_event_pending $id context request_id] eq $stamp} {dict unset ::GX::ViewerDevelopment::windows $window native_job_event_pending $id}
            dict unset ::GX::ViewerDevelopment::windows $window native_job_subscription_watches $token
        }
        set receipt [dict create subscription_id $token retired [scriptJobUnsubscribe $token]]
        dict set ::GX::ViewerDevelopment::windows $window native_job_subscriptions [lsearch -all -inline -not -exact $listeners $token]
    } else {
        if {![dict exists $request job_id]} {error {Native lifecycle operation requires a Job ID}}
        if {$action in {status cancel result} && [dict keys $request] ne {job_id}} {error {Native lifecycle operation requires only its Job ID}}
        if {$action in {reconnect subscribe} && [lsort [dict keys $request]] ni {job_id {after_sequence job_id}}} {error {Native reconnect/subscribe requires Job ID and optional sequence}}
        set id [dict get $request job_id]
        if {$action ne {reconnect}} {
            if {![dict exists $::GX::NativeJobs::viewerJobs $id] || [dict get $::GX::NativeJobs::viewerJobs $id window] ne $window || [dict get $::GX::NativeJobs::viewerJobs $id lifetime] ne $lifetime} {error {Native Job belongs to another Viewer instance; explicitly reconnect}}
        }
        switch -- $action {
            status {set receipt [nativeJobStatus $id $module]}
            cancel {set receipt [nativeJobCancel $id $module]}
            result {set receipt [nativeJobResult $id $module]}
            subscribe {
                nativeJobStatus $id $module
                set subscription [nativeJobSubscribe $id [list ::GX::_viewerNativeJobDeliver $window $lifetime $generation event] [datasetPublicationV2DictDefault $request after_sequence 0] $module]
                dict set ::GX::ViewerDevelopment::windows $window native_job_subscriptions [concat [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] native_job_subscriptions {}] [list $subscription]]
                set receipt [dict create job_id $id subscription_id $subscription]
            }
            reconnect {
                set receipt [nativeJobReconnect $id $module]
                viewerJobClientClaim $window $id 1
                dict set ::GX::ViewerDevelopment::windows $window native_job_session_token [interactiveDocumentSessionToken]
                dict set ::GX::NativeJobs::viewerJobs $id [dict create module $module window $window lifetime $lifetime generation $generation]
                set subscription [nativeJobSubscribe $id [list ::GX::_viewerNativeJobDeliver $window $lifetime $generation event] [datasetPublicationV2DictDefault $request after_sequence 0] $module]
                dict set ::GX::ViewerDevelopment::windows $window native_job_subscriptions [concat [datasetPublicationV2DictDefault [dict get $::GX::ViewerDevelopment::windows $window] native_job_subscriptions {}] [list $subscription]]
            }
            default {error {Unknown native Job lifecycle operation}}
        }
    }
    _viewerNativeJobDeliver $window $lifetime $generation $action $receipt
    return $receipt
}
