# SPDX-License-Identifier: GPL-3.0-or-later
# Script Bridge operation policy: viewer_gui_canvas_v1.script_bridge_policy.json
# Exact exclusions below are source evidence, not a runtime capability registry.
# Existing declarative Native2D component, opt-in reusable Canvas mode.
proc ::GX::_viewerGuiExtensionIds {window} {
    if {![dict exists $::GX::ViewerGui::instances $window]} {return {}}
    return [lsort -unique [dict values [datasetPublicationV2DictDefault [dict get $::GX::ViewerGui::instances $window design] extensions {}]]]
}
proc ::GX::_viewerGuiExtensionViewerCall {window hook args} {
    set result {}
    foreach id [_viewerGuiExtensionIds $window] {
        set contract [dict get [_nativeCanvasExtensionDefinition $id] contract]
        if {![dict exists $contract viewer_hooks $hook]} continue
        if {$hook ne {dispose} && ![viewerGuiDesignGuard $window]} {error {Viewer extension lifetime ended}}
        set instance [dict get $::GX::ViewerGui::instances $window]
        set incarnation {};if {$hook ne {dispose}} {set incarnation [winfo id $window]}
        set value [_datasetPrivateWithModule [dict get $instance module] [list uplevel #0 [list {*}[dict get $contract viewer_hooks $hook] $window {*}$args]]]
        _nativeCanvasExtensionDefinition $id
        if {$hook ne {dispose} && (![viewerGuiDesignGuard $window] || [winfo id $window] ne $incarnation)} {error {Viewer changed during extension callback}}
        if {$hook in {capture capture_visibility}} {set args [list $value];set result $value} elseif {$hook eq {action_enabled}} {
            if {$value ne {} && (![string is boolean -strict $value] || !$value)} {return 0}
            if {$value ne {}} {set result 1}
        } else {set result $value}
    }
    if {$result eq {} && $hook in {capture capture_visibility}} {return [lindex $args 0]}
    return $result
}
proc ::GX::_viewerGuiExtensionGrant {window api operations} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window]} {error {Extension command requires its actual captured compiled Viewer}}
    set record [dict get $::GX::ViewerDevelopment::windows $window]
    if {![dict exists $record validated_snapshot] || [_viewerDevelopmentSnapshot [dict get $record project]] ne [dict get $record validated_snapshot]} {error {Extension compiled source changed; reopen the current Viewer}}
    set grants [datasetPublicationV2DictDefault $record canvas_grants {}]
    foreach operation $operations {if {$operation ni [datasetPublicationV2DictDefault $grants $api {}]} {error "Extension lacks its captured $api/$operation grant"}}
}
proc ::GX::viewerGuiExtensionRequire {window api operations} {
    if {![viewerGuiDesignGuard $window]} {error {Viewer extension lifetime ended}}
    _viewerGuiExtensionGrant $window $api $operations
    return 1
}
proc ::GX::viewerGuiContext {window} {
    if {![viewerGuiDesignGuard $window]} {error {Viewer lifetime ended}}
    set row [dict get $::GX::ViewerGui::instances $window]
    set design [dict get $row design];set declared {}
    foreach key {requirements components extensions} {
        if {[dict exists $design $key]} {dict set declared $key [dict get $design $key]}
    }
    return [dict create schema gxtxt.viewer_context.v1 window_id [winfo id $window] \
        session_token [dict get $row token] mode [dict get $row mode] module_id [dict get $row module] \
        actor_module_id [dict get $row actor_module] provider_id [dict get $row provider] \
        context_epoch [dict get $row context_epoch] design $declared \
        canvas_slots [datasetPublicationV2DictDefault $row canvas_slots {}]]
}
proc ::GX::viewerGuiComponentContext {window component} {
    set owner [viewerGuiContext $window]
    set definition [viewerGuiDesignComponent $window $component]
    set mounted 0;set incarnation {};set visible 0
    if {[dict exists $::GX::ViewerGui::instances $window widgets $component]} {
        set widget [dict get $::GX::ViewerGui::instances $window widgets $component]
        if {[winfo exists $widget]} {
            set mounted 1;set incarnation [winfo id $widget]
            set visible [winfo ismapped $widget]
        }
    }
    return [dict create owner $owner definition $definition mounted $mounted incarnation $incarnation visible $visible]
}
proc ::GX::viewerGuiComponentHost {window component} {
    # Process-local trusted UI extension point over a declared live component.
    # This is not a transferable Script widget or a raw Viewer instance record.
    set context [viewerGuiComponentContext $window $component]
    if {![dict get $context mounted]} {error {Viewer component has no live UI host}}
    set widget [dict get $::GX::ViewerGui::instances $window widgets $component]
    return [dict merge $context [dict create widget $widget]]
}
proc ::GX::viewerGuiComponentSee {window component} {
    set host [viewerGuiComponentHost $window $component];set widget [dict get $host widget]
    set ancestor [winfo parent $widget]
    while {$ancestor ne {} && $ancestor ne $window && $ancestor ne {.}} {
        if {[winfo class $ancestor] eq {Canvas}} {
            foreach item [$ancestor find all] {
                if {[$ancestor type $item] ne {window}} continue
                set content [$ancestor itemcget $item -window]
                if {$content ne {} && ($widget eq $content || [string match $content.* $widget])} {
                    uiFieldScrollSee $ancestor $content $widget
                    return 1
                }
            }
        }
        set ancestor [winfo parent $ancestor]
    }
    return 0
}
proc ::GX::viewerGuiContextCommandCurrent {window component} {
    if {![viewerGuiDesignGuard $window]} {error {Viewer command lifetime ended}}
    viewerGuiDesignComponent $window $component
    _viewerGuiSemanticDispatchCheck $window $component
    return 1
}
proc ::GX::_viewerGuiCanvasExtensionFor {window component} {
    set design [dict get $::GX::ViewerGui::instances $window design]
    if {![dict exists $design extensions $component]} {error {Canvas component has no declared extension}}
    set id [dict get $design extensions $component]
    set contract [dict get [_nativeCanvasExtensionDefinition $id] contract]
    if {![dict exists $design requirements [dict get $contract api_id]] || [dict get $design requirements [dict get $contract api_id]] ne [dict get $contract api_version]} {error {Canvas extension public API/version differs from its actual design requirement}}
    return $id
}
proc ::GX::native2DCanvasExtensionAttach {handle window component} {
    _viewerGuiCanvasDefinition $window $component
    set row [_nativeCanvasRequire $handle]
    set instance [dict get $::GX::ViewerGui::instances $window]
    if {[dict get $row module] ne [dict get $instance module] || [dict get $row provider] ne [dict get $instance provider] || [dict get $row session] ne [dict get $instance token]} {error {Canvas extension has a foreign Viewer/Session owner}}
    if {[_viewerCanvasHandle $window $component] ne $handle} {error {Canvas extension is not the actual mounted field}}
    set id [_viewerGuiCanvasExtensionFor $window $component]
    if {[_nativeCanvasExtensionId $row] ne {} && [_nativeCanvasExtensionId $row] ne $id} {error {Canvas extension cannot be replaced}}
    set owner [dict create extension $id window $window window_id [winfo id $window] component $component handle $handle token [dict get $instance token] module_id [dict get $row module] provider_id [dict get $row provider]]
    dict set ::GX::NativeCanvas::instances $handle extension_id $id
    dict set ::GX::NativeCanvas::instances $handle extension_owner $owner
    return $owner
}
proc ::GX::_viewerGuiExtensionCommand {window component request} {
    _nativeCanvasFields $request {extension command arguments} {extension command arguments}
    set handle [_viewerCanvasHandle $window $component]
    set id [_viewerGuiCanvasExtensionFor $window $component]
    if {[dict get $request extension] ne $id || [_nativeCanvasExtensionId [_nativeCanvasRequire $handle]] ne $id} {error {Foreign Canvas extension request}}
    set contract [dict get [_nativeCanvasExtensionDefinition $id] contract]
    set name [dict get $request command]
    if {![dict exists $contract commands $name]} {error {Unknown declared typed extension command}}
    set command [dict get $contract commands $name]
    _viewerGuiExtensionGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    dict for {api operations} [dict get $command required_grants] {_viewerGuiExtensionGrant $window $api $operations}
    if {[dict get $command effect] in {submit publish}} {_viewerGuiExtensionGrant $window SCIENTIFIC_EXECUTION_API_v1 submit}
    if {[dict get $command effect] eq {publish}} {_viewerGuiExtensionGrant $window DATASET_FILE_PUBLICATION_API_v1 datasetFilePublicationPublish}
    set arguments [nativeWorkspaceShapeDecode [dict get $command arguments] [dict get $request arguments]]
    set instance [dict get $::GX::ViewerGui::instances $window];set incarnation [winfo id $window]
    set before [native2DCanvasContext $handle]
    set result [_datasetPrivateWithModule [dict get $instance module] [list uplevel #0 [list {*}[dict get $command command] $window $component $arguments]]]
    _nativeCanvasExtensionDefinition $id
    if {![viewerGuiDesignGuard $window] || [winfo id $window] ne $incarnation || [_viewerCanvasHandle $window $component] ne $handle} {error {Viewer owner changed during extension command}}
    _viewerGuiExtensionGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    # Output must satisfy the same statically registered typed owner contract.
    set typed [nativeWorkspaceEncode [dict get $command result] $result]
    _viewerGuiExtensionResultCheck $handle $typed
    _viewerCanvasCapture $window
    set current [native2DCanvasContext $handle]
    foreach key {handle canvas_id module_id provider_id document_id session} {if {[dict get $current $key] ne [dict get $before $key]} {error {Extension result belongs to a replaced Canvas owner}}}
    # An accepted same-owner edit legitimately advances receipt/sequence/native
    # generation. Bind the result to CORE's POST-effect context, never the old
    # context or a caller-supplied stamp. This is transient next-event metadata.
    set contextTyped [nativeWorkspaceEncode {record {schema text handle text canvas_id text module_id text provider_id text document_id text document_receipt {named document_receipt} session text sequence int canvas_generation int mounted bool}} $current]
    set tagged [nativeWorkspaceJsonDecode [_viewerWorkspaceTypedTransportJson $typed]]
    set receipt [list object [dict create extension [list text $id] command [list text $name] value $tagged context $contextTyped]]
    set snapshot [native2DCanvasCapture $handle]
    native2DCanvasContextCurrent $handle $current
    _viewerGuiExtensionGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    set stored [dict create component $component handle $handle window_id $incarnation token [dict get $instance token] context $current snapshot $snapshot source [dict get $::GX::ViewerDevelopment::windows $window validated_snapshot] extension $id value $receipt]
    dict set ::GX::ViewerDevelopment::windows $window canvas_extension_result $stored
    if {[catch {_viewerCanvasClientSnapshot $window $component} message options]} {
        if {[dict exists $::GX::ViewerDevelopment::windows $window canvas_extension_result] && [dict get $::GX::ViewerDevelopment::windows $window canvas_extension_result] eq $stored} {dict unset ::GX::ViewerDevelopment::windows $window canvas_extension_result}
        # A result/transport failure cannot roll back or relabel a callback's
        # already committed Canvas edit or original accepted Job. No retry.
        return -code error -errorcode {GX CANVAS EXTENSION_RESULT_TRANSPORT} "Extension callback returned but its typed receipt is unavailable; original accepted effects remain with their owners: $message"
    }
    return $result
}
proc ::GX::_viewerGuiExtensionResultCheck {handle typed {depth 0}} {
    if {$depth>64 || [llength $typed]!=2} {error {Invalid bounded typed extension result}}
    lassign $typed kind value
    switch -- $kind {
        resource {
            set reference [nativeWorkspaceDecode $typed];set context [native2DCanvasContext $handle]
            if {![dict exists $reference owner_generation] || [dict get $reference document_id] ne [dict get $context document_id] || [dict get $reference owner_generation] ne [dict get $context document_receipt generation]} {error {Extension result Resource has a foreign Canvas Document owner}}
            interactiveDocumentResourceInfo $reference
            native2DCanvasContextCurrent $handle $context
            dict for {key child} $value {if {[string first \u0000 $key]>=0} {error {Extension result field identity contains NUL}};_viewerGuiExtensionResultCheck $handle $child [expr {$depth+1}]}
        }
        object {dict for {key child} $value {if {[string first \u0000 $key]>=0} {error {Extension result field identity contains NUL}};_viewerGuiExtensionResultCheck $handle $child [expr {$depth+1}]}}
        array {foreach child $value {_viewerGuiExtensionResultCheck $handle $child [expr {$depth+1}]}}
        default {nativeWorkspaceJsonEncode $typed}
    }
    return 1
}
proc ::GX::viewerGuiCanvasOwnerCapture {window component {purpose publish}} {
    if {$purpose ni {publish flatten} || ![viewerGuiDesignGuard $window]} {error {Scientific Canvas Viewer lifetime or purpose is invalid}}
    _viewerGuiCanvasDefinition $window $component
    set handle [_viewerCanvasHandle $window $component];set row [_nativeCanvasRequire $handle]
    set id [_viewerGuiCanvasExtensionFor $window $component]
    if {[_nativeCanvasExtensionId $row] ne $id || ![dict exists $row extension_owner]} {error {Scientific Canvas extension is not attached}}
    set attached [dict get $row extension_owner]
    set instance [dict get $::GX::ViewerGui::instances $window]
    if {[dict get $attached window_id] ne [winfo id $window] || [dict get $attached token] ne [dict get $instance token]} {error {Scientific Canvas owner was replaced}}
    _viewerGuiExtensionGrant $window VIEWER_GUI_HOST_API_v1 canvas_command
    _viewerGuiExtensionGrant $window SCIENTIFIC_EXECUTION_API_v1 submit
    _viewerGuiExtensionGrant $window DATASET_FILE_PUBLICATION_API_v1 datasetFilePublicationPublish
    set compiled [dict get $::GX::ViewerDevelopment::windows $window]
    if {[dict exists $compiled validated_snapshot] && [_viewerDevelopmentSnapshot [dict get $compiled project]] ne [dict get $compiled validated_snapshot]} {error {Scientific Canvas compiled source changed}}
    if {[dict get $row pending] ne {} || [dict get [[dict get $row native] state scalar] gesture] || [dict exists $row roi_gesture]} {error {Finish the pending or provisional Canvas operation}}
    set contract [dict get [_nativeCanvasExtensionDefinition $id] contract]
    foreach key {scientific_provider projection_schema} {if {![dict exists $contract $key]} {error {Canvas extension does not declare scientific capture}}}
    set provider [scientificExecutionDescribe [dict get $contract scientific_provider]]
    if {[dict get $provider module_id] ne [dict get $contract module_id]} {error {Scientific provider differs from the registered extension owner}}
    set receipt [dict get $row receipt]
    set guard [dict create document_id [dict get $row document] generation [dict get $receipt generation] revision [dict get $receipt revision] sha256 [dict get $receipt sha256]]
    set owner [dict merge $attached [dict create schema gxtxt.viewer_canvas_owner.v1 sequence [dict get $row sequence] purpose $purpose guard $guard scientific_provider [dict get $contract scientific_provider] projection_schema [dict get $contract projection_schema] canvas_id [dict get [native2DCanvasCapture $handle] canvas_id]]]
    set veto [_nativeCanvasExtensionCall $handle owner_admit $owner]
    if {$veto ne {} && (![string is boolean -strict $veto] || !$veto)} {error {Registered scientific Canvas owner refused this state}}
    return $owner
}
proc ::GX::viewerGuiCanvasOwnerCurrent {owner held} {
    set current [viewerGuiCanvasOwnerCapture [dict get $owner window] [dict get $owner component] [dict get $owner purpose]]
    if {$current ne $owner} {error {Scientific Canvas publication owner changed}}
    native2DCanvasEditCurrent [dict get $owner handle] $held
    return $current
}
proc ::GX::viewerGuiCanvasProjection {owner held {frame auto}} {
    if {$frame ni {auto document}} {error {Unknown scientific Canvas frame}}
    viewerGuiCanvasOwnerCurrent $owner $held
    set contract [dict get [_nativeCanvasExtensionDefinition [dict get $owner extension]] contract]
    if {![dict exists $contract native_hooks capture_projection]} {error {Registered scientific projection capture is unavailable}}
    set result [_datasetPrivateWithModule [dict get $owner module_id] [list uplevel #0 [list {*}[dict get $contract native_hooks capture_projection] $owner $held $frame]]]
    _nativeCanvasFields $result {projection resources canonical_sources} {projection resources canonical_sources}
    if {![dict exists $result projection schema] || [dict get $result projection schema] ne [dict get $owner projection_schema]} {error {Projection schema differs from its captured registered owner}}
    viewerGuiCanvasOwnerCurrent $owner $held
    return $result
}
proc ::GX::_viewerGuiCanvasDefinition {window component} {
    if {![viewerGuiDesignGuard $window]} {error {Session changed; reopen the Canvas Viewer}}
    set definition [viewerGuiDesignComponent $window $component]
    if {[dict get $definition type] ne {native2d} || [datasetPublicationV2DictDefault [dict get $definition properties] source_kind {}] ne {canvas}} {error {Declare a Native2D source_kind canvas component in Interface Builder}}
    return $definition
}
proc ::GX::_viewerGuiCanvasInitialize {window {payload {}}} {
    set instance [dict get $::GX::ViewerGui::instances $window]
    foreach component [dict get $instance design components] {
        set properties [dict get $component properties]
        if {[dict get $component type] ne {native2d} || [datasetPublicationV2DictDefault $properties source_kind {}] ne {canvas}} continue
        set id [dict get $component id];set widget [dict get $instance widgets $id]
        if {[dict exists $::GX::ViewerGui::instances $window canvas_slots $id]} continue
        if {[dict get $instance mode] eq {demo} || [catch {interactiveDocumentSessionToken}]} {
            foreach child [winfo children $widget] {destroy $child}
            set notice [expr {[dict get $instance mode] eq {demo} ? {Canvas layout preview — use Builder Runtime Test to draw and edit.} : {Canvas — open a Session, then reopen this Viewer to draw and edit.}}]
            ttk::label $widget.empty -text $notice -wraplength 360
            pack $widget.empty -fill both -expand 1
            continue
        }
        set options [dict create width [datasetPublicationV2DictDefault $properties canvas_width 1024] height [datasetPublicationV2DictDefault $properties canvas_height 768] background [datasetPublicationV2DictDefault $properties canvas_background {1 1 1 1}]]
        if {[dict exists $instance design extensions $id]} {dict set options extension [_viewerGuiCanvasExtensionFor $window $id]}
        if {[dict exists $payload domain_state native2d_canvas $id document_id]} {dict set options document_id [dict get $payload domain_state native2d_canvas $id document_id]}
        set handle [native2DCanvasCreate [dict get $instance module] [dict get $instance provider] $options]
        try {
            foreach child [winfo children $widget] {destroy $child}
            native2DCanvasMount $handle $widget [dict create controls [datasetPublicationV2DictDefault $properties canvas_controls 1] callback [list ::GX::_viewerCanvasEvent $window $id]]
            dict set ::GX::ViewerGui::instances $window canvas_slots $id $handle
            if {[dict exists $options extension]} {native2DCanvasExtensionAttach $handle $window $id}
        } on error {message errorOptions} {native2DCanvasDispose $handle;return -options $errorOptions $message}
    }
    _viewerGuiExtensionViewerCall $window initialize $payload
}
proc ::GX::_viewerCanvasHandle {window component} {
    _viewerGuiCanvasDefinition $window $component
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots $component]} {error {Open a Session and Preview or reopen this Canvas component}}
    return [dict get $::GX::ViewerGui::instances $window canvas_slots $component]
}
proc ::GX::viewerGuiDesignCanvasDescribe {window component} {return [native2DCanvasDescribe [_viewerCanvasHandle $window $component]]}
proc ::GX::viewerGuiCanvasContext {window component} {
    _viewerGuiCanvasDefinition $window $component
    return [native2DCanvasContext [_viewerCanvasHandle $window $component]]
}
proc ::GX::viewerGuiDesignCanvasCommand {window component operation {request {}}} {
    _viewerGuiSemanticDispatchCheck $window $component
    set handle [_viewerCanvasHandle $window $component]
    if {$operation eq {extension}} {return [_viewerGuiExtensionCommand $window $component $request]}
    _nativeCanvasRequest $operation $request
    if {$operation eq {bind_source} && [dict exists $request source_selector]} {
        if {[dict exists $request dataset_id]} {error {Choose one declared source selector or canonical Dataset identity}}
        set selector [dict get $request source_selector]
        set definition [viewerGuiDesignComponent $window $selector]
        if {[dict get $definition type] ne {dataset_selector} || [datasetPublicationV2DictDefault [dict get $definition properties] content_kind {}] ne {raster}} {error {Canvas source selector must be a declared canonical raster Dataset selector}}
        dict set request dataset_id $::GX::ViewerGui::values($window,$selector)
        dict unset request source_selector
    }
    set result [native2DCanvasCommand $handle $operation $request]
    if {$operation eq {dispose}} {dict unset ::GX::ViewerGui::instances $window canvas_slots $component}
    _viewerCanvasCapture $window
    viewerGuiTraceEmit $window $component canvas_command [dict create status completed operation $operation]
    return $result
}
proc ::GX::_viewerCanvasEvent {window component event} {
    if {![dict exists $::GX::ViewerGui::instances $window]} return
    if {[dict get $::GX::ViewerGui::instances $window restoring]} return
    if {$event in {committed history_navigated document_changed}} {
        _viewerCanvasHistoryFlush $window
    } else {_viewerCanvasCapture $window}
    viewerGuiTraceEmit $window $component canvas_event [dict create status ready event $event]
    _viewerGuiExtensionViewerCall $window event $component $event
}
proc ::GX::_viewerCanvasHistoryProjection {bindings} {
    set result {}
    foreach component [lsort [dict keys $bindings]] {
        # Receipts remain complete in persisted captures. Their operational
        # revision changes during restore without changing the scientific state.
        dict set result $component [dict remove [dict get $bindings $component] document_receipt]
    }
    return $result
}
proc ::GX::_viewerCanvasHistoryFlush {window} {
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots] || ![dict exists $::GX::ScientificHistory::viewers $window]} return
    if {[dict get $::GX::ViewerGui::instances $window restoring] || ![scientificHistoryViewerEditable $window]} return
    set record [dict get $::GX::ScientificHistory::viewers $window record]
    # Returning to an older state must keep its redo branch until the ordinary
    # existing PrepareEdit review explicitly accepts a branch.
    if {[dict get $record cursor]!=[llength [dict get $record steps]]} return
    _viewerCanvasCapture $window
    set current [viewerGuiDesignContextGet $window]
    set accepted [datasetPublicationV2DictDefault [scientificHistoryViewerState $window] domain_state {}]
    set current [datasetPublicationV2DictDefault $current native2d_canvas {}]
    set accepted [datasetPublicationV2DictDefault $accepted native2d_canvas {}]
    if {[_viewerCanvasHistoryProjection $current] ne [_viewerCanvasHistoryProjection $accepted]} {
        scientificHistoryViewerRecordOperation $window {Update Canvas}
    }
}
proc ::GX::viewerGuiCanvasCapture {window} {
    if {![viewerGuiDesignGuard $window]} {error {Viewer lifetime ended}}
    _viewerCanvasCapture $window
    return [dict create status captured]
}
proc ::GX::_viewerCanvasCapture {window} {
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots]} return
    set states {}
    dict for {component handle} [dict get $::GX::ViewerGui::instances $window canvas_slots] {
        set row [_nativeCanvasRequire $handle]
        set history [dict get $row history]
        if {[dict exists $row gesture_history] && [dict get [[dict get $row native] state scalar] gesture]} {set history [dict get $row gesture_history]}
        dict set states $component [dict create document_id [dict get $row document] document_receipt [dict get $row receipt] snapshot [native2DCanvasCapture $handle] history $history]
    }
    set domain [viewerGuiDesignContextGet $window]
    dict set domain native2d_canvas $states
    set domain [_viewerGuiExtensionViewerCall $window capture $domain]
    viewerGuiDesignContextSet $window $domain
}
proc ::GX::_viewerCanvasRestoreCheck {window domain} {
    _viewerGuiExtensionViewerCall $window restore_check $domain
    dict for {component binding} [datasetPublicationV2DictDefault $domain native2d_canvas {}] {
        _viewerGuiCanvasDefinition $window $component
        _nativeCanvasFields $binding {document_id document_receipt snapshot history} {document_id document_receipt snapshot history}
        set current [interactiveDocumentMetadata [dict get $binding document_id]]
        set instance [dict get $::GX::ViewerGui::instances $window]
        if {[dict get $current module_id] ne [dict get $instance module] || [dict get $current provider_id] ne [dict get $instance provider] || [dict get $current format] ne {gxtxt.native2d.canvas_scene.v1}} {error {Saved Canvas has a foreign author or document format}}
        if {[dict get $current generation] ne [dict get $binding document_receipt generation]} {error {Saved Canvas owner was replaced}}
        if {$current ne [dict get $binding document_receipt]} {
            if {![dict exists $instance canvas_slots $component] || [dict get [_nativeCanvasRequire [dict get $instance canvas_slots $component]] receipt] ne $current} {error {Saved Canvas changed in another instance; reopen its current state}}
        }
        native2DCanvasSnapshotValidate [dict get $binding snapshot]
        scientificHistoryValidate framework.native2d.canvas [dict get $binding history]
    }
}
proc ::GX::_viewerCanvasRestore {window domain} {
    _viewerCanvasRestoreCheck $window $domain
    # Design mode keeps the admitted inert Document/snapshot in its domain.
    # It deliberately has no live Canvas; the runtime restore owns mounting.
    if {[dict get $::GX::ViewerGui::instances $window mode] eq {demo}} {
        _viewerGuiExtensionViewerCall $window restore $domain
        return
    }
    dict for {component binding} [datasetPublicationV2DictDefault $domain native2d_canvas {}] {
        set handle [_viewerCanvasHandle $window $component]
        set row [_nativeCanvasRequire $handle]
        if {[dict get $row document] ne [dict get $binding document_id]} {_nativeCanvasOpen $handle [dict get $binding document_id];set row [_nativeCanvasRequire $handle]}
        if {[dict get $row snapshot] ne [dict get $binding snapshot]} {native2DCanvasRestore $handle [dict get $binding snapshot]}
        if {[dict get $row snapshot] ne [dict get $binding snapshot] || [dict get $row history] ne [dict get $binding history]} {_nativeCanvasStore $handle [dict get $binding snapshot] [dict get $binding history]}
    }
    _viewerGuiExtensionViewerCall $window restore $domain
    _viewerCanvasCapture $window
}
proc ::GX::_viewerCanvasDispose {window} {
    set slots [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $::GX::ViewerGui::instances $window {}] canvas_slots {}]
    try {
        if {[catch {_viewerGuiExtensionViewerCall $window dispose} message]} {
            # Continuity/admission failures are not proof of module Job drain.
            # They must not skip the original local engine/scheduler cleanup.
            puts stderr "Viewer extension disposal could not be confirmed: $message"
        }
    } finally {
        dict for {component handle} $slots {
            if {[catch {native2DCanvasDispose $handle} message]} {puts stderr "Native Canvas disposal could not be confirmed: $message"}
            if {[dict exists $::GX::ViewerGui::instances $window canvas_slots $component] && [dict get $::GX::ViewerGui::instances $window canvas_slots $component] eq $handle} {dict unset ::GX::ViewerGui::instances $window canvas_slots $component}
        }
        if {[dict exists $::GX::ViewerGui::instances $window canvas_slots] && ![dict size [dict get $::GX::ViewerGui::instances $window canvas_slots]]} {dict unset ::GX::ViewerGui::instances $window canvas_slots}
    }
}
proc ::GX::_nativeCanvasHistoryEncode {record} {
    scientificHistoryValidate framework.native2d.canvas $record
    return [nativeWorkspaceHistoryEncode $record [list ::GX::nativeWorkspaceEncode {named canvas_snapshot}]]
}
proc ::GX::_viewerCanvasEncode {value} {
    return [nativeWorkspaceEncode {map {record {document_id text document_receipt {named document_receipt} snapshot {named canvas_snapshot} history {codec ::GX::_nativeCanvasHistoryEncode}}}} $value]
}
proc ::GX::_viewerCanvasPublicState {handle} {
    set description [native2DCanvasDescribe $handle]
    set result [dict remove $description api_id canvas_version display_precision rendering scheduling]
    dict set result roi_pages [_nativeCanvasRoiPublic $handle]
    dict set result layer_count [llength [dict get $description layers]]
    dict set result object_count [llength [dict get $description objects]]
    # Diagnostics are a bounded metadata page, never a second object authority.
    dict set result layers [lrange [dict get $description layers] 0 63]
    dict set result objects [lrange [dict get $description objects] 0 127]
    dict set result selection [lrange [dict get $description selection] 0 127]
    dict set result diagnostics_complete [expr {[dict get $result layer_count]<=64 && [dict get $result object_count]<=128 && [llength [dict get $description selection]]<=128}]
    return $result
}
proc ::GX::_viewerCanvasClientSnapshot {window {component {}}} {
    set values {}
    if {$component ne {} && [dict exists $::GX::ViewerGui::instances $window canvas_slots $component]} {
        set handle [dict get $::GX::ViewerGui::instances $window canvas_slots $component]
        if {[catch {set row [_viewerCanvasPublicState $handle]} message]} {
            dict set values $component [list object [dict create status [list text unavailable] diagnostic [list text [string range $message 0 2047]]]]
        } else {
            while {1} {
                dict set values $component [nativeWorkspaceEncode {named canvas_public_state} $row]
                set result [nativeWorkspaceJsonEncode [list object [dict create instances [list object $values]]]]
                if {[string bytelength $result]<=49152} {return [_viewerCanvasClientExtensionResult $window $component $result]}
                # A single ROI page contains nested records. Reduce that payload
                # before outer diagnostics, retaining the selected image and
                # page identity needed to request its next offset.
                if {[llength [dict get $row roi_pages]]} {
                    set page [lindex [dict get $row roi_pages] 0]
                    set records [dict get $page records]
                    if {[llength $records]>1} {
                        dict set page records [lrange $records 0 [expr {[llength $records]/2-1}]]
                        dict set page next_offset [expr {[dict get $page offset]+[llength [dict get $page records]]}]
                        dict set page complete 0
                        dict set row roi_pages [list $page]
                        dict set row diagnostics_complete 0
                        continue
                    }
                }
                set largest {};set count 0
                foreach field {layers objects selection} {
                    if {$field eq {selection} && [llength [dict get $row roi_pages]]} continue
                    set length [llength [dict get $row $field]]
                    if {$length>$count} {set count $length;set largest $field}
                }
                if {$count==0} {
                    dict set values $component [list object [dict create status [list text unavailable] diagnostic [list text {Canvas scalar diagnostics exceed the client receipt bound}]]]
                    break
                }
                dict set row $largest [lrange [dict get $row $largest] 0 [expr {$count/2-1}]]
                dict set row diagnostics_complete 0
            }
        }
    }
    set result [nativeWorkspaceJsonEncode [list object [dict create instances [list object $values]]]]
    return [_viewerCanvasClientExtensionResult $window $component $result]
}
proc ::GX::_viewerCanvasClientExtensionResult {window component json} {
    if {![dict exists $::GX::ViewerDevelopment::windows $window canvas_extension_result]} {return $json}
    set record [dict get $::GX::ViewerDevelopment::windows $window canvas_extension_result]
    if {[dict get $record component] ne $component} {return $json}
    # A stale result conveys no current Canvas/Source truth. Omit only this
    # additive transient receipt; the original diagnostics stay byte-for-byte.
    if {[catch {
        if {![viewerGuiDesignGuard $window] || [winfo id $window] ne [dict get $record window_id] || [dict get $::GX::ViewerGui::instances $window token] ne [dict get $record token] || [_viewerCanvasHandle $window $component] ne [dict get $record handle]} {error {Extension result lifetime ended}}
        set handle [dict get $record handle]
        native2DCanvasContextCurrent $handle [dict get $record context]
        if {[dict remove [native2DCanvasCapture $handle] view_state tool] ne [dict remove [dict get $record snapshot] view_state tool]} {error {Extension result selection/content changed}}
        if {[_viewerDevelopmentSnapshot [dict get $::GX::ViewerDevelopment::windows $window project]] ne [dict get $record source]} {error {Extension result compiled source changed}}
        if {[_viewerGuiCanvasExtensionFor $window $component] ne [dict get $record extension]} {error {Extension result callback owner changed}}
        _viewerGuiExtensionResultCheck $handle [_viewerWorkspaceSdkValue [nativeWorkspaceDecode [dict get [lindex [dict get $record value] 1] value]]]
    }]} {return $json}
    set typed [nativeWorkspaceJsonDecode $json]
    lset typed 1 [dict merge [lindex $typed 1] [dict create extension_result [dict get $record value]]]
    set result [nativeWorkspaceJsonEncode $typed]
    if {[string bytelength $result]>49152} {error {Canvas diagnostics plus exact typed extension result exceed the existing48KiB receipt bound}}
    return $result
}
::GX::nativeWorkspaceShapeRegister canvas_public_state {record {
    document_id text canvas_id text generation text revision int tool text active_layer text selection {array text} extent {array int} background {array real}
    layers {array {record {logical_id text name text properties {record {visible bool selectable bool locked bool order int opacity real}} blend text}}}
    objects {array {record {logical_id text kind text layer text}}}
    roi_pages {array {named canvas_roi_page}}
    history_cursor int history_steps int pending bool layer_count int object_count int diagnostics_complete bool
}}
::GX::viewerWorkspaceCodecRegister domains native2d_canvas ::GX::_viewerCanvasEncode
