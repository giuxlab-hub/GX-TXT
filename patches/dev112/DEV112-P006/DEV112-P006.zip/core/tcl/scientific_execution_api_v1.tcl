# SPDX-License-Identifier: GPL-3.0-or-later
# A typed provider facade over the existing durable Script Job authority.
namespace eval ::GX::ScientificExecution {variable providers {};variable prepared {};variable serial 0}
proc ::GX::scientificExecutionCoreCapabilities {} {
    # Inspect the actual approved public services on this installation. An
    # optional analysis checkbox is distinct from public service activation.
    set numeric [dict create available 0 reason {}]
    if {[catch {
        modulePublicApiActivate math.numeric NUMERIC_API_v1
        set numeric [dict merge [::GX::NumericAPIv1::apiInfo] [dict create available 1 operations [::GX::NumericAPIv1::listOperations] foundation_operations [::GX::NumericAPIv1::listFoundationOperations]]]
    } message]} {dict set numeric reason $message}
    set statistics [::GX::StatisticsV1::apiInfo]
    return [dict create numeric $numeric statistics $statistics scientific_execution [scientificExecutionApiInfo] script_job [scriptJobApiInfo] parallel_execution [parallelExecutionApiInfo] scope {Installed public API/catalog and actual declared runtime availability; not execution acceptance}]
}
proc ::GX::scientificExecutionImageRuntimeInfo {} {
    # Fixed original generic runtime closure; no application/provider/worker ID.
    set sources {}
    foreach name {gxtxt_scientific_image_runtime_v1.py viewer_canvas_request_v1.py gxtxt_resource_manager.py scientific_image_materializer_v1.py gxtxt_scientific_execution.py} {
        set path [file join $::GX::scriptDir core python $name];dict set sources $path [sha256File $path]
    }
    set source [file join $::GX::scriptDir core tcl scientific_execution_api_v1.tcl];dict set sources $source [sha256File $source]
    return [dict create api_id SCIENTIFIC_IMAGE_AUXILIARY_RUNTIME_v1 api_version 1 python_directory [file join $::GX::scriptDir core python] python [runtimeToolRequired python] source_files $sources provider_runtime_files [_scientificExecutionImageRuntimeFiles]]
}
proc ::GX::_scientificExecutionImageRuntimeFiles {} {
    set files {core/python/scientific_image_materializer_v1.py}
    # Installation closure, never whichever tool happened to be selected on
    # first registration. Explicit administrator overrides remain unchanged.
    set managed core/runtime/imagemagick_q16hdri_debian13_amd64
    set loader [file join $::GX::scriptDir $managed bin magick]
    set manifest [file join $::GX::scriptDir $managed manifest.json]
    set present 0
    foreach path [list $loader $manifest] {
        if {[catch {file lstat $path info} reason context]} {
            if {[lrange [dict get $context -errorcode] 0 1] ne {POSIX ENOENT}} {return -options $context $reason}
        } else {
            if {$info(type) ne {file}} {error {Managed image runtime anchors must be ordinary files}}
            incr present
        }
    }
    set installed 0
    if {[catch {file lstat [file join $::GX::scriptDir $managed] directory} reason context]} {
        if {[lrange [dict get $context -errorcode] 0 1] ne {POSIX ENOENT}} {return -options $context $reason}
    } else {
        if {$directory(type) ne {directory}} {error {Managed image runtime installation must be an ordinary directory}}
        set installed 1
    }
    if {$present==1 || ($installed && $present!=2)} {error {Managed image runtime installation is incomplete}}
    if {$present==2} {lappend files $managed/bin/magick $managed/manifest.json}
    return $files
}
proc ::GX::scientificExecutionImagePreparationIdentity {provider recipe sources} {
    # Closed correlation metadata from original registered/source/runtime
    # owners. No request, command, private registry row or admission escapes.
    set descriptor [_scientificExecutionImageProvider $provider]
    set session [_interactiveDocumentRequireSession];set token [interactiveDocumentSessionToken]
    if {![llength $sources]} {error {Image preparation requires canonical sources}}
    set runtimeFiles {}
    foreach relative [dict get $descriptor runtime_files] {dict set runtimeFiles $relative [sha256File [scriptModuleSafeRelative $::GX::scriptDir $relative]]}
    set factsTool [_scientificExecutionImageFactsTool $recipe]
    if {$factsTool ne {}} {dict for {relative hash} [dict get $factsTool runtime_files] {dict set runtimeFiles $relative $hash}}
    set datasets {};set seen {};set metadata {}
    foreach source $sources {
        _scientificExecutionImageFields $source {dataset_id source_sha256 source_revision}
        set current [_quantitativeRasterSourceIdentity [dict get $source dataset_id]]
        foreach key {dataset_id source_sha256 source_revision} {if {[dict get $source $key] ne [dict get $current $key]} {error {Canonical preparation source changed}}}
        set id [dict get $current dataset_id]
        if {[dict exists $seen $id]} {
            if {[dict get $seen $id] ne $current} {error {Conflicting canonical preparation identities}}
            continue
        }
        dict set seen $id $current
        lappend datasets [dict create dataset_id $id source_sha256 [dict get $current source_sha256] source_revision [dict get $current source_revision] source_stamp [dict get $current source_stamp]]
        dict set metadata $id [apiCatalogNative digest [datasetMetadataRead $session $id]]
    }
    set guards [dict create session_fingerprint [_scientificExecutionRemoteSessionFingerprint] session_origin [sessionOriginRead $session] datasets $datasets]
    set worker [scriptModuleSafeRelative $::GX::scriptDir [dict get $descriptor worker]]
    set adapter [file join $::GX::scriptDir core python gxtxt_scientific_execution.py]
    if {[interactiveDocumentSessionToken] ne $token || [_interactiveDocumentRequireSession] ne $session} {error {Image preparation Session changed}}
    _scientificExecutionImageProvider $provider
    return [dict create provider_version [dict get $descriptor version] worker_sha256 [sha256File $worker] adapter_sha256 [sha256File $adapter] runtime_files $runtimeFiles source_guards $guards metadata_stamps $metadata]
}
proc ::GX::scientificExecutionApiInfo {} {
    return [dict create api_id SCIENTIFIC_EXECUTION_API_v1 api_version 1 image_auxiliary_runtime_info ::GX::scientificExecutionImageRuntimeInfo image_job_facts ::GX::scientificExecutionImageJobFacts authority SCRIPT_JOB_API_v1 backend {local remote} operations {core_capabilities node_list node_inspect destination discover describe prepare discard submit status log cancel outputs read_output read_records freeze_resource import_results reconnect circuit_inspect circuit_prepare circuit_sweep_prepare circuit_sweep_submit import_table import_table_cancel} circuit_format gxtxt.native2d.diagram.v1 circuit_provider core.ngspice.circuit security_boundary cooperating_trusted_provider_not_OS_sandbox persistence existing_Job_journal host_operation_contracts [_scientificExecutionRemoteHostContracts]]
}
proc ::GX::scientificExecutionRegister {id descriptor} {
    variable ::GX::ScientificExecution::providers
    if {![regexp {^[a-zA-Z][a-zA-Z0-9_.-]*$} $id]} {error {Invalid scientific provider identity}}
    foreach key {module_id version worker tools parameters} {if {![dict exists $descriptor $key]} {error "Provider requires $key"}}
    set relative [dict get $descriptor worker]
    if {[file pathtype $relative] ne {relative}||{..} in [file split $relative]} {error {Trusted worker must be framework-relative}}
    set worker [file normalize [file join $::GX::scriptDir $relative]]
    if {![string match "$::GX::scriptDir/*" $worker]||![file isfile $worker]||[file type $worker] eq {link}} {error {Trusted worker is unavailable}}
    if {![regexp {^[0-9]+\.[0-9]+\.[0-9]+$} [dict get $descriptor version]]} {error {Invalid scientific provider version}}
    dict for {name field} [dict get $descriptor parameters] {
        if {![regexp {^[A-Za-z_][A-Za-z0-9_]*$} $name]||![dict exists $field type]||[dict get $field type] ni {integer number boolean string choice}} {error {Invalid typed provider parameter}}
    }
    foreach reserved {image_provider_binding image_callback_stamp} {
        if {[dict exists $descriptor $reserved]} {error {Provider registration cannot supply CORE-issued ownership records}}
    }
    if {[dict exists $descriptor input_profile]} {
        dict set descriptor image_provider_binding [_scientificExecutionImageRegistration $id $descriptor]
        set callbacks [list [dict get $descriptor image_source_info]]
        foreach key {image_canvas_recipe image_canvas_result image_publish} {
            if {[dict exists $descriptor $key]} {lappend callbacks [dict get $descriptor $key]}
        }
        set prefix plugins/modules/[dict get $descriptor module_id]/
        set runtimeFiles {}
        foreach relative [datasetPublicationV2DictDefault $descriptor runtime_files {}] {
            if {[string first $prefix $relative]==0} {lappend runtimeFiles [string range $relative [string length $prefix] end]}
        }
        dict set descriptor image_callback_stamp [modulePublicApiCallbacksCapture [dict get $descriptor module_id] [dict get $descriptor module_api_id] $callbacks $runtimeFiles]
    }
    if {[dict exists $providers $id] && ([dict exists $providers $id image_provider_binding] || [dict exists $descriptor image_provider_binding]) && [dict get $providers $id] ne $descriptor} {error {Scientific provider registration changed; restart its owning Host}}
    dict set providers $id $descriptor
    return $id
}
proc ::GX::_scientificExecutionImageRegistration {id descriptor} {
    # Reuse the actual public-API module activation capability. A provider name
    # or a caller-supplied module string is not registration authority.
    if {[dict get $descriptor input_profile] ne {image_resource_files_v1}} {error {Unknown scientific materialization profile}}
    foreach key {module_api_id image_source_info} {if {![dict exists $descriptor $key]} {error "Image provider requires $key"}}
    set module [dict get $descriptor module_id]
    set context [datasetPrivateMetadataContext]
    if {[dict get $context module_id] ne $module || ![regexp {^[A-Za-z][A-Za-z0-9_.-]*$} $module]} {error {Image provider requires its actual module activation context}}
    set api [dict get $descriptor module_api_id]
    if {$api ni [modulePublicApiIds $module] || ![info exists ::GX::modulePublicApiActivated($module,$api)]} {error {Image provider API is not being activated by its module}}
    set moduleRelative plugins/modules/$module/module.ini
    set modulePath [scriptModuleSafeRelative $::GX::scriptDir $moduleRelative]
    if {[file normalize [moduleField $module descriptor {}]] ne $modulePath || [file type $modulePath] ne {file}} {error {Image provider descriptor is outside its installed module}}
    set relative [dict get $descriptor worker]
    set worker [scriptModuleSafeRelative $::GX::scriptDir $relative]
    set root [file dirname $modulePath]
    if {![string match "$root/*" $worker] || [file type $worker] ne {file}} {error {Image worker is outside its registered module}}
    set ini [parseIni $modulePath]
    if {[descriptorValue $ini meta id {}] ne $module} {error {Image provider descriptor has another module identity}}
    set entryRelative plugins/modules/$module/[descriptorValue $ini public_api.$api entrypoint {}]
    set entry [scriptModuleSafeRelative $::GX::scriptDir $entryRelative]
    if {![string match "$root/*" $entry] || [file type $entry] ne {file}} {error {Image provider API entrypoint is outside its module}}
    set callback [dict get $descriptor image_source_info]
    if {[llength $callback]!=1 || ![regexp {^::[A-Za-z][A-Za-z0-9_]*(?:::[A-Za-z][A-Za-z0-9_]*)+$} $callback] || [llength [info commands $callback]]!=1} {error {Image metadata requires one registered literal host command}}
    set canvasProfile [datasetPublicationV2DictDefault $descriptor canvas_source_profile {}]
    if {$canvasProfile ne {}} {
        if {$canvasProfile ne {native_canvas_document_v1} || ![dict exists $descriptor canvas_parameters] || ![dict exists $descriptor image_canvas_recipe]} {error {Canvas image profile requires its typed parameter schema and recipe callback}}
        set callback [dict get $descriptor image_canvas_recipe]
        if {[llength $callback]!=1 || ![regexp {^::[A-Za-z][A-Za-z0-9_]*(?:::[A-Za-z][A-Za-z0-9_]*)+$} $callback] || [llength [info commands $callback]]!=1} {error {Canvas recipe requires one registered literal host command}}
        # Validate the same typed parameter definitions used by the existing
        # provider API. The application supplies values/defaults, not CORE.
        dict for {name field} [dict get $descriptor canvas_parameters] {
            if {![regexp {^[A-Za-z_][A-Za-z0-9_]*$} $name] || ![dict exists $field type] || [dict get $field type] ni {integer number boolean string choice}} {error {Invalid typed Canvas provider parameter}}
        }
    } elseif {[dict exists $descriptor canvas_parameters] || [dict exists $descriptor image_canvas_recipe]} {error {Canvas callbacks require an explicit registered source profile}}
    if {[dict exists $descriptor image_canvas_result]} {
        set callback [dict get $descriptor image_canvas_result]
        if {$canvasProfile eq {} || [llength $callback]!=1 || ![regexp {^::[A-Za-z][A-Za-z0-9_]*(?:::[A-Za-z][A-Za-z0-9_]*)+$} $callback] || [llength [info commands $callback]]!=1} {error {Canvas result validation requires its registered literal host command}}
    }
    if {[dict exists $descriptor image_publish]} {
        set callback [dict get $descriptor image_publish]
        if {[llength $callback]!=1 || ![regexp {^::[A-Za-z][A-Za-z0-9_]*(?:::[A-Za-z][A-Za-z0-9_]*)+$} $callback] || [llength [info commands $callback]]!=1} {error {Image publication requires one registered literal host command}}
    }
    return [dict create schema gxtxt.scientific_provider_binding.v1 provider_id $id provider_version [dict get $descriptor version] \
        module_id $module module_api_id $api module_descriptor_relative $moduleRelative module_descriptor_sha256 [sha256File $modulePath] \
        api_entrypoint_relative $entryRelative api_entrypoint_sha256 [sha256File $entry] \
        worker_relative $relative worker_sha256 [sha256File $worker] input_profile image_resource_files_v1 canvas_source_profile $canvasProfile]
}
proc ::GX::_scientificExecutionImageProvider {provider {request {}}} {
    variable ::GX::ScientificExecution::providers
    if {![dict exists $providers $provider image_provider_binding]} {error {Scientific image provider has no module-issued registration}}
    set descriptor [dict get $providers $provider]
    set binding [dict get $descriptor image_provider_binding]
    set module [dict get $binding module_id];set api [dict get $binding module_api_id]
    if {![info exists ::GX::modulePublicApiActivated($module,$api)] ||
        $::GX::modulePublicApiActivated($module,$api) ne [scriptModuleSafeRelative $::GX::scriptDir [dict get $binding api_entrypoint_relative]]} {error {Scientific image provider activation has not completed successfully}}
    modulePublicApiCallbacksCurrent [dict get $descriptor image_callback_stamp]
    if {[dict get $binding provider_id] ne $provider || [dict get $binding provider_version] ne [dict get $descriptor version] ||
        [dict get $binding module_id] ne [dict get $descriptor module_id] || [dict get $binding worker_relative] ne [dict get $descriptor worker] ||
        [dict get $binding input_profile] ne {image_resource_files_v1} ||
        [sha256File [scriptModuleSafeRelative $::GX::scriptDir [dict get $binding module_descriptor_relative]]] ne [dict get $binding module_descriptor_sha256] ||
        [sha256File [scriptModuleSafeRelative $::GX::scriptDir [dict get $binding api_entrypoint_relative]]] ne [dict get $binding api_entrypoint_sha256] ||
        [sha256File [scriptModuleSafeRelative $::GX::scriptDir [dict get $binding worker_relative]]] ne [dict get $binding worker_sha256]} {error {Registered scientific image owner changed}}
    if {$request ne {} && (![dict exists $request image_provider_binding] || [dict get $request image_provider_binding] ne $binding ||
        [dict get $request provider_id] ne $provider || [dict get $request provider_version] ne [dict get $binding provider_version] ||
        [dict get $request worker_sha256] ne [dict get $binding worker_sha256] ||
        [dict get $request worker] ne [scriptModuleSafeRelative $::GX::scriptDir [dict get $binding worker_relative]])} {error {Scientific request has another registered provider binding}}
    return $descriptor
}
proc ::GX::_scientificExecutionImageProviderActivate {request} {
    # A cold preparer resolves only the exact module/API frozen by registration.
    # Loading is still owned by the ordinary public module lifecycle service.
    if {![dict exists $request image_provider_binding]} {error {Scientific image preparation lacks its module-issued binding}}
    set binding [dict get $request image_provider_binding]
    _scientificExecutionImageFields $binding {schema provider_id provider_version module_id module_api_id module_descriptor_relative module_descriptor_sha256 api_entrypoint_relative api_entrypoint_sha256 worker_relative worker_sha256 input_profile canvas_source_profile}
    if {[dict get $binding schema] ne {gxtxt.scientific_provider_binding.v1} ||
        [dict get $binding provider_id] ne [dict get $request provider_id] ||
        [dict get $binding provider_version] ne [dict get $request provider_version] ||
        [dict get $binding input_profile] ne {image_resource_files_v1} ||
        [dict get $request image_profile] ne [dict get $binding input_profile] ||
        [dict get $binding canvas_source_profile] ni {{} native_canvas_document_v1}} {error {Invalid scientific provider registration binding}}
    set module [dict get $binding module_id];set api [dict get $binding module_api_id]
    if {![regexp {^[A-Za-z][A-Za-z0-9_.-]*$} $module] || ![regexp {^[A-Za-z][A-Za-z0-9_]*$} $api]} {error {Invalid scientific provider module/API identity}}
    set relative plugins/modules/$module/module.ini
    set descriptor [scriptModuleSafeRelative $::GX::scriptDir $relative]
    if {[dict get $binding module_descriptor_relative] ne $relative ||
        [file normalize [moduleField $module descriptor {}]] ne $descriptor ||
        [sha256File $descriptor] ne [dict get $binding module_descriptor_sha256] || $api ni [modulePublicApiIds $module]} {error {Scientific provider descriptor changed before activation}}
    set ini [parseIni $descriptor]
    if {[descriptorValue $ini meta id {}] ne $module} {error {Scientific provider descriptor has another module identity}}
    set entryRelative plugins/modules/$module/[descriptorValue $ini public_api.$api entrypoint {}]
    set entry [scriptModuleSafeRelative $::GX::scriptDir $entryRelative]
    if {![string match "[file dirname $descriptor]/*" $entry] ||
        [dict get $binding api_entrypoint_relative] ne $entryRelative ||
        [sha256File $entry] ne [dict get $binding api_entrypoint_sha256]} {error {Scientific provider API source changed before activation}}
    set worker [scriptModuleSafeRelative $::GX::scriptDir [dict get $binding worker_relative]]
    if {![string match "[file dirname $descriptor]/*" $worker] || [file type $worker] ne {file} ||
        $worker ne [dict get $request worker] || [dict get $request worker_sha256] ne [dict get $binding worker_sha256] ||
        [sha256File $worker] ne [dict get $binding worker_sha256]} {error {Scientific provider worker changed before activation}}
    if {[dict size [dict get $request runtime_files]]>256} {error {Scientific provider runtime source closure exceeds its bound}}
    dict for {relative expected} [dict get $request runtime_files] {
        set path [scriptModuleSafeRelative $::GX::scriptDir $relative]
        if {[file type $path] ne {file} || ![regexp {^[0-9a-f]{64}$} $expected] || [sha256File $path] ne $expected} {error {Scientific provider runtime source changed before activation}}
    }
    modulePublicApiActivate $module $api
    return [_scientificExecutionImageProvider [dict get $request provider_id] $request]
}
proc ::GX::scientificExecutionDiscover {} {
    variable ::GX::ScientificExecution::providers
    return [lsort [dict keys $providers]]
}
proc ::GX::scientificExecutionDescribe {provider} {
    variable ::GX::ScientificExecution::providers
    if {![dict exists $providers $provider]} {error {Unknown registered scientific provider}}
    set description [dict get $providers $provider]
    dict unset description worker
    if {[dict exists $description import_command]} {dict unset description import_command}
    foreach private {image_source_info image_canvas_recipe image_canvas_result image_publish image_provider_binding image_callback_stamp} {if {[dict exists $description $private]} {dict unset description $private}}
    if {[dict exists $description native_artifact]} {dict set description native_artifact [dict remove [dict get $description native_artifact] module_root artifact]}
    dict set description provider_id $provider
    dict set description backend local
    return $description
}
proc ::GX::_scientificExecutionParameters {schema parameters} {
    dict for {name value} $parameters {if {![dict exists $schema $name]} {error "Unknown scientific parameter '$name'"}}
    set result {}
    dict for {name field} $schema {
        if {[dict exists $parameters $name]} {set value [dict get $parameters $name]} elseif {[dict exists $field default]} {set value [dict get $field default]} elseif {[dict exists $field required]&&[dict get $field required]} {error "Missing scientific parameter '$name'"} else continue
        set type [dict get $field type]
        switch $type {
            integer {if {![string is entier -strict $value]} {error "Parameter '$name' requires an integer"}}
            number {if {![string is double -strict $value]||[catch {expr {abs(double($value))<Inf}} finite]||!$finite} {error "Parameter '$name' requires a finite number"}}
            boolean {if {![string is boolean -strict $value]} {error "Parameter '$name' requires a boolean"};set value [expr {!!$value}]}
            choice {if {![dict exists $field values]||$value ni [dict get $field values]} {error "Parameter '$name' has an invalid choice"}}
            string {if {[string length $value]>8192||[string first \x00 $value]>=0} {error {String parameter exceeds bounds}}}
        }
        if {$type in {integer number}} {foreach {bound relation} {min < max >} {if {[dict exists $field $bound]&&[expr "$value $relation [dict get $field $bound]"]} {error "Parameter '$name' violates $bound"}}}
        dict set result $name $value
    }
    return $result
}
proc ::GX::scientificExecutionPrepare {provider parameters {resources {}} {options {}}} {
    tailcall ::GX::_scientificExecutionPrepare $provider $parameters $resources $options {}
}
proc ::GX::_scientificExecutionPrepare {provider parameters resources options imageCanvasBinding} {
    variable ::GX::ScientificExecution::providers;variable ::GX::ScientificExecution::prepared;variable ::GX::ScientificExecution::serial
    set imageSourceProfile {}
    if {$imageCanvasBinding ne {}} {
        _scientificExecutionImageFields $imageCanvasBinding {owner held capture}
        _scientificExecutionImageCanvasCurrent [dict get $imageCanvasBinding owner] [dict get $imageCanvasBinding held]
        _scientificExecutionImageProvider $provider
        if {$provider ne [dict get $imageCanvasBinding owner scientific_provider]} {error {Scientific Canvas requires its registered owner provider}}
        set imageSourceProfile native_canvas_document_v1
    }
    set destination [datasetPublicationV2DictDefault $options node_id [scientificExecutionDestination]]
    # This registered file-backed image profile has no admitted remote input
    # materializer/target-budget protocol. Refuse BEFORE auto inspection/RPC;
    # a local policy snapshot never attests a remote execution budget.
    if {[dict exists $providers $provider input_profile] && [dict get $providers $provider input_profile] eq {image_resource_files_v1} && $destination ne {local}} {
        return -code error -errorcode {GXTXT SCIENTIFIC IMAGE_REMOTE_UNAVAILABLE} {Scientific image processing currently requires the explicit local destination; remote image materializer and target-budget admission are unavailable}
    }
    if {$destination eq "auto"} {set destination local;dict for {node descriptor} [scientificExecutionNodes] {if {![dict get $descriptor enabled] || [catch {set capabilities [scientificExecutionNodeInspect $node]}]} continue;foreach available [dict get $capabilities providers] {if {[dict get $available provider_id] eq $provider && [dict get $available available]} {set destination $node;break}};if {$destination ne "local"} break}}
    if {$destination ne "local"} {return [scientificExecutionRemotePrepare $destination $provider $parameters $resources $options]}
    set options [dict remove $options node_id remote_session_id]
    scientificExecutionDescribe $provider
    set d [dict get $providers $provider]
    if {[dict exists $d native_artifact]} {
        set options [_nativeJobPrepareOptions $options]
        if {$resources ne {} && (![dict exists $d native_artifact abi buffer_descriptor_version] || [dict get $d native_artifact abi buffer_descriptor_version] ne {2})} {error {Installed native task ABI does not admit typed buffer descriptor v2}}
        set nativeDescriptors [_nativeJobInputDescriptors $resources]
    }
    set session [_interactiveDocumentRequireSession]
    dict for {old entry} $prepared {if {[dict get $entry session_token] ne [interactiveDocumentSessionToken]} {dict unset prepared $old}}
    if {[dict size $prepared]>=16} {error {At most16 scientific preparations may be retained; submit or discard one}}
    set imageProfile [expr {[datasetPublicationV2DictDefault $d input_profile {}] eq {image_resource_files_v1}}]
    if {$imageProfile} {set d [_scientificExecutionImageProvider $provider]}
    set allowedOptions {document_id expected_revision expected_generation expected_sha256 dataset_sources}
    if {$imageProfile} {lappend allowedOptions image_sources image_recipe}
    foreach key [dict keys $options] {if {$key ni $allowedOptions} {error "Unknown scientific execution option '$key'"}}
    set sourceIdentities [dict create session_origin [sessionOriginRead $session]];set inputs {};set total 0
    if {!$imageProfile} {
    dict for {alias reference} $resources {
        if {![regexp {^[A-Za-z_][A-Za-z0-9_]*$} $alias]} {error {Invalid input resource alias}}
        interactiveDocumentResourceInfo $reference
        set size [dict get $reference size_bytes];incr total $size
        if {$total>8388608} {error {Prepared resource snapshot exceeds 8 MiB; use a bounded provider materializer}}
        set bytes {};for {set offset 0} {$offset<$size} {incr offset 1048576} {append bytes [interactiveDocumentResourceReadChunk $reference $offset [expr {min(1048576,$size-$offset)}]]}
        dict set inputs $alias [binary encode base64 -maxlen 0 $bytes]
        dict set sourceIdentities $alias [dict remove $reference metadata]
    }
    } else {
        set imageSources [_scientificExecutionImageSourceRecords $resources $options imageMetadata $imageSourceProfile $provider]
        dict for {alias reference} $resources {dict set sourceIdentities $alias [dict remove $reference metadata]}
        dict for {alias source} [dict get $options image_sources] {
            dict set sourceIdentities datasets [dict get $source dataset_id] [datasetRevisionToken [dict get $source dataset_id] $session]
        }
    }
    if {[dict exists $options document_id]} {
        set document [interactiveDocumentRead [dict get $options document_id]]
        if {[dict exists $options expected_revision]&&[dict get $options expected_revision] ne [dict get $document revision]} {error {Scientific Workspace revision changed}}
        foreach {expected field} {expected_generation generation expected_sha256 sha256} {if {[dict exists $options $expected] && [dict get $options $expected] ne [dict get $document $field]} {error {Scientific Workspace incarnation/source SHA changed}}}
        if {$imageProfile} {
            dict set sourceIdentities workspace [dict create id [dict get $document id] generation [dict get $document generation] revision [dict get $document revision] sha256 [dict get $document sha256]]
        } else {dict set sourceIdentities workspace [dict remove $document payload]}
    }
    foreach id [datasetPublicationV2DictDefault $options dataset_sources {}] {dict set sourceIdentities datasets $id [datasetRevisionToken $id $session]}
    set tools {};foreach tool [dict get $d tools] {dict set tools $tool [runtimeToolRequired $tool]}
    set imageFactsTool {}
    if {$imageProfile && [_scientificExecutionImageFactsProfile [dict get $options image_recipe]] ne {}} {
        _scientificExecutionImageProvider $provider
        set imageFactsTool [_scientificExecutionImageFactsTool [dict get $options image_recipe]]
        dict set tools quantitative_raster_native [dict get $imageFactsTool tool_path]
    }
    set worker [file normalize [file join $::GX::scriptDir [dict get $d worker]]]
    set runtimeFiles {}
    foreach relative [datasetPublicationV2DictDefault $d runtime_files {}] {
        set path [scriptModuleSafeRelative $::GX::scriptDir $relative]
        dict set runtimeFiles $relative [sha256File $path]
    }
    if {$imageProfile} {
        # Include the same actual registered callback source closure in the
        # immutable request checked BEFORE a cold module can execute source.
        dict for {path source} [dict get $d image_callback_stamp sources] {
            if {![string match "$::GX::scriptDir/*" $path]} {error {Scientific callback source is outside the framework}}
            set relative [string range $path [expr {[string length $::GX::scriptDir]+1}] end]
            dict set runtimeFiles $relative [dict get $source sha256]
        }
    }
    if {$imageFactsTool ne {}} {
        dict for {relative expected} [dict get $imageFactsTool runtime_files] {dict set runtimeFiles $relative $expected}
    }
    if {[dict size $runtimeFiles]>256} {error {Scientific provider runtime inventory exceeds256 files}}
    set adapter [file join $::GX::scriptDir core python gxtxt_scientific_execution.py]
    set request [dict create adapter_sha256 [sha256File $adapter] runtime_files $runtimeFiles provider_id $provider provider_version [dict get $d version] worker $worker worker_sha256 [sha256File $worker] schema [dict get $d parameters] parameters [_scientificExecutionParameters [dict get $d parameters] $parameters] inputs $inputs source_identities $sourceIdentities tools $tools]
    if {$imageProfile} {
        dict set request image_profile image_resource_files_v1
        dict set request image_provider_binding [dict get $d image_provider_binding]
        dict set request image_input_sources $imageSources
        dict set request image_source_metadata $imageMetadata
        dict set request image_resource_sources $resources
        dict set request image_capture_options [dict remove $options image_recipe]
        dict set request image_recipe [dict get $options image_recipe]
        if {$imageSourceProfile ne {}} {dict set request image_source_profile $imageSourceProfile}
        if {$imageFactsTool ne {}} {dict set request image_facts_tool $imageFactsTool}
    }
    if {[dict exists $d native_artifact]} {
        set artifact [_nativeJobVerifyDescriptor [dict get $d native_artifact]]
        dict set request native_artifact $artifact
        dict set request source_identities native_artifact [dict create module_id [dict get $d module_id] artifact_sha256 [dict get $artifact artifact_sha256] source_sha256 [dict get $artifact source_sha256]]
        # Independent invocations keep distinct IDs through the existing
        # Supervisor signature, even for identical native task parameters.
        dict set request native_owner [dict create module_id [dict get $d module_id] entrypoint [dict get $artifact entrypoint] invocation_id [parallelOctaveRandomToken] session_fingerprint [_scientificExecutionRemoteSessionFingerprint] session_origin [sessionOriginRead $session]]
        dict set request native_owner resource_sources $resources
        dict set request native_input_descriptors $nativeDescriptors
        set nativeUnits {}
        dict for {alias reference} $resources {dict set nativeUnits $alias [datasetPublicationV2DictDefault [dict get $reference metadata] units [datasetPublicationV2DictDefault [dict get $reference metadata] unit {}]]}
        dict set request native_input_units $nativeUnits
    }
    set token "scientific-prepare#[pid]-[incr serial]"
    dict set prepared $token [dict create session $session session_token [interactiveDocumentSessionToken] resources $resources options $options request $request]
    if {$imageCanvasBinding ne {}} {dict set prepared $token image_canvas_preparation $imageCanvasBinding}
    return $token
}
proc ::GX::scientificExecutionDiscard {token} {
    if {[string match remote-prepare#* $token]} {set p [dict get $::GX::ScientificExecution::remotePrepared $token];if {![dict exists $p receipt]} {scientificExecutionRemoteCall [dict get $p node] [dict get $p session] scientific.discard [dict get $p token]};dict unset ::GX::ScientificExecution::remotePrepared $token;return [dict create discarded 1]}
    variable ::GX::ScientificExecution::prepared
    if {![dict exists $prepared $token]} {error {Unknown scientific preparation}}
    dict unset prepared $token
    return [dict create discarded 1]
}
# Private GUI-origin binding inside the original ScientificExecution owner.
# No Script Bridge/public operation accepts a projection or grants this route.
proc ::GX::_scientificExecutionImageCanvasOwner {window component handle {purpose publish}} {
    set owner [viewerGuiCanvasOwnerCapture $window $component $purpose]
    if {[dict get $owner handle] ne $handle} {error {Scientific Canvas is outside the captured Viewer field}}
    return $owner
}
proc ::GX::_scientificExecutionImageCanvasCurrent {owner held} {
    viewerGuiCanvasOwnerCurrent $owner $held
}
proc ::GX::scientificExecutionCanvasPrepare {window component handle request {purpose publish}} {
    # Public trusted-host facade. Window/slot/grants and the registered provider
    # remain captured by CORE; this adds no Script Bridge callback/path grant.
    tailcall ::GX::_scientificExecutionImageCanvasPrepare $window $component $handle $request $purpose
}
proc ::GX::_scientificExecutionImageCanvasPrepare {window component handle request {purpose publish}} {
    if {[scientificExecutionDestination] ne {local}} {error {Select the local Scientific Execution destination for scientific Canvas publication}}
    set owner [_scientificExecutionImageCanvasOwner $window $component $handle $purpose]
    set descriptor [_scientificExecutionImageProvider [dict get $owner scientific_provider]]
    if {[datasetPublicationV2DictDefault $descriptor canvas_source_profile {}] ne {native_canvas_document_v1}} {error {Registered scientific provider does not admit Native Canvas sources}}
    set request [_scientificExecutionParameters [dict get $descriptor canvas_parameters] $request]
    set held [native2DCanvasEditCapture $handle]
    set capture [viewerGuiCanvasProjection $owner $held [expr {$purpose eq {flatten} ? {document} : {auto}}]]
    _scientificExecutionImageFields $capture {projection resources canonical_sources}
    _scientificExecutionImageCanvasCurrent $owner $held
    # The registered application constructs its recipe from the immutable
    # authorized capture; CORE owns capture/CAS/lineage and byte sealing.
    set request [uplevel #0 [list {*}[dict get $descriptor image_canvas_recipe] $request $capture $purpose]]
    if {[catch {dict size $request}]} {error {Registered Canvas recipe must be an inert record}}
    _scientificExecutionImageProvider [dict get $owner scientific_provider]
    _scientificExecutionImageCanvasCurrent $owner $held
    set guard [dict get $owner guard]
    set options [dict create node_id local document_id [dict get $guard document_id] \
        expected_generation [dict get $guard generation] expected_revision [dict get $guard revision] \
        expected_sha256 [dict get $guard sha256] dataset_sources [dict keys [dict get $capture canonical_sources]] \
        image_sources {} image_recipe $request]
    set binding [dict create owner $owner held $held capture $capture]
    set token [_scientificExecutionPrepare [dict get $owner scientific_provider] {} [dict get $capture resources] $options $binding]
    try {
        return [_scientificExecutionImageCanvasBind $token $window $component $handle]
    } on error {message context} {
        if {[dict exists $::GX::ScientificExecution::prepared $token]} {scientificExecutionDiscard $token}
        return -options $context $message
    }
}
proc ::GX::_scientificExecutionImageCanvasBind {token window component handle} {
    variable ::GX::ScientificExecution::prepared
    if {![dict exists $prepared $token]} {error {Unknown original scientific preparation}}
    set p [dict get $prepared $token]
    set request [dict get $p request]
    if {[dict exists $p image_canvas_owner] || [dict exists $request image_native_projection]} {error {Scientific Canvas preparation is already bound}}
    set descriptor [_scientificExecutionImageProvider [dict get $request provider_id] $request]
    if {[dict get $p session_token] ne [interactiveDocumentSessionToken] || \
        [datasetPublicationV2DictDefault $request image_profile {}] ne {image_resource_files_v1} || \
        [datasetPublicationV2DictDefault $descriptor canvas_source_profile {}] ne {native_canvas_document_v1} || [scientificExecutionDestination] ne {local}} {error {Scientific Canvas requires its registered local document preparation}}
    if {![dict exists $p image_canvas_preparation]} {error {Scientific Canvas requires its original authorized capture}}
    set original [dict get $p image_canvas_preparation]
    _scientificExecutionImageFields $original {owner held capture}
    set owner [dict get $original owner];set held [dict get $original held]
    if {[dict get $owner window] ne $window || [dict get $owner component] ne $component || [dict get $owner handle] ne $handle} {error {Scientific Canvas preparation captured another mounted owner}}
    _scientificExecutionImageCanvasCurrent $owner $held
    if {[dict get $request provider_id] ne [dict get $owner scientific_provider]} {error {Scientific Canvas provider differs from the activated extension}}
    set capture [dict get $original capture]
    _scientificExecutionImageFields $capture {projection resources canonical_sources}
    _scientificExecutionImageCanvasCurrent $owner $held
    set projection [dict get $capture projection]
    if {[dict get $projection schema] ne [dict get $owner projection_schema] || \
        [dict get $projection document_guard] ne [dict get $owner guard] || \
        [dict get $projection sequence] ne [dict get $owner sequence] || \
        [dict get $projection canvas_id] ne [dict get [native2DCanvasContext $handle] canvas_id]} {error {Scientific Canvas projection is outside its actual owner}}
    set guard [dict get $owner guard]
    foreach option {document_id expected_generation expected_revision expected_sha256} field {document_id generation revision sha256} {
        if {![dict exists $p options $option] || [dict get $p options $option] ne [dict get $guard $field]} {error {Scientific Canvas preparation captured another Document}}
    }
    if {[dict get $capture resources] ne [dict get $p resources] || \
        [dict get $p resources] ne [dict get $request image_resource_sources] || \
        [dict size [dict get $p options image_sources]]} {error {Scientific Canvas must capture its current Resource aliases exactly once}}
    set origins [dict get $capture canonical_sources]
    if {[lsort [dict keys $origins]] ne [lsort -unique [dict get $p options dataset_sources]]} {error {Scientific Canvas canonical lineage differs from the prepared source guards}}
    dict for {id origin} $origins {
        _scientificExecutionImageFields $origin {dataset_id source_sha256 source_revision}
        if {[dict get $origin dataset_id] ne $id} {error {Scientific Canvas canonical identity differs}}
        set actual [_quantitativeRasterSourceIdentity $id]
        foreach key {dataset_id source_sha256 source_revision} {if {[dict get $origin $key] ne [dict get $actual $key]} {error {Scientific Canvas canonical source changed}}}
    }
    set sources [_scientificExecutionImageSourceRecords [dict get $p resources] [dict get $p options] {} \
        [datasetPublicationV2DictDefault $request image_source_profile {}] [dict get $request provider_id]]
    if {$sources ne [dict get $request image_input_sources]} {error {Scientific Canvas Resource bytes changed during binding}}
    _scientificExecutionSourcesCurrent [dict get $request source_identities]
    _scientificExecutionImageCanvasCurrent $owner $held
    dict set request image_native_projection $projection
    dict set request image_native_canonical_sources $origins
    dict set request image_source_profile native_canvas_document_v1
    dict set request image_native_projection_sha256 [apiCatalogNative digest [binary encode base64 -maxlen 0 [encoding convertto utf-8 $projection]]]
    dict set p request $request
    dict set p image_canvas_owner $owner
    dict set p image_canvas_held $held
    if {[dict exists $p image_canvas_preparation]} {dict unset p image_canvas_preparation}
    dict set prepared $token $p
    return $token
}
proc ::GX::scientificExecutionCanvasResultValidate {provider request summary raster} {
    # The caller supplies output metadata from the original verified reader.
    # This facade preserves application facts validation, not an output reader,
    # publication grant, substitute renderer or numeric correctness attestation.
    set descriptor [_scientificExecutionImageProvider $provider $request]
    if {![dict exists $descriptor image_canvas_result]} {error {Registered provider has no Canvas result validator}}
    if {[datasetPublicationV2DictDefault $request image_source_profile {}] ne [dict get $descriptor canvas_source_profile]} {error {Canvas result has another registered source profile}}
    set id [dict get $raster job_id]
    set job [_scientificExecutionPublicationJob $id]
    if {[dict get $job state] ne {COMPLETED} || [dict get $job scientific_request] ne $request} {error {Canvas result differs from its owned completed Job}}
    set options [dict get $request image_capture_options]
    dict set options image_recipe [dict get $request image_recipe]
    set resources [dict get $request image_resource_sources]
    set before [_scientificExecutionImageSourceRecords $resources $options {} [dict get $request image_source_profile] $provider]
    set result [uplevel #0 [list {*}[dict get $descriptor image_canvas_result] $request $summary $raster]]
    _scientificExecutionImageProvider $provider $request
    set job [_scientificExecutionPublicationJob $id]
    if {[dict get $job state] ne {COMPLETED} || [dict get $job scientific_request] ne $request ||
        [_scientificExecutionImageSourceRecords $resources $options {} [dict get $request image_source_profile] $provider] ne $before} {error {Canvas result source/Job ownership changed during validation}}
    return $result
}
proc ::GX::scientificExecutionSubmit {token {callback {}}} {
    tailcall ::GX::_scientificExecutionSubmit $token $callback 0
}
# Public trusted-module facets over the SAME scientific/Job owners. These
# methods do not register Script Bridge operations or delegate Tcl callbacks,
# preparation tokens, Document CAS or admission recovery to worker scripts.
proc ::GX::scientificExecutionSubmitTracked {token callback} {
    tailcall ::GX::_scientificExecutionSubmitTracked $token $callback
}
proc ::GX::scientificExecutionTrackedOwnerScope {document provider} {
    tailcall ::GX::_scientificExecutionTrackedOwnerScope $document $provider
}
proc ::GX::scientificExecutionRecoverTracked {owner_scope callback {cancel_accepted 0}} {
    tailcall ::GX::_scientificExecutionRecoverTracked $owner_scope $callback $cancel_accepted
}
proc ::GX::scientificExecutionAcknowledgeTracked {owner_scope submission_id job_id callback} {
    tailcall ::GX::_scientificExecutionAcknowledgeTracked $owner_scope $submission_id $job_id $callback
}
proc ::GX::scientificExecutionTrackedResolve {admission_owner callback {close 0} {cancel 0}} {
    # Resolution deliberately retains the original captured destination, even
    # after ambient destination drift. Only the existing owner reconciles it.
    tailcall ::GX::_scriptJobTrackedResolve $admission_owner $callback $close $cancel
}
proc ::GX::scientificExecutionTrackedWait {admission_owner job_id callback} {
    tailcall ::GX::_scriptJobTrackedWait $admission_owner $job_id $callback
}
proc ::GX::scientificExecutionTrackedOwnerCurrent {admission_owner} {
    set id [dict get $admission_owner submission_id]
    # Reconstruct from the actual persistent owner before validating supplied
    # data. No command/path/capsule from a Viewer becomes execution authority.
    set actual [_scriptJobTrackedCapsule [_scriptJobTrackedOwner $id]]
    _scriptJobTrackedCapsule $admission_owner
    _scriptJobTrackedOwnerCurrent [dict get $actual owner_scope]
    if {[file normalize [scriptJobRoot]] ne [dict get $actual binding root]} {error {Scientific Job root changed; resolve the original admission before further observation}}
    return 1
}
proc ::GX::scientificExecutionSourcesCurrent {identities} {
    tailcall ::GX::_scientificExecutionSourcesCurrent $identities
}
proc ::GX::scientificExecutionPublicationGuard {guard} {
    tailcall ::GX::_scientificExecutionPublicationGuard $guard
}
proc ::GX::scientificExecutionImageOutputs {id} {
    tailcall ::GX::_scientificExecutionImageOutputs $id
}
proc ::GX::scientificExecutionImageOriginal {id alias} {
    tailcall ::GX::_scientificExecutionImageOriginal $id $alias
}
proc ::GX::scientificExecutionImageImport {id output guard callback {inputAlias {}}} {
    tailcall ::GX::_scientificExecutionImageImport $id $output $guard $callback $inputAlias
}
proc ::GX::scientificExecutionImageImportCancel {ticket} {
    tailcall ::GX::_scientificExecutionImageImportCancel $ticket
}
proc ::GX::scientificExecutionImagePublish {id token publication {applicationContext {}}} {
    # A finite registered provider operation, never a caller-selected module
    # context or command. Reuse the original rollback-capable Dataset owner.
    set job [_scientificExecutionPublicationJob $id]
    if {[dict get $job state] ne {COMPLETED} || [datasetPublicationV2DictDefault [dict get $job scientific_request] image_profile {}] ne {image_resource_files_v1}} {error {Image publication requires its owned completed image Job}}
    set descriptor [_scientificExecutionImageProvider [dict get $job scientific_request provider_id] [dict get $job scientific_request]]
    if {![dict exists $descriptor image_publish]} {error {Image provider has no registered publication operation}}
    return [_datasetPrivateWithModule [dict get $descriptor module_id] \
        ::GX::datasetAuthorityTransaction [_interactiveDocumentRequireSession] \
        ::GX::_scientificExecutionImagePublishCommit $id $token $publication $applicationContext [interactiveDocumentSessionToken]]
}
proc ::GX::_scientificExecutionImagePublishCommit {id token publication applicationContext sessionToken} {
    set job [_scientificExecutionPublicationJob $id];set request [dict get $job scientific_request]
    if {$sessionToken ne [interactiveDocumentSessionToken] || [dict get $job state] ne {COMPLETED}} {error {Scientific image publication lifetime changed}}
    set provider [dict get $request provider_id]
    set descriptor [_scientificExecutionImageProvider $provider $request]
    if {![dict exists $descriptor image_publish] || ![datasetAuthorityActive [_interactiveDocumentRequireSession]] ||
        [dict get [datasetPrivateMetadataContext] module_id] ne [dict get $descriptor module_id]} {error {Scientific image publication requires its registered transaction owner}}
    set result [_scientificExecutionImageOutputs $id];set selected {}
    foreach output [dict get $result outputs] {
        if {[dict get $output token] eq $token} {
            if {$selected ne {}} {error {Ambiguous immutable scientific image output}}
            set selected $output
        }
    }
    if {$selected eq {} || [dict get $result validation] ne {validated_structure} ||
        [dict get $selected job_id] ne $id || [dict get $selected live] || [dict get $selected availability] ne {available}} {error {Scientific image publication requires its verified immutable output}}
    set identity [dict get $job parameters request]
    set receipt [uplevel #0 [list [dict get $descriptor image_publish] $id $publication $selected $result $applicationContext]]
    # Still inside Dataset Authority: all failures roll back before commit.
    set current [_scientificExecutionPublicationJob $id]
    _scientificExecutionImageProvider $provider $request
    if {$sessionToken ne [interactiveDocumentSessionToken] || [dict get $current state] ne {COMPLETED} ||
        [dict get $current scientific_request] ne $request || [dict get $current parameters request] ne $identity} {error {Scientific image publication source/Job changed}}
    return $receipt
}
# HOST_ONLY: original prepared source/Document owner, opting into the SAME local
# durable admission correlation. No new public operation or remote certainty.
proc ::GX::_scientificExecutionSubmitTracked {token callback} {
    if {$callback eq {}} {error {Tracked Scientific submission requires a callback}}
    tailcall ::GX::_scientificExecutionSubmit $token $callback 1
}
proc ::GX::_scientificExecutionTrackedOwnerScope {document provider} {
    set session [_interactiveDocumentRequireSession]
    file lstat $session s
    set metadata [interactiveDocumentMetadata $document]
    return [_scriptJobTrackedCanonicalOwner [dict create session $session session_dev $s(dev) session_ino $s(ino) uid $s(uid) \
        document_id $document document_generation [dict get $metadata generation] provider_id $provider]]
}
proc ::GX::_scientificExecutionRecoverTracked {owner_scope callback {cancel_accepted 0}} {
    tailcall ::GX::_scriptJobTrackedRecover $owner_scope $callback $cancel_accepted
}
proc ::GX::_scientificExecutionAcknowledgeTracked {owner_scope submission_id job_id callback} {
    tailcall ::GX::_scriptJobTrackedAcknowledge $owner_scope $submission_id $job_id $callback
}
proc ::GX::_scientificExecutionSubmit {token callback tracked} {
    if {[string match remote-prepare#* $token]} {
        if {$tracked} {error {Tracked Scientific admission is LOCAL only; remote owner is unchanged}}
        return [scientificExecutionRemoteSubmit $token $callback]
    }
    variable ::GX::ScientificExecution::prepared
    if {![dict exists $prepared $token]} {error {Unknown or consumed scientific preparation}}
    set p [dict get $prepared $token]
    if {[dict exists $p image_canvas_preparation]} {error {Scientific Canvas preparation has not completed its actual GUI binding}}
    set canvasFields [list [dict exists $p request image_source_profile] [dict exists $p request image_native_projection] \
        [dict exists $p request image_native_canonical_sources] [dict exists $p request image_native_projection_sha256] \
        [dict exists $p image_canvas_owner] [dict exists $p image_canvas_held]]
    if {1 in $canvasFields} {
        if {0 in $canvasFields} {error {Scientific Canvas preparation lacks its actual complete GUI owner binding}}
        _scientificExecutionImageCanvasCurrent [dict get $p image_canvas_owner] [dict get $p image_canvas_held]
    }
    if {[dict get $p session_token] ne [interactiveDocumentSessionToken]} {error {Scientific preparation belongs to another Session lifetime}}
    dict for {alias reference} [dict get $p resources] {interactiveDocumentResourceInfo $reference}
    set request [dict get $p request]
    if {[dict exists $request native_artifact]} {_nativeJobVerifyDescriptor [dict get $request native_artifact]}
    _scientificExecutionSourcesCurrent [dict get $request source_identities]
    if {[sha256File [dict get $request worker]] ne [dict get $request worker_sha256]} {error {Scientific provider changed after preparation}}
    dict for {relative expected} [dict get $request runtime_files] {if {[sha256File [scriptModuleSafeRelative $::GX::scriptDir $relative]] ne $expected} {error {Scientific native/runtime dependency changed after preparation}}}
    if {[sha256File [file join $::GX::scriptDir core python gxtxt_scientific_execution.py]] ne [dict get $request adapter_sha256]} {error {Scientific CORE adapter changed after preparation}}
    set encoded [binary encode base64 -maxlen 0 [encoding convertto utf-8 $request]]
    if {$callback ne {}} {
        if {$tracked} {
            if {[dict exists $p image_canvas_owner]} {
                # Native-publish retains its stronger actual Canvas owner. The
                # completeness/current checks above may never fall back here.
                set documentId [dict get $p image_canvas_owner guard document_id]
                set generation [dict get $p image_canvas_owner guard generation]
            } else {
                # Ordinary public Prepare captures a real Document in options
                # and source_identities; it deliberately has NO Canvas owner.
                # SourcesCurrent above has rechecked its exact revision/SHA.
                if {![dict exists $p options document_id] || ![dict exists $request source_identities workspace]} {error {Tracked Scientific admission requires its original prepared Document binding}}
                set workspace [dict get $request source_identities workspace]
                foreach field {id generation revision sha256} {if {![dict exists $workspace $field] || [dict get $workspace $field] eq {}} {error {Tracked prepared Document identity is incomplete}}}
                set documentId [dict get $p options document_id]
                if {$documentId ne [dict get $workspace id]} {error {Tracked prepared Document differs from its source identity}}
                foreach option {expected_generation expected_revision expected_sha256} field {generation revision sha256} {
                    if {[dict exists $p options $option] && [dict get $p options $option] ne [dict get $workspace $field]} {error {Tracked prepared Document guards changed}}
                }
                set generation [dict get $workspace generation]
            }
            set ownerScope [_scientificExecutionTrackedOwnerScope $documentId [dict get $request provider_id]]
            if {[dict get $ownerScope document_generation] ne $generation} {error {Tracked original prepared Document generation changed}}
            set pending [_scriptJobSubmitCoreTracked scientific-provider [dict create request $encoded] [dict create session [dict get $p session] _admission_owner_scope $ownerScope] [list ::GX::_scientificExecutionTrackedSubmitted [dict get $request provider_id] $callback]]
            dict unset prepared $token
            return [dict merge $pending [dict create provider_id [dict get $request provider_id]]]
        }
        # Only the retained, already-current original native Canvas flatten
        # owner selects the existing committed reader for its fresh preparer.
        # Scope this interpreter-only choice through the immediate constructor;
        # unrelated ordinary callers and all worker environments stay unchanged.
        if {[dict exists $p image_canvas_owner purpose] && [dict get $p image_canvas_owner purpose] eq {flatten} &&
            [dict get $request provider_id] eq [dict get $p image_canvas_owner scientific_provider] &&
            [dict exists $request image_profile] && [dict get $request image_profile] eq {image_resource_files_v1} &&
            [dict exists $request image_source_profile] && [dict get $request image_source_profile] eq {native_canvas_document_v1}} {
            set priorReaderExists [info exists ::GX::_scriptJobAdmissionWorkspaceAccess]
            if {$priorReaderExists} {set priorReader $::GX::_scriptJobAdmissionWorkspaceAccess}
            try {
                set ::GX::_scriptJobAdmissionWorkspaceAccess read_only
                set pending [_scriptJobSubmitCore scientific-provider [dict create request $encoded] [dict create session [dict get $p session]] [list ::GX::_scientificExecutionSubmitted [dict get $request provider_id] $callback]]
            } finally {
                if {$priorReaderExists} {
                    set ::GX::_scriptJobAdmissionWorkspaceAccess $priorReader
                } else {
                    unset -nocomplain ::GX::_scriptJobAdmissionWorkspaceAccess
                }
            }
        } else {
        set pending [_scriptJobSubmitCore scientific-provider [dict create request $encoded] [dict create session [dict get $p session]] [list ::GX::_scientificExecutionSubmitted [dict get $request provider_id] $callback]]
        }
        dict unset prepared $token
        return [dict create submission_id $pending state PENDING provider_id [dict get $request provider_id]]
    }
    set job [_scriptJobSubmitCore scientific-provider [dict create request $encoded] [dict create session [dict get $p session]]]
    dict unset prepared $token
    return [dict create job_id [dict get $job id] state [dict get $job state] provider_id [dict get $request provider_id]]
}
proc ::GX::_scientificExecutionTrackedSubmitted {provider callback response} {
    if {[dict get $response ok]} {dict set response result provider_id $provider}
    uplevel #0 [list {*}$callback $response]
}
proc ::GX::_scientificExecutionSubmitted {provider callback response} {
    if {[dict get $response ok]} {
        set job [dict get $response result]
        set response [dict create ok 1 result [dict create job_id [dict get $job id] state [dict get $job state] provider_id $provider]]
    }
    uplevel #0 [list {*}$callback $response]
}
proc ::GX::_scientificExecutionJob {id {nativeModule {}}} {
    set job [scriptJobDescribe $id]
    if {[dict get $job session] ne [_interactiveDocumentRequireSession]||[dict get $job reference] ni {session:gx-core-scientific-execution core-service:scientific-provider}} {error {Scientific Job does not belong to the current Session}}
    set request [encoding convertfrom utf-8 [binary decode base64 [dict get $job parameters request]]]
    if {[dict exists $request source_identities session_origin]&&[dict get $request source_identities session_origin] ne [sessionOriginRead [_interactiveDocumentRequireSession]]} {error {Scientific Job belongs to a different Session origin}}
    dict set job scientific_request $request
    # Native projects keep the same source/incarnation guard even when reached
    # through generic Scientific Execution operations, rather than its facade.
    if {[dict exists $request native_owner]} {_nativeJobRecordGuard $job $nativeModule}
    return $job
}
proc ::GX::scientificExecutionStatus {id} {
    if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJob $id status]}
    set job [_scientificExecutionJob $id]
    set status [dict create job_id $id provider_id [dict get $job scientific_request provider_id] state [dict get $job state]]
    foreach key {created started finished error cancel cpu_seconds peak_rss_bytes peak_processes peak_threads peak_rss_bytes process_identities temporary_bytes resource_cleanup resource_id policy usage queue_reason pid pid_start} {if {[dict exists $job $key]} {dict set status $key [dict get $job $key]}}
    if {[dict exists $status resource_cleanup]} {
        set cleanup {};foreach entry [dict get $status resource_cleanup] {lappend cleanup [dict remove $entry path]}
        dict set status resource_cleanup $cleanup
    }
    dict set status source_identities [dict get $job scientific_request source_identities]
    if {[dict exists $job scientific_request native_owner]} {dict set status native_owner [dict get $job scientific_request native_owner]}
    if {[dict exists $job progress]} {dict set status progress [dict get $job progress]}
    return $status
}
proc ::GX::scientificExecutionImageStatus {id} {
    # Original local image Job/session/profile ownership, projected as finite
    # status values. It does not expose a request/capsule or grant adoption.
    set job [_scientificExecutionJob $id]
    if {[datasetPublicationV2DictDefault [dict get $job scientific_request] image_profile {}] ne {image_resource_files_v1}} {error {Job does not use the original image resource profile}}
    set raw [scientificExecutionStatus $id];set status {}
    foreach key {job_id provider_id state created started finished error cancel cpu_seconds peak_rss_bytes peak_processes peak_threads temporary_bytes progress} {
        if {[dict exists $raw $key]} {dict set status $key [dict get $raw $key]}
    }
    return $status
}
proc ::GX::scientificExecutionReconnect {id} {scientificExecutionStatus $id}
proc ::GX::scientificExecutionCancel {id} {if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJob $id cancel]};_scientificExecutionJob $id;scriptJobCancel $id;return [scientificExecutionStatus $id]}
proc ::GX::scientificExecutionLog {id {offset 0} {count 65536} {previousReceipt {}}} {
    if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJob $id log $offset $count $previousReceipt]}
    _scientificExecutionJob $id
    if {$previousReceipt ne {}&&![regexp {^[0-9]+:[0-9]+:[0-9]+:[0-9]+$} $previousReceipt]} {error {Invalid prior log generation token}}
    set page [dict remove [scriptJobLogRead $id $offset $count] path]
    set change initial;set reset 0
    if {$previousReceipt ne {}} {
        if {![dict get $page available]&&[string match {*Log shrank*} [dict get $page diagnostic]]} {set page [dict remove [scriptJobLogRead $id 0 $count] path];set reset 1;set change truncated}
        if {[dict exists $page receipt]} {
            lassign [split $previousReceipt :] oldDev oldInode oldModified oldSize
            lassign [split [dict get $page receipt] :] dev inode modified size
            if {$dev ne $oldDev||$inode ne $oldInode} {set reset 1;set change rotated} elseif {$size<$oldSize} {set reset 1;set change truncated} elseif {$modified ne $oldModified&&$size<=$oldSize} {set reset 1;set change rewritten} elseif {$size>$oldSize} {set change append} else {set change unchanged}
            if {$reset&&[dict get $page offset]!=0} {set page [dict remove [scriptJobLogRead $id 0 $count] path]}
        }
    }
    dict set page job_id $id
    dict set page change $change
    dict set page cursor_reset $reset
    if {[dict exists $page receipt]} {dict set page generation [dict get $page receipt]}
    return $page
}
proc ::GX::_scientificExecutionOutput {id operation {token {}} {offset 0} {count 65536} {generation {}}} {
    if {[scientificExecutionRemoteId $id]} {set public [dict get {list outputs read read_output read_records read_records freeze freeze_output} $operation];if {$public eq "outputs"} {return [scientificExecutionRemoteJob $id $public]};return [scientificExecutionRemoteJob $id $public $token $offset $count $generation]}
    set job [_scientificExecutionJob $id]
    set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_scientific_execution.py] [dict get $job output_dir] $id $operation $token $offset $count $generation]
    set rc [catch {exec {*}$command} response]
    if {[catch {dict get $response ok} ok]||!$ok} {if {![catch {dict get $response error} message]} {error $message};error $response}
    return [dict get $response result]
}
proc ::GX::scientificExecutionOutputs {id} {_scientificExecutionOutput $id list}
proc ::GX::scientificExecutionReadOutput {id token {offset 0} {count 65536} {generation {}}} {_scientificExecutionOutput $id read $token $offset $count $generation}
proc ::GX::scientificExecutionReadRecords {id token {offset 0} {count 65536} {generation {}}} {_scientificExecutionOutput $id read_records $token $offset $count $generation}
proc ::GX::scientificExecutionFreezeResource {id token document} {
    if {[scientificExecutionRemoteId $id]} {
        set output [_scientificExecutionOutput $id freeze $token 0 16777216]
        if {![dict exists $output sha256] || ![dict get $output complete]} {error {Remote output is not a complete immutable capture}}
        return [managedResourceWrite $document [dict create format [dict get $output format] source_job_id $id source_output_token $token source_generation [dict get $output source_generation] source_sha256 [dict get $output sha256] scientific_authority 1] [binary decode base64 [dict get $output bytes_base64]]]
    }
    set job [_scientificExecutionJob $id]
    if {[dict get $job state] ni {COMPLETED FAILED CANCELLED INTERRUPTED}} {error {Freeze a terminal Job output; live values remain provisional}}
    interactiveDocumentRead $document
    set output [_scientificExecutionOutput $id freeze $token 0 16777216]
    if {![dict exists $output sha256]||![dict get $output complete]} {error {Freeze requires a complete coherent bounded scientific output}}
    return [managedResourceWrite $document [dict create format [dict get $output format] origin scientific_job source_job_id $id source_output_token $token source_generation [dict get $output source_generation] source_sha256 [dict get $output sha256] scientific_authority 1] [binary decode base64 [dict get $output bytes_base64]]]
}
proc ::GX::scientificExecutionImportResults {id token request} {
    if {[scientificExecutionRemoteId $id]} {return [scientificExecutionRemoteJob $id import_results $token $request]}
    variable ::GX::ScientificExecution::providers
    set job [_scientificExecutionJob $id]
    if {[dict get $job state] ne {COMPLETED}} {error {Only a completed scientific Job may be imported}}
    _scientificExecutionSourcesCurrent [dict get $job scientific_request source_identities]
    set provider [dict get $job scientific_request provider_id]
    if {![dict exists $providers $provider import_command]} {error {This provider has no registered scientific result importer}}
    set output [_scientificExecutionOutput $id freeze $token 0 16777216]
    if {[dict get $output availability] ne {available}||![dict exists $output sha256]||![dict get $output complete]} {error {Import requires a complete coherent bounded result; use a provider streaming importer for larger results}}
    set bytes [binary decode base64 [dict get $output bytes_base64]]
    _scientificExecutionSourcesCurrent [dict get $job scientific_request source_identities]
    # The registered scientific provider owns result publication. A Viewer or
    # Script Bridge caller may have a different active module context; passing
    # that context through would misattribute the provider's canonical outputs.
    # Scope the existing module context to the registered owner and restore the
    # caller on both success and failure. All source/output guards above remain.
    return [_datasetPrivateWithModule [dict get $providers $provider module_id] \
        [dict get $providers $provider import_command] $id $token $bytes $request]
}
proc ::GX::scientificExecutionRegisterBuiltins {} {
    scientificExecutionRegister core.ngspice.rc_transient [dict create module_id core.scientific_execution version 1.0.0 worker core/python/gxtxt_scientific_builtin_providers.py tools {spice} parameters [dict create step_seconds {type number default 0.00001 min 0.00000001 max 0.0001} stop_seconds {type number default 0.005 min 0.001 max 0.1}] import_command ::GX::_scientificRcImport]
    if {[info exists ::env(GXTXT_SCIENTIFIC_TEST_PROVIDERS)]&&$::env(GXTXT_SCIENTIFIC_TEST_PROVIDERS) eq {1}} {
        scientificExecutionRegister core.verification.cpu [dict create module_id core.scientific_execution version 1.0.0 worker core/python/gxtxt_scientific_builtin_providers.py tools {} parameters [dict create seed {type integer default 7 min 0 max 4294967295} rounds {type integer default 10000 min 1 max 1000000} seconds {type number default 1 min 0 max 30} fail {type boolean default 0} live {type boolean default 0}]]
    }
}
proc ::GX::_scientificRcImport {jobId outputToken bytes request} {
    if {[dict keys $request] ne {dataset_id}} {error {RC import requires only a new Dataset ID}}
    set text [encoding convertfrom utf-8 $bytes]
    set lines [split [string trim $text] \n]
    if {[lindex $lines 0] ne {time,voltage}} {error {Unexpected RC waveform schema}}
    set times {};set voltages {};set previous -Inf
    foreach line [lrange $lines 1 end] {
        if {[llength [split $line ,]]!=2} {error {Malformed RC record}}
        lassign [split $line ,] t v
        foreach number [list $t $v] {if {![string is double -strict $number]||[catch {expr {abs(double($number))<Inf}} finite]||!$finite} {error {Nonfinite RC waveform}}}
        if {$t<=$previous} {error {RC time must increase}};set previous $t
        lappend times $t;lappend voltages $v
    }
    if {$times eq {}} {error {Empty RC waveform}}
    set session [_interactiveDocumentRequireSession]
    set definition [dict create dataset_id [dict get $request dataset_id] contract table.generic storage csv provenance "Scientific Job $jobId; output $outputToken; registered ngspice RC parser 1.0.0" structured_metadata [dict create scientific_execution.job_id $jobId scientific_execution.output_token $outputToken scientific_execution.source_generation [dict get [scientificExecutionReadOutput $jobId $outputToken] source_generation]]]
    set plan [datasetPublicationV2Prepare $session core.scientific_execution $definition]
    set writer [datasetPublicationV2OpenWriter $plan]
    try {
        datasetPublicationV2DeclareDimension $writer rows 0 {extendible 1}
        datasetPublicationV2DeclareVariable $writer time {dtype float64 name Time unit s dimension_ids rows}
        datasetPublicationV2DeclareVariable $writer voltage {dtype float64 name Voltage unit V dimension_ids rows}
        datasetPublicationV2Append $writer rows [dict create time $times voltage $voltages]
        return [datasetPublicationV2Finalize $writer]
    } on error {message options} {catch {datasetPublicationV2Abort $writer};return -options $options $message}
}

source [file join [file dirname [info script]] scientific_execution_remote.tcl]
::GX::scientificExecutionRegisterBuiltins
source [file join [file dirname [info script]] scientific_execution_circuit.tcl]
source [file join [file dirname [info script]] native_job_api_v1.tcl]

# Bounded cooperative CSV result adoption through existing output and Publication owners.
namespace eval ::GX::ScientificTableImport {variable serial 0;variable tasks {}}
proc ::GX::_scientificExecutionDocReadDiagnosticBound {text} {
    # PRIVATE metadata, never source/adoption authority. Keep complete original
    # options when small; make every loss explicit instead of enlarging replies.
    set bytes [string bytelength $text]
    if {$bytes<=8192} {return $text}
    set prefix "PRIVATE Docread diagnostic TRUNCATED; original_bytes=$bytes\n"
    set budget [expr {8192-[string bytelength $prefix]}]
    set low 0;set high [string length $text]
    while {$low<$high} {
        set middle [expr {($low+$high+1)/2}]
        if {[string bytelength [string range $text 0 [expr {$middle-1}]]]<=$budget} {set low $middle} else {set high [expr {$middle-1}]}
    }
    return $prefix[string range $text 0 [expr {$low-1}]]
}
proc ::GX::_scientificExecutionSourcesCurrent {identities} {
    # Historical outputs stay readable. Adoption into current scientific state
    # requires the exact captured source, including replacement generations.
    if {[dict exists $identities workspace]} {
        set expected [dict get $identities workspace]
        set readCode [catch {set current [interactiveDocumentRead [dict get $expected id]]} readMessage readOptions]
        if {$readCode} {
            set diagnostic [_scientificExecutionDocReadDiagnosticBound [dict create schema gxtxt.scientific_docread_diagnostic.v1 \
                callsite _scientificExecutionSourcesCurrent/workspace phase document_read caller_phase UNKNOWN \
                document_id [dict get $expected id] caught_code $readCode original_message $readMessage original_options $readOptions]]
            return -options [dict create -code 1 -level 0 -errorcode {GX SCIENTIFIC STALE_SOURCE} \
                -gxtxt_private_docread_diagnostic $diagnostic] {Scientific Workspace is unavailable; rerun before publication}
        }
        foreach field {generation revision sha256} {
            if {[dict exists $expected $field] && (![dict exists $current $field] || [dict get $current $field] ne [dict get $expected $field])} {
                return -code error -errorcode {GX SCIENTIFIC STALE_SOURCE} {Scientific Workspace changed; rerun before publication}
            }
        }
    }
    if {[dict exists $identities datasets]} {
        dict for {dataset expected} [dict get $identities datasets] {
            if {[catch {set current [datasetRevisionToken $dataset]}] || $current ne $expected} {
                return -code error -errorcode {GX SCIENTIFIC STALE_SOURCE} {Scientific Dataset changed; rerun before publication}
            }
        }
    }
}
proc ::GX::_scientificExecutionPublicationJob {id} {
    if {[scientificExecutionRemoteId $id]} {
        set status [scientificExecutionStatus $id]
        if {[dict exists $status source_identities datasets] && [dict size [dict get $status source_identities datasets]]} {error {Remote source Datasets require node-authoritative publication validation}}
        return [dict merge $status [dict create scientific_request [dict create source_identities [datasetPublicationV2DictDefault $status source_identities {}]]]]
    }
    set job [_scientificExecutionJob $id]
    _scientificExecutionSourcesCurrent [dict get $job scientific_request source_identities]
    return $job
}
proc ::GX::_scientificExecutionPublicationGuard {guard} {
    if {$guard eq {}} return
    if {[lsort [dict keys $guard]] ne {document_id generation revision sha256}} {error {Publication source guard needs document_id/generation/revision/sha256}}
    set current [interactiveDocumentRead [dict get $guard document_id]]
    foreach field {generation revision sha256} {if {[dict get $current $field] ne [dict get $guard $field]} {return -code error -errorcode {GX SCIENTIFIC STALE_SOURCE} {Scientific source changed before result publication}}}
}
proc ::GX::scientificExecutionImportTable {id outputToken producer definition callback {sourceGuard {}}} {
    _scientificExecutionPublicationGuard $sourceGuard
    set job [_scientificExecutionPublicationJob $id]
    if {[dict get $job state] ne {COMPLETED}} {error {Only a completed scientific Job may publish a result table}}
    set output [scientificExecutionReadRecords $id $outputToken 0 65536]
    if {[dict get $output format] ne {csv} || [dict get $output live]} {error {Result publication requires an immutable declared scientific CSV table}}
    set plan [datasetPublicationV2Prepare $::GX::currentSession $producer $definition]
    set writer [datasetPublicationV2OpenWriter $plan]
    try {
        datasetPublicationV2DeclareDimension $writer row 0 {extendible 1}
        foreach col [dict get $output columns] {datasetPublicationV2DeclareVariable $writer [dict get $col id] [dict create dtype [dict get $col dtype] unit [datasetPublicationV2DictDefault $col unit {}] dimension_ids row]}
    } on error {message options} {catch {datasetPublicationV2Abort $writer};return -options $options $message}
    set ticket scientific-table-import-[incr ::GX::ScientificTableImport::serial]
    dict set ::GX::ScientificTableImport::tasks $ticket [dict create job $id output $outputToken writer $writer session_token [interactiveDocumentSessionToken] generation [dict get $output source_generation] offset 0 rows 0 callback $callback cancelled 0 source_guard $sourceGuard]
    after 1 [list ::GX::_scientificExecutionImportTableStep $ticket]
    return $ticket
}
proc ::GX::scientificExecutionImportTableCancel {ticket} {if {[dict exists $::GX::ScientificTableImport::tasks $ticket]} {dict set ::GX::ScientificTableImport::tasks $ticket cancelled 1}}
proc ::GX::_scientificExecutionImportTableStep {ticket} {
    if {![dict exists $::GX::ScientificTableImport::tasks $ticket]} return
    set task [dict get $::GX::ScientificTableImport::tasks $ticket];set writer [dict get $task writer];set completed 0
    set rc [catch {
        if {[dict get $task cancelled]} {error {Result publication cancelled}}
        if {[dict get $task session_token] ne [interactiveDocumentSessionToken]} {error {Result publication Session changed}}
        _scientificExecutionPublicationGuard [dict get $task source_guard]
        _scientificExecutionPublicationJob [dict get $task job]
        set page [scientificExecutionReadRecords [dict get $task job] [dict get $task output] [dict get $task offset] 65536 [dict get $task generation]]
        set data {};foreach col [dict get $page columns] {dict set data [dict get $col id] {}}
        foreach row [dict get $page records] {foreach col [dict get $page columns] value $row {dict lappend data [dict get $col id] $value}}
        if {[llength [dict get $page records]]} {dict incr task rows [datasetPublicationV2Append $writer row $data]}
        if {[dict get $page next_offset]>=[dict get $page size_bytes]} {
            set job [_scientificExecutionPublicationJob [dict get $task job]]
            if {[dict get $job state] ne {COMPLETED}} {error {Scientific Job is no longer completed}}
            set receipt [datasetPublicationV2Finalize $writer];set completed 1
            dict unset ::GX::ScientificTableImport::tasks $ticket
        } else {
            if {[dict get $page next_offset]<=[dict get $task offset]} {error {Scientific result codec did not advance}}
            dict set task offset [dict get $page next_offset];dict set ::GX::ScientificTableImport::tasks $ticket $task
            after 1 [list ::GX::_scientificExecutionImportTableStep $ticket]
        }
    } reason options]
    set callback [dict get $task callback]
    if {$rc} {
        catch {datasetPublicationV2Abort $writer};dict unset ::GX::ScientificTableImport::tasks $ticket
        if {$callback ne {}} {uplevel #0 [list {*}$callback [dict create ok 0 error $reason]]}
    } elseif {$completed && $callback ne {}} {uplevel #0 [list {*}$callback [dict create ok 1 result $receipt]]}
}

# Closed image profile of this same owner. Legacy byte snapshots/freeze remain.
proc ::GX::_scientificExecutionImageFactsProfile {recipe} {
    if {![dict exists $recipe facts_profile]} {return {}}
    if {[dict get $recipe facts_profile] ne {stored_f32_full_v1}} {error {Unsupported closed scientific facts_profile}}
    return stored_f32_full_v1
}
proc ::GX::_scientificExecutionImageFactsTool {recipe} {
    set profile [_scientificExecutionImageFactsProfile $recipe]
    if {$profile eq {}} {return {}}
    set relative core/quantitative_raster_native/gxtxt_quantitative_extract
    set provenance core/quantitative_raster_native/BUILD_PROVENANCE.json
    set tool [runtimeToolRequired quantitative_raster_native]
    if {[file normalize $tool] ne [scriptModuleSafeRelative $::GX::scriptDir $relative]} {error {Scientific source facts tool is not the fixed installed native owner}}
    set version [string trim [exec -- $tool --version]]
    if {![string match {gxtxt_quantitative_extract 1.1.0;*} $version]} {error {Scientific source facts requires the matching original native1.1.0 asset}}
    set runtimeFiles [dict create $relative [sha256File $tool] $provenance [sha256File [scriptModuleSafeRelative $::GX::scriptDir $provenance]]]
    return [dict create profile $profile tool_name quantitative_raster_native tool_path $tool version $version binary_relative $relative binary_sha256 [dict get $runtimeFiles $relative] runtime_files $runtimeFiles]
}
proc ::GX::_scientificExecutionImageFields {value fields} {
    if {[catch {dict size $value}] || [lsort [dict keys $value]] ne [lsort $fields]} {error {Invalid closed scientific image record}}
}
proc ::GX::_scientificExecutionImageSourceRecords {resources options {metadataVar {}} {sourceProfile {}} {provider {}}} {
    if {$metadataVar ne {}} {upvar 1 $metadataVar metadata}
    set metadata {}
    foreach field {image_sources image_recipe} {if {![dict exists $options $field]} {error {Scientific image profile lacks its source/recipe record}}}
    if {[catch {dict size [dict get $options image_recipe]}]} {error {Scientific image recipe must be an inert record}}
    set sources [dict get $options image_sources]
    if {[catch {dict size $sources}]} {error {Scientific image sources must be an inert alias record}}
    set records {}
    dict for {alias source} $sources {
        if {![regexp {^[A-Za-z_][A-Za-z0-9_]{0,63}$} $alias] || [dict exists $resources $alias]} {error {Invalid or overlapping scientific image alias}}
        _scientificExecutionImageFields $source {dataset_id source_sha256 source_revision}
        set id [dict get $source dataset_id]
        set current [_quantitativeRasterSourceIdentity $id]
        foreach field {dataset_id source_sha256 source_revision} {if {[dict get $source $field] ne [dict get $current $field]} {error {Scientific image canonical source changed}}}
        set location [sessionInspectionDatasetLocation $id]
        set path [dict get $location path]
        if {$path eq {} || ![file isfile $path] || [file type $path] eq {link}} {error {Scientific image requires an admitted ordinary local payload}}
        # Canonical identity/readstamp and actual byte hash are distinct guards.
        set bytes [file size $path];set byteSha [sha256File $path]
        set descriptor [_scientificExecutionImageProvider $provider]
        set sourceInfo [uplevel #0 [list {*}[dict get $descriptor image_source_info] $id]]
        _scientificExecutionImageProvider $provider
        if {[catch {dict size $sourceInfo}] || ![dict exists $sourceInfo metadata]} {error {Registered image source metadata is not a typed record}}
        set originalMetadata [dict get $sourceInfo metadata]
        dict set metadata $alias $originalMetadata
        dict set sourceInfo metadata {}
        set guard [dict create kind canonical_dataset identity $current revision [datasetRevisionToken $id [_interactiveDocumentRequireSession]] \
            source_info $sourceInfo metadata_sha256 [apiCatalogNative digest $originalMetadata]]
        dict set records $alias [dict create source_path $path input_sha256 $byteSha input_bytes $bytes source_guard $guard]
    }
    if {[dict size $resources]} {
        foreach field {document_id expected_generation expected_revision expected_sha256} {if {![dict exists $options $field]} {error {Scientific image Resource capture requires complete Document CAS}}}
        set document [interactiveDocumentRead [dict get $options document_id]]
        foreach {expected field} {expected_generation generation expected_revision revision expected_sha256 sha256} {
            if {[dict get $options $expected] ne [dict get $document $field]} {error {Scientific image Document changed before capture}}
        }
        dict for {alias reference} $resources {
            if {![regexp {^[A-Za-z_][A-Za-z0-9_]{0,63}$} $alias] || ![dict exists $reference owner_generation] || [dict get $reference owner_generation] eq {} ||
                [dict get $reference document_id] ne [dict get $options document_id]} {error {Scientific image Resource requires its complete actual owner generation}}
            interactiveDocumentResourceInfo $reference
            set identity [dict create id [dict get $document id] generation [dict get $document generation] revision [dict get $document revision] sha256 [dict get $document sha256]]
            set guard [dict create kind document_resource reference [dict remove $reference metadata] document $identity]
            dict set records $alias [dict create source_path [_documentResourceIdentity $reference] input_sha256 [dict get $reference sha256] \
                input_bytes [dict get $reference size_bytes] source_guard $guard]
        }
    }
    # The extended bound is selected only by original private GUI preparation
    # or its immutable CORE-service materializer, never a public option.
    switch -- $sourceProfile {
        {} {set sourceMinimum 1;set sourceLimit 16}
        native_canvas_document_v1 {set sourceMinimum 0;set sourceLimit 4000}
        default {error {Unknown original scientific image source-owner profile}}
    }
    if {[dict size $records]<$sourceMinimum || [dict size $records]>$sourceLimit} {error {Scientific image source count exceeds its finite owner profile}}
    return $records
}
proc ::GX::_scientificExecutionImageOutputGuard {out session run {expected {}}} {
    if {[file pathtype $out] ne {absolute} || [file pathtype $session] ne {absolute} || [regexp {\x00} "$out$session$run"] || $run eq {} || [file tail $run] ne $run || $run in {. ..}} {error {Invalid scientific image output scope}}
    foreach part [concat [file split $out] [file split $session]] {if {$part in {. ..}} {error {Scientific image output scope cannot contain traversal}}}
    if {$out ne [file join $session analysis scripts $run]} {error {Scientific image output is outside its original Session}}
    set current [lindex [file split $out] 0]
    foreach part [lrange [file split $out] 1 end] {
        set current [file join $current $part]
        file lstat $current identity
        if {$identity(type) ne {directory}} {error {Scientific image output ancestry changed}}
    }
    if {![file owned $out]} {error {Scientific image output has another owner}}
    set actual [dict create dev $identity(dev) ino $identity(ino)]
    if {$expected ne {} && $actual ne $expected} {error {Scientific image output directory identity changed}}
    return $actual
}
proc ::GX::_scientificExecutionImageObserveSnapshot {out session run failed {jobId {}} {expected {}}} {
    _scientificExecutionImageOutputGuard $out $session $run $expected
    set observe [dict create category protected_authoritative lifetime session session $session owner_pid [pid] recovery_required $failed]
    if {$jobId ne {}} {
        set job [scriptJobDescribe $jobId]
        if {$jobId ne $run || [dict get $job session] ne $session || [dict get $job output_dir] ne $out} {error {Submitted image Job does not own its sealed snapshot}}
        dict set observe job_id $jobId
    }
    # Original observation inventories protected Session bytes. It grants no
    # deletion authority, queued quota or transferred child/runtime lease.
    return [resourceManagementObserve $out scientific_execution_image_snapshots $observe]
}
proc ::GX::_scientificExecutionImageMaterializePrepared {prepared} {
    set encoded [dict get $prepared values request]
    set request [encoding convertfrom utf-8 [binary decode base64 $encoded]]
    if {![dict exists $request image_profile]} {return $prepared}
    if {[dict get $request image_profile] ne {image_resource_files_v1}} {error {Unknown scientific image capture profile}}
    set provider [dict get $request provider_id]
    set registered [_scientificExecutionImageProviderActivate $request]
    set worker [scriptModuleSafeRelative $::GX::scriptDir [dict get $registered worker]]
    if {$worker ne [dict get $request worker] || [sha256File $worker] ne [dict get $request worker_sha256] ||
        [sha256File [file join $::GX::scriptDir core python gxtxt_scientific_execution.py]] ne [dict get $request adapter_sha256]} {error {Scientific image worker/adapter changed}}
    dict for {relative expected} [dict get $request runtime_files] {if {[sha256File [scriptModuleSafeRelative $::GX::scriptDir $relative]] ne $expected} {error {Scientific image runtime source changed}}}
    set factsTool [_scientificExecutionImageFactsTool [dict get $request image_recipe]]
    if {$factsTool ne {}} {
        if {![dict exists $request image_facts_tool] || [dict get $request image_facts_tool] ne $factsTool ||
            ![dict exists $request tools quantitative_raster_native] || [dict get $request tools quantitative_raster_native] ne [dict get $factsTool tool_path]} {error {Scientific source facts fixed tool changed before capture}}
        dict for {relative expected} [dict get $factsTool runtime_files] {if {![dict exists $request runtime_files $relative] || [dict get $request runtime_files $relative] ne $expected} {error {Scientific source facts runtime identity is incomplete}}}
    } elseif {[dict exists $request image_facts_tool]} {error {Unrequested Scientific source facts tool binding}}
    set resources [dict get $request image_resource_sources]
    set sourceProfile [datasetPublicationV2DictDefault $request image_source_profile {}]
    if {$sourceProfile ne {}} {
        # The cold Job preparer has not necessarily queried a Dataset identity.
        # Use the same original digest loader as retained image-output reads.
        if {![llength [info commands ::GX::apiCatalogNative]]} {load [file join $::GX::scriptDir core api_catalog libgxtxt_api_catalog[info sharedlibextension]] Gxtxt_api_catalog}
        if {$sourceProfile ne {native_canvas_document_v1} || ![dict exists $request image_native_projection] ||
            ![dict exists $request image_native_canonical_sources] || ![dict exists $request image_native_projection_sha256] ||
            [apiCatalogNative digest [binary encode base64 -maxlen 0 [encoding convertto utf-8 [dict get $request image_native_projection]]]] ne [dict get $request image_native_projection_sha256]} {error {Scientific Canvas capture binding changed}}
    }
    set options [dict get $request image_capture_options];dict set options image_recipe [dict get $request image_recipe]
    set current [_scientificExecutionImageSourceRecords $resources $options {} $sourceProfile $provider]
    if {$current ne [dict get $request image_input_sources]} {error {Scientific image inputs changed before snapshot}}
    _scientificExecutionSourcesCurrent [dict get $request source_identities]
    set out [dict get $prepared outDir];set run [dict get $prepared runId];set session [dict get $prepared session]
    if {$out ne [file join $session analysis scripts $run] || [file type $out] ne {directory}} {error {Scientific image snapshot is outside the original fresh Job}}
    set imageCaptureOutputIdentity [_scientificExecutionImageOutputGuard $out $session $run]
    # Only this newly created ScriptExecution output leaf; never an old Session.
    file attributes $out -permissions 0700
    set total 0;dict for {alias source} $current {incr total [dict get $source input_bytes]}
    # Original Supervisor policy is read-only, current and local. It is a read
    # snapshot, not a quota lease; original launch still owns final admission.
    set budgetPolicy [scriptJobPolicyRead]
    if {[dict get $budgetPolicy schema] ne {gxtxt.job_policy.v1} || ![string is entier -strict [dict get $budgetPolicy policy temp_mib]] || [dict get $budgetPolicy policy temp_mib]<1} {error {Original local Job temporary budget is unavailable}}
    set budgetBytes [expr {wide([dict get $budgetPolicy policy temp_mib])*1048576}]
    if {2*wide($total)>$budgetBytes} {error {Original local Job temporary budget cannot reserve both source capture and verification}}
    set allocation [resourceManagementAllocate scientific_execution_images [dict create kind directory lifetime operation session $session \
        owner_pid [pid] expected_bytes [expr {2*$total}] descendant_lease 1]]
    set prior {};foreach key {GXTXT_RESOURCE_LEASE GXTXT_RESOURCE_ROOT GXTXT_RESOURCE_STORAGE} {dict set prior $key [list [info exists ::env($key)] [expr {[info exists ::env($key)]?$::env($key):{}}]]}
    set imageCaptureFailed 0;set imageCaptureSealed 0;set imageCapturePhase capture;set imageCaptureHandedOff 0
    try {
        set ::env(GXTXT_RESOURCE_LEASE) [dict get $allocation id]
        set ::env(GXTXT_RESOURCE_ROOT) [resourceManagementRoot]
        set ::env(GXTXT_RESOURCE_STORAGE) [file dirname [dict get $allocation envelope]]
        set envelope [dict create profile image_resource_files_v1 session $session output $out run_id $run reservation [dict get $allocation id] \
            parent_pid [pid] parent_identity [dict get $allocation owner_identity] sources $current]
        if {$sourceProfile ne {}} {
            dict set envelope source_profile $sourceProfile
            dict set envelope native_projection_sha256 [dict get $request image_native_projection_sha256]
        }
        set helper [file join $::GX::scriptDir core python scientific_image_materializer_v1.py]
        set code [catch {exec [runtimeToolRequired python] -I -B $helper capture << $envelope} response]
        if {[catch {dict get $response ok} ok] || !$ok || $code} {error {Scientific image byte capture failed; no worker launched}}
        set captured [dict get $response result];set imageCaptureSealed 1;set imageCapturePhase source_recheck
        set after [_scientificExecutionImageSourceRecords $resources $options {} $sourceProfile $provider]
        if {$after ne $current} {error {Scientific image source changed while sealing}}
        _scientificExecutionSourcesCurrent [dict get $request source_identities]
        dict unset captured reservation
        dict unset request image_input_sources
        dict set request image_input_snapshot $captured
        set sealed [binary encode base64 -maxlen 0 [encoding convertto utf-8 $request]]
        set runtime [dict get $prepared runtime]
        if {$runtime ne [file join $out runtime.ini] || [file type $runtime] ne {file}} {error {Scientific image runtime is not its fresh original file}}
        set imageCapturePhase runtime_seal
        set ini [parseIni $runtime]
        # scriptExecutionPrepare originally emits script_parameter.request.value
        # only. The image seal adds the second explicit projection; it never
        # accepts a disagreeing pre-existing projection or missing owner input.
        if {![dict exists $ini script_parameter.request.value] || [dict get $ini script_parameter.request.value] ne $encoded} {error {Scientific image runtime request preimage differs}}
        if {[dict exists $ini parameters.request] && [dict get $ini parameters.request] ne $encoded} {error {Scientific image runtime secondary request preimage differs}}
        set before [dict remove $ini script_parameter.request.value parameters.request]
        dict set ini script_parameter.request.value $sealed;dict set ini parameters.request $sealed
        _projectIniWrite $runtime $ini
        set written [parseIni $runtime]
        foreach field {script_parameter.request.value parameters.request} {if {[dict get $written $field] ne $sealed} {error {Scientific image sealed runtime mismatch}}}
        if {[dict remove $written script_parameter.request.value parameters.request] ne $before} {error {Scientific image runtime unrelated fields changed}}
        # The durable Job parameters MUST carry exactly the same sealed DTO.
        dict set prepared values request $sealed
        dict set prepared image_input_snapshot $captured
        dict set prepared image_job_budget [dict create estimated_temporary_bytes $budgetBytes policy_sha256 [dict get $budgetPolicy policy_sha256]]
        # Keep this SAME preparer PID's operation reservation until actual
        # Supervisor submission. It is never a transferred child/runtime lease.
        dict set prepared image_capture_allocation $allocation
        dict set prepared image_capture_output_identity $imageCaptureOutputIdentity
        set imageCaptureHandedOff 1
        return $prepared
    } on error {message context} {
        set imageCaptureFailed 1
        set recoveryError {}
        if {$imageCaptureSealed} {
            if {[catch {_scientificExecutionImageObserveSnapshot $out $session $run 1 {} $imageCaptureOutputIdentity} recoveryError]} {
                set recoveryError "Protected sealed-input recovery observation failed: $recoveryError"
            } else {set recoveryError {}}
        }
        catch {_scientificExecutionImageCaptureFailure $out $imageCapturePhase $message $imageCaptureSealed $recoveryError}
        return -options $context $message
    } finally {
        dict for {key value} $prior {lassign $value existed old;if {$existed} {set ::env($key) $old} else {unset -nocomplain ::env($key)}}
        # exec completed/drained before the real owner releases this lease.
        # Cleanup errors must not hide an earlier source/capture exception.
        set cleanupCode 0
        if {!$imageCaptureHandedOff} {set cleanupCode [catch {
            resourceManagementRelease [dict get $allocation id]
            resourceManagementCleanup [list [dict get $allocation id]]
        } cleanupError cleanupContext]}
        if {$cleanupCode} {
            catch {_scientificExecutionImageCaptureFailure $out cleanup $cleanupError $imageCaptureSealed $cleanupError}
            if {!$imageCaptureFailed} {return -options $cleanupContext $cleanupError}
        }
    }
}
proc ::GX::_scientificExecutionImageCaptureFailure {out phase message sealed cleanupError {jobId {}}} {
    _scientificExecutionImageOutputGuard $out [file dirname [file dirname [file dirname $out]]] [file tail $out]
    set value [dict create schema gxtxt.scientific.image_capture_failure.v1 phase $phase error $message inputs_sealed $sealed cleanup_error $cleanupError]
    if {$jobId eq {}} {dict set value job_launched 0} else {
        dict set value job_id $jobId;dict set value job_admitted 1
        dict set value job_launch_observation {Not asserted here; inspect the existing durable Job state}
    }
    set node [nativeWorkspaceEncode {record {schema text phase text error text inputs_sealed bool job_launched bool job_admitted bool job_id text job_launch_observation text cleanup_error text}} $value]
    resourceLifecycleWriteBytes [file join $out scientific-image-capture-FAILED.json] [encoding convertto utf-8 [nativeWorkspaceJsonEncode $node]]
}

# The image provider's large immutable outputs use this original owner's
# managed auxiliary transport. No caller path or private process handle escapes.
namespace eval ::GX::ScientificImageImport {variable serial 0;variable tasks {};variable waits {}}
proc ::GX::_scientificExecutionImagePersistedReference {reference owner} {
    set document [dict get $reference document_id]
    if {[dict get $owner id] ne $document || [dict get $owner generation] ne [dict get $reference owner_generation]} {error {Scientific Resource owner generation changed}}
    # The original authoritative Workspace/collection scanner, not a marker
    # extracted from an arbitrary caller string or an application model.
    foreach stored [interactiveDocumentResourceReferences [dict get $owner payload] $document] {
        set equal 1
        foreach field {api_id document_id owner_generation sha256 size_bytes} {
            if {![dict exists $stored $field] || [dict get $stored $field] ne [dict get $reference $field]} {set equal 0;break}
        }
        if {!$equal} continue
        foreach field {source_job_id source_output_token source_generation} {
            if {![dict exists $stored metadata $field] || ![dict exists $reference metadata $field] ||
                [dict get $stored metadata $field] ne [dict get $reference metadata $field]} {set equal 0;break}
        }
        if {$equal} {return 1}
    }
    return 0
}
proc ::GX::_scientificExecutionImageResourceOwner {reference} {
    # Generic retained image ownership. A module remains responsible for its
    # own provider/model/recipe/precision facts; none are inferred here.
    if {![dict exists $reference owner_generation]} {error {Scientific image requires complete Resource owner generation}}
    interactiveDocumentResourceInfo $reference
    set owner [interactiveDocumentRead [dict get $reference document_id]]
    if {[dict get $owner generation] ne [dict get $reference owner_generation]} {error {Scientific image belongs to a replaced Document}}
    set metadata [dict get $reference metadata]
    foreach field {source_job_id source_output_token source_generation} {if {![dict exists $metadata $field]} {return {}}}
    set job [_scientificExecutionJob [dict get $metadata source_job_id]]
    if {![dict exists $job scientific_request image_profile] || [dict get $job scientific_request image_profile] ne {image_resource_files_v1} ||
        ![regexp {^[A-Za-z][A-Za-z0-9_.-]*$} [dict get $job scientific_request provider_id]]} {return {}}
    if {[dict get $job state] ne {COMPLETED}} {error {Scientific image has no owned COMPLETED producing Job}}
    set identities [dict get $job scientific_request source_identities]
    if {[catch {_scientificExecutionSourcesCurrent $identities} reason context]} {
        # Preserve the existing historical relation only for an ALREADY
        # persisted exact Resource/Job/token/generation, or a still-live proof
        # issued by the original managed-copy owner from such a source.
        # Canonical and other guards still run; no caller skip-currentness.
        set transfer {}
        if {![_scientificExecutionImagePersistedReference $reference $owner]} {
            set transfer [_managedResourceCopyProofCurrent $reference]
            if {$transfer eq {}} {return -options $context $reason}
        }
        _scientificExecutionSourcesCurrent [dict remove $identities workspace]
        if {$transfer ne {} && [_managedResourceCopyProofCurrent $reference] ne $transfer} {error {Scientific retained copy owner changed during source verification}}
    }
    return [dict create job $job owner $owner reference $reference session_token [interactiveDocumentSessionToken]]
}
proc ::GX::_scientificExecutionImageResourceRead {reference {selection reference}} {
    if {$selection ni {reference outputs}} {error {Unknown finite retained image read selection}}
    set proof [_scientificExecutionImageResourceOwner $reference]
    if {$proof eq {}} {error {Resource has no owned completed scientific image Job}}
    set job [dict get $proof job];set id [dict get $job id]
    set envelope [_scientificExecutionImageEnvelopeFromJob $job]
    set action describe
    if {$selection eq {reference}} {
        set token [dict get $reference metadata source_output_token]
        set generation [dict get $reference metadata source_generation]
        if {![string is entier -strict $generation] || $generation<1} {error {Invalid retained image output generation}}
        if {[regexp {^input-[a-f0-9]{64}$} $token]} {
            set aliases [dict merge [dict get $job scientific_request image_capture_options image_sources] [dict get $job scientific_request image_resource_sources]]
            set found 0
            dict for {alias source} $aliases {
                if {[apiCatalogNative digest "$id:$alias"] eq [string range $token 6 end]} {dict set envelope input_alias $alias;set found 1;break}
            }
            if {!$found} {error {Retained input token is outside its immutable Job capture}}
            set action describe_original
        } elseif {![regexp {^output-[a-f0-9]{64}$} $token]} {error {Invalid retained image output token}}
        dict set envelope output_token $token;dict set envelope generation $generation
    }
    set key retained-[incr ::GX::ScientificImageImport::serial]
    set command [list [runtimeToolRequired python] -I -B [file join $::GX::scriptDir core python scientific_image_materializer_v1.py] $action]
    scriptJobAsync $command $envelope [list ::GX::_scientificExecutionImageWaitDone $key] [dict create label {Retained scientific image identity} ui_lifetime 0]
    while {![dict exists $::GX::ScientificImageImport::waits $key]} {vwait ::GX::ScientificImageImport::waits}
    set response [dict get $::GX::ScientificImageImport::waits $key];dict unset ::GX::ScientificImageImport::waits $key
    if {![dict get $response ok]} {error {Original immutable scientific image identity/manifest verification failed}}
    if {[dict get $proof session_token] ne [interactiveDocumentSessionToken]} {error {Scientific image Session changed during verification}}
    set current [_scientificExecutionImageResourceOwner $reference]
    if {$current eq {} || [dict get $current owner] ne [dict get $proof owner] ||
        [dict get $current job scientific_request] ne [dict get $proof job scientific_request]} {error {Retained scientific image source changed during verification}}
    return [dict get $response result]
}
proc ::GX::_scientificExecutionImageContextProject {job} {
    set request [dict get $job scientific_request]
    set workspace [datasetPublicationV2DictDefault [dict get $request source_identities] workspace {}]
    if {$workspace ne {}} {_scientificExecutionImageFields $workspace {id generation revision sha256}}
    set resources [datasetPublicationV2DictDefault $request image_resource_sources {}]
    set canonical [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $request image_capture_options {}] image_sources {}]
    if {[dict exists $request image_native_canonical_sources]} {set canonical [dict get $request image_native_canonical_sources]}
    # Application recipes/projections remain inert producer data. CORE does not
    # interpret their private schema or infer scientific application facts.
    return [dict create job_id [dict get $job id] provider_id [dict get $request provider_id] state [dict get $job state] \
        recipe [dict get $request image_recipe] workspace_guard $workspace input_sources $resources canonical_sources $canonical \
        native_projection [datasetPublicationV2DictDefault $request image_native_projection {}] \
        native_projection_sha256 [datasetPublicationV2DictDefault $request image_native_projection_sha256 {}]]
}
proc ::GX::scientificExecutionImageJobContext {id} {
    # Live publication uses the full original source guard. The persisted
    # Resource exception is deliberately unavailable to a bare Job identifier.
    set job [_scientificExecutionPublicationJob $id]
    if {[dict get $job state] ne {COMPLETED} ||
        ![dict exists $job scientific_request image_profile] ||
        [dict get $job scientific_request image_profile] ne {image_resource_files_v1}} {error {Image context requires an owned completed image-profile Job}}
    return [_scientificExecutionImageContextProject $job]
}
proc ::GX::scientificExecutionImageJobFacts {id} {
    # Inert facts from the SAME owned completed Job and full original source
    # checks. No serialized request, provider binding, command, tool path,
    # input bytes, preparation or admission record crosses this boundary.
    set job [_scientificExecutionPublicationJob $id]
    set request [dict get $job scientific_request]
    if {[dict get $job state] ne {COMPLETED} ||
        [datasetPublicationV2DictDefault $request image_profile {}] ne {image_resource_files_v1}} {error {Image facts require an owned completed image-profile Job}}
    set facts {}
    foreach key {image_profile image_source_profile image_recipe image_resource_sources image_native_projection image_native_projection_sha256 image_native_canonical_sources} {
        if {[dict exists $request $key]} {dict set facts $key [dict get $request $key]}
    }
    set options [dict get $request image_capture_options];set capture {}
    foreach key {image_sources dataset_sources} {
        dict set capture $key [datasetPublicationV2DictDefault $options $key {}]
    }
    dict set facts image_capture_options $capture
    dict set facts image_input_snapshot [dict create sha256 [dict get $request image_input_snapshot sha256]]
    if {[dict exists $request image_facts_tool]} {dict set facts image_facts_tool [dict create binary_sha256 [dict get $request image_facts_tool binary_sha256]]}
    set original [dict get $request source_identities];set identities {}
    foreach key {session_origin workspace datasets} {
        if {[dict exists $original $key]} {dict set identities $key [dict get $original $key]}
    }
    dict for {alias reference} [dict get $request image_resource_sources] {
        # Project the ACTUAL source guard, never manufacture one from a ref:
        # application validation must still detect a conflicting association.
        set guard [dict get $original $alias]
        _scientificExecutionImageFields $guard {api_id document_id owner_generation sha256 size_bytes}
        dict set identities $alias $guard
    }
    dict set facts source_identities $identities
    return [dict create job_id [dict get $job id] provider_id [dict get $request provider_id] \
        provider_version [dict get $request provider_version] state [dict get $job state] \
        request_sha256 [nativeWorkspaceMetadataDigest [dict get $job parameters request]] validation_context $facts]
}
proc ::GX::scientificExecutionImageResourceContext {reference} {
    set proof [_scientificExecutionImageResourceOwner $reference]
    if {$proof eq {}} {return {}}
    set job [dict get $proof job];set request [dict get $job scientific_request]
    set result [_scientificExecutionImageContextProject $job]
    set current [_scientificExecutionImageResourceOwner $reference]
    if {$current eq {} || [dict get $current owner] ne [dict get $proof owner] || \
        [dict get $current job scientific_request] ne $request || [dict get $current session_token] ne [dict get $proof session_token]} {error {Scientific image context changed while reading provenance}}
    return $result
}
proc ::GX::scientificExecutionImageResourceObserve {reference {selection reference}} {
    # Closed facts only; no raw Job, envelope, helper path, action or callback.
    # Dimensions/recipe/precision rules belong to the registered application,
    # which reads its ORIGINAL inspector facts in this verified summary.
    set proof [_scientificExecutionImageResourceOwner $reference]
    if {$proof eq {}} {error {Resource has no owned completed scientific image Job}}
    set observed [_scientificExecutionImageResourceRead $reference $selection]
    if {$selection eq {outputs}} {
        set current [_scientificExecutionImageResourceOwner $reference]
        if {$current eq {} || [dict get $current owner] ne [dict get $proof owner] || \
            [dict get $current job scientific_request] ne [dict get $proof job scientific_request] || \
            [dict get $current session_token] ne [dict get $proof session_token]} {error {Scientific image owner changed during observation}}
        return [dict create outputs [dict get $observed outputs] summary [dict get $observed summary]]
    }
    if {[dict exists $observed original_input]} {
        set output [dict get $observed original_input]
        set all [_scientificExecutionImageResourceRead $reference outputs]
        set summary [dict get $all summary]
    } else {
        if {[llength [dict get $observed outputs]]!=1} {error {Retained scientific output observation is ambiguous}}
        set output [lindex [dict get $observed outputs] 0];set summary [dict get $observed summary]
    }
    foreach field {sha256 size_bytes} {if {[dict get $output $field] ne [dict get $reference $field]} {error {Retained scientific output differs from its exact Resource bytes}}}
    if {[dict get $output token] ne [dict get $reference metadata source_output_token] || \
        [dict get $output source_generation] ne [dict get $reference metadata source_generation] || \
        [dict get $output job_id] ne [dict get $reference metadata source_job_id] || \
        [dict get $output live] || [dict get $output availability] ne {available}} {error {Retained scientific output receipt changed}}
    set current [_scientificExecutionImageResourceOwner $reference]
    if {$current eq {} || [dict get $current owner] ne [dict get $proof owner] || \
        [dict get $current job scientific_request] ne [dict get $proof job scientific_request] || \
        [dict get $current session_token] ne [dict get $proof session_token]} {error {Scientific image owner changed during observation}}
    return [dict create output $output summary $summary]
}
proc ::GX::_scientificExecutionImageOutputEnvelope {id {token {}} {generation {}}} {
    set job [_scientificExecutionPublicationJob $id]
    return [_scientificExecutionImageEnvelopeFromJob $job $token $generation]
}
# Structural envelope only, shared by current adoption and independently proven
# retained Document reads. Its private caller must supply the original Job owner
# record after its appropriate source/lifetime checks; no public weaker switch.
proc ::GX::_scientificExecutionImageEnvelopeFromJob {job {token {}} {generation {}}} {
    set id [dict get $job id]
    if {[dict get $job state] ne {COMPLETED} ||
        ![regexp {^[A-Za-z][A-Za-z0-9_.-]*$} [dict get $job scientific_request provider_id]] ||
        ![dict exists $job scientific_request image_profile] ||
        [dict get $job scientific_request image_profile] ne {image_resource_files_v1}} {error {Image output requires its owned COMPLETED image-profile Job}}
    set session [_interactiveDocumentRequireSession]
    set out [dict get $job output_dir]
    if {$out ne [file join $session analysis scripts $id]} {error {Image output is outside its original Job snapshot}}
    if {$token ne {} && ![regexp {^output-[a-f0-9]{64}$} $token]} {error {Invalid original image output token}}
    if {$generation ne {} && (![string is entier -strict $generation] || $generation<1)} {error {Invalid original image output generation}}
    # Cold retained-result reads need the same original native digest loader
    # used by quantitative source identity; no Catalog refresh/cache is needed.
    if {![llength [info commands ::GX::apiCatalogNative]]} {load [file join $::GX::scriptDir core api_catalog libgxtxt_api_catalog[info sharedlibextension]] Gxtxt_api_catalog}
    return [dict create profile image_resource_files_v1 session $session output $out run_id $id job_id $id \
        request_sha256 [apiCatalogNative digest [dict get $job parameters request]] output_token $token generation $generation]
}
proc ::GX::_scientificExecutionImageOutputsAsync {id callback} {
    set envelope [_scientificExecutionImageOutputEnvelope $id]
    set command [list [runtimeToolRequired python] -I -B [file join $::GX::scriptDir core python scientific_image_materializer_v1.py] describe]
    return [scriptJobAsync $command $envelope [list ::GX::_scientificExecutionImageOutputsDone $id [interactiveDocumentSessionToken] $callback] \
        [dict create label {Scientific image output description} ui_lifetime 0]]
}
proc ::GX::_scientificExecutionImageOutputsDone {id sessionToken callback response} {
    if {[catch {
        if {$sessionToken ne [interactiveDocumentSessionToken]} {error {Scientific image output Session changed}}
        _scientificExecutionImageOutputEnvelope $id
        if {![dict get $response ok]} {error {Scientific image output manifest/identity verification failed}}
    } reason]} {set response [dict create ok 0 error $reason]}
    if {$callback ne {}} {uplevel #0 [list {*}$callback $response]}
}
proc ::GX::_scientificExecutionImageWaitDone {key response} {dict set ::GX::ScientificImageImport::waits $key $response}
proc ::GX::_scientificExecutionImageOutputs {id} {
    set key output-[incr ::GX::ScientificImageImport::serial]
    _scientificExecutionImageOutputsAsync $id [list ::GX::_scientificExecutionImageWaitDone $key]
    while {![dict exists $::GX::ScientificImageImport::waits $key]} {vwait ::GX::ScientificImageImport::waits}
    set response [dict get $::GX::ScientificImageImport::waits $key];dict unset ::GX::ScientificImageImport::waits $key
    if {![dict get $response ok]} {error [dict get $response error]}
    return [dict get $response result]
}
proc ::GX::_scientificExecutionImageImportGuard {task} {
    if {[dict get $task session_token] ne [interactiveDocumentSessionToken]} {error {Scientific image import Session changed}}
    if {[dict get $task cancelled]} {error {Scientific image import cancelled}}
    _scientificExecutionPublicationGuard [dict get $task guard]
    if {[dict get $task input_alias] eq {}} {
        set current [_scientificExecutionImageOutputEnvelope [dict get $task job] [dict get $task output token] [dict get $task output source_generation]]
    } else {set current [_scientificExecutionImageOriginalEnvelope [dict get $task job] [dict get $task input_alias] [dict get $task output token] [dict get $task output source_generation]]}
    if {$current ne [dict get $task envelope]} {error {Scientific image immutable Job/source changed during import}}
}
proc ::GX::_scientificExecutionImageImport {id output guard callback {inputAlias {}}} {
    _scientificExecutionImageFields $guard {document_id generation revision sha256}
    _scientificExecutionPublicationGuard $guard
    foreach field {token source_generation size_bytes sha256 role format live} {if {![dict exists $output $field]} {error {Image import requires the complete observed output descriptor}}}
    if {[dict get $output live] || ![regexp {^[a-f0-9]{64}$} [dict get $output sha256]] ||
        ![string is entier -strict [dict get $output size_bytes]] || [dict get $output size_bytes]<0} {error {Image import requires immutable exact bytes}}
    if {$inputAlias eq {}} {
        set envelope [_scientificExecutionImageOutputEnvelope $id [dict get $output token] [dict get $output source_generation]]
    } else {set envelope [_scientificExecutionImageOriginalEnvelope $id $inputAlias [dict get $output token] [dict get $output source_generation]]}
    set reservation [_resourceManagementAllocateScoped scientific_execution_image_import [dict create kind directory lifetime operation \
        session [_interactiveDocumentRequireSession] job_id $id owner_pid [pid] expected_bytes [dict get $output size_bytes] descendant_lease 1]]
    set allocation [dict get $reservation allocation];set cleanupScope [dict get $reservation scope]
    set ticket scientific-image-import-[incr ::GX::ScientificImageImport::serial]
    set writer {};set request {}
    try {
        _resourceManagementScopeGuard $cleanupScope [dict get $allocation id] release
        set metadata [dict create format [dict get $output format] origin scientific_job source_job_id $id source_output_token [dict get $output token] \
            source_generation [dict get $output source_generation] source_sha256 [dict get $output sha256] scientific_authority 1]
        if {$inputAlias ne {}} {
            if {[dict exists $output source_dataset_id]} {
                dict set metadata source_kind canonical_dataset
                dict set metadata source_dataset_id [dict get $output source_dataset_id]
            } else {dict set metadata source_kind scientific_io_local}
        }
        set writer [interactiveDocumentResourceOpenWriter [dict get $guard document_id] $metadata]
        set task [dict create job $id output $output guard $guard envelope $envelope writer $writer allocation $allocation cleanup_scope $cleanupScope callback $callback \
            session_token [interactiveDocumentSessionToken] input_alias $inputAlias offset 0 phase ready cancelled 0 complete 0 request {} error {}]
        dict set ::GX::ScientificImageImport::tasks $ticket $task
        set prior {};foreach key {GXTXT_RESOURCE_LEASE GXTXT_RESOURCE_ROOT GXTXT_RESOURCE_STORAGE} {dict set prior $key [list [info exists ::env($key)] [expr {[info exists ::env($key)]?$::env($key):{}}]]}
        try {
            _resourceManagementScopeGuard $cleanupScope [dict get $allocation id] release
            set ::env(GXTXT_RESOURCE_LEASE) [dict get $allocation id]
            set ::env(GXTXT_RESOURCE_ROOT) [dict get $cleanupScope root]
            set ::env(GXTXT_RESOURCE_STORAGE) [dict get $cleanupScope storage]
            set action [expr {$inputAlias eq {}?{stream}:{stream_original}}]
            set command [list [runtimeToolRequired python] -I -B [file join $::GX::scriptDir core python scientific_image_materializer_v1.py] $action]
            set payload [binary encode base64 -maxlen 0 [encoding convertto utf-8 $envelope]]
            append payload \n
            set request [scriptJobAsync $command $payload [list ::GX::_scientificExecutionImageImportDone $ticket] \
                [dict create duplex 1 max_bytes 2097152 send_pending_bytes 65536 label {Scientific image held-output import} ui_lifetime 0]]
        } finally {
            dict for {key value} $prior {lassign $value existed old;if {$existed} {set ::env($key) $old} else {unset -nocomplain ::env($key)}}
        }
        dict set ::GX::ScientificImageImport::tasks $ticket request $request
        after 1 [list ::GX::_scientificExecutionImageImportStep $ticket]
        return $ticket
    } on error {message context} {
        if {$request ne {}} {
            # The registered terminal callback owns cleanup after real drain.
            dict set ::GX::ScientificImageImport::tasks $ticket error $message
            scriptJobRequestCancel $request
        } else {
            if {$writer ne {}} {catch {interactiveDocumentResourceAbort $writer}}
            # Preserve the same original reservation scope even on an early
            # admission error; never recompute globals for deferred cleanup.
            set task [dict create job $id output $output guard $guard envelope $envelope writer $writer allocation $allocation cleanup_scope $cleanupScope callback {} \
                session_token [interactiveDocumentSessionToken] input_alias $inputAlias offset 0 phase failed cancelled 0 complete 0 request {} error $message]
            dict set ::GX::ScientificImageImport::tasks $ticket $task
            _scientificExecutionImageCleanupStart $ticket [dict create ok 0 error $message] 0
        }
        return -options $context $message
    }
}
proc ::GX::_scientificExecutionImageImportCancel {ticket} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} {return 0}
    if {[dict exists $::GX::ScientificImageImport::tasks $ticket cleanup_notified] && [dict get $::GX::ScientificImageImport::tasks $ticket cleanup_notified]} {return 0}
    dict set ::GX::ScientificImageImport::tasks $ticket cancelled 1
    if {[dict exists $::GX::ScientificImageImport::tasks $ticket cleanup_epoch]} {
        set task [dict get $::GX::ScientificImageImport::tasks $ticket]
        # Cancellation invalidates adoption, not the original owner's right to
        # retire this exact temporary reservation. Never cancel its Release.
        _scientificExecutionImageCleanupAdoption $ticket [dict get $task cleanup_epoch] cancelled
        return 1
    }
    scriptJobRequestCancel [dict get $::GX::ScientificImageImport::tasks $ticket request]
    return 1
}
proc ::GX::_scientificExecutionImageImportStep {ticket} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} return
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {[dict get $task complete] || [dict get $task error] ne {}} return
    set code [catch {
        # Empty pipe servicing is presentation work, not a new byte boundary.
        # Recheck cheap lifetime/cancel state here; expensive original source
        # and Job admission checks run once for each complete received page.
        if {[dict get $task session_token] ne [interactiveDocumentSessionToken] || [dict get $task cancelled]} {error {Scientific image import lifetime ended}}
        set request [dict get $task request]
        set drained [scriptJobRequestDrain $request 1]
        # Drain can call the terminal callback and retire this task.
        if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} return
        if {![dict get $drained active] || [dict get $drained cancelled] ne {}} {error {Scientific image output reader ended before complete acknowledgement}}
        foreach frame [dict get $drained messages] {
            _scientificExecutionImageImportGuard $task
            if {[catch {dict size $frame}] || ![dict exists $frame kind]} {error {Malformed scientific image stream frame}}
            switch -- [dict get $frame kind] {
                ready {
                    if {[dict get $task phase] ne {ready}} {error {Unexpected image stream ready frame}}
                    foreach field {token source_generation size_bytes role format live} {
                        if {[dict get $frame $field] ne [dict get $task output $field]} {error {Scientific image stream descriptor changed}}
                    }
                    dict set task phase chunks
                    scriptJobRequestSend $request next
                }
                chunk {
                    _scientificExecutionImageFields $frame {kind offset count bytes_base64}
                    if {[dict get $task phase] ne {chunks} || [dict get $frame offset] ne [dict get $task offset] ||
                        ![string is entier -strict [dict get $frame count]] || [dict get $frame count]<1 || [dict get $frame count]>1048576 ||
                        [string length [dict get $frame bytes_base64]]>1398104} {error {Invalid scientific image stream page}}
                    set bytes [binary decode base64 -strict [dict get $frame bytes_base64]]
                    if {[string length $bytes]!=[dict get $frame count] || [binary encode base64 -maxlen 0 $bytes] ne [dict get $frame bytes_base64] ||
                        [dict get $task offset]+[string length $bytes]>[dict get $task output size_bytes]} {error {Image stream page exceeds its reserved byte count}}
                    _scientificExecutionImageImportGuard $task
                    interactiveDocumentResourceAppend [dict get $task writer] $bytes
                    dict incr task offset [string length $bytes]
                    scriptJobRequestSend $request next
                }
                complete {
                    _scientificExecutionImageFields $frame {kind size_bytes sha256 source_generation}
                    if {[dict get $task phase] ne {chunks} || [dict get $task offset]!=[dict get $task output size_bytes]} {error {Incomplete scientific image byte stream}}
                    foreach field {size_bytes sha256 source_generation} {if {[dict get $frame $field] ne [dict get $task output $field]} {error {Scientific image output changed before final acknowledgement}}}
                    _scientificExecutionImageImportGuard $task
                    dict set task complete 1;dict set task phase drained
                    scriptJobRequestSend $request ack
                }
                default {error {Scientific image reader refused its source/manifest guard}}
            }
        }
        dict set ::GX::ScientificImageImport::tasks $ticket $task
        if {![dict get $task complete]} {after 1 [list ::GX::_scientificExecutionImageImportStep $ticket]}
    } reason context]
    if {$code && [dict exists $::GX::ScientificImageImport::tasks $ticket]} {
        dict set ::GX::ScientificImageImport::tasks $ticket error $reason
        scriptJobRequestCancel [dict get $task request]
    }
}
proc ::GX::_scientificExecutionImageImportDone {ticket response} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} return
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {[dict exists $task cleanup_epoch]} return
    set writer [dict get $task writer]
    set finalized 0
    set code [catch {
        if {[dict get $task error] ne {}} {error [dict get $task error]}
        if {![dict get $task complete] || [dict get $task phase] ne {drained}} {error {Scientific image output reader stopped before completion}}
        if {[dict exists $response error_type] && [dict get $response error_type] ne {closed}} {error {Scientific image output reader was cancelled}}
        _scientificExecutionImageImportGuard $task
        set reference [interactiveDocumentResourceFinalize $writer];set finalized 1
        if {![dict exists $reference owner_generation] || [dict get $reference owner_generation] ne [dict get $task guard generation] ||
            [dict get $reference sha256] ne [dict get $task output sha256] || [dict get $reference size_bytes]!=[dict get $task output size_bytes]} {error {Final Resource differs from its held scientific output}}
        _scientificExecutionImageImportGuard $task
        set result [dict create ok 1 result $reference]
    } reason]
    if {$code} {if {!$finalized} {catch {interactiveDocumentResourceAbort $writer}};set result [dict create ok 0 error $reason]}
    # EOF/escalation is not itself a retirement certificate. Keep this SAME
    # task, primary outcome and finalized flag while the unchanged Resource
    # authority decides whether its descendant reservation may be released.
    _scientificExecutionImageCleanupStart $ticket $result $finalized
}
proc ::GX::_scientificExecutionImageCleanupStart {ticket result finalized} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} return
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {[dict exists $task cleanup_epoch]} return
    dict set task primary_result $result;dict set task finalized $finalized
    dict set task cleanup_epoch [incr ::GX::ScientificImageImport::serial]
    dict set task cleanup_allocation_id [dict get $task allocation id]
    set originalScope {};if {[dict exists $task cleanup_scope]} {set originalScope [dict get $task cleanup_scope]}
    dict set task cleanup_scope_snapshot $originalScope
    dict set task cleanup_attempts {};dict set task cleanup_count 0
    dict set task cleanup_inflight {};dict set task cleanup_timer {}
    dict set task cleanup_release_confirmed 0;dict set task cleanup_notified 0
    dict set task cleanup_removed_confirmed 0;dict set task adoption_invalidations {}
    dict set task cleanup_phase preparing
    dict set ::GX::ScientificImageImport::tasks $ticket $task
    _scientificExecutionImageCleanupAdoption $ticket [dict get $task cleanup_epoch] start
    if {[catch {set now [_resourceManagementMonotonicMs]} cleanup]} {
        _scientificExecutionImageCleanupFinish $ticket [dict get $task cleanup_epoch] 0 $cleanup
        return
    }
    dict set ::GX::ScientificImageImport::tasks $ticket cleanup_started_ms $now
    # At most3 Release helpers and1 Cleanup: each admits the original SQLite10s
    # busy wait plus1000ms startup/completion. The original100/250ms backoffs and
    # all ownership/adoption checks consume this SAME finite absolute budget.
    dict set ::GX::ScientificImageImport::tasks $ticket cleanup_deadline_ms [expr {$now+44350}]
    _scientificExecutionImageCleanupDispatch $ticket [dict get $task cleanup_epoch] release
}

# HOST_ONLY: continuation of the existing source-admitted image import. No new
# Resource grant, reference adoption, executor or scientific Job is introduced.
proc ::GX::_scientificExecutionImageCleanupGuard {ticket epoch {phase release}} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} {error {Image cleanup task ended}}
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {![dict exists $task cleanup_epoch] || [dict get $task cleanup_epoch] ne $epoch ||
        [dict get $task cleanup_allocation_id] ne [dict get $task allocation id]} {error {Image cleanup task identity changed}}
    if {![dict exists $task cleanup_scope]} {error {Original image reservation scope was not captured}}
    if {[dict get $task cleanup_scope] ne [dict get $task cleanup_scope_snapshot]} {error {Original image reservation scope changed}}
    _resourceManagementScopeGuard [dict get $task cleanup_scope] [dict get $task cleanup_allocation_id] $phase
    return $task
}
proc ::GX::_scientificExecutionImageCleanupAdoption {ticket epoch where} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket cleanup_epoch] || [dict get $::GX::ScientificImageImport::tasks $ticket cleanup_epoch] ne $epoch} return
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {[dict get $task cleanup_notified]} return
    if {[catch {_scientificExecutionImageImportGuard $task} reason]} {
        dict lappend task adoption_invalidations [dict create where $where error $reason cancelled [dict get $task cancelled]]
        dict set ::GX::ScientificImageImport::tasks $ticket $task
    }
}
proc ::GX::_scientificExecutionImageCleanupDispatch {ticket epoch phase} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket cleanup_epoch] || [dict get $::GX::ScientificImageImport::tasks $ticket cleanup_epoch] ne $epoch} return
    _scientificExecutionImageCleanupAdoption $ticket $epoch before_$phase
    if {[catch {set task [_scientificExecutionImageCleanupGuard $ticket $epoch $phase];set now [_resourceManagementMonotonicMs]} reason]} {
        _scientificExecutionImageCleanupFinish $ticket $epoch 0 $reason;return
    }
    if {[dict get $task cleanup_inflight] ne {} || [dict get $task cleanup_notified]} return
    dict set task cleanup_timer {}
    if {$now>=[dict get $task cleanup_deadline_ms]} {_scientificExecutionImageCleanupFinish $ticket $epoch 0 {Image reservation cleanup admission deadline expired};return}
    set count [dict get $task cleanup_count]
    if {$phase eq {release}} {
        if {$count>=3} {_scientificExecutionImageCleanupFinish $ticket $epoch 0 {Image reservation cleanup retry limit reached};return}
        incr count;dict set task cleanup_count $count
        set arguments [list resource_id [dict get $task cleanup_allocation_id] state verified_orphan]
    } elseif {$phase eq {cleanup} && [dict get $task cleanup_release_confirmed]} {set arguments [list [dict get $task cleanup_allocation_id]]
    } else {_scientificExecutionImageCleanupFinish $ticket $epoch 0 {Invalid image cleanup phase};return}
    dict set task cleanup_phase $phase
    dict lappend task cleanup_attempts [dict create phase $phase attempt $count started_ms $now]
    dict set ::GX::ScientificImageImport::tasks $ticket $task
    if {[catch {set token [_resourceManagementBoundedAsync $phase $arguments [list ::GX::_scientificExecutionImageCleanupDone $ticket $epoch $phase $count] 11000 [dict get $task cleanup_scope] [dict get $task cleanup_deadline_ms]]} reason]} {
        _scientificExecutionImageCleanupFinish $ticket $epoch 0 $reason;return
    }
    dict set ::GX::ScientificImageImport::tasks $ticket cleanup_inflight $token
    # The constructor does not pump events; still repeat the original guards
    # before this request becomes an asynchronously waiting continuation.
    _scientificExecutionImageCleanupAdoption $ticket $epoch after_dispatch_$phase
    if {[catch {_scientificExecutionImageCleanupGuard $ticket $epoch $phase} reason]} {_resourceManagementBoundedCancel $token ownership_changed}
}
proc ::GX::_scientificExecutionImageCleanupDone {ticket epoch phase count code output lifecycle} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} return
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {![dict exists $task cleanup_epoch] || [dict get $task cleanup_epoch] ne $epoch || [dict get $task cleanup_phase] ne $phase ||
        [dict get $task cleanup_inflight] ne [dict get $lifecycle request] || [dict get $task cleanup_count]!=$count || [dict get $task cleanup_notified]} return
    set rows [dict get $task cleanup_attempts];set row [lindex $rows end]
    dict set row code $code;dict set row output $output;dict set row lifecycle $lifecycle
    set rows [lreplace $rows end end $row];dict set task cleanup_attempts $rows
    if {[dict get $lifecycle terminal_verified]} {dict set task cleanup_inflight {}}
    set released 0;set cleaned 0
    if {!$code && [dict get $lifecycle terminal_verified] && [dict get $lifecycle retirement_verified] && ![dict get $lifecycle protected]} {
        if {$phase eq {release}} {
            if {![catch {dict size $output;set same [expr {[dict get $output id] eq [dict get $task cleanup_allocation_id] &&
                [dict get $output released] eq {1} && [dict get $output removed] eq {0} && [dict get $output state] eq {verified_orphan} &&
                [dict get $output managed] eq {1} && [dict get $output recovery_required] eq {0} &&
                [dict get $output owner_pid] eq [dict get $task cleanup_scope owner_pid] && [dict get $output owner_identity] eq [dict get $task cleanup_scope owner_identity] &&
                [dict get $output envelope] eq [dict get $task cleanup_scope envelope] && [dict get $output identity] eq [dict get $task cleanup_scope allocation_identity] }]}] && $same} {set released 1;dict set task cleanup_release_confirmed 1}
        } else {
            if {![catch {set item [lindex $output 0];set same [expr {[llength $output]==1 && [dict get $item id] eq [dict get $task cleanup_allocation_id] &&
                [dict get $item path] eq [dict get $task cleanup_scope envelope] && [dict get $item result] in {removed already_removed}}]}] && $same} {set cleaned 1;dict set task cleanup_removed_confirmed 1}
        }
    }
    dict set ::GX::ScientificImageImport::tasks $ticket $task
    _scientificExecutionImageCleanupAdoption $ticket $epoch after_reply_$phase
    if {[catch {_scientificExecutionImageCleanupGuard $ticket $epoch [expr {$cleaned?{removed}:$phase}];set now [_resourceManagementMonotonicMs]} reason]} {
        if {$cleaned} {
            # The original authority confirmed removal. A later proof failure
            # cannot undo that fact or allow adoption from an uncertain scope.
            set current [dict get $::GX::ScientificImageImport::tasks $ticket]
            dict lappend current ownership_post_cleanup_errors $reason
            dict lappend current adoption_invalidations [dict create where ownership_after_removed error $reason cancelled [dict get $current cancelled]]
            dict set ::GX::ScientificImageImport::tasks $ticket $current
            _scientificExecutionImageCleanupFinish $ticket $epoch 1 {};return
        }
        _scientificExecutionImageCleanupFinish $ticket $epoch 0 $reason;return
    }
    if {$released} {_scientificExecutionImageCleanupDispatch $ticket $epoch cleanup;return}
    if {$cleaned} {_scientificExecutionImageCleanupFinish $ticket $epoch 1 {};return}
    # Only exact original Release refusal, verified terminal child and no
    # uncertainty may retry. SQLite/owner/schema/timeout/ambiguous replies do not.
    if {$phase eq {release} && $code && [dict get $lifecycle terminal_verified] && [dict get $lifecycle retirement_verified] && ![dict get $lifecycle protected] &&
        [dict get $lifecycle reason] eq {} && [dict get $lifecycle exit_status] eq {1} && $output eq {Live or unverifiable child still holds this resource lease} && $count<3} {
        set delay [lindex {100 250} [expr {$count-1}]]
        if {$now+$delay<[dict get $task cleanup_deadline_ms]} {
            dict set ::GX::ScientificImageImport::tasks $ticket cleanup_phase backoff
            dict set ::GX::ScientificImageImport::tasks $ticket cleanup_timer [after $delay [list ::GX::_scientificExecutionImageCleanupDispatch $ticket $epoch release]]
            return
        }
    }
    set reason [expr {$output ne {}?$output:{Original Resource cleanup reply was not confirmed}}]
    _scientificExecutionImageCleanupFinish $ticket $epoch 0 $reason
}
proc ::GX::_scientificExecutionImageCleanupFinish {ticket epoch cleaned reason} {
    if {![dict exists $::GX::ScientificImageImport::tasks $ticket]} return
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {![dict exists $task cleanup_epoch] || [dict get $task cleanup_epoch] ne $epoch || [dict get $task cleanup_notified]} return
    if {[dict get $task cleanup_timer] ne {}} {after cancel [dict get $task cleanup_timer];dict set task cleanup_timer {}}
    dict set ::GX::ScientificImageImport::tasks $ticket $task
    _scientificExecutionImageCleanupAdoption $ticket $epoch finish
    set task [dict get $::GX::ScientificImageImport::tasks $ticket]
    if {[dict get $task cleanup_removed_confirmed]} {set cleaned 1}
    set primary [dict get $task primary_result]
    set invalid [dict get $task adoption_invalidations]
    if {$cleaned && [llength $invalid]==0} {
        set result $primary
        if {![dict get $primary ok]} {
            dict set result operation_ok 0;dict set result operation_error [dict get $primary error]
            dict set result finalized [dict get $task finalized];dict set result cleanup_state complete
            dict set result cleanup_attempts [dict get $task cleanup_attempts];dict set result adoption_invalidations $invalid
        }
    } elseif {$cleaned} {
        set operationError [expr {![dict get $primary ok]?[dict get $primary error]:[dict get [lindex $invalid 0] error]}]
        set result [dict create ok 0 error $operationError operation_ok [dict get $primary ok] finalized [dict get $task finalized] \
            cleanup_state complete cleanup_attempts [dict get $task cleanup_attempts] adoption_invalidations $invalid]
        if {![dict get $primary ok]} {dict set result operation_error [dict get $primary error]}
    } else {
        set result [dict create ok 0 error {Scientific image import reservation cleanup remains protected} cleanup_error $reason \
            operation_ok [dict get $primary ok] finalized [dict get $task finalized] cleanup_state protected cleanup_attempts [dict get $task cleanup_attempts]]
        dict set result adoption_invalidations $invalid
        if {![dict get $primary ok]} {dict set result operation_error [dict get $primary error]}
    }
    dict set task cleanup_notified 1;dict set task cleanup_phase [expr {$cleaned?{complete}:{protected}}]
    dict set task cleanup_result $result
    if {$cleaned && [dict get $result ok]} {dict unset ::GX::ScientificImageImport::tasks $ticket} else {dict set ::GX::ScientificImageImport::tasks $ticket $task}
    set callback [dict get $task callback]
    if {$callback ne {}} {uplevel #0 [list {*}$callback $result]}
}

# Only the original source-qualified preparer's in-process record reaches this
# helper. No caller argument or durable Job ENV carries this allocation.
proc ::GX::_scientificExecutionImagePreparedFinish {prepared jobId failed} {
    if {![dict exists $prepared image_capture_allocation]} return
    set allocation [dict get $prepared image_capture_allocation]
    set out [dict get $prepared outDir];set session [dict get $prepared session]
    set code [catch {
        _scientificExecutionImageObserveSnapshot $out $session [dict get $prepared runId] $failed $jobId [datasetPublicationV2DictDefault $prepared image_capture_output_identity {}]
    } reason context]
    set cleanupCode [catch {
        resourceManagementRelease [dict get $allocation id]
        resourceManagementCleanup [list [dict get $allocation id]]
    } cleanupError cleanupContext]
    if {$code || $cleanupCode} {
        catch {_scientificExecutionImageCaptureFailure $out admission_accounting [expr {$code?$reason:{}}] 1 [expr {$cleanupCode?$cleanupError:{}}] $jobId}
        if {$code} {return -options $context $reason}
        return -options $cleanupContext $cleanupError
    }
}

# Private original-source capture: aliases are resolved from the actual sealed
# immutable Job request. The public output-resource method cannot select this
# transport or manufacture an input alias/token by putting markers in args.
proc ::GX::_scientificExecutionImageOriginalEnvelope {id alias {token {}} {generation {}}} {
    if {![regexp {^[A-Za-z_][A-Za-z0-9_]{0,63}$} $alias]} {error {Invalid captured original image alias}}
    set envelope [_scientificExecutionImageOutputEnvelope $id]
    set job [_scientificExecutionJob $id]
    if {![dict exists $job scientific_request image_capture_options image_sources $alias] &&
        ![dict exists $job scientific_request image_resource_sources $alias]} {error {Original image alias is outside the immutable Job capture}}
    if {$token ne {} && ![regexp {^input-[a-f0-9]{64}$} $token]} {error {Invalid original input observation token}}
    if {$generation ne {} && (![string is entier -strict $generation] || $generation<1)} {error {Invalid original input observation generation}}
    dict set envelope input_alias $alias
    dict set envelope output_token $token
    dict set envelope generation $generation
    return $envelope
}
proc ::GX::_scientificExecutionImageOriginalAsync {id alias callback} {
    set envelope [_scientificExecutionImageOriginalEnvelope $id $alias]
    set command [list [runtimeToolRequired python] -I -B [file join $::GX::scriptDir core python scientific_image_materializer_v1.py] describe_original]
    return [scriptJobAsync $command $envelope [list ::GX::_scientificExecutionImageOutputsDone $id [interactiveDocumentSessionToken] $callback] \
        [dict create label {Original sealed image description} ui_lifetime 0]]
}
proc ::GX::_scientificExecutionImageOriginal {id alias} {
    set key original-[incr ::GX::ScientificImageImport::serial]
    _scientificExecutionImageOriginalAsync $id $alias [list ::GX::_scientificExecutionImageWaitDone $key]
    while {![dict exists $::GX::ScientificImageImport::waits $key]} {vwait ::GX::ScientificImageImport::waits}
    set response [dict get $::GX::ScientificImageImport::waits $key];dict unset ::GX::ScientificImageImport::waits $key
    if {![dict get $response ok]} {error [dict get $response error]}
    return [dict get $response result original_input]
}
