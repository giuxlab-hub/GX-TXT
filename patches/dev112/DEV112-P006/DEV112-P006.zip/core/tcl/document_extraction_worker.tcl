# SPDX-License-Identifier: GPL-3.0-or-later
# Managed CORE helper; original services do all decoding/OCR/reconstruction.
lassign $argv framework requestPath
source [file join $framework gxtxt_pipeline.tcl]
::GX::defaults
set f [open $requestPath r];set request [read $f];close $f
# All subprocess temporary files stay inside the existing resource allocation,
# including when cancellation terminates a tool before its finally block.
set ::env(TMPDIR) [dict get $request directory]
proc python {operation} {
    set request $::request
    dict set request python_operation $operation
    set path [file join [dict get $request directory] python.tcldict]
    set f [open $path w];fconfigure $f -encoding utf-8;puts $f $request;close $f
    return [exec [::GX::runtimeToolRequired python] -B [file join $::framework core python gxtxt_document_extraction_worker.py] $path 2>@1]
}
proc run {} {
    set path [dict get $::request path];set sha [dict get $::request sha256]
    if {[::GX::sha256File $path] ne $sha} {error {Canonical source changed before processing}}
    set pdf [expr {[dict get $::request contract] eq {document.pdf}}]
    set page [dict get $::request page];set dpi [dict get $::request dpi]
    set opts [dict create languages [dict get $::request languages] psm [dict get $::request psm] dpi $dpi method [dict get $::request method] roi_mode crop]
    if {[dict get $::request scope] eq {Region} && [dict get $::request roi] ne {}} {dict set opts roi [dict get $::request roi]}
    switch [dict get $::request operation] {
        render {
            set pages 1
            if {$pdf} {
                set info [::GX::OCRLayoutAPIv1::pdfInfo $path];set pages [dict get $info page_count]
                set page [expr {max(1,min($pages,$page))}];dict set ::request page $page
                set image [file join [dict get $::request directory] rendered.png]
                ::GX::OCRLayoutAPIv1::renderPdfPage $path $page $image [dict create dpi $dpi]
            } else {set image $path}
            dict set ::request image_path $image
            set result [python preview];dict set result page $page;dict set result page_count $pages
            dict set result languages [::GX::OCRLayoutAPIv1::languages]
        }
        zoom {set result [python preview]}
        crop {set result [python crop]}
        ocr {
            if {[dict get $::request ocr_engine] eq {PDF OCR}} {
                if {[dict get $::request scope] eq {Document} && $pdf} {
                    set result [::GX::OCRLayoutAPIv1::recognizePdfText $path $opts]
                } else {
                    set crop [python crop]
                    set result [dict create text [::GX::OCRLayoutAPIv1::recognizeImageText [dict get $crop output_path] $opts] method tesseract]
                }
            } else {
                if {$pdf} {
                    if {[dict get $::request scope] eq {Document}} {set layout [::GX::OCRLayoutAPIv1::extractPdfDocument $path $opts]
                    } else {set layout [::GX::OCRLayoutAPIv1::extractPdfPage $path $page $opts]}
                } else {set layout [::GX::OCRLayoutAPIv1::extractImage $path $opts]}
                set result [dict create text [::GX::OCRLayoutAPIv1::toText $layout] method [dict get $::request method] roi_mode crop]
            }
        }
        table {
            dict set opts expected_columns [dict get $::request expected_columns]
            if {[dict get $::request table_engine] eq {Table Extractor}} {
                dict set opts minimum_rows 2
                dict set opts minimum_columns 2
                dict set opts native_minimum_columns [expr {max(2,[dict get $::request expected_columns])}]
                dict set opts split_repeated_headers 0
            }
            if {$pdf} {set result [::GX::TableExtractorAPIv1::extractPdfPage $path $page $opts]
            } else {set result [::GX::TableExtractorAPIv1::extractImage $path $opts]}
            if {[dict get $result table_count]<1} {error {No table could be reconstructed; adjust the region or extraction options}}
            set index [expr {max(0,min([dict get $result table_count]-1,[dict get $::request table_index]-1))}]
            set selected [lindex [dict get $result tables] $index]
            dict set result rows [dict get $selected matrix]
            dict set result method [dict get $result source method]
            dict set result selected_index [expr {$index+1}]
            dict unset result tables
        }
        schema {
            set table [dict create matrix [dict get $::request rows]]
            set schema [::GX::TableExtractorAPIv1::inferSchema $table [dict create first_row_header [dict get $::request header] normalize_numeric 1 ascii_header_ids [expr {[dict get $::request table_engine] eq {Table Extractor}}] monthly_title_header [expr {[dict get $::request table_engine] eq {Document Tables}}]]]
            set result [dict create columns [dict get $schema columns] rows [dict get $schema data_rows] title [::GX::datasetPublicationV2DictDefault $schema title {}]]
        }
        searchable_pdf {
            if {!$pdf} {error {Searchable PDF generation requires a canonical PDF Dataset}}
            set result [::GX::OCRLayoutAPIv1::createSearchablePdf $path [file join [dict get $::request directory] searchable.pdf] $opts]
        }
        default {error {Unsupported managed document operation}}
    }
    if {[::GX::sha256File $path] ne $sha} {error {Canonical source changed during processing}}
    return $result
}
if {[catch run result options]} {
    puts [dict create ok 0 error $result]
    exit 1
}
puts [dict create ok 1 result $result]
