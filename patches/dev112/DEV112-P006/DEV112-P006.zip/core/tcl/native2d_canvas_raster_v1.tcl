# SPDX-License-Identifier: GPL-3.0-or-later
# Canvas raster edits reuse existing Scientific Execution, Script Job,
# Document Resource and canonical Dataset File Publication authorities.
proc ::GX::native2DCanvasRasterProvenance {reference} {
    # Closed trusted-host provenance over the SAME original raster producer,
    # reader and Resource owners. This is not an arbitrary Job/freeze facade.
    nativeWorkspaceEncode {resource {named resource_metadata}} $reference
    interactiveDocumentResourceInfo $reference
    set session [_interactiveDocumentRequireSession]
    foreach field {source_job_id source_output_token source_generation} {
        if {![dict exists $reference metadata $field]} {error {Native raster Resource has no original producing receipt}}
    }
    set id [dict get $reference metadata source_job_id]
    set job [_scientificExecutionJob $id];set request [dict get $job scientific_request]
    if {[dict get $job state] ne {COMPLETED} || [dict get $request provider_id] ne {core.native2d.raster} ||
        [dict get $request parameters operation] ni {canvas_filter canvas_flatten}} {error {Resource is not an owned completed original Canvas raster}}
    set operation [dict get $request parameters operation]
    set identities [dict remove [dict get $request source_identities] workspace]
    _scientificExecutionSourcesCurrent $identities
    set token [dict get $reference metadata source_output_token]
    set generation [dict get $reference metadata source_generation]
    if {![regexp {^[1-9][0-9]*$} $generation] || $generation>9223372036854775807} {error {Native raster provenance requires its exact positive output generation}}
    set actual [_scientificExecutionOutput $id freeze $token 0 16777216 $generation]
    if {[dict get $actual job_id] ne $id || [dict get $actual token] ne $token ||
        [dict get $actual source_generation] ne $generation || [dict get $actual role] ne {raster} ||
        [dict get $actual availability] ne {available} || [dict get $actual live] || ![dict get $actual complete] ||
        [dict get $actual sha256] ne [dict get $reference sha256] || [dict get $actual size_bytes] ne [dict get $reference size_bytes]} {error {Native Resource differs from its exact immutable completed raster output}}
    set raw [binary decode base64 -strict [dict get $request inputs composition]]
    if {[string length $raw]>8388608} {error {Native composition exceeds its original prepared input bound}}
    set manifest [encoding convertfrom utf-8 $raw]
    set identity [dict get $request source_identities composition]
    if {![llength [info commands ::GX::apiCatalogNative]]} {load [file join $::GX::scriptDir core api_catalog libgxtxt_api_catalog[info sharedlibextension]] Gxtxt_api_catalog}
    if {[encoding convertto utf-8 $manifest] ne $raw || [string length $raw] ne [dict get $identity size_bytes] ||
        [apiCatalogNative digest $manifest] ne [dict get $identity sha256] || [dict get $manifest schema] ne {gxtxt.native2d.canvas_raster.v1}} {error {Original Native composition input identity changed}}
    set resources {}
    if {$operation eq {canvas_filter}} {
        if {![dict exists $manifest source_resource]} {error {Historical Native filter has no exact source Resource association}}
        dict set resources [dict get $manifest source_alias] [dict get $manifest source_resource]
        if {[dict get $manifest source_sha256] ne [dict get $manifest source_resource sha256]} {error {Native filter input SHA differs from its manifest}}
    } else {
        set snapshot [dict get $manifest snapshot];native2DCanvasSnapshotValidate $snapshot 0
        foreach item [dict get $snapshot objects] {
            if {![dict exists $item resource metadata image_resource]} continue
            set alias [dict get $manifest aliases [dict get $item logical_id] image]
            set input [dict get $item resource metadata image_resource]
            if {[dict exists $resources $alias] && [dict get $resources $alias] ne $input} {error {Native image input alias has conflicting owners}}
            dict set resources $alias $input
        }
    }
    dict for {alias input} $resources {
        nativeWorkspaceEncode {resource {named resource_metadata}} $input
        if {![dict exists $input owner_generation]} {error {Native image input lacks its original Document generation}}
        foreach field {api_id document_id owner_generation sha256 size_bytes} {
            if {[dict get $input $field] ne [dict get $request source_identities $alias $field]} {error {Native image input Resource identity changed}}
        }
        set captured [binary decode base64 -strict [dict get $request inputs $alias]]
        if {[string length $captured]>8388608 || [string length $captured] ne [dict get $input size_bytes] ||
            [datasetStorageSha256Bytes $session $captured] ne [dict get $input sha256]} {error {Native captured image input bytes differ from their original Resource}}
        interactiveDocumentResourceInfo $input
    }
    # No new adoption authority: repeat original Session/source/Resource/Job
    # guards after the reader and all original Resource observations.
    _scientificExecutionSourcesCurrent $identities
    interactiveDocumentResourceInfo $reference
    set current [_scientificExecutionJob $id]
    if {[_interactiveDocumentRequireSession] ne $session || [dict get $current state] ne {COMPLETED} ||
        [dict get $current scientific_request] ne $request} {error {Native raster producer or Session changed during provenance capture}}
    return [dict create operation $operation manifest $manifest output [dict remove $actual bytes_base64] \
        source_bindings [dict create resources $resources canonical_sources [datasetPublicationV2DictDefault $identities datasets {}]]]
}
proc ::GX::_nativeCanvasRasterStamp {handle} {
    set row [_nativeCanvasRequire $handle]
    return [dict create handle $handle native [dict get $row native] document [dict get $row document] \
        receipt [dict get $row receipt] session [dict get $row session] sequence [dict get $row sequence]]
}
proc ::GX::_nativeCanvasRasterCurrent {handle stamp {allowViewOnlyPan 0}} {
    set row [_nativeCanvasRequire $handle]
    foreach key {native document receipt session sequence} {
        if {[dict get $row $key] ne [dict get $stamp $key]} {error {Canvas raster result is stale; no result adopted}}
    }
    set state [[dict get $row native] state scalar]
    if {[dict get $state gesture]} {
        set viewOnlyPan 0
        if {$allowViewOnlyPan && [dict get $state tool] eq {pan} && [dict get $row pending] ne {}} {
            set admitted [_nativeCanvasExtensionCall $handle pending_view adopt {}]
            set viewOnlyPan [expr {$admitted ne {} && $admitted}]
            set row [_nativeCanvasRequire $handle]
            foreach key {native document receipt session sequence} {
                if {[dict get $row $key] ne [dict get $stamp $key]} {error {Canvas changed during registered pending-view admission}}
            }
        }
        if {!$viewOnlyPan} {error {Canvas gesture is active; no asynchronous raster adopted}}
    }
    _nativeCanvasAdmitSources $row
    return $row
}
proc ::GX::_nativeCanvasRasterFilterParameters {request} {
    _nativeCanvasFields $request {object name parameters} name
    set name [dict get $request name]
    if {$name ni {grayscale invert brightness_contrast blur sharpen}} {error {Unsupported fixed Canvas filter}}
    set values [datasetPublicationV2DictDefault $request parameters {}]
    set allowed {};if {$name eq {brightness_contrast}} {set allowed {brightness contrast}} elseif {$name in {blur sharpen}} {set allowed radius}
    _nativeCanvasFields $values $allowed
    set result [dict create effect [expr {$name eq {invert}?{negate}:$name}]]
    dict for {key value} $values {
        if {$key eq {radius}} {dict set result effect_radius [_nativeCanvasNumber $value 0 16 {Filter radius (source pixels)}]} else {
            dict set result $key [_nativeCanvasNumber $value -100 100 {Brightness/contrast (percent)}]
        }
    }
    return $result
}
proc ::GX::_nativeCanvasRasterLeaf {snapshot logical} {
    foreach item [dict get $snapshot objects] {if {[dict get $item logical_id] eq $logical} {return $item}}
    error {Canvas raster target is not an owned leaf object}
}
proc ::GX::_nativeCanvasRasterEditable {snapshot item} {
    set style [dict get $item style]
    if {[dict get $style locked] || ![dict get $style visible] || ![dict get $style selectable]} {error {Canvas raster object is locked, hidden or unselectable}}
    foreach layer [dict get $snapshot layers] {
        if {[dict get $layer logical_id] ne [dict get $item layer_logical_id]} continue
        set properties [dict get $layer properties]
        if {[dict get $properties locked] || ![dict get $properties visible] || ![dict get $properties selectable]} {error {Canvas raster layer is locked, hidden or unselectable}}
        return
    }
    error {Canvas raster object has no owned layer}
}
proc ::GX::_nativeCanvasRasterManifest {row snapshot operation request} {
    set document [dict get $row document]
    set manifest [dict create schema gxtxt.native2d.canvas_raster.v1 document_id $document \
        document_generation [dict get $row receipt generation] document_revision [dict get $row receipt revision] canvas_id [dict get $snapshot canvas_id]]
    set resources {};set aliases {};set index 0
    if {$operation eq {filter}} {
        set target [datasetPublicationV2DictDefault $request object {}]
        if {$target eq {}} {
            if {[llength [dict get $snapshot selection]]!=1} {error {Select exactly one owned raster object for filtering}}
            set target [lindex [dict get $snapshot selection] 0]
        }
        set item [_nativeCanvasRasterLeaf $snapshot $target]
        _nativeCanvasRasterEditable $snapshot $item
        set metadata [dict get $item resource metadata]
        if {![dict exists $metadata reference_image] || ![dict exists $metadata image_resource]} {error {Canvas filter requires an existing native raster image}}
        set reference [dict get $metadata image_resource]
        interactiveDocumentResourceInfo $reference
        dict set resources source $reference
        dict set manifest source_alias source
        dict set manifest source_sha256 [dict get $reference sha256]
        dict set manifest source_resource $reference
        dict set manifest target $target
        dict set manifest source_state [dict get $metadata reference_image]
    } else {
        if {![info exists ::env(DISPLAY)] || $::env(DISPLAY) eq {}} {error {Native mixed Canvas materialization requires the supported Tk display/font service}}
        dict set manifest display $::env(DISPLAY)
        dict set manifest snapshot $snapshot
        if {[llength [info commands tk]]} {dict set manifest tk_scaling [tk scaling]}
        set fonts {}
        foreach item [dict get $snapshot objects] {
            set logical [dict get $item logical_id]
            set reference [dict get $item resource]
            set alias leaf_[incr index]
            dict set resources $alias $reference
            dict set aliases $logical geometry $alias
            set metadata [dict get $reference metadata]
            if {[dict exists $metadata reference_image]} {
                set alias image_$index
                dict set resources $alias [dict get $metadata image_resource]
                dict set aliases $logical image $alias
            }
            if {[llength [info commands font]] && [dict exists $metadata sketch_attributes gx.canvas]} {
                set presentation [dict get $metadata sketch_attributes gx.canvas]
                if {[datasetPublicationV2DictDefault $presentation kind {}] eq {text}} {
                    set declared [datasetPublicationV2DictDefault $presentation font TkDefaultFont]
                    dict set fonts $declared [font actual $declared]
                }
            }
        }
        dict set manifest aliases $aliases
        dict set manifest fonts $fonts
    }
    set reference [managedResourceWrite $document {format native2d.canvas_raster_manifest.v1 origin native2d_canvas scientific_authority 1} [encoding convertto utf-8 $manifest]]
    dict set resources composition $reference
    return [dict create manifest $manifest resources $resources]
}
proc ::GX::_nativeCanvasRasterCommand {handle operation request} {
    if {$operation ni {filter flatten publish}} {error {Unknown managed Canvas raster operation}}
    set row [_nativeCanvasRequire $handle]
    if {[dict get $row pending] ne {}} {error {Cancel the pending Canvas operation before starting another}}
    set edit [_nativeCanvasEditCapture $handle]
    [dict get $row native] command cancel {}
    _nativeCanvasAdmitSources $row
    set snapshot [native2DCanvasCapture $handle]
    set parameters [dict create operation [expr {$operation eq {filter}?{canvas_filter}:{canvas_flatten}}]]
    if {$operation eq {filter}} {
        set parameters [dict merge $parameters [_nativeCanvasRasterFilterParameters $request]]
    } else {
        if {[datasetPublicationV2DictDefault $request precision rgba8] ne {rgba8} || [datasetPublicationV2DictDefault $request format png] ne {png}} {error {Canvas materialization supports explicit derived RGBA8 sRGB PNG only}}
        if {$operation eq {flatten}} {
            _nativeCanvasFields $request {layers precision}
            set all [lmap item [dict get $snapshot layers] {dict get $item logical_id}]
            set selected [datasetPublicationV2DictDefault $request layers $all]
            if {[lsort -unique $selected] ne [lsort $all] || [llength $selected]!=[llength $all]} {error {Partial Canvas flatten cannot preserve arbitrary backdrop blends; flatten the complete document}}
            foreach layer [dict get $snapshot layers] {
                if {[dict get $layer properties locked] || ![dict get $layer properties visible]} {error {Show and unlock all layers before flattening the complete Canvas}}
            }
            foreach item [dict get $snapshot objects] {_nativeCanvasRasterEditable $snapshot $item}
            foreach group [dict get $snapshot groups] {if {[dict get $group style locked] || ![dict get $group style visible]} {error {Hidden or locked groups cannot be flattened}}}
        } else {
            _nativeCanvasFields $request {dataset_id name format precision} dataset_id
            datasetPublicationV2ValidateId dataset [dict get $request dataset_id]
            if {[datasetField [dict get $request dataset_id] id {}] ne {}} {error {Canvas publication requires a new canonical Dataset identity}}
        }
    }
    set prepared {};set job {};set waiter {}
    try {
        set input [_nativeCanvasRasterManifest $row $snapshot $operation $request]
        set sourceIds {}
        foreach item [dict get $snapshot objects] {if {[dict exists $item source dataset_id]} {lappend sourceIds [dict get $item source dataset_id]}}
        set sourceIds [lsort -unique $sourceIds]
        set prepared [scientificExecutionPrepare core.native2d.raster $parameters [dict get $input resources] \
            [dict create node_id local document_id [dict get $row document] expected_revision [dict get $row receipt revision] dataset_sources $sourceIds]]
        dict set ::GX::NativeCanvas::instances $handle sequence [expr {[dict get $row sequence]+1}]
        dict set ::GX::NativeCanvas::instances $handle pending [list preparation $prepared]
        set stamp [_nativeCanvasRasterStamp $handle]
        dict set edit sequence [dict get $stamp sequence]
        dict set stamp edit $edit
        set submission [scientificExecutionSubmit $prepared];set prepared {}
        set job [dict get $submission job_id]
        dict set ::GX::NativeCanvas::instances $handle pending [list job $job]
        set command [list [info nameofexecutable] [file join $::GX::scriptDir core tcl native2d_canvas_raster_wait_v1.tcl] $::GX::scriptDir [scriptJobRoot] $job]
        set waiter [scriptJobAsync $command {} [list ::GX::_nativeCanvasRasterCompleted $handle $stamp $operation $request $snapshot [dict get $input manifest] $job] \
            {timeout_ms 190000 max_bytes 65536 process_group 1 ui_lifetime 1 label {Canvas managed raster completion}}]
        dict set ::GX::NativeCanvas::instances $handle pending [list job $job waiter $waiter]
        dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status pending operation $operation job_id $job]
        _nativeCanvasNotify $handle raster_pending
        return [dict create status pending operation $operation job_id $job]
    } on error {message options} {
        if {$prepared ne {}} {catch {scientificExecutionDiscard $prepared}}
        if {$job ne {}} {catch {scientificExecutionCancel $job}}
        if {$waiter ne {}} {catch {scriptJobRequestCancel $waiter canceled}}
        if {[dict exists $::GX::NativeCanvas::instances $handle]} {dict set ::GX::NativeCanvas::instances $handle pending {}}
        return -options $options $message
    }
}
proc ::GX::_nativeCanvasRasterGeometry {handle imageReference provenanceReference {original {}} {logical {}} {fullPrecision 0} {targetLogical {}} {extraAttributes {}} {removeAttributes {}}} {
    set row [_nativeCanvasRequire $handle]
    set scene [::GX::Native2D::core scene]
    try {
        if {$original ne {}} {
            set metadata [dict get $original resource metadata]
            set state [dict get $metadata reference_image]
            set logical [dict get $original logical_id]
            set attributes [datasetPublicationV2DictDefault $metadata sketch_attributes {}]
        } else {
            lassign [dict get [[dict get $row native] state scalar] extent] width height
            set state [dict create width $width height $height scale 1 rotation 0 translation {0 0} opacity 1 visible 1 locked 0 length_unit px]
            set attributes [dict create gx.canvas [dict create logical_id $logical kind image]]
        }
        if {$targetLogical ne {}} {set logical $targetLogical;dict set attributes gx.canvas logical_id $targetLogical}
        if {$extraAttributes ne {}} {set attributes [dict merge $attributes $extraAttributes]}
        foreach key $removeAttributes {dict unset attributes $key}
        if {$fullPrecision} {
            set dimensions [_native2DImageDimensions $imageReference]
            if {[llength $dimensions]!=2} {error {Full-precision geometry requires its actual verified image dimensions}}
            lassign $dimensions width height
            dict set state width $width;dict set state height $height
        }
        dict set state resource_id [dict get $imageReference sha256]
        set object [::GX::Native2D::core image_create $scene $state]
        native2DReferenceImageBind $scene $object $imageReference
        # ROI and image annotations still describe the same source-pixel frame,
        # but now bind explicitly to the accepted derived resource identity.
        foreach key {gx.image.rois gx.image.annotations} {
            if {![dict exists $attributes $key]} continue
            set collection [dict get $attributes $key]
            dict set collection source_resource_id [dict get $imageReference sha256]
            if {[dict exists $collection rois]} {
                dict for {id roi} [dict get $collection rois] {dict set roi source_resource_id [dict get $imageReference sha256];dict set collection rois $id $roi}
            }
            dict set attributes $key $collection
        }
        dict for {key value} $attributes {::GX::Native2D::core identity_attribute $scene $object $key $value}
        set role [expr {$fullPrecision?{original_full_precision}:{derived_rgba8_sRGB}}]
        return [interactiveDocumentNative2DStore [dict get $row document] $scene $object [dict create dependencies [list $provenanceReference] source_kind native2d_canvas_derived role $role]]
    } finally {
        native2DRasterSceneDispose $scene
        ::GX::Native2D::core destroy $scene
    }
}
proc ::GX::_nativeCanvasRasterCompleted {handle stamp operation request before manifest job response} {
    # A completed Job is durable under its existing owner. An obsolete callback
    # never freezes/adopts it into a replacement Canvas or another Session.
    if {[catch {_nativeCanvasRasterCurrent $handle $stamp} message]} {
        if {[dict exists $::GX::NativeCanvas::instances $handle]} {
            set raw [dict get $::GX::NativeCanvas::instances $handle]
            if {[dict get $raw native] eq [dict get $stamp native] && [dict get $raw sequence]==[dict get $stamp sequence] && [dict get $raw session] eq [dict get $stamp session]} {
                dict set ::GX::NativeCanvas::instances $handle pending {}
                dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status rejected operation $operation job_id $job error $message]
                catch {_nativeCanvasNotify $handle raster_rejected}
            }
        }
        return
    }
    set accepted 0
    try {
        if {![dict get $response ok]} {error [datasetPublicationV2DictDefault $response error {Canvas managed waiter failed}]}
        set status [scientificExecutionStatus $job]
        if {[dict get $status state] ne {COMPLETED}} {error "Canvas raster Job ended in [dict get $status state]; no result adopted"}
        set outputs [scientificExecutionOutputs $job];set found {}
        if {[datasetPublicationV2DictDefault $outputs validation {}] ne {validated_structure}} {error {Canvas raster provider did not validate its output structure}}
        foreach output [dict get $outputs outputs] {
            if {[dict get $output role] in {raster provenance}} {dict set found [dict get $output role] [dict get $output token]}
        }
        if {![dict exists $found raster] || ![dict exists $found provenance]} {error {Canvas raster Job omitted raster or provenance; no result adopted}}
        _nativeCanvasRasterCurrent $handle $stamp
        set raster [scientificExecutionFreezeResource $job [dict get $found raster] [dict get $stamp document]]
        set provenance [scientificExecutionFreezeResource $job [dict get $found provenance] [dict get $stamp document]]
        set row [_nativeCanvasRasterCurrent $handle $stamp]
        set next $before
        set currentPresentation [native2DCanvasCapture $handle]
        foreach key {view_state selection active_layer tool} {dict set next $key [dict get $currentPresentation $key]}
        dict lappend next retained_outputs $raster
        dict lappend next retained_outputs $provenance
        set publication {}
        if {$operation eq {filter}} {
            set target [dict get $manifest target];set original [_nativeCanvasRasterLeaf $before $target]
            set reference [_nativeCanvasRasterGeometry $handle $raster $provenance $original]
            set objects {}
            foreach item [dict get $before objects] {if {[dict get $item logical_id] eq $target} {dict set item resource $reference};lappend objects $item}
            dict set next objects $objects
        } elseif {$operation eq {flatten}} {
            set suffix [dict get $stamp sequence]-[clock clicks]
            set logical canvas_flatten_object_$suffix;set layer canvas_flatten_layer_$suffix
            set reference [_nativeCanvasRasterGeometry $handle $raster $provenance {} $logical]
            dict set next layers [list [dict create logical_id $layer name Flattened attributes [dict create gx.canvas [dict create logical_id $layer kind layer name Flattened blend Over]] \
                properties {visible 1 selectable 1 locked 0 order 0 opacity 1} blend Over]]
            dict set next objects [list [dict create logical_id $logical name {Flattened Canvas} resource $reference \
                style {visible 1 selectable 1 locked 0 order 0 line_style 0 marker 0 line_width 1 color {1 1 1 1}} layer_logical_id $layer]]
            dict set next groups {};dict set next selection [list $logical];dict set next active_layer $layer
            # The materialized pixels already contain the original background.
            dict set next background {0 0 0 0}
        } else {
            set sourceIds {}
            foreach item [dict get $before objects] {
                if {[dict exists $item source dataset_id]} {lappend sourceIds [dict get $item source dataset_id]}
            }
            set sourceIds [lsort -unique $sourceIds]
            set sourceFile [file join [_documentResourceRoot [dict get $row document]] [dict get $raster sha256].blob]
            set definition [dict create dataset_id [dict get $request dataset_id] contract image.raster format png storage_kind binary media_type image/png \
                source_file $sourceFile verified_source_sha256 [dict get $raster sha256] source_dataset_ids $sourceIds immutable 1 \
                provenance [dict create owner NATIVE2D_API_v1 document_id [dict get $row document] canvas_id [dict get $before canvas_id] \
                    raster_resource $raster provenance_resource $provenance precision rgba8_sRGB scientific_precision_preserved 0] \
                notes [datasetPublicationV2DictDefault $request name {Native Canvas derived RGBA8 sRGB composition}]]
            _nativeCanvasRasterCurrent $handle $stamp
            set publication [datasetAuthorityTransaction $::GX::currentSession ::GX::datasetFilePublicationPublish $::GX::currentSession [dict get $row module] $definition]
        }
        _nativeCanvasRasterCurrent $handle $stamp
        dict set ::GX::NativeCanvas::instances $handle pending {}
        set result [_nativeCanvasCommitSnapshot $handle [dict get $stamp edit] $next "Canvas $operation accepted (derived RGBA8 sRGB)"]
        set accepted 1
        dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status completed operation $operation job_id $job \
            raster_sha256 [dict get $raster sha256] provenance_sha256 [dict get $provenance sha256] publication [dict remove $publication path]]
        _nativeCanvasNotify $handle raster_completed
    } on error {message options} {
        if {[dict exists $::GX::NativeCanvas::instances $handle] && ![catch {_nativeCanvasRequire $handle}]} {
            dict set ::GX::NativeCanvas::instances $handle pending {}
            # Staged adoption did not mutate the accepted scene on refusal.
            # Restoring an old snapshot here could overwrite a newer selection
            # or foreign winner after an asynchronous guard failure.
            dict set ::GX::NativeCanvas::instances $handle raster_status [dict create status failed operation $operation job_id $job error $message]
            _nativeCanvasNotify $handle raster_failed
        }
    }
}

# Registered scientific owner opt-in; public/default RGBA8 API stays unchanged.
source [file join [file dirname [info script]] native2d_canvas_flatten_v1.tcl]
