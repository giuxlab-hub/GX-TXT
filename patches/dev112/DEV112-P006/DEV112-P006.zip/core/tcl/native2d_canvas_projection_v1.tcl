# SPDX-License-Identifier: GPL-3.0-or-later
# Generic original-Canvas annotation/frame capture. Held/Tk/native lifetimes
# remain host capabilities, not Script grants. Glyph coverage writes a disposable
# presentation-only Document Resource; no independent geometry/text renderer.
# Trusted-host ownership/classification is reviewed with the original adjacent
# native2d_canvas_api_v1.script_bridge_policy.json; no automatic Script grant.
proc ::GX::_nativeCanvasCaptureGlyph {handle held logical reference frameContext definition metadata canonicalScene canonicalDefinition} {
    set descriptor [datasetPublicationV2DictDefault $metadata font TkDefaultFont]
    set text [dict get $metadata text]
    # These are textAsset's bounds, not an application's narrower text grammar.
    if {[string bytelength $text]>8192} {error {Canvas text exceeds 8192 UTF8 bytes}}
    if {[string bytelength $descriptor]<1 || [string bytelength $descriptor]>512} {error {Canvas font descriptor exceeds 512 bytes}}
    set worldSize [_nativeCanvasNumber [datasetPublicationV2DictDefault $metadata font_size 12] 1 1200 font_size]
    set anchor [datasetPublicationV2DictDefault $metadata anchor nw]
    if {![llength [info commands font]] || ![llength [info commands ::gx::native2d::text_photo]]} {error {The original live Tk/native glyph owner is unavailable}}
    set actual [font actual $descriptor];set metrics [font metrics $descriptor]
    set facts [dict create descriptor $descriptor actual $actual metrics $metrics world_size $worldSize anchor $anchor]
    set scope [list [dict get $held native] [dict get $held document] [dict get $held receipt] [dict get $held session]]
    set key [dict create reference $reference frame_context $frameContext definition $definition canvas_metadata $metadata descriptor $descriptor actual $actual metrics $metrics world_size $worldSize anchor $anchor]
    set row [_nativeCanvasEditCurrent $handle $held]
    set cache [datasetPublicationV2DictDefault $row glyph_cache {}]
    set entry {};set hit 0
    if {[dict exists $cache scope] && [dict get $cache scope] eq $scope && [dict exists $cache entries $logical]} {
        set candidate [dict get $cache entries $logical];set equal 1
        # Compare exact fields without flattening/repeating a large shared frame
        # reference into each cache-key string. Cache remains weak and bounded.
        dict for {field value} $key {if {![dict exists $candidate key $field] || [dict get $candidate key $field] ne $value} {set equal 0;break}}
        if {$equal && ![catch {interactiveDocumentResourceInfo [dict get $candidate resource]}]} {set entry $candidate;set hit 1}
        _nativeCanvasEditCurrent $handle $held
    }
    set photo {};set writer {}
    try {
        if {!$hit} {
            set photo [image create photo]
            # Same original glyph/layout owner as textAsset; only unit WHITE
            # alpha coverage enters this presentation Resource, never science.
            set receipt [::gx::native2d::text_photo $photo $descriptor $text $anchor 0 {1 1 1 1}]
            _nativeCanvasEditCurrent $handle $held
            if {[font actual $descriptor] ne $actual || [font metrics $descriptor] ne $metrics} {error {Original Tk font changed while glyph coverage was captured}}
            if {[dict get $receipt width]!=[image width $photo] || [dict get $receipt height]!=[image height $photo]} {error {Original glyph receipt differs from its actual photo}}
            set bytes [$photo data -format png]
            _nativeCanvasEditCurrent $handle $held
            if {[binary encode hex [string range $bytes 0 7]] ne {89504e470d0a1a0a}} {error {Original Tk glyph formatter did not produce PNG}}
            set outputMetadata [dict create format png media_type image/png encoding png-alpha8 role native_tk_glyph_alpha scientific_authority 0 disposable 1 width [dict get $receipt width] height [dict get $receipt height] source_kind native_tk_glyph]
            set writer [interactiveDocumentResourceOpenWriter [dict get $held document] $outputMetadata]
            _nativeCanvasEditCurrent $handle $held
            for {set start 0} {$start<[string length $bytes]} {incr start 65536} {
                interactiveDocumentResourceAppend $writer [string range $bytes $start [expr {$start+65535}]]
                _nativeCanvasEditCurrent $handle $held
            }
            set resource [interactiveDocumentResourceFinalize $writer];set writer {}
            _nativeCanvasEditCurrent $handle $held
            set entry [dict create key $key resource $resource receipt $receipt]
            set row [_nativeCanvasEditCurrent $handle $held]
            set cache [datasetPublicationV2DictDefault $row glyph_cache {}]
            if {![dict exists $cache scope] || [dict get $cache scope] ne $scope} {set cache [dict create scope $scope entries {}]}
            # One replacement per actual leaf; abandoned/raw external identities
            # cannot grow this beyond the original held scene's identity bound.
            set valid {};foreach item [dict get $held snapshot objects] {dict set valid [dict get $item logical_id] 1}
            foreach old [dict keys [dict get $cache entries]] {if {![dict exists $valid $old]} {dict unset cache entries $old}}
            dict set cache entries $logical $entry
            dict set ::GX::NativeCanvas::instances $handle glyph_cache $cache
        }
        set receipt [dict get $entry receipt]
        # Exact original buildNative placement: local anchor controls[0],
        # offsets from text_photo, unit=worldSize/actual Tk linespace. Native
        # affine/device kernels do every subsequent coordinate transformation.
        if {[dict get $definition family] ne {rectangle} || [llength [dict get $definition controls]]!=2} {error {Canvas text requires an exact native rectangle anchor}}
        set unit [expr {$worldSize/double([dict get $metrics -linespace])}]
        lassign [lindex [dict get $definition controls] 0] ax ay
        lassign [dict get $receipt offset] dx dy
        set x [expr {$ax+$dx*$unit}];set y [expr {$ay-$dy*$unit}]
        set basis [::GX::Native2D::core pointset $canonicalScene [list [list $x $y] [list [expr {$x+$unit}] $y] [list $x [expr {$y-$unit}]]]]
        ::GX::Native2D::core affine $canonicalScene [list $basis] [dict get $canonicalDefinition matrix] 0
        set points [lmap p [::GX::Native2D::core points $canonicalScene $basis] {::GX::Native2D::core device $canonicalScene $p}]
        lassign [lindex $points 0] x y
        lassign [lindex $points 1] xx xy
        lassign [lindex $points 2] yx yy
        set matrix [list [expr {$xx-$x}] [expr {$xy-$y}] [expr {$yx-$x}] [expr {$yy-$y}] $x $y]
        dict set facts glyph_receipt $receipt
        set glyph [dict create resource [dict get $entry resource] width [dict get $receipt width] height [dict get $receipt height] matrix $matrix coverage_stage original_native_tk_glyph_alpha8_v1]
        set result [dict create font_facts $facts text_glyph $glyph]
    } finally {
        if {$writer ne {}} {interactiveDocumentResourceAbort $writer}
        if {$photo ne {}} {image delete $photo}
    }
    # Cleanup can retire native/Tk lifetimes: never return a refreshed held.
    _nativeCanvasEditCurrent $handle $held
    if {[font actual $descriptor] ne $actual || [font metrics $descriptor] ne $metrics} {error {Original Tk font changed while glyph coverage was captured}}
    return $result
}
# The extent is the ORIGINAL held Document's, not an image/Job or live camera.
# An internal two-pixel viewport accommodates the existing Native view guard;
# unused right/bottom padding never changes actual publication extent/basis.
proc ::GX::_nativeCanvasDocumentBasis {scene snapshot} {
    lassign [_nativeCanvasExtent {*}[dict get $snapshot extent]] width height
    set viewportWidth [expr {max(2,$width)}];set viewportHeight [expr {max(2,$height)}]
    ::GX::Native2D::core aspect $scene auto
    ::GX::Native2D::core view $scene [list $viewportWidth $viewportHeight 0 0 0 0 [list 0 [expr {$height-$viewportHeight}] $viewportWidth $height]]
    set basis {};foreach world {{0 0} {1 0} {0 1}} {lappend basis [::GX::Native2D::core device $scene $world]}
    lassign [lindex $basis 0] x y;lassign [lindex $basis 1] xx xy;lassign [lindex $basis 2] yx yy
    set matrix [list [expr {$xx-$x}] [expr {$xy-$y}] [expr {$yx-$x}] [expr {$yy-$y}] $x $y]
    return [dict create kind native_document_extent canvas_id [dict get $snapshot canvas_id] extent [list $width $height] width $width height $height world_to_frame $matrix matrix_convention native_source_topdown_to_frame_topdown_v1]
}
proc ::GX::native2DCanvasCaptureDocumentFrame {handle held} {
    _nativeCanvasEditCurrent $handle $held
    set scene [::GX::Native2D::core scene]
    try {set result [_nativeCanvasDocumentBasis $scene [dict get $held snapshot]]} finally {::GX::Native2D::core destroy $scene}
    _nativeCanvasEditCurrent $handle $held
    return $result
}
proc ::GX::native2DCanvasCaptureAnnotation {handle held logical frameLogical} {
    set scene {}
    try {
        set row [_nativeCanvasEditCurrent $handle $held]
        set item [_nativeCanvasRasterLeaf [dict get $held snapshot] $logical]
        set state [_nativeCanvasIndexedState [[dict get $row native] state]]
        set sourceScene [dict get $state scene]
        set source [_nativeCanvasLogical $state objects $logical]
        set definition [::GX::Native2D::core sketch_definition $sourceScene $source]
        set direction [::GX::Native2D::core direction_marker $sourceScene $source]
        set attrs [::GX::Native2D::core identity_attributes $sourceScene $source]
        set nativeKind [::GX::Native2D::core kind $sourceScene $source]
        set style [::GX::Native2D::core object_style $sourceScene $source]
        set descriptor {}
        foreach candidate [[dict get $row native] presentation] {if {[dict get $candidate object]==$source} {set descriptor $candidate;break}}
        if {$descriptor eq {}} {error {Annotation has no original native presenter descriptor}}
        set result [dict create definition $definition direction_marker $direction]
        if {[dict exists $attrs gx.canvas]} {dict set result canvas_metadata [dict get $attrs gx.canvas]}
        set scene [::GX::Native2D::core scene]
        if {$frameLogical eq {}} {
            set frameContext [_nativeCanvasDocumentBasis $scene [dict get $held snapshot]]
        } else {
            set frameItem [_nativeCanvasRasterLeaf [dict get $held snapshot] $frameLogical]
            set frameSource [_nativeCanvasLogical $state objects $frameLogical]
            set frame [interactiveDocumentNative2DRestore [dict get $frameItem resource] $scene]
            _nativeCanvasEditCurrent $handle $held
            set image [::GX::Native2D::core image_get $scene $frame]
            if {$image eq {} || $image ne [::GX::Native2D::core image_get $sourceScene $frameSource]} {error {Publication frame differs from its held native image}}
            set frameContext [dict get $frameItem resource]
        }
        set object [interactiveDocumentNative2DRestore [dict get $item resource] $scene]
        _nativeCanvasEditCurrent $handle $held
        if {[::GX::Native2D::core sketch_definition $scene $object] ne $definition || [::GX::Native2D::core direction_marker $scene $object] ne $direction} {error {Annotation Resource differs from its held native definition or direction}}
        if {$definition eq {} && $nativeKind eq {curve} && [::GX::Native2D::core breaks $scene $object] ne [::GX::Native2D::core breaks $sourceScene $source]} {error {Raw annotation Resource differs from its actual native cut ownership}}
        if {$frameLogical ne {}} {
            # The original same-owner basis is Raster TOPDOWN; only coordinate
            # order/y convention changes before the ORIGINAL affine owner.
            lassign [_nativeCanvasCaptureFrameMatrix $scene $frame] a b c d e f
            set width [dict get $image width];set height [dict get $image height]
            ::GX::Native2D::core affine $scene [list $object] [list $a $c [expr {-$b}] [expr {-$d}] $e [expr {$height-$f}]] 0
            ::GX::Native2D::core aspect $scene auto
            ::GX::Native2D::core view $scene [list $width $height 0 0 0 0 [list 0 0 $width $height]]
        }
        set isText [expr {[dict exists $attrs gx.canvas kind] && [dict get $attrs gx.canvas kind] eq {text}}]
        set skip [uiFieldNormalize {type boolean} [datasetPublicationV2DictDefault $descriptor skip_path 0]]
        set skip [expr {$skip || $isText || [::GX::Native2D::core image_get $sourceScene $source] ne {}}]
        set sampleMarkers [uiFieldNormalize {type boolean} [datasetPublicationV2DictDefault $descriptor sample_markers 1]]
        set drawSymbols [expr {!$skip && ($nativeKind ne {curve} || ($sampleMarkers && [dict get $style marker]!=0))}]
        if {$definition eq {} || $drawSymbols || ([dict exists $definition family] && [dict get $definition family] eq {construction_line}) || (!$isText && [::GX::Native2D::core image_get $sourceScene $source] eq {} && ([dict get $style marker]!=0 || $skip))} {
            # Exact same kernels as retainedSample/sample in buildNative. The
            # owning Canvas presenter fixes budget4096; no caller substitutes
            # controls for tessellated/display points or drops segment cuts.
            set method [expr {$nativeKind eq {curve}?{render_curve_lod}:{render_lod}}]
            set geometry [::GX::Native2D::core $method $scene $object 4096]
            dict set result native_sampling [dict create native_kind $nativeKind method $method budget 4096 sample_markers $sampleMarkers skip_path $skip draw_line [expr {!$skip && $nativeKind eq {curve}}] draw_symbols $drawSymbols marker [dict get $style marker] radius_px 3 line_width_px 1 geometry $geometry]
        }
        set family [expr {$definition eq {}?{}:[dict get $definition family]}]
        if {$family in {composite_path compound}} {
            set states [::GX::Native2D::core composition_states $sourceScene $source]
            dict set result composition_states $states
            set geometry {}
            if {!$skip} {
                foreach part $states {
                    set marker [dict get $part direction]
                    if {![dict get $marker present] || ![dict get $marker visible]} continue
                    set points [::GX::Native2D::core part_marker_render $scene $object [dict get $part part_id]]
                    lappend geometry [dict create part_id [dict get $part part_id] ordinal [dict get $part ordinal] geometry $points]
                }
            }
            dict set result part_marker_geometry $geometry
        } elseif {!$skip && $nativeKind eq {curve} && [dict get $direction present] && [dict get $direction visible]} {
            dict set result marker_geometry [::GX::Native2D::core render_marker $scene $object]
        }
        if {$isText} {
            set canonical [::GX::Native2D::core sketch_definition $scene $object]
            set glyph [_nativeCanvasCaptureGlyph $handle $held $logical [dict get $item resource] $frameContext $definition [dict get $attrs gx.canvas] $scene $canonical]
            set result [dict merge $result $glyph]
        }
        _nativeCanvasEditCurrent $handle $held
    } on error {message options} {
        return -options $options "Cannot capture native annotation '$logical': $message"
    } finally {
        if {$scene ne {}} {native2DRasterSceneDispose $scene;::GX::Native2D::core destroy $scene}
    }
    _nativeCanvasEditCurrent $handle $held
    if {[dict exists $result font_facts]} {
        set fontFacts [dict get $result font_facts];set descriptor [dict get $fontFacts descriptor]
        if {[font actual $descriptor] ne [dict get $fontFacts actual] || [font metrics $descriptor] ne [dict get $fontFacts metrics]} {error "Cannot capture native annotation '$logical': Original Tk font changed during cleanup"}
    }
    return $result
}

proc ::GX::_nativeCanvasCaptureFrameMatrix {scene frame} {
    set image [::GX::Native2D::core image_get $scene $frame]
    if {$image eq {}} {error {Publication requires its actual retained native image frame}}
    set height [dict get $image height];set points {}
    foreach world {{0 0} {1 0} {0 1}} {
        lassign [::GX::Native2D::core image_map $scene $frame $world 1] x y
        lappend points [list $x [expr {$height-$y}]]
    }
    lassign [lindex $points 0] x y
    lassign [lindex $points 1] xx xy
    lassign [lindex $points 2] yx yy
    return [list [expr {$xx-$x}] [expr {$xy-$y}] [expr {$yx-$x}] [expr {$yy-$y}] $x $y]
}
# Return finite image/frame facts through the same existing mapping kernel,
# without exposing its live scene/object identifiers to an extension.
proc ::GX::native2DCanvasCaptureImageFrame {handle held logical} {
    set row [_nativeCanvasEditCurrent $handle $held]
    set state [_nativeCanvasIndexedState [[dict get $row native] state]]
    set scene [dict get $state scene];set object [_nativeCanvasLogical $state objects $logical]
    set image [::GX::Native2D::core image_get $scene $object]
    if {$image eq {}} {error {Frame capture requires its actual owned image}}
    set matrix [_nativeCanvasCaptureFrameMatrix $scene $object]
    set result [dict create width [dict get $image width] height [dict get $image height] world_to_frame $matrix image $image]
    _nativeCanvasEditCurrent $handle $held
    return $result
}
