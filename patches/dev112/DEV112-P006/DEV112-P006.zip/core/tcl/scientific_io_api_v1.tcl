# SPDX-License-Identifier: GPL-3.0-or-later
# Opaque local source transport, backed by existing Dataset/Document authorities.
namespace eval ::GX::ScientificIO {variable scopes {};variable entries {};variable entryTokens {};variable serial 0}
proc ::GX::scientificIoApiInfo {} {return [dict create api_id SCIENTIFIC_IO_API_v1 api_version 1 operations {capabilities browse import describe read export} authorization host_user_admin scope_lifetime current_Session transport local codecs opaque_file remote_backends not_implemented host_image_chooser ::GX::scientificIoChooseImageResource]}
proc ::GX::scientificIoCapabilities {} {return [dict create transport local identity canonical_Dataset location_opaque 1 formats_independent 1 metadata_browse 1 copy 1 verified_reference 1 random_read 1 bounded_read 1 offline_identity_preserved 1 remote 0 hostile_code_sandbox 0]}
proc ::GX::_scientificIoCall {root operation relative offset count {expected {}} {destination {}}} {
    set rc [catch {exec [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_scientific_io.py] $root $operation $relative $offset $count $expected $destination} response]
    if {[catch {dict get $response ok} ok]||!$ok} {if {![catch {dict get $response error} message]} {error $message};error $response}
    return [dict get $response result]
}
# Host-only explicit user/admin grant, never a Script Bridge operation.
proc ::GX::scientificIoAuthorize {root producers {allowImport 0} {allowExport 0}} {
    variable ::GX::ScientificIO::scopes;variable ::GX::ScientificIO::entries;variable ::GX::ScientificIO::entryTokens;variable ::GX::ScientificIO::serial
    dict for {old entry} $scopes {if {[dict get $entry session_token] ne [interactiveDocumentSessionToken]} {dict unset scopes $old}}
    if {![dict size $scopes]} {set entries {};set entryTokens {}}
    if {[dict size $scopes]>=32} {error {Authorized source scope budget is32 per host Session}}
    if {$::GX::DatasetPrivate::activeContext ne {}} {error {Only user/admin may authorize source scopes}}
    if {![string is boolean -strict $allowImport]||![string is boolean -strict $allowExport]} {error {Invalid content authorization}}
    set root [file normalize $root]
    if {![file isdirectory $root]||[file type $root] eq {link}} {error {Choose an existing ordinary source directory}}
    foreach producer $producers {datasetPublicationV2ValidateId module $producer}
    _scientificIoCall $root list {} 0 1
    set token "scientific-scope#[pid]-[incr serial]"
    dict set scopes $token [dict create root $root producers $producers allow_import $allowImport allow_export $allowExport session_token [interactiveDocumentSessionToken]]
    return $token
}
proc ::GX::_scientificIoScope {token producer} {
    variable ::GX::ScientificIO::scopes
    if {![dict exists $scopes $token]} {error {Unknown authorized source scope}}
    set scope [dict get $scopes $token]
    if {[dict get $scope session_token] ne [interactiveDocumentSessionToken]||$producer ni [dict get $scope producers]} {error {Source scope is unavailable to this producer/Session}}
    if {$::GX::DatasetPrivate::activeContext ne {}&&[dict get $::GX::DatasetPrivate::activeContext module_id] ne $producer} {error {Source producer identity mismatch}}
    return $scope
}
proc ::GX::scientificIoBrowse {scopeToken producer {directoryToken {}} {offset 0} {count 100}} {
    variable ::GX::ScientificIO::entries;variable ::GX::ScientificIO::entryTokens;variable ::GX::ScientificIO::serial
    set scope [_scientificIoScope $scopeToken $producer];set relative {}
    if {$directoryToken ne {}} {
        if {![dict exists $entries $directoryToken]||[dict get $entries $directoryToken scope] ne $scopeToken||[dict get $entries $directoryToken kind] ne {directory}} {error {Unknown directory entry token}}
        set relative [dict get $entries $directoryToken relative]
    }
    set page [_scientificIoCall [dict get $scope root] list $relative $offset $count]
    set public {}
    foreach entry [dict get $page entries] {
        set identityKey [list $scopeToken [dict get $entry relative] [dict get $entry identity]]
        if {[dict exists $entryTokens $identityKey]} {set token [dict get $entryTokens $identityKey]} else {
            if {[dict size $entryTokens]>=20000} {error {Source entry budget is20000 per host Session; use a narrower authorized scope}}
            set token "scientific-entry#[pid]-[incr serial]"
            dict set entryTokens $identityKey $token
        }
        dict set entry scope $scopeToken
        dict set entries $token $entry
        lappend public [dict merge [dict remove $entry scope relative identity] [dict create entry_token $token availability metadata_only]]
    }
    dict set page entries $public
    return $page
}
proc ::GX::scientificIoImport {scopeToken producer entryToken request} {
    variable ::GX::ScientificIO::entries
    set scope [_scientificIoScope $scopeToken $producer]
    if {![dict get $scope allow_import]} {error {Browsing does not authorize content import}}
    if {![dict exists $entries $entryToken]||[dict get $entries $entryToken scope] ne $scopeToken||[dict get $entries $entryToken kind] ne {file}} {error {Unknown authorized file entry}}
    set entry [dict get $entries $entryToken]
    foreach key [dict keys $request] {if {$key ni {dataset_id contract format storage_kind media_type policy expected_sha256 dataset_namespace}} {error "Unknown scientific import option '$key'"}}
    foreach key {dataset_id contract format storage_kind media_type policy} {if {![dict exists $request $key]} {error "Scientific import requires '$key'"}}
    if {[dict get $request policy] ni {copy reference}} {error {Scientific import supports copy or verified reference}}
    set verification [expr {[dict get $request storage_kind] eq {text}?{text}:{read}}]
    set source [_scientificIoCall [dict get $scope root] $verification [dict get $entry relative] 0 1 [datasetPublicationV2DictDefault $request expected_sha256 {}]]
    if {[dict get $source identity] ne [dict get $entry identity]} {error {Source entry changed after browsing; browse again}}
    set session [_interactiveDocumentRequireSession]
    set definition [dict remove $request policy expected_sha256]
    dict set definition immutable 1
    dict set definition source_file [file join [dict get $scope root] [dict get $entry relative]]
    dict set definition provenance "CORE authorized source import; source SHA [dict get $source sha256]; policy [dict get $request policy]"
    if {[dict get $request policy] eq {reference}} {
        dict set definition verified_reference [dict create source_root [dict get $scope root] source_relative [dict get $entry relative] identity [dict get $source identity] sha256 [dict get $source sha256]]
    }
    set allocation {}
    try {
        if {[dict get $request policy] eq {copy}} {
            set allocation [resourceManagementAllocate scientific_io [dict create kind directory session $session lifetime operation expected_bytes [dict get $source size_bytes]]]
            set materialized [file join [dict get $allocation path] imported-source]
            set copied [_scientificIoCall [dict get $scope root] copy [dict get $entry relative] 0 1 [dict get $source sha256] $materialized]
            if {[dict get $copied identity] ne [dict get $entry identity]} {error {Source changed during copy}}
            dict set definition source_file $materialized
            dict set definition verified_source_sha256 [dict get $source sha256]
        }
        set receipt [datasetFilePublicationPublish $session $producer $definition]
    } finally {
        if {$allocation ne {}} {resourceManagementRelease [dict get $allocation id];resourceManagementCleanup [list [dict get $allocation id]]}
    }
    return [dict remove $receipt path]
}
proc ::GX::scientificIoDescribeDataset {id} {
    set session [_interactiveDocumentRequireSession];loadDatasetRegistry $session
    if {[datasetField $id id {}] eq {}} {error {Unknown canonical Dataset}}
    set result [dict create dataset_id $id format [datasetField $id format {}] contract [datasetField $id contract {}] content_sha256 [datasetField $id sha256 [datasetField $id canonical_sha256 {}]] policy [datasetField $id source_storage_policy copy] availability available readonly 1]
    set path [datasetResolvePath $session $id]
    if {![file isfile $path]} {dict set result availability unavailable}
    return $result
}
proc ::GX::scientificIoReadDataset {id {offset 0} {count 65536}} {
    set description [scientificIoDescribeDataset $id]
    if {[dict get $description availability] ne {available}} {return $description}
    set path [datasetResolvePath [_interactiveDocumentRequireSession] $id]
    set root [datasetField $id external_source_root [file dirname $path]]
    set relative [datasetField $id external_source_relative [file tail $path]]
    set page [_scientificIoCall $root read $relative $offset $count [dict get $description content_sha256]]
    return [dict merge $description [dict remove $page identity]]
}

proc ::GX::scientificIoExportDataset {scopeToken producer id filename} {
    set scope [_scientificIoScope $scopeToken $producer]
    if {![dict get $scope allow_export]} {error {This scope does not authorize export}}
    if {![regexp {^[A-Za-z0-9][A-Za-z0-9_.-]{0,191}$} $filename]} {error {Export requires a single safe leaf name}}
    set descriptor [scientificIoDescribeDataset $id]
    if {[dict get $descriptor availability] ne {available}} {error {Canonical source is unavailable}}
    set destination [file join [dict get $scope root] $filename]
    set receipt [filePublicationPublishBundle [list [dict create id export destination $destination writer [list ::GX::_scientificIoExportWriter $id [dict get $descriptor content_sha256]]]]]
    set public [dict get $receipt files export]
    return [dict merge [dict remove $public destination] [dict create dataset_id $id filename $filename]]
}
proc ::GX::_scientificIoExportWriter {id expected channel context} {
    set offset 0
    while {1} {
        set page [scientificIoReadDataset $id $offset 1048576]
        if {![dict exists $page sha256]||[dict get $page sha256] ne $expected} {error {Source changed during export}}
        set bytes [binary decode base64 [dict get $page bytes_base64]]
        puts -nonewline $channel $bytes
        if {[string length $bytes]<1048576} break
        set offset [dict get $page next_offset]
    }
}

# HOST_ONLY private chooser adapter: live Tk parent/user choice, trusted fixed
# completion prefix and original Document/Session authority are not Script values.
# No public operation/grant, Dataset publisher or scientific executor is added.
namespace eval ::GX::ScientificIO {variable imageOperations {}}
proc ::GX::_scientificIoImageCurrent {entry} {
    set parent [dict get $entry parent]
    if {![llength [info commands winfo]] || ![winfo exists $parent] || [winfo id $parent] ne [dict get $entry parent_id]} {error {Image import parent lifetime ended}}
    if {[interactiveDocumentSessionToken] ne [dict get $entry session_token]} {error {Image import Session changed}}
    set guard [dict get $entry guard];set producer [dict get $entry producer]
    if {[lsort [dict keys $guard]] ne {document_id generation revision sha256}} {error {Image import requires its complete held Document receipt}}
    set metadata [interactiveDocumentMetadata [dict get $guard document_id]]
    foreach field {generation revision sha256} {if {[dict get $metadata $field] ne [dict get $guard $field]} {error {Image import Document changed}}
    }
    if {[dict get $metadata module_id] ne $producer || [moduleField $producer descriptor {}] eq {} || ![moduleIsEnabled $producer]} {error {Image import requires its actual enabled Document owner}}
    if {[dict get $entry scope] ne {}} {_scientificIoScope [dict get $entry scope] $producer}
    return $metadata
}
proc ::GX::_scientificIoImageEncode {value} {
    return [list GXTXT_SCIENTIFIC_IO_V1 [binary encode base64 -maxlen 0 [encoding convertto utf-8 $value]]]
}
proc ::GX::_scientificIoImageDecode {line} {
    if {[string bytelength $line]>131072 || [llength $line]!=2 || [lindex $line 0] ne {GXTXT_SCIENTIFIC_IO_V1}} {error {Invalid bounded image reader frame}}
    set encoded [lindex $line 1];set bytes [binary decode base64 -strict $encoded]
    if {[binary encode base64 -maxlen 0 $bytes] ne $encoded} {error {Noncanonical image reader frame}}
    set value [encoding convertfrom utf-8 $bytes]
    if {[encoding convertto utf-8 $value] ne $bytes} {error {Image reader frame is not UTF-8}}
    dict size $value
    return $value
}
proc ::GX::_scientificIoImageDestroyed {operation actual} {
    if {[dict exists $::GX::ScientificIO::imageOperations $operation] && $actual eq [dict get $::GX::ScientificIO::imageOperations $operation parent]} {_scientificIoCancelImageResource $operation}
}
proc ::GX::_scientificIoCancelImageResource {operation} {
    variable ::GX::ScientificIO::imageOperations
    if {![dict exists $imageOperations $operation]} {return 0}
    _scientificIoImageFail $operation cancelled
    return 1
}
proc ::GX::_scientificIoImageFail {operation type} {
    variable ::GX::ScientificIO::imageOperations
    if {![dict exists $imageOperations $operation]} return
    if {[dict get $imageOperations $operation error_type] eq {}} {dict set imageOperations $operation error_type $type}
    set request [dict get $imageOperations $operation request]
    if {$request ne {}} {
        # Original managed owner retains the FD/process/group until terminal.
        catch {scriptJobRequestCancel $request cancelled}
    } else {after idle [list ::GX::_scientificIoImageFinish $operation]}
}
proc ::GX::scientificIoChooseImageResource {parent documentGuard producer completion} {
    # Trusted GUI entry point over the original user/admin chooser and exact
    # parent/Session/Document/source/Resource/cleanup checks. No new file grant.
    tailcall ::GX::_scientificIoChooseImageResource $parent $documentGuard $producer $completion
}
proc ::GX::_scientificIoChooseImageResource {parent documentGuard producer completion} {
    variable ::GX::ScientificIO::imageOperations;variable ::GX::ScientificIO::serial
    if {![llength $completion]} {error {Image import requires its trusted host completion prefix}}
    set operation "scientific-image-import#[pid]-[incr serial]"
    dict set imageOperations $operation [dict create parent $parent parent_id {} guard $documentGuard producer $producer callback $completion session_token {} scope {} allocation {} request {} writer {} timer {} tag GXScientificIO:$operation stage choosing bytes 0 sequence 0 sha256 {} verified 0 finish_sent 0 error_type {}]
    try {
        # Do not clear a module callback's activeContext to manufacture a user
        # grant. The original GUI owner schedules this after that event returns.
        if {$::GX::DatasetPrivate::activeContext ne {}} {error {Image chooser requires the original user/admin context}}
        dict set imageOperations $operation parent_id [winfo id $parent]
        dict set imageOperations $operation session_token [interactiveDocumentSessionToken]
        _scientificIoImageCurrent [dict get $imageOperations $operation]
        set path [workspaceOpenFile manifest_dir -parent $parent -title {Choose image source} -filetypes {{{Image files} {.png .jpg .jpeg .tif .tiff .bmp .gif .webp .ppm .pgm .pbm .pnm .exr .hdr .fits .fit}} {{All files} *}}]
        if {$path eq {}} {_scientificIoImageFail $operation cancelled;return $operation}
        _scientificIoImageCurrent [dict get $imageOperations $operation]
        if {[file pathtype $path] ne {absolute} || [string length [encoding convertto utf-8 $path]]>4096 || [regexp {[\x00-\x1f]} $path]} {error {Choose an ordinary local image file}}
        file lstat $path identity
        if {$identity(type) ne {file} || $identity(nlink)!=1 || $identity(size)<1} {error {Choose an ordinary single-link nonempty image file}}
        set scope [scientificIoAuthorize [file dirname $path] [list $producer] 1 0]
        dict set imageOperations $operation scope $scope
        _scientificIoImageCurrent [dict get $imageOperations $operation]
        # This reservation counts pending Document bytes plus the bounded
        # original launcher; its child lease outlives cancellation until drain.
        set allocation [resourceManagementAllocate scientific_io [dict create kind directory lifetime operation session [_interactiveDocumentRequireSession] expected_bytes [expr {$identity(size)+16384}] descendant_lease 1]]
        dict set imageOperations $operation allocation $allocation
        set argv [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_scientific_io.py] --resource-stream [dict get [_scientificIoScope $scope $producer] root] [file tail $path] $operation $identity(dev) $identity(ino) $identity(size) $identity(mtime) $identity(ctime)]
        set launch "GXTXT_PARALLEL_EXEC_V1\nGROUP\t1\n"
        foreach arg $argv {append launch "ARG\t[binary encode base64 -maxlen 0 [encoding convertto utf-8 $arg]]\n"}
        foreach {key value} [list GXTXT_RESOURCE_ROOT [resourceManagementRoot] GXTXT_RESOURCE_LEASE [dict get $allocation id]] {append launch "ENV\t[binary encode base64 -maxlen 0 $key]\t[binary encode base64 -maxlen 0 [encoding convertto utf-8 $value]]\n"}
        if {[string length $launch]>16384} {error {Image import launcher exceeds its reserved bound}}
        set launcher [file join [dict get $allocation path] reader.launch]
        set channel [open $launcher {WRONLY CREAT EXCL}]
        try {fconfigure $channel -encoding ascii -translation lf;puts -nonewline $channel $launch} finally {close $channel}
        file attributes $launcher -permissions 0600
        dict set imageOperations $operation expected_bytes $identity(size)
        dict set imageOperations $operation filename [file tail $path]
        set tag [dict get $imageOperations $operation tag]
        bind $tag <Destroy> [list ::GX::_scientificIoImageDestroyed $operation %W]
        bindtags $parent [linsert [bindtags $parent] 1 $tag]
        set command [list [runtimeToolRequired python] -I -B [file join $::GX::scriptDir core python parallel_process_exec_v1.py] $launcher]
        set request [scriptJobAsync $command {} [list ::GX::_scientificIoImageDrained $operation] {duplex 1 process_group 1 ui_lifetime 1 max_bytes 131072 send_pending_bytes 32768 label {Selected image Resource import}}]
        dict set imageOperations $operation request $request
        dict set imageOperations $operation stage reading
        dict set imageOperations $operation timer [after 10 [list ::GX::_scientificIoImagePoll $operation]]
    } on error {message options} {
        set type [expr {[string match {*budget exhausted*} $message]?{quota}:{admission}}]
        _scientificIoImageFail $operation $type
    }
    return $operation
}
proc ::GX::_scientificIoImagePoll {operation} {
    variable ::GX::ScientificIO::imageOperations
    if {![dict exists $imageOperations $operation]} return
    dict set imageOperations $operation timer {}
    set request [dict get $imageOperations $operation request]
    if {[catch {
        _scientificIoImageCurrent [dict get $imageOperations $operation]
        set drained [scriptJobRequestDrain $request 1]
        if {![dict exists $imageOperations $operation]} return
        foreach line [dict get $drained messages] {
            set message [_scientificIoImageDecode $line];set entry [dict get $imageOperations $operation]
            if {[dict get $message operation] ne $operation} {error {Foreign image reader operation}}
            _scientificIoImageCurrent $entry
            switch -- [dict get $message kind] {
                ready {
                    if {[dict get $entry writer] ne {} || [dict get $entry verified] || [lsort [dict keys $message]] ne {kind operation sha256 size_bytes} || [dict get $message size_bytes] ne [dict get $entry expected_bytes] || ![regexp {^[a-f0-9]{64}$} [dict get $message sha256]]} {error {Invalid image reader admission}}
                    dict set imageOperations $operation sha256 [dict get $message sha256]
                    set metadata [dict create format binary origin scientific_io_choice scientific_authority 0 filename [dict get $entry filename]]
                    dict set imageOperations $operation writer [interactiveDocumentResourceOpenWriter [dict get $entry guard document_id] $metadata]
                    scriptJobRequestSend $request [_scientificIoImageEncode [dict create operation $operation action next sequence 0]]
                }
                chunk {
                    if {[dict get $entry writer] eq {} || [dict get $entry verified] || [lsort [dict keys $message]] ne {bytes_base64 kind offset operation sequence} || [dict get $message offset] ne [dict get $entry bytes] || [dict get $message sequence] ne [dict get $entry sequence]} {error {Invalid image reader chunk order}}
                    set encoded [dict get $message bytes_base64];set bytes [binary decode base64 -strict $encoded];set count [string length $bytes]
                    if {[binary encode base64 -maxlen 0 $bytes] ne $encoded || $count<1 || $count>65536 || [dict get $entry bytes]+$count>[dict get $entry expected_bytes]} {error {Invalid bounded image reader bytes}}
                    interactiveDocumentResourceAppend [dict get $entry writer] $bytes
                    dict incr entry bytes $count;dict incr entry sequence
                    dict set imageOperations $operation $entry
                    scriptJobRequestSend $request [_scientificIoImageEncode [dict create operation $operation action next sequence [dict get $entry sequence]]]
                }
                verified {
                    if {[dict get $entry writer] eq {} || [dict get $entry verified] || [lsort [dict keys $message]] ne {kind operation sha256 size_bytes} || [dict get $message size_bytes] ne [dict get $entry expected_bytes] || [dict get $entry bytes] ne [dict get $entry expected_bytes] || [dict get $message sha256] ne [dict get $entry sha256]} {error {Incomplete image reader verification}}
                    dict set imageOperations $operation verified 1
                    # Mark intent before Send; a partial write is never retried.
                    dict set imageOperations $operation finish_sent 1
                    scriptJobRequestSend $request [_scientificIoImageEncode [dict create operation $operation action finish sequence [dict get $entry sequence]]]
                }
                default {error {Selected image source could not be completely verified}}
            }
        }
        if {[dict exists $imageOperations $operation] && [dict get $drained active]} {dict set imageOperations $operation timer [after [expr {[llength [dict get $drained messages]]?1:10}] [list ::GX::_scientificIoImagePoll $operation]]}
    } message options]} {_scientificIoImageFail $operation source_or_owner_changed}
}
proc ::GX::_scientificIoImageDrained {operation transport} {
    variable ::GX::ScientificIO::imageOperations
    if {![dict exists $imageOperations $operation]} return
    set entry [dict get $imageOperations $operation]
    # Duplex EOF uses the original managed closed/group-drain path. Success
    # additionally requires our complete verified protocol and current owner.
    if {![dict get $entry verified] || ![dict get $entry finish_sent] || [datasetPublicationV2DictDefault $transport error_type closed] ne {closed}} {
        if {[dict get $entry error_type] eq {}} {dict set imageOperations $operation error_type incomplete}
    }
    dict set imageOperations $operation request {}
    _scientificIoImageFinish $operation
}
proc ::GX::_scientificIoImageFinish {operation} {
    variable ::GX::ScientificIO::imageOperations
    if {![dict exists $imageOperations $operation]} return
    set entry [dict get $imageOperations $operation]
    if {[dict get $entry request] ne {}} return
    if {[dict get $entry timer] ne {}} {after cancel [dict get $entry timer]}
    set result {};set type [dict get $entry error_type]
    if {$type eq {}} {
        if {[catch {
            _scientificIoImageCurrent $entry
            set result [interactiveDocumentResourceFinalize [dict get $entry writer]]
            dict set entry writer {}
            if {[dict get $result sha256] ne [dict get $entry sha256] || [dict get $result size_bytes] ne [dict get $entry bytes] || [dict get $result owner_generation] ne [dict get $entry guard generation]} {error {Image Resource final identity differs}}
            _scientificIoImageCurrent $entry
        } message options]} {set type source_or_owner_changed;set result {}}
    }
    # Original Document Delete may already have aborted this exact writer.
    # Its retired token is not another cleanup failure or a replacement handle.
    if {[dict get $entry writer] ne {} && [dict exists $::GX::DocumentResource::writers [dict get $entry writer]]} {if {[catch {interactiveDocumentResourceAbort [dict get $entry writer]}]} {set type cleanup}}
    set scope [dict get $entry scope]
    if {$scope ne {}} {
        catch {dict unset ::GX::ScientificIO::scopes $scope}
        dict for {token value} $::GX::ScientificIO::entries {if {[dict get $value scope] eq $scope} {dict unset ::GX::ScientificIO::entries $token}}
        foreach key [dict keys $::GX::ScientificIO::entryTokens] {if {[lindex $key 0] eq $scope} {dict unset ::GX::ScientificIO::entryTokens $key}}
    }
    set allocation [dict get $entry allocation]
    if {$allocation ne {}} {
        if {[catch {resourceManagementRelease [dict get $allocation id];resourceManagementCleanup [list [dict get $allocation id]]}]} {set type cleanup;set result {}}
    }
    set parent [dict get $entry parent];set tag [dict get $entry tag]
    if {[llength [info commands winfo]] && [winfo exists $parent] && [winfo id $parent] eq [dict get $entry parent_id]} {bindtags $parent [lsearch -all -inline -not -exact [bindtags $parent] $tag]}
    catch {bind $tag <Destroy> {}}
    dict unset imageOperations $operation
    if {$type ne {}} {
        set text [dict get [dict create cancelled {Image import cancelled; no Resource was delivered} quota {Image import exceeds the managed Resource budget; no Resource was delivered} admission {Image import requires an unchanged admitted owner and ordinary selected file} source_or_owner_changed {Image source or Document/Session/parent changed; no Resource was delivered} incomplete {Image reader ended without complete verified bytes; no Resource was delivered} cleanup {Image import cleanup could not be confirmed; retained allocations require owner inspection}] $type]
        set response [dict create ok 0 error $text error_type $type]
    } else {set response [dict create ok 1 result $result]}
    uplevel #0 [list {*}[dict get $entry callback] $response]
}
