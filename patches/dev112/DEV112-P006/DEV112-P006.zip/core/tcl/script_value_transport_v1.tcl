# SPDX-License-Identifier: GPL-3.0-or-later
# Internal value transport only. Fixed original owners perform all algorithms.
namespace eval ::GX::ScriptValueTransportV1 {}
proc ::GX::ScriptValueTransportV1::pack {value} {
    set bytes [encoding convertto unicode $value]
    if {[encoding convertto unicode [encoding convertfrom unicode $bytes]] ne $bytes} {
        error {Native Unicode value cannot be represented losslessly}
    }
    set marker [binary encode hex [encoding convertto unicode A]]
    switch -- $marker {
        4100 {set representation tcl_unicode_hex_le}
        0041 {set representation tcl_unicode_hex_be}
        default {error {Unsupported native Unicode encoding}}
    }
    return [dict create format gxtxt.inert_tcl_value.v2 representation $representation shape unresolved lexeme [binary encode hex $bytes]]
}
proc ::GX::ScriptValueTransportV1::unpack {representation lexeme} {
    if {$representation eq {unicode_text}} {return $lexeme}
    if {$representation ni {tcl_unicode_hex_le tcl_unicode_hex_be} ||
        [string length $lexeme] % 4 || ![regexp {^[0-9a-f]*$} $lexeme]} {
        error {Invalid whole native Unicode hex value}
    }
    set bytes [binary decode hex $lexeme]
    set nativeLittle [expr {[binary encode hex [encoding convertto unicode A]] eq {4100}}]
    if {($representation eq {tcl_unicode_hex_le}) != $nativeLittle} {
        binary scan $bytes c* octets
        set swapped {}
        foreach {a b} $octets {lappend swapped $b $a}
        set bytes [binary format c* $swapped]
    }
    set value [encoding convertfrom unicode $bytes]
    if {[encoding convertto unicode $value] ne $bytes} {
        error {Native Unicode hex value is not lossless}
    }
    return [::GX::nativeWorkspaceDecode [list text $value]]
}
proc ::GX::ScriptValueTransportV1::invoke {operation arguments} {
    # No caller command or callback is evaluated. This closed transport table
    # is not a provider, service family, scientific implementation or grant.
    switch -- $operation {
        toText {set command ::GX::OCRLayoutAPIv1::toText}
        filterRoi {set command ::GX::OCRLayoutAPIv1::filterRoi}
        extractLayout {set command ::GX::TableExtractorAPIv1::extractLayout}
        nativeModel {set command ::GX::MathematicsExplorer::nativeModel}
        historyValidate {set command ::GX::ReplicateViewer::historyValidate}
        validate {set command ::GX::ReplicateWorkspace::validate}
        rebase {set command ::GX::scientificRecipeRebase}
        viewerGuiComponentDemoCatalog - viewerGuiComponentDemoRegister -
        viewerGuiDesignAnalysisProfile - viewerGuiDesignHandlerSource -
        viewerGuiDesignModelCreate - viewerGuiDesignModelEdit -
        viewerGuiDesignValidate - viewerGuiIconEdit - viewerGuiIconsValidate -
        viewerGuiTestFixtureValidate {set command ::GX::$operation}
        default {error {Unknown original value operation}}
    }
    set code [catch {uplevel #0 [list $command {*}$arguments]} result options]
    # Capture before crossing _tkinter: Python tuple conversions must not
    # replace the original result/options spellings. Includes ALL options.
    if {$operation eq {viewerGuiDesignHandlerSource} && $code == 0} {
        # Original rb channel bytes: no text decoding, Unicode conversion or
        # replacement. The caller uses the established shared uint8 transport.
        set packed [dict create format gxtxt.bytes.hex.v1 representation binary_hex shape bytes lexeme [binary encode hex $result]]
    } else {set packed [pack $result]}
    return [dict create code $code result $packed options [pack $options]]
}
