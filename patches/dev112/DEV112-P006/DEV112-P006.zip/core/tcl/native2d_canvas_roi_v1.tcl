# SPDX-License-Identifier: GPL-3.0-or-later
# Restricted Canvas facets over the original Native2D image ROI owner.
# No image bytes, paths, native IDs or alternative ROI/Workspace store escape.
proc ::GX::_nativeCanvasRoiTools {} {return {roi_rectangle roi_select roi_translate roi_vertex}}
proc ::GX::_nativeCanvasRoiSchemas {} {
    set common {object expected_source_sha256 expected_source_revision expected_revision}
    return [dict create \
        roi_list [list $common {offset count}] \
        roi_create [list [concat $common {roi_id expected_roi_revision definition}] {space}] \
        roi_update [list [concat $common {roi_id expected_roi_revision definition}] {space}] \
        roi_delete [list [concat $common {roi_id expected_roi_revision}] {}] \
        roi_select [list [concat $common {roi_id expected_roi_revision}] {}]]
}
proc ::GX::_nativeCanvasRoiIdentity {value {empty 0}} {
    if {$empty && $value eq {}} {return $value}
    if {![regexp {^[A-Za-z][A-Za-z0-9_.:#-]{0,127}$} $value]} {error {ROI requires a stable logical identity}}
    return $value
}
proc ::GX::_nativeCanvasRoiOwnedImageContext {handle logical selected} {
    _nativeCanvasRoiIdentity $logical
    set row [_nativeCanvasRequire $handle]
    set state [_nativeCanvasIndexedState [_nativeCanvasReconcile $handle]]
    if {$selected} {
        set selection [lmap id [dict get $state selected_objects] {_nativeCanvasLogicalFromId $state objects $id}]
        if {$selection ne [list $logical]} {error {ROI requires exactly its selected original Canvas image}}
    }
    set geometry [dict get $row geometry];set scene [_native2DGeometryRequire $geometry]
    set id [_nativeCanvasLogical $state objects $logical];set token {}
    dict for {candidate entry} [dict get $scene objects] {if {[dict get $entry native]==$id} {set token $candidate;break}}
    if {$token eq {}} {error {ROI image is outside its actual Canvas geometry}}
    set image [_native2DRasterImage $scene $token]
    set reference [dict get $image resource]
    if {[dict get $reference document_id] ne [dict get $row document] || ![dict exists $reference owner_generation] || [dict get $reference owner_generation] ne [dict get $row receipt generation]} {error {ROI Resource belongs to another Document lifetime}}
    return [dict create row $row canvas_id [dict get $state canvas_id] geometry $geometry object_token $token image $image logical $logical \
        attributes [::GX::Native2D::core identity_attributes [dict get $scene native] $id] \
        canonical_binding [datasetPublicationV2DictDefault [dict get $scene objects $token metadata] raster_dataset {}] \
        collection [native2DGeometryCall $geometry raster_roi_get [dict create object_token $token]]]
}
proc ::GX::_nativeCanvasRoiPublicContext {context} {
    set public [dict remove $context row]
    dict set public image [dict remove [dict get $public image] id]
    return $public
}
proc ::GX::_nativeCanvasRoiImageContext {handle logical {selected 1}} {
    set owned [_nativeCanvasRoiOwnedImageContext $handle $logical $selected]
    # An actual canonical binding is authoritative before any module hook.
    # A failed canonical SHA/revision/Resource check can NEVER be rescued by
    # a noncanonical module claim, model marker or presentation thumbnail.
    if {[dict get $owned canonical_binding] ne {}} {
        set context [_quantitativeCanvasImage $handle $logical]
        dict set context logical $logical
        dict set context collection [native2DGeometryCall [dict get $context geometry] raster_roi_get [dict create object_token [dict get $context object_token]]]
        return $context
    }
    set resourceContext [_nativeCanvasExtensionCall $handle roi_image_context $logical $selected]
    if {$resourceContext ne {}} {
        _nativeCanvasFields $resourceContext {source_kind source extension_data} {source_kind source extension_data}
        _nativeCanvasFields [dict get $resourceContext source] {dataset_id source_kind source_stamp} {dataset_id source_kind source_stamp}
        if {[dict get $resourceContext source dataset_id] ne {} || [dict get $resourceContext source source_kind] ne [dict get $resourceContext source_kind] || [dict get $resourceContext source_kind] eq {} || [catch {dict size [dict get $resourceContext extension_data]}]} {error {Invalid noncanonical module ROI source claim}}
        set current [_nativeCanvasRoiOwnedImageContext $handle $logical $selected]
        if {[dict remove $owned row] ne [dict remove $current row]} {error {ROI image changed during module source classification}}
        return [dict merge $current $resourceContext [dict create extension_owner [_nativeCanvasExtensionId [dict get $current row]]]]
    }
    # This original quantitative context admits the canonical Dataset binding,
    # its Document resource and actual Native2D image, without exposing a path.
    set context [_quantitativeCanvasImage $handle $logical]
    dict set context logical $logical
    dict set context collection [native2DGeometryCall [dict get $context geometry] raster_roi_get [dict create object_token [dict get $context object_token]]]
    return $context
}
proc ::GX::_nativeCanvasRoiContext {handle logical {selected 1}} {
    set context [_nativeCanvasRoiImageContext $handle $logical $selected]
    if {[dict exists $context extension_owner]} {
        set result [_nativeCanvasExtensionCall $handle roi_context $logical $selected [_nativeCanvasRoiPublicContext $context]]
        if {$result eq {}} {error {Registered ROI source context is unavailable}}
        _nativeCanvasFields $result {source_info extension_data} {source_info}
        set info [dict get $result source_info]
        _nativeCanvasFields $info {dataset_id source_sha256 source_revision} {dataset_id source_sha256 source_revision}
        if {[dict get $info dataset_id] ne {} || [dict get $info source_sha256] ne [dict get $context image resource sha256] || [dict get $info source_revision] eq {}} {error {Module ROI source identity differs from its actual Resource}}
        set current [_nativeCanvasRoiOwnedImageContext $handle $logical $selected]
        foreach field {canvas_id geometry object_token image logical attributes canonical_binding collection} {if {[dict get $current $field] ne [dict get $context $field]} {error {ROI image changed during full module source admission}}}
        dict set context row [dict get $current row]
        dict set context source_info $info
        if {[dict exists $result extension_data]} {
            if {[catch {dict size [dict get $result extension_data]}]} {error {Module ROI extension data must remain a dictionary}}
            dict set context extension_data [dict get $result extension_data]
        }
        return $context
    }
    set info [_quantitativeRasterSourceIdentity [dict get $context source dataset_id]]
    if {[dict get $info source_sha256] ne [dict get $context image resource sha256]} {error {ROI canonical source differs from its original image resource}}
    dict set context source_info $info
    return $context
}
proc ::GX::_nativeCanvasRoiGuard {handle request {editable 0}} {
    set context [_nativeCanvasRoiContext $handle [dict get $request object]]
    set row [dict get $context row]
    if {![string is entier -strict [dict get $request expected_revision]] || [dict get $request expected_revision] != [dict get $row receipt revision]} {error {Stale Canvas revision}}
    foreach supplied {expected_source_sha256 expected_source_revision} actual {source_sha256 source_revision} {
        if {[dict get $request $supplied] ne [dict get $context source_info $actual]} {error {ROI source SHA or revision changed; rediscover its canonical source}}
    }
    if {[dict exists $request expected_roi_revision]} {
        if {![string is entier -strict [dict get $request expected_roi_revision]] || [dict get $request expected_roi_revision] != [dict get $context collection revision]} {error {ROI collection changed; read its current page before editing}}
    }
    if {$editable} {_nativeCanvasRoiEditable $context}
    return $context
}
proc ::GX::_nativeCanvasRoiEditable {context} {
    set scene [_native2DGeometryRequire [dict get $context geometry]]
    _native2DRasterEditable $scene [dict get $context object_token]
    set style [::GX::Native2D::core object_style [dict get $scene native] [dict get $context image id]]
    if {[dict get $style locked]} {error {Canvas image object is locked}}
}
proc ::GX::_nativeCanvasRoiSelected {context} {
    set row [dict get $context row]
    set scene [dict get [[dict get $row native] state scalar] scene]
    set attrs [::GX::Native2D::core identity_attributes $scene [dict get $context image id]]
    set id [datasetPublicationV2DictDefault $attrs gx.image.roi_selection {}]
    if {$id ne {} && ![dict exists $context collection rois $id]} {return {}}
    return $id
}
proc ::GX::_nativeCanvasRoiSelectionSet {context id} {
    set row [dict get $context row]
    set scene [dict get [[dict get $row native] state scalar] scene]
    # Selection is metadata on that SAME native image identity. Normal Native2D
    # Resource export already captures these attributes for History/Workspace.
    ::GX::Native2D::core identity_attribute $scene [dict get $context image id] gx.image.roi_selection $id
}
proc ::GX::_nativeCanvasRoiDefinition {context definition space} {
    _nativeCanvasFields $definition {kind points} {kind points}
    set kind [dict get $definition kind];set points [dict get $definition points]
    if {$kind ni {rectangle polygon}} {error {ROI kind must be rectangle or polygon}}
    set count [llength $points]
    if {($kind eq {rectangle} && $count!=2) || ($kind eq {polygon} && ($count<3 || $count>128))} {error {ROI requires two rectangle corners or3..128 polygon vertices}}
    foreach point $points {
        if {[llength $point]!=2} {error {ROI points require two finite coordinates}}
        foreach value $point {_nativeCanvasNumber $value -1e12 1e12 {ROI coordinate}}
    }
    set source [dict get $context collection source_resource_id]
    if {$space eq {device}} {
        set proposal [native2DGeometryCall [dict get $context geometry] raster_roi_propose [dict create object_token [dict get $context object_token] operation create kind $kind device_points $points source_resource_id $source expected_revision [dict get $context collection revision]]]
    } elseif {$space eq {source}} {
        set proposal [native2DGeometryCall [dict get $context geometry] raster_roi_geometry [dict create object_token [dict get $context object_token] definition $definition source_resource_id $source expected_revision [dict get $context collection revision]]]
    } else {error {ROI coordinate space must be source or device}}
    if {![dict get $proposal valid]} {error {Original Native2D owner refused ROI geometry}}
    return [dict get $proposal definition]
}
proc ::GX::_nativeCanvasRoiCommand {handle operation request} {
    set context [_nativeCanvasRoiGuard $handle $request [expr {$operation ne {roi_list}}]]
    set collection [dict get $context collection]
    if {$operation eq {roi_list}} {
        set offset [datasetPublicationV2DictDefault $request offset 0];set count [datasetPublicationV2DictDefault $request count 16]
        if {![string is entier -strict $offset] || $offset<0 || ![string is entier -strict $count] || $count<1 || $count>32} {error {ROI page requires offset>=0 and count1..32}}
        # Only an inert page request is retained. Every response is projected
        # afresh from the original native image; this is not another ROI store.
        set page [_nativeCanvasRoiPage $handle $context $offset $count]
        dict set ::GX::NativeCanvas::instances $handle roi_page [dict create object [dict get $request object] offset $offset count $count]
        return $page
    }
    set id [_nativeCanvasRoiIdentity [dict get $request roi_id] [expr {$operation eq {roi_select}}]]
    set exists [dict exists $collection rois $id]
    if {$operation eq {roi_create} && $exists} {error {ROI identity already exists; use explicit update}}
    if {$operation in {roi_update roi_delete} && !$exists} {error {ROI identity does not exist on this image}}
    if {$operation eq {roi_select} && $id ne {} && !$exists} {error {Selected ROI does not exist on this image}}
    set base [dict create object_token [dict get $context object_token] roi_id $id expected_revision [dict get $collection revision]]
    switch -- $operation {
        roi_create - roi_update {
            set definition [_nativeCanvasRoiDefinition $context [dict get $request definition] [datasetPublicationV2DictDefault $request space source]]
            dict set base definition $definition
            native2DGeometryCall [dict get $context geometry] raster_roi_set $base
            _nativeCanvasRoiSelectionSet $context $id
        }
        roi_delete {
            native2DGeometryCall [dict get $context geometry] raster_roi_remove $base
            if {[_nativeCanvasRoiSelected $context] eq $id} {_nativeCanvasRoiSelectionSet $context {}}
        }
        roi_select {_nativeCanvasRoiSelectionSet $context $id}
        default {error {Unknown retained Canvas ROI operation}}
    }
    # Original source/Document/Session guards also run after native mutation,
    # before the common Canvas accepted checkpoint. Its existing rollback owns
    # compensation if any admission changes in this interval.
    set current [_nativeCanvasRoiContext $handle [dict get $request object]]
    if {[dict get $current source_info] ne [dict get $context source_info]} {error {ROI canonical source changed before commit}}
    dict set ::GX::NativeCanvas::instances $handle roi_page [dict create object [dict get $request object] offset 0 count 16]
    return [dict create status ready roi_id $id]
}
proc ::GX::_nativeCanvasRoiPage {handle context offset count} {
    set collection [dict get $context collection];set keys [lsort [dict keys [dict get $collection rois]]];set rows {}
    if {$offset>[llength $keys]} {error {ROI page offset exceeds the current collection}}
    foreach id [lrange $keys $offset [expr {$offset+$count-1}]] {
        set roi [dict get $collection rois $id]
        lappend rows [dict create roi_id $id kind [dict get $roi kind] points [dict get $roi points] revision [dict get $roi revision]]
    }
    set total [llength $keys];set next [expr {min($total,$offset+[llength $rows])}]
    return [dict create object [dict get $context logical] dataset_id [dict get $context source_info dataset_id] \
        source_sha256 [dict get $context source_info source_sha256] source_revision [dict get $context source_info source_revision] \
        source_resource_id [dict get $collection source_resource_id] collection_revision [dict get $collection revision] \
        selected_roi_id [_nativeCanvasRoiSelected $context] tool [datasetPublicationV2DictDefault [dict get $context row] roi_tool roi_select] \
        offset $offset next_offset $next total $total complete [expr {$offset==0 && $next==$total}] records $rows]
}
proc ::GX::_nativeCanvasRoiPublic {handle} {
    set description [native2DCanvasDescribe $handle]
    if {[llength [dict get $description selection]]!=1} {return {}}
    set logical [lindex [dict get $description selection] 0]
    foreach object [dict get $description objects] {if {[dict get $object logical_id] eq $logical && [dict get $object kind] ne {image}} {return {}}}
    # Ordinary Canvas diagnostics must remain available for noncanonical or
    # stale images. Explicit ROI commands still refuse those sources in Guard.
    if {[catch {set context [_nativeCanvasRoiContext $handle $logical]}]} {return {}}
    set row [dict get $context row];set page [datasetPublicationV2DictDefault $row roi_page {}]
    if {[datasetPublicationV2DictDefault $page object {}] ne $logical} {set page {offset 0 count 16}}
    return [list [_nativeCanvasRoiPage $handle $context [dict get $page offset] [dict get $page count]]]
}
proc ::GX::_nativeCanvasRoiToolSet {handle tool} {
    if {$tool ni [_nativeCanvasRoiTools]} {error {Unknown retained ROI tool}}
    set row [_nativeCanvasRequire $handle]
    [dict get $row native] command tool_set {tool select}
    dict set ::GX::NativeCanvas::instances $handle roi_tool $tool
    _nativeCanvasNotify $handle tool_changed
    return [native2DCanvasDescribe $handle]
}
proc ::GX::_nativeCanvasRoiCancel {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    catch {dict unset ::GX::NativeCanvas::instances $handle roi_gesture}
    set canvas [dict get $::GX::NativeCanvas::instances $handle canvas]
    if {$canvas ne {} && [winfo exists $canvas]} {$canvas delete gx_canvas_roi_preview}
}
proc ::GX::_nativeCanvasRoiHeldRequest {context} {
    return [dict create object [dict get $context logical] expected_revision [dict get $context row receipt revision] \
        expected_source_sha256 [dict get $context source_info source_sha256] expected_source_revision [dict get $context source_info source_revision] \
        expected_roi_revision [dict get $context collection revision]]
}
proc ::GX::_nativeCanvasRoiProposal {context gesture position} {
    set request [dict create object_token [dict get $context object_token] source_resource_id [dict get $context collection source_resource_id] \
        expected_revision [dict get $context collection revision]]
    if {[dict get $gesture mode] eq {roi_rectangle}} {
        dict set request operation create;dict set request kind rectangle
        dict set request device_points [list [dict get $gesture start] $position]
    } else {
        dict set request operation [expr {[dict get $gesture mode] eq {roi_vertex}?{vertex}:{translate}}]
        dict set request roi_id [dict get $gesture roi_id]
        dict set request start_device [dict get $gesture start];dict set request end_device $position
        if {[dict get $gesture mode] eq {roi_vertex}} {dict set request index [dict get $gesture index]}
    }
    return [native2DGeometryCall [dict get $context geometry] raster_roi_propose $request]
}
proc ::GX::_nativeCanvasRoiInput {handle kind data} {
    set row [_nativeCanvasRequire $handle]
    if {![dict exists $row roi_tool]} {return 0}
    if {$kind eq {wheel}} {_nativeCanvasRoiCancel $handle;return 0}
    if {$kind eq {key}} {_nativeCanvasRoiCancel $handle;return 1}
    if {$kind ni {down move up}} {return 0}
    if {$kind eq {down}} {
        _nativeCanvasRoiCancel $handle
        if {[dict get $row pending] ne {}} {error {Cancel the pending Canvas operation before drawing ROI}}
        set selection [dict get [native2DCanvasDescribe $handle] selection]
        if {[llength $selection]!=1} {error {Select exactly one original canonical Canvas image first}}
        set context [_nativeCanvasRoiContext $handle [lindex $selection 0]]
        set held [_nativeCanvasRoiHeldRequest $context]
        _nativeCanvasRoiGuard $handle $held 1
        focus [dict get $row canvas]
        set mode [dict get $row roi_tool];set position [dict get $data position]
        if {$mode eq {roi_rectangle}} {
            set id "roi_[pid]_[clock clicks]"
            set gesture [dict create mode $mode roi_id $id start $position held $held image_state [dict get $context image state]]
        } else {
            set pick [native2DGeometryCall [dict get $context geometry] raster_roi_pick [dict create object_token [dict get $context object_token] \
                device $position tolerance 6 source_resource_id [dict get $context collection source_resource_id] expected_revision [dict get $context collection revision]]]
            if {![dict get $pick hit]} {return 1}
            set id [dict get $pick roi_id]
            if {$mode eq {roi_select}} {
                native2DCanvasCommand $handle roi_select [dict merge $held [dict create roi_id $id]]
                return 1
            }
            if {$mode eq {roi_vertex} && [dict get $pick kind] ne {vertex}} {error {Choose an original ROI vertex handle}}
            set gesture [dict create mode $mode roi_id $id index [dict get $pick index] start $position held $held image_state [dict get $context image state]]
        }
        dict set gesture source_stamp [dict get $context source source_stamp]
        dict set gesture dataset_id [dict get $context source dataset_id]
        dict set gesture source_resource_id [dict get $context collection source_resource_id]
        dict set ::GX::NativeCanvas::instances $handle roi_gesture $gesture
        return 1
    }
    if {![dict exists $row roi_gesture]} {return 1}
    set gesture [dict get $row roi_gesture]
    # Provisional geometry uses the ORIGINAL bound-image/stamp guard, not a
    # complete file SHA on every pointer frame. Mouse release still enters the
    # ordinary full-identity public mutator before ANY retained ROI write.
    set context [_nativeCanvasRoiImageContext $handle [dict get $gesture held object]]
    if {[dict get $context row receipt revision] != [dict get $gesture held expected_revision] ||
        [dict get $context collection revision] != [dict get $gesture held expected_roi_revision] ||
        [dict get $context source source_stamp] ne [dict get $gesture source_stamp] ||
        [dict get $context source dataset_id] ne [dict get $gesture dataset_id] ||
        [dict get $context collection source_resource_id] ne [dict get $gesture source_resource_id]} {error {ROI source, Canvas or collection changed during gesture}}
    _nativeCanvasRoiEditable $context
    if {[dict get $context image state] ne [dict get $gesture image_state]} {error {Original Canvas image changed during ROI gesture}}
    set proposal [_nativeCanvasRoiProposal $context $gesture [dict get $data position]]
    if {$kind eq {move}} {
        dict set gesture proposal $proposal
        dict set ::GX::NativeCanvas::instances $handle roi_gesture $gesture
        guiUpdateSchedulerRequest [dict get $row scheduler] intensive
        return 1
    }
    _nativeCanvasRoiCancel $handle
    if {[dict get $proposal valid]} {
        set request [dict merge [dict get $gesture held] [dict create roi_id [dict get $gesture roi_id] definition [dict remove [dict get $proposal definition] source_resource_id]]]
        native2DCanvasCommand $handle [expr {[dict get $gesture mode] eq {roi_rectangle}?{roi_create}:{roi_update}}] $request
    }
    guiUpdateSchedulerFinish [dict get $row scheduler]
    return 1
}
proc ::GX::_nativeCanvasRoiDraw {handle} {
    set row [_nativeCanvasRequire $handle];set canvas [dict get $row canvas]
    if {$canvas eq {} || ![winfo exists $canvas]} return
    $canvas delete gx_canvas_roi
    $canvas delete gx_canvas_roi_preview
    set selection [dict get [native2DCanvasDescribe $handle] selection]
    if {[llength $selection]!=1 || [catch {set context [_nativeCanvasRoiImageContext $handle [lindex $selection 0]]}]} return
    set selected [_nativeCanvasRoiSelected $context]
    dict for {id definition} [dict get $context collection rois] {
        set geometry [native2DGeometryCall [dict get $context geometry] raster_roi_geometry [dict create object_token [dict get $context object_token] roi_id $id]]
        if {![dict get $geometry valid]} continue
        set color [expr {$id eq $selected?{#e08d00}:{#087ea4}}]
        $canvas create polygon [concat {*}[dict get $geometry device_points]] -fill {} -outline $color -width 2 -tags gx_canvas_roi
        if {$id eq $selected} {
            foreach point [dict get $geometry handles] {
                lassign $point x y
                $canvas create rectangle [expr {$x-3}] [expr {$y-3}] [expr {$x+3}] [expr {$y+3}] -fill white -outline $color -tags gx_canvas_roi
            }
        }
    }
    if {[dict exists $row roi_gesture proposal] && [dict get $row roi_gesture proposal valid]} {
        $canvas create polygon [concat {*}[dict get $row roi_gesture proposal device_points]] -fill {} -outline #cf2700 -width 2 -dash {5 3} -tags gx_canvas_roi_preview
    }
}
::GX::nativeWorkspaceShapeRegister canvas_roi_record {record {roi_id text kind text points {array {array real}} revision int}}
::GX::nativeWorkspaceShapeRegister canvas_roi_page {record {
    object text dataset_id text source_sha256 text source_revision text source_resource_id text collection_revision int selected_roi_id text tool text
    offset int next_offset int total int complete bool records {array {named canvas_roi_record}}
}}

# Raw Script Bridge operation admission remains with
# native2d_canvas_api_v1.script_bridge_policy.json. These private facets do not
# register another API or raw worker alias. roi_create/update/delete use the
# current Canvas Document/History owner; roi_list/select address that same
# selected image identity. The public restricted C++ alternative is the owning
# Viewer's declared canvas_command, never another Host's native handle.

# Private completed-Resource contexts share this ROI owner; canonical guards
# and canvas_roi_page fields remain unchanged. Empty dataset_id on a genuine
# Working/local page explicitly means no canonical Dataset measurement source.
