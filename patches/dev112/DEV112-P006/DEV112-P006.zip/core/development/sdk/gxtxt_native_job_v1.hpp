// Script Bridge source contract scope: gxtxt_native_job_v1.script_bridge_policy.json (exact C++ signatures; documentation only, no added authority).
// SPDX-License-Identifier: GPL-3.0-or-later
// C++17 computational task SDK. This is separate from restricted GUI callbacks.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <complex>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <variant>
#include <vector>

namespace gx { namespace native_job {
struct Value {
    using Object = std::map<std::string, Value>;
    using Array = std::vector<Value>;
    std::variant<std::nullptr_t, bool, std::int64_t, double, std::string, Object, Array> data;
    Value():data(nullptr){}
    Value(bool v):data(v){}
    template<class T, typename std::enable_if<std::is_integral<T>::value && !std::is_same<T,bool>::value,int>::type = 0>
    Value(T v):data(std::int64_t(v)) {
        if constexpr (std::is_unsigned<T>::value) if (v>std::uint64_t(std::numeric_limits<std::int64_t>::max())) throw std::range_error("Use typed managed descriptor for uint64 beyond int64");
    }
    Value(double v):data(v){if(!std::isfinite(v))throw std::range_error("Nonfinite scalar requires existing typed binary transport");}
    Value(const char* v):data(std::string(v)){}
    Value(std::string v):data(std::move(v)){}
    Value(Object v):data(std::move(v)){}
    Value(Array v):data(std::move(v)){}
};
using Result = Value::Object;
inline std::string quote(const std::string& v) {
    std::ostringstream out;out<<'"';
    for(unsigned char c:v) {
        if(c=='"'||c=='\\')out<<'\\'<<char(c);
        else if(c<32)out<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<unsigned(c)<<std::dec;
        else out<<char(c);
    }
    return out.str()+'"';
}
inline std::string json(const Value& v) {
    return std::visit([](const auto& x)->std::string {
        using T=typename std::decay<decltype(x)>::type;
        if constexpr(std::is_same<T,std::nullptr_t>::value)return "null";
        else if constexpr(std::is_same<T,bool>::value)return x?"true":"false";
        else if constexpr(std::is_same<T,std::string>::value)return quote(x);
        else if constexpr(std::is_same<T,Value::Object>::value){std::string out="{";for(const auto& p:x){if(out.size()>1)out+=',';out+=quote(p.first)+':'+json(p.second);}return out+'}';}
        else if constexpr(std::is_same<T,Value::Array>::value){std::string out="[";for(const auto& p:x){if(out.size()>1)out+=',';out+=json(p);}return out+']';}
        else {std::ostringstream out;out<<std::setprecision(17)<<x;return out.str();}
    },v.data);
}
inline std::string unbase64(const std::string& s) {
    const std::string alphabet="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;unsigned acc=0;int bits=0;
    for(char c:s){if(c=='=')break;auto at=alphabet.find(c);if(at==std::string::npos)throw std::invalid_argument("Invalid task parameter encoding");acc=(acc<<6)|unsigned(at);bits+=6;if(bits>=8){bits-=8;result+=char((acc>>bits)&255);}}
    return result;
}
template<class T>inline std::string dtype_name();
template<>inline std::string dtype_name<std::int8_t>(){return "int8";}
template<>inline std::string dtype_name<std::uint8_t>(){return "uint8";}
template<>inline std::string dtype_name<std::int16_t>(){return "int16";}
template<>inline std::string dtype_name<std::uint16_t>(){return "uint16";}
template<>inline std::string dtype_name<std::int32_t>(){return "int32";}
template<>inline std::string dtype_name<std::uint32_t>(){return "uint32";}
template<>inline std::string dtype_name<std::int64_t>(){return "int64";}
template<>inline std::string dtype_name<std::uint64_t>(){return "uint64";}
template<>inline std::string dtype_name<float>(){return "float32";}
template<>inline std::string dtype_name<double>(){return "float64";}
template<>inline std::string dtype_name<std::complex<float>>(){return "complex64";}
template<>inline std::string dtype_name<std::complex<double>>(){return "complex128";}
class Buffer {
    std::string root_,resource_;
    friend class Context;
public:
    std::string dtype,units,source_alias;
    std::vector<std::size_t> shape;
    std::size_t count=0,byte_count=0;
    std::vector<unsigned char> bytes()const {
        if(byte_count>512u*1024u*1024u)throw std::length_error("Native buffer exceeds shared transport bound");
        std::ifstream stream(root_+'/'+resource_,std::ios::binary);
        std::vector<unsigned char> result(byte_count);
        if(byte_count)stream.read(reinterpret_cast<char*>(result.data()),std::streamsize(byte_count));
        if(!stream||stream.peek()!=std::char_traits<char>::eof())throw std::runtime_error("Native owned buffer size changed");
        return result;
    }
    template<class T>std::vector<T> values()const {
        if(dtype!=dtype_name<T>()||count>std::numeric_limits<std::size_t>::max()/sizeof(T)||count*sizeof(T)!=byte_count)throw std::invalid_argument("Native buffer dtype mismatch");
        auto raw=bytes();std::vector<T> result(count);if(byte_count)std::memcpy(result.data(),raw.data(),byte_count);return result;
    }
};
class Context {
    struct Field {std::string type,text;};
    std::map<std::string,Field> fields_;
    mutable double last_progress_ = 0;
    std::map<std::string,Buffer> buffers_;
    std::string buffer_root_;
    std::uint64_t output_serial_=0;
    const Field& get(const std::string& name,const std::string& type)const {
        auto it=fields_.find(name);if(it==fields_.end()||it->second.type!=type)throw std::invalid_argument("Missing or wrongly typed task parameter: "+name);return it->second;
    }
public:
    explicit Context(std::istream& input=std::cin) {
        std::string line;if(!std::getline(input,line)||line!="gxtxt.native_job_request.v1")throw std::invalid_argument("Invalid native task protocol");
        if(!std::getline(input,line))throw std::invalid_argument("Missing task field count");
        std::size_t end=0;auto count=std::stoul(line,&end);if(end!=line.size()||count>256)throw std::invalid_argument("Invalid task field count");
        std::size_t total=0;
        for(unsigned i=0;i<count;++i){if(!std::getline(input,line)||(total+=line.size())>1048576)throw std::invalid_argument("Task control input exceeds bound");auto a=line.find('\t'),b=line.find('\t',a+1);if(a==std::string::npos||b==std::string::npos)throw std::invalid_argument("Invalid task field");if(!fields_.emplace(line.substr(0,a),Field{line.substr(a+1,b-a-1),unbase64(line.substr(b+1))}).second)throw std::invalid_argument("Duplicate task field");}
        const char* root=std::getenv("GXTXT_NATIVE_BUFFER_ROOT");if(root)buffer_root_=root;
        if(std::getline(input,line)) {
            auto n=std::stoul(line,&end);if(end!=line.size()||n>256)throw std::invalid_argument("Invalid native buffer count");
            for(unsigned i=0;i<n;++i){
                if(!std::getline(input,line)||(total+=line.size())>1048576)throw std::invalid_argument("Native buffer control bound");
                std::vector<std::string> fields;std::istringstream row(line);std::string field;
                while(std::getline(row,field,'\t'))fields.push_back(field);
                if(fields.size()!=9||fields[2]!="little"||fields[3]!="F"||buffer_root_.empty())throw std::invalid_argument("Invalid native buffer descriptor");
                Buffer b;b.dtype=fields[1];b.root_=buffer_root_;b.resource_=fields[7];b.units=unbase64(fields[8]);b.source_alias=fields[0];
                if(b.resource_.size()!=36||b.resource_.substr(32)!=".bin"||b.resource_.find_first_not_of("0123456789abcdef")<32)throw std::invalid_argument("Invalid native buffer identity");
                std::istringstream dimensions(fields[4]);while(std::getline(dimensions,field,','))b.shape.push_back(std::stoull(field));
                b.count=std::stoull(fields[5]);b.byte_count=std::stoull(fields[6]);
                if(b.shape.empty()||b.shape.size()>16||!buffers_.emplace(fields[0],b).second)throw std::invalid_argument("Invalid native buffer shape/alias");
            }
        }
    }
    std::int64_t integer(const std::string& name)const {auto text=get(name,"integer").text;std::size_t n;auto v=std::stoll(text,&n);if(n!=text.size())throw std::invalid_argument("Invalid integer");return v;}
    double number(const std::string& name)const {auto it=fields_.find(name);if(it==fields_.end())throw std::invalid_argument("Missing number");if(it->second.type=="integer")return double(integer(name));auto text=get(name,"number").text;std::size_t n;auto v=std::stod(text,&n);if(n!=text.size()||!std::isfinite(v))throw std::invalid_argument("Invalid number");return v;}
    bool flag(const std::string& name)const{return get(name,"boolean").text=="1";}
    std::string text(const std::string& name)const{return get(name,"string").text;}
    const Buffer& buffer(const std::string& name)const {auto it=buffers_.find(name);if(it==buffers_.end())throw std::invalid_argument("Unadmitted native buffer alias");return it->second;}
    Value publish_bytes(const Buffer& source,const std::vector<unsigned char>& raw) {
        if(buffer_root_.empty())throw std::runtime_error("Managed native buffer scope unavailable");
        if(raw.size()!=source.byte_count)throw std::invalid_argument("Native output buffer shape/byte count mismatch");
        std::string id;
        do {std::ostringstream out;out<<std::hex<<std::setw(32)<<std::setfill('0')<<++output_serial_<<".bin";id=out.str();} while(std::ifstream(buffer_root_+'/'+id,std::ios::binary).good());
        std::ofstream stream(buffer_root_+'/'+id,std::ios::binary);if(!raw.empty())stream.write(reinterpret_cast<const char*>(raw.data()),std::streamsize(raw.size()));stream.close();if(!stream)throw std::runtime_error("Cannot publish owned native buffer");
        Value::Array shape;for(auto n:source.shape)shape.emplace_back(n);
        return Value::Object{{"__gxtxt_native_buffer__",Value::Object{{"version",2},{"dtype",source.dtype},{"endian","little"},{"order","F"},{"shape",shape},{"count",source.count},{"byte_count",source.byte_count},{"resource_id",id}}},{"units",source.units},{"source_alias",source.source_alias}};
    }
    Value publish_buffer(const Buffer& source){return publish_bytes(source,source.bytes());}
    template<class T>Value publish_buffer(const Buffer& source,const std::vector<T>& values){
        if(source.dtype!=dtype_name<T>()||values.size()!=source.count||values.size()*sizeof(T)!=source.byte_count)throw std::invalid_argument("Native typed output dtype/shape mismatch");
        std::vector<unsigned char> raw(source.byte_count);if(!raw.empty())std::memcpy(raw.data(),values.data(),raw.size());return publish_bytes(source,raw);
    }
    void progress(double fraction,const std::string& stage)const {
        if(!std::isfinite(fraction)||fraction<last_progress_||fraction>1)throw std::range_error("Progress must be monotonic in [0,1]");
        last_progress_=fraction;
        std::string escaped;for(char c:stage){if(c=='\\')escaped+="\\\\";else if(c=='\n')escaped+="\\n";else if(c=='\r')escaped+="\\r";else if(c=='\t')escaped+="\\t";else escaped+=c;}
        std::cerr<<"@@GXTXT_PROGRESS_V1@@\tfraction="<<fraction<<"\tstage="<<escaped<<std::endl;
    }
};
template<class Function>int main(Function function) {
    try {Context context;auto result=json(Value(function(context)));if(result.size()>1048576)throw std::length_error("Task result exceeds bound; use managed resources");std::cout<<result<<std::endl;return 0;}
    catch(const std::exception& error){std::cerr<<"Native task failed: "<<error.what()<<std::endl;return 1;}
}
}}
#define GXTXT_NATIVE_JOB_MAIN(function) int main(){return ::gx::native_job::main(function);}
