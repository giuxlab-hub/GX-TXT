"""Original Portable Resource export/inspection with private managed I/O."""
# SPDX-License-Identifier: GPL-3.0-or-later
import hashlib
import json
import math
from pathlib import Path
from gxtxt_script_bridge_server import BridgeError

_MAX_ARCHIVE = 64 * 1024 * 1024
REGISTRATION = {
    'api_id': 'PORTABLE_RESOURCE_API_v2', 'api_version': 2,
    'provider_kind': 'core', 'provider_id': 'portable_resource',
    'documentation_ref': 'docs/api/PORTABLE_RESOURCE_API_v2.md',
    'operations': {
        'export_group': {'name': 'export_group', 'summary': 'Export the original complete canonical Group to bounded bytes',
                         'arguments': [{'name': 'group_id', 'kind': 'canonical Group ID', 'required': True},
                                       {'name': 'expectation', 'kind': 'held source receipt', 'required': False}],
                         'result_contract': 'uint8 archive bytes, original verified metadata/source receipt; no destination pathname'},
        'inspect': {'name': 'inspect', 'summary': 'Inspect an actual owned managed archive through its original parser',
                    'arguments': [{'name': 'resource', 'kind': 'current runtime Module Document Resource', 'required': True}],
                    'result_contract': 'Original verified pathless package summary; no extraction or import authority'},
    },
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _module_call(host, command, *args):
    host.dataset_private_context()
    return host.call('::GX::_datasetPrivateWithModule', host.module_id, command, *args)


def _group(host, group_id):
    if not isinstance(group_id, str): _invalid('Choose a current canonical Group identity')
    raw = _module_call(host, '::GX::datasetGroupGet', host.session, group_id)
    group = host.as_dict(raw)
    if str(group['status']) != 'COMPLETE': _invalid('Only complete current Groups can be exported')
    identities = []
    for member in host.as_list(group['members']):
        dataset = str(host.as_dict(member)['dataset_id'])
        identities.extend((host.call('::GX::datasetRevisionToken', dataset, host.session),
                           host.call('::GX::datasetMetadataRead', host.session, dataset),
                           host.call('::GX::datasetPrivateMetadataRead', host.session, dataset)))
    parts = (host.call('::GX::interactiveDocumentSessionToken'), raw, *identities)
    stamp = hashlib.sha256('\0'.join(str(host.tcl.call('format', '%s', p)) for p in parts).encode()).hexdigest()
    return stamp


def _summary(host, path):
    try:
        raw = host.call('::GX::portableResourceInspect', str(path))
    except Exception as exc:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Original Portable Resource validation refused this archive') from exc
    result = host.as_dict(raw)
    integers = {'file_count', 'total_bytes', 'group_member_count', 'group_revision', 'dependency_count', 'native_snapshot_dataset_count'}
    lists = {'group_member_ids', 'dependency_ids', 'native_snapshot_dataset_ids', 'variable_ids'}
    allowed = {'resource_type', 'source_gxtxt_version', 'source_session_name', 'resource_identity', 'dataset_id', 'module_id', 'group_id', 'group_namespace', 'graph_id', 'variant_id', 'clone_id', 'contract', 'provider', 'capture_mode', 'archive_sha256', 'integrity'} | integers | lists
    output = {k: str(v) for k, v in result.items() if k in allowed or k.endswith('_sha256')}
    for key in integers:
        if key in result: output[key] = int(result[key])
    for key in lists:
        if key in result: output[key] = str(result[key]).split(';') if str(result[key]) else []
    if 'resource_identity' in result: output['resource_identity'] = json.loads(str(result['resource_identity']))
    if len(json.dumps(output).encode()) > 1048576: _invalid('Portable summary exceeds1MiB')
    return output


def _resource(host, value):
    required = {'api_id', 'document_id', 'owner_generation', 'sha256', 'size_bytes', 'metadata'}
    if not isinstance(value, dict) or set(value) != required or not isinstance(value['metadata'], dict):
        _invalid('Inspection requires the original current managed Resource identity')
    reference = dict(value);size = reference['size_bytes']
    if isinstance(size, bool) or not isinstance(size, (int, float)) or not math.isfinite(size) or int(size) != size or not 1 <= size <= _MAX_ARCHIVE:
        _invalid('Portable archive requires an exact byte count in1..64MiB')
    reference['size_bytes'] = int(size)
    owner = host.as_dict(host.call('::GX::interactiveDocumentMetadata', reference['document_id']))
    if str(owner['module_id']) != host.module_id or str(owner['generation']) != reference['owner_generation']:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Archive Resource belongs to another runtime Module or Document generation')
    host.call('::GX::interactiveDocumentResourceInfo', reference)
    return reference, tuple(str(owner[k]) for k in ('id', 'generation', 'revision', 'sha256'))


def invoke(host, operation, args):
    if operation == 'export_group':
        if len(args) not in (1, 2): _invalid('Group export takes its ID and optional held receipt')
        stamp = _group(host, args[0])
        if len(args) == 2:
            if not isinstance(args[1], dict) or set(args[1]) != {'sha256'}: _invalid('Held Group receipt requires exactly SHA256')
            if args[1]['sha256'] != stamp: raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Canonical Group/source changed')
    elif operation == 'inspect':
        if len(args) != 1: _invalid('Inspection takes one owned managed Resource')
        reference, owner_stamp = _resource(host, args[0]);session_stamp = str(host.call('::GX::interactiveDocumentSessionToken'))
    else:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', operation)
    allocation = host.call('::GX::resourceManagementAllocate', 'portable_resource_bridge', {'category': 'temporary', 'lifetime': 'request', 'retention_seconds': 0})
    folder = Path(str(host.as_dict(allocation)['path']))
    try:
        if not folder.is_dir() or any(p.is_symlink() for p in (folder, *folder.parents)): _invalid('Managed archive allocation is unavailable')
        path = folder / 'archive.zip'
        if operation == 'export_group':
            _module_call(host, '::GX::portableResourceExportGroup', args[0], str(path))
            if path.stat().st_size > _MAX_ARCHIVE: _invalid('Portable archive output exceeds64MiB; original parser expansion limits remain separate')
            summary = _summary(host, path)
            data = path.read_bytes()
            if _group(host, args[0]) != stamp: raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Group/source changed during export')
            return {'group_id': args[0], 'source_receipt': {'sha256': stamp}, 'archive_sha256': hashlib.sha256(data).hexdigest(),
                    'archive_size_bytes': len(data), 'bytes': host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(data), 'inspection': summary}
        digest = hashlib.sha256()
        with path.open('xb') as stream:
            for offset in range(0, reference['size_bytes'], 1048576):
                data = host.call('::GX::interactiveDocumentResourceReadChunk', reference, offset, min(1048576, reference['size_bytes']-offset))
                if not isinstance(data, bytes): _invalid('Managed archive byte type changed')
                stream.write(data);digest.update(data)
        if digest.hexdigest() != reference['sha256']: _invalid('Managed archive bytes changed')
        summary = _summary(host, path)
        _, after = _resource(host, reference)
        if after != owner_stamp or str(host.call('::GX::interactiveDocumentSessionToken')) != session_stamp:
            raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Archive Document/Session changed during inspection')
        return summary
    finally:
        host.call('::GX::documentInteractiveAllocationRelease', allocation)
