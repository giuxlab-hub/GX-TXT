"""Canonical presets for this owner-prepared registered Script snapshot only."""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
import re
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    'api_id': 'SCRIPT_PARAMETER_DATASET_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'script_execution',
    'documentation_ref': 'docs/api/SCRIPT_PARAMETER_DATASET_API_v1.md',
    'operations': {
        'save': {'name': 'save', 'host_command': '::GX::scriptParameterDatasetSave',
                 'summary': 'Create an ordinary canonical preset for this registered Script',
                 'arguments': [{'name': 'request', 'kind': 'dataset_id, parameters, optional label', 'required': True}],
                 'argument_convention': 'request struct; Script, source, producer and Session are held runtime identity',
                 'result_contract': 'committed Dataset ID/SHA and Script source/revision; raw Session revision/path omitted'},
        'load': {'name': 'load', 'host_command': '::GX::scriptParameterDatasetLoad',
                 'summary': 'Read and validate a canonical preset for this registered Script',
                 'arguments': [{'name': 'request', 'kind': 'dataset_id only', 'required': True}],
                 'argument_convention': 'request struct; no caller reference, Session, schema, review or owner context',
                 'result_contract': 'typed original parameter values, canonical SHA/Variable IDs and Script stamp; no execution grant'},
    },
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _held(host):
    config = host.config
    reference = config.get('config', 'registered_script', fallback='')
    language = config.get('config', 'script_language', fallback='')
    digest = config.get('config', 'script_sha256', fallback='')
    revision = config.get('config', 'script_revision', fallback='')
    if (host.core_service or not host.session or
            config.get('config', 'source_mode', fallback='') != 'registered_script' or
            not re.fullmatch(r'(user|session):[A-Za-z][A-Za-z0-9_.-]*', reference) or
            language not in {'Python', 'Octave'} or
            not re.fullmatch(r'[a-f0-9]{64}', digest) or
            not re.fullmatch(r'[1-9][0-9]*', revision)):
        raise BridgeError('GXTXT:ScriptParameterPreset:NoRegisteredSnapshot',
                          'Presets require this owner-prepared registered Script snapshot')
    try:
        if host.module_id != _text(host, host.call('::GX::scriptAnalysisModule', language)):
            raise ValueError('Runtime Analysis module differs')
        active = host.call('set', '::GX::DatasetPrivate::activeContext')
        if host.tcl.getint(host.tcl.call('dict', 'size', active)):
            if _text(host, host.tcl.call('dict', 'get', active, 'module_id')) != host.module_id:
                raise ValueError('Active Dataset Module differs')
        metadata = host.as_dict(host.call('::GX::scriptRegistryDescribe', reference, host.session))
        if (_text(host, metadata['language']) != language or
                _text(host, metadata['sha256']) != digest or int(metadata['revision']) != int(revision)):
            raise ValueError('Registered source snapshot changed')
        expected = host.as_dict(host.call('::GX::_scriptRegistryPinned', metadata))
        host.call('::GX::_scriptRegistryExpectedCheck', metadata, expected)
    except Exception:
        raise BridgeError('GXTXT:ScriptParameterPreset:IdentityMismatch',
                          'Registered preset source, owner or runtime Module is unavailable or changed') from None
    return reference, metadata, expected


def invoke(host, operation, args):
    if operation not in {'save', 'load'} or len(args) != 1 or not isinstance(args[0], dict):
        _invalid('Presets require one request struct')
    request = args[0]
    allowed = {'dataset_id'} | ({'parameters', 'label'} if operation == 'save' else set())
    if (set(request) - allowed or not isinstance(request.get('dataset_id'), str) or
            not 1 <= len(request['dataset_id']) <= 512):
        _invalid('Preset requests accept only a canonical Dataset ID and their declared fields')
    if operation == 'save':
        values = request.get('parameters')
        if not isinstance(values, dict) or any(not isinstance(k, str) for k in values):
            _invalid('Preset parameters require a named scalar value dictionary')
        if any(not isinstance(v, (str, int, float, bool)) or
               (isinstance(v, float) and not math.isfinite(v)) for v in values.values()):
            _invalid('Preset parameters are inert scalar text, integer, finite number or boolean values')
        label = request.get('label', '')
        if not isinstance(label, str) or len(label.encode('utf-8')) > 4096 or '\0' in label:
            _invalid('Preset display label requires bounded text')
    reference, metadata, expected = _held(host)
    dataset = request['dataset_id']
    if operation == 'save':
        # Full Registry/root expectations are private, derived at call entry.
        # The original owner locks and checks them BEFORE canonical finalize;
        # there is deliberately no post-publication wrapper refusal.
        reviewed = {key: metadata[key] for key in ('sha256', 'revision', 'parameters')}
        reviewed.update(expected)
        result = host.as_dict(host.call('::GX::scriptParameterDatasetSave', host.session,
                                        reference, values, dataset, label, reviewed, {}))
        output = {'dataset_id': _text(host, result['dataset_id']),
                  'sha256': _text(host, result['sha256']),
                  'script_sha256': _text(host, metadata['sha256']),
                  'script_revision': int(metadata['revision'])}
        return host.record_publications(output)
    result = host.as_dict(host.call('::GX::scriptParameterDatasetLoad', host.session, reference, dataset))
    host.call('::GX::_scriptRegistryExpectedCheck',
              host.call('::GX::scriptRegistryDescribe', reference, host.session), expected)
    # Manual invocation declarations, when present in a loaded preset, remain
    # ordinary validated DATA. They do not alter this Job or grant callbacks.
    schema = host.as_dict(host.call('::GX::scriptInvocationSchema', metadata, result['invocation_parameters']))
    parameters = {}
    for name, raw in host.as_dict(result['parameters']).items():
        kind = _text(host, host.as_dict(schema[name])['type'])
        if kind == 'integer':
            value = int(raw)
        elif kind in {'double', 'number'}:
            value = float(raw)
        elif kind == 'boolean':
            value = bool(host.tcl.getboolean(raw))
        else:
            value = _text(host, raw)
        parameters[name] = value
    return {'dataset_id': _text(host, result['dataset_id']), 'sha256': _text(host, result['sha256']),
            'variable_ids': [_text(host, v) for v in host.as_list(result['variable_ids'])],
            'parameters': parameters, 'script_sha256': _text(host, metadata['sha256']),
            'script_revision': int(metadata['revision'])}
