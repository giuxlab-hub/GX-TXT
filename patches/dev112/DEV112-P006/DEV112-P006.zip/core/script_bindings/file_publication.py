"""Closed return-bytes projections of the original complete-file transaction.

The original external-destination/writer-prefix interface remains distinct.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import hashlib
import math
import os
import re
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    'api_id': 'FILE_PUBLICATION_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'file_publication',
    'documentation_ref': 'docs/api/FILE_PUBLICATION_API_v1.md',
    'operations': {
        'publish_bundle': {'name': 'publish_bundle', 'summary': 'Copy owned module Document Resource readers through the original bundle transaction',
                           'arguments': [{'name': 'artifacts', 'kind': '1..16 closed {id,resource_reader} entries', 'required': True}],
                           'argument_convention': 'artifacts', 'result_contract': 'Bounded original byte artifacts/hash/count; no external destination or canonical Dataset publication'},
        'text_document': {'name': 'text_document', 'summary': 'Original UTF-8/PDF document writer into private managed output bytes',
                          'arguments': [{'name': key, 'kind': kind, 'required': key != 'options'} for key, kind in
                                        (('text', 'bounded inert Unicode text'), ('format', 'text|pdf'), ('options', 'closed page/orientation/margin settings'))],
                          'argument_convention': 'text, format, options?', 'result_contract': 'Original bounded UTF-8/PDF uint8 bytes/hash/count; no external destination'},
    },
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _session(host):
    current = _text(host, host.call('::GX::sessionInspectionCurrentSession'))
    if not host.session or current != host.session:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'File projection requires its original current execution Session')
    return _text(host, host.call('::GX::interactiveDocumentSessionToken'))


def _reader(host, token):
    binding = host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']
    if not isinstance(token, str) or token not in binding._handles(host)['readers']:
        _invalid('Use a live Document Resource reader owned by this execution')
    raw = host.as_dict(host.call('::GX::interactiveDocumentResourceReaderInfo', token))
    reference = raw['reference'];fields = host.as_dict(reference)
    host.call('::GX::interactiveDocumentResourceInfo', reference)
    document = _text(host, fields['document_id']);owner = host.as_dict(host.call('::GX::interactiveDocumentMetadata', document))
    if _text(host, owner['module_id']) != host.module_id:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Export requires a Resource of the actual execution-module Document')
    stamp = tuple(_text(host, owner[key]) for key in ('id', 'module_id', 'generation', 'revision', 'sha256'))
    if _text(host, fields['owner_generation']) != stamp[2]:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Resource Document generation changed')
    return {'reader': token, 'reference': _text(host, reference), 'offset': int(raw['offset']),
            'document': document, 'document_stamp': stamp,
            'sha256': _text(host, fields['sha256']), 'byte_count': int(fields['size_bytes']),
            'path': _text(host, host.call('::GX::_documentResourceIdentity', reference))}


def _check(host, held, session):
    if _session(host) != session or any(_reader(host, record['reader']) != record for record in held):
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'File Resource/Document/revision/Session changed during projection')


def _read(host, path, expected, maximum):
    if path.is_symlink() or not path.is_file():
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Original complete-file owner output is unavailable')
    with path.open('rb') as stream:data = stream.read(maximum+1)
    sha = hashlib.sha256(data).hexdigest()
    if len(data) > maximum or sha != expected:
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Original output changed or exceeds the return-bytes bound')
    return {'sha256': sha, 'byte_count': len(data),
            'bytes': host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(data)}


def _run(host, operation, args):
    from gxtxt_resource_manager import ResourceManager
    session = _session(host);held = [];artifacts = [];settings = None
    if operation == 'publish_bundle':
        if len(args) != 1 or not isinstance(args[0], list) or not 1 <= len(args[0]) <= 16:
            _invalid('Bundle requires1..16 closed Resource-reader artifacts')
        total = 0;ids = set()
        for item in args[0]:
            if not isinstance(item, dict) or set(item) != {'id', 'resource_reader'}:
                _invalid('Artifact accepts only id and execution-owned resource_reader')
            name = item['id']
            if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,47}', name) or name in ids:
                _invalid('Artifact IDs must be distinct bounded inert labels')
            ids.add(name);record = _reader(host, item['resource_reader']);total += record['byte_count']
            if record['byte_count'] > 16777216 or total > 33554432:_invalid('Bundle byte bounds exceeded')
            held.append(record);artifacts.append({'id': name})
        _check(host, held, session)
    else:
        if not 2 <= len(args) <= 3 or not isinstance(args[0], str) or args[1] not in ('text', 'pdf'):
            _invalid('Text document requires bounded inert text and text|pdf')
        text, format = args[:2]
        if len(text.encode('utf-8')) > 65536 or text.count('\n') > 1024:
            _invalid('Document text exceeds64KiB/1024 line-break bound')
        settings = args[2] if len(args)>2 else {}
        if not isinstance(settings, dict) or set(settings)-{'page', 'orientation', 'margin_mm'}:
            _invalid('Document options accept page/orientation/margin_mm only')
        settings = dict(settings)
        if settings.get('page', 'A4') not in ('A4', 'A3', 'LETTER') or settings.get('orientation', 'portrait') not in ('portrait', 'landscape'):
            _invalid('Select an original supported compositor page/orientation')
        margin = settings.get('margin_mm', 15)
        if type(margin) not in (int, float) or not math.isfinite(margin) or not 0 <= margin <= 50:
            _invalid('Document margin must be finite0..50mm')
        settings['margin_mm'] = margin
    manager = ResourceManager();allocation = None
    try:
        allocation = manager.allocate('script_file_publication', kind='directory', job_id=os.environ.get('GXTXT_JOB_ID', ''), session=host.session)
        root = Path(allocation['path'])
        if operation == 'publish_bundle':
            for i, (artifact, record) in enumerate(zip(artifacts, held)):
                artifact.update(destination=str(root/('artifact-'+str(i)+'.bin')),
                                writer=['::GX::_filePublicationCopyWriter', record['path'], record['sha256']])
            _check(host, held, session)
            raw = host.call('::GX::filePublicationPublishBundle', artifacts, 'create_only')
        else:
            destination = root/('document.'+('txt' if format=='text' else 'pdf'))
            raw = host.call('::GX::filePublicationTextDocument', str(destination), text, format, settings)
        _check(host, held, session)
        receipt = host.as_dict(raw);files = host.as_dict(receipt['files']);result = {}
        if operation == 'publish_bundle' and set(files) != {item['id'] for item in artifacts}:
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Original bundle receipt membership changed')
        for name, value in files.items():
            value = host.as_dict(value);path = Path(_text(host, value['destination']))
            if path.parent != root or path.is_symlink():
                raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Original output escaped its private managed allocation')
            data = _read(host, path, _text(host, value['sha256']), 16777216 if operation=='publish_bundle' else 8388608)
            if data['byte_count'] != int(value['byte_count']):
                raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Original complete-file byte count changed')
            if operation == 'publish_bundle':
                record = held[next(i for i,item in enumerate(artifacts)if item['id']==name)]
                if data['sha256'] != record['sha256']:_invalid('Original Resource copy content changed')
                data['document_id'] = record['document']
            else:data['media_type'] = 'text/plain;charset=utf-8' if format=='text' else 'application/pdf'
            result[_text(host, name)] = data
        _check(host, held, session)
        return {'api_id': 'FILE_PUBLICATION_API_v1', 'profile': 'current_execution_return_bytes',
                'files': result, 'canonical_dataset_publication': False, 'external_destination_authority': False}
    finally:
        if allocation is not None:
            # Original synchronous writer has returned/failed before release.
            # PDF's unchanged exec uses its original temporary scratch path and
            # outer managed Job group/lease, not this target allocation.
            manager.release(allocation['id']);manager.cleanup([allocation['id']])
        manager.close()


def invoke(host, operation, args):
    if operation not in REGISTRATION['operations']:_invalid('Unknown closed File Publication operation')
    return _run(host, operation, args)
