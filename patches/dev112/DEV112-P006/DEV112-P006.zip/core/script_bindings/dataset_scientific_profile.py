"""Read-only queries of the existing CORE Scientific Profile authority."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
REGISTRATION = {
    'api_id': 'DATASET_SCIENTIFIC_PROFILE_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'dataset_scientific_profile',
    'documentation_ref': 'docs/api/DATASET_SCIENTIFIC_PROFILE_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Nonmutating profile '+name,
        'arguments': [{'name': 'request', 'kind': 'struct', 'required': True}],
        'argument_convention': 'request struct', 'result_contract': 'honest available profile; no source scan',
        'result_convention': 'struct'} for name in ('describe', 'variable', 'distinct')}}
for _name, _command in {'read':'datasetScientificProfileRead',
                        'discover':'datasetScientificProfileDiscover'}.items():
    REGISTRATION['operations'][_name] = {
        'name':_name, 'summary':'Read canonical stored profile' if _name=='read' else
                                   'Discover bounded canonical categorical values without persistence',
        'host_command':'::GX::'+_command,
        'arguments':[{'name':'request','kind':'struct with dataset_id and optional row_budget/value_budget for discover','required':True}],
        'argument_convention':'request struct; Session is the execution Session',
        'result_contract':'source-owned categorical profile with lexical values, exact budget/count fields and completeness flags'}

def summary(host, raw):
    s = host.as_dict(raw)
    # These are scalar text fields declared by the existing profile owners.
    # A Tcl object's cached list representation must not change their type.
    for key in ('variable_id', 'label', 'unit', 'type', 'dtype', 'status',
                'reason', 'extrema_status', 'monotonicity', 'missing_policy'):
        if key in s:
            s[key] = str(host.tcl.call('format', '%s', s[key]))
    if 'values' in s:
        # Lexical values preserve the exact filter transport. Dtype remains
        # explicit; never round int64/float values through JSON double here.
        s['values'] = host.as_list(s['values'])
    for key in ('observed', 'finite', 'missing', 'nan', 'positive_infinity',
                'negative_infinity', 'invalid', 'total', 'retained_bytes', 'scanned_rows'):
        if key in s: s[key] = int(s[key])
    for key in ('complete', 'distinct_complete', 'strict', 'moments_available', 'moments_exact','truncated'):
        if key in s: s[key] = bool(int(s[key]))
    return s

def invoke(host, operation, args):
    if len(args) != 1 or not isinstance(args[0], dict):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Profile requires a request struct')
    r = args[0]
    if operation in {'read','discover'}:
        allowed = {'dataset_id'} | ({'row_budget','value_budget'} if operation=='discover' else set())
        if set(r)-allowed or not isinstance(r.get('dataset_id'),str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Canonical profile requires a Dataset ID and admitted budgets only')
        parameters = [host.session,r['dataset_id']]
        if operation=='discover':
            import math
            budgets = [r.get('row_budget',100000),r.get('value_budget',1024)]
            if any(isinstance(value,bool) or not isinstance(value,(int,float)) or
                   not math.isfinite(value) or int(value)!=value for value in budgets):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Profile budgets require finite integer scalars')
            parameters.extend(int(value) for value in budgets)
        command = '::GX::datasetScientificProfile'+('Read' if operation=='read' else 'Discover')
        p = host.as_dict(host.call(command,*parameters))
        p['content_identity'] = host.as_dict(p['content_identity'])
        p['scientific_schema_identity'] = str(p['scientific_schema_identity'])
        p['operations'] = [str(value) for value in host.as_list(p['operations'])]
        p['variables'] = [summary(host,value) for value in host.as_list(p['variables'])]
        if 'summaries' in p:
            p['summaries'] = {str(key):summary(host,value) for key,value in host.as_dict(p['summaries']).items()}
        for key in ('api_version','profile_revision','row_budget','value_budget',
                    'value_bytes_max','profile_value_bytes_max','scanned_variables_max','summary_revision','summary_crc32'):
            if key in p:p[key] = int(p[key])
        p['persistent'] = bool(host.tcl.getboolean(p['persistent']))
        return p
    if operation == 'describe':
        p = host.as_dict(host.call('::GX::datasetProfileDescribe', host.session, r['dataset_id']))
        p['content_identity'] = host.as_dict(p['content_identity'])
        # Scientific schema identity is the established opaque CORE stamp.
        p['scientific_schema_identity'] = str(p['scientific_schema_identity'])
        p['structure'] = [host.as_dict(v) for v in host.as_list(p['structure'])]
        p['variables'] = [summary(host, v) for v in host.as_list(p['variables'])]
        if 'summaries' in p: p['summaries'] = {k:summary(host,v) for k,v in host.as_dict(p['summaries']).items()}
        return p
    if operation == 'variable':
        s = summary(host, host.call('::GX::datasetProfileVariable', host.session, r['dataset_id'], r['variable_id']))
        s['structure'] = host.as_dict(s['structure'])
        return s
    if operation == 'distinct':
        p = host.as_dict(host.call('::GX::datasetProfileDistinct', host.session, r['dataset_id'], r['variable_id'], r.get('options', {})))
        p['values'] = host.as_list(p['values'])
        for key in ('returned','next','retained_count','observed'): p[key] = int(p[key])
        p['complete'] = bool(int(p['complete']))
        if p['cardinality'] != 'unknown': p['cardinality'] = int(p['cardinality'])
        return p
    raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown profile operation')
