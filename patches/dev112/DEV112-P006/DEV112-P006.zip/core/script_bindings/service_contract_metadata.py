"""Literal service contracts from their existing CORE owners, without execution."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

# Existing API identity: exact operation and original fixed Tcl command.
_GETTERS = {
    'OCR_LAYOUT_API_v1': ('capabilities', '::GX::OCRLayoutAPIv1::capabilities', 'list'),
    'SCIENTIFIC_SPECTRUM_API_v1': ('api_info', '::GX::SpectrumAPIv1::apiInfo', 'dict'),
    'SCIENTIFIC_SPECTRUM_SESSION_API_v1': ('api_info', '::GX::SpectrumSessionAPIv1::apiInfo', 'dict'),
    'TABLE_EXTRACTOR_API_v1': ('capabilities', '::GX::TableExtractorAPIv1::capabilities', 'list'),
    'VIEWER_COMPONENT_DEMO_API_v1': ('api_info', '::GX::viewerGuiComponentDemoApiInfo', 'dict'),
}
REGISTRATIONS = [
    {'api_id': api, 'api_version': 1, 'provider_kind': 'core', 'provider_id': 'CORE',
     'documentation_ref': 'docs/api/'+api+'.md',
     'operations': {operation: {
         'name': operation, 'summary': 'Read the original inert CORE service contract',
         'arguments': [], 'argument_convention': 'no arguments', 'host_command': command,
         'result_contract': 'Complete original typed metadata or ordered declared feature strings; listed methods/features grant no invocation or actual tool availability',
     }}}
    for api, (operation, command, _) in _GETTERS.items()
]


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def invoke_api(host, api_id, operation, args):
    getter = _GETTERS.get(api_id)
    if getter is None or operation != getter[0]:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown literal service metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Literal service metadata takes no arguments')
    _, command, kind = getter
    raw = host.call(command)
    if kind == 'list':
        return [_text(host, value) for value in host.as_list(raw)]
    fields = host.as_dict(raw)
    result = {_text(host, key): _text(host, value) for key, value in fields.items()}
    for key in ('api_version', 'fixture_version', 'page_samples_max'):
        if key in fields:
            result[key] = int(fields[key])
    for key in ('domain_handlers', 'publication'):
        if key in fields:
            result[key] = bool(host.tcl.getboolean(fields[key]))
    for key in ('operations', 'host_validation_operations', 'modes'):
        if key in fields:
            result[key] = [_text(host, value) for value in host.as_list(fields[key])]
    return result


# Additional exact value facets of the existing CORE registrations. Existing
# five getters and their descriptors/invocation paths above remain unchanged.
_VALUE_FACETS = {
    'OCR_LAYOUT_API_v1': {
        'supports': ('::GX::OCRLayoutAPIv1::supports', ('capability',), 'boolean'),
        'requireCapability': ('::GX::OCRLayoutAPIv1::requireCapability', ('capability',), 'integer'),
    },
    'TABLE_EXTRACTOR_API_v1': {
        'supports': ('::GX::TableExtractorAPIv1::supports', ('capability',), 'boolean'),
        'tableToMatrix': ('::GX::TableExtractorAPIv1::tableToMatrix', ('table',), 'text_matrix'),
        'tableToCsv': ('::GX::TableExtractorAPIv1::tableToCsv', ('table', 'options'), 'text'),
    },
}
for _registration in REGISTRATIONS:
    for _name, (_command, _fields, _result) in _VALUE_FACETS.get(_registration['api_id'], {}).items():
        _registration['operations'][_name] = {
            'name': _name, 'summary': 'Use the original in-memory CORE value owner: ' + _name,
            'host_command': _command,
            'arguments': [{'name': field, 'kind': 'string' if field == 'capability' else 'struct',
                           'required': field != 'options'} for field in _fields],
            'argument_convention': ', '.join(_fields) + ('; options omitted uses original {} default' if _name == 'tableToCsv' else ''),
            'result_contract': ('original capability boolean; no tool availability probe' if _result == 'boolean' else
                                'original integer 1 or original unsupported-capability error' if _result == 'integer' else
                                'exact ragged text matrix; <=256 rows/columns, 4096 cells and 1 MiB input text' if _result == 'text_matrix' else
                                'original CSV text, no file write; bounded text matrix as tableToMatrix, <=2 MiB result'),
        }


def _value_invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text_table(table):
    if not isinstance(table, dict):
        _value_invalid('Table must be a struct')
    # Missing matrix reaches the original owner's exact missing-field error.
    if 'matrix' not in table:
        return
    matrix = table['matrix']
    if not isinstance(matrix, (list, tuple)) or len(matrix) > 256:
        _value_invalid('Matrix must contain at most 256 text rows')
    cells = byte_count = 0
    for row in matrix:
        if not isinstance(row, (list, tuple)) or len(row) > 256:
            _value_invalid('Each matrix row must contain at most 256 text cells')
        cells += len(row)
        if any(not isinstance(value, str) for value in row):
            _value_invalid('Matrix cells must be text; no inferred numeric conversion')
        byte_count += sum(len(value.encode('utf-8')) for value in row)
        if cells > 4096 or byte_count > 1048576:
            _value_invalid('Text matrix exceeds 4096 cells or 1 MiB')


_established_invoke_api = invoke_api


def invoke_api(host, api_id, operation, args):
    facet = _VALUE_FACETS.get(api_id, {}).get(operation)
    if facet is None:
        return _established_invoke_api(host, api_id, operation, args)
    command, fields, result_kind = facet
    minimum = 1
    if not minimum <= len(args) <= len(fields):
        _value_invalid('Value operation requires its exact arguments')
    if fields[0] == 'capability':
        if not isinstance(args[0], str) or len(args[0].encode('utf-8')) > 4096:
            _value_invalid('Capability must be text of at most 4096 bytes')
    else:
        _text_table(args[0])
        if len(args) == 2 and not isinstance(args[1], dict):
            _value_invalid('CSV options must be a struct')
        if len(args) == 2 and 'separator' in args[1] and not isinstance(args[1]['separator'], str):
            _value_invalid('CSV separator must be text; original owner checks its length')
    raw = host.call(command, *args)
    if result_kind == 'boolean':
        return bool(host.tcl.getboolean(raw))
    if result_kind == 'integer':
        return int(raw)
    if result_kind == 'text_matrix':
        return [[_text(host, cell) for cell in host.as_list(row)] for row in host.as_list(raw)]
    result = _text(host, raw)
    if len(result.encode('utf-8')) > 2097152:
        raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original CSV exceeds 2 MiB transport bound')
    return result


# Supplied-value algorithms remain exclusively in the original CORE owners.
from gxtxt_script_values_v1 import descriptor as _value_descriptor, invoke as _whole_value
_WHOLE_VALUES = {
    'OCR_LAYOUT_API_v1': {'toText': (['layoutOrDocument', 'options'], True),
                         'filterRoi': (['layout', 'roi'], False)},
    'TABLE_EXTRACTOR_API_v1': {'extractLayout': (['layout', 'options'], True)},
}
for _registration in REGISTRATIONS:
    for _name, (_fields, _optional) in _WHOLE_VALUES.get(_registration['api_id'], {}).items():
        _registration['operations'][_name] = _value_descriptor(
            _name, _fields, 'Original text (whole TclValue for non-scalar Unicode)' if _name == 'toText'
            else 'Complete original structured result as opaque whole TclValue; open fields preserved', _optional)
        _registration['operations'][_name]['host_command'] = (
            '::GX::OCRLayoutAPIv1::' if _registration['api_id'] == 'OCR_LAYOUT_API_v1' else '::GX::TableExtractorAPIv1::') + _name
_previous_value_invoke = invoke_api

def invoke_api(host, api_id, operation, args):
    if operation in _WHOLE_VALUES.get(api_id, {}):
        return _whole_value(host, api_id, operation, args)
    return _previous_value_invoke(host, api_id, operation, args)


from gxtxt_design_values_v1 import component as _component_value
for _registration in REGISTRATIONS:
    if _registration['api_id'] == 'VIEWER_COMPONENT_DEMO_API_v1':
        for _name, _fields in (('catalog', []), ('register', ['type', 'spec'])):
            _registration['operations'][_name] = _value_descriptor(
                _name, _fields, 'Entire original component catalog/current specification map; inert open properties preserved as whole TclValues')
            _registration['operations'][_name]['host_command'] = '::GX::viewerGuiComponentDemo' + _name.title()
_previous_component_invoke = invoke_api

def invoke_api(host, api_id, operation, args):
    if api_id == 'VIEWER_COMPONENT_DEMO_API_v1' and operation in ('catalog', 'register'):
        return _component_value(host, operation, args)
    return _previous_component_invoke(host, api_id, operation, args)
