"""The existing graphics policy data, without a widget or scheduler lifetime."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    'api_id': 'GUI_UPDATE_SCHEDULER_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'gui_update_scheduler',
    'documentation_ref': 'docs/api/GUI_UPDATE_SCHEDULER_API_v1.md',
    'operations': {'graphics_policy': {
        'name': 'graphics_policy', 'summary': 'Read this interpreter current declared graphics policy',
        'host_command': '::GX::guiUpdateSchedulerGraphicsPolicy', 'arguments': [],
        'result_contract': 'Original profile text and adaptive_ms integer; no settings mutation, widget, callback or scheduler handle',
    }},
}


def invoke(host, operation, args):
    if operation != 'graphics_policy' or args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Graphics policy takes no arguments')
    result = host.as_dict(host.call('::GX::guiUpdateSchedulerGraphicsPolicy'))
    return {'profile': str(host.tcl.call('format', '%s', result['profile'])),
            'adaptive_ms': int(result['adaptive_ms'])}
