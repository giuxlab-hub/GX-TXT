"""Execution-owned Native2D geometry with bounded typed transport."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray
import math

_OPERATIONS = "raster_annotation_get raster_annotation_project raster_annotation_remove raster_annotation_set raster_dataset_bind raster_roi_geometry raster_roi_pick raster_roi_propose raster_snapshot raster_save raster_restore raster_roi_set raster_roi_get raster_roi_remove raster_layer_get raster_layer_update raster_prepare raster_submit raster_freeze axis_presentation composition_parts composition_traversal part_direction part_direction_batch part_render part_marker_geometry part_marker_hit part_marker_place part_pick image_calibration_reset selection_definition spline_line_plan spline_span_to_line composition_create composition_part composition_split composition_explode path_vertices path_split path_join primitive_publish dataset_promote selection_pick selection_region selection_set_apply selection_set_restore selection_set_bounds image_attach image_get image_update image_calibrate image_map symmetry_preview symmetry_construct canvas_preview spline_tangent_get spline_tangent_edit fit_all fit_selected fit_bounds zoom pan scene_bounds world_to_device device_to_world pixel_tolerance construct_attached placement_points placement_preview reference_connected sketch_status sketch_component dimension_infer dimension_preview dimension_apply dimension_geometry relationship_state relationship_hit construct construct_preview from_fit controls reference reference_resolve reference_point_index control_definition control_edit constraint_options constraint_apply constraint_location polar_bulk compare_geometry geometry_role series_create series_get series_list series_members series_update series_transform series_bounds series_delete series_explode saved_view_create saved_view_get saved_view_list saved_view_update saved_view_restore saved_view_delete view_state view_state_rescale layer_create layer_get layer_list layer_update layer_delete layer_assign selection_set_create selection_set_get selection_set_list selection_set_update selection_set_add_member selection_set_remove_member selection_set_delete selection_set_activate identity fragment_create fragment_get fragment_list fragment_update fragment_delete fragment_sample fragment_length fragment_bounds fragment_materialize sketch sketch_update sketch_evaluate sketch_sample sketch_materialize sketch_explode curve from_source describe metrics measure path_point replace_points points_page nearest_vertex rescale_coordinates affine series group group_members group_add group_remove ungroup delete endpoint_frame bridge spline compare selection pivot grid polar view style direction export_resource restore_resource constraint_create constraint_join constraint_get constraint_list constraint_update constraint_enable constraint_delete checkpoint".split()
_RASTER_FIELDS = {
    'raster_annotation_get': ({'object_token'}, {'object_token'}),
    'raster_annotation_project': ({'object_token'}, {'object_token'}),
    'raster_annotation_remove': ({'object_token', 'expected_revision', 'annotation_id'}, {'object_token', 'expected_revision', 'annotation_id'}),
    'raster_annotation_set': ({'object_token', 'expected_revision', 'annotation_id', 'definition'}, {'object_token', 'expected_revision', 'annotation_id', 'definition'}),
    'raster_dataset_bind': ({'dataset_id', 'options'}, {'dataset_id'}),
    'raster_roi_geometry': ({'object_token', 'roi_id', 'definition', 'expected_revision', 'source_resource_id'}, {'object_token'}),
    'raster_roi_pick': ({'object_token', 'device', 'tolerance', 'roi_id', 'expected_revision', 'source_resource_id'}, {'object_token', 'device', 'tolerance'}),
    'raster_roi_propose': ({'object_token', 'operation', 'roi_id', 'kind', 'device_points', 'start_device', 'end_device', 'index', 'expected_revision', 'source_resource_id'}, {'object_token', 'operation'}),
}
_ARGS = {"api_info": [], "open": ["document_id"], "close": ["scene"]}
_ARGS["path_validate"] = ["points", "topology"]
_PURE_REQUESTS = {
    "distance": {"point_a", "point_b"},
    "angle_normalize": {"angle", "degrees"},
    "rotation_matrix_degrees": {"pivot", "degrees"},
    "scaling_matrix": {"pivot", "scale"},
    "reflection_matrix": {"axis_a", "axis_b"},
}
_VALUE_REQUESTS = {
    "definition_validate": {"definition"},
    "definition_evaluate": {"definition", "parameter"},
    "definition_bounds": {"definition"},
    "definition_sample": {"definition", "first", "last", "total", "start", "count"},
    "numeric_pack": {"points", "source_rows", "row_base"},
}
_ARGS.update({name: ["request"] for name in _PURE_REQUESTS})
_ARGS.update({name: ["request"] for name in _VALUE_REQUESTS})
_ARGS.update({name: ["scene", "request"] for name in _OPERATIONS})
_DIAGRAM_ARGS = {
    'diagram_catalog': (['catalog_id'], 0),
    'diagram_create': (['provider_id', 'catalog_id'], 2),
    'diagram_read': (['document_id'], 1),
    'diagram_validate': (['payload'], 1),
    'diagram_endpoint': (['payload', 'endpoint'], 2),
    'diagram_edit': (['document_id', 'expected', 'operation', 'request', 'mode'], 4),
    'diagram_project': (['document_id', 'preview'], 1),
}
_ARGS.update({name: fields for name, (fields, _) in _DIAGRAM_ARGS.items()})
_OWNED_ARGS = {
    'canvas_create': (['provider_id', 'options'], 1),
    'canvas_capture': (['canvas'], 1), 'canvas_restore': (['canvas', 'snapshot'], 2),
    'canvas_command': (['canvas', 'operation', 'request'], 2),
    'canvas_describe': (['canvas'], 1), 'canvas_dispose': (['canvas'], 1),
    'sketch_quick_open_list': (['documents', 'target_unit', 'rebuild'], 1),
    'sketch_quick_open_publish': (['document_id', 'target_unit'], 1),
    'sketch_quick_open_presentation': (['document_id', 'target_unit'], 1),
    'sketch_quick_open_status': ([], 0),
    'cad_sketch_is_managed': (['sketch_name'], 1),
    'cad_action_states': (['sketch_name'], 0),
    'cad_action_state': (['sketch_name', 'action'], 2),
}
_ARGS.update({name: fields for name, (fields, _) in _OWNED_ARGS.items()})
REGISTRATION = {
    "api_id": "NATIVE_2D_GEOMETRY_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "native2d_geometry",
    "documentation_ref": "docs/api/NATIVE_2D_GEOMETRY_API_v1.md",
    "operations": {name: {"name": name, "summary": "Scoped retained Native2D geometry: " + name,
                           "arguments": [{"name": arg, "kind": "opaque token" if arg == "scene" else "public value", "required": True} for arg in args],
                           "argument_convention": ", ".join(args), "result_contract": "opaque tokens or bounded typed public geometry",
                           "result_convention": "public geometry receipt"} for name, args in _ARGS.items()},
}
for _name in _PURE_REQUESTS:
    REGISTRATION["operations"][_name].update(
        summary="Pure Native2D owner query without a retained scene: " + _name,
        arguments=[{"name": "request", "kind": "struct with exact fields: " + ", ".join(sorted(_PURE_REQUESTS[_name])), "required": True}],
        result_contract="finite scalar in the supplied coordinate/angle unit" if _name in {"distance", "angle_normalize"} else "six finite affine coefficients xx,xy,yx,yy,x0,y0; rotation input is degrees",
        result_convention="numeric scalar or six-element numeric vector; no scene/resource handle or publication",
    )

for _name, (_fields, _minimum) in _DIAGRAM_ARGS.items():
    REGISTRATION['operations'][_name].update(
        summary='Canonical Native2D diagram metadata/Document/geometry owner: '+_name,
        arguments=[{'name': field, 'kind': 'typed public value', 'required': index < _minimum}
                   for index, field in enumerate(_fields)],
        result_contract='Copied diagram metadata/canonical Document/owned scene projection; connectivity stays with existing Document owner',
    )
for _name, (_fields, _minimum) in _OWNED_ARGS.items():
    REGISTRATION['operations'][_name].update(
        summary='Existing Native2D Document/native/cache data owner: '+_name,
        arguments=[{'name': field, 'kind': 'typed public value', 'required': index < _minimum}
                   for index, field in enumerate(_fields)],
        result_contract='Execution-owned headless Canvas or copied saved-Sketch/native action metadata; native Workspace kinds retain Resource identity',
    )
for _name, _fields in _VALUE_REQUESTS.items():
    REGISTRATION['operations'][_name].update(
        summary='Bounded value query through the existing Native2D kernel: '+_name,
        arguments=[{'name': 'request', 'kind': 'struct with exact fields: '+', '.join(sorted(_fields)), 'required': True}],
        result_contract='Typed value/geometry receipt; packing returns float64 XY and exact uint64 row bytes in canonical little endian Base64',
        result_convention='No retained object, file path, pointer, callback or publication',
    )


def _uint64_value(value):
    if (isinstance(value, bool) or not isinstance(value, (int, float)) or
            isinstance(value, float) and (not math.isfinite(value) or value != math.trunc(value) or abs(value) > 2**53) or
            not 0 <= value < 2**64):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'An exact unsigned64 identity is required; large identities require integer values')
    return int(value)


def _bounded_points(value):
    if isinstance(value, NumericArray):
        if value.dtype not in ('float32', 'float64') or not (value.shape == [2] or len(value.shape) == 2 and value.shape[1] == 2):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Coordinates require a real float32/float64 Nx2 matrix')
        count = len(value.values)//2
    elif isinstance(value, (list, tuple)) and all(isinstance(row, (list, tuple)) and len(row) == 2 for row in value):
        count = len(value)
    else:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Coordinates require an Nx2 matrix')
    if count > 65536:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'A value query is limited to65536 coordinate pairs')
    return count


def _bounded_definition(value, depth=0):
    if not isinstance(value, dict) or depth > 1:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'A bounded unnested public sketch definition is required')
    if 'parts' in value:
        parts = value['parts']
        if not isinstance(parts, (list, tuple)) or not 1 <= len(parts) <= 256:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'A composition requires1..256 primitive parts')
        total = 0
        for part in parts:
            if not isinstance(part, dict) or 'definition' not in part:
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'A composition part requires its definition')
            total += _bounded_definition(part['definition'], depth+1)
    else:
        total = _bounded_points(value.get('controls'))
    if total > 65536:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'A definition query is limited to65536 total controls')
    return total


def _value_request(operation, request):
    if not isinstance(request, dict) or set(request) != _VALUE_REQUESTS[operation]:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Value query requires its exact documented request fields')
    request = dict(request)
    if operation != 'numeric_pack':
        _bounded_definition(request['definition'])
        if operation == 'definition_sample':
            for field in ('total', 'start', 'count'):
                value = _uint64_value(request[field])
                if value > 1000000:
                    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Sampling index exceeds the bounded native grid')
                request[field] = value
    else:
        count = _bounded_points(request['points'])
        rows = request['source_rows']
        if isinstance(rows, NumericArray):
            if rows.dtype not in ('int8','uint8','int16','uint16','int32','uint32','int64','uint64','float32','float64'):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Source rows require real integer identities')
            if len(rows.shape) > 2 or len(rows.shape) == 2 and all(size > 1 for size in rows.shape):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Source rows require a vector')
            rows = [int(v) if rows.dtype.startswith(('int', 'uint')) else float(v) for v in rows.values]
        elif isinstance(rows, (int, float)) and not isinstance(rows, bool):
            rows = [rows]
        if not isinstance(rows, (list, tuple)) or len(rows) not in (0, count):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Source rows must be empty or match every XY row')
        request['source_rows'] = [_uint64_value(row) for row in rows]
        request['row_base'] = _uint64_value(request['row_base'])
    return request


def _state(host):
    return host.handles.setdefault("native2d_geometry", {"scenes": set()})


def _array(host, raw):
    return NumericArray([float(value) for value in host.as_list(raw)])


def _matrix(host, raw):
    rows = [host.as_list(row) for row in host.as_list(raw)]
    if not rows:
        return NumericArray([], [0, 2])
    return NumericArray([float(row[column]) for column in range(2) for row in rows], [len(rows), 2])


def _axis_presentation(host, raw):
    result = {}
    for axis, settings in host.as_dict(raw).items():
        fields = host.as_dict(settings)
        if 'ticks' in fields:
            ticks = host.as_dict(fields['ticks'])
            if 'precision' in ticks:
                ticks['precision'] = int(ticks['precision'])
            if ticks.get('step', 'auto') != 'auto':
                ticks['step'] = float(ticks['step'])
            fields['ticks'] = ticks
        if 'context' in fields:
            context = host.as_dict(fields['context'])
            if 'image_id' in context:
                context['image_id'] = int(context['image_id'])
            fields['context'] = context
        result[axis] = fields
    return result


def _receipt(host, raw):
    result = host.as_dict(raw)
    series_parameters = "columns" in result and "rows" in result
    for key, value in list(result.items()):
        if key == "axis_presentation":
            result[key] = _axis_presentation(host, value)
        elif key == "coordinate_units":
            result[key] = host.as_list(value)
        elif key in {"coordinate_relations", "original_source_variable_schema"}:
            # Ordered axis meanings retain the Unit Registry's literal strings.
            # Decode structure only; this transport does not evaluate relations.
            result[key] = {axis: host.as_dict(fields)
                           for axis, fields in host.as_dict(value).items()}
        elif key == "coordinate_frame":
            frame = host.as_dict(value)
            result[key] = {"schema_version": int(frame["schema_version"]), "method": frame["method"],
                           **{name: host.as_list(frame[name]) for name in ("reference_units", "target_units", "output_units")},
                           **{name: _array(host, frame[name]) for name in ("reference_matrix", "target_matrix")}}
        elif key == "statistics":
            binding = host.modules["STATISTICAL_RESULT_SEMANTICS_API_v1"]
            result[key] = {name: binding.invoke(host, "validated_result", [record])
                           for name, record in host.as_dict(value).items()}
        elif key.endswith("_base64"):
            result[key] = value.decode("ascii") if isinstance(value, bytes) else str(value)
        elif key == "cells":
            result[key] = {k: host.as_list(v) for k,v in host.as_dict(value).items()}
        elif key == "attributes":
            result[key] = host.as_dict(value)
        elif key == "metadata" and result.get("api_id") == "INTERACTIVE_DOCUMENT_RESOURCE_API_v1":
            # Same opaque metadata representation as MANAGED_RESOURCE_API_v1.
            # A provenance origin record must never be decoded as an XY vector.
            result[key] = host.as_dict(value)
        elif key == "rois":
            result[key] = {name: _receipt(host, record) for name, record in host.as_dict(value).items()}
        elif key in {"roi", "source_snapshot", "ticket"}:
            result[key] = host.as_dict(value)
        elif key in {"native_direction", "direction", "part_ref", "image_state", "resource", "polar_frame", "parameters", "snapshot", "manifest_resource", "source_snapshot", "roi", "view_state", "style", "metrics", "metadata", "source_descriptor", "request", "source_rows_resource", "gap_resource", "fragment_descriptor", "geometry_metadata", "bridge_descriptor", "definition", "sketch_definition", "geometry_parameters", "sampling", "reference", "tail_reference", "member", "conversion", "quality", "provenance", "conversion_provenance", "source_request"}:
            result[key] = _receipt(host, value)
        elif key in {"start", "end"} and "bridge_kind" in result:
            result[key] = _receipt(host, value)
        elif key in {"first", "last"} and (result.get("method") == "uniform_parameter" or "fragment_token" in result):
            result[key] = float(value)
        elif key in {"width", "height"}:
            result[key] = int(float(value))
        elif key in {"part_id", "ordinal", "part_identity_counter", "knot_count", "index_start", "index_step", "knot", "parameter_count", "rank", "dof", "branch", "sample_budget", "count_a", "count_b", "revision", "topology_epoch", "epoch", "unit_power", "point_count", "point_index", "a_index", "b_index", "axis_index", "segment", "row_count", "display_budget", "start", "count", "first", "last", "size_bytes", "display_rows", "max_index", "max_source_index", "index", "control_count", "object_count", "columns", "positions", "total", "subdivisions", "major_interval", "radial_major_interval", "angular_major_interval", "order", "line_style", "marker", "interpolation", "layer", "traversal_contract", "curved_samples"}:
            result[key] = None if key == "part_id" and not value else int(value)
        elif key in {"effective_direction", "reversed", "original_dataset_modified", "source_modified", "repeat_endpoint", "materialization_verified", "calibrated", "explicit", "incoming", "connected", "periodic", "analysis_complete", "hit", "solved", "driven", "placed", "area_supported", "projection_exact_a", "projection_exact_b", "closest_exact", "normal_output", "geometry_modified", "parameter", "missing", "angular", "exact", "unit_declared", "disabled", "valid", "geometry_supported", "general_solver", "circular", "include_origin", "rotate_geometry", "finite_bounds", "copy", "found", "intersects_image", "physical_scale", "assumed_undeclared", "closed", "c0", "c1_start", "c1_end", "tangent_start", "tangent_end", "display_is_scientific_data", "visible", "locked", "selectable", "selected", "enabled", "snap_enabled", "major_visible", "minor_visible", "axes_visible", "clockwise", "degrees", "present", "forward", "base_selected"}:
            result[key] = bool(int(value))
        elif key == "origin" and "creation_kind" in host.as_list(value):
            result[key] = host.as_dict(value)
        elif key == "viewport":
            fields = host.as_list(value)
            result[key] = {name: float(fields[i]) for i, name in enumerate(("width", "height", "left", "top", "right", "bottom"))}
            result[key]["world"] = _array(host, fields[6])
        elif key in {"tail", "tip", "head_left", "head_right", "translation", "annotation", "label", "clipped_bounds", "hit_bounds", "closest_a", "closest_b", "point_a", "point_b", "anchor", "bounds", "point", "derivative", "origin", "start_derivative", "end_derivative", "major_color", "minor_color", "axes_color", "color", "pivot", "step_u", "step_v", "frame", "matrix", "affine_matrix"}:
            result[key] = _array(host, value)
        elif key == "lines":
            result[key] = [_matrix(host, item) for item in host.as_list(value)]
        elif key == "tangents":
            result[key] = [[int(host.as_list(item)[0]), _array(host, host.as_list(item)[1]), _array(host, host.as_list(item)[2])] for item in host.as_list(value)]
        elif key in {"points", "controls", "calibration"}:
            result[key] = _matrix(host, value)
        elif key in {"images", "inputs", "series_containers", "saved_views", "layers", "selection_sets", "members", "fragments", "constraints", "objects", "parts", "segments", "variables", "source_identities", "coordinate_conversions", "handles", "compatible_constraints", "constituents"}:
            result[key] = [_receipt(host, item) for item in host.as_list(value)]
        elif key in {"missing_refs", "source_tokens", "object_tokens", "operations", "host_operations"}:
            result[key] = host.as_list(value)
        elif key in {"row_indices", "source_rows", "nodes", "control_map"}:
            # Logical row identities stay exact integers, including uint64
            # values beyond IEEE double precision; never cast these to floats.
            result[key] = [int(item) for item in host.as_list(value)]
        elif key == "value" and ("constraint_token" in result or "unit_power" in result or "kind" in result):
            result[key] = float(value)
        elif key in {"maximum_knot_error", "scale", "calibrated_distance", "curvature_tolerance", "symmetric_rmse", "hausdorff_sampled", "length_difference", "area_difference", "closest_distance", "measured_value", "residual", "angular_residual", "angular_tolerance", "spacing_x", "spacing_y", "angle_step", "t", "radius_x", "radius_y", "rotation", "angle_start", "angle_sweep", "factor", "distance", "red", "green", "blue", "opacity", "line_width", "length", "span_x", "span_y", "signed_area", "area_pixels_squared", "length_span_ratio", "max_absolute", "mean_absolute", "rmse", "fraction", "offset_px", "length_px", "head_scale", "tolerance", "angle", "spacing_x", "spacing_y", "major_width", "minor_width", "axes_width", "theta_zero", "radius_min", "radius_max", "angle_min", "angle_span", "radial_spacing", "angular_spacing"}:
            result[key] = float(value)
        elif key == "rows" and series_parameters:
            result[key] = int(value)
        elif key == "rows":
            result[key] = []
            for item in host.as_list(value):
                row = host.as_list(item)
                result[key].append({"position": float(row[0]), "signed_residual": float(row[1]), "absolute_residual": float(row[2]),
                                    "reference": _array(host, row[3]), "derived": _array(host, row[4])})
    return result



def _request(value, key=None):
    # A 1x2 matrix is one XY control, not a scalar vector. The generic Tcl
    # transport intentionally flattens vectors, so this geometry boundary
    # preserves the explicit Nx2 contract even for one-point primitives.
    if isinstance(value, NumericArray) and key in {"controls", "points", "calibration", "polygon", "vertices", "route"}:
        if len(value.shape) == 2 and value.shape[1] == 2:
            rows = value.shape[0]
            return [[value.values[r + rows*c] for c in range(2)] for r in range(rows)]
        if value.shape == [2]:
            return [value.values]
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Geometry controls/points require an Nx2 matrix")
    if isinstance(value, dict) and key == "viewport":
        return [value[name] for name in ("width", "height", "left", "top", "right", "bottom")] + [value["world"]]
    if isinstance(value, dict):
        return {name: _request(item, name) for name, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_request(item) for item in value]
    return value



REGISTRATION['operations']['api_info'] = {
    'name': 'api_info', 'summary': 'Read the complete original owner discovery metadata',
    'host_command': '::GX::native2DGeometryApiInfo', 'arguments': [], 'argument_convention': 'no arguments',
    'result_contract': 'complete owner dictionary with explicit nested dictionaries, ordered text arrays, integer versions/limits and logical metadata flags; command names are inert data',
}


def _api_info_map(host, raw, lists=(), flags=(), integers=()):
    # Fixed owner-declared metadata shapes; command names remain inert text.
    result = {str(key): str(host.tcl.call('format', '%s', value)) for key, value in host.as_dict(raw).items()}
    for key in lists:
        result[key] = [str(value) for value in host.as_list(result[key])]
    for key in flags:
        result[key] = bool(host.tcl.getboolean(result[key]))
    for key in integers:
        result[key] = int(result[key])
    return result


def _api_info(host):
    result = _api_info_map(host, host.call('::GX::native2DGeometryApiInfo'),
                           ('operations', 'host_operations', 'diagram_commands', 'diagram_edit_modes', 'diagram_route_fields', 'diagram_junction_fields'),
                           ('raw_pointers', 'implicit_dataset_publication'), ('api_version', 'point_page_limit'))
    result['diagram_wire_target'] = _api_info_map(host, result['diagram_wire_target'], ('point',))
    result['raster_annotation_limits'] = _api_info_map(host, result['raster_annotation_limits'],
                                                     integers=('maximum_annotations', 'maximum_attribute_bytes', 'font_size_min', 'font_size_max'))
    result['diagram_electrical_notation'] = _api_info_map(host, result['diagram_electrical_notation'], flags=('editable_exact_roundtrip',))
    result['diagram_symbol_variants'] = _api_info_map(host, result['diagram_symbol_variants'])
    return result

def invoke(host, operation, args):
    if operation in _OWNED_ARGS:
        return _owned_invoke(host, operation, args)
    if operation in _PURE_REQUESTS:
        if (len(args) != 1 or not isinstance(args[0], dict) or
                set(args[0]) != _PURE_REQUESTS[operation]):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Pure geometry requires the exact declared request fields")
        raw = host.call("::GX::native2DGeometryPure", operation, _request(args[0]))
        if operation in {"distance", "angle_normalize"}:
            return float(raw)
        return _array(host, raw)
    if operation in _DIAGRAM_ARGS:
        return _diagram_invoke(host, operation, args)
    if operation == "path_validate" and len(args) == 2:
        rows = args[0]
        if isinstance(rows, NumericArray):
            import numpy as np
            rows = np.asarray(rows.values).reshape(rows.shape, order="F").tolist()
        result = host.as_dict(host.call("::GX::native2DGeometryPathValidate", rows, args[1]))
        return {"length": float(result["length"]), "signed_area": float(result["signed_area"]), "closed": bool(int(result["closed"]))}
    if operation not in _ARGS or len(args) != len(_ARGS[operation]):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Invalid Native2D geometry arguments")
    if operation in _VALUE_REQUESTS:
        request = _value_request(operation, args[0])
        return _receipt(host, host.call('::GX::native2DGeometryDefinitionQuery', operation, _request(request)))
    state = _state(host)
    if operation == "api_info":
        return _api_info(host)
    if operation == "open":
        scene = str(host.call("::GX::native2DGeometryOpen", args[0]))
        state["scenes"].add(scene)
        return scene
    scene = args[0]
    if not isinstance(scene, str) or scene not in state["scenes"]:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Scene token is not owned by this execution")
    if operation == "close":
        host.call("::GX::native2DGeometryClose", scene);state["scenes"].remove(scene);return True
    request = args[1]
    if not isinstance(request, dict):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Geometry request must be a struct")
    if operation in _RASTER_FIELDS:
        allowed, required = _RASTER_FIELDS[operation]
        if not set(request).issubset(allowed) or not required.issubset(request):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Raster request has missing or unknown fields')
        if 'object_token' in request and not isinstance(request['object_token'], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Raster object token must be a string')
        if operation == 'raster_dataset_bind' and (not isinstance(request['dataset_id'], str) or 'options' in request and not isinstance(request['options'], dict)):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Raster binding requires a canonical Dataset ID and optional options struct')
    # View/snapshot round trips include aspect. Preserve the default value but
    # reject indirect overrides too; only native/module hosts may choose auto.
    if operation == "view_state" and isinstance(request.get("view_state"), dict):
        if request["view_state"].get("aspect", "xy_equal") != "xy_equal":
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Native2D aspect overrides are host/module-only")
    if operation == "from_source" and request.get("source_token") not in host.handles.get("curve_source", {}).get("sources", set()):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Curve Source is not owned by this execution")
    if operation == "checkpoint":
        raw = host.call("::GX::native2DGeometryCheckpoint", scene, request)
        # The document service owns the payload; geometry resources remain
        # ordinary public reference dictionaries in that payload.
        result = host.as_dict(raw)
        return {"id": result["id"], "generation": result["generation"], "revision": int(result["revision"])}
    if operation == "primitive_publish":
        raw = host.call("::GX::_datasetPrivateWithModule", host.module_id, "::GX::native2DGeometryCall", scene, operation, _request(request))
    else:
        raw = host.call("::GX::native2DGeometryCall", scene, operation, _request(request))
    if operation in {"series_delete", "saved_view_delete", "layer_delete", "selection_set_delete", "fragment_delete", "constraint_delete", "delete", "ungroup", "group_add", "group_remove"}:
        return bool(int(raw))
    if operation == "view":
        # Existing native view contract is a six-number frame plus world bounds.
        value = host.as_list(raw)
        return {"frame": NumericArray([float(item) for item in value[:6]]), "world": _array(host, value[6])}
    if operation == "part_marker_geometry":
        return {"geometry": _receipt(host, host.as_dict(raw)["geometry"])}
    if operation.startswith('raster_annotation_'):
        return _raster_annotation_receipt(host, raw, operation == 'raster_annotation_project')
    if operation in {'raster_roi_geometry', 'raster_roi_pick', 'raster_roi_propose'}:
        return _raster_roi_receipt(host, raw)
    result = _receipt(host, raw)
    if operation == 'raster_dataset_bind':
        result['implicit_dataset_publication'] = bool(int(result['implicit_dataset_publication']))
        source = host.as_dict(host.as_dict(raw)['source'])
        result['source'] = {key: str(source[key]) for key in ('dataset_id', 'source_sha256')}
        for key in ('dataset_identity', 'variable_schema', 'origin'):
            result['source'][key] = host.normalize(host.as_dict(source[key]))
    return result


def cleanup(host):
    for canvas in list(_state(host).get('canvases', set())):
        _owned_invoke(host, 'canvas_dispose', [canvas])
    for scene in list(_state(host)["scenes"]):
        invoke(host, "close", [scene])


def _canvas_description(host, raw):
    result = host.as_dict(raw)
    for field in ('canvas_version', 'revision', 'history_cursor', 'history_steps'):
        result[field] = int(result[field])
    result['pending'] = bool(host.tcl.getboolean(result['pending']))
    result['extent'] = [int(v) for v in host.as_list(result['extent'])]
    result['background'] = _array(host, result['background'])
    result['selection'] = [str(v) for v in host.as_list(result['selection'])]
    result['objects'] = [host.as_dict(v) for v in host.as_list(result['objects'])]
    layers = []
    for raw_layer in host.as_list(result['layers']):
        layer = host.as_dict(raw_layer);properties = host.as_dict(layer['properties'])
        for field in ('visible', 'selectable', 'locked'): properties[field] = bool(host.tcl.getboolean(properties[field]))
        properties['order'] = int(properties['order']);properties['opacity'] = float(properties['opacity'])
        layer['properties'] = properties;layers.append(layer)
    result['layers'] = layers
    return result


def _frame_value(host, raw):
    result = host.as_dict(raw)
    for key in ('origin', 'normal', 'u_axis', 'v_axis'):
        if key in result: result[key] = _array(host, result[key])
    for key in ('orthonormal', 'right_handed'):
        if key in result: result[key] = bool(host.tcl.getboolean(result[key]))
    return result


def _quick_descriptor(host, raw):
    result = host.as_dict(raw)
    result['source'] = host.modules['INTERACTIVE_DOCUMENT_API_v1']._document_metadata(host, result['source'])
    if 'unavailable' in result:
        result['unavailable'] = bool(host.tcl.getboolean(result['unavailable']));return result
    for key in ('object_count', 'relationship_count', 'points', 'asset_bytes'): result[key] = int(result[key])
    for key in ('exact_edit_source', 'editing_overlay_required'): result[key] = bool(host.tcl.getboolean(result[key]))
    result['pixels_per_unit'] = float(result['pixels_per_unit'])
    result['local_bounds'] = _array(host, result['local_bounds'])
    for key in ('plane', 'normalized_frame'): result[key] = _frame_value(host, result[key])
    return result


def _quick_presentation(host, raw):
    result = host.as_dict(raw);result.pop('session_token', None);result['revision'] = int(result['revision'])
    if 'descriptor' in result: result['descriptor'] = _quick_descriptor(host, result['descriptor'])
    layers = {}
    for name, value in host.as_dict(result['layers']).items():
        layer = host.as_dict(value)
        points = [[float(v) for v in host.as_list(point)] for point in host.as_list(layer['vertices'])]
        layer['vertices'] = NumericArray([point[c] for c in range(3) for point in points], [len(points), 3])
        layer['polylines'] = [[int(v) for v in host.as_list(row)] for row in host.as_list(layer['polylines'])]
        layer['triangles'] = [[int(v) for v in host.as_list(row)] for row in host.as_list(layer['triangles'])]
        layer['points'] = [int(v) for v in host.as_list(layer['points'])]
        for key in ('visible', 'backface_culling', 'scalar_coloring'): layer[key] = bool(host.tcl.getboolean(layer[key]))
        for key in ('opacity', 'line_width', 'point_size'): layer[key] = float(layer[key])
        layer['layer_order'] = int(layer['layer_order']);layers[name] = layer
    result['layers'] = layers
    return result


def _owned_invoke(host, operation, args):
    fields, minimum = _OWNED_ARGS[operation]
    if not minimum <= len(args) <= len(fields):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid Native2D owner arguments')
    if operation in {'cad_sketch_is_managed', 'cad_action_states', 'cad_action_state'}:
        name = args[0] if args else ''
        if not isinstance(name, str) or len(name) > 512 or '\0' in name:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Sketch identity must be bounded text')
        managed = bool(host.tcl.getboolean(host.call('::GX::nativeCadSketchIsManaged', name)))
        if operation == 'cad_sketch_is_managed': return managed
        # Unknown names are not Tcl command capabilities. Use the owner's inert
        # disabled-state branch; only its actual managed class can be queried.
        receiver = name if managed else ''
        if operation == 'cad_action_state':
            if not isinstance(args[1], str):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'CAD action requires its fixed ID')
            raw = host.call('::GX::native2DCadActionState', receiver, args[1])
            states = {'single': raw}
        else: states = host.as_dict(host.call('::GX::native2DCadActionStates', receiver))
        result = {}
        for action, raw in states.items():
            item = host.as_dict(raw)
            for key in ('enabled', 'checked'): item[key] = bool(host.tcl.getboolean(item[key]))
            result[action] = item
        return result['single'] if operation == 'cad_action_state' else result
    if operation.startswith('sketch_quick_open_'):
        if operation == 'sketch_quick_open_status':
            raw = host.as_dict(host.call('::GX::nativeCadSketchQuickOpenStatus'))
            result = {key: int(raw[key]) for key in ('hits', 'misses', 'publications', 'disk_budget_bytes', 'asset_limit')}
            result['error_present'] = bool(str(raw['last_error']))
            result['payload_cache'] = host.modules['INTERACTIVE_DOCUMENT_API_v1']._document_cache(host, 'cache_status', '::GX::interactiveDocumentCacheStatus', [])
            return result
        if operation == 'sketch_quick_open_list':
            if not isinstance(args[0], (list, tuple)) or len(args[0]) > 4096 or any(not isinstance(x, str) for x in args[0]):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Quick-open requires at most4096 Document IDs')
            raw = host.call('::GX::nativeCadSketchQuickOpenList', *args)
            return {key: _quick_descriptor(host, value) for key, value in host.as_dict(raw).items()}
        if not isinstance(args[0], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Quick-open requires a canonical Document ID')
        unit = args[1] if len(args) > 1 else ''
        if operation == 'sketch_quick_open_publish':
            return _quick_descriptor(host, host.call('::GX::nativeCadSketchQuickOpenPublish', args[0], {}, unit))
        return _quick_presentation(host, host.call('::GX::nativeCadSketchQuickOpenPresentation', args[0], unit))
    canvases = _state(host).setdefault('canvases', set())
    if operation == 'canvas_create':
        options = args[1] if len(args) > 1 else {}
        if not isinstance(args[0], str) or not isinstance(options, dict):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Canvas requires provider identity and options struct')
        token = str(host.call('::GX::native2DCanvasCreate', host.module_id, args[0], options));canvases.add(token);return token
    if not isinstance(args[0], str) or args[0] not in canvases:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Canvas is not owned by this execution')
    token = args[0]
    if operation == 'canvas_dispose':
        result = bool(host.tcl.getboolean(host.call('::GX::native2DCanvasDispose', token)));canvases.remove(token);return result
    if operation == 'canvas_describe': return _canvas_description(host, host.call('::GX::native2DCanvasDescribe', token))
    workspace = host.modules['NATIVE_WORKSPACE_API_v1']
    if operation == 'canvas_capture':
        raw = host.call('::GX::native2DCanvasCapture', token)
        return workspace.from_tcl(host, host.call('::GX::nativeWorkspaceEncode', ['named', 'canvas_snapshot'], raw))
    if operation == 'canvas_restore':
        typed = workspace.to_tcl(args[1]);snapshot = host.call('::GX::nativeWorkspaceDecode', typed)
        return host.as_dict(host.call('::GX::native2DCanvasRestore', token, snapshot))
    if not isinstance(args[1], str) or len(args) > 2 and not isinstance(args[2], dict):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Canvas command requires finite operation and request struct')
    raw = host.call('::GX::native2DCanvasCommand', token, args[1], _request(args[2]) if len(args) > 2 else {})
    if args[1] == 'dispose': canvases.remove(token);return bool(host.tcl.getboolean(raw))
    result = host.as_dict(raw)
    if result.get('api_id') == 'NATIVE2D_API_v1': return _canvas_description(host, raw)
    result = {str(key): str(value) for key, value in result.items()}
    for key in ('objects', 'revision'):
        if key in result: result[key] = int(result[key])
    return result


def _annotation(host, raw):
    fields = host.as_dict(raw)
    result = {str(key): str(value) for key, value in fields.items() if key not in {'point', 'font_size'}}
    result['point'] = _array(host, fields['point'])
    if 'font_size' in fields:
        result['font_size'] = float(fields['font_size'])
    return result


def _raster_annotation_receipt(host, raw, projected):
    source = host.as_dict(raw)
    result = {key: str(source[key]) for key in ('source_resource_id',)}
    result['revision'] = int(source['revision'])
    if projected:
        result['annotations'] = [_annotation(host, value) for value in host.as_list(source['annotations'])]
    else:
        result['format'] = str(source['format'])
        result['annotations'] = {str(key): _annotation(host, value) for key, value in host.as_dict(source['annotations']).items()}
        result['generations'] = {str(key): int(value) for key, value in host.as_dict(source['generations']).items()}
    return result


def _raster_roi_receipt(host, raw):
    source = host.as_dict(raw)
    result = {}
    for key, value in source.items():
        if key in {'canonical_points', 'device_points', 'handles'}:
            result[key] = _matrix(host, value)
        elif key == 'definition':
            definition = host.as_dict(value)
            result[key] = {str(k): str(v) for k, v in definition.items() if k != 'points'}
            result[key]['points'] = _matrix(host, definition['points'])
        elif key in {'valid', 'hit', 'image_hit'}:
            result[key] = bool(int(value))
        elif key in {'collection_revision', 'index'}:
            result[key] = int(value)
        elif key == 'distance':
            result[key] = float(value)
        elif key == 'device':
            result[key] = _array(host, value)
        else:
            result[str(key)] = str(value)
    return result


def _diagram_catalog_value(host, raw):
    source = host.as_dict(raw)
    result = {str(k): str(v) for k, v in source.items() if k != 'symbols'}
    symbols = {}
    for kind, raw_symbol in host.as_dict(source['symbols']).items():
        symbol = host.as_dict(raw_symbol)
        value = {str(k): str(v) for k, v in symbol.items() if k not in {'paths', 'pins', 'attributes', 'variants'}}
        value['paths'] = [_matrix(host, path) for path in host.as_list(symbol['paths'])]
        value['pins'] = {str(k): _array(host, point) for k, point in host.as_dict(symbol['pins']).items()}
        value['attributes'] = {}
        for name, raw_field in host.as_dict(symbol['attributes']).items():
            field = host.as_dict(raw_field)
            converted = {str(k): str(v) for k, v in field.items()}
            if str(field['type']) == 'number':
                for key in ('default', 'min', 'max'):
                    if key in field:
                        converted[key] = float(field[key])
            if 'values' in field:
                converted['values'] = [str(item) for item in host.as_list(field['values'])]
            value['attributes'][str(name)] = converted
        if 'variants' in symbol:
            variants = host.as_dict(symbol['variants'])
            value['variants'] = {'attribute': str(variants['attribute']),
                                 'marks': {str(k): [_matrix(host, path) for path in host.as_list(paths)]
                                           for k, paths in host.as_dict(variants['marks']).items()}}
        symbols[str(kind)] = value
    result['symbols'] = symbols
    return result


def _diagram_payload(host, raw):
    source = host.as_dict(raw)
    catalog = _diagram_catalog_value(host, host.call('::GX::native2DGeometryDiagramCatalog', source['catalog']))
    result = {'schema': str(source['schema']), 'catalog': str(source['catalog']), 'next_id': int(source['next_id']),
              'components': {}, 'junctions': {}, 'wires': {}, 'labels': {}}
    for name, raw_item in host.as_dict(source['components']).items():
        item = host.as_dict(raw_item)
        attributes = {}
        for key, value in host.as_dict(item['attributes']).items():
            field = catalog['symbols'][str(item['kind'])]['attributes'][str(key)]
            attributes[str(key)] = float(value) if field['type'] == 'number' else str(value)
        result['components'][str(name)] = {'kind': str(item['kind']), 'name': str(item['name']),
            'position': _array(host, item['position']), 'rotation': int(item['rotation']), 'attributes': attributes}
    result['junctions'] = {str(k): _array(host, v) for k, v in host.as_dict(source['junctions']).items()}
    for name, raw_wire in host.as_dict(source['wires']).items():
        wire = host.as_dict(raw_wire)
        result['wires'][str(name)] = {'start': [str(v) for v in host.as_list(wire['start'])],
            'end': [str(v) for v in host.as_list(wire['end'])], 'route': _matrix(host, wire['route'])}
    for name, raw_label in host.as_dict(source['labels']).items():
        label = host.as_dict(raw_label)
        value = {'text': str(label['text']), 'endpoint': [str(v) for v in host.as_list(label['endpoint'])]}
        if 'offset' in label:
            value['offset'] = _array(host, label['offset'])
        result['labels'][str(name)] = value
    return result


def _diagram_document(host, raw):
    source = host.as_dict(raw)
    result = {str(key): host.normalize(value) for key, value in source.items() if key != 'payload'}
    for key in ('revision', 'format_version'):
        if key in source:
            result[key] = int(source[key])
    if 'payload' in source:
        result['payload'] = _diagram_payload(host, source['payload'])
    return result


def _diagram_invoke(host, operation, args):
    fields, minimum = _DIAGRAM_ARGS[operation]
    if not minimum <= len(args) <= len(fields):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid diagram argument count')
    if operation == 'diagram_catalog':
        if args and not isinstance(args[0], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Catalog ID must be a string')
        raw = host.call('::GX::native2DGeometryDiagramCatalog', *args)
        return _diagram_catalog_value(host, raw) if args else {str(k): _diagram_catalog_value(host, v) for k, v in host.as_dict(raw).items()}
    if operation == 'diagram_create':
        if not host.module_id or not all(isinstance(value, str) for value in args):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Creation requires current module context, provider ID and registered catalog ID')
        return _diagram_document(host, host.call('::GX::native2DGeometryDiagramCreate', host.module_id, *args))
    if operation == 'diagram_read':
        if not isinstance(args[0], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Document ID must be a string')
        return _diagram_document(host, host.call('::GX::native2DGeometryDiagramRead', args[0]))
    if operation in {'diagram_validate', 'diagram_endpoint'}:
        if not isinstance(args[0], dict):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Diagram payload must be a struct')
        validated = host.call('::GX::native2DGeometryDiagramValidate', _request(args[0]))
        if operation == 'diagram_validate':
            return _diagram_payload(host, validated)
        return _array(host, host.call('::GX::native2DGeometryDiagramEndpoint', validated, args[1]))
    if operation == 'diagram_edit':
        if not isinstance(args[0], str) or not isinstance(args[1], dict) or not isinstance(args[2], str) or not isinstance(args[3], dict) or len(args) == 5 and not isinstance(args[4], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Diagram edit requires Document, expected source, operation, request and optional mode')
        raw = host.as_dict(host.call('::GX::native2DGeometryDiagramEdit', *[_request(value) for value in args]))
        result = {str(k): str(v) for k, v in raw.items() if k not in {'document', 'payload', 'proposed_payload', 'source'}}
        for key in ('document', 'source'):
            if key in raw:
                result[key] = _diagram_document(host, raw[key])
        for key in ('payload', 'proposed_payload'):
            if key in raw:
                result[key] = _diagram_payload(host, raw[key])
        return result
    if not isinstance(args[0], str) or len(args) == 2 and not isinstance(args[1], dict):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Projection requires a Document ID and optional validated preview')
    raw = host.as_dict(host.call('::GX::native2DGeometryDiagramProject', *[_request(value) for value in args]))
    token = str(raw['scene_token'])
    try:
        result = {'scene_token': token, 'document': _diagram_document(host, raw['document']),
                  'object_tokens': {str(k): [str(v) for v in host.as_list(values)] for k, values in host.as_dict(raw['object_tokens']).items()},
                  'annotations': [_annotation(host, v) for v in host.as_list(raw['annotations'])]}
    except Exception:
        host.call('::GX::native2DGeometryClose', token)
        raise
    _state(host)['scenes'].add(token)
    return result
