"""Bounded bytes and opaque handles from the existing Document Resource owner.

Script handles remain in this Bridge execution and are drained on normal stop.
Native scene handles, trusted file imports and host-wide collection are not
accepted; operation-specific technical reasons live in the owning Tcl source.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
from gxtxt_script_bridge_server import BridgeError, NumericArray

_COMMANDS = {
 'open_writer': ('interactiveDocumentResourceOpenWriter', ['document_id','metadata']),
 'append': ('interactiveDocumentResourceAppend', ['writer','bytes']),
 'finalize': ('interactiveDocumentResourceFinalize', ['writer','repair_disposable']),
 'abort': ('interactiveDocumentResourceAbort', ['writer']),
 'info': ('interactiveDocumentResourceInfo', ['reference']),
 'read_chunk': ('interactiveDocumentResourceReadChunk', ['reference','start','count']),
 'read_ranges': ('interactiveDocumentResourceReadRanges', ['reference','ranges']),
 'open_reader': ('interactiveDocumentResourceOpenReader', ['reference']),
 'reader_info': ('interactiveDocumentResourceReaderInfo', ['reader']),
 'next': ('interactiveDocumentResourceNext', ['reader','count']),
 'close_reader': ('interactiveDocumentResourceCloseReader', ['reader']),
 'api_info': ('interactiveDocumentResourceApiInfo', []),
}
REGISTRATION = {
 'api_id':'INTERACTIVE_DOCUMENT_RESOURCE_API_v1','api_version':1,
 'provider_kind':'core','provider_id':'interactive_document_resources',
 'documentation_ref':'docs/api/INTERACTIVE_DOCUMENT_RESOURCE_API_v1.md',
 'operations':{name:{'name':name,'summary':'Existing CORE Resource/Workspace dependency '+name,
  'arguments':[{'name':'payload_utf8','kind':'inert UTF-8 value or explicit receipt struct' if name=='references' else 'inert UTF-8 value','required':True},{'name':arg,'kind':kind,'required':True}],
  'argument_convention':'payload_utf8, '+arg,'result_contract':result,'unit_behavior':'No numerical value or unit changes'}
  for name,arg,kind,result in [('references','document_id','optional owner string','serialized verified complete resource receipt list'),
                             ('remap_references','references_utf8','serialized current receipt list','Exact marker/escape-free identity text after receipt validation; full raw opaque remap is unavailable/deprecated')]}}
REGISTRATION['operations'].update({name:{
 'name':name,'summary':'Existing bounded Document Resource operation '+name,
 'host_command':'::GX::'+command,
 'arguments':[{'name':arg,'kind':'uint8 vector' if arg=='bytes' else 'explicit public value',
               'required':not (name=='finalize' and arg=='repair_disposable' or name=='next' and arg=='count')}
              for arg in fields],
 'argument_convention':', '.join(fields) or 'no arguments',
 'result_contract':'Owner receipt, execution-local handle, or bounded uint8 byte vector',
 'unit_behavior':'Exact bytes; no numeric/scientific reinterpretation',
} for name,(command,fields) in _COMMANDS.items()})
REGISTRATION['operations']['references']['summary']='Verified original receipts through the existing bounded Document Resource scanner'
REGISTRATION['operations']['remap_references'].update(
 availability='UNAVAILABLE_DEPRECATED_OWNER_CONTRACT', deprecated=True,
 availability_scope='full_raw_opaque_tcl_workspace_resource_remap',
 full_raw_available=False, supported_profile='marker_escape_free_text_identity',
 native_alternative='NATIVE_WORKSPACE_API_v1/resource_copy_tree', raw_equivalence=False,
 summary='Validate supplied current receipts and retain exact marker/escape-free inert text; retired opaque Workspace values refuse',
 result_contract='Exact marker/escape-free UTF-8 value; resource-bearing legacy Workspace remap is unsupported. Explicit native graphs use NATIVE_WORKSPACE_API_v1/resource_copy_tree.')


def _invalid(message):
 raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)


def _handles(host):
 if not hasattr(host,'_document_resource_script_handles'):
  host._document_resource_script_handles={'writers':set(),'readers':set()}
 return host._document_resource_script_handles


def _receipt(host,raw):
 result=host.as_dict(raw)
 result['size_bytes']=int(result['size_bytes'])
 result['metadata']=host.as_dict(result['metadata'])
 return host.normalize(result)


def _byte_result(raw):
 if raw=='':raw=b''
 if not isinstance(raw,bytes):
  raise BridgeError('GXTXT:ScriptBridge:Transport','Document Resource lost its binary byte type')
 import numpy as np
 return NumericArray(np.frombuffer(raw,dtype=np.uint8).copy(),[len(raw),1])


def invoke(host,operation,args):
 if operation in ('references','remap_references'):
  if (len(args)!=2 or not isinstance(args[1],str) or
      not isinstance(args[0],(str,dict) if operation=='references' else str)):
   _invalid('Resource dependencies require inert text/receipt and owner or reference-list text')
  command='::GX::interactiveDocumentResourceReferences' if operation=='references' else '::GX::interactiveDocumentResourceRemapReferences'
  value=host.call(command,*args)
  return value.decode('utf-8') if isinstance(value,bytes) else str(host.tcl.call('format','%s%s',value,''))
 if operation not in _COMMANDS:
  _invalid('Unknown bounded Document Resource operation')
 command,fields=_COMMANDS[operation]
 minimum=len(fields)-(1 if operation in ('finalize','next') else 0)
 if not minimum<=len(args)<=len(fields):
  _invalid('Invalid bounded Document Resource arguments')
 handles=_handles(host)
 if operation in ('append','finalize','abort','reader_info','next','close_reader'):
  group='writers' if operation in ('append','finalize','abort') else 'readers'
  if not isinstance(args[0],str) or args[0] not in handles[group]:
   raise BridgeError('GXTXT:ScriptBridge:Ownership','Document Resource handle belongs to another or closed Bridge execution')
 if operation=='open_writer' and (not isinstance(args[0],str) or not isinstance(args[1],dict)):
  _invalid('A writer requires an existing document identity and metadata struct')
 if operation=='append':
  value=args[1]
  if (not isinstance(value,NumericArray) or value.dtype!='uint8' or len(value.shape)>2 or
      len(value.shape)==2 and min(value.shape)>1 or math.prod(value.shape)>1048576):
   _invalid('Append requires a bounded uint8 vector of at most 1 MiB')
  # Fixed public owner command, with a Tcl bytearray rather than str(bytes).
  return int(host.tcl.call('::GX::'+command,args[0],value.values.tobytes()))
 raw=host.call('::GX::'+command,*args)
 if operation in ('open_writer','open_reader'):
  token=str(raw);handles['writers' if operation=='open_writer' else 'readers'].add(token)
  return token
 if operation in ('finalize','abort','close_reader'):
  handles['readers' if operation=='close_reader' else 'writers'].discard(args[0])
  return _receipt(host,raw) if operation=='finalize' else None
 if operation=='info':return _receipt(host,raw)
 if operation=='read_chunk':return _byte_result(raw)
 if operation=='read_ranges':return [_byte_result(value) for value in host.as_list(raw)]
 if operation in ('reader_info','next'):
  result=host.as_dict(raw)
  result['offset']=int(result['offset'])
  if operation=='reader_info':result['reference']=_receipt(host,result['reference'])
  else:
   result['bytes']=_byte_result(result['bytes']);result['count']=int(result['count']);result['eof']=bool(int(result['eof']))
  return result
 result=host.as_dict(raw)
 result['api_version']=int(result['api_version']);result['chunk_bytes_max']=int(result['chunk_bytes_max'])
 result['implicit_dataset_publication']=bool(int(result['implicit_dataset_publication']))
 result['operations']=[str(value) for value in host.as_list(result['operations'])]
 if 'script_host_only' in result:result['script_host_only']={str(k):str(v) for k,v in host.as_dict(result['script_host_only']).items()}
 if 'operation_availability' in result:
  availability={}
  for name,value in host.as_dict(result['operation_availability']).items():
   row={str(k):str(v) for k,v in host.as_dict(value).items()}
   for key in ('deprecated','full_raw_available','raw_equivalence'):row[key]=bool(host.tcl.getboolean(row[key]))
   availability[str(name)]=row
  result['operation_availability']=availability
 return result


def cleanup(host):
 """Release only handles opened by this existing provider during this run."""
 for group,command in (('writers','interactiveDocumentResourceAbort'),('readers','interactiveDocumentResourceCloseReader')):
  for token in list(_handles(host)[group]):
   try:host.call('::GX::'+command,token)
   finally:_handles(host)[group].discard(token)
