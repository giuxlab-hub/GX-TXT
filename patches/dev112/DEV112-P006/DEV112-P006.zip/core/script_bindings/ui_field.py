"""Headless declarative UI value validation and canonical color accessors."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
REGISTRATION = {
    'api_id': 'UI_FIELD_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'ui_field',
    'documentation_ref': 'docs/api/UI_FIELD_API_v1.md',
    'operations': {
        name: {'name': name, 'summary': summary,
               'arguments': [{'name': arg, 'kind': kind, 'required': True} for arg,kind in arguments],
               'argument_convention': ', '.join(arg for arg,kind in arguments),
               'result_convention': result, 'result_contract': result}
        for name,summary,arguments,result in (
            ('api_info','Read supported declarative field types',[], 'field API descriptor'),
            ('normalize','Validate one declarative value',[('descriptor','struct'),('value','public value')], 'canonical value'),
            ('color_components','Read canonical RGB and presentation opacity',[('color','canonical color')], 'rgb/alpha struct'),
            ('component_capabilities','Read inert component property and event schemas',[], 'component capability dictionary'),
            ('component_descriptor','Construct a typed field descriptor without creating widgets',[('type','string'),('properties','struct')], 'inert field descriptor'),
            ('dataset_choices','Read canonical Dataset choice IDs',[('content_kind','string'),('allow_empty','boolean')], 'ordered Dataset IDs'))
    }
}
for _argument in REGISTRATION['operations']['dataset_choices']['arguments']:
    _argument['required'] = False
for _name, _command in {'component_capabilities':'uiFieldComponentCapabilities',
                        'component_descriptor':'uiFieldComponentDescriptor',
                        'dataset_choices':'uiFieldDatasetChoices'}.items():
    REGISTRATION['operations'][_name]['host_command'] = '::GX::'+_command

def invoke(host, operation, args):
    if operation == 'component_capabilities' and not args:
        result = {}
        for name, raw in host.as_dict(host.call('::GX::uiFieldComponentCapabilities')).items():
            row = host.as_dict(raw)
            row['api_version'] = int(row['api_version'])
            row['properties'] = host.as_dict(row['properties'])
            row['events'] = [str(value) for value in host.as_list(row['events'])]
            result[str(name)] = row
        return result
    if operation == 'component_descriptor' and len(args)==2 and isinstance(args[0],str) and isinstance(args[1],dict):
        result = host.as_dict(host.call('::GX::uiFieldComponentDescriptor', *args))
        result['compact'] = bool(host.tcl.getboolean(result['compact']))
        # Preserve supplied inert property values without reinterpreting text as
        # Tcl dictionaries or numerical data. The existing owner chooses defaults.
        for key in ('default','min','max','alpha','max_utf8_bytes'):
            if key in args[1] and key in result:
                result[key] = args[1][key]
        if 'default' not in args[1]:
            result['default'] = False if result['type']=='boolean' else ''
        if 'values' in result:
            result['values'] = [str(value) for value in host.as_list(result['values'])]
        return result
    if operation == 'dataset_choices' and len(args)<=2:
        if args and not isinstance(args[0],str) or len(args)==2 and not isinstance(args[1],bool):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Dataset choices require content kind and optional boolean')
        return [str(value) for value in host.as_list(host.call('::GX::uiFieldDatasetChoices', *args))]
    if operation == 'api_info' and not args:
        info=host.as_dict(host.call('::GX::uiFieldApiInfo'))
        info['types']=host.as_list(info['types']);info['api_version']=int(info['api_version'])
        return info
    if operation == 'normalize' and len(args)==2 and isinstance(args[0],dict):
        result=host.call('::GX::uiFieldNormalize',*args)
        kind=args[0].get('type','string')
        if str(result)=='': return ''
        if kind=='integer': return int(result)
        if kind in ('double','number'): return float(result)
        if kind=='boolean': return bool(int(result))
        if kind=='color' and args[0].get('alpha'):
            color=host.as_dict(result);color['alpha']=float(color['alpha']);return color
        return str(result)
    if operation == 'color_components' and len(args)==1:
        color=host.as_dict(host.call('::GX::uiFieldColorComponents',args[0]))
        color['alpha']=float(color['alpha']);return color
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Invalid UI_FIELD_API_v1 arguments')
