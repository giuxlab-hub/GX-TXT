"""Shared UML source owner with canonical CAS and bounded owned export bytes."""
# SPDX-License-Identifier: GPL-3.0-or-later
import hashlib
from pathlib import Path
import uuid
from gxtxt_script_bridge_server import BridgeError, NumericArray

_COMMANDS={
    'api_info':('umlDocumentApiInfo',[]),
    'detect':('umlDocumentDetect',[('filename','inert filename hint',True),('source','UTF-8 source',True)]),
    'parse':('umlDocumentParse',[('source','UTF-8 source',True),('options','profile/family struct',False)]),
    'edit':('umlDocumentEdit',[('source','UTF-8 source',True),('expected_sha256','source SHA',True),('operation','finite semantic edit ID',True),('request','owner-defined semantic fields',True)]),
    'layout':('umlDocumentLayout',[('receipt','source and source_sha256',True),('options','bounded font_size struct',False)]),
    'inspect_element':('umlDocumentInspectElement',[('receipt','source and source_sha256',True),('id','stable semantic ID',True)]),
    'describe':('umlDocumentDescribe',[('dataset_id','canonical UML Dataset ID',True),('options','expected_session struct',False)]),
    'read':('umlDocumentRead',[('dataset_id','canonical UML Dataset ID',True),('options','expected_session struct',False)]),
    'write':('umlDocumentWrite',[('request','canonical source write with Session/revision/SHA guards',True)]),
    'export':('umlDocumentExport',[('source','UTF-8 source',True),('format','source/png/svg',True),('options','bounded width/height/font_size struct',False)]),
}
REGISTRATION={
    'api_id':'UML_DOCUMENT_API_v1','api_version':1,'provider_kind':'core','provider_id':'uml_document',
    'documentation_ref':'docs/api/UML_DOCUMENT_API_v1.md',
    'operations':{name:{'name':name,'summary':'Existing UML source/Document owner: '+name,
                       'host_command':'::GX::'+command,
                       'arguments':[{'name':field,'kind':kind,'required':required}for field,kind,required in fields],
                       'argument_convention':', '.join(field for field,_,_ in fields)or'no arguments',
                       'result_contract':'Typed source-bound UML receipt; canonical revisions are execution-owned opaque values. Export returns exact bounded uint8 bytes and releases its actual owner allocation in finally; no path, lease, capability or caller-derived model authority.'}
                  for name,(command,fields)in _COMMANDS.items()},
}


def _invalid(message):raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)
def _text(host,value):return str(host.tcl.call('format','%s',value))
def _list(host,value):return [_text(host,v)for v in host.as_list(value)]
def _ints(host,value):return [int(v)for v in host.as_list(value)]
def _number(host,value):return NumericArray([float(v)for v in host.as_list(value)])


def _item(host,raw):
    result={}
    for key,value in host.as_dict(raw).items():
        if key in('line','column','order','start','end','depth'):
            result[key]=int(value)if _text(host,value)else''
        elif key in('x','y'):result[key]=float(value)
        elif key in('span','annotated_span','declaration_span','close_span'):result[key]=_ints(host,value)
        elif key in('members','branches'):result[key]=[_item(host,v)for v in host.as_list(value)]
        elif key=='frames':result[key]=_list(host,value)
        elif key=='frame_context':result[key]=[[_text(host,host.as_list(v)[0]),int(host.as_list(v)[1])]for v in host.as_list(value)]
        else:result[key]=_text(host,value)
    return result


def _parsed(host,raw):
    result={}
    for key,value in host.as_dict(raw).items():
        if key in('parser_version','source_bytes'):result[key]=int(value)
        elif key=='valid':result[key]=bool(host.tcl.getboolean(value))
        elif key in('elements','frames','positions'):result[key]={name:_item(host,v)for name,v in host.as_dict(value).items()}
        elif key in('relations','messages','diagnostics'):result[key]=[_item(host,v)for v in host.as_list(value)]
        elif key=='end_span':result[key]=_ints(host,value)
        else:result[key]=_text(host,value)
    return result


def _receipt(value):
    if not isinstance(value,dict)or not all(isinstance(value.get(k),str)for k in('source','source_sha256')):
        _invalid('UML receipt requires exact source and source_sha256 strings')
    # The source owner reparses these fields; derived spans/nodes/plans from a
    # caller never become semantic or rendering authority.
    return {key:value[key]for key in('source','source_sha256')}


def _layout(host,raw):
    result={}
    for key,value in host.as_dict(raw).items():
        if key in('parser_version','text_engine_version'):result[key]=int(value)
        elif key=='font_size':result[key]=float(value)
        elif key=='bounds':result[key]=_number(host,value)
        elif key=='primitives':
            primitives=[]
            for item in host.as_list(value):
                primitive={}
                for field,v in host.as_dict(item).items():
                    if field in('coords','dash'):primitive[field]=_number(host,v)
                    elif field in('width','font_size'):primitive[field]=float(v)
                    elif field=='text_engine_version':primitive[field]=int(v)
                    else:primitive[field]=_text(host,v)
                primitives.append(primitive)
            result[key]=primitives
        elif key=='hit_map':
            result[key]={name:{field:_number(host,v)if field in('bounds','path')else _text(host,v)for field,v in host.as_dict(item).items()}for name,item in host.as_dict(value).items()}
        else:result[key]=_text(host,value)
    return result


def _state(host):
    session=_text(host,host.call('::GX::interactiveDocumentSessionToken'))
    state=host.handles.setdefault('uml_document',{'session':session,'revisions':{}})
    if state['session']!=session:
        state={'session':session,'revisions':{}};host.handles['uml_document']=state
    return state


def _revision(host,value):
    revisions=_state(host)['revisions']
    for token,actual in revisions.items():
        if actual==value:return token
    if len(revisions)>=128:revisions.pop(next(iter(revisions)))
    token='uml-revision-'+uuid.uuid4().hex;revisions[token]=value
    return token


def _description(host,raw):
    result={}
    for key,value in host.as_dict(raw).items():
        if key=='revision':result[key]=_revision(host,value)
        elif key in('can_replace','can_create','immutable'):result[key]=bool(host.tcl.getboolean(value))
        elif key in('metadata','association'):result[key]={k:_text(host,v)for k,v in host.as_dict(value).items()}
        elif key=='assets':
            result[key]={name:host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._receipt(host,v)for name,v in host.as_dict(value).items()}
        else:result[key]=_text(host,value)
    return result


def _export(host,command,args):
    raw=None
    try:
        raw=host.call(command,*args);receipt=host.as_dict(raw);allocation=host.as_dict(receipt['allocation'])
        path=Path(_text(host,receipt['path']));root=Path(_text(host,allocation['path']))
        if path.is_symlink()or not path.is_file()or not path.resolve().is_relative_to(root.resolve()):
            raise BridgeError('GXTXT:ScriptBridge:Ownership','UML owner export is outside its actual managed allocation')
        with path.open('rb')as stream:data=stream.read(16777217)
        if len(data)>16777216 or hashlib.sha256(data).hexdigest()!=_text(host,receipt['sha256']):
            raise BridgeError('GXTXT:ScriptBridge:Ownership','UML owner export byte identity changed')
        result={key:_text(host,receipt[key])for key in('schema','format','sha256','source_sha256','layout_sha256','renderer')}
        result['source_valid']=bool(host.tcl.getboolean(receipt['source_valid']))
        result['bytes']=host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(data)
        return result
    finally:
        if raw is not None:host.call('::GX::umlDocumentExportRelease',raw)


def invoke(host,operation,args):
    if operation not in _COMMANDS:raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
    command,fields=_COMMANDS[operation]
    if not sum(required for _,_,required in fields)<=len(args)<=len(fields):_invalid('Invalid UML argument count')
    command='::GX::'+command
    if operation=='api_info':
        result=host.as_dict(host.call(command))
        for key in('api_version','source_bytes_max','class_elements_max','class_relations_max','participants_max','messages_max','frame_depth_max','export_pixels_max'):result[key]=int(result[key])
        for key in('families','deferred_families','operations','commands','host_operations','export_formats','unsupported'):result[key]=_list(host,result[key])
        return result
    if operation in('detect','parse','edit','export'):
        text_count=2 if operation=='detect'else 3 if operation=='edit'else 2 if operation=='export'else 1
        if any(not isinstance(v,str)for v in args[:text_count]):_invalid('UML source, hints and operation choices must be strings')
        if len(args)>text_count and not isinstance(args[text_count],dict):_invalid('UML options/request must be a struct')
    if operation=='detect':
        result=host.as_dict(host.call(command,*args))
        for key in('candidate','recognized'):result[key]=bool(host.tcl.getboolean(result[key]))
        if'parser_version'in result:result['parser_version']=int(result['parser_version'])
        result['diagnostics']=[_item(host,v)for v in host.as_list(result['diagnostics'])]
        return result
    if operation=='parse':return _parsed(host,host.call(command,*args))
    if operation=='edit':
        result=host.as_dict(host.call(command,*args));result['parsed']=_parsed(host,result['parsed']);result['affected_ids']=_list(host,result['affected_ids'])
        result['changed_spans']=[[int(host.as_list(v)[0]),int(host.as_list(v)[1]),_text(host,host.as_list(v)[2])]for v in host.as_list(result['changed_spans'])]
        return result
    if operation in('layout','inspect_element'):
        receipt=_receipt(args[0])
        if operation=='layout':
            if len(args)>1 and not isinstance(args[1],dict):_invalid('UML layout options must be a struct')
            return _layout(host,host.call(command,receipt,*args[1:]))
        if not isinstance(args[1],str):_invalid('UML semantic ID must be a string')
        return _item(host,host.call(command,receipt,args[1]))
    if operation=='export':return _export(host,command,args)
    context=host.dataset_private_context()
    if operation in('describe','read'):
        if not isinstance(args[0],str):_invalid('Canonical UML Dataset ID must be a string')
        options=dict(args[1])if len(args)>1 and isinstance(args[1],dict)else{}
        if len(args)>1 and not isinstance(args[1],dict)or set(options)-{'expected_session'}:
            _invalid('Canonical UML options admit only expected_session; capability/actor are runtime-owned')
        options['capability']=context['capability']
        raw=host.call(command,args[0],options)
        if operation=='describe':return _description(host,raw)
        result=host.as_dict(raw)
        return {'source':_text(host,result['source']),'sha256':_text(host,result['sha256']),
                'bytes':int(result['bytes']),'complete':bool(host.tcl.getboolean(result['complete'])),
                'description':_description(host,result['description']),'parsed':_parsed(host,result['parsed'])}
    if not isinstance(args[0],dict):_invalid('Canonical UML write requires a request struct')
    request=dict(args[0]);state=_state(host)
    for key in('expected_revision','source_revision'):
        if key in request:
            if not isinstance(request[key],str)or request[key]not in state['revisions']:
                _invalid('Use an opaque UML revision returned in this execution and Session')
            request[key]=state['revisions'][request[key]]
    result=_description(host,host.call(command,context['capability'],request))
    return host.record_publications(result)


def cleanup(host):host.handles.pop('uml_document',None)
