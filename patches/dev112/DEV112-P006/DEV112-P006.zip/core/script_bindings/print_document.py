"""Inert Print recipes through the existing Print Document authority.

The native Workspace shape supplies explicit field kinds; this adapter neither
infers dictionaries from scientific text nor implements layout or validation.
Printing, filesystem sources, callbacks and lifetime management stay host-owned.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray

_OPERATIONS = {
    'new': ('printRecipeNew', []),
    'poster_new': ('printRecipePosterNew', []),
    'slides_new': ('printRecipeSlidesNew', []),
    'slide_edit': ('printRecipeSlideEdit', ['recipe', 'operation', 'slide_id', 'options']),
    'page_size': ('printRecipePageSize', ['page']),
    'validate': ('printRecipeValidate', ['recipe']),
    'asset_identity': ('printRecipeAssetIdentity', ['item']),
    'item_label': ('printRecipeItemLabel', ['item']),
    'api_info': ('printDocumentApiInfo', []),
    'history_create': ('printRecipeHistoryCreate', ['recipe']),
    'history_edit': ('printRecipeHistoryEdit', ['history','recipe','description']),
    'document_save': ('printRecipeDocumentSave', ['recipe','history','id','expected']),
    'document_read': ('printRecipeDocumentRead', ['id']),
    'content_describe': ('printContentDescribe', ['kind','source']),
}
REGISTRATION = {
    'api_id': 'PRINT_DOCUMENT_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'print_document',
    'documentation_ref': 'docs/api/PRINT_DOCUMENT_API_v1.md',
    'operations': {name: {
        'name': name, 'summary': 'Existing inert Print Document operation: '+name,
        'host_command': '::GX::'+command,
        'arguments': [{'name': arg, 'kind': ('string' if arg in ('operation','slide_id','description','id') else
                                            'cell' if arg == 'expected' else 'struct'),
                       'required': not (arg == 'options' or name == 'document_save' and arg in ('id','expected'))}
                      for arg in arguments],
        'argument_convention': ', '.join(arguments) or 'no arguments',
        'result_contract': ('physical width/height numeric row in millimetres' if name == 'page_size' else
                            'opaque ordered content-reuse tokens' if name == 'asset_identity' else
                            'inert public string' if name == 'item_label' else
                            'typed owner-declared inert model or metadata'),
        'unit_behavior': 'Physical presentation millimetres; no scientific data or unit changes',
    } for name, (command, arguments) in _OPERATIONS.items()},
}

REGISTRATION['operations']['content_describe']['arguments'] = [
    {'name':'kind','kind':'dataset or graph','required':True},
    {'name':'source','kind':'canonical Dataset ID or provider graph reference struct','required':True}]
REGISTRATION['operations']['content_describe']['result_contract'] = 'closed canonical source presentation descriptor; graph identities remain path-free; no materialization, original-media transfer or printer grant'


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _shape_value(host, raw, depth=0):
    """Decode the existing owner's explicit native shape, never Tcl heuristics."""
    if depth > 64:
        _invalid('Print model exceeds the native Workspace depth limit')
    kind, value = host.as_list(raw)
    # Native live-state and cold DB reads may retain different Tcl internal
    # representations for the same explicit scalar tag. Preserve its Tcl text.
    kind = _text(host, kind)
    if kind == 'object':
        return {str(key): _shape_value(host, item, depth+1)
                for key, item in host.as_dict(value).items()}
    if kind == 'array':
        return [_shape_value(host, item, depth+1) for item in host.as_list(value)]
    if kind == 'int':
        return int(_text(host, value))
    if kind == 'real':
        return float(_text(host, value))
    if kind == 'bool':
        return bool(host.tcl.getboolean(_text(host, value)))
    if kind == 'text':
        return _text(host, value)
    _invalid('Unsupported Print owner native field kind')


def _recipe(host, raw):
    return _shape_value(host, host.call('::GX::nativeWorkspaceEncode', ['named', 'print_recipe'], raw))


def _history(host, raw):
    return _shape_value(host, host.call('::GX::nativeWorkspaceHistoryEncode', raw,
                                      ['::GX::nativeWorkspaceEncode', ['named','print_recipe']]))


def _document(host, raw, with_payload=False):
    result = host.normalize(raw)
    fields = host.as_dict(raw)
    for key in ('revision','format_version','durable_revision','queued_bytes'):
        if key in fields:
            result[key] = int(fields[key])
    for key in ('native_workspace','accepted','pending','failed','has_notes','has_preview'):
        if key in fields:
            result[key] = bool(host.tcl.getboolean(fields[key]))
    if with_payload:
        payload = host.as_dict(fields['payload'])
        result['payload'] = {'schema': _text(host, payload['schema']),
                             'recipe': _recipe(host, payload['recipe']),
                             'history': _history(host, payload['history'])}
    return result


def _api_info(host, raw):
    fields = host.as_dict(raw)
    result = {key: _text(host, fields[key]) for key in ('api_id','authority','transport','cups_lifetime')}
    result['api_version'] = int(fields['api_version'])
    result['scientific_authority'] = bool(host.tcl.getboolean(fields['scientific_authority']))
    result['operations'] = [_text(host, item) for item in host.as_list(fields['operations'])]
    contracts = {}
    for method, value in host.as_dict(fields['host_operation_contracts']).items():
        contract = host.as_dict(value)
        contracts[method] = {
            'command': _text(host, contract['command']),
            'arguments': [_text(host, arg) for arg in host.as_list(contract['arguments'])],
            'parameters': {name: {key: _text(host, item) for key, item in host.as_dict(parameter).items()}
                           for name, parameter in host.as_dict(contract['parameters']).items()},
            'result': {key: _text(host, item) for key, item in host.as_dict(contract['result']).items()},
            'context': _text(host, contract['context']),
        }
        for key in ('script_exposure','script_exclusion_reason'):
            if key in contract:
                contracts[method][key] = _text(host, contract[key])
    result['host_operation_contracts'] = contracts
    return result


def invoke(host, operation, args):
    if operation == 'content_describe':
        return _content_describe(host,args)
    if operation not in _OPERATIONS:
        _invalid('Unknown inert Print operation')
    command, fields = _OPERATIONS[operation]
    minimum = len(fields)-(1 if operation == 'slide_edit' else 2 if operation == 'document_save' else 0)
    if not minimum <= len(args) <= len(fields):
        _invalid('Invalid inert Print operation arguments')
    for name, value in zip(fields, args):
        if name in ('operation','slide_id','description','id'):
            if not isinstance(value, str):
                _invalid('Print operation, description and identity must be strings')
        elif name == 'expected':
            if not isinstance(value, (list,tuple)):
                _invalid('Existing Document expected stamp must be an explicit cell/list')
        elif not isinstance(value, dict):
            _invalid('Print model, page, item and options must be explicit structs')
    raw = host.call('::GX::'+command, *args)
    if operation in ('new','poster_new','slides_new','validate'):
        return _recipe(host, raw)
    if operation in ('history_create','history_edit'):
        return _history(host, raw)
    if operation in ('document_save','document_read'):
        return _document(host, raw, operation == 'document_read')
    if operation == 'slide_edit':
        receipt = host.as_dict(raw)
        return {'recipe': _recipe(host, receipt['recipe']),
                'selected_slide_id': _text(host, receipt['selected_slide_id'])}
    if operation == 'page_size':
        return NumericArray([float(value) for value in host.as_list(raw)], [1,2])
    if operation == 'asset_identity':
        return [_text(host, value) for value in host.as_list(raw)]
    if operation == 'item_label':
        return _text(host, raw)
    return _api_info(host, raw)


def _content_describe(host,args):
    import re
    from pathlib import Path
    if len(args)!=2 or args[0] not in {'dataset','graph'}:
        _invalid('Content description requires dataset or graph and its canonical identity')
    kind,source=args
    if kind=='dataset':
        if not isinstance(source,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]*',source):
            _invalid('Print Dataset source must be a canonical Dataset ID')
        owner_source=source
    else:
        if (not isinstance(source,dict) or set(source)-{'kind','module_id','graph_id','variant_id'} or
                source.get('kind','provider')!='provider'):
            _invalid('Print Graph source requires a closed provider graph reference; raw paths are forbidden')
        for key in ('module_id','graph_id'):
            if not isinstance(source.get(key),str) or not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*',source[key]):
                _invalid('Print Graph source requires installed provider and graph IDs')
        if 'variant_id' in source and (not isinstance(source['variant_id'],str) or source['variant_id'] and not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*',source['variant_id'])):
            _invalid('Print Graph variant must be a stable Variant ID')
        source=host.as_dict(host.call('::GX::graphResourceRef',source))
        owner_source=str(host.call('::GX::graphAxisArtifactPath',source['module_id'],source['graph_id'],source['variant_id']))
        path=Path(owner_source)
        if not host.session or not path.resolve().is_relative_to(Path(host.session).resolve()):
            raise BridgeError('GXTXT:ScriptBridge:Ownership','Graph artwork must remain in the execution Session')
        for part in (path,*path.parents):
            if part.is_symlink():
                raise BridgeError('GXTXT:ScriptBridge:Ownership','Graph artwork symlink ancestry is forbidden')
    fields=host.as_dict(host.call('::GX::printContentDescribe',kind,owner_source))
    result={key:_text(host,fields[key]) for key in ('source_kind','title','kind','default','reason')}
    result['source_id']=source
    result['representations']=[_text(host,value) for value in host.as_list(fields['representations'])]
    if kind=='dataset':
        for key in ('format','media_type'):result[key]=_text(host,fields[key])
        result['row_count']=int(fields['row_count']) if fields['row_count']!='' else ''
        for key in ('table_variables','xy_variables'):result[key]=[_text(host,value) for value in host.as_list(fields[key])]
        variables=[]
        allowed={'variable_id','column_id','canonical','display_name','unit','dtype','rank','shape','dimension_ids','enabled','coordinate_role','semantic_role','group_id','label','name','render_role'}
        for value in host.as_list(fields['variables']):
            row={key:item for key,item in host.as_dict(value).items() if key in allowed}
            if 'rank' in row:row['rank']=int(row['rank'])
            if 'enabled' in row:row['enabled']=bool(host.tcl.getboolean(row['enabled']))
            if 'shape' in row:row['shape']=[int(size) for size in host.as_list(row['shape'])]
            if 'dimension_ids' in row:row['dimension_ids']=[_text(host,item) for item in host.as_list(row['dimension_ids'])]
            variables.append(row)
        result['variables']=variables
    return result
