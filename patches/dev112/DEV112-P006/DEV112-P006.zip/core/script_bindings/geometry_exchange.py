"""Closed exact-copy transport through the existing Geometry Exchange owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
import uuid
from gxtxt_script_bridge_server import BridgeError

_ARGS = {'info': ([], 0),
         'export': (['document_id', 'selected', 'expectation', 'options'], 3),
         'export_resource': (['document_id', 'selected', 'expectation', 'options'], 3),
         'inspect': (['exchange_token'], 1),
         'import': (['document_id', 'exchange_token', 'expectation', 'options'], 3),
         'import_resource': (['document_id', 'resource', 'expectation', 'options'], 3),
         'restore': (['document_id', 'exchange_index', 'expectation'], 3)}
REGISTRATION = {
    'api_id': 'GEOMETRY_EXCHANGE_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'geometry_exchange',
    'documentation_ref': 'docs/api/GEOMETRY_EXCHANGE_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Existing exact Geometry Exchange owner: '+name,
        'arguments': [{'name': field, 'kind': 'public owned value', 'required': index < minimum}
                      for index, field in enumerate(fields)],
        'argument_convention': ', '.join(fields),
        'result_contract': 'owned descriptor token, verified managed Resource, or adopted Native2D scene/receipt; no paths/callbacks/Session token'}
        for name, (fields, minimum) in _ARGS.items()},
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _state(host):
    return host.handles.setdefault('geometry_exchange', {'exchanges': {}, 'resources': {}})


def _owned_call(host, command, *args):
    host.dataset_private_context()
    return host.call('::GX::_datasetPrivateWithModule', host.module_id, command, *args)


def _guard(host, document, expected, owned=False):
    if not isinstance(document, str) or not isinstance(expected, dict) or set(expected) != {'generation', 'revision', 'sha256'}:
        _invalid('Exchange requires a Document identity and held generation/revision/sha256')
    revision = expected['revision']
    if (any(not isinstance(expected[key], str) for key in ('generation', 'sha256')) or
        isinstance(revision, bool) or not isinstance(revision, (int, float)) or
        not math.isfinite(revision) or revision < 1 or int(revision) != revision):
        _invalid('Exchange receipt fields require strings and an exact positive revision')
    raw = (_owned_call(host, '::GX::_geometryExchangeOwner', document) if owned
           else host.call('::GX::_geometryExchangeDocumentRead', document))
    owner = host.as_dict(raw)
    if any(str(owner[key]) != str(int(revision) if key == 'revision' else expected[key]) for key in ('generation', 'revision', 'sha256')):
        raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Exchange Document changed; read its current receipt again')
    return owner


def _options(value, importing=False):
    allowed = {'target_unit', 'transform'} if importing else {'dependencies', 'groups', 'frame'}
    if not isinstance(value, dict) or set(value) - allowed:
        _invalid('Exchange options admit only declared value fields, without callbacks or paths')
    if not importing and 'frame' in value:
        frame = value['frame']
        if not isinstance(frame, dict) or any(not isinstance(x, str) for x in frame.values()):
            _invalid('Exchange frame metadata requires explicit text fields')
    return value


def _inspect(host, descriptor):
    result = host.as_dict(host.call('::GX::geometryExchangeInspect', descriptor))
    result['source'] = host.modules['INTERACTIVE_DOCUMENT_API_v1']._document_metadata(host, result['source'])
    for key in ('object_count', 'constraint_count'): result[key] = int(result[key])
    result['frame'] = host.as_dict(result['frame'])
    return result


def _descriptor(host, token):
    if not isinstance(token, str) or token not in _state(host)['exchanges']:
        _invalid('Exchange descriptor is not owned by this execution')
    return _state(host)['exchanges'][token]


def _resource(host, raw):
    result = host.as_dict(raw);result['size_bytes'] = int(result['size_bytes'])
    result['metadata'] = host.as_dict(result['metadata'])
    return result


def _resource_key(value):
    if not isinstance(value, dict) or not isinstance(value.get('metadata'), dict):
        _invalid('Exchange resource requires its original managed identity')
    try:
        size = value['size_bytes']
        if isinstance(size, bool) or not isinstance(size, (int, float)) or not math.isfinite(size) or int(size) != size or not 0 <= size <= 67108864:
            _invalid('Exchange resource byte count must be an exact bounded integer')
        return tuple(str(value[key]) for key in ('api_id', 'document_id', 'owner_generation', 'sha256')) + (str(int(size)), str(value['metadata']['format']))
    except KeyError:
        _invalid('Exchange resource is missing its owned identity fields')


def _adopt(host, raw, index):
    record = host.as_dict(raw)
    result = {'scene_token': str(record['scene_token']), 'exchange_index': index,
              'object_tokens': {str(k): str(v) for k, v in host.as_dict(record['object_tokens']).items()},
              'group_tokens': {str(k): str(v) for k, v in host.as_dict(record['group_tokens']).items()}}
    for key in ('target_document',):
        if key in record: result[key] = str(record[key])
    if 'revision' in record: result['revision'] = int(record['revision'])
    if 'copy' in record: result['copy'] = bool(host.tcl.getboolean(record['copy']))
    if 'source_to_destination' in record:
        result['source_to_destination'] = {str(k): str(v) for k, v in host.as_dict(record['source_to_destination']).items()}
    host.modules['NATIVE_2D_GEOMETRY_API_v1']._state(host)['scenes'].add(result['scene_token'])
    return result


def invoke(host, operation, args):
    if operation not in _ARGS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', operation)
    fields, minimum = _ARGS[operation]
    if not minimum <= len(args) <= len(fields): _invalid('Invalid Geometry Exchange arguments')
    if operation == 'info':
        result = host.as_dict(host.call('::GX::geometryExchangeApiInfo'))
        for key in ('api_version', 'format_version', 'max_bytes', 'max_document_bytes', 'max_objects'): result[key] = int(result[key])
        for key in ('exact_geometry', 'implicit_dataset_publication', 'owner_payload_adapter'): result[key] = bool(host.tcl.getboolean(result[key]))
        for key in ('transport', 'dependency_policies', 'operations'): result[key] = host.as_list(result[key])
        result.update(script_callbacks=False, script_import_formats=['core.geometry_exchange'], script_operations=list(_ARGS))
        return result
    if operation in {'export', 'export_resource'}:
        document, selected, expected = args[:3]
        if not isinstance(selected, (list, tuple)) or not 1 <= len(selected) <= 16384 or any(not isinstance(x, str) for x in selected):
            _invalid('Exchange selection requires1..16384whole saved object IDs')
        options = _options(args[3] if len(args) > 3 else {})
        _guard(host, document, expected)
        if operation == 'export_resource':
            raw = host.call('::GX::geometryExchangeExportResource', document, selected, options)
            _guard(host, document, expected);resource = _resource(host, raw)
            _state(host)['resources'][_resource_key(resource)] = resource
            return resource
        descriptor = host.call('::GX::geometryExchangeExport', document, {}, selected, options)
        _guard(host, document, expected);result = _inspect(host, descriptor)
        token = 'geometry-exchange#'+uuid.uuid4().hex;_state(host)['exchanges'][token] = descriptor
        result.update(exchange_token=token, descriptor_sha256=str(host.as_dict(descriptor)['sha256']))
        return result
    if operation == 'inspect': return _inspect(host, _descriptor(host, args[0]))
    document, value, expected = args[:3]
    owner = _guard(host, document, expected, owned=True)
    if str(owner['format']) != 'core.geometry_exchange':
        _invalid('Closed exchange writes/restores require the existing core.geometry_exchange destination owner')
    payload = host.as_dict(owner['payload']);copies = host.as_list(payload.get('exchanges', ''))
    if operation == 'restore':
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or int(value) != value or not 0 <= value < len(copies):
            _invalid('Restore requires an existing committed destination copy index')
        copy = host.as_dict(copies[int(value)])
        raw = _owned_call(host, '::GX::geometryExchangeRestore', document, copy['sketch'], copy['groups'])
        return _adopt(host, raw, int(value))
    options = _options(args[3] if len(args) > 3 else {}, importing=True)
    if operation == 'import_resource':
        key = _resource_key(value)
        if key not in _state(host)['resources']: _invalid('Resource was not exported by this execution')
        resource = _state(host)['resources'][key]
        raw = _owned_call(host, '::GX::geometryExchangeImportResource', document, resource, options)
    else:
        raw = _owned_call(host, '::GX::geometryExchangeImport', document, _descriptor(host, value), options)
    return _adopt(host, raw, len(copies))
