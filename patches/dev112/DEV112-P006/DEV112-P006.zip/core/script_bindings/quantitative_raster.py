"""Original scientific sample measurements through the canonical CORE owners."""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
from gxtxt_script_bridge_server import BridgeError

COMMANDS = {
    'source_info': ('::GX::quantitativeRasterSourceInfo', ['dataset_id']),
    'submit': ('::GX::quantitativeRasterSubmit', ['document_id', 'dataset_id', 'expected_sha256',
               'expected_revision', 'source_resource', 'parameters']),
    'status': ('::GX::quantitativeRasterStatus', ['job_id']),
    'cancel': ('::GX::quantitativeRasterCancel', ['job_id']),
    'result': ('::GX::quantitativeRasterResult', ['job_id']),
    'histogram_page': ('::GX::quantitativeRasterHistogramPage',
                       ['job_id', 'output_token', 'generation', 'offset', 'count']),
}
REGISTRATION = {
    'api_id': 'QUANTITATIVE_RASTER_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'quantitative_raster',
    'documentation_ref': 'docs/api/QUANTITATIVE_RASTER_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Original-source quantitative raster '+name,
        'arguments': [{'name': arg, 'kind': 'public value', 'required': True} for arg in args],
        'argument_convention': ', '.join(args),
        'result_contract': 'Canonical source identity, managed Job receipt or finite typed measurement'}
        for name, (_, args) in COMMANDS.items()},
}


REGISTRATION['operations']['api_info'] = {
    'name': 'api_info', 'summary': 'Read the original quantitative metadata owner',
    'arguments': [], 'argument_convention': 'no arguments',
    'result_contract': 'Exact original API/version/provider/lists/limits/units/diagnostics; no measurement',
}
REGISTRATION['operations']['canvas_command'] = {
    'name': 'canvas_command', 'summary': 'Use only this execution-owned Native2D Canvas through original quantitative owners',
    'arguments': [{'name': name, 'kind': kind, 'required': True} for name, kind in
                  [('canvas', 'existing same-execution Native2D Canvas token'),
                   ('operation', 'discover/map_roi/submit/status/cancel/result/histogram_page/reconnect'),
                   ('request', 'original closed finite request; no path/callback/owner/Resource fields')]],
    'argument_convention': 'canvas, operation, request',
    'result_contract': 'Original typed source/ROI/managed Job/status/measurement/count page; no new scientific owner',
}


def _canvas_lease(host, token, lifecycle):
    owned = host.handles.get('native2d_geometry', {}).get('canvases', set())
    if not isinstance(token, str) or token not in owned:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Quantitative Canvas belongs to another or closed Bridge execution')
    row = host.as_dict(host.call('::GX::_nativeCanvasRequire', token, 0 if lifecycle else 1))
    if str(row['module']) != host.module_id or str(row['session']) != str(host.call('::GX::interactiveDocumentSessionToken')):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Quantitative Canvas Module/Session differs from this execution')
    receipt = host.as_dict(row['receipt'])
    return tuple(str(row[k]) for k in ('session', 'module', 'provider', 'document', 'geometry', 'native')) + (str(receipt['generation']),)


def _canvas_command(host, args):
    if len(args) != 3 or not isinstance(args[1], str) or not isinstance(args[2], dict):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Choose an owned Canvas, finite quantitative operation and closed request')
    token, action, request = args
    # Ordinary Octave scalars can arrive as exact integral binary64 values.
    # Normalize only transport integer controls; original bounds/semantics
    # remain exclusively in the existing validator and owner.
    request = dict(request)
    for key in ('x', 'y', 'width', 'height', 'frame', 'bins', 'offset', 'count'):
        value = request.get(key)
        if type(value) is float and value.is_integer(): request[key] = int(value)
    from viewer_quantitative_request_v1 import validate_quantitative_request
    validate_quantitative_request(action, request, lambda message, code: BridgeError('GXTXT:ScriptBridge:InvalidArguments', message))
    if len(json.dumps(request, allow_nan=False).encode('utf-8')) > 49152:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Quantitative request exceeds its existing48KiB finite envelope')
    lifecycle = action in ('status', 'cancel')
    held = _canvas_lease(host, token, lifecycle)
    raw = host.call('::GX::quantitativeRasterCanvasCommand', token, action, request)
    if _canvas_lease(host, token, lifecycle) != held:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Quantitative Canvas lease changed while awaiting its original owner')
    return json.loads(str(host.call('::GX::nativeWorkspaceJsonEncode', raw)))


def invoke(host, operation, args):
    if operation == 'api_info':
        if args: raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Quantitative API metadata takes no arguments')
        result = host.as_dict(host.call('::GX::quantitativeRasterApiInfo'))
        for key in ('api_version', 'histogram_page_limit', 'encoded_bytes_max', 'pixels_max', 'metadata_bytes_max'): result[key] = int(result[key])
        for key in ('operations', 'canvas_operations'): result[key] = [str(v) for v in host.as_list(result[key])]
        return {str(k): v if isinstance(v, (int, list)) else str(v) for k, v in result.items()}
    if operation == 'canvas_command': return _canvas_command(host, args)
    if operation not in COMMANDS or len(args) != len(COMMANDS[operation][1]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid finite quantitative arguments')
    raw = host.call(COMMANDS[operation][0], *args)
    if operation in {'result', 'histogram_page'}:
        return json.loads(str(host.call('::GX::nativeWorkspaceJsonEncode', raw)))
    if operation in {'status', 'cancel'}:
        fields = host.as_dict(raw)
        result = {key: str(fields[key]) for key in
                  ('job_id', 'provider_id', 'state', 'error', 'diagnostic', 'progress_stage') if key in fields}
        if 'progress_percent' in fields:
            result['progress_percent'] = float(fields['progress_percent'])
        if 'policy' in fields:
            result['policy'] = {str(k): int(v) for k, v in host.as_dict(fields['policy']).items()}
        if 'source_current' in fields:
            result['source_current'] = bool(int(fields['source_current']))
        return host.normalize(result)
    return host.normalize(host.as_dict(raw))
