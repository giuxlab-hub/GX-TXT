"""Execution-owned opaque Native3D geometry on the public CORE authority."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray
import math
import hashlib

_ARGS = {"api_info": [], "open": ["document_id"], "close": ["scene"], "scene_info": ["scene"],
         "checkpoint": ["scene", "payload"],
         "planar_api_info": [], "planar_list": [],
         "planar_edit_begin": ["document_id", "mode"],
         "planar_edit_cancel": ["edit_token"],
         "planar_edit_accept": ["edit_token", "definitions", "working_unit", "presentation"],
         "origin_receipt": ["document_id", "object_id"], "origin_validate": ["receipt"],
         "convert_axes": ["scene", "object_token", "source_units", "target_unit"],
         "import_dataset": ["scene", "dataset_id", "working_unit", "assumed_input_unit"],
         "profile_from_sources": ["scene", "sources", "plane", "tolerance"],
         "profile_resources": ["scene", "profile_token"],
         "profile_view_resource": ["scene", "profile_token"],
         "export_resource": ["scene", "object_token", "format", "millimeters_per_working_unit", "placement"]}
for _operation in ("profile", "logical_id", "plane_frame", "indexed_mesh", "polydata", "masked_surface", "sweep", "project", "projection_profile", "load_scientific", "extrude", "box", "cylinder", "boolean", "duplicate", "mesh",
                   "load_mesh", "load_step", "restore_step",
                   "describe", "compare_geometry", "compare_sections", "geometry_role", "anchor_describe", "delete", "transform", "profile_delete", "translate", "rotate",
                   "scale", "rescale_coordinates", "reset_transform", "clean", "weld", "orient", "heal", "clip", "profile_rescale", "section_profile",
                   "clip_cap", "self_intersections", "mesh_append", "mesh_merge", "mesh_stitch", "mesh_bridge", "mesh_heal_seam", "mesh_lod", "mesh_boundaries", "mesh_intersection_pairs", "group_copy", "group_duplicate", "group_delete", "measure", "align_three_points", "constraint_solve"):
    _ARGS[_operation] = ["scene", "request"]
for _family in ("selection_set", "layer", "saved_view"):
    for _action in ("create", "get", "list", "update", "delete"):
        _ARGS[_family+"_"+_action] = ["scene", "request"]
for _operation in ("selection_set_activate", "selection_set_apply", "layer_assign", "saved_view_restore"):
    _ARGS[_operation] = ["scene", "request"]
REGISTRATION = {
    "api_id": "NATIVE_3D_GEOMETRY_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "native3d_geometry",
    "documentation_ref": "docs/api/NATIVE_3D_GEOMETRY_API_v1.md",
    "operations": {name: {"name": name, "summary": "Scoped retained Native3D geometry: " + name,
                           "arguments": [{"name": arg, "kind": "opaque token" if arg == "scene" else "public value", "required": True} for arg in args],
                           "argument_convention": ", ".join(args),
                           "result_contract": "opaque scene/object/profile or bounded scientific descriptor",
                           "result_convention": "typed public geometry receipt"} for name, args in _ARGS.items()},
}
_HOST_ARGS = {"layer_texture_validate": ["descriptor", "layer"],
              "layer_texture_bind": ["module_id", "viewer_id", "layer_id", "resource", "placement"],
              "document_presentation_set": ["snapshot"],
              "document_presentation_remove": ["document_id"],
              "document_presentation_inspect": []}
TEXTURE_REGISTRATION = {
    "api_id": "NATIVE_3D_GUI_HOST_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "native3d_gui_host",
    "documentation_ref": "docs/api/NATIVE_3D_GUI_HOST_API_v1.md",
    "operations": {operation: {
        "name": operation, "summary": "Existing Native3D data presentation owner: " + operation,
        "arguments": [{"name": name, "kind": "public value", "required": True} for name in names],
        "argument_convention": ", ".join(names), "result_contract": "typed derived presentation or managed texture descriptor",
        "result_convention": "Current Document/Resource owner, bounded values, no rendering"} for operation, names in _HOST_ARGS.items()},
}
PREPARATION_REGISTRATION = {
    "api_id": "NATIVE_3D_GUI_HOST_API_v2", "api_version": 2,
    "provider_kind": "core", "provider_id": "native3d_gui_host",
    "documentation_ref": "docs/api/NATIVE_3D_GUI_HOST_API_v2.md",
    "operations": {"scene_prepare": {
        "name": "scene_prepare", "summary": "Resolve current registered scene columns and managed texture metadata",
        "arguments": [{"name": name, "kind": "public value", "required": name != "expectation"}
                      for name in ("module_id", "viewer_id", "layer_ids", "expectation")],
        "result_contract": "Bounded pathless source receipt, view/layer/column/texture metadata; no rendering or caller scene",
    }},
}
REGISTRATIONS = [REGISTRATION, TEXTURE_REGISTRATION, PREPARATION_REGISTRATION]


def _scene_prepare(host, args):
    def invalid(message):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", message)
    if len(args) not in (3, 4): invalid("Scene preparation requires module, Viewer, layer IDs and optional held source receipt")
    module, viewer, selected = args[:3]
    if any(not isinstance(x, str) or not 1 <= len(x) <= 256 or "\0" in x for x in (module, viewer)):
        invalid("Choose an existing registered Viewer owner")
    if not isinstance(selected, (list, tuple)) or len(selected) > 256 or any(not isinstance(x, str) or not 1 <= len(x) <= 128 for x in selected) or len(set(selected)) != len(selected):
        invalid("Select at most256 unique current registered layer IDs")
    current = [str(x) for x in host.as_list(host.call("::GX::viewerLayerIds", module, viewer))]
    if len(current) > 256: invalid("Registered source exceeds256 layers")
    chosen = list(selected) if selected else current
    if any(x not in current for x in chosen): invalid("Selected layer is not owned by this registered Viewer")
    expected = args[3] if len(args) == 4 else None
    if expected is not None and (not isinstance(expected, dict) or set(expected) != {"sha256"} or not isinstance(expected["sha256"], str) or len(expected["sha256"]) != 64):
        invalid("Held scene source receipt requires exactly its SHA256")
    def capture():
        owner = host.call("::GX::viewerProviderDefinition", module, viewer)
        if not str(owner): invalid("Viewer provider is disabled or unavailable")
        raw = host.call("::GX::viewerSceneResolve", module, viewer, {"presentation_layer_ids": chosen})
        if len(str(host.tcl.call("format", "%s", raw)).encode()) > 1048576:
            invalid("Prepared source metadata exceeds1MiB")
        identity = host.call("::GX::_native3DViewportScientificIdentity", raw)
        session = str(host.call("::GX::interactiveDocumentSessionToken"))
        view = host.as_dict(raw)["view"]
        pieces = (module, viewer, session, owner, identity, view)
        stamp = hashlib.sha256("\0".join(str(host.tcl.call("format", "%s", x)) for x in pieces).encode()).hexdigest()
        return raw, stamp
    raw, stamp = capture()
    if expected is not None and expected["sha256"] != stamp:
        raise BridgeError("GXTXT:ScriptBridge:StaleInput", "Scene owner/source changed; capture its current receipt again")
    prepared = host.as_dict(host.call("::GX::native3DScenePrepare", raw))
    view = host.as_dict(prepared["view"])
    result = {"module_id": module, "viewer_id": viewer, "source_receipt": {"sha256": stamp},
              "view": {k: str(view[k]) for k in ("camera_position", "camera_target", "camera_up", "projection")}, "layers": {}}
    for key in ("axes_world", "navigation_cube_visible", "orientation_indicator_visible"):
        result["view"][key] = bool(host.tcl.getboolean(view[key]))
    identifiers = {"kind", "source_mode", "dataset_id", "source_dataset_id", "source_dataset_sha256", "format", "format_version", "sha256", "x_variable_id", "y_variable_id", "z_variable_id", "scalar_array", "radius_array", "opacity_array", "color_array", "representation", "colormap", "scalar_range"}
    for layer_id, value in host.as_dict(prepared["layers"]).items():
        layer = host.as_dict(value)
        item = {key: str(layer[key]) for key in identifiers if key in layer}
        for key in ("x_column", "y_column", "z_column", "scalar_column", "radius_column", "opacity_column", "layer_order"):
            if key in layer: item[key] = int(layer[key])
        if "vector_columns" in layer: item["vector_columns"] = [int(x) for x in str(layer["vector_columns"]).split(";")]
        for key in ("opacity", "line_width", "point_size"):
            if key in layer: item[key] = float(layer[key])
        for key in ("visible", "backface_culling", "scalar_coloring"):
            if key in layer: item[key] = bool(host.tcl.getboolean(layer[key]))
        if item.get("source_mode") == "dataset":
            item["coordinate_units"] = {axis: str(host.as_dict(host.call("::GX::datasetVariableById", item["dataset_id"], layer[axis+"_variable_id"])).get("unit", "")) for axis in ("x", "y", "z")}
        if str(layer.get("texture", "")):
            texture = host.as_dict(layer["texture"])
            # Internal renderer paths/mapping/provenance are not public values.
            output = {key: str(texture[key]) for key in ("schema", "source_geometry_sha256", "local_anchor", "working_unit")}
            for key in ("source_triangle", "occurrence_index", "image_width", "image_height", "image_bit_depth"): output[key] = int(texture[key])
            for key in ("anchor_u", "anchor_v", "width", "height", "rotation_radians"): output[key] = float(texture[key])
            for key in ("flip_u", "flip_v"): output[key] = bool(host.tcl.getboolean(texture[key]))
            resource = host.as_dict(texture["resource"])
            output["resource"] = {key: str(resource[key]) for key in ("api_id", "document_id", "owner_generation", "sha256")}
            output["resource"]["size_bytes"] = int(resource["size_bytes"])
            output["resource"]["metadata"] = {"format": str(host.as_dict(resource["metadata"])["format"])}
            item["texture"] = output
        result["layers"][str(layer_id)] = item
    _, after = capture()
    if after != stamp:
        raise BridgeError("GXTXT:ScriptBridge:StaleInput", "Scene source changed during preparation")
    if len(str(result).encode()) > 1048576: invalid("Prepared result metadata exceeds1MiB")
    return result


def _native2d_codec(host):
    # The existing registered owner defines retained-definition transport.
    return host.modules["NATIVE_2D_GEOMETRY_API_v1"]


def _document_metadata(host, raw):
    fields = host.as_dict(raw)
    names = {"id", "module_id", "provider_id", "format", "format_version", "sha256", "created_at", "updated_at",
             "revision", "generation", "native_workspace", "provider", "name", "schema", "version"}
    result = {key: str(value) for key, value in fields.items() if key in names}
    for key in ("revision", "format_version"):
        if key in fields: result[key] = int(fields[key])
    if "native_workspace" in fields: result["native_workspace"] = bool(host.tcl.getboolean(fields["native_workspace"]))
    return result


def _planar_begin(host, raw):
    result = host.as_dict(raw);context = host.as_dict(result["context"])
    context.pop("session_token", None);context["revision"] = int(context["revision"])
    payload = host.as_dict(result["payload"]);mode = context["mode"]
    definitions = {}
    for key, value in host.as_dict(host.as_dict(payload[mode])["definitions"]).items():
        record = host.as_dict(value);record["definition"] = _native2d_codec(host)._receipt(host, record["definition"])
        record["units"] = host.as_list(record["units"])
        if "provenance" in record:
            record["provenance"] = host.as_dict(record["provenance"])
            if "source_contour" in record["provenance"]: record["provenance"]["source_contour"] = int(record["provenance"]["source_contour"])
        definitions[key] = record
    # The original Document text remains inert, as in INTERACTIVE_DOCUMENT_API.
    # Editable values have an explicit typed contract; no Tcl text is evaluated.
    return {"token": result["token"], "context": context,
            "payload_text": str(host.tcl.call("format", "%s", result["payload"])),
            "definitions": definitions, "working_unit": payload["working_unit"],
            "plane": {k: NumericArray([float(x) for x in host.as_list(v)]) if k in {"origin", "normal", "u_axis", "v_axis"} else v
                      for k, v in host.as_dict(payload["plane"]).items()},
            "tolerance": float(payload["tolerance"]),
            "presentation": {"reference_opacity": float(host.as_dict(payload["presentation"])["reference_opacity"]),
                             "reference_visible": bool(host.tcl.getboolean(host.as_dict(payload["presentation"])["reference_visible"]))}}


def _planar_invoke(host, operation, args):
    edits = _state(host).setdefault("planar_edits", {})
    if operation == "planar_api_info":
        result = host.as_dict(host.call("::GX::native3DPlanarApiInfo"))
        for key in ("operations", "create_modes"): result[key] = host.as_list(result[key])
        for key in ("max_contours", "max_points", "reference_pixels_max"): result[key] = int(result[key])
        return result
    if operation == "planar_list":
        return [_document_metadata(host, item) for item in host.as_list(host.call("::GX::native3DPlanarList"))]
    if operation == "planar_edit_begin":
        raw = host.call("::GX::native3DPlanarEditBegin", *args)
        try: result = _planar_begin(host, raw)
        except Exception:
            host.call("::GX::native3DPlanarEditCancel", host.as_dict(raw)["token"])
            raise
        edits[result["token"]] = result["context"]["document_id"]
        return result
    if operation in {"planar_edit_accept", "planar_edit_cancel"}:
        if args[0] not in edits:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Planar edit token is not owned by this execution")
        if operation == "planar_edit_cancel":
            result = str(host.call("::GX::native3DPlanarEditCancel", args[0]))
        else:
            definitions, presentation = args[1], args[3]
            if not isinstance(definitions, dict) or not 1 <= len(definitions) <= 4096 or not isinstance(presentation, dict) or set(presentation) != {"reference_opacity", "reference_visible"}:
                raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Planar acceptance requires bounded definitions and explicit reference presentation")
            raw = host.call("::GX::native3DPlanarEditAccept", args[0], _native2d_codec(host)._request(definitions), args[2], presentation)
            result = host.as_dict(raw);result["result"] = _receipt(host, result["result"])
        del edits[args[0]]
        return result
    if operation == "origin_receipt":
        result = host.as_dict(host.call("::GX::native3DPlanarOriginReceipt", *args));result["revision"] = int(result["revision"])
        result["session_origin"] = host.as_dict(result["session_origin"])
        return result
    if not isinstance(args[0], dict):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Origin validation requires an explicit receipt")
    raw = host.call("::GX::native3DPlanarOriginValidate", args[0]);owner = host.as_dict(raw)
    host.call("::GX::modulePublicApiActivate", "viewer.3d_workbench", "WORKBENCH_3D_API_v1")
    typed = host.call("::GX::Workbench3D::workspaceEncode", owner["payload"])
    result = _document_metadata(host, raw)
    result["payload"] = host.modules["NATIVE_WORKSPACE_API_v1"].from_tcl(host, typed)
    return result


def _texture_receipt(host, raw):
    descriptor = host.as_dict(raw)
    for key in ("source_triangle", "occurrence_index", "image_width", "image_height", "image_bit_depth"): descriptor[key] = int(descriptor[key])
    for key in ("anchor_u", "anchor_v", "width", "height", "rotation_radians"): descriptor[key] = float(descriptor[key])
    for key in ("flip_u", "flip_v"): descriptor[key] = bool(host.tcl.getboolean(descriptor[key]))
    for key in ("mapping", "provenance"):
        if key in descriptor: descriptor[key] = host.as_dict(descriptor[key])
    descriptor["resource"] = _receipt(host, descriptor["resource"])
    return descriptor


def _memory_layers(layers):
    def invalid():
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Presentation requires bounded finite retained memory geometry")
    def rows(value, width):
        if isinstance(value, NumericArray):
            numbers = value.values.tolist() if hasattr(value.values, "tolist") else list(value.values)
            if value.shape == [width]: value = [numbers]
            elif len(value.shape) == 2 and value.shape[1] == width:
                count = value.shape[0];value = [[numbers[r+count*c] for c in range(width)] for r in range(count)]
            else: invalid()
        if not isinstance(value, (list, tuple)): invalid()
        result = []
        for row in value:
            if not isinstance(row, (list, tuple)) or len(row) != width: invalid()
            if any(not isinstance(x, (int, float)) or not math.isfinite(x) for x in row): invalid()
            result.append(list(row))
        return result
    if not isinstance(layers, dict) or len(layers) > 4096: invalid()
    result = {};total = 0
    allowed = {"source_mode", "vertices", "triangles", "polylines", "points", "kind", "provenance", "dataset_id", "layer_order", "visible", "opacity", "representation", "base_color", "line_width", "point_size", "backface_culling", "scalar_coloring", "scalar_array"}
    for name, layer in layers.items():
        if not isinstance(layer, dict) or set(layer)-allowed or layer.get("source_mode") != "memory_geometry": invalid()
        item = dict(layer);item["vertices"] = rows(layer.get("vertices"), 3);count = len(item["vertices"]);total += count
        if total > 1048576: invalid()
        def indices(data):
            if isinstance(data, NumericArray): data = data.values.tolist() if hasattr(data.values, "tolist") else list(data.values)
            if not isinstance(data, (list, tuple)): invalid()
            if any(not isinstance(x, (int, float)) or not math.isfinite(x) or int(x) != x or not 0 <= x < count for x in data): invalid()
            return [int(x) for x in data]
        if "triangles" in layer: item["triangles"] = [indices(row) for row in rows(layer["triangles"], 3)]
        if "polylines" in layer:
            if not isinstance(layer["polylines"], (list, tuple)): invalid()
            item["polylines"] = [indices(row) for row in layer["polylines"]]
        if "points" in layer: item["points"] = indices(layer["points"])
        for field in ("opacity", "line_width", "point_size"):
            if field in item and (not isinstance(item[field], (int, float)) or not math.isfinite(item[field]) or item[field] < 0): invalid()
        for field in ("visible", "backface_culling", "scalar_coloring"):
            if field in item and item[field] not in (False, True, 0, 1): invalid()
        result[name] = item
    return result


def invoke_api(host, api_id, operation, args):
    if api_id == REGISTRATION["api_id"]: return invoke(host, operation, args)
    if api_id == PREPARATION_REGISTRATION["api_id"]:
        if operation != "scene_prepare":
            raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", operation)
        return _scene_prepare(host, args)
    if api_id != TEXTURE_REGISTRATION["api_id"] or operation not in _HOST_ARGS or len(args) != len(_HOST_ARGS[operation]):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Invalid Native3D presentation arguments")
    if operation == "layer_texture_validate":
        if not all(isinstance(x, dict) for x in args):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Texture validation requires descriptor/layer structs")
        return _texture_receipt(host, host.call("::GX::native3DLayerTextureValidate", *args))
    if operation == "layer_texture_bind":
        if not isinstance(args[3], dict) or not isinstance(args[4], dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Texture binding requires managed Resource and placement structs")
        return _texture_receipt(host, host.call("::GX::native3DLayerTextureBind", *args))
    if operation == "document_presentation_set":
        snapshot = args[0]
        if not isinstance(snapshot, dict) or set(snapshot) != {"document_id", "generation", "revision", "layers"}:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Presentation requires a held Document identity and layers")
        snapshot = {**snapshot, "layers": _memory_layers(snapshot["layers"]),
                    "session_token": str(host.call("::GX::interactiveDocumentSessionToken"))}
        result = host.as_dict(host.call("::GX::native3DGuiHostDocumentPresentationSet", snapshot))
        for key in ("revision", "layers", "points"): result[key] = int(result[key])
        return result
    if operation == "document_presentation_remove":
        host.call("::GX::native3DGuiHostDocumentPresentationRemove", args[0]);return True
    result = {}
    for document, value in host.as_dict(host.call("::GX::native3DGuiHostDocumentPresentationInspect")).items():
        item = host.as_dict(value);item.pop("session_token", None)
        for key in ("revision", "layer_count"): item[key] = int(item[key])
        result[document] = item
    return result


def _state(host):
    return host.handles.setdefault("native3d_geometry", {"scenes": set(), "objects": {}, "profiles": {}, "groups": {}, "group_members": {}})


def _receipt(host, raw):
    result = host.as_dict(raw)
    if "statistics" in result:
        binding = host.modules["STATISTICAL_RESULT_SEMANTICS_API_v1"]
        result["statistics"] = {name: binding.invoke(host, "validated_result", [record])
                                for name, record in host.as_dict(result["statistics"]).items()}
    for field in ("volume", "surface_area", "value", "maximum_residual", "reference_rms", "reference_mean", "reference_max", "symmetric_rms", "hausdorff_sampled", "closest_sampled", "area_difference", "volume_difference", "distance", "rmse", "symmetric_rmse", "closest_distance", "length_difference", "max_absolute", "mean_absolute", "position", "signed_residual", "tolerance"):
        if field in result:
            result[field] = float(result[field])
    for field in ("logical_id", "cell_count", "array_count", "input_points", "contour_count", "solids", "boundary_edges", "nonmanifold_edges",
                  "orientation_conflicts", "components", "edge_count", "loop_count", "intersecting_pairs", "constraint_status", "satisfied_count", "reference_vertices", "target_vertices", "reference_samples", "target_samples", "direction", "source_vertex", "sample_index", "count_a", "count_b", "sample_budget", "size_bytes", "point_count"):
        if field in result:
            result[field] = int(result[field])
    for field in ("closed", "topology_valid", "volume_defined", "unit_known", "has_normal", "has_tangent", "edges_truncated", "loops_truncated", "truncated", "reference_tessellated", "target_tessellated", "area_supported", "closest_exact", "projection_exact_a", "projection_exact_b"):
        if field in result:
            result[field] = bool(int(result[field]))
    for field in ("origin", "u_axis", "v_axis", "transform", "world_transform", "bounds_min", "bounds_max", "world_point", "normal", "tangent", "source", "projected", "closest_source", "closest_target", "bounds_min_difference", "bounds_max_difference", "closest_a", "closest_b"):
        if field in result:
            result[field] = NumericArray([float(x) for x in host.as_list(result[field])])
    for field in ("captured_plane", "plane"):
        if field in result:
            value = host.as_dict(result[field])
            result[field] = {key: NumericArray([float(x) for x in host.as_list(item)]) for key, item in value.items()}
    if "coordinate_conversion" in result:
        conversion = host.as_dict(result["coordinate_conversion"])
        conversion["factors"] = NumericArray([float(x) for x in host.as_list(conversion["factors"])])
        conversion["source_units"] = host.as_list(conversion["source_units"])
        result["coordinate_conversion"] = conversion
    if "points" in result:
        result["points"] = [NumericArray([float(x) for x in host.as_list(p)]) for p in host.as_list(result["points"])]
    if "source_bindings" in result:
        bindings = []
        for raw_binding in host.as_list(result["source_bindings"]):
            binding = host.as_dict(raw_binding)
            for field in ("xy_resource", "gap_resource", "source_rows_resource"):
                reference = host.as_dict(binding[field]);reference["metadata"] = host.as_dict(reference["metadata"])
                reference["size_bytes"] = int(reference["size_bytes"]);binding[field] = reference
            descriptor = host.as_dict(binding["source_descriptor"])
            for field in ("row_count", "display_budget"):
                descriptor[field] = int(descriptor[field])
            for field in ("variables", "source_identities"):
                descriptor[field] = [host.as_dict(item) for item in host.as_list(descriptor[field])]
            descriptor["request"] = host.as_dict(descriptor["request"])
            binding["source_descriptor"] = descriptor;bindings.append(binding)
        result["source_bindings"] = bindings
    if "members" in result:
        result["members"] = [_receipt(host, item) for item in host.as_list(result["members"])]
    if "selected_members" in result:
        result["selected_members"] = [_receipt(host, item) for item in host.as_list(result["selected_members"])]
    if "rows" in result: result["rows"] = [_receipt(host,item) for item in host.as_list(result["rows"])]
    for field in ("section_resources", "contours"):
        if field in result: result[field] = [_receipt(host,item) for item in host.as_list(result[field])]
    for field in ("xy_resource", "metadata"):
        if field in result:
            # Resource metadata belongs to the managed-resource contract. Its
            # origin is a provenance record, not a geometric XYZ origin vector.
            result[field] = (host.as_dict(result[field]) if field == "metadata" and
                             result.get("api_id") == "INTERACTIVE_DOCUMENT_RESOURCE_API_v1"
                             else _receipt(host, result[field]))
    if "tessellation" in result: result["tessellation"] = host.as_dict(result["tessellation"])
    for field in ("member_states",):
        if field in result: result[field] = host.as_list(result[field])
    for field in ("visibility", "view"):
        if field in result: result[field] = host.as_dict(result[field])
    for field in ("selected_members",):
        if field in result: result[field] = [_receipt(host,item) for item in host.as_list(result[field])]
    for field in ("visible", "selectable", "locked"):
        if field in result: result[field] = bool(int(result[field]))
    if "opacity" in result: result["opacity"] = float(result["opacity"])
    if "edges" in result:
        result["edges"] = [[int(index) for index in host.as_list(pair)] for pair in host.as_list(result["edges"])]
    if "loops" in result:
        loops = []
        for raw_loop in host.as_list(result["loops"]):
            loop = host.as_dict(raw_loop)
            for field in ("loop_index", "vertex_count"):
                loop[field] = int(loop[field])
            loop["truncated"] = bool(int(loop["truncated"]))
            loop["source_indices"] = [int(index) for index in host.as_list(loop["source_indices"])]
            loop["world_points"] = [NumericArray([float(x) for x in host.as_list(point)]) for point in host.as_list(loop["world_points"])]
            loops.append(loop)
        result["loops"] = loops
    if "pairs" in result:
        pairs = []
        for raw_pair in host.as_list(result["pairs"]):
            pair = host.as_dict(raw_pair)
            for field in ("triangle_a", "triangle_b"):
                pair[field] = int(pair[field])
            pair["witness"] = NumericArray([float(x) for x in host.as_list(pair["witness"])])
            pairs.append(pair)
        result["pairs"] = pairs
    if "dataset_binding" in result:
        binding = host.as_dict(result["dataset_binding"])
        binding["coordinate_factor"] = float(binding["coordinate_factor"])
        binding["assumed_input_unit"] = bool(int(binding["assumed_input_unit"]))
        reference = host.as_dict(binding["source_resource"])
        reference["size_bytes"] = int(reference["size_bytes"])
        reference["metadata"] = host.as_dict(reference["metadata"])
        binding["source_resource"] = reference
        result["dataset_binding"] = binding
    return result


def invoke(host, operation, args):
    if operation not in _ARGS or len(args) != len(_ARGS[operation]):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Invalid Native3D geometry arguments")
    state = _state(host)
    if operation.startswith("planar_") or operation in {"origin_receipt", "origin_validate"}:
        return _planar_invoke(host, operation, args)
    if operation == "api_info":
        result = host.as_dict(host.call("::GX::native3DGeometryApiInfo"))
        for field in ("operations", "geometry_operations"):
            result[field] = host.as_list(result[field])
        result["raw_pointers"] = False;result["implicit_dataset_publication"] = False
        return result
    if operation == "open":
        token = str(host.call("::GX::native3DGeometryOpen", args[0]));state["scenes"].add(token);return token
    scene = args[0]
    if scene not in state["scenes"]:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Scene token is not owned by this script execution")
    if operation == "scene_info":
        result = host.as_dict(host.call("::GX::native3DGeometrySceneInfo", scene))
        result["revision"] = int(result["revision"]);result["worker_generation"] = int(result["worker_generation"])
        # Session lifetime is an authority-side guard, not a reusable script
        # credential or native-scene number.
        result.pop("session_token", None)
        return result
    if operation == "close":
        host.call("::GX::native3DGeometryClose", scene);state["scenes"].remove(scene)
        for collection in ("objects", "profiles", "groups"):
            for token, owner in list(state[collection].items()):
                if owner == scene:
                    del state[collection][token]
                    if collection == "groups":
                        state["group_members"].pop(token, None)
        return True
    if operation == "checkpoint":
        if not isinstance(args[1], dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Checkpoint payload requires a struct")
        result = host.as_dict(host.call("::GX::native3DGeometryCheckpoint", *args))
        return {"id": result["id"], "generation": result["generation"], "revision": int(result["revision"])}
    if operation == "export_resource":
        if state["objects"].get(args[1]) != scene:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Object token is not owned by this scene/execution")
        result = host.as_dict(host.call("::GX::native3DGeometryExportResource", *args))
        result["size_bytes"] = int(result["size_bytes"])
        result["metadata"] = host.as_dict(result["metadata"])
        for field in ("bounds_min", "bounds_max", "transform"):
            if field in result["metadata"]:
                result["metadata"][field] = NumericArray([float(x) for x in host.as_list(result["metadata"][field])])
        return result
    if operation in ("profile_resources", "profile_view_resource"):
        if state["profiles"].get(args[1]) != scene:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Profile token is not owned by this scene/execution")
        command = "::GX::native3DGeometryProfileResources" if operation == "profile_resources" else "::GX::native3DGeometryProfileViewResource"
        if operation == "profile_view_resource":
            result = host.as_dict(host.call(command, *args));result["size_bytes"] = int(result["size_bytes"]);result["metadata"] = host.as_dict(result["metadata"])
            return result
        return _receipt(host, host.call(command, *args))
    if operation == "convert_axes":
        if state["objects"].get(args[1]) != scene:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Object token is not owned by this scene/execution")
        raw = host.call("::GX::native3DGeometryConvertAxes", *args)
    elif operation == "import_dataset":
        raw = host.call("::GX::native3DGeometryImportDataset", *args)
    elif operation == "profile_from_sources":
        sources = args[1]
        if not isinstance(sources, (list, tuple)) or not isinstance(args[2], dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Source profiles require source structs and an explicit plane")
        owned_sources = host.handles.get("curve_source", {}).get("sources", set())
        for source in sources:
            if not isinstance(source, dict) or source.get("source_token") not in owned_sources:
                raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Profile source is not owned by this execution")
        raw = host.call("::GX::native3DGeometryProfileFromSources", *args)
    else:
        request = args[1]
        if not isinstance(request, dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Geometry request must be a struct")
        def validate_references(value, depth=0):
            if depth > 16:
                raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Geometry request is too deeply nested")
            if isinstance(value, dict):
                for field, item in value.items():
                    if field in ("object_token", "surface_object_token", "base", "tool", "profile_token", "group_token"):
                        collection = "profiles" if field == "profile_token" else "groups" if field == "group_token" else "objects"
                        if state[collection].get(item) != scene:
                            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Nested geometry reference is not owned by this scene/execution")
                    else:
                        validate_references(item, depth+1)
            elif isinstance(value, (list, tuple)):
                for item in value:
                    validate_references(item, depth+1)
        validate_references(request)
        for token in request.get("object_tokens", []):
            if state["objects"].get(token) != scene:
                raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Grouped object is not owned by this scene/execution")
        for field in ("object_token", "base", "tool", "profile_token", "group_token"):
            if field in request:
                collection = "profiles" if field == "profile_token" else "groups" if field == "group_token" else "objects"
                if state[collection].get(request[field]) != scene:
                    raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Geometry token is not owned by this scene/execution")
        raw = host.call("::GX::native3DGeometryCall", scene, operation, request)
        if operation in ("delete", "profile_delete", "group_delete"):
            collection = "profiles" if operation == "profile_delete" else "groups" if operation == "group_delete" else "objects"
            token = request[{"profiles": "profile_token", "groups": "group_token", "objects": "object_token"}[collection]]
            del state[collection][token]
            if collection == "groups":
                for member in state["group_members"].pop(token, []):
                    state["objects"].pop(member, None)
            return True
    if operation in ("selection_set_list", "layer_list", "saved_view_list"):
        return [_receipt(host,item) for item in host.as_list(raw)]
    result = _receipt(host, raw)
    for field, collection in (("object_token", "objects"), ("profile_token", "profiles"), ("group_token", "groups")):
        if field in result:
            state[collection][result[field]] = scene
    if "group_token" in result:
        members = [item["object_token"] for item in result["members"]]
        state["group_members"][result["group_token"]] = members
        for member in members:
            state["objects"][member] = scene
    return result


def cleanup(host):
    for token in list(_state(host).get("planar_edits", {})):
        invoke(host, "planar_edit_cancel", [token])
    for scene in list(_state(host)["scenes"]):
        invoke(host, "close", [scene])
