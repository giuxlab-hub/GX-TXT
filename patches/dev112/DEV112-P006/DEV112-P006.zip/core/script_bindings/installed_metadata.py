"""Inert installed-service metadata through its existing CORE owners."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATIONS = [
    {"api_id": api, "api_version": 1, "provider_kind": "core", "provider_id": provider,
     "documentation_ref": "docs/api/" + api + ".md", "operations": {
         operation: {"name": operation, "summary": summary, "arguments": [],
                     "host_command": command, "argument_convention": "no arguments",
                     "result_contract": result}}}
    for api, provider, operation, command, summary, result in (
        ("FRAMEWORK_MAINTENANCE_API_v1", "framework_maintenance", "modules_inventory", "::GX::frameworkMaintenanceModulesInventory",
         "Read installed Module operational metadata without changing enablement", "ordered Module identity/version/state/flags/dependency records"),
        ("STDERR_DIAGNOSTICS_API_v1", "stderr_diagnostics", "info", "::GX::stderrDiagnostics",
         "Read inert diagnostic API schema without capture or collector access", "fixed API identity, payload bounds, defaults and operation names"),
    )
]


def invoke_api(host, api_id, operation, args):
    if args:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Installed metadata takes no arguments")
    if api_id == "FRAMEWORK_MAINTENANCE_API_v1" and operation == "modules_inventory":
        result = []
        for raw in host.as_list(host.call("::GX::frameworkMaintenanceModulesInventory")):
            row = host.as_dict(raw)
            for key in ("core_protected", "always_available", "analysis_enableable", "run_eligible", "enabled", "optional"):
                row[key] = bool(host.tcl.getboolean(row[key]))
            row["depends"] = [str(value) for value in host.as_list(row["depends"])]
            result.append(row)
        return result
    if api_id == "STDERR_DIAGNOSTICS_API_v1" and operation == "info":
        result = host.as_dict(host.call("::GX::stderrDiagnostics", "info"))
        result["api_version"] = int(result["api_version"])
        result["max_payload_bytes"] = int(result["max_payload_bytes"])
        result["config_defaults"] = {str(key): int(value) for key, value in host.as_dict(result["config_defaults"]).items()}
        result["operations"] = [str(value) for value in host.as_list(result["operations"])]
        return result
    raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", "No host administration or diagnostic capture operation is registered")
