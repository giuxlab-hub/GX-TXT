"""Typed inert metadata from the existing compiled Native2D/Native3D owners.

Only fixed value/POD functions are adapted here. No client supplies a library,
path, symbol name, address, callback, native context, or allocation to release.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import ctypes
from functools import lru_cache
import math
from pathlib import Path
import sys

from gxtxt_script_bridge_server import BridgeError

_ROOT = Path(__file__).resolve().parents[2]


class _EngineInfo(ctypes.Structure):
    _fields_ = [('struct_size', ctypes.c_uint32), ('abi_version', ctypes.c_uint32),
                ('capabilities', ctypes.c_uint64), ('reserved', ctypes.c_uint64 * 4)]


class _CapabilitySet(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint32) for name in
                ('struct_size', 'api_group', 'api_version', 'word_count')] + [
                ('words', ctypes.c_uint64 * 4), ('reserved', ctypes.c_uint64 * 4)]


class _ImageInfo(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint32) for name in
                ('struct_size', 'component_count', 'bits_per_component',
                 'alpha_convention', 'transfer', 'png_transfer', 'png_color_tag')] + [
                ('component_order', ctypes.c_char * 8), ('reserved', ctypes.c_uint64 * 4)]


@lru_cache(maxsize=3)
def _library(owner):
    # Filenames are fixed distribution-owned artifacts, never client inputs.
    names = {
        'native2d': ('core/native2d/bin/gx2dtcl.so', 'core/native2d/bin/gx2dtcl.dll'),
        'engine': ('core/native3d/lib/libgx3de.so', 'core/native3d/lib/gx3de.dll'),
        'legacy': ('plugins/modules/viewer.native_3d/lib/libgx3d.so',
                   'plugins/modules/viewer.native_3d/lib/gx3d.dll'),
    }
    path = _ROOT / names[owner][1 if sys.platform == 'win32' else 0]
    try:
        library = ctypes.CDLL(str(path))
        if owner == 'native2d':
            library.gx2d_status_text.argtypes = [ctypes.c_int32]
            library.gx2d_status_text.restype = ctypes.c_char_p
        elif owner == 'legacy':
            library.gx3d_abi_version.argtypes = []
            library.gx3d_abi_version.restype = ctypes.c_uint32
            library.gx3d_version_utf8.argtypes = []
            library.gx3d_version_utf8.restype = ctypes.c_char_p
        else:
            library.gx3de_get_info.argtypes = [ctypes.POINTER(_EngineInfo)]
            library.gx3de_get_info.restype = ctypes.c_int32
            library.gx3de_get_capabilities.argtypes = [ctypes.c_uint32, ctypes.POINTER(_CapabilitySet)]
            library.gx3de_get_capabilities.restype = ctypes.c_int32
            library.gx3de_result_name.argtypes = [ctypes.c_int32]
            library.gx3de_result_name.restype = ctypes.c_char_p
            library.gx3de_image_output_info_get.argtypes = [ctypes.POINTER(_ImageInfo)]
            library.gx3de_image_output_info_get.restype = ctypes.c_int32
    except (OSError, AttributeError) as exc:
        raise BridgeError('GXTXT:ScriptBridge:Dependency',
                          'Installed native metadata runtime is unavailable') from exc
    return library


def _int32(value):
    # Octave's ordinary numeric scalar is binary64; accept exact integral values.
    if (isinstance(value, bool) or not isinstance(value, (int, float)) or
            (isinstance(value, float) and (not math.isfinite(value) or value != math.trunc(value))) or
            not -(2**31) <= value < 2**31):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'An exact signed 32-bit code is required')
    return int(value)


def _check(result):
    if result:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native metadata request was refused')


def _record(value):
    # Keep capability words as exact integers through the shared integer transport.
    return {name: ([int(item) for item in getattr(value, name)] if name in ('words', 'reserved')
                   else bytes(getattr(value, name)).decode('utf-8') if name == 'component_order'
                   else int(getattr(value, name))) for name, _ in value._fields_}


def native2d_status_text(code):
    """Native2D's exact enum spelling, including its unknown-code fallback."""
    return _library('native2d').gx2d_status_text(_int32(code)).decode('utf-8')


def legacy_metadata(operation, args):
    """Called only by the legacy module-owned registration of these two methods."""
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native library metadata takes no arguments')
    if operation == 'gx3d_abi_version':
        return int(_library('legacy').gx3d_abi_version())
    if operation == 'gx3d_version_utf8':
        return _library('legacy').gx3d_version_utf8().decode('utf-8')
    raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown native library metadata operation')


_ARGUMENTS = {'gx3de_get_info': [], 'gx3de_get_capabilities': [('api_group', 'integer in 1..4')],
              'gx3de_result_name': [('result', 'signed 32-bit integer')], 'gx3de_image_output_info_get': []}
REGISTRATION = {
    'api_id': 'NATIVE_3D_ENGINE_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'native3d_geometry',
    'documentation_ref': 'docs/api/NATIVE_3D_ENGINE_API_v1.md',
    'operations': {operation: {'name': operation,
        'summary': 'Read compiled Native3D owner metadata: '+operation,
        'arguments': [{'name': name, 'kind': kind, 'required': True} for name, kind in arguments],
        'argument_convention': ', '.join(name for name, _ in arguments) or 'no arguments',
        'result_contract': 'Native owner UTF-8 result spelling' if operation == 'gx3de_result_name'
                           else 'Native owner POD metadata with exact uint64 capability words'}
        for operation, arguments in _ARGUMENTS.items()},
}


def invoke(host, operation, args):
    if operation not in _ARGUMENTS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown native metadata operation')
    if len(args) != len(_ARGUMENTS[operation]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid native metadata argument count')
    # Validate codes before loading a compiled artifact.
    code = _int32(args[0]) if args else None
    if operation == 'gx3de_get_capabilities' and code not in (1, 2, 3, 4):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native API group must be in 1..4')
    library = _library('engine')
    if operation == 'gx3de_result_name':
        return library.gx3de_result_name(code).decode('utf-8')
    if operation == 'gx3de_get_info':
        info = _EngineInfo();info.struct_size = ctypes.sizeof(info)
        _check(library.gx3de_get_info(ctypes.byref(info)))
    elif operation == 'gx3de_get_capabilities':
        info = _CapabilitySet();info.struct_size = ctypes.sizeof(info)
        _check(library.gx3de_get_capabilities(code, ctypes.byref(info)))
    else:
        info = _ImageInfo();info.struct_size = ctypes.sizeof(info)
        _check(library.gx3de_image_output_info_get(ctypes.byref(info)))
    return _record(info)
