"""Interpreter-owned Native2D sprite diagnostic control, without a Canvas."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    'api_id': 'NATIVE2D_SPRITE_SCENE_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'native2d_sprite_scene',
    'documentation_ref': 'docs/api/NATIVE2D_SPRITE_SCENE_API_v1.md',
    'operations': {'diagnostics': {
        'name': 'diagnostics', 'summary': 'Read/control only this interpreter native diagnostic counters',
        'arguments': [{'name': 'operation', 'kind': 'on/off/reset/get', 'required': True}],
        'result_contract': 'Native phase calls/us/points/bytes or acknowledgement; no Canvas/scene/pointer',
    }},
}


def invoke(host, operation, args):
    if operation != 'diagnostics' or len(args) != 1 or not isinstance(args[0], str) or args[0] not in ('on', 'off', 'reset', 'get'):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Choose exactly one native diagnostic mode: on/off/reset/get')
    raw = host.call('::GX::native2DSpriteSceneDiagnostics', args[0])
    if args[0] != 'get':
        return {'operation': args[0], 'applied': True}
    return {str(phase): {key: int(value) for key, value in host.as_dict(row).items()}
            for phase, row in host.as_dict(raw).items()}
