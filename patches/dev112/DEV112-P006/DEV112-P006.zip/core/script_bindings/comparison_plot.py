"""Closed original Comparison source, Numeric preparation and PlotSpec routes."""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
import uuid
from gxtxt_script_bridge_server import BridgeError, NumericArray

_ARGS={'source_dataset':['dataset_id','x_variable_id','y_variable_id'],
       'source_library':['library_id','entry_id'], 'validate':['configuration'],
       'prepare':['configuration'], 'spec':['configuration']}
REGISTRATION={
    'api_id':'COMPARISON_PLOT_API_v1','api_version':1,
    'provider_kind':'core','provider_id':'comparison_plot',
    'documentation_ref':'docs/api/COMPARISON_PLOT_API_v1.md',
    'operations':{op:{'name':op,'summary':'Original Comparison owner: '+op,
        'arguments':[{'name':arg,'kind':'public value','required':True} for arg in args],
        'result_contract':'Execution-owned source capture, original validation, bounded derived display or original PlotSpec; no native event command or publication'}
        for op,args in _ARGS.items()}}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)


def _text(host,value):
    return str(host.tcl.call('format','%s',value))


def _state(host):
    return host.handles.setdefault('comparison_plot_sources',{})


def _session(host):
    return _text(host,host.call('::GX::interactiveDocumentSessionToken'))


def _dataset_stamp(host,dataset):
    return tuple(_text(host,host.call(command,*args)) for command,args in [
        ('::GX::datasetRevisionToken',(dataset,)),
        ('::GX::datasetCoordinateRead',(host.session,dataset)),
        ('::GX::datasetViewerScientificIdentity',(dataset,))])


def _summary(host,raw):
    fields={'kind','dataset_id','x_variable_id','y_variable_id','library_id','entry_id',
            'sha256','schema_sha256','semantic_sha256','revision','x_unit','y_unit','label'}
    result={k:_text(host,v) for k,v in host.as_dict(raw).items() if k in fields}
    result['sample_count']=int(host.as_dict(raw)['sample_count'])
    for key in ('x_meaning','y_meaning'):
        result[key]={k:_text(host,v) for k,v in host.as_dict(host.as_dict(raw)[key]).items()}
    return result


def _current(host,record):
    if _session(host)!=record['session']:
        raise BridgeError('GXTXT:ScriptBridge:StaleInput','Comparison source belongs to an earlier Session lifetime')
    host.call('::GX::_comparisonPlotCurrent',record['raw'])
    if record['dataset'] is not None and _dataset_stamp(host,record['dataset'])!=record['stamp']:
        raise BridgeError('GXTXT:ScriptBridge:StaleInput','Comparison canonical source, coordinates or namespace changed')


def _source(host,operation,args):
    if any(not isinstance(v,str) or not 1<=len(v.encode('utf-8'))<=512 or '\0' in v for v in args):
        _invalid('Comparison sources require bounded literal canonical identities')
    if len(_state(host))>=32:_invalid('At most32 captured Comparison sources per execution')
    session=_session(host);dataset=args[0] if operation=='source_dataset' else None
    stamp=_dataset_stamp(host,dataset) if dataset else None
    command='::GX::comparisonPlotSourceDataset' if dataset else '::GX::comparisonPlotSourceLibrary'
    raw=host.call(command,*args)
    record={'raw':raw,'session':session,'dataset':dataset,'stamp':stamp}
    _current(host,record)
    handle='comparison-source-'+uuid.uuid4().hex
    _state(host)[handle]=record
    return {'source':handle,**_summary(host,raw)}


def _configuration(host,value):
    allowed={'sources','mode','normalization','offset','denominator_floor','interpolation','domain','single_source_consultation'}
    if not isinstance(value,dict) or set(value)-allowed or not {'sources','mode'}<=set(value):
        _invalid('Comparison accepts only declared options and captured source handles')
    sources=value['sources']
    if not isinstance(sources,list) or not 1<=len(sources)<=8 or any(not isinstance(s,str) or s not in _state(host) for s in sources):
        _invalid('Choose1..8 source handles owned by this execution')
    for key in ('mode','normalization','interpolation','domain'):
        if key in value and (not isinstance(value[key],str) or len(value[key])>64):
            _invalid('Comparison method options require bounded literal text')
    for key in ('offset','denominator_floor'):
        if key in value and (isinstance(value[key],bool) or not isinstance(value[key],(int,float)) or not math.isfinite(value[key])):
            _invalid('Comparison offsets/floors require finite numeric scalars')
    if 'single_source_consultation' in value and not isinstance(value['single_source_consultation'],bool):
        _invalid('Single-source consultation requires an explicit boolean')
    records=[_state(host)[s] for s in sources]
    for record in records:_current(host,record)
    if sum(int(host.as_dict(r['raw'])['sample_count']) for r in records)>65536:
        _invalid('Shared Comparison transport admits at most65536 total source samples; no truncation')
    result=dict(value,schema='GXTXT_COMPARISON_PLOT_v1',sources=[r['raw'] for r in records])
    return result,records


def _receipt(host,raw,records):
    d=host.as_dict(raw)
    result={k:_text(host,v) for k,v in d.items() if k not in {'configuration','sources'}}
    for key in ('invalid_samples',):result[key]=int(d[key])
    for key in ('extrapolation','scientific_identification','canonical_values_modified'):
        result[key]=bool(host.tcl.getboolean(d[key]))
    result['display_offset_step']=float(d['display_offset_step'])
    result['sources']=[_summary(host,r['raw']) for r in records]
    return result


def _model(host,raw):
    model=host.as_dict(raw);panels=[]
    for raw_panel in host.as_list(model['panels']):
        panel=host.as_dict(raw_panel);traces=[]
        for raw_trace in host.as_list(panel['series']):
            trace=host.as_dict(raw_trace)
            points=[host.as_list(p) for p in host.as_list(trace['points'])]
            values=[float(p[c]) for c in range(2) for p in points]
            traces.append({k:_text(host,trace[k]) for k in ('id','label','kind','axis','point_identity_kind')})
            traces[-1].update(points=NumericArray(values,[len(points),2]),row_count=int(trace['row_count']),
                              style={k:_text(host,v) for k,v in host.as_dict(trace['style']).items()})
        panels.append({'id':_text(host,panel['id']),'title':_text(host,panel['title']),
                       'axes':{k:{f:_text(host,v) for f,v in host.as_dict(axis).items()} for k,axis in host.as_dict(panel['axes']).items()},
                       'series':traces})
    return {'title':_text(host,model['title']),'panels':panels,
            'shared_x_interaction':bool(host.tcl.getboolean(model['shared_x_interaction'])),
            'display_is_scientific_data':False}


def invoke(host,operation,args):
    if operation not in _ARGS or len(args)!=len(_ARGS[operation]):
        _invalid('Use the declared Comparison operation arguments')
    if operation.startswith('source_'):return _source(host,operation,args)
    configuration,records=_configuration(host,args[0])
    command={'validate':'comparisonPlotValidate','prepare':'comparisonPlotPrepare','spec':'comparisonPlotSpec'}[operation]
    raw=host.call('::GX::'+command,configuration)
    for record in records:_current(host,record)
    if operation=='validate':
        d=host.as_dict(raw)
        return {'valid':bool(host.tcl.getboolean(d['valid'])),'source_count':int(d['source_count']),
                'mode':_text(host,d['mode']),'canonical_values_modified':bool(host.tcl.getboolean(d['canonical_values_modified']))}
    if operation=='prepare':
        d=host.as_dict(raw)
        return {'model':_model(host,d['model']),'receipt':_receipt(host,d['receipt'],records)}
    # Original persistent PlotSpec/source pins remain intact. This is ordinary
    # data, with no renderer, native event receiver, Workspace or write grant.
    return host.normalize(raw)


def cleanup(host):
    host.handles.pop('comparison_plot_sources',None)
