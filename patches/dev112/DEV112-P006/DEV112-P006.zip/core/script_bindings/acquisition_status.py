"""Read the original Acquisition observer in this interpreter only.

This does not observe a separate GUI/admitting process or authorize Dataset work.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    'api_id': 'ACQUISITION_HANDLER_PLUGIN_API_v1',
    'api_version': 1,
    'provider_kind': 'core',
    'provider_id': 'CORE',
    'documentation_ref': 'docs/api/ACQUISITION_HANDLER_PLUGIN_API_v1.md',
    'operations': {
        'acquisitionHandlerAuthorityBusy': {
            'name': 'acquisitionHandlerAuthorityBusy',
            'summary': 'Read interpreter-local Acquisition activity for the runtime Session.',
            'arguments': [],
            'result_contract': (
                'Logical Boolean from the original observer in this same Host interpreter, '
                'bound to its current runtime Session. Instantaneous advisory value only; '
                'neither a separate GUI status nor Dataset mutation/lock authority.'),
        },
    },
}


def _context(host):
    if not host.session:
        raise BridgeError('GXTXT:ScriptBridge:Ownership',
                          'Acquisition status requires the runtime Session')
    session = str(host.call('file', 'normalize', host.session))
    current = str(host.call('set', '::GX::currentSession'))
    if (not current or not host.tcl.getboolean(host.call('file', 'isdirectory', session))
            or str(host.call('file', 'normalize', current)) != session):
        raise BridgeError('GXTXT:ScriptBridge:Ownership',
                          'Acquisition status requires the same current runtime Session')
    token = str(host.call('::GX::interactiveDocumentSessionToken'))
    return session, token


def invoke(host, operation, args):
    if operation != 'acquisitionHandlerAuthorityBusy' or args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',
                          'Acquisition status accepts no arguments')
    held = _context(host)
    value = host.call('::GX::acquisitionHandlerAuthorityBusy', held[0])
    if _context(host) != held:
        raise BridgeError('GXTXT:ScriptBridge:StaleInput',
                          'The Acquisition status Session generation changed during the call')
    return bool(host.tcl.getboolean(value))
