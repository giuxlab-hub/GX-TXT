"""Inert Viewer interface models through the existing GUI/schema owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_OPERATIONS = {
    'icon_catalog': ('viewerGuiIconCatalog', []),
    'component_capabilities': ('viewerGuiComponentCapabilities', []),
    'preview_component_types': ('viewerGuiPreviewComponentTypes', [('design','struct',True)]),
    'numeric_preview_new': ('viewerGuiDesignNumericPreviewNew', [('title','string',False)]),
    'design_new': ('viewerGuiDesignNew', [('title','string',False)]),
    'model_navigate': ('viewerGuiDesignModelNavigate', [('model','struct',True),('direction','string',True)]),
    'visibility_commands': ('viewerGuiDesignVisibilityCommands', [('design','struct',True)]),
    'raster_tool_bindings': ('viewerGuiDesignRasterToolBindings', [('design','struct',True)]),
    'diagram_tool_bindings': ('viewerGuiDesignDiagramToolBindings', [('design','struct',True)]),
    'component_initial_properties': ('viewerGuiComponentInitialProperties', [('type','string',True),('design','struct',False)]),
    'scenario_validate': ('viewerGuiScenarioValidate', [('scenario','struct',True)]),
    'document_compatible': ('viewerGuiDocumentCompatible', [('dataset_id','string',True),('content_kind','string',True)]),
    'scientific_binding_summary': ('viewerGuiScientificBindingSummary', [('binding','struct',True)]),
    'manifest_validate': ('viewerGuiManifestValidate', [('manifest','closed inert manifest with empty handlers',True)]),
}
REGISTRATION = {
    'api_id':'VIEWER_GUI_HOST_API_v1','api_version':1,
    'provider_kind':'core','provider_id':'viewer_gui_host',
    'documentation_ref':'docs/api/VIEWER_GUI_HOST_API_v1.md',
    'operations':{name:{
        'name':name,'summary':'Existing inert Viewer GUI model operation: '+name,
        'host_command':'::GX::'+command,
        'arguments':[{'name':field,'kind':kind,'required':required} for field,kind,required in fields],
        'argument_convention':', '.join(field for field,_,_ in fields) or 'no arguments',
        'result_contract':'owner-declared typed inert interface model or metadata; no widgets, files, callback invocation, source generation or replay',
    } for name,(command,fields) in _OPERATIONS.items()},
}


def _typed(host, raw):
    # Existing declared Workspace tags decide every kind, including empty
    # arrays. Tcl cache/internal representations never decide scientific types.
    return host.modules['PRINT_DOCUMENT_API_v1']._shape_value(host,raw)


def _design(host, raw):
    values=host.as_dict(raw)
    preview=values.get('preview')
    if preview is not None:
        # The established Workspace design shape covers Viewer interfaces;
        # the Preview factory additionally declares this finite metadata map.
        raw=host.tcl.call('dict','remove',raw,'preview')
    result=_typed(host,host.call('::GX::viewerGuiWorkspaceEncode',{'design':raw}))['design']
    if preview is not None:
        fields=host.as_dict(preview)
        result['preview']={str(key):str(value) for key,value in fields.items()}
        if 'dataset_contracts' in fields:
            result['preview']['dataset_contracts']=[str(value) for value in host.as_list(fields['dataset_contracts'])]
    return result


def _capabilities(host, raw):
    result={}
    for name,value in host.as_dict(raw).items():
        row=host.as_dict(value)
        row['api_version']=int(row['api_version'])
        row['properties']=host.as_dict(row['properties'])
        for key in ('events','supported_parents'):
            if key in row:row[key]=[str(value) for value in host.as_list(row[key])]
        for key in ('default_properties','canvas_mode','scope_contract','demo'):
            if key not in row:continue
            fields=host.as_dict(row[key])
            if key=='scope_contract':
                fields['dimensions']=[str(value) for value in host.as_list(fields['dimensions'])]
                for count in ('max_ids_per_dimension','max_utf8_json_bytes'):fields[count]=int(fields[count])
            if key=='canvas_mode':fields['multiple_instances']=bool(host.tcl.getboolean(fields['multiple_instances']))
            if key=='demo':fields['fixture_version']=int(fields['fixture_version'])
            row[key]=fields
        result[str(name)]=row
    return result



REGISTRATION['operations']['api_info'] = {
    'name': 'api_info', 'summary': 'Read the complete original owner discovery metadata',
    'host_command': '::GX::viewerGuiHostApiInfo', 'arguments': [], 'argument_convention': 'no arguments',
    'result_contract': 'complete owner dictionary with explicit nested dictionaries, ordered text arrays, integer versions/limits and logical metadata flags; command names are inert data',
}


def _api_info_map(host, raw, lists=(), flags=(), integers=()):
    # Fixed owner-declared metadata shapes; command names remain inert text.
    result = {str(key): str(host.tcl.call('format', '%s', value)) for key, value in host.as_dict(raw).items()}
    for key in lists:
        result[key] = [str(value) for value in host.as_list(result[key])]
    for key in flags:
        result[key] = bool(host.tcl.getboolean(result[key]))
    for key in integers:
        result[key] = int(result[key])
    return result


def _icon_catalog(host, raw):
    source = host.as_dict(raw)
    result = _api_info_map(host, raw, integers=('count',))
    result['icons'] = {
        str(identifier): _api_info_map(host, row, integers=('width', 'height'))
        for identifier, row in host.as_dict(source['icons']).items()
    }
    return result


def _api_info(host):
    result = _api_info_map(host, host.call('::GX::viewerGuiHostApiInfo'),
                           ('operations', 'design_operations', 'scientific_probe_analyses', 'diagram_tool_property', 'transform_form_commands', 'transform_form_arguments', 'laboratory_operations', 'pcb_source_form_commands'),
                           ('host_only', 'transform_form_implicit_execution', 'pcb_source_form_implicit_import', 'pcb_source_form_native_projection'), ('api_version',))
    result['owners'] = _api_info_map(host, result['owners'], ('canvas',))
    result['scientific_probe_optional_context'] = _api_info_map(host, result['scientific_probe_optional_context'], ('point',))
    result['native2d_canvas'] = _api_info_map(host, result['native2d_canvas'], ('commands',), ('multiple_instances',))
    result['document_extraction'] = _api_info_map(host, result['document_extraction'], ('commands', 'source_guards', 'services'), ('asynchronous', 'original_viewers_unchanged'))
    result['markdown_document'] = _api_info_map(host, result['markdown_document'], ('commands',))
    result['library_browser'] = _api_info_map(host, result['library_browser'], ('pages', 'host_focus_arguments'), ('implicit_publication', 'secrets_in_workspace'))
    result['script_bridge'] = _api_info_map(host, result['script_bridge'], flags=('generic_api_operation_whitelist',))
    result['native_jobs'] = _api_info_map(host, result['native_jobs'])
    return result

def invoke(host, operation, args):
    if operation == 'api_info':
        if args:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Metadata requires no arguments')
        return _api_info(host)
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
    command,fields=_OPERATIONS[operation]
    if not sum(required for _,_,required in fields)<=len(args)<=len(fields):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Invalid inert Viewer model argument count')
    for (field,kind,_),value in zip(fields,args):
        if (kind=='struct' or operation=='manifest_validate') and not isinstance(value,dict) or kind=='string' and not isinstance(value,str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',field+' must be '+kind)
    if operation=='manifest_validate':
        manifest=args[0]
        allowed={'schema','viewer_id','provider_id','window','title','handlers','geometry','inspector_width','toolbar_mode','help'}
        if set(manifest)-allowed or not isinstance(manifest.get('handlers'),dict) or manifest['handlers']:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Inert manifest requires empty handlers and admits no callback, guard, mount, Workspace or History fields')
        for key in ('schema','viewer_id','provider_id','window','title','geometry','toolbar_mode'):
            if key in manifest and not isinstance(manifest[key],str):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Inert manifest text fields must be scalar strings')
        if 'help' in manifest and not isinstance(manifest['help'],bool):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Inert manifest help must be boolean')
    raw=host.call('::GX::'+command,*args)
    if operation=='icon_catalog':return _icon_catalog(host,raw)
    if operation=='manifest_validate':return args[0]
    if operation=='document_compatible':return bool(host.tcl.getboolean(raw))
    if operation=='scientific_binding_summary':
        result=host.as_dict(raw)
        for key in ('revision','component_count','wire_count','source_count','panels','series','model_crc32'):
            if key in result:result[key]=int(result[key])
        if 'prepared_model' in result:result['prepared_model']=bool(host.tcl.getboolean(result['prepared_model']))
        if 'dataset_sha256' in result:result['dataset_sha256']=host.as_dict(result['dataset_sha256'])
        if 'source' in result:result['source']=args[0]['source']
        if 'source_pins' in result:result['source_pins']=args[0]['spec']['comparison']['sources']
        return result
    if operation=='component_capabilities':return _capabilities(host,raw)
    if operation in {'design_new','numeric_preview_new'}:return _design(host,raw)
    if operation=='preview_component_types':return [str(value) for value in host.as_list(raw)]
    if operation=='visibility_commands':return {str(key):str(value) for key,value in host.as_dict(raw).items()}
    if operation in {'raster_tool_bindings','diagram_tool_bindings'}:
        return {str(key):[str(value) for value in host.as_list(pair)] for key,pair in host.as_dict(raw).items()}
    if operation=='scenario_validate':
        # Validation returns the same inert scenario; preserve caller's exact
        # typed values rather than parse arbitrary action payload text.
        return args[0]
    if operation=='component_initial_properties':
        design=host.call('::GX::viewerGuiDesignNew')
        component={'id':'inert_properties','type':args[0],'parent':'canvas','properties':raw,'layout':{}}
        design=host.tcl.call('dict','replace',design,'components',host.tcl_arg([component]))
        return _design(host,design)['components'][0]['properties']
    if operation=='model_navigate':
        model=host.as_dict(raw)
        for key in ('design','saved'):
            if key in model:model[key]=_design(host,model[key])
        for key in ('past','future'):model[key]=[_design(host,value) for value in host.as_list(model[key])]
        model['revision']=int(model['revision'])
        return model
    raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)


# Additional original data-only authoring operations. Existing routes above
# and their authority remain unchanged; full ModelEdit selectors are forwarded.
from gxtxt_design_values_v1 import declarations as _design_declarations, design as _design_value
_NEW_DESIGN_OPERATIONS = _design_declarations()
REGISTRATION['operations'].update(_NEW_DESIGN_OPERATIONS)
_previous_design_invoke = invoke

def invoke(host, operation, args):
    if operation in _NEW_DESIGN_OPERATIONS:
        return _design_value(host, operation, args)
    return _previous_design_invoke(host, operation, args)
