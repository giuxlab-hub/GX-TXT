"""Read and candidate-analysis binding owned by Scientific Reference Library API."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray

_OPERATIONS = {
    "list_libraries": ("List installed reference library IDs", [], "cell of library IDs"),
    "library_info": ("Read versioned library metadata", [("library_id", "string")], "library struct"),
    "list_entities": ("List library entity IDs", [("library_id", "string")], "cell of entity IDs"),
    "entity_info": ("Read entity metadata", [("library_id", "string"), ("entity_id", "string")], "entity struct"),
    "list_spectra": ("List library spectrum IDs", [("library_id", "string"), ("entity_id", "optional string")], "cell of spectrum IDs"),
    "spectrum_info": ("Read spectrum metadata", [("library_id", "string"), ("spectrum_id", "string")], "spectrum struct"),
    "read_spectrum": ("Read stable scientific X/Y arrays", [("library_id", "string"), ("spectrum_id", "string")], "spectrum struct with numeric vectors"),
    "search": ("Search reference identifiers and metadata", [("library_id", "string"), ("query", "string")], "cell of spectrum IDs"),
    "bulk_rank": ("Prescreen reference spectra against processed data", [("library_id", "string"), ("experimental", "spectrum struct"), ("options", "struct")], "candidate ranking struct"),
    "managed_library_info": ("Read package-admitted managed Reference metadata", [("library_id","string")], "managed/scientific version and integrity metadata"),
    "managed_validate": ("Validate registered managed Reference content", [("library_id","string")], "source-owned scientific validation receipt"),
    "managed_list_spectra": ("List admitted managed Reference spectra", [("library_id","string"),("entity_id","optional string")], "ordered spectrum IDs"),
    "managed_entity_info": ("Read admitted managed Reference entity metadata", [("library_id","string"),("entity_id","string")], "scientific entity metadata"),
    "managed_read_spectrum": ("Read validated managed Reference scientific samples", [("library_id","string"),("spectrum_id","string")], "scientific spectrum with typed binary64 X/Y"),
    "managed_bulk_rank": ("Invoke existing managed Reference prescreen owner", [("library_id","string"),("experimental","spectrum struct"),("options","struct")], "source-owned bounded candidate ranking"),
}
_MANAGED_COMMANDS={
    'managed_library_info':'managedLibraryInfo','managed_validate':'managedValidateLibrary',
    'managed_list_spectra':'managedListSpectra','managed_entity_info':'managedEntityInfo',
    'managed_read_spectrum':'managedReadSpectrum','managed_bulk_rank':'managedBulkRank'}
REGISTRATION = {
    "api_id": "SCIENTIFIC_REFERENCE_LIBRARY_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "scientific_reference_library",
    "documentation_ref": "docs/api/SCIENTIFIC_REFERENCE_LIBRARY_API_v1.md",
    "operations": {name: {"name": name, "summary": summary,
                          "arguments": [{"name": label, "kind": kind, "required": not kind.startswith("optional")}
                                        for label, kind in arguments],
                          "result_contract": result,
                          "argument_convention": ", ".join(label for label, _ in arguments) or "no arguments",
                          "result_convention": result}
                   for name, (summary, arguments, result) in _OPERATIONS.items()},
}

for _operation,_command in _MANAGED_COMMANDS.items():
    REGISTRATION['operations'][_operation]['host_command']='::GX::ReferenceLibraryAPIv1::'+_command


def invoke(host, operation, args):
    schema = _OPERATIONS.get(operation)
    if schema is None:
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", f"unknown reference operation {operation}")
    arguments = schema[1]
    if not sum(not kind.startswith("optional") for _, kind in arguments) <= len(args) <= len(arguments):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", f"{operation} has invalid argument count")
    prefix = "::GX::ReferenceLibraryAPIv1::"
    commands = {"list_libraries": "listLibraries", "library_info": "libraryInfo",
                "list_entities": "listEntities", "entity_info": "entityInfo",
                "list_spectra": "listSpectra", "spectrum_info": "spectrumInfo",
                "read_spectrum": "readSpectrum", "search": "search", "bulk_rank": "bulkRank"}
    commands.update(_MANAGED_COMMANDS)
    if operation in _MANAGED_COMMANDS:
        import re
        for index,(_,kind) in enumerate(arguments[:len(args)]):
            if kind=='optional string' and args[index]=='':continue
            if kind in {'string','optional string'} and (not isinstance(args[index],str) or
                not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,127}',args[index])):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Managed Reference requires bounded stable identity strings')
        if operation=='managed_bulk_rank':
            allowed={'experimental_representation','range_min','range_max','normalization','step','method','fingerprint_min','fingerprint_max','fingerprint_weight','limit'}
            if not isinstance(args[1],dict) or set(args[1])!={'x','y'} or not isinstance(args[2],dict) or set(args[2])!=allowed:
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Managed prescreen accepts only processed X/Y and the existing closed scientific options')
        failed=False
        try:result=host.call(prefix+commands[operation],*args)
        except Exception:failed=True
        if failed:
            raise BridgeError('GXTXT:ScriptBridge:RemoteError','Managed Reference owner refused the request; check identity, scientific contract, integrity and admitted content policy')
    else:
        result = host.call(prefix + commands[operation], *args)
    if operation in ("list_libraries", "list_entities", "list_spectra", "search",'managed_list_spectra'):
        return host.as_list(result)
    item = host.as_dict(result)
    item.pop("path", None)
    if operation in {"read_spectrum",'managed_read_spectrum'}:
        for field in ("x", "y"):
            item[field] = NumericArray(host.as_list(item[field]))
        for field in ("metadata", "provenance"):
            item[field] = host.as_dict(item.get(field, ""))
    if operation in {"bulk_rank",'managed_bulk_rank'} and "candidates" in item:
        item["candidates"] = [host.as_dict(value) for value in host.as_list(item["candidates"])]
    if operation in _MANAGED_COMMANDS:
        for key in ('metadata','provenance'):
            if key in item and not isinstance(item[key],dict):item[key]=host.as_dict(item[key])
        for key in ('sample_count','entity_count','spectrum_count','scanned','skipped'):
            if key in item:item[key]=int(item[key])
        if operation=='managed_read_spectrum':
            for key in ('x_min','x_max'):
                if key in item:item[key]=float(item[key])
        if operation=='managed_bulk_rank':
            for candidate in item.get('candidates',[]):
                for key in ('match_score','full_spectrum_score','fingerprint_score'):candidate[key]=float(candidate[key])
    return item
