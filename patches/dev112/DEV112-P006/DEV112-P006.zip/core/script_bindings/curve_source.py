"""Execution-scoped exact curve sources and bounded Native2D display proxies."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray

_ARGS = {
    "api_info": [], "dataset_identity": ["dataset_id"], "open": ["request"], "describe": ["source"], "validate_snapshot": ["descriptor"],
    "display": ["source"], "page": ["source", "start", "count"],
    "locate_rows": ["source", "source_rows"],
    "open_stream": ["source", "variable_ids", "chunk_rows", "options"],
    "close_stream": ["source", "stream"], "close": ["source"],
    "validate_point_mask": ["mask"],
}
REGISTRATION = {
    "api_id": "CURVE_SOURCE_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "curve_source",
    "documentation_ref": "docs/api/CURVE_SOURCE_API_v1.md",
    "operations": {
        name: {"name": name, "summary": "Backend-neutral curve source: " + name,
               "arguments": [{"name": arg, "kind": "opaque token" if arg in ("source", "stream") else "public value", "required": True} for arg in args],
               "argument_convention": ", ".join(args), "result_contract": "exact source descriptor or bounded typed result",
               "result_convention": "source token, public metadata or typed data"}
        for name, args in _ARGS.items()
    },
}


def _state(host):
    return host.handles.setdefault("curve_source", {"sources": set(), "streams": {}})


def _matrix(host, value):
    rows = [host.as_list(row) for row in host.as_list(value)]
    return NumericArray([float(row[column]) for column in range(2) for row in rows], [len(rows), 2])


def _close_stream(host, source, stream):
    state = _state(host)
    if state["streams"].get(stream) != source:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Stream is not owned by this Curve Source")
    host.call("::GX::curveSourceCloseStream", source, stream)
    del state["streams"][stream]
    host.handles.setdefault("table_stream", set()).discard(stream)


def _existing(host, operation, args):
    if operation not in _ARGS or len(args) != len(_ARGS[operation]):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Invalid Curve Source arguments")
    if operation == "validate_point_mask":
        if not isinstance(args[0], dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Point selection requires its explicit descriptor")
        return str(host.call("::GX::curveSourcePointMaskValidate", args[0]))
    state = _state(host)
    if operation == "dataset_identity":
        return host.as_dict(host.call("::GX::curveSourceDatasetIdentity", host.session, args[0]))
    if operation == "api_info":
        result = host.as_dict(host.call("::GX::curveSourceApiInfo"))
        result["operations"] = host.as_list(result["operations"])
        return result
    if operation == "validate_snapshot":
        if not isinstance(args[0],dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments","Curve Source snapshot must be a struct")
        result=host.as_dict(host.call("::GX::curveSourceValidateSnapshot",host.session,args[0]))
        result["valid"]=str(result["valid"])=="1"
        for key in ("missing_dataset_ids","stale_dataset_ids","reasons"):
            result[key]=host.as_list(result[key])
        result["source_identities"]=[host.as_dict(item) for item in host.as_list(result["source_identities"])]
        return result
    if operation == "open":
        if not isinstance(args[0], dict):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Curve Source request must be a struct")
        token = str(host.call("::GX::curveSourceOpen", host.session, args[0]))
        state["sources"].add(token)
        return token
    token = args[0]
    if not isinstance(token, str) or token not in state["sources"]:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Unknown/closed Curve Source in this execution")
    if operation == "describe":
        result = host.as_dict(host.call("::GX::curveSourceDescribe", token))
        result["request"] = host.as_dict(result["request"])
        if "filters" in result["request"]:
            result["request"]["filters"] = [host.as_dict(item) for item in host.as_list(result["request"]["filters"])]
        result["variables"] = [host.as_dict(item) for item in host.as_list(result["variables"])]
        result["source_identities"] = [host.as_dict(item) for item in host.as_list(result["source_identities"])]
        result["row_count"] = int(result["row_count"])
        result["display_budget"] = int(result["display_budget"])
        result["display_is_scientific_data"] = False
        return result
    if operation == "locate_rows":
        result = host.as_dict(host.call("::GX::curveSourceLocateRows", *args))
        for key in ("source_rows", "positions"):
            result[key] = [int(value) for value in host.as_list(result[key])]
        return result
    if operation in ("display", "page"):
        result = host.as_dict(host.call("::GX::curveSource" + operation.title(), *args))
        result["source_rows"] = [int(row) for row in host.as_list(result["source_rows"])]
        for key in ("row_count", "display_rows", "finite_rows", "start", "count"):
            if key in result: result[key] = int(result[key])
        if operation == "display":
            result["breaks"] = [int(item) for item in host.as_list(result["breaks"])]
            result["points"] = _matrix(host, result["points"])
            result["full_bounds"] = NumericArray(host.as_list(result["full_bounds"]))
            result["diagnostics"] = host.as_dict(result["diagnostics"])
            result["reduced"] = bool(int(result["reduced"]))
            result["display_is_scientific_data"] = False
        else:
            result["rows"] = _matrix(host, result["rows"])
            result["columns"] = [host.as_dict(item) for item in host.as_list(result["columns"])]
        return result
    if operation == "open_stream":
        # The shared script Table Stream binding owns numeric-array encoding;
        # native display ingestion independently uses Canonical binary columns.
        options = dict(args[3])
        options["numeric_transport"] = "values"
        stream = str(host.call("::GX::curveSourceOpenStream", token, args[1], args[2], options))
        state["streams"][stream] = token
        host.handles.setdefault("table_stream", set()).add(stream)
        return stream
    if operation == "close_stream":
        _close_stream(host, token, args[1])
        return True
    if operation == "close":
        for stream, owner in list(state["streams"].items()):
            if owner == token: _close_stream(host, token, stream)
        host.call("::GX::curveSourceClose", token)
        state["sources"].remove(token)
        return True


def _existing_cleanup(host):
    for token in list(_state(host)["sources"]):
        invoke(host, "close", [token])

# Callback-free projections retain the original Curve/Document/Native2D owners.
# Cache handles hold original immutable Resource receipts only for this invocation.
import uuid

_EXTRA = {
    'display_batch': (['request', 'options'], 1),
    'display_cache_store': (['document_id', 'source'], 2),
    'display_cache_restore': (['cache', 'scene'], 2),
}
for _name, (_fields, _minimum) in _EXTRA.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Original canonical grouped/display Resource owner projection: '+_name,
        'arguments': [{'name': field, 'kind': 'closed public value or execution-owned token', 'required': i < _minimum}
                      for i, field in enumerate(_fields)],
        'argument_convention': ', '.join(_fields),
        'result_contract': 'Bounded derived display with exact original row/group/unit labels; cache/scene handles are invocation-scoped, scientific_authority false',
    }


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _bounded(host, value, maximum, label):
    if int(host.call('string', 'bytelength', value)) > maximum:
        _invalid(label+' exceeds its closed projection bound')


def _caches(host):
    return host.handles.setdefault('curve_source_display_cache', {})


def _source_stamp(host, dataset):
    # Keep all raw owner fingerprints private, including Namespace/Session
    # origin and declared continuity beyond the older payload/schema snapshot.
    return tuple(_text(host, host.call(command, *args)) for command, args in (
        ('::GX::curveSourceDatasetIdentity', (host.session, dataset)),
        ('::GX::datasetRevisionToken', (dataset, host.session)),
        ('::GX::datasetNamespaceGet', (host.session, dataset)),
        ('::GX::datasetNamespaceCurrentGet', (host.session,)),
        ('::GX::_curveSourceBatchContext', (host.session, dataset)),
        ('::GX::interactiveDocumentSessionToken', ()),
    ))


def _doc_stamp(host, document):
    raw = host.as_dict(host.call('::GX::interactiveDocumentMetadata', document))
    if _text(host, raw['module_id']) != host.module_id:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Display cache writes require the actual execution module Document')
    return tuple(_text(host, raw[key]) for key in ('id', 'module_id', 'generation', 'revision', 'sha256'))


def _descriptor(host, raw):
    result = host.as_dict(raw)
    result['request'] = host.as_dict(result['request'])
    if 'filters' in result['request']:
        result['request']['filters'] = [host.as_dict(item) for item in host.as_list(result['request']['filters'])]
    for key in ('variables', 'source_identities'):
        result[key] = [host.as_dict(item) for item in host.as_list(result[key])]
    if 'batch_context' in result:result['batch_context'] = host.as_dict(result['batch_context'])
    for key in ('api_version', 'row_count', 'display_budget'):result[key] = int(result[key])
    result['display_is_scientific_data'] = False
    return result


def _diagnostics(host, raw, depth=0):
    if depth > 4:_invalid('Original display diagnostics nesting exceeds its bound')
    fields = host.as_dict(raw);result = {}
    # Existing reader/native counters are data. Decode known nested diagnostic
    # maps only; the fixed original owner, not a caller/provider callback, emits them.
    for key, value in fields.items():
        if key in ('provider', 'storage', 'native_batch', 'native_provider'):
            result[key] = _diagnostics(host, value, depth+1)
        else:result[key] = _text(host, value)
    return result


def _display_projection(host, raw):
    result = host.as_dict(raw)
    for key in ('source_rows', 'breaks'):
        if key in result:result[key] = NumericArray([int(v) for v in host.as_list(result[key])], dtype='uint64')
    result['points'] = _matrix(host, result['points'])
    for key in ('full_bounds', 'bounds'):
        if key in result:result[key] = NumericArray([float(v) for v in host.as_list(result[key])])
    for key in ('row_count', 'display_rows', 'finite_rows', 'start', 'count'):
        if key in result:result[key] = int(result[key])
    if 'diagnostics' in result:result['diagnostics'] = _diagnostics(host, result['diagnostics'])
    if 'reduced' in result:result['reduced'] = bool(host.tcl.getboolean(result['reduced']))
    result.update(display_is_scientific_data=False, points_contract='derived_float64_display', scientific_authority=False)
    return result


def _batch(host, request, options):
    allowed = {'dataset_id', 'x_variable_id', 'y_variable_id', 'filters', 'start', 'count', 'display_budget', 'order_variable_id'}
    if not isinstance(request, dict) or set(request)-allowed or not {'dataset_id', 'x_variable_id', 'y_variable_id'} <= set(request):
        _invalid('Canonical batch requires a closed Dataset/X/Y request')
    if not isinstance(options, dict) or set(options)-{'group_variable_ids', 'max_series', 'total_display_points'}:
        _invalid('Batch options accept grouping/bounds only')
    if 'filters' in request and (not isinstance(request['filters'], list) or len(request['filters']) > 32):
        _invalid('Batch filters require at most32 original row predicates')
    _bounded(host, request, 65536, 'Batch request')
    _bounded(host, options, 16384, 'Batch options')
    options = dict(options)
    for key, default, maximum in (('max_series', 64, 64), ('total_display_points', 32768, 32768)):
        value = options.get(key, default)
        if type(value) not in (int, float) or not 1 <= value <= maximum or int(value) != value:
            _invalid('Batch '+key+' exceeds its projection bound')
        options[key] = int(value)
    dataset = request['dataset_id'];stamp = _source_stamp(host, dataset)
    raw = host.as_dict(host.call('::GX::curveSourceDisplayBatch', host.session, request, options))
    if _source_stamp(host, dataset) != stamp:
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Canonical batch source/Session/Namespace changed')
    _bounded(host, raw, 4194304, 'Original batch result')
    result = {'api_id': 'CURVE_SOURCE_API_v1', 'api_version': 1, 'operation': 'display_batch',
              'source_identities': [host.as_dict(item) for item in host.as_list(raw['source_identities'])],
              'diagnostics': _diagnostics(host, raw['diagnostics']), 'series': [], 'scientific_authority': False}
    for item in host.as_list(raw['series']):
        item = host.as_dict(item)
        result['series'].append({'group_key': [_text(host, v) for v in host.as_list(item['group_key'])],
                                 'filters': [host.as_dict(v) for v in host.as_list(item['filters'])],
                                 'source_descriptor': _descriptor(host, item['source_descriptor']),
                                 'display': _display_projection(host, item['display'])})
    if _source_stamp(host, dataset) != stamp:
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Canonical batch changed during projection')
    return result


def _cache_current(host, held):
    if held['source'] not in _state(host)['sources']:
        _invalid('Cache requires its original live execution-owned Curve Source')
    descriptor = host.call('::GX::curveSourceDescribe', held['source'])
    if (_text(host, descriptor) != held['descriptor'] or tuple((id, _source_stamp(host, id)) for id in held['datasets']) != held['source_stamp']
            or _doc_stamp(host, held['document']) != held['document_stamp']):
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Display cache source/Namespace/Session/Document generation or revision changed')


def _store(host, document, source):
    if not isinstance(document, str) or not isinstance(source, str) or source not in _state(host)['sources']:
        _invalid('Store requires a module-owned Document and original live Curve Source token')
    if len(_caches(host)) >= 32:_invalid('At most32 invocation-scoped display caches may be held')
    descriptor = host.call('::GX::curveSourceDescribe', source);fields = host.as_dict(descriptor)
    request = host.as_dict(fields['request']);dataset = _text(host, request['dataset_id'])
    datasets = list(dict.fromkeys([dataset]+[_text(host, host.as_dict(item)['dataset_id']) for item in host.as_list(fields['source_identities'])]))
    held = dict(source=source, document=document, dataset=dataset, datasets=datasets, descriptor=_text(host, descriptor),
                request=request, source_stamp=tuple((id, _source_stamp(host, id)) for id in datasets), document_stamp=_doc_stamp(host, document))
    _cache_current(host, held)
    # The original Store appends its receipt once while ResourceAppend has a
    # smaller per-chunk limit. Refuse the narrowed bounded projection before
    # allocating resources; do not change that original owner's write algorithm.
    if int(fields['display_budget']) > 4096:_invalid('Invocation cache supports display budgets up to4096')
    _bounded(host, host.call('::GX::interactiveDocumentMetadata', document), 32768, 'Original Document metadata/origin')
    _bounded(host, descriptor, 65536, 'Original source descriptor')
    _bounded(host, request, 65536, 'Original source request')
    _bounded(host, host.call('::GX::sessionOriginRead', host.session), 16384, 'Original Session origin')
    _bounded(host, host.call('::GX::datasetNamespaceGet', host.session, dataset), 16384, 'Original Namespace')
    display = host.call('::GX::curveSourceDisplay', source);_bounded(host, display, 262144, 'Original display')
    _cache_current(host, held)
    held['record_id'] = 'script-display-'+uuid.uuid4().hex
    held['cache'] = host.call('::GX::curveSourceDisplayCacheStore', document, source, held['record_id'])
    _cache_current(host, held)
    rawcache = host.as_dict(held['cache'])
    for key in ('receipt', 'geometry'):host.call('::GX::interactiveDocumentResourceInfo', rawcache[key])
    _cache_current(host, held)
    token = 'curve-display-cache:'+uuid.uuid4().hex;_caches(host)[token] = held
    return {'cache': token, 'document_id': document, 'scientific_authority': False, 'disposable': True,
            'lifetime': 'current_execution', 'display': _display_projection(host, display),
            'source_descriptor': _descriptor(host, descriptor)}


def _restore(host, cache, scene):
    if not isinstance(cache, str) or cache not in _caches(host):_invalid('Use an invocation-owned original display cache handle')
    scenes = host.handles.get('native2d_geometry', {}).get('scenes', set())
    if not isinstance(scene, str) or scene not in scenes:_invalid('Use an existing execution-owned Native2D scene')
    held = _caches(host)[cache];_cache_current(host, held)
    owner = host.as_dict(host.call('::GX::_native2DGeometryRequire', scene))
    if _text(host, owner['document_id']) != held['document']:_invalid('Cache restore scene belongs to another Document')
    native_scene = owner['native'];native = None;adopted = None
    try:
        raw = host.as_dict(host.call('::GX::curveSourceDisplayCacheRestore', host.session, held['document'], held['cache'],
                                    held['record_id'], held['request'], native_scene))
        native = raw['native'];_cache_current(host, held)
        current = host.as_dict(host.call('::GX::_native2DGeometryRequire', scene))
        if _text(host, current['native']) != _text(host, native_scene):_invalid('Owned native scene incarnation changed')
        # Disposable display points carry no fabricated canonical source-row
        # Resource, scientific definition or publication provenance. Original
        # row mapping/continuity/units stay in the separate display projection.
        adopted = host.call('::GX::_native2DGeometryAdopt', scene, native,
                            {'source_kind': 'curve_source_display_cache', 'scientific_authority': 0, 'disposable': 1})
        native = None;_cache_current(host, held)
        host.call('::GX::_native2DGeometryRequire', scene)
        return {'geometry': host.modules['NATIVE_2D_GEOMETRY_API_v1']._receipt(host, adopted),
                'display': _display_projection(host, raw['display']), 'source_descriptor': _descriptor(host, raw['descriptor']),
                'scientific_authority': False, 'disposable': True, 'lifetime': 'current_execution'}
    except BaseException:
        if adopted is not None:
            try:host.call('::GX::native2DGeometryCall', scene, 'delete', {'object_token': host.as_dict(adopted)['object_token']})
            except Exception:
                # An expired Document/Session scene can still be closed by its
                # original owner, which destroys every object in that scene.
                try:host.call('::GX::native2DGeometryClose', scene)
                finally:scenes.discard(scene)
        elif native is not None:
            try:host.call('::GX::Native2D::core', 'delete', native_scene, native)
            except Exception:pass
        raise


def invoke(host, operation, args):
    if operation not in _EXTRA:return _existing(host, operation, args)
    fields, minimum = _EXTRA[operation]
    if not minimum <= len(args) <= len(fields):_invalid('Invalid callback-free Curve Source projection arguments')
    if operation == 'display_batch':return _batch(host, args[0], args[1] if len(args)>1 else {})
    if operation == 'display_cache_store':return _store(host, *args)
    return _restore(host, *args)


def cleanup(host):
    try:_existing_cleanup(host)
    finally:_caches(host).clear()
