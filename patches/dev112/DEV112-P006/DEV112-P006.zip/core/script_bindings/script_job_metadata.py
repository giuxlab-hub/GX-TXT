"""Inert debugger capability metadata from the existing CORE Job owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    "api_id": "SCRIPT_JOB_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "script_job",
    "documentation_ref": "docs/api/SCRIPT_JOB_API_v1.md",
    "operations": {"debug_capabilities": {
        "name": "debug_capabilities", "summary": "Read inert native debugger protocol capabilities",
        "host_command": "::GX::scriptJobDebugCapabilities",
        "arguments": [{"name": "language", "kind": "Python or Octave", "required": True}],
        "argument_convention": "language", "result_contract": "language/backend, ordered control IDs and explicit pause availability; no Job is started",
    }},
}


REGISTRATION['operations']['policy_read'] = {
    'name': 'policy_read', 'summary': 'Read the original same-admitted LOCAL Job policy snapshot',
    'host_command': '::GX::scriptJobPolicyRead', 'arguments': [],
    'argument_convention': 'no arguments',
    'result_contract': 'Original schema/configured/origin/seven positive integer policy fields/policy_sha256; no caller root, remote budget or admission lease',
}


def _policy_read(host, args):
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'policy_read takes no arguments')
    result = host.as_dict(host.call('::GX::scriptJobPolicyRead'))
    return {'schema': str(result['schema']),
            'configured': bool(host.tcl.getboolean(result['configured'])),
            'origin': str(result['origin']),
            'policy': {str(key): int(value) for key, value in host.as_dict(result['policy']).items()},
            'policy_sha256': str(result['policy_sha256'])}


def invoke(host, operation, args):
    if operation == 'policy_read': return _policy_read(host, args)
    if operation != "debug_capabilities":
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", "No host Job operation is registered by this metadata adapter")
    if len(args) != 1 or not isinstance(args[0], str) or args[0] not in {"Python", "Octave"}:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Debugger metadata requires Python or Octave")
    result = host.as_dict(host.call("::GX::scriptJobDebugCapabilities", args[0]))
    result["controls"] = [str(value) for value in host.as_list(result["controls"])]
    result["pause_supported"] = bool(host.tcl.getboolean(result["pause_supported"]))
    return result
