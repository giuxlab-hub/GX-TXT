"""Closed installed-reference catalogue reads; the catalogue owns initialization."""
# SPDX-License-Identifier: GPL-3.0-or-later
import time
from pathlib import PurePosixPath
from gxtxt_script_bridge_server import BridgeError

_FIELDS = {'query': ['filters'], 'get': ['record_id'], 'provider_state': ['provider_id'],
           'diagnostics': ['verify_sources'], 'manual_inspect': ['record_id','provider_id'], 'status': []}
REGISTRATION = {
    'api_id': 'API_CATALOG_SERVICE_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'api_catalog',
    'documentation_ref': 'docs/api/API_CATALOG_SERVICE_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Read installed catalogue '+name,
        'arguments': [{'name': arg, 'kind': 'closed metadata value', 'required': True} for arg in fields],
        'host_command': '::GX::apiCatalog'+{'query':'Query','get':'Get','provider_state':'ProviderState',
            'diagnostics':'Diagnostics','manual_inspect':'ManualInspect','status':'Status'}[name],
        'result_contract': 'Reference-only declared identities, source metadata and runtime availability; never execution admission'}
        for name, fields in _FIELDS.items()},
}


# Preserve the original inert optional defaults; the owner still validates them.
for _operation, _index, _default in (('query', 0, {}), ('diagnostics', 0, False), ('manual_inspect', 1, '')):
    _argument = REGISTRATION['operations'][_operation]['arguments'][_index]
    _argument.update(required=False, default=_default)


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _reference(value):
    value = str(value)
    path = PurePosixPath(value)
    if value and (path.is_absolute() or '..' in path.parts or '\\' in value or '\x00' in value):
        return ''
    return value


def _state(host, raw):
    fields = host.as_dict(raw)
    result = {key: bool(host.tcl.getboolean(fields[key])) for key in
              ('installed', 'enabled', 'active', 'pending') if key in fields}
    result.update({key: str(fields[key]) for key in
                   ('installed_version', 'active_status', 'admission') if key in fields})
    # A failed installed runtime probe may include physical source paths.
    if 'runtime_error' in fields:
        result['runtime_error_present'] = bool(str(fields['runtime_error']))
    if 'providers' in fields:
        result['providers'] = {str(key): _state(host, value)
                               for key, value in host.as_dict(fields['providers']).items()}
    return result


def _record(host, raw):
    fields = host.as_dict(raw)
    result = {key: str(fields[key]) for key in
              ('id', 'api_id', 'provider_id', 'surface', 'language', 'version', 'title', 'summary')}
    payload = host.as_dict(fields['payload'])
    source = host.as_dict(payload['catalog_meta'])
    meta = {key: str(source[key]) for key in
            ('provider_version', 'declaration_sha256', 'documentation_status', 'operation',
             'superseded_by', 'result_contract', 'source_kind') if key in source}
    for key in ('declaration_ref', 'documentation'):
        if key in source:
            meta[key] = _reference(source[key])
    for key in ('deprecated', 'public_documented', 'python', 'octave', 'cpp_sdk'):
        if key in source:
            meta[key] = bool(host.tcl.getboolean(source[key])) if str(source[key]) else False
    arguments = []
    for value in host.as_list(source.get('arguments', '')):
        argument = host.as_dict(value)
        item = {key: str(argument[key]) for key in ('name', 'kind', 'description', 'default') if key in argument}
        if str(argument.get('required', '')) in ('0', '1'):
            item['required'] = bool(int(argument['required']))
        arguments.append(item)
    meta['arguments'] = arguments
    members = []
    for value in host.as_list(source.get('source_members', '')):
        entry = host.as_dict(value)
        item = {key: str(entry[key]) for key in
                ('provider_id', 'provider_version', 'declaration_sha256', 'source_role', 'documentation_status') if key in entry}
        for key in ('declaration_ref', 'documentation'):
            if key in entry:
                item[key] = _reference(entry[key])
        members.append(item)
    meta['source_members'] = members
    result['catalog_meta'] = meta
    result['runtime_state'] = _state(host, fields['runtime_state'])
    return result


def _ready(host):
    # Use the original fixed metadata reconciliation workflow, including its
    # snapshot/source identity checks. No caller callback or path is accepted.
    host.call('::GX::apiCatalogStartup')
    deadline = time.monotonic()+30
    while True:
        try:
            host.call('::GX::_apiCatalogDefinitionRequire')
            return
        except Exception:
            if time.monotonic() >= deadline or str(host.tcl.getvar('::GX::ApiCatalog::progress')) in {'failed', 'closed'}:
                raise BridgeError('GXTXT:ApiCatalog:Unavailable', 'Installed reference catalogue initialization did not produce an available definition') from None
            host.tcl.eval('update')
            time.sleep(.01)


def _file_metadata(host, raw):
    fields = host.as_dict(raw)
    result = {key: str(fields[key]) for key in
              ('type','sha256','status','indexed_status','indexed_sha256') if key in fields}
    if 'reference' in fields:
        result['reference'] = _reference(fields['reference'])
    if 'present' in fields:
        result['present'] = bool(host.tcl.getboolean(fields['present']))
    if 'size' in fields:
        result['size'] = int(fields['size'])
    if 'error' in fields:
        result['error_present'] = bool(str(fields['error']))
    return result


def _snapshot_lifecycle(host, raw):
    fields = host.as_dict(raw)
    result = {'logical_category': str(fields['logical_category']),
              'total_rows': int(fields['total_rows']),
              'omitted_rows': int(fields['omitted_rows']),
              'global_worker_drain_proven': bool(host.tcl.getboolean(fields['global_worker_drain_proven']))}
    close = host.as_dict(fields['close_receipt'])
    receipt = {}
    if close:
        receipt['snapshot_cleanup_complete'] = bool(host.tcl.getboolean(close['snapshot_cleanup_complete']))
        receipt['pending_snapshots'] = int(close['pending_snapshots'])
        receipt['errors_present'] = bool(host.as_list(close['errors']))
        worker = host.as_dict(close['stage_worker'])
        receipt['stage_worker'] = {key: str(worker[key]) for key in
                                   ('cancellation', 'retirement') if key in worker}
        if 'cancellation_error' in worker:
            receipt['stage_worker']['cancellation_error_present'] = bool(str(worker['cancellation_error']))
    result['close_receipt'] = receipt
    # Resource-keyed rows/receipts contain owner scopes, paths and caught error
    # text. Inspect those through their host owner rather than this shared read.
    # Cancellation acknowledgment is deliberately not a worker-drain claim.
    return result


def _diagnostics(host, verify):
    fields = host.as_dict(host.call('::GX::apiCatalogDiagnostics', verify))
    result = {'schema':str(fields['schema'])}
    counts = host.as_dict(fields['counts'])
    result['counts'] = {key:int(counts[key]) for key in ('total','family','host','script_bridge','cpp_sdk')}
    result['counts']['providers'] = {str(key):int(value) for key,value in host.as_dict(counts['providers']).items()}
    status = host.as_dict(fields['status'])
    result['status'] = {key:str(status[key]) for key in ('fingerprint','freshness','progress')}
    result['status']['generation'] = int(status['generation'])
    result['status']['error_present'] = bool(str(status['error']))
    verification = host.as_dict(fields['source_verification'])
    result['source_verification'] = {key:str(verification[key]) for key in ('state','fingerprint')}
    result['source_verification']['attempted'] = bool(host.tcl.getboolean(verification['attempted']))
    result['source_verification']['error_present'] = bool(str(verification['error']))
    packaged = host.as_dict(fields['packaged'])
    result['packaged'] = {key:_file_metadata(host,packaged[key]) for key in ('database','manifest')}
    result['packaged'].update({key:str(packaged[key]) for key in
        ('loaded_expected_database_sha256','loaded_manifest_fingerprint')})
    if 'snapshot_lifecycle' in fields:
        result['snapshot_lifecycle'] = _snapshot_lifecycle(host, fields['snapshot_lifecycle'])
    return result


def _manual(host, identity, provider):
    fields = host.as_dict(host.call('::GX::apiCatalogManualInspect', identity, provider))
    result = {key:str(fields[key]) for key in
              ('schema','status','record_id','api_id','provider_id','fingerprint')}
    result['generation'] = int(fields['generation'])
    result['reasons'] = [str(value) for value in host.as_list(fields['reasons'])]
    declaration = host.as_dict(fields['declaration'])
    result['declaration'] = {key:str(declaration[key]) for key in
        ('indexed_sha256','current_sha256','current_reference_state') if key in declaration}
    for key in ('indexed_reference','reference','documentation','descriptor_reference'):
        if key in declaration:
            result['declaration'][key] = _reference(declaration[key])
    for key in ('indexed_document','installed_document'):
        result[key] = _file_metadata(host,fields[key])
    resolver = host.as_dict(fields['resolver'])
    result['resolver'] = {key:str(resolver[key]) for key in
        ('document_id','status','source_sha256','relation') if key in resolver}
    result['resolver']['error_present'] = bool(str(resolver['error']))
    result['runtime_state'] = _state(host,fields['runtime_state'])
    # No window argument is accepted, so the owner never enters its optional
    # live presentation inspection branch.
    return result


def invoke(host, operation, args):
    if operation not in _FIELDS:
        _invalid('Catalogue reads require exactly their declared arguments')
    minimum = {'query': 0, 'diagnostics': 0, 'manual_inspect': 1}.get(operation, len(_FIELDS[operation]))
    if not minimum <= len(args) <= len(_FIELDS[operation]):
        _invalid('Catalogue reads require exactly their declared arguments')
    if len(args) < len(_FIELDS[operation]):
        args = [*args, {'query': {}, 'diagnostics': False, 'manual_inspect': ''}[operation]]
    if operation == 'status':
        _ready(host)
        fields = host.as_dict(host.call('::GX::apiCatalogStatus'))
        result = {key: str(host.tcl.call('format', '%s', fields[key])) for key in
                  ('fingerprint', 'freshness', 'progress', 'target_fingerprint',
                   'source_manifest_schema', 'source_manifest_fingerprint',
                   'loaded_packaged_database_sha256') if key in fields}
        result['generation'] = int(fields['generation'])
        result['request_active'] = bool(host.tcl.getboolean(fields['request_active']))
        result['error_present'] = bool(str(fields['error']))
        result['pending_metadata_present'] = bool(str(fields['pending_metadata']))
        return result
    if operation == 'diagnostics':
        if not isinstance(args[0],bool):
            _invalid('Source verification requires an explicit boolean')
        _ready(host)
        return _diagnostics(host,args[0])
    if operation == 'manual_inspect':
        if any(not isinstance(value,str) or len(value)>4096 for value in args):
            _invalid('Manual inspection requires bounded record/provider identities')
        _ready(host)
        return _manual(host,*args)
    if operation == 'provider_state':
        if not isinstance(args[0], str) or len(args[0]) > 1024:
            _invalid('Provider identity must be a bounded string')
        return _state(host, host.call('::GX::apiCatalogProviderState', args[0]))
    if operation == 'get':
        if not isinstance(args[0], str) or len(args[0]) > 4096:
            _invalid('Record identity must be a bounded string')
    else:
        filters = args[0]
        if not isinstance(filters, dict) or set(filters)-{'surface','language','query','api_id','provider_id','source_ref','source_sha256','offset','limit'}:
            _invalid('Catalogue query accepts only declared filters')
        for key, value in filters.items():
            if key in {'offset','limit'}:
                if isinstance(value, bool) or not isinstance(value, (int,float)) or not float(value).is_integer():
                    _invalid('Catalogue pagination requires integers')
            elif key == 'surface':
                if not isinstance(value, (list,tuple)) or any(not isinstance(item,str) for item in value):
                    _invalid('Catalogue surface filter requires a list of declared surface names')
            elif not isinstance(value, str):
                _invalid('Catalogue text filters require literal strings')
        if 'source_ref' in filters and _reference(filters['source_ref']) != filters['source_ref']:
            _invalid('Catalogue source reference must be a relative declaration identity')
        # Octave transports integral numeric scalars as doubles.
        args = [{key: int(value) if key in {'offset','limit'} else value for key,value in filters.items()}]
    _ready(host)
    if operation == 'get':
        return _record(host, host.call('::GX::apiCatalogGet', args[0]))
    fields = host.as_dict(host.call('::GX::apiCatalogQuery', args[0]))
    result = {key: int(fields[key]) for key in ('total','offset','limit','generation')}
    result.update(fingerprint=str(fields['fingerprint']), freshness=str(fields['freshness']),
                  error_present=bool(str(fields['error'])),
                  rows=[_record(host, value) for value in host.as_list(fields['rows'])])
    return result


def cleanup(host):
    # Embedded Tcl has no ::exit command. The existing Bridge module lifetime
    # hook closes the same catalogue owner and removes its snapshot files.
    host.call('::GX::apiCatalogClose')
