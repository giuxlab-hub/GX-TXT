"""Read the existing CORE Spectrum Import declaration without invoking import."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
from gxtxt_script_bridge_server import NumericArray

_API_ID = 'SCIENTIFIC_SPECTRUM_IMPORT_API_v1'
_COMMAND = '::GX::SpectrumImportAPIv1::apiInfo'
_FIELDS = {'api_name', 'api_version', 'formats', 'native_value_owner',
           'host_validation_operation'}

REGISTRATIONS = [{
    'api_id': _API_ID, 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'CORE',
    'documentation_ref': 'docs/api/SCIENTIFIC_SPECTRUM_IMPORT_API_v1.md',
    'operations': {'api_info': {
        'name': 'api_info',
        'summary': 'Read the original inert Spectrum Import declaration',
        'arguments': [], 'argument_convention': 'no arguments',
        'host_command': _COMMAND,
        'result_contract': 'Complete original five fields: text identities, integer version and ordered text formats; listed methods and formats grant no invocation',
    }},
}]

_RESOURCE_OPERATIONS = {
    'parse_resource': ('parse', ['format', 'resource', 'options']),
    'parse_csv_resource': ('parseCsv', ['resource', 'options']),
    'parse_jcamp_resource': ('parseJcamp', ['resource', 'options']),
    'validate_resource': ('validateSource', ['format', 'resource', 'options', 'expected_count']),
}
REGISTRATIONS[0]['operations'].update({
    operation: {
        'name': operation, 'summary': 'Parse or validate an admitted Resource with the original Spectrum Import owner',
        'host_command': '::GX::SpectrumImportAPIv1::' + command,
        'arguments': [{'name': name, 'kind': 'existing Resource reference' if name == 'resource' else 'inert public value',
                       'required': True} for name in names],
        'argument_convention': ', '.join(names),
        'result_contract': 'Complete original typed Spectrum or validation under an explicit envelope with separately admitted source receipt; new managed bounds, no raw-path/default equivalence or publication',
    } for operation, (command, names) in _RESOURCE_OPERATIONS.items()
})


def invoke_api(host, api_id, operation, args):
    if api_id == _API_ID and operation in _RESOURCE_OPERATIONS:
        return _resource_call(host, operation, args)
    if api_id != _API_ID or operation != 'api_info':
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',
                          'Unknown Spectrum Import metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',
                          'Spectrum Import metadata takes no arguments')
    fields = host.as_dict(host.call(_COMMAND))
    if set(fields) != _FIELDS:
        raise BridgeError('GXTXT:ScriptBridge:InvalidResult',
                          'Spectrum Import declaration fields changed')
    text = lambda value: str(host.tcl.call('format', '%s', value))
    result = {text(key): text(value) for key, value in fields.items()}
    result['api_version'] = int(fields['api_version'])
    result['formats'] = [text(value) for value in host.as_list(fields['formats'])]
    return result


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _inputs(operation, args):
    import json
    _, names = _RESOURCE_OPERATIONS[operation]
    if len(args) != len(names):
        _invalid('Invalid managed Spectrum Import argument count')
    if operation in ('parse_csv_resource', 'parse_jcamp_resource'):
        reference, options = args
        format_value = None
    else:
        format_value, reference, options = args[:3]
        if not isinstance(format_value, str):
            _invalid('Spectrum Import format must be text')
    required = {'api_id', 'document_id', 'sha256', 'size_bytes', 'metadata'}
    if (not isinstance(reference, dict) or not required <= set(reference)
            or set(reference) - required - {'owner_generation'}
            or any(not isinstance(reference[key], str) for key in ('api_id', 'document_id', 'sha256'))
            or type(reference['size_bytes']) is not int or reference['size_bytes'] < 0
            or not isinstance(reference['metadata'], dict)):
        _invalid('Spectrum Import requires an original Document Resource reference')
    if ('owner_generation' in reference and
            (isinstance(reference['owner_generation'], bool) or not isinstance(reference['owner_generation'], (str, int)))):
        _invalid('Resource generation must retain its original scalar identity')
    if any(not isinstance(key, str) or not isinstance(value, str)
           for key, value in reference['metadata'].items()):
        _invalid('Resource metadata must retain inert scalar text values')
    if not isinstance(options, dict) or not isinstance(options.get('source_identity'), str):
        _invalid('Spectrum Import requires explicit caller source_identity text')
    for key, value in options.items():
        if not isinstance(key, str):
            _invalid('Spectrum Import option keys must be text')
        if key in ('metadata', 'provenance'):
            if not isinstance(value, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in value.items()):
                _invalid('Spectrum Import annotations must be scalar text maps')
        elif not isinstance(value, str):
            _invalid('Spectrum Import options must retain original scalar text')
    if len(json.dumps(options, ensure_ascii=False, separators=(',', ':')).encode('utf-8')) > 49152:
        raise BridgeError('GXTXT:ScriptBridge:Budget', 'Managed Spectrum Import options exceed 48 KiB')
    if operation == 'validate_resource' and (type(args[3]) is not int or args[3] < 2):
        _invalid('Spectrum validation requires an integer expected count of at least two')
    return format_value, reference, options


def _receipt(host, raw):
    fields = host.as_dict(raw)
    result = {key: _text(host, fields[key]) for key in ('api_id', 'document_id', 'sha256')}
    if 'owner_generation' in fields:
        result['owner_generation'] = _text(host, fields['owner_generation'])
    result['size_bytes'] = int(fields['size_bytes'])
    result['metadata'] = {_text(host, key): _text(host, value) for key, value in host.as_dict(fields['metadata']).items()}
    return result


def _source_check(host, reference, incarnation):
    if _text(host, host.call('::GX::interactiveDocumentSessionToken')) != incarnation:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Resource Session lifetime changed during Spectrum Import')
    result = _receipt(host, host.call('::GX::interactiveDocumentResourceInfo', reference))
    if _text(host, host.call('::GX::interactiveDocumentSessionToken')) != incarnation:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Resource Session lifetime changed during Spectrum Import')
    return result


def _snapshot_check(path, held, identity):
    import hashlib
    import os
    import stat
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        current = os.fstat(stream.fileno())
        if (not stat.S_ISREG(current.st_mode) or current.st_nlink != 1
                or (current.st_dev, current.st_ino) != identity or current.st_size != held['size_bytes']
                or hashlib.sha256(stream.read()).hexdigest() != held['sha256']):
            raise BridgeError('GXTXT:ScriptBridge:Transport', 'Owned Spectrum Import snapshot changed')


def _typed_result(host, raw, validation):
    fields = host.as_dict(raw)
    expected = {'sample_count', 'spectrum_hash', 'source_hash', 'x_ordering', 'x_min', 'x_max'}
    if not validation:
        expected |= {'spectrum_id', 'display_name', 'spectrum_kind', 'x_quantity', 'x_unit',
                     'y_quantity', 'y_representation', 'y_unit', 'contract', 'x', 'y',
                     'metadata', 'provenance', 'source_identity', 'entity_id'}
    if set(fields) != expected:
        raise BridgeError('GXTXT:ScriptBridge:InvalidResult', 'Original Spectrum Import result fields changed')
    count = int(fields['sample_count'])
    if count > 1000000:
        raise BridgeError('GXTXT:ScriptBridge:Budget', 'Managed Spectrum Import result exceeds one million samples after owner execution')
    result = {}
    for key, value in fields.items():
        if key in ('x', 'y'):
            result[key] = NumericArray(host.as_list(value))
        elif key in ('metadata', 'provenance'):
            result[key] = {_text(host, k): _text(host, v) for k, v in host.as_dict(value).items()}
        elif key == 'sample_count':
            result[key] = count
        elif key in ('x_min', 'x_max'):
            result[key] = float(value)
        else:
            result[key] = _text(host, value)
    return result


def _private_diagnostic(host, phase, error):
    """Keep exact owner diagnostics in the existing private execution stderr."""
    import json
    import sys
    record = {'event': 'managed_spectrum_import_refusal', 'phase': phase,
              'exception_type': type(error).__name__, 'raw_message': str(error)}
    if not isinstance(error, BridgeError):
        for key in ('errorInfo', 'errorCode'):
            try:
                record[key] = _text(host, host.tcl.getvar(key))
            except Exception:
                pass
    print(json.dumps(record, ensure_ascii=False), file=sys.stderr)


def _resource_call(host, operation, args):
    import hashlib
    import os
    from gxtxt_resource_manager import ResourceManager

    format_value, reference, options = _inputs(operation, args)
    manager = None
    allocation = None
    reader = None
    failure = None
    result = None
    phase = 'resource'
    try:
        incarnation = _text(host, host.call('::GX::interactiveDocumentSessionToken'))
        held = _source_check(host, reference, incarnation)
        if held['size_bytes'] > 1048576:
            raise BridgeError('GXTXT:ScriptBridge:Budget', 'Managed Spectrum Import source exceeds 1 MiB')
        reader = host.call('::GX::interactiveDocumentResourceOpenReader', reference)
        phase = 'snapshot'
        manager = ResourceManager()
        allocation = manager.allocate('script_bridge_spectrum_import', kind='file', suffix='.spectrum',
                                      lifetime='operation', job_id=host.run_id, session=host.session,
                                      expected_bytes=held['size_bytes'], retention_seconds=0)
        digest = hashlib.sha256()
        copied = 0
        fd = os.open(allocation['path'], os.O_WRONLY | os.O_TRUNC | os.O_NOFOLLOW)
        with os.fdopen(fd, 'wb') as stream:
            created = os.fstat(stream.fileno())
            snapshot_identity = (created.st_dev, created.st_ino)
            while True:
                phase = 'resource'
                raw_page = host.call('::GX::interactiveDocumentResourceNext', reader, 1048576)
                # Extract the original bytearray before the dictionary helper
                # formats scalar Tcl objects as text.
                payload = host.tcl.call('dict', 'get', raw_page, 'bytes')
                page = host.as_dict(raw_page)
                if payload == '':
                    payload = b''
                if not isinstance(payload, bytes) or len(payload) != int(page['count']):
                    raise BridgeError('GXTXT:ScriptBridge:Transport', 'Resource reader lost its exact byte shape')
                stream.write(payload)
                digest.update(payload)
                copied += len(payload)
                if bool(host.tcl.getboolean(page['eof'])):
                    break
        if copied != held['size_bytes'] or digest.hexdigest() != held['sha256']:
            raise BridgeError('GXTXT:ScriptBridge:Transport', 'Resource snapshot differs from its admitted byte identity')
        host.call('::GX::interactiveDocumentResourceCloseReader', reader)
        reader = None
        _source_check(host, reference, incarnation)
        phase = 'snapshot'
        _snapshot_check(allocation['path'], held, snapshot_identity)
        phase = 'owner'
        command = '::GX::SpectrumImportAPIv1::' + _RESOURCE_OPERATIONS[operation][0]
        parameters = [allocation['path'], options]
        if format_value is not None:
            parameters.insert(0, format_value)
        if operation == 'validate_resource':
            parameters.extend([held['sha256'], args[3]])
        raw = host.call(command, *parameters)
        phase = 'snapshot'
        _snapshot_check(allocation['path'], held, snapshot_identity)
        phase = 'resource'
        source = _source_check(host, reference, incarnation)
        phase = 'result'
        if _text(host, host.as_dict(raw)['source_hash']) != held['sha256']:
            raise BridgeError('GXTXT:ScriptBridge:Transport', 'Original Spectrum Import source hash differs from the admitted bytes')
        result = {'validation' if operation == 'validate_resource' else 'spectrum':
                  _typed_result(host, raw, operation == 'validate_resource'),
                  'validated_source': source}
    except Exception as error:
        _private_diagnostic(host, phase, error)
        if isinstance(error, BridgeError):
            failure = error
        else:
            identifier, message = {
                'resource': ('ResourceRefused', 'Original Document Resource owner refused this source or its current lifetime'),
                'owner': ('SpectrumImportRefused', 'Original Spectrum Import owner refused this scientific source or its options'),
                'snapshot': ('SnapshotRefused', 'Managed Spectrum Import could not prepare its owned byte snapshot'),
                'result': ('InvalidResult', 'Original Spectrum Import result could not retain its typed transport'),
            }[phase]
            failure = BridgeError('GXTXT:ScriptBridge:' + identifier, message)
    finally:
        cleanup_errors = []
        if reader is not None:
            try:
                host.call('::GX::interactiveDocumentResourceCloseReader', reader)
            except Exception as error:
                cleanup_errors.append(error)
        if manager is not None:
            try:
                if allocation is not None:
                    manager.release(allocation['id'])
                    manager.cleanup([allocation['id']])
            except Exception as error:
                cleanup_errors.append(error)
            finally:
                try:
                    manager.close()
                except Exception as error:
                    cleanup_errors.append(error)
        for error in cleanup_errors:
            _private_diagnostic(host, 'cleanup', error)
        if cleanup_errors and failure is None:
            failure = BridgeError('GXTXT:ScriptBridge:ResourceCleanup', 'Managed Spectrum Import could not finish its owned temporary cleanup')
    if failure is not None:
        raise failure from None
    return result
