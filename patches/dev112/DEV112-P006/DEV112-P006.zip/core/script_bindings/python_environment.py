"""Closed observational Python metadata and inert existing AST owner routes.

The configured interpreter/helper remain the sole inventory/parser/organizer
owner. Source travels only on stdin; no path, report, callback or installation
option crosses this adapter.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
import subprocess
from gxtxt_script_bridge_server import BridgeError

_FIELDS={'inventory':[('limit','integer',False),('offset','integer',False)],
         'preflight':[('source','string',True)],
         'organize':[('source','string',True),('statements','list of strings',True)]}
REGISTRATION={'api_id':'PYTHON_ENVIRONMENT_API_v1','api_version':1,'provider_kind':'core','provider_id':'python_environment',
 'documentation_ref':'docs/api/PYTHON_ENVIRONMENT_API_v1.md',
 'operations':{name:{'name':name,'summary':'Existing nonexecuting Python Environment '+name,
  'arguments':[{'name':field,'kind':kind,'required':required} for field,kind,required in fields],
  'result_contract':'Closed configured-Python names/versions/status or exact inert UTF8 source/SHA; no executable/prefix/search path/module location/report/callback'}
  for name,fields in _FIELDS.items()}}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)


def _integer(value,minimum,maximum):
    if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or int(value)!=value or not minimum<=value<=maximum:
        _invalid('Python metadata budget must be an integer within its declared bounds')
    return int(value)


def _identity(host,raw):
    fields=host.as_dict(raw)
    return {'version':str(fields['version']),
            'virtual_environment':bool(host.tcl.getboolean(fields['virtual_environment'])),
            'scanned_at':str(fields['scanned_at'])}


def _import(host,raw):
    fields=host.as_dict(raw)
    result={key:str(fields[key]) for key in ('module','status','alias_or_members','intent','static_status') if key in fields}
    for key in ('line','column'):
        if key in fields:result[key]=int(fields[key])
    if 'from_import' in fields:result['from_import']=bool(host.tcl.getboolean(fields['from_import']))
    return result


def invoke(host,operation,args):
    if operation not in _FIELDS or not sum(required for _,_,required in _FIELDS[operation])<=len(args)<=len(_FIELDS[operation]):
        _invalid('Invalid closed Python Environment operation/arguments')
    options=[];source=''
    if operation=='inventory':
        limit=_integer(args[0],1,2000) if args else 100
        offset=_integer(args[1],0,2147483647) if len(args)>1 else 0
        options=['--limit',str(limit),'--offset',str(offset)]
    else:
        if not isinstance(args[0],str):_invalid('Python source requires exact inert UTF8 text')
        source=args[0]
        if len(source.encode('utf-8'))>4194304:_invalid('Python source exceeds the existing 4 MiB owner bound')
        if operation=='organize':
            statements=args[1]
            if (not isinstance(statements,(list,tuple)) or len(statements)>128 or
                any(not isinstance(value,str) or '\0' in value or len(value.encode('utf-8'))>4096 for value in statements)):
                _invalid('Import organization requires at most128 bounded inert statement strings')
            for statement in statements:options.append('--statement='+statement)
    # Only this fixed original owner constructs the configured executable and
    # fixed helper path. Caller source is never argv/--source or executed code.
    command=[str(host.tcl.call('format','%s',value)) for value in host.as_list(host.call('::GX::pythonEnvironmentCommand',operation,*options))]
    try:
        response=subprocess.run(command,input=source.encode('utf-8'),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False)
    except (OSError,subprocess.TimeoutExpired):
        raise BridgeError('GXTXT:ScriptBridge:RemoteError','Configured Python Environment owner is unavailable') from None
    if response.returncode:
        raise BridgeError('GXTXT:ScriptBridge:RemoteError','Configured Python Environment owner did not return a valid response')
    fields=host.as_dict(response.stdout.decode('utf-8'))
    if not host.tcl.getboolean(fields['ok']):
        error=str(fields.get('error','')).split(':',1)[0]
        kind=error if error in {'SyntaxError','ValueError','TypeError','UnicodeError'} else 'InvalidRequest'
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Python Environment owner rejected the inert request ('+kind+')')
    result=host.as_dict(fields['result'])
    if operation=='inventory':
        entries=[]
        for raw in host.as_list(result['entries']):
            row=host.as_dict(raw)
            item={key:str(row[key]) for key in ('module','classification','status')}
            item['distributions']={str(name):str(version) for name,version in host.as_dict(row['distributions']).items()}
            entries.append(item)
        return {'identity':_identity(host,result['identity']),'total':int(result['total']),
                'limit':int(result['limit']),'offset':int(result['offset']),'entries':entries}
    if operation=='preflight':
        return {'identity':_identity(host,result['identity']),'status':str(result['status']),
                'source_sha256':str(result['source_sha256']),'original_bytes_sha256':str(result['original_bytes_sha256']),
                'imports':[_import(host,value) for value in host.as_list(result['imports'])],
                'issues':[_import(host,value) for value in host.as_list(result['issues'])]}
    return {'source':str(host.tcl.call('format','%s',result['source'])),
            'before_sha256':str(result['before_sha256']),'after_sha256':str(result['after_sha256']),
            'original_bytes_sha256':str(result['original_bytes_sha256']),
            'statements':[str(value) for value in host.as_list(result['statements'])],
            'duplicates':[str(value) for value in host.as_list(result['duplicates'])],
            'changed':bool(host.tcl.getboolean(result['changed']))}
