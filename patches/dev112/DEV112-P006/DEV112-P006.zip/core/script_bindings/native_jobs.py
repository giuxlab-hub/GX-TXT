"""Same-registry native scientific Jobs for Python, Octave and C++ frontends.

Installed executable admission stays in CORE. The caller's existing Module and
Session context select its native project; no extra frontend operation allowlist.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
import base64
import os
from pathlib import Path
import uuid
import hashlib
from gxtxt_script_bridge_server import BridgeError

ARGUMENTS = {'info': [], 'describe': ['entrypoint'],
             'prepare': ['entrypoint', 'parameters', 'options', 'resources'], 'submit': ['prepared_token'],
             'status': ['job_id'], 'cancel': ['job_id'], 'result': ['job_id'],
             'reconnect': ['job_id'], 'events': ['job_id', 'after_sequence', 'limit'], 'read_buffer':['job_id','resource_id']}
REGISTRATION = dict(api_id='NATIVE_JOB_API_v1', api_version=1, provider_kind='core', provider_id='native_jobs',
                    documentation_ref='docs/api/NATIVE_JOB_API_v1.md',
                    capabilities=['native_installed_artifact', 'typed_native_results', 'supervised_native_jobs', 'durable_job_events'],
                    operations={name: dict(name=name, summary='Existing Supervisor native task '+name,
                        arguments=[dict(name=arg,kind='public value',required=arg!='resources') for arg in args],
                        argument_convention=', '.join(args), result_contract='Source-bound native Job/typed value; existing Module and Session authority')
                        for name,args in ARGUMENTS.items()})


def _module(host):
    if not host.module_id:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native task requires its installed Viewer module context')
    return host.module_id


def _receipt(host, raw):
    value = host.as_dict(raw)
    for field in ('abi', 'dependencies', 'runtime_dependencies', 'sources', 'source_identities', 'progress', 'native_owner'):
        if field in value: value[field] = host.normalize(host.as_dict(value[field]))
    if 'abi' in value:
        for field in ('protocol', 'pointer_bits', 'cpp_standard'): value['abi'][field] = int(value['abi'][field])
    if 'parameters' in value:
        value['parameters'] = {str(k): host.normalize(host.as_dict(v)) for k,v in host.as_dict(value['parameters']).items()}
    if 'result_typed' in value:
        value['result'] = json.loads(str(host.call('::GX::nativeWorkspaceJsonEncode', value.pop('result_typed'))))
    return host.normalize(value)


def invoke(host, operation, args):
    if operation not in ARGUMENTS or (len(args) != len(ARGUMENTS[operation]) and not (operation=='prepare' and len(args)==3)):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid native Job operation arguments')
    if operation == 'info':
        result = host.as_dict(host.call('::GX::nativeJobApiInfo'))
        for field in ('operations', 'host_only_operations'): result[field] = list(map(str, host.as_list(result[field])))
        result['api_version'] = int(result['api_version'])
        return host.normalize(result)
    module = _module(host)
    if operation == 'describe': return _receipt(host, host.call('::GX::nativeJobDescribe', module, args[0]))
    if operation == 'prepare':
        if not isinstance(args[1], dict) or not isinstance(args[2], dict):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native parameters/options require typed objects')
        resources = args[3] if len(args)==4 else {}
        if not isinstance(resources,dict):raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Native resources require a logical Document resource mapping')
        return str(host.call('::GX::nativeJobPrepare', module, *args[:3], resources))
    if operation == 'submit': return _receipt(host, host.call('::GX::nativeJobSubmitOwned', module, args[0]))
    if operation == 'events':
        if any(type(v) is not int for v in args[1:]):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native event cursor/page require integers')
        values = host.as_list(host.call('::GX::nativeJobEvents', *args, module))
        events = []
        for raw in values:
            event = _receipt(host, raw)
            event['sequence'] = int(event['sequence']);event['timestamp'] = float(event['timestamp'])
            for field in ('terminal', 'cancel_requested'): event[field] = bool(int(event[field]))
            if 'fraction' in event.get('progress', {}): event['progress']['fraction'] = float(event['progress']['fraction'])
            events.append(event)
        return events
    if operation == 'read_buffer':
        from gxtxt_native_job import validate_descriptor_metadata,owned_buffer
        from gxtxt_script_bridge_server import ResourceNumericArray
        job_id,resource_id=args
        raw=host.call('::GX::nativeJobResult',job_id,module)
        result=_receipt(host,raw)['result'];matches=[]
        def visit(value):
            if isinstance(value,dict):
                if value.get('schema')=='gxtxt.viewer_bridge_buffer.v1' and value.get('descriptor',{}).get('resource_id')==resource_id:matches.append(value)
                else:
                    for child in value.values():visit(child)
            elif isinstance(value,list):
                for child in value:visit(child)
        visit(result)
        if not matches:raise BridgeError('GXTXT:ScriptBridge:Ownership','Native buffer does not belong to the completed source Job')
        item=matches[0];descriptor=dict(item['descriptor']);validate_descriptor_metadata(descriptor)
        root=os.environ.get('GXTXT_BRIDGE_WORKSPACE')
        if not root or os.environ.get('GXTXT_BRIDGE_TYPED_DESCRIPTORS')!='1':raise BridgeError('GXTXT:ScriptBridge:Transport','Native typed buffer read requires the existing managed descriptor-capable Bridge client')
        root=Path(root)
        if not root.is_dir() or any(path.is_symlink() for path in (root,*root.parents)):raise BridgeError('GXTXT:ScriptBridge:Ownership','Unsafe managed Bridge buffer scope')
        manifest=host.as_dict(host.call('::GX::scientificExecutionOutputs',job_id))
        outputs=[host.as_dict(v) for v in host.as_list(manifest['outputs'])]
        output=next((v for v in outputs if str(v['role'])==item['output_role']),None)
        if output is None or int(output['size_bytes'])!=descriptor['byte_count']:raise BridgeError('GXTXT:ScriptBridge:Ownership','Native retained output size/role mismatch')
        descriptor['resource_id']=uuid.uuid4().hex+'.bin';target=root/descriptor['resource_id']
        offset=0;generation=output['source_generation'];digest=hashlib.sha256()
        with target.open('xb') as stream:
            while offset<descriptor['byte_count']:
                page=host.as_dict(host.call('::GX::scientificExecutionReadOutput',job_id,output['token'],offset,min(1048576,descriptor['byte_count']-offset),generation))
                data=base64.b64decode(str(page['bytes_base64']),validate=True)
                if not data or int(page['next_offset'])!=offset+len(data):raise BridgeError('GXTXT:ScriptBridge:Transport','Native output read did not advance coherently')
                stream.write(data);digest.update(data);offset+=len(data)
        if digest.hexdigest()!=item.get('sha256'):raise BridgeError('GXTXT:ScriptBridge:Ownership','Native output buffer changed since completed result publication')
        fd,_,_=owned_buffer(root,descriptor);os.close(fd)
        return dict(values=ResourceNumericArray.from_descriptor(root,descriptor),dtype=descriptor['dtype'],shape=descriptor['shape'],
                    units=item.get('units',''),job_id=job_id,source_resource=item.get('source_resource',{}),source_identities=_receipt(host,raw).get('source_identities',{}))
    command = {'status':'::GX::nativeJobStatus','cancel':'::GX::nativeJobCancel',
               'result':'::GX::nativeJobResult','reconnect':'::GX::nativeJobReconnect'}[operation]
    return _receipt(host, host.call(command, args[0], module))
