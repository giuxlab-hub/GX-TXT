"""Inert installed managed-Preview metadata; development execution stays hosted."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
import re

REGISTRATION={
    'api_id':'VIEWER_DEVELOPMENT_API_v1','api_version':1,
    'provider_kind':'core','provider_id':'viewer_development',
    'documentation_ref':'docs/api/VIEWER_DEVELOPMENT_API_v1.md',
    'operations':{'preview_tabs':{
        'name':'preview_tabs','summary':'Read eligible inert tab IDs from an installed managed Preview and canonical Dataset',
        'host_command':'::GX::viewerDevelopmentPreviewTabs',
        'arguments':[{'name':'module_id','kind':'installed Preview module ID','required':True},
                     {'name':'dataset_id','kind':'current Session canonical Dataset ID','required':True}],
        'argument_convention':'module_id, dataset_id; source root and Session are assigned by existing owners',
        'result_contract':'ordered tab ID/label/kind records; no source paths, mounting, callbacks or worker launch'}}}
REGISTRATION['operations']['maintenance_modules']={
    'name':'maintenance_modules','summary':'Read original eligible installed Viewer maintenance metadata',
    'host_command':'::GX::viewerDevelopmentMaintenanceModules','arguments':[],
    'argument_convention':'no arguments',
    'result_contract':'Module-keyed original provider/name/backend records; no project creation, paths or invocation authority'}


def invoke(host,operation,args):
    if operation=='maintenance_modules':
        if args:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Installed maintenance metadata takes no arguments')
        rows=host.as_dict(host.call('::GX::viewerDevelopmentMaintenanceModules'))
        return {'modules':{str(module):{key:str(host.as_dict(row)[key]) for key in ('provider','name','backend')}
                           for module,row in rows.items()}}
    if operation!='preview_tabs':
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
    if len(args)!=2 or any(not isinstance(value,str) for value in args):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Preview tabs require installed module and canonical Dataset IDs')
    module,dataset=args
    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.-]{0,127}',module):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Preview tabs require installed module and canonical Dataset IDs')
    try:
        canonical_dataset=str(host.call('::GX::datasetPublicationV2ValidateId','dataset',dataset))
    except Exception:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Preview tabs require installed module and canonical Dataset IDs') from None
    if canonical_dataset!=dataset:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Preview tabs require installed module and canonical Dataset IDs')
    # Presentation enablement is independent of installed inert metadata. The
    # existing owner checks the installed Preview and declared managed runtime.
    if str(host.call('::GX::moduleField',module,'kind',''))!='preview':
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Preview metadata requires an installed Preview module')
    if not str(host.call('::GX::datasetField',dataset,'id','')):
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Preview metadata requires a canonical Dataset in this execution Session')
    descriptor=host.call('::GX::moduleField',module,'descriptor','')
    root=host.tcl.call('file','dirname',descriptor)
    result=host.as_dict(host.call('::GX::viewerDevelopmentPreviewTabs',module,root,{'dataset_id':dataset}))
    return {'tabs':[{str(key):str(value) for key,value in host.as_dict(tab).items()}
                    for tab in host.as_list(result['tabs'])]}
