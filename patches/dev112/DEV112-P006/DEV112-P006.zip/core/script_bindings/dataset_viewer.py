"""Read-only Dataset viewer dispatch discovery for researcher scripts."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
REGISTRATION = {
    'api_id': 'DATASET_VIEWER_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'dataset_viewer',
    'documentation_ref': 'docs/api/DATASET_VIEWER_API_v1.md',
    'operations': {'describe': {'name': 'describe',
        'summary': 'Resolve canonical contract, format and CORE consultation target',
        'arguments': [{'name': 'request', 'kind': 'struct', 'required': True}],
        'argument_convention': 'request struct', 'result_contract': 'read-only dispatch descriptor',
        'result_convention': 'struct'}}}
REGISTRATION['operations']['reference'] = {
    'name': 'reference', 'summary': 'Read the existing canonical Dataset reference without its Session path',
    'host_command': '::GX::datasetViewerReference',
    'arguments': [{'name': 'request', 'kind': 'struct containing only dataset_id', 'required': True}],
    'argument_convention': 'request struct; the execution Session supplies scope',
    'result_contract': 'Original kind, Dataset ID, payload revision/SHA and contract; no Session path, viewer handle or opening action',
    'full_raw_equivalence': False,
}
def invoke(host, operation, args):
    if operation == 'reference':
        if (len(args) != 1 or not isinstance(args[0], dict) or set(args[0]) != {'dataset_id'} or
                not isinstance(args[0]['dataset_id'], str) or not 1 <= len(args[0]['dataset_id']) <= 512):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'reference requires only a canonical Dataset ID')
        result = host.as_dict(host.call('::GX::datasetViewerReference', args[0]['dataset_id']))
        return {key: str(host.tcl.call('format', '%s', result[key]))
                for key in ('kind', 'dataset_id', 'revision', 'sha256', 'contract')}
    if operation != 'describe' or len(args) != 1 or not isinstance(args[0], dict):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'describe requires {dataset_id: ...}')
    result = host.as_dict(host.call('::GX::datasetViewerDescribe', args[0]['dataset_id']))
    for key in ('read_only', 'implicit_publication'):
        result[key] = bool(int(result[key]))
    return result
