"""Installed restricted Viewer action declarations without executable prefixes."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    'api_id':'RESTRICTED_VIEWER_CLIENT_API_v1', 'api_version':1,
    'provider_kind':'core', 'provider_id':'restricted_viewer_metadata',
    'documentation_ref':'docs/api/RESTRICTED_VIEWER_CLIENT_API_v1.md',
    'operations': {
        'providers': {'name':'providers','summary':'Discover installed restricted Viewer metadata owners',
            'arguments':[], 'result_contract':'Actual installed module/provider identities; no activation'},
        'handlers': {'name':'handlers','summary':'Read installed Viewer action declarations',
            'arguments':[{'name':name,'kind':'installed identity','required':True} for name in ('module_id','provider_id')],
            'host_command':'::GX::viewerDevelopmentInstalledBindings',
            'result_contract':'Module/provider and ordered action IDs with command/enabled presence; executable prefixes remain with the original owner'},
    },
}

REGISTRATION['operations']['handler_values'] = {
    'name': 'handler_values', 'summary': 'Read complete inert installed Viewer handler dictionaries',
    'arguments': [{'name': name, 'kind': 'installed identity', 'required': True}
                  for name in ('module_id', 'provider_id')],
    'host_command': '::GX::viewerDevelopmentInstalledBindings',
    'result_contract': 'Original action-to-field dictionary with exact Tcl UTF8 scalar text; command text is data and grants no invocation or live Viewer authority',
}


def _providers(host):
    result=[]
    for module in host.as_list(host.tcl.getvar('::GX::moduleOrder')):
        module=str(module)
        if 'RESTRICTED_VIEWER_CLIENT_API_v1' not in host.as_list(host.call('::GX::modulePublicApiIds',module)):
            continue
        for provider in host.as_list(host.call('::GX::viewerProviderIds',module)):
            provider=str(provider)
            definition=host.as_dict(host.call('::GX::viewerProviderDefinition',module,provider,1))
            if definition['activation_api']=='RESTRICTED_VIEWER_CLIENT_API_v1':
                result.append({'module_id':module,'provider_id':provider})
    return result


def invoke(host,operation,args):
    if operation == 'handler_values':
        return _handler_values(host, args)
    if operation=='providers' and not args:
        return _providers(host)
    if operation!='handlers' or len(args)!=2 or any(not isinstance(v,str) for v in args):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Choose an installed module/provider; no callback or source-root arguments exist')
    module,provider=args
    if {'module_id':module,'provider_id':provider} not in _providers(host):
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Unknown installed restricted Viewer metadata owner')
    descriptor=host.call('::GX::moduleField',module,'descriptor','')
    root=host.call('file','dirname',descriptor)
    raw=host.call('::GX::viewerDevelopmentInstalledBindings',module,provider,root)
    handlers=[]
    for action,value in host.as_dict(raw).items():
        fields=host.as_dict(value)
        handlers.append({'action_id':str(action),'command_declared':bool(host.as_list(fields.get('command',''))),
                         'enabled_declared':bool(host.as_list(fields.get('enabled','')))})
    return {'module_id':module,'provider_id':provider,'handlers':handlers}


def _handler_values(host, args):
    if len(args) != 2 or any(not isinstance(value, str) for value in args):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Choose an installed module/provider; no callback, command or source-root arguments exist')
    module, provider = args
    if {'module_id': module, 'provider_id': provider} not in _providers(host):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Unknown installed restricted Viewer metadata owner')
    descriptor = host.call('::GX::moduleField', module, 'descriptor', '')
    root = host.call('file', 'dirname', descriptor)
    raw = host.call('::GX::viewerDevelopmentInstalledBindings', module, provider, root)
    text = lambda value: str(host.tcl.call('format', '%s', value))
    return {text(action): {text(field): text(value) for field, value in host.as_dict(fields).items()}
            for action, fields in host.as_dict(raw).items()}
