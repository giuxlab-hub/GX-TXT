"""Script-safe operations owned by CORE public service providers.

Each entry binds a named public operation to a fixed public Tcl procedure.
Research scripts never provide a procedure name or filesystem implementation path.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
import uuid


def _api(api_id, version, provider, documentation, operations):
    return {"api_id": api_id, "api_version": version, "provider_kind": "core",
            "provider_id": provider, "documentation_ref": documentation,
            "operations": {name: {"name": name, "summary": summary,
                                  "arguments": arguments, "result_contract": result,
                                  "argument_convention": ", ".join(a["name"] for a in arguments) or "no arguments",
                                  "result_convention": result}
                           for name, (summary, arguments, result, *_rest) in operations.items()}}


def _arg(name, kind, required=True):
    return {"name": name, "kind": kind, "required": required}


# Operation tuples: summary, argument schema, result, public command, conversion.
SERVICES = {
    "SOURCE_NOTE_API_v1": (1, "source_note", "docs/api/SOURCE_NOTE_API_v1.md", {
        "association": ("Inspect a canonical document's validated source association", [_arg("dataset_id", "string")], "source association and availability; never creates an attachment", "::GX::sourceNoteAssociation", "source_note"),
        "source": ("Consult an associated source only when its exact identity and revision remain valid", [_arg("dataset_id", "string")], "bounded source text or explicit unavailable/revised diagnostic", "::GX::sourceNoteSource", "source_note"),
    }),
    "DOCUMENT_SOURCE_API_v1": (1, "document_source", "docs/api/DOCUMENT_SOURCE_API_v1.md", {
        name: (summary, [_arg("request", "struct")], "guarded Markdown document receipt with opaque revision and exact UTF-8 source",
               "::GX::documentSourceRequest", "document_request")
        for name, summary in {
            "describe": "Read canonical Markdown identity/permissions or current empty publication context",
            "read": "Read exact canonical Markdown UTF-8 bytes and optimistic revision",
            "write": "Create or explicitly replace an authorized Markdown Dataset with Session/revision/SHA guards",
        }.items()
    }),
    "OBJECT_ORIGIN_API_v1": (1, "object_origin", "docs/api/OBJECT_ORIGIN_API_v1.md", {
        "document": ("Read scientific document creator", [_arg("document_id", "string")], "origin dictionary", "::GX::documentOriginRead", "origin"),
        "dataset": ("Read Dataset publication creator", [_arg("dataset_id", "string")], "origin dictionary", "::GX::datasetOriginRead", "origin"),
        "resource": ("Read managed resource declared creator", [_arg("resource", "struct")], "origin dictionary", "::GX::resourceOriginRead", "origin"),
        "session": ("Read current Session/Experiment declared creator and lineage", [], "origin dictionary with ordered import events", "::GX::sessionOriginRead", "origin"),
        "project": ("Read Project declared creator and lineage", [_arg("project_id", "string")], "origin dictionary", "::GX::projectOriginRead", "origin"),
    }),
    "INSTALLATION_IDENTITY_API_v1": (1, "installation_identity", "docs/api/INSTALLATION_IDENTITY_API_v1.md", {
        "info": ("Read CORE installation identity, authority and recovery diagnostics", [], "identity dictionary; history serialized as Tcl list", "::GX::installationIdentityInfo", "dict"),
        "current": ("Read current installation serial", [], "installation serial", "::GX::installationIdentityCurrent", "string"),
        "history": ("Read retained local installation serial history", [], "ordered history dictionaries", "::GX::installationIdentityHistory", "identity_history"),
    }),
    "EXPERIMENT_DUPLICATION_POLICY_API_v1": (1, "experiment_duplication_policy", "docs/api/EXPERIMENT_DUPLICATION_POLICY_API_v1.md", {
        "info": ("Inspect optional declarative duplication capabilities", [], "capability dictionary", "::GX::experimentDuplicationPolicyInfo", "dict"),
        "module": ("Inspect a module optional policy and conservative fallback", [_arg("module_id", "string")], "policy validation dictionary", "::GX::experimentDuplicationPolicyModule", "dict"),
        "validate": ("Validate an optional flat INI descriptor", [_arg("descriptor", "struct")], "validation dictionary", "::GX::experimentDuplicationPolicyValidate", "dict"),
    }),
    "SESSION_EXPERIMENT_API_v1": (1, "session_experiment", "docs/api/SESSION_EXPERIMENT_API_v1.md", {
        "preparation": ("Read reusable unbound Experiment preparation", [], "preparation dictionary with serialized nested definitions", "::GX::sessionExperimentPreparationRead", "dict"),
    }),
    "SCIENTIFIC_RECIPE_API_v1": (1, "scientific_recipe", "docs/api/SCIENTIFIC_RECIPE_API_v1.md", {
        "data_decode": ("Decode a bounded inert versioned recipe envelope without executing or validating its owner's scientific payload", [_arg("encoded", "string"), _arg("expected_format", "string")], "dictionary with owner-specific nested data serialized", "::GX::scientificRecipeDataDecode", "dict"),
        "inspect": ("Inspect an inert recorded scientific recipe", [_arg("encoded", "string")], "recipe descriptor", "::GX::scientificRecipeInspect", "dict"),
        "validate": ("Validate required APIs, plugins, sources and complete geometry", [_arg("encoded", "string")], "validation receipt", "::GX::scientificRecipeValidate", "dict"),
        "proposal": ("Prepare a validated transactional Workbench replay proposal", [_arg("encoded", "string")], "structured action proposal", "::GX::scientificRecipeProposal", "recipe_proposal"),
    }),
    "TEMPORAL_SET_API_v1": (1, "temporal_set", "docs/api/TEMPORAL_SET_API_v1.md", {
        "create": ("Create a persistent Temporal Set", [_arg("definition", "struct")], "Set ID", "::GX::temporalSetCreate", "string"),
        "list": ("List Temporal Sets", [_arg("dataset_id", "string", False)], "cell of Set descriptors", "::GX::temporalSetList", "dict_list"),
        "read": ("Read a Temporal Set definition", [_arg("set_id", "string")], "Set struct", "::GX::temporalSetRead", "dict"),
        "resolve_info": ("Inspect resolved window count and source", [_arg("set_id", "string")], "resolution struct", "::GX::temporalSetResolveInfo", "dict"),
        "resolve_member": ("Resolve one window or segment", [_arg("set_id", "string"), _arg("index", "integer")], "member struct", "::GX::temporalSetResolveMember", "dict"),
        "update": ("Update a persistent Temporal Set", [_arg("set_id", "string"), _arg("changes", "struct")], "Set struct", "::GX::temporalSetUpdate", "dict"),
        "delete": ("Delete a Temporal Set", [_arg("set_id", "string")], "Set ID", "::GX::temporalSetDelete", "string"),
        "resolve": ("Resolve all Temporal Set members", [_arg("set_id", "string")], "resolution struct", "::GX::temporalSetResolve", "dict"),
    }),
    "VIEWER_PROVIDER_API_v1": (1, "viewer_provider", "docs/api/VIEWER_PROVIDER_API_v1.md", {
        "providers": ("List enabled Viewer providers", [], "cell of provider structs", "::GX::viewerProviderList", "dict_list"),
        "scene_set": ("Set persistent scene presentation", [_arg("module_id", "string"), _arg("viewer_id", "string"), _arg("fields", "struct")], "scene struct", "::GX::viewerSceneSet", "dict"),
        "scene_get": ("Read persistent scene presentation", [_arg("module_id", "string"), _arg("viewer_id", "string")], "scene struct", "::GX::viewerSceneGet", "dict"),
        "layer_set": ("Set a persistent scientific layer", [_arg("module_id", "string"), _arg("viewer_id", "string"), _arg("layer_id", "string"), _arg("fields", "struct")], "layer struct", "::GX::viewerLayerSet", "dict"),
        "layer_get": ("Read a persistent scientific layer", [_arg("module_id", "string"), _arg("viewer_id", "string"), _arg("layer_id", "string")], "layer struct", "::GX::viewerLayerGet", "dict"),
        "layer_ids": ("List scene layer IDs", [_arg("module_id", "string"), _arg("viewer_id", "string")], "cell of IDs", "::GX::viewerLayerIds", "list"),
    }),
    "SESSION_INSPECTION_API_v1": (1, "session_inspection", "docs/api/SESSION_INSPECTION_API_v1.md", {
        "summary": ("Inspect current Session", [], "summary struct", "::GX::sessionInspectionSummary", "dict"),
        "dataset_ids": ("List current Session Dataset IDs", [], "cell of IDs", "::GX::sessionInspectionDatasetIds", "list"),
        "dataset": ("Inspect one Dataset identity and provenance", [_arg("dataset_id", "string")], "Dataset identity struct", "::GX::sessionInspectionDataset", "safe_dataset"),
        "dataset_location": ("Inspect guarded Dataset availability without reading payload bytes", [_arg("dataset_id", "string")], "availability struct without absolute storage path", "::GX::sessionInspectionDatasetLocation", "safe_dataset_location"),
        "selection_ids": ("List current Session Selection IDs", [], "cell of IDs", "::GX::sessionInspectionSelectionIds", "list"),
    }),
    "SESSION_PERSISTENCE_API_v1": (1, "session_persistence", "docs/api/SESSION_PERSISTENCE_API_v1.md", {
        "commit": ("Commit framework-owned current Session state", [], "commit struct without storage path", "::GX::sessionPersistenceCommit", "safe_commit"),
    }),
    "PARALLEL_EXECUTION_API_v1": (1, "parallel_execution", "docs/api/PARALLEL_EXECUTION_API_v1.md", {
        "api_info": ("Inspect parallel resource and ordering policy", [], "policy struct", "::GX::parallelExecutionApiInfo", "dict"),
        "resources": ("Read allowed parallel resource policy", [], "policy struct", "::GX::parallelExecutionConfigure", "dict"),
    }),
    "PROGRESS_API_v1": (1, "progress", "docs/api/PROGRESS_API_v1.md", {
        "publish": ("Publish a structured progress event", [_arg("event", "struct")], "event struct", "::GX::progressPublish", "dict"),
    }),
    "INTERACTIVE_DOCUMENT_API_v1": (1, "interactive_document", "docs/api/INTERACTIVE_DOCUMENT_API_v1.md", {
        "list": ("List persistent Interactive Documents", [], "cell of document structs", "::GX::interactiveDocumentList", "dict_list"),
        "read": ("Read a persistent Interactive Document", [_arg("document_id", "string")], "document metadata and exact inert UTF-8 payload text", "::GX::interactiveDocumentRead", "document_read"),
        "exists": ("Check a canonical Document identity in the execution Session", [_arg("document_id","string")], "boolean existence", "::GX::interactiveDocumentExists", "boolean"),
        "read_cached": ("Read checked stored Document bytes through its derived process cache", [_arg("document_id","string"),_arg("include_payload","boolean",False)], "closed metadata and optional inert owner payload text; native typed graphs use NATIVE_WORKSPACE_API_v1", "::GX::interactiveDocumentReadCached", "document_cache"),
        "metadata_batch": ("Read bounded canonical Document metadata without payload reads", [_arg("documents","list")], "Document ID to closed metadata", "::GX::interactiveDocumentMetadataBatch", "document_cache"),
        "source_identities": ("Read bounded path-free checked canonical Document source identities", [_arg("documents","list")], "Document ID to closed metadata and exact source identity integers", "::GX::interactiveDocumentSourceIdentities", "document_cache"),
        "cache_status": ("Read this Bridge execution's derived Document cache counters", [], "cache counters without Session token or raw fallback errors", "::GX::interactiveDocumentCacheStatus", "document_cache"),
        "cache_configure": ("Set bounded byte/entry policy for this execution's derived cache", [_arg("options","struct")], "source-owned cache counters and policy", "::GX::interactiveDocumentCacheConfigure", "document_cache"),
        "cache_clear": ("Discard only this execution's derived checked Document cache", [], "cleared true; scientific_mutation false", "::GX::interactiveDocumentCacheClear", "document_cache"),
        "tex_info": ("Inspect the existing inert TeX profile contract and bounds", [], "TeX profile metadata; raw host operations are not worker grants", "::GX::interactiveDocumentTeXApiInfo", "tex_profile"),
        "tex_create": ("Create an empty article through an installed TeX Workspace provider", [_arg("provider_id","string"),_arg("name","string")], "canonical native receipt and explicit typed article projection", "::GX::interactiveDocumentTeXCreate", "tex_profile"),
        "tex_read": ("Read canonical article resources and revision without host compiler diagnostics", [_arg("document_id","string")], "native receipt and explicit typed canonical article projection; not the full raw host payload", "::GX::interactiveDocumentTeXRead", "tex_profile"),
        "tex_read_source": ("Read exact checked UTF-8 source from the article's owned Resource", [_arg("document_id","string")], "exact inert UTF-8 source text", "::GX::interactiveDocumentTeXReadSource", "tex_profile"),
        "tex_status": ("Read closed article revision/PDF status and this execution's pending state", [_arg("document_id","string")], "closed status; pending scope current Bridge execution; no raw worker response or paths", "::GX::interactiveDocumentTeXStatus", "tex_profile"),
        "tex_save": ("Save exact source and same-article canonical assets with a held native receipt", [_arg("expected","struct"),_arg("source","string"),_arg("assets","struct")], "canonical native CAS receipt and typed article projection; no caller History or callbacks", "::GX::interactiveDocumentTeXSave", "tex_profile"),
    }),
    "PROJECT_API_v1": (1, "project", "docs/api/PROJECT_API_v1.md", {
        "list": ("List Project IDs", [], "cell of IDs", "::GX::projectIds", "list"),
        "get": ("Read Project metadata", [_arg("project_id", "string")], "Project struct without storage path", "::GX::projectGet", "safe_project"),
        "organization_info": ("Inspect owning organization contract and per-operation host-only reasons", [], "typed organization metadata", "::GX::projectOrganizationApiInfo", "project_organization_info"),
        "organization_generation": ("Read current organization generation without a write grant", [], "integer generation", "::GX::projectOrganizationGeneration", "integer"),
        "namespace_list": ("Read global Project namespace identities and names", [], "namespace ID to name map", "::GX::projectNamespaceList", "project_namespace_map"),
        "session_namespace_list": ("Read a Project's Session namespace identities and names", [_arg("project_id", "string")], "namespace ID to name map", "::GX::projectSessionNamespaceList", "project_namespace_map"),
        "organization_catalog": ("Read organization hierarchy without opening or moving a Session", [_arg("query", "string", False)], "generation and typed hierarchy rows; no filesystem paths", "::GX::projectOrganizationCatalog", "project_organization_catalog"),
        "organization_capture": ("Capture a stable generation-guarded Project/Experiment identity without moving it", [_arg("node", "string")], "inert organization capture; no write authority", "::GX::projectOrganizationCapture", "project_organization_capture"),
    }),
    "SEMANTIC_REGISTRY_API_v1": (1, "semantic_registry", "docs/api/SEMANTIC_REGISTRY_API_v1.md", {
        "list": ("List public semantic IDs", [], "cell of IDs", "::GX::semanticRegistryList", "list"),
        "definition": ("Read public semantic definition", [_arg("semantic_id", "string")], "semantic struct", "::GX::semanticRegistryDefinition", "dict"),
    }),
    "DOCUMENTATION_BROWSER_API_v1": (1, "documentation_browser", "docs/api/DOCUMENTATION_BROWSER_API_v1.md", {
        "api_info": ("Read exact original Documentation Browser contract metadata", [], "api_name, integer api_version, source and ordered host_operations", "::GX::documentationBrowserApiInfo", "doc_browser_info"),
        "list": ("Discover public documentation entries", [_arg("query", "string", False)], "cell of document descriptors without paths", "::GX::documentationBrowserList", "safe_doc_list"),
        "read": ("Read public documentation", [_arg("document_id", "string")], "UTF-8 text", "::GX::documentationBrowserRead", "string"),
        "resolve": ("Resolve an indexed document to checked public source metadata", [_arg("document_id", "string")], "closed pathless document source descriptor", "::GX::documentationBrowserResolve", "safe_doc_resolve"),
        "module_tutorials": ("Discover this module's indexed tutorials", [_arg("module_id", "string")], "closed pathless tutorial descriptor list", "::GX::documentationBrowserModuleTutorials", "safe_doc_tutorials"),
    }),
    "MODULE_API_v1": (1, "module", "docs/api/MODULE_API_v1.md", {
        "analysis_capabilities": ("Discover targeted Standard Analysis admission without submitting to a detached queue", [_arg("module_id", "string")], "capability struct", "::GX::moduleAnalysisCapabilities", "dict"),
        "operational_class": ("Read operational module class independently of package protection", [_arg("module_id", "string")], "operational class", "::GX::moduleOperationalClass", "string"),
        "operational_info": ("Inspect availability, analysis eligibility and package protection", [_arg("module_id", "string")], "typed module classification", "::GX::moduleOperationalInfo", "module_info"),
        "public_api_ids": ("Discover module-declared public API IDs", [_arg("module_id", "string")], "cell of API IDs", "::GX::modulePublicApiIds", "list"),
    }),
    "GRAPH_SERIES_API_v1": (1, "graph_series", "docs/api/GRAPH_SERIES_API_v1.md", {
        "set": ("Set persistent graph series", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("series_id", "string"), _arg("fields", "struct"), _arg("variant_id", "string", False)], "series struct", "::GX::graphSeriesSet", "safe_series"),
        "list": ("List persistent graph series", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False), _arg("include_disabled", "integer", False)], "cell of series structs", "::GX::graphSeriesList", "safe_series_list"),
        "resolve": ("Resolve graph series", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("series_id", "string"), _arg("variant_id", "string", False)], "series struct", "::GX::graphSeriesResolve", "safe_series"),
        "remove": ("Remove graph series", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("series_id", "string"), _arg("variant_id", "string", False)], "empty", "::GX::graphSeriesRemove", "empty"),
        "ids": ("List series IDs", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False)], "cell of IDs", "::GX::graphSeriesIds", "list"),
        "move": ("Move series order", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("series_id", "string"), _arg("delta", "integer"), _arg("variant_id", "string", False)], "cell of IDs", "::GX::graphSeriesMove", "list"),
        "snapshot": ("Read persistent series state", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("series_id", "string"), _arg("variant_id", "string", False)], "series struct", "::GX::graphSeriesSnapshot", "safe_series"),
        "expand_groups": ("Create grouped graph series", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("dataset_id", "string"), _arg("x_variable_id", "string"), _arg("y_variable_id", "string"), _arg("group_variable_id", "string"), _arg("options", "struct", False), _arg("variant_id", "string", False)], "cell of member structs", "::GX::graphSeriesExpandGroups", "dict_list"),
    }),
    "GRAPH_WORKFLOW_API_v1": (1, "graph_workflow", "docs/api/GRAPH_WORKFLOW_API_v1.md", {
        "axis_snapshot": ("Read axis state", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False)], "axis struct", "::GX::graphAxisConfigSnapshot", "dict"),
        "presentation_set": ("Set graph aspect/background presentation", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("changes", "struct")], "axis struct", "::GX::graphAxisPresentationSet", "dict"),
        "use_get": ("Read graph USE state", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False)], "boolean", "::GX::graphUseStateGet", "integer"),
        "use_set": ("Set graph USE state", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("value", "integer")], "boolean", "::GX::graphUseStateSet", "integer"),
        "scheduled_graph_ids": ("List scheduled graph IDs", [_arg("module_id", "string")], "cell of IDs", "::GX::scheduledModuleGraphIds", "list"),
    }),
    "PLOT_ANNOTATION_API_v1": (1, "plot_annotation", "docs/api/PLOT_ANNOTATION_API_v1.md", {
        "info": ("Read graph annotation capability", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False)], "capability struct", "::GX::plotAnnotationInfo", "dict"),
        "read": ("Read graph annotation document", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False)], "annotation document", "::GX::plotAnnotationRead", "dict"),
        "validate": ("Validate annotation objects", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("objects", "list")], "normalized objects", "::GX::plotAnnotationValidate", "dict_list"),
        "add": ("Add one annotation", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("object", "struct")], "annotation document", "::GX::plotAnnotationAdd", "dict"),
        "update": ("Update annotation by ID", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("annotation_id", "string"), _arg("changes", "struct")], "annotation document", "::GX::plotAnnotationUpdate", "dict"),
        "remove": ("Remove annotation by ID", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("annotation_id", "string")], "annotation document", "::GX::plotAnnotationRemove", "dict"),
        "replace": ("Replace annotation objects atomically", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("objects", "list")], "annotation document", "::GX::plotAnnotationReplace", "dict"),
        "clear": ("Clear graph annotations", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string", False)], "annotation document", "::GX::plotAnnotationClear", "dict"),
        "set_enabled": ("Enable or disable annotation layer", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("enabled", "integer")], "annotation document", "::GX::plotAnnotationSetEnabled", "dict"),
    }),
    "GRAPH_NOTES_API_v1": (1, "graph_notes", "docs/api/GRAPH_NOTES_API_v1.md", {
        "info": ("Inspect one graph note", [_arg("graph_ref", "struct")], "note info", "::GX::graphNotesInfo", "dict"),
        "exists": ("Check graph note existence", [_arg("graph_ref", "struct")], "boolean", "::GX::graphNotesExists", "integer"),
        "read": ("Read graph Markdown note", [_arg("graph_ref", "struct")], "UTF-8 Markdown", "::GX::graphNotesRead", "string"),
        "write": ("Write graph Markdown note", [_arg("graph_ref", "struct"), _arg("markdown", "string")], "note info", "::GX::graphNotesWrite", "dict"),
        "clear": ("Remove graph Markdown note", [_arg("graph_ref", "struct")], "note info", "::GX::graphNotesClear", "dict"),
    }),
    "GRAPH_METADATA_API_v1": (1, "graph_metadata", "docs/api/GRAPH_METADATA_API_v1.md", {
        "info": ("Inspect graph metadata resource", [_arg("graph_ref", "struct")], "metadata info", "::GX::graphMetadataInfo", "dict"),
        "read": ("Read graph metadata", [_arg("graph_ref", "struct")], "metadata struct", "::GX::graphMetadataRead", "dict"),
        "write": ("Replace graph metadata", [_arg("graph_ref", "struct"), _arg("metadata", "struct")], "metadata struct", "::GX::graphMetadataWrite", "dict"),
        "update": ("Merge graph metadata", [_arg("graph_ref", "struct"), _arg("changes", "struct")], "metadata struct", "::GX::graphMetadataUpdate", "dict"),
        "unset": ("Remove graph metadata keys", [_arg("graph_ref", "struct"), _arg("keys", "list")], "metadata struct", "::GX::graphMetadataUnset", "dict"),
    }),
    "LEVEL_SCALE_API_v1": (1, "level_scale", "docs/api/LEVEL_SCALE_API_v1.md", {
        "get": ("Read level scale presentation", [_arg("graph_id", "string"), _arg("axis", "string")], "level scale struct", "::GX::levelScaleGet", "dict"),
        "set": ("Set level scale presentation", [_arg("graph_id", "string"), _arg("axis", "string"), _arg("fields", "struct")], "level scale struct", "::GX::levelScaleSet", "dict"),
    }),
    "CONTRACT_REGISTRY_API_v1": (1, "contract_registry", "docs/api/CONTRACT_REGISTRY_API_v1.md", {
        "describe": ("Inspect authoritative contract owners and declared visualizer recommendations", [_arg("contract_id", "string")], "contract definition status and recommendations", "::GX::contractRegistryDescribe", "dict"),
        "list": ("List contract IDs", [], "cell of IDs", "::GX::contractRegistryIds", "list"),
        "known": ("Check a contract ID", [_arg("contract_id", "string")], "boolean", "::GX::contractRegistryKnown", "integer"),
        "field": ("Read a contract field", [_arg("contract_id", "string"), _arg("field", "string"), _arg("default", "string", False)], "field value", "::GX::contractRegistryField", "string"),
        "choices": ("List contract choices", [], "cell of choices", "::GX::contractRegistryChoices", "list"),
        "satisfies": ("Check contract specialization", [_arg("actual", "string"), _arg("expected", "string")], "boolean", "::GX::contractSatisfies", "integer"),
        "satisfies_any": ("Check any expected contract", [_arg("actual", "string"), _arg("expected", "list")], "boolean", "::GX::contractSatisfiesAny", "integer"),
    }),
    "CONTRACT_VISUALIZER_API_v1": (1, "contract_visualizer", "docs/api/CONTRACT_VISUALIZER_API_v1.md", {
        "describe_registry": ("Describe installed contract owners, schema declarations and visualizer recommendations", [_arg("contract_id", "string")], "contract metadata with typed declaration and recommendation lists", "::GX::contractRegistryDescribe", "contract_registry_description"),
        "providers": ("Inspect installed declared visualizer capabilities", [], "provider records", "::GX::contractVisualizerProviders", "list"),
        "candidates": ("Inspect compatible Open or Preview providers", [_arg("contract_id", "string"), _arg("target", "string"), _arg("dataset_id", "string", False)], "compatible provider records", "::GX::contractVisualizerCandidates", "list"),
        "resolve": ("Resolve separate Open or embedded Preview preference", [_arg("contract_id", "string"), _arg("target", "string"), _arg("dataset_id", "string", False)], "resolution and diagnostics", "::GX::contractVisualizerResolve", "dict"),
        "preference_get": ("Read retained qualified provider preference", [_arg("contract_id", "string"), _arg("target", "string")], "qualified provider or auto", "::GX::contractVisualizerPreferenceGet", "string"),
        "preference_set": ("Commit compatible provider preference or Restore Auto", [_arg("contract_id", "string"), _arg("target", "string"), _arg("provider", "string")], "committed preference", "::GX::contractVisualizerPreferenceSet", "dict"),
    }),
    "PLOT_MODULE_API_v1": (1, "plot_module", "docs/api/PLOT_MODULE_API_v1.md", {
        "supports": ("Check variant support", [_arg("module_id", "string"), _arg("graph_id", "string")], "boolean", "::GX::plotVariantSupports", "integer"),
        "variant_ids": ("List persistent Variant IDs", [_arg("module_id", "string"), _arg("graph_id", "string")], "cell of IDs", "::GX::plotVariantIds", "list"),
        "variant_field": ("Read public Variant field", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string"), _arg("field", "string"), _arg("default", "string", False)], "field value", "::GX::plotVariantField", "string"),
        "variant_artifact": ("Read Variant artifact path", [_arg("module_id", "string"), _arg("graph_id", "string"), _arg("variant_id", "string")], "artifact path", "::GX::plotVariantArtifact", "string"),
    }),
}

_HISTORY_OPERATIONS = {
    'history_create': ('scientificHistoryCreate', [_arg('owner','string'),_arg('snapshot','struct')]),
    'history_validate': ('scientificHistoryValidate', [_arg('owner','string'),_arg('encoded_history','string')]),
    'history_state': ('scientificHistoryState', [_arg('encoded_history','string'),_arg('index','integer',False)]),
    'history_append': ('scientificHistoryAppend', [_arg('owner','string'),_arg('encoded_history','string'),_arg('snapshot','struct'),_arg('description','string')]),
    'history_navigate': ('scientificHistoryNavigate', [_arg('owner','string'),_arg('encoded_history','string'),_arg('index','integer')]),
    'history_branch': ('scientificHistoryBranch', [_arg('owner','string'),_arg('encoded_history','string'),_arg('index','integer')]),
    'history_strip_fields': ('scientificHistoryStripFields', []),
    'history_strip_validate': ('scientificHistoryStripValidate', [_arg('values','struct')]),
    'history_grouped_entries': ('scientificHistoryGroupedEntries', [_arg('encoded_history','string'),_arg('grouped','boolean',False)]),
    'history_drafts': ('scientificHistoryDrafts', [_arg('owner','string'),_arg('channel','string',False)]),
    'rebase': ('scientificRecipeRebase', [_arg('encoded_history','string'),_arg('current','struct'),_arg('context','struct')]),
    'geometry_state': ('scientificRecipeGeometryState', [_arg('encoded_history','string'),_arg('step_count','integer',False)]),
}
for _name, (_command, _arguments) in _HISTORY_OPERATIONS.items():
    SERVICES['SCIENTIFIC_RECIPE_API_v1'][3][_name] = (
        'Existing owner-neutral inert History operation: '+_name, _arguments,
        'Existing scientificRecipeEncode Base64 history text for record results; state dictionaries retain owner-defined nested values as opaque Tcl text; no replay or durable mutation',
        '::GX::'+_command, 'scientific_history')

SERVICES['DOCUMENT_SOURCE_API_v1'][3]['navigation_context'] = (
    'Read checked canonical Markdown or installed documentation link-base metadata',
    [_arg('kind','string'),_arg('identity','string')],
    'Source identity/SHA and opaque canonical revision; no filesystem root, callback or live Session Files browser context',
    '::GX::markdownNavigationContext', 'markdown_context')

REGISTRATIONS = [_api(api_id, version, provider, doc, operations)
                 for api_id, (version, provider, doc, operations) in SERVICES.items()]
for _descriptor in REGISTRATIONS:
    if _descriptor['api_id'] == 'SCIENTIFIC_RECIPE_API_v1':
        for _name, (_command, _arguments) in _HISTORY_OPERATIONS.items():
            _descriptor['operations'][_name]['host_command'] = '::GX::'+_command


def _origin_record(host, value, depth=0):
    if depth > 64:
        raise BridgeError("GXTXT:ScriptBridge:RemoteError", "Origin chain exceeds inspection depth")
    row = host.as_dict(value)
    parent = host.as_dict(row.get("parent", ""))
    if parent.get("origin_snapshot"):
        parent["origin_snapshot"] = _origin_record(host, parent["origin_snapshot"], depth + 1)
    row["parent"] = parent
    row["events"] = [host.as_dict(item) for item in host.as_list(row.get("events", ""))]
    return row


def _document_request(host, command, operation, request):
    """Opaque per-Host revision receipts hide internal Session/registry tokens.

    This is transient transport admission, never another document store. Every
    actual mutation still uses the existing Dataset transaction and capability.
    """
    context = host.dataset_private_context()
    session = str(host.call("::GX::interactiveDocumentSessionToken"))
    if getattr(host, "_document_revision_session", None) != session:
        host._document_revision_session = session
        host._document_revision_receipts = {}
    request = dict(request)
    for key in ("expected_revision", "source_revision"):
        if key in request:
            if not isinstance(request[key], str) or request[key] not in host._document_revision_receipts:
                raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Use an opaque document revision returned by describe/read in this Session")
            request[key] = host._document_revision_receipts[request[key]]
    raw = host.call(command, context["capability"], operation, request)
    result = host.as_dict(raw)
    revision = result.get("revision", "")
    if revision:
        token = next((key for key, value in host._document_revision_receipts.items() if value == revision), None)
        if token is None:
            if len(host._document_revision_receipts) >= 128:
                host._document_revision_receipts.pop(next(iter(host._document_revision_receipts)))
            token = "document-revision#" + uuid.uuid4().hex
            host._document_revision_receipts[token] = revision
        result["revision"] = token
    result["metadata"] = host.as_dict(result.get("metadata", ""))
    result["association"] = host.as_dict(result.get("association", ""))
    assets = {}
    for name, value in host.as_dict(result.get("assets", "")).items():
        resource = host.as_dict(value)
        resource["size_bytes"] = int(resource["size_bytes"])
        resource["metadata"] = host.as_dict(resource["metadata"])
        if "origin" in resource["metadata"]:
            resource["metadata"]["origin"] = _origin_record(host, resource["metadata"]["origin"])
        assets[name] = resource
    result["assets"] = assets
    for key in ("can_create", "can_replace", "immutable", "complete"):
        if key in result: result[key] = bool(int(result[key]))
    if "bytes" in result: result["bytes"] = int(result["bytes"])
    if operation == "write": return host.record_publications(result)
    return result


def invoke_api(host, api_id, operation, args):
    definition = SERVICES.get(api_id)
    if definition is None or operation not in definition[3]:
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", f"{api_id}/{operation} is unavailable")
    _, schema, _, command, conversion = definition[3][operation]
    minimum = sum(a["required"] for a in schema)
    if not minimum <= len(args) <= len(schema):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", f"{api_id}/{operation} expects {minimum} to {len(schema)} arguments")
    for value, arg in zip(args, schema):
        kind = arg["kind"]
        if kind == "string" and not isinstance(value, str) or kind == "struct" and not isinstance(value, dict) or kind == "list" and not isinstance(value, (list, tuple)):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", f"{api_id}/{operation}: {arg['name']} must be {kind}")
        if kind == "integer" and (not isinstance(value, (int, float)) or int(value) != value):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", f"{api_id}/{operation}: {arg['name']} must be integer")
        if kind == 'boolean' and not isinstance(value, bool):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', f'{api_id}/{operation}: {arg["name"]} must be boolean')
    if conversion == 'scientific_history':
        return _scientific_history(host, operation, command, schema, args)
    if conversion == 'document_cache':
        return _document_cache(host, operation, command, args)
    if conversion == 'document_read':
        return _document_metadata(host,host.call(command,*args))
    if conversion == 'tex_profile':
        return _tex_profile(host,operation,command,args)
    if conversion == 'markdown_context':
        return _markdown_context(host,command,args)
    if conversion == 'contract_registry_description':
        result = host.as_dict(host.call(command, *args))
        result['known'] = bool(host.tcl.getboolean(result['known']))
        for key in ('owners','parents','consumers','producers'):
            result[key] = [str(value) for value in host.as_list(result[key])]
        result['declarations'] = [host.as_dict(value) for value in host.as_list(result['declarations'])]
        for row in result['declarations']:
            if 'diagnostics' in row:
                row['diagnostics'] = [str(value) for value in host.as_list(row['diagnostics'])]
        result['recommendations'] = {str(key): [str(value) for value in host.as_list(values)]
                                     for key,values in host.as_dict(result['recommendations']).items()}
        return result
    if conversion == "document_request":
        return _document_request(host, command, operation, args[0])
    result = host.call(command, *args)
    if conversion == "source_note":
        result = host.as_dict(result)
        if "source_ref" in result:
            reference = host.as_dict(result["source_ref"])
            reference["reference"] = host.as_dict(reference["reference"])
            result["source_ref"] = reference
        return result
    if conversion == "origin":
        return _origin_record(host, result)
    if conversion == "identity_history":
        return [host.as_dict(item) for item in host.as_list(result)]
    if conversion == "recipe_proposal":
        result = host.as_dict(result)
        result["operations"] = [host.as_dict(item) for item in host.as_list(result["operations"])]
        result["warnings"] = host.as_list(result["warnings"])
        result["provenance"] = host.as_dict(result["provenance"])
        return result
    if (api_id == "GRAPH_SERIES_API_v1" and operation in {"set", "remove", "move", "expand_groups"} or
        api_id == "GRAPH_WORKFLOW_API_v1" and operation in {"use_set", "presentation_set"} or
        api_id == "PLOT_ANNOTATION_API_v1" and operation in {"add", "update", "remove", "replace", "clear", "set_enabled"} or
        api_id == "GRAPH_NOTES_API_v1" and operation in {"write", "clear"} or
        api_id == "GRAPH_METADATA_API_v1" and operation in {"write", "update", "unset"} or
        api_id == "LEVEL_SCALE_API_v1" and operation == "set"):
        host.persist_manifest(f"{api_id}/{operation}")
    if conversion == "module_info":
        result = host.as_dict(result)
        for key in ("core_protected", "always_available", "analysis_enableable", "run_eligible", "enabled"):
            result[key] = bool(int(result[key]))
        return result
    if conversion == "integer":
        return int(result)
    if conversion == 'boolean':
        return bool(host.tcl.getboolean(result))
    if conversion == "empty":
        return ""
    if conversion == "list":
        return host.as_list(result)
    if conversion == "dict_list":
        return [host.normalize(item) for item in host.as_list(result)]
    if conversion == "doc_browser_info":
        entry = host.as_dict(result)
        return {"api_name": str(entry["api_name"]), "api_version": int(entry["api_version"]),
                "source": str(entry["source"]), "host_operations": [str(item) for item in host.as_list(entry["host_operations"])]}
    if conversion == "safe_doc_resolve":
        entry = host.as_dict(result)
        return {key: entry[key] for key in
                ("id", "category", "title", "type", "owner", "version", "format", "source_sha256")}
    if conversion == "safe_doc_tutorials":
        return [{key: entry[key] for key in
                 ("id", "category", "title", "type", "owner", "version")}
                for entry in (host.as_dict(item) for item in host.as_list(result))]
    if conversion == "safe_doc_list":
        entries = [host.as_dict(item) for item in host.as_list(result)]
        for entry in entries:
            entry.pop("path", None)
        return entries
    if conversion == "safe_series_list":
        rows = [host.normalize(item) for item in host.as_list(result)]
        for row in rows:
            row.pop("path", None)
        return rows
    if conversion == "safe_series":
        row = host.normalize(result)
        row.pop("path", None)
        return row
    if conversion == "safe_commit":
        result = host.as_dict(result)
        result.pop("session", None)
        result.pop("manifest_path", None)
        return result
    if conversion == "safe_dataset_location":
        details = host.as_dict(result)
        details.pop("path", None)
        return details
    if conversion == "safe_dataset":
        details = host.as_dict(result)
        return {key: details.get(key, "") for key in ("id", "kind", "format", "row_count", "canonical_sha256", "source_sha256", "source_module", "created_at")}
    if conversion == "safe_project":
        details = host.as_dict(result)
        details.pop("storage_path", None)
        return details
    if conversion == "project_namespace_map":
        return {str(key): str(value) for key, value in host.as_dict(result).items()}
    if conversion == "project_organization_capture":
        details = {str(key): str(value) for key, value in host.as_dict(result).items()}
        details['generation'] = int(details['generation'])
        return details
    if conversion == "project_organization_catalog":
        details = host.as_dict(result)
        rows = {}
        for node, raw_row in host.as_dict(details['rows']).items():
            row = {str(key): str(value) for key, value in host.as_dict(raw_row).items()}
            row['count'] = int(row['count'])
            rows[str(node)] = row
        return {'generation': int(details['generation']), 'rows': rows}
    if conversion == "project_organization_info":
        details = host.as_dict(result)
        details['api_version'] = int(details['api_version'])
        details['physical_relocation'] = bool(int(details['physical_relocation']))
        details['operations'] = [str(value) for value in host.as_list(details['operations'])]
        details['script_host_only'] = {str(key): str(value) for key, value in host.as_dict(details['script_host_only']).items()}
        return details
    if conversion == "string":
        return str(result)
    return host.normalize(result)


def _markdown_context(host,command,args):
    kind,identity=args
    if kind not in {'documentation','dataset'} or not identity or len(identity)>1024:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Choose canonical Markdown or an indexed documentation identity')
    session=str(host.call('::GX::interactiveDocumentSessionToken'))
    description=None
    if kind=='dataset':
        description=_document_request(host,'::GX::documentSourceRequest','describe',{'dataset_id':identity})
    fields=host.as_dict(host.call(command,kind,identity,{}))
    if str(host.call('::GX::interactiveDocumentSessionToken'))!=session:
        raise BridgeError('GXTXT:ScriptBridge:StaleInput','Markdown context Session changed during source checks')
    source=[str(host.tcl.call('format','%s',value)) for value in host.as_list(fields['identity'])]
    result={key:str(fields[key]) for key in ('schema','kind','id')}
    if kind=='dataset':
        expected=str(host.tcl.call('format','%s',host._document_revision_receipts[description['revision']]))
        if len(source)!=3 or source[1]!=expected or source[2]!=description['sha256']:
            raise BridgeError('GXTXT:ScriptBridge:StaleInput','Canonical Markdown revision changed during source checks')
        result.update(scope='canonical_session_document',revision=description['revision'],source_sha256=source[2])
    else:
        if len(source)!=5:
            raise BridgeError('GXTXT:ScriptBridge:RemoteError','Malformed installed documentation identity')
        result.update(scope=str(fields['scope']),owner_id=source[1],version=source[2],
                      source_sha256=source[3],manifest_sha256=source[4])
    return result


def _tex_profile(host,operation,command,args):
    if operation=='tex_info':
        raw=host.as_dict(host.call(command))
        result={key:str(raw[key]) for key in ('api_id','profile','schema','compiler','build_owner_window','lifecycle')}
        for key in ('api_version','source_bytes_max','assets_max','implicit_dataset_publication'):result[key]=int(raw[key])
        result['operations']=[str(value) for value in host.as_list(raw['operations'])]
        return result
    if operation=='tex_create':
        descriptor=host.as_dict(host.call('::GX::_workspaceProvider',args[0]))
        if str(descriptor['schema'])!='gxtxt.tex_project.v1' or int(descriptor['version'])!=1:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Article creation requires an installed TeX Workspace provider')
    if operation=='tex_save':
        import math
        import re
        expected,source,assets=args
        if (set(expected)!={'id','generation','revision','sha256'} or
            any(not isinstance(expected[key],str) or not expected[key] for key in ('id','generation','sha256')) or
            not re.fullmatch('[a-f0-9]{64}',expected['sha256']) or
            isinstance(expected['revision'],bool) or not isinstance(expected['revision'],(int,float)) or
            not math.isfinite(expected['revision']) or not expected['revision']>=1 or int(expected['revision'])!=expected['revision']):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','TeX Save requires only held id/generation/integer revision/SHA-256')
        if len(source.encode('utf-8'))>16777216 or len(assets)>4095:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','TeX source/assets exceed existing owner bounds')
        for name,reference in assets.items():
            if not isinstance(name,str) or name=='main.tex' or not isinstance(reference,dict):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','TeX assets require explicit logical names and canonical Resource references')
            host.call('::GX::_interactiveDocumentTeXName',name)
            if (set(reference)!={'api_id','document_id','owner_generation','sha256','size_bytes','metadata'} or
                not isinstance(reference['metadata'],dict) or
                set(reference['metadata'])-{'format','media_type','encoding','role','filename','language','origin'} or
                any(not isinstance(value,str) for key,value in reference['metadata'].items() if key!='origin') or
                'filename' in reference['metadata'] and reference['metadata']['filename']!=name):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','TeX assets require closed canonical Resource identities and inert file metadata')
            if reference.get('document_id')!=expected['id'] or reference.get('owner_generation')!=expected['generation']:
                raise BridgeError('GXTXT:ScriptBridge:Ownership','TeX assets must belong to this exact article')
            if 'origin' in reference['metadata']:
                host.call('::GX::_nativeWorkspaceResourceOriginEncode',reference['metadata']['origin'])
            # Resolve the original immutable reference through its existing
            # owner, before admitting it to the article. No path is accepted.
            host.call('::GX::interactiveDocumentResourceInfo',reference)
        raw=host.call(command,expected['id'],source,assets,{},expected)
    else:
        raw=host.call(command,*args)
    if operation=='tex_read_source':return str(host.tcl.call('format','%s',raw))
    fields=host.as_dict(raw)
    if operation=='tex_status':
        result={key:str(fields[key]) for key in ('status','pdf_status','owner_generation') if key in fields}
        for key in ('source_revision','compiled_source_revision','build_source_revision'):
            if key in fields:result[key]=int(fields[key])
        build=host.as_dict(fields['last_build'])
        result['last_build']={key:(int(build[key]) if key=='source_revision' else str(build[key]))
            for key in ('status','source_revision') if key in build}
        result['pending_scope']='current_bridge_execution'
        return result
    payload=host.as_dict(fields.pop('payload'))
    projected={key:payload[key] for key in ('source','source_revision','assets','last_good_pdf')}
    build=host.as_dict(payload['last_build'])
    projected['last_build']={key:build[key] for key in ('status','source_revision') if key in build}
    result=_document_metadata(host,host.tcl_arg(fields))
    result['state']=host.modules['NATIVE_WORKSPACE_API_v1'].from_tcl(host,host.call('::GX::nativeWorkspaceTeXEncode',projected))
    for key in ('durable_revision',):
        if key in fields:result[key]=int(fields[key])
    for key in ('accepted','pending'):
        if key in fields:result[key]=bool(host.tcl.getboolean(fields[key]))
    return result


def _document_metadata(host, raw):
    fields=host.as_dict(raw)
    names={'id','module_id','provider_id','format','format_version','sha256','created_at','updated_at',
           'revision','generation','native_workspace','provider','name','schema','version'}
    result={key:str(value) for key,value in fields.items() if key in names}
    if 'revision' in fields:result['revision']=int(fields['revision'])
    if 'native_workspace' in fields:result['native_workspace']=bool(host.tcl.getboolean(fields['native_workspace']))
    if 'origin' in fields:result['origin']=_origin_record(host,fields['origin'])
    if 'payload' in fields:
        # The legacy Document contract is inert UTF-8 text. Typed scientific
        # Workspace states retain their own native graph transport instead of
        # inferring numerical kinds from Tcl strings or internal cache types.
        result['payload']=str(host.tcl.call('format','%s',fields['payload']))
    if 'source_identity' in fields:
        identity=host.as_dict(fields['source_identity'])
        result['source_identity']={key:str(value) for key,value in identity.items()
            if key in {'api_id','id','generation','sha256'}}
        for key in ('device','inode','size','mode','uid','gid','links','mtime_ns','ctime_ns','revision'):
            if key in identity:result['source_identity'][key]=int(identity[key])
    return result


def _document_cache(host,operation,command,args):
    if operation in {'metadata_batch','source_identities'}:
        if len(args[0])>4096 or any(not isinstance(value,str) for value in args[0]):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Document batches require at most4096 identity strings')
    if operation=='cache_configure':
        import math
        if set(args[0])-{'byte_budget','entry_budget'} or any(isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or int(value)!=value for value in args[0].values()):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Document cache accepts only integer byte_budget and entry_budget')
    if operation=='read_cached':
        raw=host.call(command,args[0],'stored',args[1] if len(args)>1 else True)
        return _document_metadata(host,raw)
    raw=host.call(command,*args)
    if operation in {'metadata_batch','source_identities'}:
        return {str(identity):_document_metadata(host,value) for identity,value in host.as_dict(raw).items()}
    fields=host.as_dict(raw)
    if operation=='cache_clear':
        return {key:bool(host.tcl.getboolean(fields[key])) for key in ('cleared','scientific_mutation')}
    result={key:str(fields[key]) for key in ('schema','policy') if key in fields}
    if 'available' in fields:result['available']=bool(host.tcl.getboolean(fields['available']))
    for key in ('entries','accounted_bytes','byte_budget','entry_budget','hits','misses','evictions','verified_bytes',
                'metadata_entries','metadata_source_bytes','metadata_limit_bytes','fallback_reads'):
        if key in fields:result[key]=int(fields[key])
    # Raw last_fallback may contain a host pathname; session_token identifies
    # a private interpreter lifetime. Neither is needed for public counters.
    return result


def _scientific_history(host, operation, command, schema, args):
    """Lossless existing inert recipe codec, without guessing scientific shapes."""
    if operation == 'history_drafts':
        import re
        if not host.module_id or args[0] != host.module_id:
            raise BridgeError('GXTXT:ScriptBridge:Ownership','History draft inspection requires the execution module owner')
        if len(args)>1 and args[1] and not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}',args[1]):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','History channel must be a stable CORE channel identifier')
        result = []
        for value in host.as_list(host.call(command,*args)):
            draft = host.as_dict(value)
            encoded = host.call('::GX::scientificRecipeEncode',draft['record'])
            result.append({'id':str(draft['id']), 'modified':int(draft['modified']),
                           'revision':int(draft['revision']),
                           'encoded_history':encoded.decode('ascii') if isinstance(encoded,bytes) else str(encoded),
                           'auxiliary':{str(key):str(item) for key,item in host.as_dict(draft['auxiliary']).items()}})
        return result
    parameters = []
    for field, value in zip(schema, args):
        if field['name'] == 'encoded_history':
            value = host.call('::GX::scientificRecipeDataDecode', value, 'gxtxt.scientific_recipe.v1')
        parameters.append(value)
    # geometry_state already owns validation and accepts the encoded recipe;
    # its argument is not the decoded Tcl record used by the History methods.
    if operation == 'geometry_state':
        parameters = args
    raw = host.call(command, *parameters)
    if operation in {'history_create','history_append','history_navigate','history_branch','rebase'}:
        encoded = host.call('::GX::scientificRecipeEncode', raw)
        return encoded.decode('ascii') if isinstance(encoded,bytes) else str(encoded)
    if operation == 'history_validate':
        result = host.as_dict(raw)
        result['count'] = int(result['count']);result['cursor'] = int(result['cursor'])
        return result
    if operation == 'history_strip_fields':
        result = {}
        for name, value in host.as_dict(raw).items():
            field = host.as_dict(value)
            if field['type']=='boolean':
                field['default'] = bool(host.tcl.getboolean(field['default']))
            if 'values' in field:
                field['values'] = [str(value) for value in host.as_list(field['values'])]
            result[str(name)] = field
        return result
    if operation == 'history_strip_validate':
        result = host.as_dict(raw)
        for key in ('visible','grouped'):
            result[key] = bool(host.tcl.getboolean(result[key]))
        return result
    if operation == 'history_grouped_entries':
        result = []
        for value in host.as_list(raw):
            entry = host.as_dict(value)
            for key in ('first','last','count','timestamp'):
                if key in entry and entry[key]!='':
                    entry[key] = int(entry[key])
            result.append(entry)
        return result
    return {str(key): str(value) for key,value in host.as_dict(raw).items()}


# Raw CORE documentationBrowserRefresh is projected through the already-owned
# documentation_browser registration, without changing its existing operations.
for _registration in REGISTRATIONS:
    if _registration['api_id'] == 'DOCUMENTATION_BROWSER_API_v1':
        _registration['operations']['documentationBrowserRefresh'] = {
            'name': 'documentationBrowserRefresh', 'summary': 'Rebuild the original installed documentation index',
            'host_command': '::GX::documentationBrowserRefresh', 'arguments': [],
            'argument_convention': 'no arguments',
            'result_contract': 'ordered original document ID strings only, <=8192 IDs /4 MiB total /1024 bytes per ID; no descriptor paths',
        }


_established_service_invoke_api = invoke_api


def invoke_api(host, api_id, operation, args):
    if api_id != 'DOCUMENTATION_BROWSER_API_v1' or operation != 'documentationBrowserRefresh':
        return _established_service_invoke_api(host, api_id, operation, args)
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Documentation refresh takes no arguments')
    # The existing Host has already loaded the original descriptor catalogs.
    # No caller path, catalog substitute, module activation or GUI is supplied.
    raw = host.call('::GX::documentationBrowserRefresh')
    result = [str(host.tcl.call('format', '%s', item)) for item in host.as_list(raw)]
    sizes = [len(item.encode('utf-8')) for item in result]
    if len(result) > 8192 or any(size > 1024 for size in sizes) or sum(sizes) > 4194304:
        raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original documentation ID result exceeds transport bounds')
    return result


# Existing recipe family/provider and encoded-history path are retained.
# Raw records now have a complete, opaque whole-value representation as well.
from gxtxt_script_values_v1 import rebase as _whole_recipe
for _registration in REGISTRATIONS:
    if _registration['api_id'] == 'SCIENTIFIC_RECIPE_API_v1':
        _registration['operations']['rebase']['arguments'][0]['kind'] = 'encoded history String or whole record value'
        _registration['operations']['rebase']['result_contract'] += '; raw record/whole TclValue input returns the complete raw candidate as whole TclValue; original registered validator remains mandatory'
_previous_recipe_invoke = invoke_api

def invoke_api(host, api_id, operation, args):
    if api_id == 'SCIENTIFIC_RECIPE_API_v1' and operation == 'rebase':
        return _whole_recipe(host, args)
    return _previous_recipe_invoke(host, api_id, operation, args)
