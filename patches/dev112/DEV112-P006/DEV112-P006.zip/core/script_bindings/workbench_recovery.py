"""Original read-only Recovery inspection and explicitly native-only facets.

Native status/flush does not create, clean, erase or restore legacy journals.
The raw host lifecycle identities and availability remain distinct contracts.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
import re
from gxtxt_script_bridge_server import BridgeError

_ACTIONS = ('begin', 'checkpoint', 'mark_saved', 'close')
_ARGS = {'api_info': [], 'inspect': ['expected'],
         'native_lifecycle': ['expected', 'action']}
REGISTRATION = {
    'api_id': 'WORKBENCH_RECOVERY_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'workbench_recovery',
    'documentation_ref': 'docs/api/WORKBENCH_RECOVERY_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Bounded original Recovery facet: '+name,
        'arguments': [{'name': field, 'kind': 'held id/generation/revision' if field == 'expected' else 'declared native lifecycle action', 'required': True} for field in fields],
        'result_contract': 'Original bounded scalar status; native-only flush differs from legacy journal lifecycle, no raw restore/delete authority',
        'full_raw_equivalence': False} for name, fields in _ARGS.items()},
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _revision(value):
    if isinstance(value, bool):
        _invalid('A held Document revision must be an exact nonnegative integer')
    if isinstance(value, float):
        if not math.isfinite(value) or not value.is_integer() or abs(value) > 9007199254740991:
            _invalid('A held Document revision must be an exact nonnegative integer')
        value = int(value)
    value = str(value)
    if not re.fullmatch(r'0|[1-9][0-9]{0,18}', value) or int(value) > 9223372036854775807:
        _invalid('A held Document revision must be an exact nonnegative integer')
    return value


def _expected(value):
    if not isinstance(value, dict) or set(value) != {'id', 'generation', 'revision'}:
        _invalid('Use a held Document id/generation/revision only')
    if (not isinstance(value['id'], str) or not re.fullmatch(r'idoc_[0-9]{4,64}', value['id']) or
            not isinstance(value['generation'], str) or not 1 <= len(value['generation'].encode('utf-8')) <= 512 or '\0' in value['generation']):
        _invalid('Use a held Document identity and generation')
    return dict(value, revision=_revision(value['revision']))


def _guard(host, expected, lifetime=None):
    token = _text(host, host.call('::GX::interactiveDocumentSessionToken'))
    if lifetime is not None and token != lifetime:
        raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Recovery belongs to an earlier Session lifetime')
    metadata = host.as_dict(host.call('::GX::interactiveDocumentMetadata', expected['id']))
    if (_text(host, metadata['generation']) != expected['generation'] or
            _text(host, metadata['revision']) != expected['revision']):
        raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Recovery Document belongs to an earlier generation or revision')
    return token


def _summary(host, raw):
    fields = host.as_dict(raw)
    text_fields = ('status', 'document_id', 'authority', 'saved_sha256', 'checkpoint_sha256', 'module_id', 'provider_id')
    result = {key: _text(host, fields[key]) for key in text_fields if key in fields}
    for key in ('saved_revision', 'checkpoint_revision'):
        if key in fields:
            result[key] = int(fields[key])
    result['recoverable'] = bool(host.tcl.getboolean(fields['recoverable']))
    if 'receipts' in fields:
        result['receipt_count'] = len(host.as_list(fields['receipts']))
    if 'reason' in fields:
        # The host retains exact corruption details. Filesystem exception text
        # and arbitrary historical receipt contents are not a transport grant.
        result['diagnostic_available'] = True
    return result


def invoke(host, operation, args):
    if operation not in _ARGS or len(args) != len(_ARGS[operation]):
        _invalid('Use the declared Recovery arguments')
    if operation == 'api_info':
        info = host.as_dict(host.call('::GX::workbenchRecoveryApiInfo'))
        return {'api_id': _text(host, info['api_id']), 'api_version': int(info['api_version']),
                'provider': _text(host, info['provider']),
                'raw_operations': [_text(host, value) for value in host.as_list(info['operations'])],
                'maximum_bytes': int(info['maximum_bytes']), 'maximum_receipts': int(info['maximum_receipts']),
                'native_lifecycle_actions': list(_ACTIONS), 'legacy_journal_mutation_available': False,
                'raw_resolve_available': False, 'raw_forget_available': False, 'full_raw_equivalence': False}
    expected = _expected(args[0])
    lifetime = _guard(host, expected)
    if operation == 'inspect':
        raw = host.call('::GX::workbenchRecoveryInspect', expected['id'])
    else:
        action = args[1]
        if not isinstance(action, str) or action not in _ACTIONS:
            _invalid('Use a declared native lifecycle action')
        if not host.tcl.getboolean(host.call('::GX::_nativeWorkspaceExists', expected['id'])):
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'This facet accepts native Workspace only; legacy journal lifecycle remains host-owned')
        # Reuse the original native branches directly. A concurrent replacement
        # can never fall through a raw dispatch into legacy journal writes.
        if action in ('mark_saved', 'close'):
            host.call('::GX::nativeWorkspaceFlush', expected['id'])
        raw = host.call('::GX::_nativeWorkspaceRecoveryStatus', expected['id'])
    _guard(host, expected, lifetime)
    return _summary(host, raw)
