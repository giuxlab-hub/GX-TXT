"""Inert CAD metadata from the existing Native2D owner, without GUI contexts."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_OPERATIONS = {
    'construction_count': ('native2DCadConstructionCount', [('family', 'string')]),
    'dimension_kinds': ('native2DCadDimensionKinds', []),
    'actions': ('native2DCadActions', []),
}
REGISTRATION = {
    'api_id': 'NATIVE2D_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'native2d',
    'documentation_ref': 'docs/api/NATIVE2D_API_v1.md',
    'operations': {name: {
        'name': name, 'summary': 'Read inert Native2D CAD metadata: '+name,
        'host_command': '::GX::'+command,
        'arguments': [{'name': field, 'kind': kind, 'required': True}
                      for field, kind in fields],
        'argument_convention': ', '.join(field for field, _ in fields) or 'no arguments',
        'result_contract': 'integer construction count' if name == 'construction_count' else
                           'ordered dimension kind strings' if name == 'dimension_kinds' else
                           'action ID to inert label/icon/group/default metadata',
    } for name, (command, fields) in _OPERATIONS.items()},
}


REGISTRATION['operations']['gx2d_status_text'] = {
    'name': 'gx2d_status_text', 'summary': 'Read the compiled Native2D status spelling',
    'arguments': [{'name': 'status', 'kind': 'signed 32-bit integer', 'required': True}],
    'argument_convention': 'exact signed 32-bit status code',
    'result_contract': 'native UTF-8 status spelling, including unknown-code fallback',
}



REGISTRATION['operations']['api_info'] = {
    'name': 'api_info', 'summary': 'Read the complete original owner discovery metadata',
    'host_command': '::GX::native2DCadApiInfo', 'arguments': [], 'argument_convention': 'no arguments',
    'result_contract': 'complete owner dictionary with explicit nested dictionaries, ordered text arrays, integer versions/limits and logical metadata flags; command names are inert data',
}


def _api_info_map(host, raw, lists=(), flags=(), integers=()):
    # Fixed owner-declared metadata shapes; command names remain inert text.
    result = {str(key): str(host.tcl.call('format', '%s', value)) for key, value in host.as_dict(raw).items()}
    for key in lists:
        result[key] = [str(value) for value in host.as_list(result[key])]
    for key in flags:
        result[key] = bool(host.tcl.getboolean(result[key]))
    for key in integers:
        result[key] = int(result[key])
    return result


def _api_info(host):
    result = _api_info_map(host, host.call('::GX::native2DCadApiInfo'),
                           ('capabilities', 'host_commands', 'sketch_operations', 'operations', 'cad_families', 'host_tool_families'),
                           ('advanced_tools_host_only', 'cad_raw_pointers'), ('api_version',))
    result['canvas'] = _api_info_map(host, result['canvas'], ('commands', 'host_commands'),
                                     ('host_only', 'multiple_instances', 'raw_pointers'), ('api_version', 'canvas_version'))
    return result

def invoke(host, operation, args):
    if operation == 'api_info':
        if args:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Metadata requires no arguments')
        return _api_info(host)
    if operation == 'gx2d_status_text':
        if len(args) != 1:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native status metadata requires one code')
        return host.modules['NATIVE_3D_ENGINE_API_v1'].native2d_status_text(args[0])
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', operation)
    command, fields = _OPERATIONS[operation]
    if len(args) != len(fields) or any(not isinstance(value, str) for value in args):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid CAD metadata arguments')
    raw = host.call('::GX::'+command, *args)
    if operation == 'construction_count':
        return int(raw)
    if operation == 'dimension_kinds':
        return [str(value) for value in host.as_list(raw)]
    return {str(name): {str(key): str(value) for key, value in host.as_dict(row).items()}
            for name, row in host.as_dict(raw).items()}
