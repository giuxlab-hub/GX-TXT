"""Scoped Parameter transport through the original C/formula/Workspace owner.

Only Host.dataset_private_context supplies the module capability. This adapter
owns typed transport/lifetimes, never expression or persistence implementation.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import math
from gxtxt_script_bridge_server import BridgeError
_COMMANDS = {
    "session_definitions": ("::GX::parameterSessionDefinitions", []),
    "session_list": ("::GX::parameterSessionList", []),
    "session_evaluate": ("::GX::parameterSessionEvaluate", ["expression"]),
    "workspace_list": ("::GX::parameterWorkspaceRead", ["workspace_id"]),
    "workspace_evaluate": ("::GX::parameterWorkspaceRead", ["workspace_id", "expression"]),
    "context": ("::GX::parameterContext", ["workspace_id"]),
    "context_info": ("::GX::parameterContextInfo", ["context"]),
    "definitions": ("::GX::parameterDefinitions", ["context"]),
    "list": ("::GX::parameterList", ["context"]),
    "evaluate": ("::GX::parameterEvaluate", ["context", "expression"]),
    "read_view": ("::GX::parameterReadView", ["context", "definitions", "session_definitions"]),
    "read_view_close": ("::GX::parameterReadViewClose", ["context"]),
    "bindings_set": ("::GX::parameterBindingsSet", ["context", "bindings", "expected"]),
}
REGISTRATION = {
    "api_id": "CORE_PARAMETER_SERVICE_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "parameter_service",
    "documentation_ref": "docs/api/CORE_PARAMETER_SERVICE_v1.md",
    "operations": {name: {"name": name, "summary": "Scoped original-owner parameters: " + name,
        "arguments": [{"name": arg, "kind": "public value", "required": True} for arg in args],
        "argument_convention": ", ".join(args), "result_contract": "typed parameter records, scalar, context token or managed receipt",
        "result_convention": "execution/Session-owned contexts; original C evaluation and native Workspace persistence"}
        for name, (_, args) in _COMMANDS.items()},
}
REGISTRATION["operations"]["context"]["argument_convention"] = "workspace_id (empty string selects the runtime module's own module scope)"
REGISTRATION["operations"]["bindings_set"]["argument_convention"] = "context, expression map, held native Workspace id/generation/revision receipt; rejects History read view"


# Optional operands retain the original owner defaults, not caller authority.
for _operation, _index, _default in (("context", 0, ""), ("read_view", 2, {})):
    _argument = REGISTRATION["operations"][_operation]["arguments"][_index]
    _argument.update(required=False, default=_default)
REGISTRATION["operations"]["bindings_set"]["arguments"][2].update(
    required=False, description="If omitted, the original owner captures and holds the native receipt before expression evaluation")
REGISTRATION["operations"]["context"]["argument_convention"] = "optional workspace_id; omitted or empty selects runtime module's own scope"
REGISTRATION["operations"]["read_view"]["argument_convention"] = "context, definitions, optional session_definitions (empty overlay by default)"
REGISTRATION["operations"]["bindings_set"]["argument_convention"] = "context, expression map, optional held native receipt; omitted receipt is captured before evaluation by the original owner; rejects History read view"

# Precise full-interface boundaries, not a Session/CAS exclusion:
# Set/Delete call _parameterWrite, which invokes matching live consumers' trusted
# prepare prefixes, returned rollback commands, and deferred History commands.
# The current worker protocol cannot enlist the submitting desktop's consumer
# transaction or transport these Tcl callback/rollback commands. Replacing that
# transaction with a property edit would not preserve its full interface.
# Subscribe/Unsubscribe manage those raw Tcl prefixes, rather than generic Script
# callback resources. ModuleRegister issues the private issuer capability, and
# ApplyDimensions takes a raw Native2D scene. These full interfaces are not
# admitted here. Fixed trusted callbacks alone do not make data unsafe:
# BindingsSet uses the original CAS/metadata-notification owner, like existing
# native Workspace mutations, with held-receipt and History readView guards.


def _invalid(message):
    raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", message)


def _text(value, label):
    if not isinstance(value, str):
        _invalid(label + " must be text")
    return value


def _expression(value):
    value = _text(value, "expression")
    if len(value) > 4096:
        _invalid("Expression exceeds the original C evaluator's4096-character limit")
    return value


def _finite_number(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _definitions(value):
    # Structural typed transport only; original owners validate names/formulas.
    if not isinstance(value, dict) or len(value) > 4096:
        _invalid("Definitions must be a map of at most4096 parameter records")
    allowed = {"formula", "label", "description", "unit", "type", "min", "max", "editable"}
    for name, record in value.items():
        _text(name, "parameter name")
        if not isinstance(record, dict) or "formula" not in record or not set(record) <= allowed:
            _invalid("A parameter record requires formula and the original owner's declared fields")
        _expression(record["formula"])
        for key, field in record.items():
            if key in {"min", "max"}:
                if not _finite_number(field):
                    _invalid("Parameter " + key + " requires a finite number")
            elif key == "editable":
                if not isinstance(field, bool):
                    _invalid("Parameter editable requires a boolean")
            else:
                _text(field, "Parameter " + key)
    return value


def _records(host, raw, evaluated=False):
    result = {}
    for name, value in host.as_dict(raw).items():
        record = host.as_dict(value)
        for key in ("min", "max", "value"):
            if key in record:
                record[key] = float(record[key])
        if "editable" in record:
            record["editable"] = bool(host.tcl.getboolean(record["editable"]))
        if evaluated:
            record["dependencies"] = list(dict.fromkeys(map(str, host.as_list(record["dependencies"]))))
        result[str(name)] = record
    return result


def _contexts(host):
    return host.handles.setdefault("parameter_service", {})


def _require_context(host, token):
    _text(token, "context")
    if token not in _contexts(host):
        raise BridgeError("GXTXT:ScriptBridge:Ownership", "Parameter context is foreign, unknown or belongs to another execution")
    held = _contexts(host)[token]
    # Original owner checks Session/module/Workspace ownership every request.
    # Generation additionally protects source incarnation, allowing revisions.
    info = host.as_dict(host.call("::GX::parameterContextInfo", token))
    if info["module"] != host.module_id or info["module"] != held["module"]:
        raise BridgeError("GXTXT:ScriptBridge:Ownership", "Parameter context owner changed")
    if held["workspace"]:
        current = host.as_dict(host.call("::GX::nativeWorkspaceMetadata", held["workspace"]))
        if str(current["generation"]) != held["generation"]:
            raise BridgeError("GXTXT:ScriptBridge:Ownership", "Parameter Workspace source incarnation changed")
    return held, info


def invoke(host, operation, args):
    if operation not in _COMMANDS:
        _invalid("Invalid Parameter operation/arguments")
    minimum = {"context": 0, "read_view": 2, "bindings_set": 2}.get(operation, len(_COMMANDS[operation][1]))
    if not minimum <= len(args) <= len(_COMMANDS[operation][1]):
        _invalid("Invalid Parameter operation/arguments")
    values = dict(zip(_COMMANDS[operation][1], args))
    if "expression" in values:
        _expression(values["expression"])
    if "workspace_id" in values:
        _text(values["workspace_id"], "workspace_id")
    if operation == "context":
        owner = host.dataset_private_context()
        workspace = values.get("workspace_id", "")
        token = str(host.call("::GX::parameterContext", owner["capability"], workspace))
        generation = str(host.as_dict(host.call("::GX::nativeWorkspaceMetadata", workspace))["generation"]) if workspace else ""
        _contexts(host)[token] = {"module": host.module_id, "workspace": workspace, "generation": generation, "read_view": False}
        return token
    if "context" in values:
        held, info = _require_context(host, values["context"])
        if operation == "context_info":
            return info
        if operation == "read_view":
            definitions = _definitions(values["definitions"])
            session = _definitions(values.get("session_definitions", {}))
            # Validate via original C before installing an atomic read overlay.
            host.call("::GX::_parameterEvaluate", definitions, session)
            host.call("::GX::parameterReadView", values["context"], definitions, session)
            held["read_view"] = True
            return True
        if operation == "read_view_close":
            host.call("::GX::parameterReadViewClose", values["context"])
            held["read_view"] = False
            return True
        if operation == "bindings_set":
            if not held["workspace"] or held["read_view"]:
                raise BridgeError("GXTXT:ScriptBridge:Ownership", "Bindings require a current canonical Workspace context outside History read view")
            bindings = values["bindings"]
            if not isinstance(bindings, dict):
                _invalid("Bindings must be an expression map")
            for key, expression in bindings.items():
                _text(key, "binding identity")
                _expression(expression)
            if "expected" not in values:
                # Original owner captures BEFORE C evaluation, rechecks even
                # no-op, and forwards that SAME receipt to native CAS.
                host.call("::GX::parameterBindingsSet", values["context"], bindings)
            else:
                expected = values["expected"]
                if not isinstance(expected, dict) or not {"id", "generation", "revision"} <= set(expected):
                    _invalid("Bindings require a held native Workspace id/generation/revision receipt")
                revision = expected["revision"]
                if (not isinstance(expected["id"], str) or not isinstance(expected["generation"], str)
                        or not _finite_number(revision) or revision != int(revision)
                        or not 0 <= revision < 2**64
                        or isinstance(revision, float) and revision > 2**53):
                    _invalid("Bindings require exact typed id/generation/revision")
                current = host.as_dict(host.call("::GX::nativeWorkspaceMetadata", held["workspace"]))
                if any(str(expected[key]) != str(current[key]) for key in ("id", "generation")) or int(expected["revision"]) != int(current["revision"]):
                    raise BridgeError("GXTXT:ScriptBridge:Ownership", "Stale or foreign Parameter Workspace CAS receipt")
                # Preserve the same caller-held receipt through the original owner
                # and its final native CAS, including validation/no-op interleaving.
                host.call("::GX::parameterBindingsSet", values["context"], bindings, expected)
            result = host.as_dict(host.call("::GX::nativeWorkspaceMetadata", held["workspace"]))
            for key in ("revision", "durable_revision", "queued_bytes", "size_bytes"):
                if key in result:
                    result[key] = int(result[key])
            return result
    raw = host.call(_COMMANDS[operation][0], *args)
    if operation in {"session_definitions", "definitions"}:
        return _records(host, raw)
    if operation in {"session_evaluate", "workspace_evaluate", "evaluate"}:
        return float(raw)
    return _records(host, raw, evaluated=True)
