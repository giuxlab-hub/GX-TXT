"""Closed schema/action declarations from existing Configuration owners.

No configured values, field defaults, validators, structured callback prefixes, effective
shortcut overrides, Session tokens, window handlers or invocation cross here.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import re
from gxtxt_script_bridge_server import BridgeError

_COMMANDS={'fields':('::GX::configurationFields',[]),
           'module_fields':('::GX::configurationModuleFields',['module_id']),
           'viewer_command_catalog':('::GX::viewerCommandCatalog',['catalog_id'])}
REGISTRATION={'api_id':'CONFIGURATION_API_v1','api_version':1,'provider_kind':'core','provider_id':'configuration',
 'documentation_ref':'docs/api/CONFIGURATION_API_v1.md',
 'operations':{name:{'name':name,'summary':'Read declared Configuration metadata: '+name,
  'arguments':[{'name':field,'kind':'stable declared identity','required':True} for field in fields],
  'result_contract':('Declared action IDs/labels/scopes/default shortcut strings; no effective overrides, handlers or invocation.' if name=='viewer_command_catalog' else 'Closed schema IDs/labels/types/scopes/module keys and exact lexical bounds; no configured values/field defaults, callbacks, paths or tokens.')}
  for name,(_,fields) in _COMMANDS.items()}}


def invoke(host,operation,args):
    if operation not in _COMMANDS or len(args)!=len(_COMMANDS[operation][1]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Invalid closed Configuration metadata operation/arguments')
    if args and (not isinstance(args[0],str) or len(args[0])>256 or not re.fullmatch(r'[a-z][a-zA-Z0-9_.-]*',args[0])):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Configuration metadata requires a stable declared identity')
    try:rows=host.as_dict(host.call(_COMMANDS[operation][0],*args))
    except Exception:
        raise BridgeError('GXTXT:Configuration:Unavailable','Declared Configuration metadata is unavailable') from None
    result={}
    for identity,raw in rows.items():
        fields=host.as_dict(raw)
        if operation=='viewer_command_catalog':
            row={key:str(host.tcl.call('format','%s',fields[key]))
                 for key in ('label','default','scope','clipboard_operation','toolbar_label') if key in fields}
            row['command_id']=str(identity)
        else:
            row={key:str(host.tcl.call('format','%s',fields[key]))
                 for key in ('group','label','type','scope','module_id','module_key','module_type','application','min','max') if key in fields}
            row['field_id']=str(identity)
            if 'scopes' in fields:row['scopes']=[str(value) for value in host.as_list(fields['scopes'])]
        result[str(identity)]=row
    return result
