"""Registered declarations, supervised identity and owned Job dependencies."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_ARGS = {'callable_list': [], 'callable_describe': ['reference', 'callable_id'], 'current_callable': [], 'job_wait': ['job_id', 'timeout_seconds'], 'job_submit': ['reference', 'parameters'], 'provided_api_inventory': []}
REGISTRATION = {
    'api_id': 'SCRIPT_EXECUTION_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'script_execution',
    'documentation_ref': 'docs/api/SCRIPT_EXECUTION_API_v1.md',
    'capabilities': ['registered_callable_declarations', 'supervised_callable_identity', 'owned_job_dependency_wait', 'supervised_job_submission', 'provided_function_jobs_v1', 'provided_bridge_control_arrays_v1'],
    'operations': {name: {'name': name, 'summary': 'Registered Script ' + name,
        'arguments': [{'name': arg, 'kind': {'parameters': 'dictionary', 'timeout_seconds': 'integer'}.get(arg, 'string'), 'required': True} for arg in args],
        'argument_convention': ', '.join(args),
        'result_contract': 'Verified declaration/identity or bounded supervised Job receipt; no arbitrary source paths'}
        for name, args in _ARGS.items()},
}
REGISTRATION['operations']['provided_api_inventory'].update(
    summary='Inspect static PROVIDED declarations of this exact registered runtime snapshot',
    argument_convention='No arguments; current Session, runtime module and registered source identity only',
    result_contract='Typed static inventory, declared counts and path-free Registry stamp; execution_authority none. No caller Session/draft/path/owner context or public API registration.')


def _descriptor(host, raw):
    result = host.as_dict(raw)
    for key, value in result.items():
        result[key] = value.decode('ascii') if isinstance(value, bytes) else str(value)
    result['revision'] = int(result['revision'])
    return result


def invoke(host, operation, args):
    if operation not in _ARGS or len(args) != len(_ARGS[operation]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid Script Execution operation arguments')
    if operation == 'provided_api_inventory':
        return _provided_api_inventory(host)
    if operation == 'job_submit':
        if not isinstance(args[0], str) or not isinstance(args[1], dict):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Job submission requires a registered reference and parameter dictionary')
        raw = host.as_dict(host.call('::GX::scriptJobSubmit', *args))
        return {'job_id': str(raw['id']), 'state': str(raw['state'])}
    if operation == 'job_wait':
        if host.tcl.getboolean(host.call('::GX::scientificExecutionRemoteId', args[0])):
            # This API waits for a supervised same-Session Script child.
            # Raw host remote references must pass that same owner admission
            # before they can reach any configured remote transport.
            host.call('::GX::scriptJobCall', 'wait_begin', args[0])
        raw = host.as_dict(host.call('::GX::scriptJobWait', *args))
        return {'job_id': str(raw['id']), 'state': str(raw['state']),
                'wait_cancel_requested': bool(int(raw['wait_cancel_requested']))}
    if operation == 'callable_list':
        return [_descriptor(host, value) for value in host.as_list(host.call('::GX::scriptRegistryCallableList', host.session))]
    if operation == 'callable_describe':
        return _descriptor(host, host.call('::GX::scriptRegistryCallableDescribe', *args, host.session))
    if not host.config.has_section('registered_callable'):
        raise BridgeError('GXTXT:ScriptCallback:NoInvocation', 'This Job has no registered callable invocation')
    invocation = dict(host.config.items('registered_callable'))
    reference = host.config.get('config', 'registered_script')
    if invocation['source_sha256'] != host.config.get('config', 'script_sha256'):
        raise BridgeError('GXTXT:ScriptCallback:IdentityMismatch', 'Callable source differs from its Job snapshot')
    request = {key: invocation[key] for key in ('callable_id','source_sha256','revision','declaration_sha256','consumer_api','consumer_operation','payload_json')}
    host.call('::GX::scriptCallableInvocationValidate', reference, request, host.session)
    result = _descriptor(host, host.call('::GX::scriptRegistryCallableDescribe', reference, invocation['callable_id'], host.session))
    for key in ('source_sha256', 'revision', 'declaration_sha256'):
        if str(result[key]) != invocation[key]:
            raise BridgeError('GXTXT:ScriptCallback:IdentityMismatch', 'Registered callable changed during identity resolution')
    result.update({key: invocation[key] for key in ('consumer_api', 'consumer_operation')})
    result['run_id'] = host.run_id
    return result


def _provided_api_inventory(host):
    """Same Registry/Project owner and parser; explicit metadata kinds only."""
    import re

    def mismatch():
        raise BridgeError('GXTXT:ScriptCallback:IdentityMismatch',
                          'Registered inventory snapshot is unavailable or changed')

    config=host.config
    reference=config.get('config','registered_script',fallback='')
    language=config.get('config','script_language',fallback='')
    source_sha=config.get('config','script_sha256',fallback='')
    revision=config.get('config','script_revision',fallback='')
    if (config.get('config','source_mode',fallback='')!='registered_script' or
        not re.fullmatch(r'(user|session):[A-Za-z][A-Za-z0-9_.-]*',reference) or
        language not in {'Python','Octave'} or not re.fullmatch(r'[a-f0-9]{64}',source_sha) or
        not re.fullmatch(r'[1-9][0-9]*',revision) or not host.session):
        raise BridgeError('GXTXT:ScriptCallback:NoRegisteredSnapshot',
                          'Inventory requires this execution registered Script snapshot')
    if host.module_id!=str(host.call('::GX::scriptAnalysisModule',language)):
        mismatch()
    try:
        metadata=host.as_dict(host.call('::GX::scriptRegistryDescribe',reference,host.session))
        if (str(metadata['language'])!=language or str(metadata['sha256'])!=source_sha or
            int(metadata['revision'])!=int(revision)):
            mismatch()
        expected={'expected_sha256':source_sha,'expected_revision':revision,
                  'expected_record_sha256':metadata['record_sha256'],
                  'expected_owner_context':metadata['owner_context']}
        # The unchanged owner checks the full expected source/record/root
        # identity before AND after its fixed static parser. No caller options.
        result=host.as_dict(host.call('::GX::scriptRegistryProvidedApiInventory',reference,expected,host.session))
    except Exception:
        mismatch()
    if (str(result['schema'])!='gxtxt.script_provided_api_inventory.v1' or
        str(result['source_scope'])!='registered_snapshot' or
        str(result['execution_authority'])!='none' or str(result['language'])!=language):
        mismatch()

    def text(raw):return str(host.tcl.call('format','%s',raw))
    def strings(raw):return [text(value) for value in host.as_list(raw)]

    def default(raw,spec):
        # Transport conversion follows the original owner-declared kind, never
        # Tcl cache representation or dict/list/string parseability. No source
        # parser, default validator or scientific logic is duplicated here.
        kind=spec['kind']
        if kind=='null':return None
        if kind=='string':return text(raw)
        if kind=='boolean':return bool(host.tcl.getboolean(raw))
        if kind=='integer':return int(raw)
        if kind in {'number','double'}:
            value=text(raw)
            return int(value) if re.fullmatch(r'[+-]?[0-9]+',value) else float(value)
        if kind=='array':return [default(value,spec['items']) for value in host.as_list(raw)]
        fields={field['name']:field for field in spec['fields']}
        return {name:default(value,fields[name]) for name,value in host.as_dict(raw).items()}

    def schema(raw):
        fields=host.as_dict(raw)
        out={key:text(fields[key]) for key in ('kind','name','units','description') if key in fields}
        for key in ('max_length','max_items'):
            if key in fields:out[key]=int(fields[key])
        if 'required' in fields:out['required']=bool(host.tcl.getboolean(fields['required']))
        if 'items' in fields:out['items']=schema(fields['items'])
        if 'fields' in fields:out['fields']=[schema(value) for value in host.as_list(fields['fields'])]
        if 'default' in fields:out['default']=default(fields['default'],out)
        return out

    provided=[]
    for raw in host.as_list(result['provided']):
        fields=host.as_dict(raw)
        provided.append({'id':text(fields['id']),'version':int(fields['version']),
                         'name':text(fields['name']),'operations':strings(fields['operations'])})
    operations=[]
    for raw in host.as_list(result['operations']):
        fields=host.as_dict(raw)
        out={key:text(fields[key]) for key in ('id','summary','result_contract','unit_behavior','api_id','declaration_file','declaration_file_sha256')}
        for key in ('api_version','declaration_line'):out[key]=int(fields[key])
        out['read_only']=bool(host.tcl.getboolean(fields['read_only']))
        for key in ('effects','capabilities','required_apis'):out[key]=strings(fields[key])
        out['arguments']=[schema(value) for value in host.as_list(fields['arguments'])]
        out['result']=schema(fields['result'])
        out['implementation']={key:(int(value) if key=='line' else text(value))
                               for key,value in host.as_dict(fields['implementation']).items()
                               if key in {'file','function','module','line','sha256','signature'}}
        operations.append(out)
    files=[]
    for raw in host.as_list(result['files']):
        fields=host.as_dict(raw)
        hazards=[]
        for value in host.as_list(fields['load_hazards']):
            item=host.as_dict(value);hazards.append({'line':int(item['line']),'reason':text(item['reason'])})
        files.append({'path':text(fields['path']),'sha256':text(fields['sha256']),
                      'size':int(fields['size']),'load_hazards':hazards})
    diagnostics=[]
    for raw in host.as_list(result['diagnostics']):
        fields=host.as_dict(raw)
        diagnostics.append({key:(int(value) if key=='line' else text(value))
                            for key,value in fields.items() if key in {'code','message','file','line','severity'}})
    consumed=strings(result['consumed']);baseline=host.as_dict(result['registry_baseline'])
    return {'schema':text(result['schema']),'language':language,'entrypoint':text(result['entrypoint']),
            'provided':provided,'operations':operations,'consumed':consumed,'files':files,'diagnostics':diagnostics,
            'valid':bool(host.tcl.getboolean(result['valid'])),'declaration_sha256':text(result['declaration_sha256']),
            'discovery_scope':text(result['discovery_scope']),'reference':reference,'runtime_module':host.module_id,
            'source_scope':text(result['source_scope']),'execution_authority':text(result['execution_authority']),
            'registry_stamp':{'source_sha256':text(baseline['expected_sha256']),
                              'revision':int(baseline['expected_revision']),
                              'record_sha256':text(baseline['expected_record_sha256'])},
            'counts':{'provided_apis':len(provided),'operations':len(operations),'consumed_apis':len(consumed),
                      'files':len(files),'diagnostics':len(diagnostics)}}
