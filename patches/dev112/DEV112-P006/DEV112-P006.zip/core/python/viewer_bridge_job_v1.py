"""Framework-owned generic frontend, executed by the ordinary Script Job owner.

Provider discovery, require and invocation use public gxtxt unchanged. No API
family/operation is enumerated here; stateful workflows belong in one admitted
project script and retain the same Bridge process/resource ownership.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
from pathlib import Path
import gxtxt

context = gxtxt.gxtxt_context()
from viewer_bridge_control_v1 import load_request
request=load_request(context['output_dir'],context['parameters']['request_json'])
action = request['action']
arguments = request['request']
if action == 'list':
    value = gxtxt.gxtxt_api_list()
elif action == 'describe':
    value = gxtxt.gxtxt_api_describe(arguments['api_id'])
elif action == 'require':
    value = gxtxt.gxtxt_api_require(arguments['requirements'])
elif action == 'call':
    from viewer_bridge_buffers_v1 import discover_references, resolve_inputs, load_manifest
    args = arguments['args']
    if discover_references(args):
        import configparser
        config = configparser.ConfigParser(interpolation=None)
        config.read(Path(context['output_dir'])/'runtime.ini')
        manifest = load_manifest(context['output_dir'],config.get('viewer_bridge_inputs','manifest_sha256'))
        args = resolve_inputs(args, manifest, context['output_dir'])
    requirement = {key:arguments[key] for key in ('api_id','api_version','provider_id') if key in arguments}
    gxtxt.gxtxt_api_require([requirement])
    value = gxtxt.gxtxt_api_call(arguments['api_id'], arguments['operation'], args)
else:
    raise ValueError('Unknown generic Bridge action')

output = Path(context['output_dir'])
from viewer_bridge_control_v1 import retain_value
receipt = {'schema':'gxtxt.viewer_bridge_result.v1','module_id':context['module_id'],'run_id':context['run_id'],'action':action,'request':arguments,'result':retain_value(value,output)}
from viewer_bridge_control_v1 import retain_result
raw=retain_result(output,receipt)
(output/'viewer_bridge_result.json').write_bytes(raw)
print('@@GXTXT_PROGRESS_V1@@\tfraction=1\tstage=Viewer Script Bridge operation completed',flush=True)
