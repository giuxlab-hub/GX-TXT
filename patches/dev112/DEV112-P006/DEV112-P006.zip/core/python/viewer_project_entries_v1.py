"""Inert declarations in the normal Viewer Project source closure.

No registry, runtime, interpreter or Job owner is implemented here. Script
Execution and Scientific Execution admit and execute these exact sources.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
import re


def validate(meta, files):
    for kind in ('script_entries', 'native_jobs'):
        entries = meta.get(kind, {})
        if not isinstance(entries, dict) or len(entries) > 32:
            raise ValueError(kind + ' must contain at most 32 named entries')
        for name, item in entries.items():
            if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,63}', name) or not isinstance(item, dict):
                raise ValueError('Entry names and metadata must be bounded inert objects')
            if not isinstance(item.get('parameters', {}), dict) or len(json.dumps(item.get('parameters', {}), allow_nan=False)) > 32768:
                raise ValueError('Entrypoint requires a bounded existing typed parameter schema')
            if kind == 'script_entries':
                if set(item) - {'language', 'entrypoint', 'required_apis', 'parameters'} or not {'language', 'entrypoint'}.issubset(item):
                    raise ValueError('Unknown script entrypoint metadata')
                suffix = {'Python': '.py', 'Octave': '.m'}.get(item['language'])
                entry = item['entrypoint']
                if not suffix or not isinstance(entry, str) or not entry.startswith('scripts/') or not entry.endswith(suffix) or entry not in files:
                    raise ValueError('Script entrypoint must name its declared language source')
                if not isinstance(item.get('required_apis', ''), str) or len(item.get('required_apis', '')) > 8192:
                    raise ValueError('Use the existing bounded Script Bridge required_apis declarations')
            else:
                if set(item) - {'sources', 'parameters'} or 'sources' not in item:
                    raise ValueError('Unknown native Job entrypoint metadata')
                sources = item['sources']
                if not isinstance(sources, list) or not 1 <= len(sources) <= 32 or len(set(sources)) != len(sources):
                    raise ValueError('Native Job requires unique declared C++ task sources')
                if any(not isinstance(src, str) or not src.startswith('jobs/') or not src.endswith('.cpp') or src not in files for src in sources):
                    raise ValueError('Native Job sources must name declared jobs/*.cpp units')
    return True
