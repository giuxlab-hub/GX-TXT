# SPDX-License-Identifier: GPL-3.0-or-later
"""Finite transport to the existing scalar Numeric owner, outside author limits.

This owns no numerical implementation, registry or Job state. The same original
broker_message/core path admits every call. Native author limits remain intact.
"""
from pathlib import Path
import ctypes,json,math,os,select,signal,subprocess,sys,threading,time,uuid

sys.path.insert(0,str(Path(__file__).resolve().parent))
from gxtxt_job_supervisor import enable_subreaper,process_identity,process_tree,drain_tree,reap_adopted

SCALAR={4:'array_binary.add',6:'array_unary.sqrt',7:'array_unary.exp'}
OWNED=[]
SCOPE_KEY='GXTXT_VIEWER_SCALAR_SCOPE'

def refresh_owned(record,pid,token):
    if pid==os.getpid() or (record.get('pid_start') and process_identity(pid)==record['pid_start']):
        record['process_identities'].update({str(p):row[2] for p,row in process_tree(pid).items() if p!=os.getpid()})
    # The existing supervisor's exact identity rule also covers adopted nested
    # groups. This ephemeral tag is deliberately NOT a scientific Job identity.
    tag=(SCOPE_KEY+'='+token).encode()
    for path in Path('/proc').glob('[0-9]*/environ'):
        try:
            if path.stat().st_uid==os.getuid() and tag in path.read_bytes().split(b'\0'):
                child=int(path.parent.name);identity=process_identity(child)
                if child!=os.getpid() and identity:record['process_identities'][str(child)]=identity
        except (OSError,ValueError):pass
    # Keep live/zombie identities for drainage; discard completed/reused PIDs
    # before any waitpid, so a long-lived Viewer never reaps a later child.
    for child,start in tuple(record['process_identities'].items()):
        try:same=Path('/proc',child,'stat').read_text().rsplit(')',1)[1].split()[19]==start.rsplit(':',1)[1]
        except (OSError,IndexError):same=False
        if not same:record['process_identities'].pop(child,None)

def close_owned_brokers():
    for broker in tuple(OWNED):
        try:broker.close()
        except Exception:pass

class ScalarBroker:
    def __init__(self,work,source,validation,grants,environment,active,generic_scope=None):
        enable_subreaper()
        self.active=active;self.token=uuid.uuid4().hex;self.closed=False;self.buffer=b'';self.lock=threading.Lock()
        self.receipt=work/'derived'/('scalar-broker-'+self.token+'.json')
        env=dict(environment);env[SCOPE_KEY]=self.token
        self.errors=(work/'derived'/('scalar-broker-'+self.token+'.stderr')).open('wb')
        blocked=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGINT})
        try:
            self.child=subprocess.Popen([sys.executable,'-I','-B',str(Path(__file__).resolve()),str(work),str(os.getpid()),self.receipt.name],
                stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.errors,env=env,start_new_session=True)
            self.active.add(self.child.pid);OWNED.append(self)
            self.record=dict(run_id='compiled_viewer_scalar',job_root='',pid_start=process_identity(self.child.pid),process_identities={str(self.child.pid):process_identity(self.child.pid)})
        finally:signal.pthread_sigmask(signal.SIG_SETMASK,blocked)
        try:
            snapshot={key:validation[key] for key in ('source_sha256','design_sha256','project_sha256','source_tree_sha256','source_manifest') if key in validation}
            self.send(dict(schema='gxtxt.viewer_scalar_broker.v1',source=str(source),snapshot=snapshot,grants=sorted(grants),generic_scope=generic_scope,generic_methods=sorted(set(validation.get('sdk_calls',[])) & {'script_bridge','script_bridge_result','input_text'})))
            ready=self.receive(time.monotonic()+5)
            if ready!=dict(ok=True,pid=self.child.pid):raise ValueError('Scalar broker did not admit its frozen source/grants')
        except BaseException:
            self.close();raise
    def send(self,value):
        data=json.dumps(value,allow_nan=False,separators=(',',':')).encode()+b'\n'
        if len(data)>65536:raise ValueError('Scalar broker framing exceeds64KiB')
        self.child.stdin.write(data);self.child.stdin.flush()
    def receive(self,deadline,scan=True):
        while b'\n' not in self.buffer:
            if scan:refresh_owned(self.record,self.child.pid,self.token)
            remaining=deadline-time.monotonic()
            if remaining<=0:raise TimeoutError('Public scalar Numeric request exceeded its existing event budget')
            if not select.select([self.child.stdout],[],[],min(.1,remaining))[0]:continue
            chunk=os.read(self.child.stdout.fileno(),65537)
            if not chunk:raise ValueError('Scalar broker ended before its typed response')
            self.buffer+=chunk
            if len(self.buffer)>65536:raise ValueError('Scalar broker response exceeds64KiB')
        line,self.buffer=self.buffer.split(b'\n',1)
        return json.loads(line)
    def call(self,message,deadline):
        with self.lock:
            if self.closed:raise ValueError('Scalar broker is closed; reopen the Viewer')
            self.send(dict(message=message,deadline=deadline))
            try:result=self.receive(deadline)
            except BaseException:self.close();raise
            if not result.get('ok'):raise ValueError(result.get('error','Scalar Numeric request failed'))
            return result['response'],[],result['numeric_receipts']
    def control(self,action,**values):
        with self.lock:
            if self.closed:raise ValueError('Generic control broker is closed')
            self.send(dict(control=action,**values))
            result=self.receive(time.monotonic()+12,scan=False)
            if not result.get('ok'):raise ValueError(result.get('error','Generic control transport refused'))
            return result['value']
    def spool_native(self,pointer,total,purpose='generic'):
        import base64
        from viewer_bridge_control_v1 import CHUNK
        token=self.control('begin',total=total,**({'purpose':purpose} if purpose!='generic' else {}))
        try:
            for offset in range(0,total,CHUNK):
                raw=ctypes.string_at(pointer+offset,min(CHUNK,total-offset))
                self.control('append',token=token,offset=offset,bytes_base64=base64.b64encode(raw).decode('ascii'))
            return self.control('seal',token=token)
        except BaseException:
            try:self.control('abort',token=token)
            except Exception:pass
            raise
    def spool_generic(self,message):
        import base64
        from viewer_bridge_control_v1 import CHUNK
        raw=message['text'].encode('utf-8')
        token=self.control('begin',total=len(raw))
        try:
            for offset in range(0,len(raw),CHUNK):
                self.control('append',token=token,offset=offset,bytes_base64=base64.b64encode(raw[offset:offset+CHUNK]).decode('ascii'))
            return self.control('seal',token=token)
        except BaseException:
            try:self.control('abort',token=token)
            except Exception:pass
            raise
    def close(self):
        if self.closed:return
        self.closed=True
        refresh_owned(self.record,self.child.pid,self.token)
        try:
            if self.child.poll() is None:self.child.terminate()
            try:self.child.wait(timeout=2)
            except subprocess.TimeoutExpired:pass
            refresh_owned(self.record,self.child.pid,self.token)
            drained=drain_tree(self.record,self.child.pid,timeout=1)
            if self.child.poll() is None:self.child.kill()
            self.child.wait(timeout=1);reap_adopted(self.record)
            self.cleanup=dict(pid=self.child.pid,reaped=True,descendants_drained=drained,returncode=self.child.returncode)
        finally:
            self.active.discard(self.child.pid)
            if self in OWNED:OWNED.remove(self)
            self.child.stdin.close();self.child.stdout.close();self.errors.close()
    def __enter__(self):return self
    def __exit__(self,*arguments):self.close()

def main():
    import gxtxt_viewer_development as dev
    if len(sys.argv)!=4:raise ValueError('Internal scalar broker requires its owned allocation/parent/receipt')
    work=Path(sys.argv[1]);parent=int(sys.argv[2]);name=sys.argv[3]
    if not work.is_absolute() or work.resolve()!=work or not __import__('re').fullmatch(r'scalar-broker-[0-9a-f]{32}\.json',name):raise ValueError('Invalid scalar broker allocation')
    enable_subreaper();token=os.environ.get(SCOPE_KEY,'')
    if not __import__('re').fullmatch(r'[0-9a-f]{32}',token):raise ValueError('Scalar broker scope is missing')
    record=dict(run_id='compiled_viewer_scalar',job_root='',process_identities={})
    receipt=dict(schema='gxtxt.viewer_scalar_broker.v1',pid=os.getpid(),parent_pid=parent,source_owner_sha256=dev.digest(Path(__file__).read_bytes()),state='STARTING')
    stopping=False
    def stop(signum,frame):
        nonlocal stopping
        if stopping:return
        stopping=True;raise SystemExit(128+signum)
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    # A hard-killed native parent must not leave a trusted CORE helper alive.
    if ctypes.CDLL(None,use_errno=True).prctl(1,signal.SIGTERM,0,0,0)!=0 or os.getppid()!=parent:raise ValueError('Scalar broker parent lifetime ended')
    signal.pthread_sigmask(signal.SIG_UNBLOCK,{signal.SIGTERM,signal.SIGINT})
    try:
        raw=sys.stdin.buffer.readline(65537)
        if len(raw)>65536:raise ValueError('Scalar broker configuration exceeds bound')
        config=json.loads(raw)
        if set(config)!={'schema','source','snapshot','grants','generic_scope','generic_methods'} or config['schema']!='gxtxt.viewer_scalar_broker.v1':raise ValueError('Invalid scalar broker configuration')
        source=Path(config['source']);snapshot=config['snapshot'];grants=config['grants']
        if not source.is_absolute() or source.resolve()!=source:raise ValueError('Scalar source must be the fixed ordinary admitted project root')
        meta=dev.read_project(source,installed=True)
        declared={operation for request in meta['capabilities'] if request.get('api_id')=='NUMERIC_API_v1' and request.get('version')==1 for operation in request['operations']}
        if not isinstance(grants,list) or not set(grants)<=set(SCALAR.values()) or not set(grants)<=declared:raise ValueError('Scalar grants differ from the frozen project')
        def unchanged():
            if not dev.sources_match(source,snapshot) or any(dev.digest((source/n).read_bytes())!=snapshot[k] for n,k in [('project.json','project_sha256'),('design.gxtxt-viewer','design_sha256')]):raise ValueError('Scalar broker source revision changed')
        generic_methods=config['generic_methods'];generic_scope=config['generic_scope'];control_store=None
        if not isinstance(generic_methods,list) or set(generic_methods)-{'script_bridge','script_bridge_result','input_text'} or (generic_scope is not None and not generic_methods):raise ValueError('Generic control eligibility differs from admitted compiled source')
        # Scope is passed only by the original admitted compiled owner before
        # constructors run; Numeric eligibility cannot grant generic access.
        def control(action,payload):
            nonlocal control_store
            if generic_scope is None or not generic_methods:raise ValueError('Generic control was not requested by admitted compiled source')
            from viewer_bridge_control_v1 import ControlStore,context_stream,decode_packet
            if generic_scope.get('module')!=meta['module_id']:raise ValueError('Generic control scope is not this admitted source module')
            if control_store is None:control_store=ControlStore(generic_scope)
            if action=='begin' and set(payload) in ({'control','total'},{'control','total','purpose'}):
                purpose=payload.get('purpose','generic')
                if purpose=='input_text':
                    if 'input_text' not in generic_methods or not any(row.get('api_id')=='VIEWER_GUI_HOST_API_v1' and row.get('version')==1 and 'value_set' in row.get('operations',[]) for row in meta['capabilities']):raise ValueError('Input write-back requires admitted GUI value_set')
                elif purpose!='generic' or not set(generic_methods)&{'script_bridge','script_bridge_result'}:raise ValueError('Generic control purpose was not admitted')
                return control_store.begin(payload['total'],purpose=purpose)
            if action=='discard_inputs' and set(payload)=={'control'} and 'input_text' in generic_methods:
                for token,row in tuple(control_store.uploads.items()):
                    if row['purpose']!='input_text':continue
                    if not control_store.manager.inspect(token).get('removed'):
                        control_store.manager.release(token,state='verified_orphan');control_store.manager.cleanup([token])
                    if control_store.manager.inspect(token).get('removed'):control_store.uploads.pop(token)
                return True
            if action=='append' and set(payload)=={'control','token','offset','bytes_base64'}:control_store.append(payload['token'],payload['offset'],payload['bytes_base64']);return True
            if action=='abort' and set(payload)=={'control','token'}:control_store.abort(payload['token']);return True
            if action=='seal' and set(payload)=={'control','token'}:
                descriptor=control_store.seal(payload['token'])
                from viewer_bridge_control_v1 import resource_packet
                purpose=control_store.uploads[payload['token']]['purpose']
                packet=resource_packet(descriptor,generic_scope,purpose=purpose)
                if purpose=='input_text':
                    from viewer_bridge_control_v1 import input_text_packet
                    index,text=input_text_packet(packet)
                    design=dev.dictionary((source/'design.gxtxt-viewer').read_text(encoding='utf-8'));components=dev.tkinter.Tcl().splitlist(design['components'])
                    if index>len(components):raise ValueError('Input target is undeclared')
                    component=dev.dictionary(components[index-1]);properties=dev.dictionary(component['properties']);kind=component['type']
                    if kind not in {'field','entry','choice','combobox'} or (kind=='field' and properties.get('datatype','string') not in {'string','choice'}):raise ValueError('Input target is not a declared string/choice control')
                    if properties.get('pcb_source_kind')=='eagle_pair_fixed_v1':raise ValueError('PCB source controls retain their original owner')
                    from viewer_bridge_control_v1 import canonical
                    return dict(descriptor_json=canonical(descriptor).decode(),component=index)
                dev.validate_bridge_request(packet['operation'],packet['request'],dev.DevelopmentError)
                from viewer_bridge_control_v1 import canonical
                return dict(descriptor_json=canonical(descriptor).decode(),operation=packet['operation'],header_json=canonical(packet['request'] if packet['operation'] in {'status','cancel','result','read_resource','reconnect','subscribe','unsubscribe'}else {}).decode())
            if action=='context' and set(payload)=={'control','descriptor'}:return str(context_stream(payload['descriptor'],generic_scope))
            raise ValueError('Unknown fixed generic control I/O action')
        unchanged();receipt.update(state='READY',snapshot=snapshot,grants=grants,generic_methods=generic_methods)
        dev.SCALAR_BROKER_CONTEXT=dict(token=token,core_requests={})
        dev.write_json(work/'derived'/name,receipt)
        print(json.dumps(dict(ok=True,pid=os.getpid())),flush=True)
        while True:
            raw=sys.stdin.buffer.readline(65537)
            if not raw:break
            try:
                if len(raw)>65536:raise ValueError('Trusted broker frame exceeds64KiB')
                payload=json.loads(raw)
                if isinstance(payload,dict) and 'control' in payload:
                    if payload['control']!='append':unchanged()
                    value=control(payload['control'],payload)
                    if payload['control']!='append':unchanged()
                    print(json.dumps(dict(ok=True,value=value),allow_nan=False),flush=True);continue
                if len(raw)>8192:raise ValueError('Scalar request exceeds8KiB')
                if set(payload)!={'message','deadline'}:raise ValueError('Invalid scalar request envelope')
                message=payload['message'];deadline=payload['deadline']
                if not isinstance(message,dict) or set(message)!={'request','operation','component','left','right','text'} or type(message['operation'])is not int or message['operation'] not in SCALAR or type(message['request'])is not int or not 1<=message['request']<=64 or message['component']!=0 or message['text']!='':raise ValueError('Only fixed scalar SDK messages are admitted')
                if SCALAR[message['operation']] not in grants or type(deadline) not in {int,float} or not math.isfinite(deadline) or not 0<deadline-time.monotonic()<=13:raise ValueError('Scalar grant or event deadline is invalid')
                unchanged()
                response,operations,numeric=dev.broker_message(work,message,{}, {'NUMERIC_API_v1':set(grants)},deadline)
                unchanged();result=dict(ok=True,response=response,numeric_receipts=numeric)
            except Exception as error:result=dict(ok=False,error=str(error))
            encoded=json.dumps(result,allow_nan=False)
            if len(encoded.encode())>65536:raise ValueError('Scalar response exceeds bound')
            print(encoded,flush=True)
    finally:
        stopping=True;limit=time.monotonic()+1.5
        if 'control_store' in locals() and control_store is not None:control_store.close()
        # A terminating Tcl helper can fork its native backend between samples.
        # Refresh adopted descendants until the whole exact scope is empty.
        while True:
            refresh_owned(record,os.getpid(),token)
            record['process_identities'].pop(str(os.getpid()),None)
            drain_tree(record,None,timeout=.2);reap_adopted(record)
            remaining=[pid for pid in process_tree(os.getpid()) if pid!=os.getpid()]
            if not remaining or time.monotonic()>=limit:break
        receipt.update(state='CLOSED',descendants_drained=not remaining,core_requests=(dev.SCALAR_BROKER_CONTEXT or {}).get('core_requests',{}),remaining_descendants=remaining)
        dev.write_json(work/'derived'/name,receipt)

if __name__=='__main__':main()
