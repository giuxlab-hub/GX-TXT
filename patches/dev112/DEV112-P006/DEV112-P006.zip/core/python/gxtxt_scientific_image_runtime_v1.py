"""Public process-local scientific image auxiliary runtime v1.

These are the original generic CORE owners, exported under supported names.
The API grants no source, parent, Resource, Job or publication authority. File
and process operations retain their original identity, Session and lease checks.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from viewer_canvas_request_v1 import decode_client_value
from gxtxt_resource_manager import ResourceManager
from scientific_image_materializer_v1 import (
    _parent as require_parent,
    _directory as open_directory,
    _open_source as open_source,
    _signature as file_signature,
)
from gxtxt_scientific_execution import tvalue as encode_tcl_value

API_ID = "SCIENTIFIC_IMAGE_AUXILIARY_RUNTIME_v1"
API_VERSION = 1
__all__ = ("API_ID", "API_VERSION", "decode_client_value", "ResourceManager",
           "require_parent", "open_directory", "open_source", "file_signature",
           "encode_tcl_value")
