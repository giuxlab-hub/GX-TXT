"""Typed Viewer frontend admission to the existing Script Project/Bridge owner.

API IDs and operations are intentionally not enumerated here. The authoritative
Script Bridge registration/provider performs their admission in the managed Job.
This adapter owns neither execution nor a Registry or scientific algorithms.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import base64
import hashlib
import json
from pathlib import Path
import os
import stat
import sys


def validate_request(action, request, error):
    def reject(message):
        raise error(message, 'RUNTIME_VALUE')
    fields = {
        'list': ((), ('language',)),
        'describe': (('api_id',), ('language',)),
        'require': (('requirements',), ('language',)),
        'call': (('api_id', 'operation', 'args'), ('api_version', 'provider_id', 'inputs', 'language')),
        'run': (('entrypoint',), ('parameters', 'inputs')),
        'status': (('job_id',), ()),
        'cancel': (('job_id',), ()),
        'result': (('job_id',), ()),
        'reconnect': (('job_id',), ('after_sequence',)),
        'subscribe': (('job_id',), ('after_sequence',)),
        'unsubscribe': (('job_id',), ()),
        'read_resource': (('job_id', 'resource_id', 'offset', 'count'), ()),
    }
    if action not in fields or not isinstance(request, dict):
        reject('Unknown generic Script Bridge frontend action')
    required, optional = fields[action]
    if not set(required) <= set(request) or set(request) - set(required) - set(optional):
        reject('Unknown or missing typed Script Bridge frontend fields')
    for key in ('api_id', 'operation', 'entrypoint', 'provider_id', 'job_id', 'resource_id'):
        if key in request and (not isinstance(request[key], str) or not request[key] or len(request[key].encode()) > 256 or '\0' in request[key]):
            reject('Frontend requires bounded inert identity text')
    if action == 'call' and not isinstance(request['args'], list):
        reject('Script Bridge args must be an ordered typed array')
    if action == 'require' and not isinstance(request['requirements'], list):
        reject('Script Bridge requirements must be an ordered array')
    for key in ('parameters', 'inputs'):
        if key in request and not isinstance(request[key], dict):
            reject('Script execution parameters/inputs must be typed objects')
    for key in ('api_version', 'offset', 'count', 'after_sequence'):
        if key in request and (type(request[key]) is not int or request[key] < (1 if key == 'api_version' else 0)):
            reject('Frontend requires exact nonnegative integer controls')
    if action == 'read_resource' and request['count'] > 16384:
        reject('Managed binary pages are bounded to 16 KiB')
    if 'language' in request and request['language'] not in ('Python','Octave'):
        reject('Select an actual configured Script Bridge runtime language')
    return request


def project_admission(module_root, module_id, action, request):
    """Re-admit installed source closure; paths are trusted CORE-only inputs."""
    from gxtxt_viewer_development import read_project, project_sources, source_identity
    from script_project import manifest
    root = Path(module_root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Installed Viewer module root is unavailable')
    project = root / 'source'
    meta = read_project(project, installed=True)
    if meta['module_id'] != module_id:
        raise ValueError('Viewer source belongs to a different module')
    files = project_sources(project, meta)
    pins = dict(source_tree_sha256=source_identity(files)['source_tree_sha256'], project_sha256=hashlib.sha256((project/'project.json').read_bytes()).hexdigest(), descriptor_sha256=hashlib.sha256((root/'module.ini').read_bytes()).hexdigest())
    if action == 'run':
        entry = request['entrypoint']
        if entry not in meta.get('script_entries', {}):
            raise ValueError('Viewer script entrypoint is not declared in its source project')
        item = meta['script_entries'][entry]
        language = item['language']
        entrypoint = item['entrypoint']
        extension = '.py' if language == 'Python' else '.m'
        sources = {name: raw for name, raw in files.items() if name.startswith('scripts/') and name.endswith(extension)}
        parameters = item.get('parameters', {})
        required = item.get('required_apis', '')
    else:
        language = request.get('language','Python')
        if language not in ('Python','Octave'):
            raise ValueError('Unknown Script Bridge frontend runtime language')
        entrypoint = 'viewer_bridge_job.py' if language == 'Python' else 'viewer_bridge_job.m'
        runner_path = Path(__file__).with_name('viewer_bridge_job_v1.py') if language == 'Python' else Path(__file__).parents[1]/'octave/viewer_bridge_job_v1.m'
        runner = runner_path.read_bytes()
        sources = {entrypoint: runner}
        pins['frontend_runner_sha256'] = hashlib.sha256(runner).hexdigest()
        parameters = {'request_json': {'type': 'string', 'required': 1, 'default': ''}}
        # Same shared Bridge declarations, with no extra C++ API allowlist.
        required = ''
    source_manifest, declared, source_parameters = manifest(language, entrypoint, sources)
    required = ';'.join(sorted(set(filter(None, required.replace(',', ';').split(';'))) | set(declared)))
    # Existing Script Registry schema normalization remains the authority.
    pins['script_project_sha256'] = source_manifest['sha256']
    from viewer_bridge_buffers_v1 import discover_references
    input_references = discover_references(request['args']) if action == 'call' else []
    return dict(language=language, entrypoint=entrypoint,
                entrypoint_sha256=hashlib.sha256(sources[entrypoint]).hexdigest(),
                project_sha256=source_manifest['sha256'], required_apis=required,
                parameters=parameters, source_parameters=source_parameters, input_references=input_references,
                sources={k:v.decode('utf-8') for k,v in sources.items()}, pins=pins)


def _owned_directory(path):
    """Do not let a same-UID alias borrow another Job's retained buffers."""
    root = Path(path).absolute()
    if any(part.is_symlink() for part in (root, *root.parents)):
        raise ValueError('Viewer result directories forbid symlink aliases and ancestors')
    info = root.stat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        raise ValueError('Viewer result directory owner/type mismatch')
    return root


def read_result(output, resource_id=None, offset=0, count=16384):
    root = _owned_directory(output)
    path = root / 'viewer_bridge_result.json'
    if path.is_symlink() or not path.is_file() or path.stat().st_size > 1048576 or path.stat().st_nlink != 1 or path.stat().st_uid != os.getuid():
        raise ValueError('Managed script has no bounded Viewer result receipt')
    value = json.loads(path.read_text())
    from viewer_bridge_control_v1 import result_value
    value=result_value(root,value)
    if resource_id is None:
        return value
    descriptors = {}
    def collect(item):
        if isinstance(item, dict):
            if item.get('schema') == 'gxtxt.viewer_bridge_buffer.v1':
                descriptor = item['descriptor']
                descriptors[descriptor['resource_id']] = (descriptor,item.get('sha256'))
            else:
                for child in item.values(): collect(child)
        elif isinstance(item, list):
            for child in item: collect(child)
    collect(value.get('result') if isinstance(value,dict) else None)
    if resource_id not in descriptors:
        raise ValueError('Binary resource does not belong to this retained Job result')
    if type(offset) is not int or offset < 0 or type(count) is not int or not 0 <= count <= 16384:
        raise ValueError('Binary result page exceeds its bound')
    from gxtxt_scientific_binary_v1 import open_buffer
    descriptor, expected_sha256 = descriptors[resource_id]
    if expected_sha256 is not None and (not isinstance(expected_sha256,str) or len(expected_sha256)!=64 or any(c not in '0123456789abcdef' for c in expected_sha256)):
        raise ValueError('Retained binary resource requires an exact SHA256 receipt')
    directory = _owned_directory(root / 'viewer_bridge_arrays')
    fd, _, _ = open_buffer(directory, descriptor)
    try:
        if os.fstat(fd).st_nlink != 1:
            raise ValueError('Viewer result buffer cannot be shared through a hard link')
        os.lseek(fd, offset, os.SEEK_SET)
        data = os.read(fd, min(count, max(0, descriptor['byte_count']-offset)))
    finally:
        os.close(fd)
    return dict(descriptor=descriptor, resource_sha256=expected_sha256, offset=offset, bytes=len(data), bytes_base64=base64.b64encode(data).decode('ascii'), eof=offset+len(data)>=descriptor['byte_count'])


if __name__ == '__main__':
    from gxtxt_job_supervisor import tcl_result
    action = sys.argv[1]
    if action in {'admit','admit_control','admit_frozen'}:
        request = json.loads(sys.stdin.read())
        if action=='admit_control':
            from viewer_bridge_control_v1 import resource_packet
            request=resource_packet(request['descriptor'],request['scope'])['request']
        if action=='admit_frozen':
            from viewer_bridge_control_v1 import frozen_request
            request=frozen_request(request['output'],request['manifest_sha256'])['request']
        result = project_admission(sys.argv[2], sys.argv[3], sys.argv[4], request)
        if action=='admit_control' and 'inputs' in request:result['control_inputs']=request['inputs']
        print(tcl_result(result))
    elif action == 'result':
        result = read_result(sys.argv[2], *(sys.argv[3:4]), *[int(v) for v in sys.argv[4:]])
        print(json.dumps(result, allow_nan=False, separators=(',', ':')))
    elif action in {'freeze_inputs','freeze_control_inputs'}:
        from viewer_bridge_buffers_v1 import freeze_inputs, MANIFEST_NAME
        request = json.loads(sys.stdin.read())
        if action=='freeze_control_inputs':
            from viewer_bridge_control_v1 import resource_packet
            control=request['control'];request['args']=resource_packet(control['descriptor'],control['scope'])['request']['args']
        freeze_inputs(request['args'], request['sources'], sys.argv[2])
        print(tcl_result(dict(manifest_sha256=hashlib.sha256((Path(sys.argv[2])/MANIFEST_NAME).read_bytes()).hexdigest())))
    elif action == 'encode_wire':
        request = json.loads(sys.stdin.read())
        language = sys.argv[2] if len(sys.argv)>2 else 'Octave'
        if language not in {'Python','Octave'}:raise ValueError('Unknown Script Bridge runtime language')
        # Fixed metadata armor avoids INI escape rewriting. Application values
        # are packed only by the original per-argument codec at depth0/MAX32.
        wire=json.dumps(request,allow_nan=False,separators=(',',':')).encode('utf-8')
        print(json.dumps(dict(viewer_request_base64=base64.b64encode(wire).decode('ascii')),separators=(',',':')))
    else:
        raise SystemExit('Unknown trusted Viewer Bridge adapter command')
