"""Faithful supplied-value transport to fixed original public owners.

The four-string TclValue is opaque DATA, not a recovered scientific type or a
callback/resource descriptor. Ordinary Script Bridge values use its existing
Tcl conversion. Opaque carriers may occur inside ordinary lists/structs.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import tkinter
import json
import _tkinter
from gxtxt_script_bridge_server import BridgeError, NumericArray, encode_value

FORMAT = 'gxtxt.inert_tcl_value.v2'
_FIELDS = {'format', 'representation', 'shape', 'lexeme'}
MAX_INPUT_BYTES = 16 * 1024 * 1024
MAX_OUTPUT_HEX = 48 * 1024 * 1024
MAX_WIRE_BYTES = 64 * 1024 * 1024
MAX_NODES = 100000
ROOT = Path(__file__).resolve().parents[2]
_TARGETS = {
    'toText': (1, 2), 'filterRoi': (2, 2), 'extractLayout': (1, 2),
    'nativeModel': (2, 2), 'historyValidate': (1, 1), 'validate': (1, 1),
    'rebase': (3, 3),
    'viewerGuiComponentDemoCatalog': (0, 0), 'viewerGuiComponentDemoRegister': (2, 2),
    'viewerGuiDesignAnalysisProfile': (3, 3), 'viewerGuiDesignHandlerSource': (2, 2),
    'viewerGuiDesignModelCreate': (1, 1), 'viewerGuiDesignModelEdit': (2, None),
    'viewerGuiDesignValidate': (1, 1), 'viewerGuiIconEdit': (2, None),
    'viewerGuiIconsValidate': (1, 1), 'viewerGuiTestFixtureValidate': (2, 2),
}


def descriptor(name, fields, result, optional=False):
    return {'name': name, 'summary': 'Original supplied-value owner: ' + name,
            'arguments': [{'name': field, 'kind': 'public value or whole TclValue',
                           'required': not (optional and i == len(fields)-1)}
                          for i, field in enumerate(fields)],
            'argument_convention': ', '.join(fields) +
                 ('; omitted options use the original native default' if optional else ''),
            'result_contract': result + '; complete original errors; ordinary shared transport limits; no scientific algorithm or authority added'}


def is_value(value):
    return (isinstance(value, dict) and set(value) == _FIELDS and
            value.get('format') == FORMAT and value.get('shape') == 'unresolved' and
            value.get('representation') in ('unicode_text', 'tcl_unicode_hex_le', 'tcl_unicode_hex_be'))


def _load(host):
    if not getattr(host, '_script_values_v1_loaded', False):
        host.call('source', str(ROOT / 'core/tcl/script_value_transport_v1.tcl'))
        host._script_values_v1_loaded = True


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _carrier(host, raw):
    fields = host.as_dict(raw)
    return {str(k): str(host.tcl.call('format', '%s', v)) for k, v in fields.items()}


def text(value):
    """Decode an explicit whole value for display, not type/shape inference."""
    representation = value['representation']
    if representation == 'unicode_text':
        return value['lexeme']
    codec = {'tcl_unicode_hex_le': 'utf-16-le', 'tcl_unicode_hex_be': 'utf-16-be'}[representation]
    return bytes.fromhex(value['lexeme']).decode(codec, errors='surrogatepass')


def _argument(host, value, budget, depth=0):
    budget[1] += 1
    if depth > 64 or budget[1] > MAX_NODES:
        raise BridgeError('GXTXT:ScriptBridge:ResourceLimit', 'Value transport exceeds nesting/node limit')
    if is_value(value):
        if set(value) != _FIELDS or any(type(v) is not str for v in value.values()) or value['shape'] != 'unresolved':
            _invalid('Whole TclValue requires its exact four text fields and unresolved shape')
        budget[0] += len(value['lexeme'].encode('utf-8'))
        if budget[0] > MAX_INPUT_BYTES:
            raise BridgeError('GXTXT:ScriptBridge:ResourceLimit', 'Whole value arguments exceed 16 MiB')
        return host.tcl.call('::GX::ScriptValueTransportV1::unpack', value['representation'], value['lexeme'])
    if isinstance(value, dict):
        values = []
        for key, child in value.items():
            if not isinstance(key, str):
                _invalid('Script struct keys must be text')
            values.extend((_argument(host, key, budget, depth+1), _argument(host, child, budget, depth+1)))
        return host.tcl.call('dict', 'create', *values)
    if isinstance(value, (list, tuple)):
        return host.tcl.call('list', *(_argument(host, v, budget, depth+1) for v in value))
    if value is None:
        _invalid('Tcl has no distinct null argument; use explicit empty text for its empty value')
    # Only actual value types, never CallbackRef or arbitrary Python objects
    # whose __str__ would invent an opaque value or apparent authority.
    if not isinstance(value, (str, int, float, bool, NumericArray, _tkinter.Tcl_Obj)):
        _invalid('Value arguments cannot contain callbacks or executable objects')
    # Reuse normal NumericArray, scalar, signed-zero and Boolean conversions.
    raw = host.tcl_arg(value)
    rendered = host.tcl.call('format', '%s', raw)
    budget[0] += len(str(rendered).encode('utf-8', errors='surrogatepass'))
    if budget[0] > MAX_INPUT_BYTES:
        raise BridgeError('GXTXT:ScriptBridge:ResourceLimit', 'Whole value arguments exceed 16 MiB')
    return raw


def arguments(host, values):
    _load(host)
    budget = [0, 0]
    return [_argument(host, v, budget) for v in values]


def _recipe_owner(host, context):
    # Compose with the original owner registration. No fabricated Host/Window,
    # callback, captured Document or substitute validator is installed here.
    try:
        owner = host.tcl.call('dict', 'get', context, 'owner')
        # Missing context fields remain the original rebase owner's errors.
        for key in ('document_id', 'retention'):
            host.tcl.call('dict', 'get', context, key)
    except tkinter.TclError:
        return
    hosts = host.tcl.getvar('::GX::ScientificRecipe::hosts')
    if not int(host.tcl.call('dict', 'exists', hosts, owner)):
        # Same normal activation route used by scientificRecipeValidate.
        if not host.call('::GX::moduleField', owner, 'descriptor', ''):
            return  # No invented owner: original rebase reports unregistered.
        for api in host.as_list(host.call('::GX::modulePublicApiIds', owner)):
            host.call('::GX::modulePublicApiActivate', owner, api)


def _wire_limit(response):
    # Reuse the server's actual typed encoder/JSON convention. Count the LF;
    # control-character escaping and NUL Base64 cannot evade the Octave cap.
    wire = json.dumps(response, ensure_ascii=False, separators=(',', ':')) + '\n'
    if len(wire.encode('utf-8')) > MAX_WIRE_BYTES:
        raise BridgeError('GXTXT:ScriptBridge:ResourceLimit', 'Complete native response exceeds 64 MiB wire limit; no partial native outcome returned')


def _returned(value):
    _wire_limit({'ok': True, 'value': encode_value(value)})
    return value


def invoke(host, api, operation, values, converter=None, public_operation=None):
    minimum, maximum = _TARGETS[operation]
    if len(values) < minimum or (maximum is not None and len(values) > maximum):
        _invalid(operation + ' requires its original argument count')
    argv = arguments(host, values)
    if operation == 'rebase':
        _recipe_owner(host, argv[2])
    raw = host.tcl.call('::GX::ScriptValueTransportV1::invoke', operation, tuple(argv))
    outcome = host.as_dict(raw)
    result = _carrier(host, outcome['result'])
    options = _carrier(host, outcome['options'])
    if len(result['lexeme']) + len(options['lexeme']) > MAX_OUTPUT_HEX:
        raise BridgeError('GXTXT:ScriptBridge:ResourceLimit', 'Complete native outcome exceeds shared wire budget; no truncated result returned')
    code = int(host.tcl.call('format', '%s', outcome['code']))
    if code:
        message = text(result)
        # Non-scalar Tcl Unicode remains available in the complete carrier.
        message = message.encode('utf-8', errors='backslashreplace').decode('utf-8')
        error = BridgeError('GXTXT:ScriptBridge:RemoteError', api + '/' + (public_operation or operation) + ': ' + message)
        error.native_outcome = {'code': code, 'result': result, 'options': options}
        _wire_limit({'ok': False, 'identifier': error.identifier, 'message': str(error),
                     'native_outcome': error.native_outcome})
        raise error
    if converter is not None:
        value = converter(host, result)
        # Shared uint8 output encoding owns its managed file exactly once in
        # the server, not once for a size probe and again for the real reply.
        return value if isinstance(value, NumericArray) else _returned(value)
    if operation in ('historyValidate', 'validate'):

        return _returned(int(text(result)))
    if operation == 'toText':
        value = text(result)
        try:
            value.encode('utf-8')
        except UnicodeError:
            return _returned(result)  # Full non-scalar native code units, never replacement.
        return _returned(value)
    return _returned(result)


def rebase(host, args):
    if len(args) != 3:
        _invalid('rebase requires record, current and context')
    encoded = isinstance(args[0], str)
    values = list(args)
    if encoded:
        values[0] = host.call('::GX::scientificRecipeDataDecode', args[0], 'gxtxt.scientific_recipe.v1')
    result = invoke(host, 'SCIENTIFIC_RECIPE_API_v1', 'rebase', values)
    if encoded:
        native = arguments(host, [result])[0]
        data = host.tcl.call('::GX::scientificRecipeEncode', native)
        return _returned(data.decode('ascii') if isinstance(data, bytes) else str(data))
    return result
