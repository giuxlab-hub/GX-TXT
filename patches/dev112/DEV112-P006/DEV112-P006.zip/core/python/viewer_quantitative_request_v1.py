# SPDX-License-Identifier: GPL-3.0-or-later
"""Finite original-source quantitative requests; live owners validate at dispatch."""
import math
import re

OPERATIONS = ('discover', 'submit', 'status', 'cancel', 'result', 'histogram_page', 'map_roi', 'reconnect')


def validate_quantitative_request(operation, request, error):
    def reject(message):
        raise error(message, 'RUNTIME_VALUE')
    schemas = {
        'discover': ({'object'}, set()),
        'map_roi': ({'object', 'roi_id'}, set()),
        'submit': ({'object', 'operation', 'expected_sha256', 'expected_revision'},
                   {'roi_id', 'x', 'y', 'width', 'height', 'channels', 'frame',
                    'histogram_mode', 'bins', 'domain_low', 'domain_high'}),
        'status': ({'job_id'}, set()), 'cancel': ({'job_id'}, set()),
        'result': ({'job_id'}, set()),
        'reconnect': ({'job_id'}, set()),
        'histogram_page': ({'job_id', 'token', 'generation', 'offset', 'count'}, set()),
    }
    if operation not in schemas or not isinstance(request, dict):
        reject('Unknown finite quantitative operation')
    required, optional = schemas[operation]
    if not required <= set(request) or set(request) - required - optional:
        reject('Unknown or missing quantitative request field')
    for key, value in request.items():
        if key in {'x', 'y', 'width', 'height', 'frame', 'bins', 'offset', 'count'}:
            upper = {'x': 16383, 'y': 16383, 'width': 16384, 'height': 16384,
                     'frame': 0, 'bins': 65536, 'offset': 65535, 'count': 256}[key]
            lower = 1 if key in {'width', 'height', 'bins', 'count'} else 0
            if type(value) is not int or not lower <= value <= upper:
                reject('Quantitative integer violates its finite bounds')
        elif key in {'domain_low', 'domain_high'}:
            if type(value) not in (int, float) or not math.isfinite(value):
                reject('Histogram domain requires finite numeric edges')
        else:
            limit = 64 if key == 'expected_revision' else 256
            if not isinstance(value, str) or not value or '\0' in value or len(value.encode('utf-8')) > limit:
                reject('Quantitative identity must be bounded nonempty UTF-8')
    if 'expected_sha256' in request and not re.fullmatch('[a-f0-9]{64}', request['expected_sha256']):
        reject('Exact canonical SHA-256 is required')
    if 'expected_revision' in request and not re.fullmatch('[a-f0-9]{64}', request['expected_revision']):
        reject('Exact opaque canonical revision SHA-256 is required')
    if operation == 'submit':
        if request['operation'] not in {'describe', 'pixel', 'statistics', 'histogram'}:
            reject('Unknown original-sample measurement')
        if 'roi_id' in request and set(request) & {'x', 'y', 'width', 'height'}:
            reject('Choose one retained ROI or an explicit pixel rectangle')
        if 'roi_id' not in request and request['operation'] != 'describe':
            if not {'x', 'y'} <= set(request):
                reject('Explicit source pixel coordinates are required')
            if request['operation'] != 'pixel' and not {'width', 'height'} <= set(request):
                reject('Explicit half-open source rectangle is required')
        if request.get('histogram_mode', 'native') not in {'native', 'bounded'}:
            reject('Unknown histogram mode')
        if request.get('histogram_mode') == 'bounded':
            if not {'domain_low', 'domain_high', 'bins'} <= set(request) or request['domain_low'] >= request['domain_high'] or request['bins'] > 4096:
                reject('Bounded histogram requires 1..4096 bins and increasing explicit edges')
    return request
