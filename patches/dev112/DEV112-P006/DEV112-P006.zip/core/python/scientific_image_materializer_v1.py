#!/usr/bin/env python3
"""Private byte capture for the original ScientificExecution image profile.

This helper has no scientific dispatch or public pathname capability. Its caller
is the source-qualified original Job preparer, which derives paths from current
Dataset/Document owners. ResourceManager remains the quota/lifetime authority.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import base64
import configparser
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gxtxt_resource_manager import ResourceManager, process_identity
from gxtxt_scientific_execution import tdict, tvalue, decode_request, _observe_output_fd

CHUNK = 1048576
PROFILE = 'image_resource_files_v1'
NATIVE_SOURCE_PROFILE = 'native_canvas_document_v1'


def native_source_binding(request):
    """Correlate data issued by the private GUI binder, not public authority.

    Only the original private CORE service can supply this request. The public
    ScientificExecution preparation constructs its request from closed fields;
    neither user Script Jobs nor registered Script Bridge operations can mint
    this binding. The digest checks transport identity, not GUI permission.
    """
    keys = ('image_source_profile', 'image_native_projection',
            'image_native_canonical_sources', 'image_native_projection_sha256')
    if not any(key in request for key in keys):
        return '', ''
    if (not all(key in request for key in keys) or
            request['image_source_profile'] != NATIVE_SOURCE_PROFILE or
            request.get('image_profile') != PROFILE or
            not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]*', request.get('provider_id', ''))):
        raise ValueError('Incomplete original scientific Canvas binding')
    if 'image_provider_binding' in request:
        binding = tdict(request['image_provider_binding'])
        if binding.get('canvas_source_profile') != NATIVE_SOURCE_PROFILE:
            raise ValueError('Registered provider does not admit the Canvas source profile')
    elif tdict(request['image_recipe']).get('kind') != 'figure':
        # Existing completed snapshots retain their original closed recipe
        # check. New executions additionally require module-issued binding.
        raise ValueError('Invalid legacy scientific Canvas recipe')
    projection = request['image_native_projection']
    if not isinstance(projection, str) or len(projection.encode('utf-8')) > 8388608:
        raise ValueError('Scientific Canvas projection exceeds its original snapshot bound')
    digest = _sha(request['image_native_projection_sha256'])
    if hashlib.sha256(base64.b64encode(projection.encode('utf-8'))).hexdigest() != digest:
        raise ValueError('Scientific Canvas projection transport changed')
    return NATIVE_SOURCE_PROFILE, digest


def _source_limit(source_profile, projection_sha256):
    if not source_profile and not projection_sha256:
        return 16
    if source_profile != NATIVE_SOURCE_PROFILE:
        raise ValueError('Unknown private scientific source-owner profile')
    _sha(projection_sha256)
    return 4000


def _fields(value, required):
    if not isinstance(value, dict) or set(value) != set(required):
        raise ValueError('Invalid private image capture fields')


def _integer(value):
    if not isinstance(value, str) or not re.fullmatch(r'0|[1-9][0-9]*', value):
        raise ValueError('Invalid image byte count')
    return int(value)


def _sha(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9a-f]{64}', value):
        raise ValueError('Invalid image byte digest')
    return value


def _hash_exact(fd, size):
    """Hash one held byte image without following a concurrently growing EOF."""
    before = os.fstat(fd)
    if type(size) is not int or size < 0 or before.st_size != size:
        raise ValueError('Held image size differs before verification')
    original = _signature(before)
    os.lseek(fd, 0, os.SEEK_SET)
    remaining = size + 1
    count = 0
    digest = hashlib.sha256()
    while remaining:
        chunk = os.read(fd, min(CHUNK, remaining))
        if not chunk:
            break
        remaining -= len(chunk)
        count += len(chunk)
        if count > size:
            raise ValueError('Held image grew beyond its admitted byte count')
        digest.update(chunk)
    if count != size or _signature(os.fstat(fd)) != original:
        raise ValueError('Held image changed during bounded verification')
    os.lseek(fd, 0, os.SEEK_SET)
    return digest.hexdigest()


def _read_stable(fd, size):
    """Capture the admitted finite control bytes before invoking a parser."""
    before = os.fstat(fd)
    if type(size) is not int or size < 0 or before.st_size != size:
        raise ValueError('Image control size changed before reading')
    original = _signature(before)
    os.lseek(fd, 0, os.SEEK_SET)
    remaining = size + 1
    data = bytearray()
    while remaining:
        chunk = os.read(fd, min(CHUNK, remaining))
        if not chunk:
            break
        remaining -= len(chunk)
        if len(data) + len(chunk) > size:
            raise ValueError('Image control grew beyond its admitted size')
        data.extend(chunk)
    if len(data) != size or _signature(os.fstat(fd)) != original:
        raise ValueError('Image control changed during bounded reading')
    os.lseek(fd, 0, os.SEEK_SET)
    return bytes(data)


def _absolute(value):
    # Reject lexical escapes BEFORE any filesystem access or normalization.
    if not isinstance(value, str) or not value.startswith('/') or '\0' in value:
        raise ValueError('Image owner path must be absolute')
    if any(part in ('.', '..') for part in value.split('/')):
        raise ValueError('Image owner path cannot contain traversal')
    return Path(value)


def _directory(path, *, private=False):
    path = _absolute(str(path))
    fd = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for component in path.parts[1:]:
            child = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW,
                            dir_fd=fd)
            os.close(fd)
            fd = child
        identity = os.fstat(fd)
        if private and (identity.st_uid != os.getuid() or identity.st_mode & 0o077):
            raise ValueError('Image snapshot owner must be private')
        return fd
    except BaseException:
        os.close(fd)
        raise


def _open_source(path):
    path = _absolute(path)
    parent = _directory(path.parent)
    try:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                     dir_fd=parent)
    finally:
        os.close(parent)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd)
        raise ValueError('Image source must be an ordinary file')
    return fd


def _signature(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def _parent(expected_pid, expected_identity):
    if (not isinstance(expected_identity, str) or expected_identity in ('dead', 'unknown') or
            expected_pid < 1 or os.getppid() != expected_pid or
            process_identity(expected_pid) != expected_identity):
        raise ValueError('Original image preparer is no longer alive')


def capture_inputs(envelope):
    """Copy original admitted files; source authority is checked by Tcl owner.

    The reservation belongs to the still-live preparer. The helper inherits its
    explicit lease at exec, so cleanup cannot race a copied child after loss of
    the preparer. No allocation or leaf marker is accepted from public callers.
    """
    extra = ('source_profile', 'native_projection_sha256') if any(
        key in envelope for key in ('source_profile', 'native_projection_sha256')) else ()
    _fields(envelope, ('profile', 'session', 'output', 'run_id', 'reservation',
                       'parent_pid', 'parent_identity', 'sources') + extra)
    source_profile = envelope.get('source_profile', '')
    projection_sha256 = envelope.get('native_projection_sha256', '')
    source_limit = _source_limit(source_profile, projection_sha256)
    if envelope['profile'] != PROFILE:
        raise ValueError('Unregistered image capture profile')
    session = _absolute(envelope['session'])
    output = _absolute(envelope['output'])
    run_id = envelope['run_id']
    if not re.fullmatch(r'script-[0-9]{8}T[0-9]{6}Z-[0-9]+-[0-9]+', run_id):
        raise ValueError('Invalid original Job snapshot identity')
    if output != session / 'analysis' / 'scripts' / run_id:
        raise ValueError('Image capture is outside its original Job snapshot')
    parent_pid = _integer(envelope['parent_pid'])
    parent_identity = envelope['parent_identity']
    _parent(parent_pid, parent_identity)
    sources = {key: tdict(value) for key, value in tdict(envelope['sources']).items()}
    if not (0 if source_profile else 1) <= len(sources) <= source_limit:
        raise ValueError('Image capture requires the finite original source set')
    total = 0
    for alias, source in sources.items():
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}', alias):
            raise ValueError('Invalid image input alias')
        _fields(source, ('source_path', 'input_sha256', 'input_bytes', 'source_guard'))
        _absolute(source['source_path'])
        _sha(source['input_sha256'])
        total += _integer(source['input_bytes'])
    manager = ResourceManager(root=os.environ.get('GXTXT_RESOURCE_ROOT'),
                              storage_root=os.environ.get('GXTXT_RESOURCE_STORAGE'))
    try:
        reservation = manager.inspect(envelope['reservation'])
        if (reservation['owner_pid'] != parent_pid or
                reservation['owner_identity'] != parent_identity or
                reservation.get('released') or reservation.get('removed') or
                not reservation.get('managed') or not reservation.get('descendant_lease') or
                int(reservation.get('expected_bytes', 0)) < 2 * total or
                reservation.get('session') != str(session) or
                os.environ.get('GXTXT_RESOURCE_LEASE') != reservation['id']):
            raise ValueError('Image capture lacks its actual reserved owner lease')
        output_fd = _directory(output, private=True)
        created = []
        directory_fd = None
        try:
            os.mkdir('scientific-image-inputs', mode=0o700, dir_fd=output_fd)
            directory_fd = os.open('scientific-image-inputs', os.O_RDONLY | os.O_DIRECTORY |
                                   os.O_NOFOLLOW, dir_fd=output_fd)
            rows = {}
            written = 0
            for alias, source in sources.items():
                _parent(parent_pid, parent_identity)
                name = alias + '.bin'
                input_fd = _open_source(source['source_path'])
                try:
                    original = os.fstat(input_fd)
                    size = _integer(source['input_bytes'])
                    if original.st_size != size:
                        raise ValueError('Image source byte count changed before capture')
                    target = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                                     os.O_NOFOLLOW, 0o600, dir_fd=directory_fd)
                    created.append((name, _signature(os.fstat(target))[:2]))
                    digest = hashlib.sha256()
                    count = 0
                    try:
                        while True:
                            _parent(parent_pid, parent_identity)
                            chunk = os.read(input_fd, CHUNK)
                            if not chunk:
                                break
                            if count + len(chunk) > size or written + len(chunk) > total:
                                raise ValueError('Image capture exceeded its declared reservation')
                            view = memoryview(chunk)
                            while view:
                                view = view[os.write(target, view):]
                            digest.update(chunk)
                            count += len(chunk)
                            written += len(chunk)
                            if _signature(os.fstat(input_fd)) != _signature(original):
                                raise ValueError('Image source changed during capture')
                        os.fsync(target)
                    finally:
                        os.close(target)
                    if (count != size or digest.hexdigest() != source['input_sha256'] or
                            _signature(os.fstat(input_fd)) != _signature(original)):
                        raise ValueError('Image capture failed complete-byte integrity')
                    rows[alias] = dict(file='scientific-image-inputs/' + name,
                                       sha256=digest.hexdigest(), size_bytes=count,
                                       source_guard=source['source_guard'])
                finally:
                    os.close(input_fd)
            _parent(parent_pid, parent_identity)
            if written != total:
                raise ValueError('Incomplete image capture')
            manifest = dict(schema='gxtxt.scientific.image_inputs.v1', inputs=rows,
                            total_bytes=total, run_id=run_id)
            if source_profile:
                manifest.update(source_profile=source_profile,
                                native_projection_sha256=projection_sha256)
            raw = json.dumps(manifest, sort_keys=True, ensure_ascii=False,
                             separators=(',', ':')).encode('utf-8')
            if len(raw) > (8388608 if source_profile else CHUNK):
                raise ValueError('Sealed image manifest exceeds its finite source-owner profile')
            fd = os.open('manifest.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                         os.O_NOFOLLOW, 0o600, dir_fd=directory_fd)
            created.append(('manifest.json', _signature(os.fstat(fd))[:2]))
            try:
                view = memoryview(raw)
                while view:
                    view = view[os.write(fd, view):]
                os.fsync(fd)
            finally:
                os.close(fd)
            return dict(profile=PROFILE, file='scientific-image-inputs/manifest.json',
                        sha256=hashlib.sha256(raw).hexdigest(), size_bytes=len(raw),
                        total_bytes=total, reservation=reservation['id'])
        except BaseException:
            if directory_fd is not None:
                for name, identity in reversed(created):
                    try:
                        current = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
                        if stat.S_ISREG(current.st_mode) and _signature(current)[:2] == identity:
                            os.unlink(name, dir_fd=directory_fd)
                    except FileNotFoundError:
                        pass
            raise
        finally:
            if directory_fd is not None:
                os.close(directory_fd)
            os.close(output_fd)
    finally:
        manager.close()


def verify_snapshot(output, descriptor, source_profile='', projection_sha256=''):
    """Verify the sealed original Job input inventory before provider import."""
    _fields(descriptor, ('profile', 'file', 'sha256', 'size_bytes', 'total_bytes'))
    if descriptor['profile'] != PROFILE or descriptor['file'] != 'scientific-image-inputs/manifest.json':
        raise ValueError('Invalid sealed image input descriptor')
    _sha(descriptor['sha256'])
    source_limit = _source_limit(source_profile, projection_sha256)
    manifest_limit = 8388608 if source_profile else CHUNK
    output = _absolute(str(output))
    owner = _directory(output, private=True)
    os.close(owner)
    path = output / descriptor['file']
    fd = _open_source(str(path))
    try:
        before = os.fstat(fd)
        if (before.st_nlink != 1 or before.st_uid != os.getuid() or
                before.st_size != _integer(descriptor['size_bytes']) or before.st_size > manifest_limit):
            raise ValueError('Unsafe sealed image manifest')
        raw = _read_stable(fd, before.st_size)
        if (hashlib.sha256(raw).hexdigest() != descriptor['sha256'] or
                _signature(os.fstat(fd)) != _signature(before)):
            raise ValueError('Sealed image manifest changed')
    finally:
        os.close(fd)
    def unique(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError('Duplicate sealed image field')
            value[key] = item
        return value
    manifest = json.loads(raw.decode('utf-8'), object_pairs_hook=unique)
    extra = ('source_profile', 'native_projection_sha256') if source_profile else ()
    _fields(manifest, ('schema', 'inputs', 'total_bytes', 'run_id') + extra)
    if source_profile and (manifest['source_profile'] != source_profile or
                           manifest['native_projection_sha256'] != projection_sha256):
        raise ValueError('Sealed scientific Canvas source binding changed')
    if (manifest['schema'] != 'gxtxt.scientific.image_inputs.v1' or
            manifest['run_id'] != output.name or type(manifest['total_bytes']) is not int or
            manifest['total_bytes'] != _integer(descriptor['total_bytes']) or
            not isinstance(manifest['inputs'], dict) or
            not (0 if source_profile else 1) <= len(manifest['inputs']) <= source_limit):
        raise ValueError('Sealed image inventory identity changed')
    files = {}
    total = 0
    for alias, item in manifest['inputs'].items():
        _fields(item, ('file', 'sha256', 'size_bytes', 'source_guard'))
        if (not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}', alias) or
                item['file'] != 'scientific-image-inputs/' + alias + '.bin' or
                type(item['size_bytes']) is not int or item['size_bytes'] < 0 or
                not isinstance(item['source_guard'], str)):
            raise ValueError('Invalid sealed image input')
        _sha(item['sha256'])
        filename = output / item['file']
        fd = _open_source(str(filename))
        try:
            before = os.fstat(fd)
            if before.st_nlink != 1 or before.st_uid != os.getuid() or before.st_size != item['size_bytes']:
                raise ValueError('Sealed image byte identity changed')
            digest = _hash_exact(fd, item['size_bytes'])
            if digest != item['sha256'] or _signature(os.fstat(fd)) != _signature(before):
                raise ValueError('Sealed image bytes changed before provider import')
        finally:
            os.close(fd)
        files[alias] = filename
        total += item['size_bytes']
    if total != manifest['total_bytes']:
        raise ValueError('Sealed image total byte count differs')
    return files, manifest['inputs']


def _unique_fields(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate immutable image output field')
        result[key] = value
    return result


def _runtime_request(output, expected_sha256):
    """Bind both actual runtime fields to the immutable durable Job parameter."""
    _sha(expected_sha256)
    fd = _open_source(str(output / 'runtime.ini'))
    try:
        before = os.fstat(fd)
        if before.st_nlink != 1 or before.st_uid != os.getuid():
            raise ValueError('Unsafe original image runtime')
        parser = configparser.ConfigParser(interpolation=None, strict=False)
        parser.read_string(_read_stable(fd, before.st_size).decode('utf-8'))
        first = parser.get('script_parameter.request', 'value')
        second = parser.get('parameters', 'request')
        if (first != second or hashlib.sha256(first.encode('ascii')).hexdigest() != expected_sha256 or
                _signature(os.fstat(fd)) != _signature(before)):
            raise ValueError('Image runtime differs from durable Job parameters')
        return decode_request(first)
    finally:
        os.close(fd)


def _image_owner_request(envelope, *, original=False):
    """One scope/parser for the fixed output and sealed-original actions."""
    required = ('profile', 'session', 'output', 'run_id', 'job_id',
                'request_sha256', 'output_token', 'generation')
    _fields(envelope, required + (('input_alias',) if original else ()))
    if envelope['profile'] != PROFILE or envelope['job_id'] != envelope['run_id']:
        raise ValueError('Invalid original image output Job identity')
    session = _absolute(envelope['session'])
    output = _absolute(envelope['output'])
    if (output != session / 'analysis' / 'scripts' / envelope['run_id'] or
            not re.fullmatch(r'script-[0-9]{8}T[0-9]{6}Z-[0-9]+-[0-9]+', envelope['run_id'])):
        raise ValueError('Image output is outside its original Job')
    directory = _directory(output, private=True)
    os.close(directory)
    request = _runtime_request(output, envelope['request_sha256'])
    if request.get('image_profile') != PROFILE or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.-]*', request.get('provider_id', '')):
        raise ValueError('Image output request has another provider')
    return output, request


def _held_outputs(envelope):
    """Open and bind immutable output files without exposing caller paths."""
    output, request = _image_owner_request(envelope)
    fd = _open_source(str(output / 'scientific-outputs.json'))
    try:
        before = os.fstat(fd)
        if before.st_nlink != 1 or before.st_uid != os.getuid():
            raise ValueError('Unsafe scientific output manifest')
        manifest = json.loads(_read_stable(fd, before.st_size).decode('utf-8'),
                              object_pairs_hook=_unique_fields)
        if _signature(os.fstat(fd)) != _signature(before):
            raise ValueError('Image output manifest changed while binding')
    finally:
        os.close(fd)
    _fields(manifest, ('schema', 'provider_id', 'provider_version', 'worker_sha256',
                       'source_identities', 'runtime_files', 'adapter_sha256',
                       'outputs', 'validation', 'summary'))
    if manifest['schema'] != 'gxtxt.scientific_job_outputs.v1' or manifest['validation'] != 'validated_structure':
        raise ValueError('Image output is not structurally validated')
    for key in ('provider_id', 'provider_version', 'worker_sha256', 'adapter_sha256',
                'runtime_files', 'source_identities'):
        if manifest[key] != request[key]:
            raise ValueError('Image output manifest differs from immutable Job ' + key)
    if not isinstance(manifest['outputs'], list) or not 1 <= len(manifest['outputs']) <= 3:
        raise ValueError('Invalid original image output set')
    allowed = {'raster': {'miff', 'png16', 'tiff16', 'tiff32f'},
               'display_preview': {'png8'}, 'provenance': {'json'}}
    held = []
    roles = set()
    try:
        for item in manifest['outputs']:
            _fields(item, ('role', 'file', 'format', 'columns', 'live'))
            if (item['role'] not in allowed or item['role'] in roles or
                    item['format'] not in allowed[item['role']] or item['columns'] != [] or item['live'] is not False):
                raise ValueError('Invalid immutable image output declaration')
            roles.add(item['role'])
            leaf = Path(item['file'])
            if (leaf.is_absolute() or len(leaf.parts) != 1 or leaf.name in ('.', '..') or
                    not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', leaf.name)):
                raise ValueError('Invalid original image output leaf')
            token = 'output-' + hashlib.sha256((envelope['job_id'] + ':' + item['role']).encode()).hexdigest()
            if envelope['output_token'] and envelope['output_token'] != token:
                continue
            source = _open_source(str(output / leaf))
            try:
                info = os.fstat(source)
                if info.st_nlink != 1 or info.st_uid != os.getuid():
                    raise ValueError('Unsafe immutable image output')
                generation, change, signature = _observe_output_fd(output, token, item, source)
                if envelope['generation'] and _integer(envelope['generation']) != generation:
                    raise ValueError('Stale image output generation')
                descriptor = dict(role=item['role'], format=item['format'], live=False,
                                  token=token, job_id=envelope['job_id'],
                                  logical_id=envelope['job_id'] + ':' + item['role'],
                                  availability='available', source_generation=generation,
                                  size_bytes=info.st_size, change=change,
                                  content_class='provider_output', source_file=str(output / leaf))
                held.append((source, descriptor, signature))
            except BaseException:
                os.close(source)
                raise
        if envelope['output_token'] and len(held) != 1:
            raise ValueError('Unknown original image output token')
        return held, manifest
    except BaseException:
        for source, _, _ in held:
            os.close(source)
        raise


def _held_original(envelope):
    """Resolve only a source-qualified alias in the actual sealed Job snapshot."""
    output, request = _image_owner_request(envelope, original=True)
    alias = envelope['input_alias']
    if not isinstance(alias, str) or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}', alias):
        raise ValueError('Invalid fixed original image input alias')
    files, records = verify_snapshot(output, tdict(request['image_input_snapshot']),
                                     *native_source_binding(request))
    if alias not in records:
        raise ValueError('Original image alias is not in this immutable Job')
    record = records[alias]
    guard = tdict(record['source_guard'])
    source_kind = guard.get('kind')
    if source_kind == 'canonical_dataset':
        identity = tdict(guard['identity'])
        source_info = tdict(guard['source_info'])
        captured_sources = tdict(tdict(request['image_capture_options'])['image_sources'])
        if alias not in captured_sources:
            raise ValueError('Original alias differs from the immutable capture request')
        declared = tdict(captured_sources[alias])
        if (set(declared) != {'dataset_id', 'source_sha256', 'source_revision'} or
                any(declared[key] != identity[key] for key in declared) or
                source_info['id'] != identity['dataset_id']):
            raise ValueError('Original image source/alias association changed')
    elif source_kind == 'document_resource':
        _fields(guard, ('kind', 'reference', 'document'))
        reference = tdict(guard['reference']); document = tdict(guard['document'])
        declared = tdict(tdict(request['image_resource_sources'])[alias])
        if ({k: v for k, v in declared.items() if k != 'metadata'} != reference or
                tdict(tdict(request['source_identities'])[alias]) != reference or
                tdict(tdict(request['source_identities'])['workspace']) != document or
                reference['document_id'] != document['id'] or not reference.get('owner_generation') or
                reference['owner_generation'] != document['generation'] or
                reference['sha256'] != record['sha256'] or _integer(reference['size_bytes']) != record['size_bytes']):
            raise ValueError('Original Resource alias differs from its actual immutable Document capture')
        identity = dict(source_revision=reference['owner_generation'])
        source_info = dict(format=tdict(declared.get('metadata', '')).get('format', 'binary'))
    else:
        raise ValueError('Original image alias lacks its admitted source association')
    token = 'input-' + hashlib.sha256((envelope['job_id'] + ':' + alias).encode()).hexdigest()
    if envelope['output_token'] and envelope['output_token'] != token:
        raise ValueError('Foreign original image input token')
    source = _open_source(str(files[alias]))
    try:
        before = os.fstat(source)
        if before.st_uid != os.getuid() or before.st_nlink != 1 or before.st_size != record['size_bytes']:
            raise ValueError('Unsafe immutable original image input')
        digest = _hash_exact(source, record['size_bytes'])
        if digest != record['sha256'] or _signature(os.fstat(source)) != _signature(before):
            raise ValueError('Held original image bytes differ from the sealed input')
        os.lseek(source, 0, os.SEEK_SET)
        item = dict(format=source_info['format'], columns=[], live=False)
        generation, change, signature = _observe_output_fd(output, token, item, source)
        if envelope['generation'] and _integer(envelope['generation']) != generation:
            raise ValueError('Original image input generation changed')
        descriptor = dict(role='original_source', format=item['format'], live=False,
                          token=token, job_id=envelope['job_id'], logical_id=envelope['job_id'] + ':' + alias,
                          availability='available', source_generation=generation, size_bytes=before.st_size,
                          change=change, content_class='immutable_original_input', sha256=digest,
                          source_kind=source_kind, source_revision=identity['source_revision'])
        if source_kind == 'canonical_dataset':
            descriptor.update(source_dataset_id=identity['dataset_id'], canonical_source_sha256=identity['source_sha256'])
        return [(source, descriptor, signature)]
    except BaseException:
        os.close(source)
        raise


def describe_original(envelope):
    held = _held_original(envelope)
    try:
        return dict(original_input=held[0][1])
    finally:
        for fd, _, _ in held:
            os.close(fd)


def describe_outputs(envelope):
    held, manifest = _held_outputs(envelope)
    try:
        outputs = []
        for fd, descriptor, signature in held:
            digest = _hash_exact(fd, descriptor['size_bytes'])
            if _signature(os.fstat(fd)) != tuple(signature[:5]):
                raise ValueError('Image output changed while hashing')
            outputs.append(dict(descriptor, sha256=digest))
        return dict(provider_id=manifest['provider_id'], validation=manifest['validation'],
                    summary=manifest['summary'], outputs=outputs)
    finally:
        for fd, _, _ in held:
            os.close(fd)


def stream_output(envelope, *, original=False):
    """One fixed duplex reader, one acknowledged <=1MiB raw page in flight."""
    if not envelope['output_token'] or not envelope['generation']:
        raise ValueError('Image stream requires an observed exact output generation')
    held = _held_original(envelope) if original else _held_outputs(envelope)[0]
    try:
        fd, descriptor, signature = held[0]
        print(tvalue(dict(kind='ready', **descriptor)), flush=True)
        digest = hashlib.sha256()
        offset = 0
        while True:
            command = sys.stdin.readline(16)
            if command == 'abort\n' or not command:
                raise ValueError('Image stream aborted before complete acknowledgement')
            if command != 'next\n':
                raise ValueError('Invalid fixed image stream command')
            if _signature(os.fstat(fd)) != tuple(signature[:5]):
                raise ValueError('Image output changed during held stream')
            chunk = os.read(fd, CHUNK)
            if chunk:
                digest.update(chunk)
                print(tvalue(dict(kind='chunk', offset=offset, count=len(chunk),
                                 bytes_base64=base64.b64encode(chunk).decode())), flush=True)
                offset += len(chunk)
                continue
            if offset != descriptor['size_bytes'] or _signature(os.fstat(fd)) != tuple(signature[:5]):
                raise ValueError('Incomplete or changed image output stream')
            print(tvalue(dict(kind='complete', size_bytes=offset, sha256=digest.hexdigest(),
                             source_generation=descriptor['source_generation'])), flush=True)
            if sys.stdin.readline(16) != 'ack\n':
                raise ValueError('Image stream complete frame was not acknowledged')
            return
    finally:
        for fd, _, _ in held:
            os.close(fd)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ('capture', 'describe', 'stream', 'describe_original', 'stream_original'):
        raise ValueError('Private image materializer requires its fixed action')
    if sys.argv[1] in ('stream', 'stream_original'):
        line = sys.stdin.readline(2 * CHUNK)
        raw = base64.b64decode(line.strip(), validate=True).decode('utf-8')
        stream_output(tdict(raw), original=sys.argv[1] == 'stream_original')
        return
    # The trusted capture envelope contains the whole Native Document's source
    # guards. Parse at most that owner's existing8MiB control bound; ordinary
    # image/describe routes retain their original1MiB envelope contract.
    limit = 8388608 if sys.argv[1] == 'capture' else CHUNK
    wire = sys.stdin.buffer.read(limit + 1)
    if len(wire) > limit:
        raise ValueError('Private image descriptors exceed their finite envelope')
    raw = wire.decode('utf-8')
    envelope = tdict(raw)
    native_capture = (sys.argv[1] == 'capture' and
                      envelope.get('source_profile') == NATIVE_SOURCE_PROFILE and
                      'native_projection_sha256' in envelope)
    if not native_capture and len(wire) > CHUNK:
        raise ValueError('Ordinary image descriptors exceed their original finite envelope')
    actions = {'capture': capture_inputs, 'describe': describe_outputs, 'describe_original': describe_original}
    result = actions[sys.argv[1]](envelope)
    print(tvalue(dict(ok=1, result=result)), flush=True)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        # Frame-safe diagnostics; no key/config/environment dump.
        print(tvalue(dict(ok=0, error_type=type(exc).__name__,
                         error_base64=base64.b64encode(str(exc).encode()).decode())),
              flush=True)
        raise SystemExit(1)
