#!/usr/bin/env python3
"""Bounded host raster compositing of Native2D device primitives.

The caller supplies a private render plan; geometry/calibration/view decisions
already came from Native2D. No plugin code or archive content is executed.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import argparse
import base64
import math
import io
import hashlib
import os
import re
import stat
import sys
from functools import lru_cache
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

Image.MAX_IMAGE_PIXELS = 64_000_000

def axis_label(canvas, row):
    x, y = map(float, row[2].split())
    text = base64.b64decode(row[3]).decode('utf-8')
    if len(row) < 6:
        ImageDraw.Draw(canvas).text((x,y), text, fill=rgba(row[1]))
        return
    size = max(6, min(96, round(float(row[5]))))
    font = None
    for name in ('DejaVuSans.ttf', 'arial.ttf'):
        try:
            font = ImageFont.truetype(name, size)
            break
        except OSError:
            continue
    if font is None:
        font = ImageFont.load_default()
    anchor = {'n': 'mt', 'ne': 'rt', 'nw': 'lt', 'e': 'rm', 'w': 'lm', 's': 'mb', 'center': 'mm'}.get(row[4], 'lt')
    rotation = float(row[6]) if len(row) > 6 else 0.0
    if not math.isfinite(rotation):
        raise ValueError("Axis text rotation must be finite")
    if rotation:
        # Native's rotated axis title is center-anchored. Preserve its exact
        # device center while rendering a bounded local text layer.
        if row[4] != 'center':
            raise ValueError("Rotated axis text requires a center anchor")
        left, top, right, bottom = font.getbbox(text)
        layer = Image.new('RGBA', (max(1, right-left+8), max(1, bottom-top+8)))
        ImageDraw.Draw(layer).text((4-left, 4-top), text, font=font, fill=rgba(row[1]))
        layer = layer.rotate(rotation, expand=True, resample=Image.Resampling.BICUBIC)
        canvas.alpha_composite(layer, (round(x-layer.width/2), round(y-layer.height/2)))
    else:
        ImageDraw.Draw(canvas).text((x,y), text, font=font, anchor=anchor, fill=rgba(row[1]))


def rgba(text):
    values = [float(value) for value in text.split()]
    return tuple(round(max(0, min(1, value)) * 255) for value in values)


@lru_cache(maxsize=2)
def reference_pixels(path):
    # Managed resources are immutable; the small worker cache avoids reopening
    # and decoding the same calibrated image for every camera frame.
    with Image.open(path) as image:
        if image.width * image.height > 64_000_000:
            raise ValueError("reference raster exceeds limit")
        return image.convert("RGBA")


def display_png(source_path, output_path, width, height, expected_sha, allocation_id):
    """One bounded RGBA8 display file; original scientific samples stay untouched."""
    if (type(width) is not int or type(height) is not int
            or not 1 <= width <= 16384 or not 1 <= height <= 16384
            or width * height > 16777216
            or not isinstance(expected_sha, str)
            or re.fullmatch(r'[0-9a-f]{64}', expected_sha) is None
            or not isinstance(allocation_id, str)
            or re.fullmatch(r'resource-[0-9a-f]{32}', allocation_id) is None):
        raise ValueError('Invalid bounded display image request')
    target = Path(os.path.abspath(output_path))
    if (target.name != 'display.png' or target.parent.name != allocation_id
            or any(parent.is_symlink() for parent in target.parents)):
        raise ValueError('Display output must stay in its allocated envelope')
    directory = os.open(target.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        owner = os.fstat(directory)
        if (not stat.S_ISDIR(owner.st_mode) or owner.st_uid != os.getuid()
                or stat.S_IMODE(owner.st_mode) != 0o700 or os.listdir(directory)):
            raise ValueError('Display envelope must be an empty private directory')
        source_fd = os.open(source_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(source_fd, 'rb') as source:
            before = os.fstat(source.fileno())
            if not stat.S_ISREG(before.st_mode) or not 1 <= before.st_size <= 67108864:
                raise ValueError('Original display source exceeds its regular-file bound')
            def digest():
                source.seek(0)
                result = hashlib.sha256()
                while True:
                    block = source.read(1048576)
                    if not block:
                        return result.hexdigest()
                    result.update(block)
            if digest() != expected_sha:
                raise ValueError('Original display source SHA differs')
            source.seek(0)
            header = Image.open(source)
            try:
                if header.getexif().get(274, 1) != 1:
                    raise ValueError('Nonidentity stored image orientation is not admitted for display conversion')
                if header.size != (width, height):
                    raise ValueError('Original display dimensions differ from Native2D')
                source.seek(0)
                pixels = reference_pixels(source)
                if pixels.mode != 'RGBA' or pixels.size != (width, height):
                    raise ValueError('Decoded display dimensions differ from Native2D')
                after = os.fstat(source.fileno())
                version = lambda value: (value.st_dev, value.st_ino, value.st_size,
                                         value.st_mtime_ns, value.st_ctime_ns)
                if version(before) != version(after) or digest() != expected_sha:
                    raise ValueError('Original display source changed during decoding')
            finally:
                header.close()
        maximum = 5 * width * height + 65536
        output_fd = os.open('display.png', os.O_WRONLY | os.O_CREAT | os.O_EXCL
                            | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        with os.fdopen(output_fd, 'wb') as output:
            class BoundedOutput:
                def __init__(self):
                    self.size = 0
                def write(self, data):
                    if self.size + len(data) > maximum:
                        raise ValueError('Display PNG exceeds its allocated output bound')
                    written = output.write(data)
                    self.size += written
                    return written
                def flush(self):
                    output.flush()
            bounded = BoundedOutput()
            # Existing Pillow RGBA conversion is display-only. Strip container
            # metadata rather than introducing profile/orientation transforms.
            pixels.save(bounded, 'PNG', optimize=False, compress_level=6,
                        icc_profile=None, exif=b'')
            output.flush()
            info = os.fstat(output.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > maximum:
                raise ValueError('Display output file exceeds its allocation contract')
        return dict(width=width, height=height, source_sha256=expected_sha,
                    output_bytes=info.st_size, representation='display_RGBA8')
    finally:
        os.close(directory)


def composite_image(canvas, path, opacity, frame):
    source = reference_pixels(path)
    x0, y0, ax, ay, bx, by = frame
    det = ax * by - ay * bx
    if not math.isfinite(det) or abs(det) < 1e-20:
        raise ValueError("singular reference raster device transform")
    # Inverse device mapping only: uniform world calibration belongs to C.
    coefficients = (by / det, -bx / det, (-by*x0 + bx*y0)/det,
                    -ay / det, ax / det, (ay*x0 - ax*y0)/det)
    warped = source.transform(canvas.size, Image.Transform.AFFINE, coefficients,
                              resample=Image.Resampling.BILINEAR)
    if opacity != 1:
        alpha = warped.getchannel("A").point(lambda value: round(value * opacity))
        warped.putalpha(alpha)
    canvas.alpha_composite(warped)

def render_text(plan, output):
    rows = [line.split("\t") for line in plan.splitlines()]
    width, height = map(int, rows[0][1:3])
    if width < 16 or height < 16 or width > 4096 or height > 4096:
        raise ValueError("preview dimensions must be 16..4096")
    canvas = Image.new("RGBA", (width, height), rgba(rows[0][3]))
    clip = tuple(map(float, rows[0][4].split()))
    layer = Image.new("RGBA", canvas.size)
    for row in rows[1:]:
        if row[0] == "image":
            path = base64.b64decode(row[1], validate=True).decode("utf-8")
            composite_image(layer, path, float(row[2]), list(map(float, row[3].split())))
        elif row[0] == "line":
            xy = list(map(float, row[3].split()))
            if len(xy) % 2 or len(xy) > 131072:
                raise ValueError("invalid bounded primitive")
            primitive = Image.new("RGBA", canvas.size)
            draw = ImageDraw.Draw(primitive)
            if len(xy) >= 4:
                points = list(zip(xy[::2], xy[1::2]))
                stroke = max(1, round(float(row[2])))
                style = int(row[4]) if len(row) > 4 else 0
                if style == 0:
                    draw.line(points, fill=rgba(row[1]), width=stroke, joint="curve")
                else:
                    # Carry dash phase across the sampled Native path, rather
                    # than restarting at each segment and changing its style.
                    dash, gap = (6., 3.) if style == 1 else (1., 3.)
                    phase = 0.
                    for start, end in zip(points, points[1:]):
                        dx, dy = end[0]-start[0], end[1]-start[1]
                        length = math.hypot(dx, dy); position = 0.
                        while position < length:
                            on = phase < dash
                            step = min(length-position, (dash if on else dash+gap)-phase)
                            if on and step > 0:
                                a = (start[0]+dx*position/length, start[1]+dy*position/length)
                                b = (start[0]+dx*(position+step)/length, start[1]+dy*(position+step)/length)
                                draw.line((a,b), fill=rgba(row[1]), width=stroke)
                            position += step; phase = (phase+step) % (dash+gap)
                layer.alpha_composite(primitive)
        elif row[0] == "point":
            x, y = map(float, row[3].split());radius = float(row[2])
            primitive = Image.new("RGBA", canvas.size)
            ImageDraw.Draw(primitive).ellipse((x-radius,y-radius,x+radius,y+radius), fill=rgba(row[1]))
            layer.alpha_composite(primitive)
        elif row[0] == "label":
            continue
        elif row[0] == "text":
            x, y = map(float, row[2].split())
            text = base64.b64decode(row[3], validate=True).decode("utf-8")
            primitive = Image.new("RGBA", canvas.size)
            ImageDraw.Draw(primitive).text((x,y), text, fill=rgba(row[1]))
            layer.alpha_composite(primitive)
        else:
            raise ValueError("unknown render primitive")
    mask = Image.new("L", canvas.size);ImageDraw.Draw(mask).rectangle(clip, fill=255)
    alpha = layer.getchannel("A")
    from PIL import ImageChops
    layer.putalpha(ImageChops.multiply(alpha, mask))
    canvas.alpha_composite(layer)
    for row in rows[1:]:
        if row[0] == "label":
            axis_label(canvas, row)
    canvas.save(output, "PNG", optimize=False, compress_level=6)


def render(plan, output):
    render_text(Path(plan).read_text(encoding="utf-8"), output)


def worker():
    # A single host-owned process, with one in-flight request. Geometry and
    # calibration remain Native decisions encoded in the shared render plan.
    for line in sys.stdin:
        try:
            plan = base64.b64decode(line.strip(), validate=True).decode("utf-8")
            result = io.BytesIO()
            render_text(plan, result)
            reply = base64.b64encode(result.getvalue()).decode("ascii")
        except Exception as error:
            reply = "ERROR " + base64.b64encode(str(error).encode()).decode("ascii")
        print(reply, flush=True)


def render_pdf(plan, output):
    """Vector PDF from the same Native presentation plan used by previews."""
    from reportlab.pdfgen import canvas as pdfcanvas
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    rows = [line.split("\t") for line in Path(plan).read_text(encoding="utf-8").splitlines()]
    width, height = map(int, rows[0][1:3])
    if not (16 <= width <= 4096 and 16 <= height <= 4096):
        raise ValueError("PDF dimensions must be 16..4096")
    c = pdfcanvas.Canvas(output, pagesize=(width, height), pageCompression=1)
    c.setTitle("GX-TXT Curve Workbench graphics")
    bg = list(map(float, rows[0][3].split()))
    c.setFillColorRGB(*bg[:3]); c.rect(0, 0, width, height, stroke=0, fill=1)
    x0, y0, x1, y1 = map(float, rows[0][4].split())
    c.saveState()
    p = c.beginPath(); p.rect(x0, height-y1, x1-x0, y1-y0); c.clipPath(p, stroke=0)
    font = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
    if font.exists():
        pdfmetrics.registerFont(TTFont("GXText", str(font))); c.setFont("GXText", 10)
    else:
        c.setFont("Helvetica", 10)
    for row in rows[1:]:
        if row[0] == "label": continue
        if row[0] == "image":
            layer = Image.new("RGBA", (width, height))
            composite_image(layer, base64.b64decode(row[1]).decode(), float(row[2]), list(map(float, row[3].split())))
            c.drawImage(ImageReader(layer), 0, 0, width, height, mask="auto")
        else:
            color = list(map(float, row[1].split()))
            # Native styles may target a dark interactive canvas. Preserve hue
            # but cap luminance on paper so white/light geometry remains legible.
            luminance = .2126*color[0]+.7152*color[1]+.0722*color[2]
            if sum(bg[:3])/3 > .8 and luminance > .65:
                color[:3] = [v*.45/luminance for v in color[:3]]
            c.setStrokeColorRGB(*color[:3]); c.setFillColorRGB(*color[:3])
            c.setStrokeAlpha(color[3]); c.setFillAlpha(color[3])
            if row[0] == "line":
                xy = list(map(float, row[3].split()))
                if len(xy) < 4: continue
                p = c.beginPath(); p.moveTo(xy[0], height-xy[1])
                for x,y in zip(xy[2::2], xy[3::2]): p.lineTo(x, height-y)
                c.setLineWidth(float(row[2]))
                style = int(row[4]) if len(row)>4 else 0
                c.setDash([] if style==0 else ([6,3] if style==1 else [1,3]))
                c.drawPath(p)
            elif row[0] == "point":
                x,y = map(float,row[3].split()); c.circle(x,height-y,float(row[2]),stroke=0,fill=1)
            elif row[0] == "text":
                x,y = map(float,row[2].split()); c.drawString(x,height-y-10,base64.b64decode(row[3]).decode("utf-8"))
            else: raise ValueError("unknown PDF primitive")
    c.restoreState();c.setFont("GXText" if font.exists() else "Helvetica",10)
    for row in rows[1:]:
        if row[0] == "label":
            x,y=map(float,row[2].split());color=list(map(float,row[1].split()))
            text=base64.b64decode(row[3]).decode("utf-8")
            size=max(6,min(96,float(row[5]))) if len(row)>5 else 10
            face="GXText" if font.exists() else "Helvetica"
            anchor=row[4] if len(row)>4 else 'nw'
            rotation=float(row[6]) if len(row)>6 else 0
            if not math.isfinite(rotation): raise ValueError("Axis text rotation must be finite")
            width_text=pdfmetrics.stringWidth(text,face,size)
            ascent,descent=pdfmetrics.getAscentDescent(face,size)
            dx=-width_text if anchor in ('e','ne') else (-width_text/2 if anchor in ('n','s','center') else 0)
            dy=-ascent if anchor in ('n','ne','nw') else (-descent if anchor=='s' else -(ascent+descent)/2)
            c.saveState();c.setFillColorRGB(*color[:3]);c.setFillAlpha(color[3])
            c.translate(x,height-y);c.rotate(rotation);c.setFont(face,size)
            c.drawString(dx,dy,text);c.restoreState()
    c.showPage(); c.save()


def main():
    if sys.argv[1:] == ["worker"]:
        worker()
        return
    parser = argparse.ArgumentParser();parser.add_argument("operation", choices=("render", "pdf", "info", "display_png"))
    parser.add_argument("input");parser.add_argument("output", nargs="?")
    parser.add_argument('--width', type=int);parser.add_argument('--height', type=int)
    parser.add_argument('--sha256');parser.add_argument('--allocation-id');args = parser.parse_args()
    if args.operation == 'display_png':
        from gxtxt_job_supervisor import request_process_group, tcl_result
        request_process_group()
        try:
            result = display_png(args.input, args.output, args.width, args.height,
                                 args.sha256, args.allocation_id)
            print(tcl_result(dict(ok=1, result=result)), flush=True)
        except Exception as error:
            print(tcl_result(dict(ok=0, error=str(error))), flush=True)
            raise SystemExit(1)
        return
    if args.operation == "info":
        with Image.open(args.input) as image:
            if image.width*image.height > 64_000_000 or max(image.size) > 32768:
                raise ValueError("reference raster exceeds limit")
            print(f"{image.width} {image.height}")
    elif args.operation == "pdf":
        render_pdf(args.input, args.output)
    else:
        render(args.input, args.output)


if __name__ == "__main__":
    main()
