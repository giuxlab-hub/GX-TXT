# SPDX-License-Identifier: GPL-3.0-or-later
"""Internal control-value transport owned by the existing Viewer/Job owners.

Application values never select this transport. Only captured CORE operation
metadata refers to a sealed Resource allocation or an admitted Job output.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys
import time
sys.path.insert(0,str(Path(__file__).resolve().parent))

SCHEMA='gxtxt.viewer_bridge_control.v1'
CHUNK=16384
__all__=()  # Internal CORE transport, not a second public API/provider surface.

def canonical(value):
    return json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode('utf-8')

def _has_cells(value,depth=0):
    from gxtxt_cell_v1 import CellArray
    if depth>64:raise ValueError('Control value exceeds existing native nesting')
    if isinstance(value,CellArray):value.validated_shape();return True
    if isinstance(value,dict):return any(_has_cells(v,depth+1)for v in value.values())
    if isinstance(value,(list,tuple)):return any(_has_cells(v,depth+1)for v in value)
    return False

def _encode_control(value):
    if not isinstance(value,dict):raise ValueError('Internal control requires its fixed CORE envelope')
    if set(value)=={'action','request'}:
        from viewer_bridge_request_v1 import validate_request
        validate_request(value['action'],value['request'],lambda message,code:ValueError(message))
    elif set(value)=={'schema','module_id','run_id','action','request','result'} and value['schema']=='gxtxt.viewer_bridge_result.v1':
        if value['action'] not in {'list','describe','require','call'}:raise ValueError('Unknown retained generic action')
    else:raise ValueError('Unknown fixed CORE control envelope')
    if _has_cells(value):
        import gxtxt
        # Four trusted receipt/request envelope levels are transport metadata;
        # actual API argument/result depth remains enforced by the SAME public
        # Bridge at invocation. Do not impose another smaller frontend limit.
        return canonical(gxtxt._pack(value,[],depth=-4)),'script_bridge'
    return canonical(value),None

def _decode_control(raw,encoding):
    value=json.loads(raw)
    if encoding is None:return value
    if encoding!='script_bridge':raise ValueError('Unknown original control encoding')
    from gxtxt_script_bridge_server import decode_value
    return decode_value(value)

def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()).hexdigest()

def _parent(path):
    from gxtxt_resource_manager import _safe_directory
    path=Path(path)
    if not path.is_absolute() or '..' in path.parts:
        raise ValueError('Control transport requires an absolute owned path')
    return path,_safe_directory(path.parent)

def ordinary(path):
    path,parent=_parent(path)
    try:
        info=os.stat(path.name,dir_fd=parent,follow_symlinks=False)
        if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_nlink!=1:
            raise ValueError('Control transport requires an ordinary single-link owned file')
        fd=os.open(path.name,os.O_RDONLY|os.O_NOFOLLOW,dir_fd=parent)
        if os.fstat(fd)[:3]!=info[:3]:os.close(fd);raise ValueError('Control file changed during open')
        return os.fdopen(fd,'rb')
    finally:os.close(parent)

def _exclusive(path):
    path,parent=_parent(path)
    try:return os.open(path.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=parent)
    finally:os.close(parent)

def create_output(session,output):
    # Only the original ScriptExecution owner passes its freshly minted run ID.
    # mkdirat refuses an existing file, directory or dangling symlink atomically.
    session=Path(session);output=Path(output)
    if not session.is_absolute()or '..'in session.parts or output.parent!=session/'analysis/scripts'or re.fullmatch(r'script-[A-Za-z0-9-]+',output.name)is None:raise ValueError('Unknown fresh Viewer Job output location')
    parent=os.open('/',os.O_RDONLY|os.O_DIRECTORY)
    try:
        for part in output.parts[1:-1]:
            child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
            os.close(parent);parent=child
        if os.fstat(parent).st_uid!=os.getuid():raise ValueError('Viewer Job output parent ownership changed')
        os.mkdir(output.name,0o700,dir_fd=parent)
        child=os.open(output.name,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=parent)
        try:
            info=os.fstat(child)
            if info.st_uid!=os.getuid()or stat.S_IMODE(info.st_mode)!=0o700:raise ValueError('Fresh Viewer Job output is not private')
        finally:os.close(child)
    finally:os.close(parent)

def read_json(path,expected=None):
    with ordinary(path) as stream:
        raw=stream.read()
    if expected and hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('Control file SHA changed')
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value:raise ValueError('Duplicate control field')
            value[key]=item
        return value
    return json.loads(raw,object_pairs_hook=unique)

def write_new(path,raw):
    fd=_exclusive(path)
    with os.fdopen(fd,'wb') as stream:
        stream.write(raw);stream.flush();os.fsync(stream.fileno())

def validate_scope(scope):
    from gxtxt_resource_manager import process_identity
    required={'module','session','lifetime','client_pid','client_identity','session_directory','session_origin','resource_root','resource_storage','session_device','session_inode'}
    if not isinstance(scope,dict) or set(scope)!=required:raise ValueError('Generic control scope is incomplete')
    if type(scope['client_pid'])is not int or process_identity(scope['client_pid'])!=scope['client_identity'] or scope['client_identity'] in {'dead','unknown'}:
        raise ValueError('Generic control GUI identity is no longer current')
    if not all(isinstance(scope[k],str) and scope[k] and '\0' not in scope[k] for k in required-{'client_pid','session_device','session_inode'}):
        raise ValueError('Generic control scope requires inert identities')
    for key in ('resource_root','resource_storage'):
        root=Path(scope[key])
        if not root.is_absolute() or '..' in root.parts or root.resolve()!=root:raise ValueError('Generic control resource authority path changed')
    if type(scope['session_device'])is not int or type(scope['session_inode'])is not int:raise ValueError('Generic control Session identity requires exact integers')
    session=Path(scope['session'])
    if not session.is_absolute() or '..' in session.parts or session.resolve()!=session:
        raise ValueError('Generic control Session path changed')
    info=session.stat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.getuid() or info.st_dev!=scope['session_device'] or info.st_ino!=scope['session_inode']:raise ValueError('Generic control Session owner/identity changed')
    return scope

class ControlStore:
    """Delegated GUI-owner allocations, exact reservation before any writes."""
    def __init__(self,scope):
        from gxtxt_resource_manager import ResourceManager
        self.scope=validate_scope(scope)
        self.manager=ResourceManager(root=scope['resource_root'],storage_root=scope['resource_storage'],caller_pid=scope['client_pid'])
        self.uploads={}
    def begin(self,total,purpose='generic'):
        validate_scope(self.scope)
        if purpose not in {'generic','input_text'}:raise ValueError('Unknown captured control purpose')
        if type(total)is not int or total<1:raise ValueError('Control reservation requires exact positive byte count')
        record=self.manager.allocate('viewer_bridge_control',kind='file',suffix='.json',owner_pid=self.scope['client_pid'],session=self.scope['session'],lifetime='viewer_invocation',expected_bytes=total+65536,descendant_lease=True)
        token=record['id']
        self.uploads[token]=dict(record=record,total=total,written=0,hash=hashlib.sha256(),sealed=False,purpose=purpose)
        return token
    def append(self,token,offset,encoded):
        row=self.uploads[token]
        if row['sealed'] or type(offset)is not int or offset!=row['written']:raise ValueError('Control append sequence changed')
        data=base64.b64decode(encoded,validate=True)
        if not data or len(data)>CHUNK or row['written']+len(data)>row['total']:raise ValueError('Control append exceeds its reservation')
        path,parent=_parent(row['record']['path'])
        try:fd=os.open(path.name,os.O_WRONLY|os.O_APPEND|os.O_NOFOLLOW,dir_fd=parent)
        finally:os.close(parent)
        with os.fdopen(fd,'ab') as stream:
            info=os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid() or info.st_nlink!=1 or info.st_size!=offset:raise ValueError('Control spool owner/type/size changed before append')
            stream.write(data)
        row['hash'].update(data);row['written']+=len(data)
    def seal(self,token):
        validate_scope(self.scope)
        row=self.uploads[token]
        if row['sealed'] or row['written']!=row['total']:raise ValueError('Incomplete control reservation cannot seal')
        descriptor=dict(schema=SCHEMA,resource_id=token,byte_count=row['total'],sha256=row['hash'].hexdigest(),scope_sha256=digest(self.scope))
        metadata=dict(descriptor=descriptor,scope=self.scope)
        if row['purpose']!='generic':metadata['purpose']=row['purpose']
        raw=canonical(metadata)
        if len(raw)>65536:raise ValueError('Control scope metadata exceeds its reserved bytes')
        write_new(Path(row['record']['envelope'])/'seal.json',raw)
        row['sealed']=True
        return descriptor
    def abort(self,token):
        row=self.uploads[token]
        if row['sealed']:raise ValueError('Sealed asynchronous input requires capture acknowledgment')
        self.manager.release(token,state='verified_orphan')
        self.manager.cleanup([token]);self.uploads.pop(token)
    def close(self):
        # The compiled lifetime is ending. Existing descendant-lease checks
        # refuse release while an actual fixed preparer can still read; any
        # uncertainty remains protected. Accepted Jobs already own immutable
        # snapshots, and do not borrow these temporary uploads. A pending call
        # with no active capture may refuse after its frontend lifetime ended.
        for token in tuple(self.uploads):
            try:
                if not self.manager.inspect(token).get('removed'):
                    self.manager.release(token,state='verified_orphan')
                    self.manager.cleanup([token])
            except Exception:pass
        self.manager.close()

def resource_path(descriptor,scope,purpose='generic'):
    from gxtxt_resource_manager import ResourceManager
    validate_scope(scope)
    keys={'schema','resource_id','byte_count','sha256','scope_sha256'}
    if not isinstance(descriptor,dict) or set(descriptor)!=keys or descriptor['schema']!=SCHEMA or descriptor['scope_sha256']!=digest(scope):
        raise ValueError('Captured control descriptor/scope differs')
    if not re.fullmatch(r'resource-[0-9a-f]{32}',descriptor['resource_id']) or type(descriptor['byte_count'])is not int or descriptor['byte_count']<1 or not re.fullmatch('[0-9a-f]{64}',descriptor['sha256']):
        raise ValueError('Invalid sealed control identity')
    manager=ResourceManager(root=scope['resource_root'],storage_root=scope['resource_storage'])
    try:
        record=manager.inspect(descriptor['resource_id'])
        for key,expected in {'subsystem':'viewer_bridge_control','session':scope['session'],'owner_pid':scope['client_pid'],'owner_identity':scope['client_identity'],'released':False,'removed':False}.items():
            if record.get(key)!=expected:raise ValueError('Control allocation '+key+' differs')
        metadata=read_json(Path(record['envelope'])/'seal.json')
        expected={'descriptor':descriptor,'scope':scope}
        if purpose!='generic':
            if purpose!='input_text':raise ValueError('Unknown captured control purpose')
            expected['purpose']=purpose
        if metadata!=expected:raise ValueError('Control seal differs from captured request/purpose')
        with ordinary(record['path']) as stream:
            if os.fstat(stream.fileno()).st_size!=descriptor['byte_count'] or hashlib.file_digest(stream,'sha256').hexdigest()!=descriptor['sha256']:
                raise ValueError('Sealed control bytes changed')
        return Path(record['path'])
    finally:manager.close()

def resource_packet(descriptor,scope,purpose='generic'):
    path=resource_path(descriptor,scope,purpose=purpose)
    with ordinary(path) as stream:raw=stream.read()
    if len(raw)!=descriptor['byte_count'] or hashlib.sha256(raw).hexdigest()!=descriptor['sha256']:raise ValueError('Consumed control bytes changed')
    return decode_packet(raw.decode('utf-8'))

def input_text_packet(packet):
    if not isinstance(packet,dict) or set(packet)!={'operation','request'} or packet['operation']!='input_text_set':raise ValueError('Unknown fixed input control envelope')
    request=packet['request']
    if not isinstance(request,dict) or set(request)!={'component','value'} or type(request['component'])is not int or not 1<=request['component']<=512 or not isinstance(request['value'],str):raise ValueError('Typed input requires an exact component and string')
    request['value'].encode('utf-8',errors='strict')
    return request['component'],request['value']

def input_text_read(descriptor,scope,component):
    index,value=input_text_packet(resource_packet(descriptor,scope,purpose='input_text'))
    if type(component)is not int or component!=index:raise ValueError('Captured input component differs')
    return base64.b64encode(value.encode('utf-8')).decode('ascii')

def input_text_release(descriptor,scope):
    from gxtxt_resource_manager import ResourceManager
    # Retry only the original uncommitted protected-lease refusal. This
    # admission deadline bounds extra waits/attempts, not lower-level SQLite,
    # filesystem or process-scan work; their original limits remain unchanged.
    retry_deadline=time.monotonic()+1.0
    resource_path(descriptor,scope,purpose='input_text')
    manager=ResourceManager(root=scope['resource_root'],storage_root=scope['resource_storage'],caller_pid=scope['client_pid'])
    try:
        refusal=None
        for attempt in range(3):
            if attempt:
                delay=(0.1,0.25)[attempt-1]
                if time.monotonic()+delay>=retry_deadline:raise refusal
                time.sleep(delay)
                if time.monotonic()>=retry_deadline:raise refusal
                resource_path(descriptor,scope,purpose='input_text')
                if time.monotonic()>=retry_deadline:raise refusal
            try:
                manager.release(descriptor['resource_id'],state='verified_orphan')
            except ValueError as error:
                if type(error) is not ValueError or str(error)!='Live or unverifiable child still holds this resource lease':raise
                if attempt==2:raise
                refusal=error
                continue
            break
        result=manager.cleanup([descriptor['resource_id']])
        if not manager.inspect(descriptor['resource_id']).get('removed'):raise ValueError('Input Resource still has a live reader; allocation remains protected')
        return True
    finally:manager.close()

def decode_packet(raw):
    # The existing finite client parser keeps its strict defaults. This entry
    # only removes unrelated finite-form limits for a captured generic value.
    from viewer_canvas_request_v1 import decode_client_request
    def error(message,code):return ValueError(message)
    return decode_client_request(raw,error,maximum_bytes=None,maximum_nodes=None)

def snapshot_request(descriptor,scope,output,action):
    source=resource_path(descriptor,scope)
    packet=resource_packet(descriptor,scope)
    if packet['operation']!=action:raise ValueError('Control action differs from captured operation')
    raw,encoding=_encode_control(dict(action=action,request=packet['request']))
    output=Path(output)
    write_new(output/'viewer_bridge_request.json',raw)
    receipt=dict(schema='gxtxt.viewer_bridge_control_snapshot.v1',sha256=hashlib.sha256(raw).hexdigest(),byte_count=len(raw),source=descriptor)
    if encoding is not None:receipt['encoding']=encoding
    write_new(output/'viewer_bridge_request_manifest.json',canonical(receipt))
    return receipt

def frozen_request(output,expected_manifest=None):
    output=Path(output)
    manifest=read_json(output/'viewer_bridge_request_manifest.json',expected_manifest)
    with ordinary(output/'viewer_bridge_request.json') as stream:raw=stream.read()
    if len(raw)!=manifest['byte_count'] or hashlib.sha256(raw).hexdigest()!=manifest['sha256']:raise ValueError('Frozen control request changed')
    return _decode_control(raw,manifest.get('encoding'))

def load_request(output,parameter):
    if parameter.startswith('__GXTXT_FROZEN_CONTROL__:'):
        request=frozen_request(output,parameter.split(':',1)[1])
    else:
        envelope=json.loads(parameter)
        if not isinstance(envelope,dict)or set(envelope)!={'viewer_request_base64'}:raise ValueError('Unknown armored generic request')
        request=json.loads(base64.b64decode(envelope['viewer_request_base64'],validate=True))
        if isinstance(request,dict)and request.get('kind')=='struct':
            from gxtxt_script_bridge_server import decode_value
            request=decode_value(request)
    if not isinstance(request,dict)or set(request)-{'original_request_json_base64'}!={'action','request'}:raise ValueError('Unknown fixed generic request fields')
    from viewer_bridge_request_v1 import validate_request
    validate_request(request['action'],request['request'],lambda message,code:ValueError(message))
    return request

def retain_value(item,output):
    # Original generic Python retention projection, shared by both runtimes.
    # Numerical storage remains exclusively the original scientific owner.
    import math
    try:
        import numpy as np
    except ImportError:
        np=None
    if np is not None and isinstance(item,np.ndarray):
        from gxtxt_scientific_binary_v1 import write_buffer
        directory=Path(output)/'viewer_bridge_arrays'
        from gxtxt_resource_manager import _safe_directory
        fd=_safe_directory(directory,True);os.close(fd)
        descriptor=write_buffer(directory,item)
        with ordinary(directory/descriptor['resource_id'])as stream:checksum=hashlib.file_digest(stream,'sha256').hexdigest()
        return dict(schema='gxtxt.viewer_bridge_buffer.v1',descriptor=descriptor,sha256=checksum)
    if np is not None and isinstance(item,np.generic):return retain_value(item.item(),output)
    if isinstance(item,float)and not math.isfinite(item):return dict(schema='gxtxt.nonfinite_scalar.v1',value='NaN'if math.isnan(item)else'Inf'if item>0 else'-Inf')
    if isinstance(item,complex):
        if np is None:raise ValueError('Complex scientific transport requires the same NumPy support as the Bridge')
        return retain_value(np.asarray(item).reshape(1,1),output)
    if isinstance(item,int)and not -(2**63)<=item<2**63:return dict(schema='gxtxt.exact_integer_scalar.v1',decimal=str(item))
    from gxtxt_cell_v1 import CellArray
    if isinstance(item,CellArray):return CellArray([retain_value(v,output)for v in item],item.validated_shape())
    if isinstance(item,dict):return {str(k):retain_value(v,output)for k,v in item.items()}
    if isinstance(item,(tuple,list)):return [retain_value(v,output)for v in item]
    if item is None or isinstance(item,(bool,int,float,str)):return item
    raise ValueError('Unsupported public Bridge return value')

def octave_packets(output,scope,parameter):
    from viewer_bridge_request_v1 import _owned_directory
    import gxtxt
    output=_owned_directory(output);scope=_owned_directory(scope)
    request=load_request(output,parameter);action=request['action'];args=request['request']
    packets=[]
    if action=='call':
        from viewer_bridge_buffers_v1 import discover_references,resolve_inputs,load_manifest
        values=args['args']
        if discover_references(values):
            import configparser
            config=configparser.ConfigParser(interpolation=None);config.read(output/'runtime.ini')
            values=resolve_inputs(values,load_manifest(output,config.get('viewer_bridge_inputs','manifest_sha256')),output)
        requirements={key:args[key]for key in ('api_id','api_version','provider_id')if key in args}
        packets.append(dict(action='require',requirements=[gxtxt._pack(requirements,[])]))
        gxtxt._buffer_root=scope
        # Same public per-argument encoder/depth0/MAX32 as ordinary clients.
        wire=[gxtxt._pack(value,[])for value in values]
        packets.append(dict(action='call',api_id=args['api_id'],operation=args['operation'],args=wire))
    elif action=='list':packets.append(dict(action='list'))
    elif action=='describe':packets.append(dict(action='describe',api_id=args['api_id']))
    elif action=='require':packets.append(dict(action='require',requirements=[gxtxt._pack(item,[])for item in gxtxt._normalize_requirements(args['requirements'])]))
    else:raise ValueError('Unknown framework generic action')
    return dict(schema='gxtxt.viewer_bridge_packets.v1',action=action,parameter_sha256=hashlib.sha256(parameter.encode()).hexdigest(),packets=[dict(viewer_request_base64=base64.b64encode(canonical(packet)).decode('ascii'))for packet in packets])

def retain_result(output,receipt):
    output=Path(output);raw,encoding=_encode_control(receipt)
    if encoding is None and len(raw)<=1048576:return raw
    write_new(output/'viewer_bridge_control_result.json',raw)
    manifest=dict(schema='gxtxt.viewer_bridge_control_result.v1',file='viewer_bridge_control_result.json',sha256=hashlib.sha256(raw).hexdigest(),byte_count=len(raw))
    if encoding is not None:manifest['encoding']=encoding
    return canonical(manifest)

def result_value(output,value):
    if isinstance(value,dict) and value.get('schema')=='gxtxt.viewer_bridge_control_result.v1':
        if set(value)-{'encoding'}!={'schema','file','sha256','byte_count'} or value['file']!='viewer_bridge_control_result.json':raise ValueError('Invalid retained control result')
        path=Path(output)/value['file']
        with ordinary(path) as stream:
            if os.fstat(stream.fileno()).st_size!=value['byte_count']:raise ValueError('Retained control length changed')
        with ordinary(path) as stream:raw=stream.read()
        if hashlib.sha256(raw).hexdigest()!=value['sha256']:raise ValueError('Retained control bytes changed')
        return _decode_control(raw,value.get('encoding'))
    return value

def node_records(value,parent=0,key='',counter=None,depth=0):
    if counter is None:counter=[0]
    if depth>64:raise ValueError('Control result exceeds shared typed nesting')
    index=counter[0];counter[0]+=1
    if value is None:kind,scalar,children=0,b'',0
    elif isinstance(value,str):kind,scalar,children=1,value.encode('utf-8'),0
    elif type(value)is bool:kind,scalar,children=2,b'1' if value else b'0',0
    elif type(value)is int:
        if not -(2**63)<=value<2**63:raise ValueError('Unretained control integer exceeds int64')
        kind,scalar,children=3,str(value).encode(),0
    elif type(value)is float:
        import math
        if not math.isfinite(value):raise ValueError('Unretained control real must be finite')
        kind,scalar,children=4,repr(value).encode(),0
    elif isinstance(value,dict):kind,scalar,children=5,b'',len(value)
    elif isinstance(value,list):
        from gxtxt_cell_v1 import CellArray
        shape=value.validated_shape()if isinstance(value,CellArray)else ()
        kind,scalar,children=6,(struct.pack('<'+'I'*len(shape),*shape)if shape else b''),len(value)
    else:raise ValueError('Unsupported retained control value')
    name=key.encode('utf-8')
    yield struct.pack('<IIIII',parent,kind,children,len(name),len(scalar))+name+scalar
    if kind==5:
        for name,item in value.items():yield from node_records(item,index,name,counter,depth+1)
    elif kind==6:
        for item in value:yield from node_records(item,index,'',counter,depth+1)

def retain_context(output,typed_receipt,scope,request_id):
    value=json.loads(typed_receipt)if isinstance(typed_receipt,str)else typed_receipt
    validate_scope(scope)
    output=Path(output)
    session=Path(scope['session'])
    if output.parent!=session/'analysis/scripts' or output.resolve()!=output:raise ValueError('Context result is not the captured Session Job output')
    name='viewer_bridge_receipt_'+hashlib.sha256(request_id.encode()).hexdigest()+'.nodes'
    count=sum(1 for _ in node_records(value))
    path=output/name
    header=b'GXBCN2\0\0'+struct.pack('<I',count)
    fd=_exclusive(path)
    h=hashlib.sha256();total=0
    with os.fdopen(fd,'wb') as stream:
        for raw in (header,):stream.write(raw);h.update(raw);total+=len(raw)
        for raw in node_records(value):stream.write(raw);h.update(raw);total+=len(raw)
        stream.flush();os.fsync(stream.fileno())
    return dict(schema='gxtxt.viewer_bridge_context.v2',output_dir=str(output),file=name,byte_count=total,sha256=h.hexdigest(),scope_sha256=digest(scope),job_id=output.name)

def context_stream(descriptor,scope):
    validate_scope(scope)
    if not isinstance(descriptor,dict) or set(descriptor)!={'schema','output_dir','file','byte_count','sha256','scope_sha256','job_id'} or descriptor['schema']!='gxtxt.viewer_bridge_context.v2' or descriptor['scope_sha256']!=digest(scope):raise ValueError('Context descriptor/scope changed')
    output=Path(descriptor['output_dir'])
    if output.parent!=Path(scope['session'])/'analysis/scripts' or output.name!=descriptor['job_id'] or not re.fullmatch(r'viewer_bridge_receipt_[0-9a-f]{64}\.nodes',descriptor['file']):raise ValueError('Context descriptor is outside retained Job output')
    with ordinary(output/descriptor['file']) as stream:
        if os.fstat(stream.fileno()).st_size!=descriptor['byte_count'] or hashlib.file_digest(stream,'sha256').hexdigest()!=descriptor['sha256']:raise ValueError('Context nodes changed')
    return output/descriptor['file']

if __name__=='__main__':
    import sys
    from gxtxt_job_supervisor import tcl_result
    action=sys.argv[1]
    if action=='create_output':
        create_output(sys.argv[2],sys.argv[3]);raise SystemExit(0)
    raw_input=sys.stdin.buffer.read()
    request=json.loads(raw_input)if action!='octave_packets'else None
    if action=='octave_packets':
        print(canonical(octave_packets(sys.argv[2],sys.argv[3],raw_input.decode('utf-8'))).decode())
    elif action=='retain_octave':
        import gxtxt
        output=Path(sys.argv[2]);scope=Path(sys.argv[3]);parameter_path=Path(sys.argv[4]);expected=sys.argv[5]
        with ordinary(parameter_path)as stream:parameter_raw=stream.read()
        if hashlib.sha256(parameter_raw).hexdigest()!=expected:raise ValueError('Original generic parameter changed during provider execution')
        original=load_request(output,parameter_raw.decode('utf-8'))
        if not isinstance(request,dict)or set(request)!={'ok','value'}or request['ok']is not True:raise ValueError('Expected original successful Bridge response')
        from viewer_bridge_request_v1 import _owned_directory
        gxtxt._buffer_root=_owned_directory(scope)
        value=gxtxt._unpack(request['value'])
        receipt=dict(schema='gxtxt.viewer_bridge_result.v1',module_id=sys.argv[6],run_id=sys.argv[7],action=original['action'],request=original['request'],result=retain_value(value,output))
        write_new(output/'viewer_bridge_result.json',retain_result(output,receipt))
    elif action=='input_text':
        print(input_text_read(request['descriptor'],request['scope'],request['component']))
    elif action=='input_text_release':
        input_text_release(request['descriptor'],request['scope']);print('released')
    elif action=='lease':
        resource_path(request['descriptor'],request['scope'])
        if os.environ.get('GXTXT_RESOURCE_LEASE')==request['descriptor']['resource_id'] and os.environ.get('GXTXT_RESOURCE_ROOT')!=request['scope']['resource_root']:raise ValueError('Inherited transfer resource root differs')
        if request['scope']['module']!=sys.argv[2]:raise ValueError('Transferred lease module differs from original public submission')
        print(request['descriptor']['resource_id'])
    elif action=='packet':
        path=resource_path(request['descriptor'],request['scope'])
        packet=resource_packet(request['descriptor'],request['scope'])
        if packet['operation']!=request['action']:raise ValueError('Captured control action changed')
        print(canonical(packet['request']).decode())
    elif action=='snapshot':
        print(tcl_result(snapshot_request(request['descriptor'],request['scope'],request['output'],request['action'])))
    elif action=='frozen':
        print(canonical(frozen_request(request['output'])).decode())
    elif action=='receipt':
        from viewer_bridge_request_v1 import read_result
        if request['action']=='read_resource':
            page=request['page'];result=read_result(request['output'],page['resource_id'],page['offset'],page['count'])
        else:result=read_result(request['output'])
        if request['control_input']:original=frozen_request(request['output'],request['manifest_sha256'])['request']
        else:original=json.loads(request['request_json'])
        receipt=dict(job_id=request['job_id'],request=original,result=result,schema='gxtxt.viewer_bridge_receipt.v1',operation=request['action'],status='completed')
        raw=canonical(receipt)
        if request['context_abi']==2 or len(raw)>1048576:receipt=retain_context(request['output'],receipt,request['scope'],request['request_id'])
        print(canonical(receipt).decode())
    elif action=='context':
        print(canonical(retain_context(request['output'],request['typed_receipt'],request['scope'],request['request_id'])).decode())
    else:raise SystemExit('Unknown fixed control transport action')
