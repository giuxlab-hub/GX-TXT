"""Original-dtype retained inputs for the existing generic Script Bridge.

The caller owns Viewer/Session/source/client admission before and at snapshot.
Only that trusted owner supplies source Job output directories. Public arguments
contain logical Job/resource identities, never paths. This leaf owns no store,
queue, scientific operation registry or numerical implementation.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import uuid

REFERENCE_SCHEMA = 'gxtxt.viewer_bridge_input_buffer.v1'
MANIFEST_SCHEMA = 'gxtxt.viewer_bridge_inputs.v1'
MANIFEST_NAME = 'viewer_bridge_inputs.json'
ARRAY_DIRECTORY = 'viewer_bridge_input_arrays'
MAX_REFERENCES = 256
MAX_BYTES = 512 * 1024 * 1024
_SHA = re.compile(r'[0-9a-f]{64}')
_RESOURCE = re.compile(r'[0-9a-f]{32}\.bin')


def _owned_directory(path):
    # Admission imports this leaf too; resolve its existing directory owner only
    # at call time so the two adapters cannot form an initialization cycle.
    from viewer_bridge_request_v1 import _owned_directory as owned
    return owned(path)


def _binary_owner():
    # Ordinary discovery/scalar clients do not require NumPy. The existing
    # scientific transport dependency is activated only for an actual buffer.
    from gxtxt_scientific_binary_v1 import MAX_BYTES as owner_limit, open_buffer
    if owner_limit != MAX_BYTES:
        raise ValueError('Input buffer limit differs from the scientific transport owner')
    return open_buffer


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')


def _reference(value):
    if not isinstance(value, dict) or set(value) != {'schema', 'job_id', 'resource_id'} or value['schema'] != REFERENCE_SCHEMA:
        raise ValueError('Input buffer reference requires only schema, job_id and resource_id')
    job = value['job_id']
    resource = value['resource_id']
    if not isinstance(job, str) or not job or len(job.encode()) > 256 or any(ord(c) < 32 for c in job):
        raise ValueError('Input buffer requires a bounded logical Job ID')
    if not isinstance(resource, str) or _RESOURCE.fullmatch(resource) is None:
        raise ValueError('Input buffer requires an existing logical binary resource ID')
    return {'schema': REFERENCE_SCHEMA, 'job_id': job, 'resource_id': resource}


def _walk(value, replace, depth=0, active=None):
    if depth > 32:
        raise ValueError('Input buffer argument nesting exceeds 32')
    if not isinstance(value, (dict, list, tuple)):
        return value
    active = set() if active is None else active
    identity = id(value)
    if identity in active:
        raise ValueError('Input buffer arguments cannot contain cycles')
    active.add(identity)
    try:
        if isinstance(value, dict):
            if value.get('schema') == REFERENCE_SCHEMA:
                return replace(_reference(value))
            return {key: _walk(item, replace, depth + 1, active) for key, item in value.items()}
        children = [_walk(item, replace, depth + 1, active) for item in value]
        from gxtxt_cell_v1 import CellArray
        if isinstance(value, CellArray):
            return CellArray(children, value.validated_shape())
        return tuple(children) if isinstance(value, tuple) else children
    finally:
        active.remove(identity)


def _key(reference):
    return hashlib.sha256(_canonical(reference)).hexdigest()


def discover_references(value):
    """Find only explicit logical input refs; ordinary public structs stay data."""
    found = {}
    def collect(reference):
        found.setdefault(_key(reference), reference)
        if len(found) > MAX_REFERENCES:
            raise ValueError('Input buffer reference inventory exceeds 256')
        return reference
    if not isinstance(value,(list,tuple)):raise ValueError('Input references require the ordered argument root')
    _walk(value, collect, depth=-1)
    return list(found.values())


def _occurrences(value):
    result = Counter()
    def count(reference):
        result[_key(reference)] += 1
        return reference
    if not isinstance(value,(list,tuple)):raise ValueError('Input references require the ordered argument root')
    _walk(value, count, depth=-1)
    return result


def _file_state(info):
    return (info.st_dev, info.st_ino, info.st_uid, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _owned_file(fd, size=None):
    info = os.fstat(fd)
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
        raise ValueError('Input buffer files require one link and the current owner')
    if size is not None and info.st_size != size:
        raise ValueError('Input buffer byte count changed')
    return info


def _receipt_identity(output):
    root = _owned_directory(output)
    fd = os.open(root / 'viewer_bridge_result.json', os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        before = _owned_file(fd)
        if before.st_size > 1048576:
            raise ValueError('Retained Viewer result receipt exceeds 1 MiB')
        digest = hashlib.sha256()
        remaining = before.st_size
        while remaining:
            chunk = os.read(fd, min(65536, remaining))
            if not chunk:
                raise ValueError('Retained Viewer result receipt changed while reading')
            digest.update(chunk); remaining -= len(chunk)
        if os.read(fd, 1) or _file_state(_owned_file(fd)) != _file_state(before):
            raise ValueError('Retained Viewer result receipt changed while reading')
        return digest.hexdigest(), _file_state(before)
    finally:
        os.close(fd)


def _descriptor(value):
    fields = {'version', 'dtype', 'endian', 'order', 'shape', 'count', 'byte_count', 'resource_id'}
    if not isinstance(value, dict) or set(value) != fields:
        raise ValueError('Input buffers require the original versioned binary descriptor')
    for key in ('version', 'count', 'byte_count'):
        if type(value[key]) is not int or value[key] < 0:
            raise ValueError('Binary descriptor counts/version require exact integers')
    # open_buffer remains the dtype/shape/order/endian/size authority.
    return json.loads(_canonical(value))


def _write_all(fd, chunk):
    view = memoryview(chunk)
    while view:
        written = os.write(fd, view)
        if written <= 0:
            raise OSError('Input snapshot write did not advance')
        view = view[written:]


def freeze_inputs(value, sources, target_output, *, max_bytes=MAX_BYTES):
    """Snapshot admitted source Job buffers into a NEW existing Job output.

    sources[job_id] has trusted output_dir and optional result_sha256. No source
    directory is ever taken from the public reference. Callers retain and pin
    the returned manifest in their existing immutable invocation metadata.
    """
    from viewer_bridge_request_v1 import read_result
    if type(max_bytes) is not int or not 0 <= max_bytes <= MAX_BYTES:
        raise ValueError('Input buffer aggregate budget must be within 512 MiB')
    if not isinstance(sources, dict):
        raise ValueError('Input buffer sources must be supplied by the admitted Job owner')
    references = discover_references(value)
    occurrences = _occurrences(value)
    open_buffer = _binary_owner() if references else None
    target = _owned_directory(target_output)
    manifest_path = target / MANIFEST_NAME
    if manifest_path.exists() or manifest_path.is_symlink():
        raise ValueError('Input snapshot manifest already exists; it cannot be replaced')
    plans = []
    total = 0
    for reference in references:
        source = sources.get(reference['job_id'])
        if not isinstance(source, dict) or 'output_dir' not in source:
            raise ValueError('Input source Job was not admitted by the caller')
        path = Path(source['output_dir'])
        if not path.is_absolute():
            raise ValueError('Trusted input source output directory must be absolute')
        root = _owned_directory(path)
        if root == target:
            raise ValueError('Input snapshot requires a distinct previously retained Job')
        before = _receipt_identity(root)
        if 'result_sha256' in source and source['result_sha256'] != before[0]:
            raise ValueError('Input source result receipt SHA256 changed')
        page = read_result(root, reference['resource_id'], 0, 0)
        descriptor = _descriptor(page['descriptor'])
        expected_data_sha256 = page.get('resource_sha256')
        if not isinstance(expected_data_sha256, str) or _SHA.fullmatch(expected_data_sha256) is None:
            raise ValueError('Retained input buffers require immutable producer SHA256; rerun the source Job')
        if _receipt_identity(root) != before:
            raise ValueError('Input source result changed during descriptor admission')
        directory = _owned_directory(root / 'viewer_bridge_arrays')
        total += descriptor['byte_count'] * occurrences[_key(reference)]
        if total > max_bytes:
            raise ValueError('Input buffers exceed the aggregate 512 MiB budget')
        plans.append((reference, root, directory, descriptor, before, expected_data_sha256))
    directory = target / ARRAY_DIRECTORY
    if plans:
        directory.mkdir(mode=0o700)
        _owned_directory(directory)
    records = []
    for reference, root, source_directory, descriptor, receipt, expected_data_sha256 in plans:
        if _receipt_identity(root) != receipt:
            raise ValueError('Input source result changed before snapshot')
        source_fd, _, _ = open_buffer(_owned_directory(source_directory), descriptor)
        destination_fd = None
        name = uuid.uuid4().hex + '.bin'
        try:
            before = _owned_file(source_fd, descriptor['byte_count'])
            destination_fd = os.open(directory / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
            digest = hashlib.sha256()
            remaining = descriptor['byte_count']
            while remaining:
                chunk = os.read(source_fd, min(1048576, remaining))
                if not chunk:
                    raise ValueError('Input buffer changed during snapshot')
                _write_all(destination_fd, chunk); digest.update(chunk); remaining -= len(chunk)
            if os.read(source_fd, 1) or _file_state(_owned_file(source_fd)) != _file_state(before):
                raise ValueError('Input buffer changed during snapshot')
            if digest.hexdigest() != expected_data_sha256:
                raise ValueError('Input source buffer differs from its immutable producer SHA256')
            # Some retained filesystems expose coarse metadata timestamps.
            # Rehash the same FD to detect same-size mutation even when mtime
            # and ctime did not advance during this bounded copy.
            os.lseek(source_fd, 0, os.SEEK_SET)
            observed = hashlib.sha256()
            remaining = descriptor['byte_count']
            while remaining:
                chunk = os.read(source_fd, min(1048576, remaining))
                if not chunk:
                    raise ValueError('Input buffer changed during snapshot')
                observed.update(chunk); remaining -= len(chunk)
            if os.read(source_fd, 1) or observed.digest() != digest.digest() or _file_state(_owned_file(source_fd)) != _file_state(before):
                raise ValueError('Input buffer changed during snapshot')
            if _receipt_identity(root) != receipt:
                raise ValueError('Input source receipt changed during snapshot')
            _owned_directory(source_directory); _owned_directory(directory)
            os.fchmod(destination_fd, 0o400); os.fsync(destination_fd)
            _owned_file(destination_fd, descriptor['byte_count'])
        finally:
            os.close(source_fd)
            if destination_fd is not None:
                os.close(destination_fd)
        records.append(dict(reference=reference, reference_sha256=_key(reference),
                            descriptor=dict(descriptor, resource_id=name), sha256=digest.hexdigest(),
                            source_result_sha256=receipt[0]))
    manifest = dict(schema=MANIFEST_SCHEMA, records=records, total_bytes=total,
                    snapshot_bytes=sum(record['descriptor']['byte_count'] for record in records))
    manifest['sha256'] = hashlib.sha256(_canonical(manifest)).hexdigest()
    raw = _canonical(manifest)
    if len(raw) > 1048576:
        raise ValueError('Input snapshot manifest exceeds 1 MiB')
    fd = os.open(manifest_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        _write_all(fd, raw); os.fchmod(fd, 0o400); os.fsync(fd); _owned_file(fd, len(raw))
    finally:
        os.close(fd)
    return manifest


def resolve_inputs(value, manifest, target_output):
    """Replace explicit refs with original ndarrays through the same descriptor FD.

    Resolve all buffers before any scientific API invocation. SHA verification
    uses the actual allocated bytes; no array values are encoded into JSON.
    """
    references = discover_references(value)
    if manifest is None and not references:
        return value
    fields = {'schema', 'records', 'total_bytes', 'snapshot_bytes', 'sha256'}
    if not isinstance(manifest, dict) or set(manifest) != fields or manifest['schema'] != MANIFEST_SCHEMA:
        raise ValueError('Missing or invalid input snapshot manifest')
    unsigned = {key: item for key, item in manifest.items() if key != 'sha256'}
    if hashlib.sha256(_canonical(unsigned)).hexdigest() != manifest['sha256']:
        raise ValueError('Input snapshot manifest SHA256 changed')
    records = manifest['records']
    if not isinstance(records, list) or len(records) > MAX_REFERENCES:
        raise ValueError('Input snapshot record inventory exceeds bounds')
    admitted = {}
    resources = set()
    for record in records:
        if not isinstance(record, dict) or set(record) != {'reference', 'reference_sha256', 'descriptor', 'sha256', 'source_result_sha256'}:
            raise ValueError('Input snapshot record is malformed')
        reference = _reference(record['reference'])
        key = _key(reference)
        if key != record['reference_sha256'] or key in admitted:
            raise ValueError('Input snapshot reference identity changed or duplicated')
        for name in ('sha256', 'source_result_sha256'):
            if not isinstance(record[name], str) or _SHA.fullmatch(record[name]) is None:
                raise ValueError('Input snapshot requires exact byte/receipt SHA256')
        descriptor = _descriptor(record['descriptor'])
        if descriptor['resource_id'] in resources:
            raise ValueError('Input snapshot records cannot borrow another record resource')
        resources.add(descriptor['resource_id'])
        admitted[key] = record
    if set(admitted) != {_key(reference) for reference in references}:
        raise ValueError('Input argument references differ from the frozen snapshot')
    counts = _occurrences(value)
    total = sum(record['descriptor']['byte_count'] * counts[key] for key, record in admitted.items())
    stored = sum(record['descriptor']['byte_count'] for record in admitted.values())
    if any(type(manifest[name]) is not int for name in ('total_bytes', 'snapshot_bytes')) or total != manifest['total_bytes'] or stored != manifest['snapshot_bytes'] or total > MAX_BYTES:
        raise ValueError('Input snapshot aggregate accounting exceeds bounds or changed')
    root = _owned_directory(target_output)
    directory = _owned_directory(root / ARRAY_DIRECTORY) if records else None
    open_buffer = _binary_owner() if records else None
    arrays = {}
    def materialize(reference):
        key = _key(reference)
        if key in arrays:
            return arrays[key]
        record = admitted[key]
        descriptor = record['descriptor']
        fd, dtype, count = open_buffer(_owned_directory(directory), descriptor)
        try:
            before = _owned_file(fd, descriptor['byte_count'])
            if before.st_mode & 0o222:
                raise ValueError('Input snapshot bytes must remain immutable read-only files')
            import numpy as np
            with os.fdopen(fd, 'rb', closefd=False) as stream:
                flat = np.fromfile(stream, dtype=dtype, count=count)
                extra = stream.read(1)
            if flat.size != count or extra or _file_state(_owned_file(fd)) != _file_state(before):
                raise ValueError('Input snapshot changed while reading')
            if hashlib.sha256(memoryview(flat).cast('B')).hexdigest() != record['sha256']:
                raise ValueError('Input snapshot byte SHA256 changed')
            _owned_directory(directory)
        finally:
            os.close(fd)
        arrays[key] = flat.reshape(descriptor['shape'], order='F')
        return arrays[key]
    if not isinstance(value,(list,tuple)):raise ValueError('Input references require the ordered argument root')
    return _walk(value, materialize, depth=-1)


def load_manifest(output, expected_sha256):
    """Load the pinned metadata file through one bounded, owned, immutable FD.

    Shared by Python/Octave execution adapters. This metadata operation remains
    stdlib-only and does not activate a scientific runtime or interpret paths
    supplied by a Viewer argument.
    """
    if not isinstance(expected_sha256, str) or _SHA.fullmatch(expected_sha256) is None:
        raise ValueError('Input manifest requires an exact expected raw-file SHA256')
    root = _owned_directory(output)
    path = root / MANIFEST_NAME
    if path.is_symlink():
        raise ValueError('Input manifest forbids symlink aliases')
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    try:
        before = _owned_file(fd)
        if before.st_mode & 0o222:
            raise ValueError('Input manifest must remain an immutable read-only file')
        if before.st_size > 1048576:
            raise ValueError('Input manifest exceeds 1 MiB')
        chunks = []
        digest = hashlib.sha256()
        remaining = before.st_size
        while remaining:
            chunk = os.read(fd, min(65536, remaining))
            if not chunk:
                raise ValueError('Input manifest changed while reading')
            chunks.append(chunk); digest.update(chunk); remaining -= len(chunk)
        if os.read(fd, 1) or _file_state(_owned_file(fd)) != _file_state(before):
            raise ValueError('Input manifest changed while reading')
        if digest.hexdigest() != expected_sha256:
            raise ValueError('Input manifest raw-file SHA256 changed')
        _owned_directory(root)
    finally:
        os.close(fd)
    def unique_fields(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Input manifest contains duplicate JSON fields')
            result[key] = value
        return result
    def finite_only(value):
        raise ValueError('Input manifest cannot contain nonfinite JSON constants')
    result = json.loads(b''.join(chunks).decode('utf-8'), object_pairs_hook=unique_fields, parse_constant=finite_only)
    if not isinstance(result, dict):
        raise ValueError('Input manifest must be a metadata object')
    return result
