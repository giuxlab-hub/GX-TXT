"""Debian compute agent: authenticated projection of existing CORE authorities.

The HTTP loop admits no shell, scripts, filesystem paths or executable names.
Scientific Jobs belong exclusively to the existing node-local Job Supervisor.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import argparse
import configparser
import hashlib
from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import math
import os
from pathlib import Path
import platform
import sqlite3
import ssl
import socket
import struct
import uuid
import time
import sys
import _tkinter
from gxtxt_remote_transport import MAX_BODY, pack, unpack
from gxtxt_script_bridge_server import Host

def native_build_metadata(module_root, module, entrypoint):
    """Read normal installed project inputs, never infer a target executable."""
    from gxtxt_viewer_development import read_project, project_sources, source_identity
    root = Path(module_root)
    if not root.is_dir() or any(path.is_symlink() for path in (root, *root.parents)):
        raise ValueError('Installed native build project forbids aliases')
    project = root / 'source'
    meta = read_project(project, installed=True)
    if meta['module_id'] != module or entrypoint not in meta.get('native_jobs', {}):
        raise ValueError('Installed native build project/module/entrypoint mismatch')
    files = project_sources(project, meta)
    # project_sources intentionally contains compilation inputs only. Bind the
    # normal project's metadata/design too: task SHA alone omits parameters and
    # which reviewed translation units an entry selects.
    files = dict(files)
    for name in ('project.json', 'design.gxtxt-viewer'):
        files[name] = (project / name).read_bytes()
    if json.loads(files['project.json']) != meta:
        raise ValueError('Installed native project changed during metadata admission')
    module_path = root / 'module.ini'
    if module_path.is_symlink() or not module_path.is_file() or module_path.stat().st_nlink != 1 or module_path.stat().st_size > 4194304:
        raise ValueError('Installed native module descriptor must be ordinary and bounded')
    files['module.ini'] = module_path.read_bytes()
    module_meta = configparser.ConfigParser(interpolation=None)
    module_meta.read_string(files['module.ini'].decode('utf-8'))
    if module_meta.get('meta', 'id') != module or module_meta.get('meta', 'version') != str(meta['version']):
        raise ValueError('Installed native module/project version identity mismatch')
    contract = meta['native_jobs'][entrypoint]
    return dict(project_source_sha256=source_identity(files)['source_tree_sha256'],
                build_contract_sha256=hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest(),
                parameters=contract.get('parameters', {}))

class Node:
    def __init__(self, config):
        self.config = config
        self.root = Path(config['state_root']).resolve(); self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(self.root, 0o700)
        # These are installation/user configuration, never Session credentials.
        for name in ('XDG_CONFIG_HOME', 'XDG_DATA_HOME', 'XDG_CACHE_HOME', 'XDG_STATE_HOME', 'GXTXT_JOB_ROOT', 'GXTXT_RESOURCE_ROOT'):
            os.environ[name] = str(self.root / name)
        self.hosts = {}; self.digests = {}; self.stages = {}
        self.db = sqlite3.connect(self.root / 'remote_requests.sqlite')
        self.db.execute('CREATE TABLE IF NOT EXISTS requests (client TEXT, nonce TEXT, fingerprint TEXT, state TEXT, job TEXT, PRIMARY KEY(client,nonce))')
        self.db.execute('CREATE TABLE IF NOT EXISTS resources (client TEXT, session TEXT, fingerprint TEXT, reference TEXT, PRIMARY KEY(client,session,fingerprint))')
        self.db.commit()

    def host(self, client, session):
        grants = self.config['clients'].get(client, {})
        if session not in grants.get('sessions', []): raise ValueError('Client is not authorized for this Session')
        if session not in self.config['sessions']: raise ValueError('Unknown authorized Session')
        if session not in self.hosts:
            path = Path(self.config['sessions'][session]).resolve()
            runtime = self.root / ('runtime_' + hashlib.sha256(session.encode()).hexdigest() + '.ini')
            cfg = configparser.ConfigParser(interpolation=None)
            cfg['runtime'] = dict(session=str(path), module_id='core.scientific_execution', run_id='compute-node')
            with runtime.open('w') as f: cfg.write(f)
            host = Host(runtime)
            host.call('::GX::scientificExecutionRegisterBuiltins')
            self.hosts[session] = host
        return self.hosts[session]

    def summary_scope(self, client):
        """Counts-only operational grant; never initialize a scientific Host."""
        grants = self.config['clients'].get(client)
        if not isinstance(grants, dict) or not grants.get('sessions'):
            raise ValueError('Client is not authorized for Job summary Sessions')
        sessions = grants['sessions']
        if not isinstance(sessions, list) or any(not isinstance(s, str) or s not in self.config['sessions'] for s in sessions):
            raise ValueError('Client is not authorized for configured Job summary Sessions')
        return sorted({str(Path(self.config['sessions'][s]).resolve()) for s in sessions})

    def summary_retire(self):
        """Release transient monitoring only; no durable Job or state changes."""
        listener = getattr(self, '_summary_socket', None)
        if listener is not None: listener.close()
        self._summary_socket = None
        self._summary_cache = {}; self._summary_buffer = bytearray()
        self._summary_hint = None

    def summary_idle(self):
        # Existing HTTP service_actions owns this bounded monitor lease. A dead
        # client must not keep the original idle Supervisor alive forever.
        if getattr(self, '_summary_socket', None) is not None and time.monotonic() - getattr(self, '_summary_touched', 0) > 30:
            self.summary_retire()

    def summary_page(self, client, after_sequence=0, previous_revision='', wait_ms=0, monitor=False):
        if type(wait_ms) is not int or not 0 <= wait_ms <= 1000:
            raise ValueError('Job summary wait exceeds metadata bounds')
        deadline = time.monotonic() + wait_ms / 1000
        while True:
            remaining = max(0, int((deadline - time.monotonic()) * 1000 + .999))
            page = self._summary_read_page(client, after_sequence, previous_revision, remaining, monitor)
            if not monitor or page['changed'] or time.monotonic() >= deadline:
                return page
            # A foreign Session's wake must not shorten an unchanged caller's
            # wait and disclose activity through response/frame timing.

    def _summary_read_page(self, client, after_sequence=0, previous_revision='', wait_ms=0, monitor=False):
        """Project the existing UID journal through the current CN Session grants.

        HOST_ONLY_JUSTIFIED: authenticated operational metadata is not an
        untrusted module's global Job/result/cancellation grant. The one shared
        local socket carries wake hints only; unrestricted counts never leave
        this adapter. Transient filtered caches are not a second Job store.
        """
        from gxtxt_job_events import read_summary_root, endpoint
        import base64
        import select
        import stat
        sessions = self.summary_scope(client)
        if monitor: self._summary_touched = time.monotonic()
        root = self.root / 'GXTXT_JOB_ROOT'
        if not hasattr(self, '_summary_cache'):
            self._summary_cache = {}; self._summary_socket = None
            self._summary_buffer = bytearray(); self._summary_hint = None
            self._summary_start = 0
        if type(after_sequence) is not int or after_sequence < 0 or type(wait_ms) is not int or not 0 <= wait_ms <= 1000 or not isinstance(previous_revision, str) or (previous_revision and (len(previous_revision) != 64 or any(c not in '0123456789abcdef' for c in previous_revision))):
            raise ValueError('Job summary cursor/revision/wait exceeds metadata bounds')
        # Recheck physical scope even for cached metadata. Never follow a newly
        # substituted alias, or keep a previous journal's apparently current zero.
        for path in (root, *root.parents):
            if path.is_symlink():
                raise ValueError('Job summary journal identity changed')
        database = root / 'jobs.sqlite'
        identity = ''
        if root.exists() and database.exists():
            r, d = root.stat(), database.lstat()
            if r.st_uid != os.getuid() or d.st_uid != os.getuid() or not stat.S_ISDIR(r.st_mode) or not stat.S_ISREG(d.st_mode) or d.st_nlink != 1:
                raise ValueError('Job summary journal ownership refused')
            identity = (r.st_dev, r.st_ino, d.st_dev, d.st_ino)
        if getattr(self, '_summary_physical', None) != identity:
            if self._summary_socket is not None: self._summary_socket.close()
            self._summary_socket = None; self._summary_buffer.clear()
            self._summary_hint = None; self._summary_cache.clear()
            self._summary_physical = identity
        if monitor and self._summary_socket is None:
            # Monitoring explicitly initializes only the SAME original journal;
            # a snapshot read alone remains read-only. No scientific Job exists.
            import gxtxt_job_supervisor as supervisor
            if time.monotonic() - self._summary_start > 10:
                owned = supervisor.root_path(root)
                connection = supervisor.connect(owned); connection.close()
                supervisor.ensure(owned); self._summary_start = time.monotonic()
            listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            listener.settimeout(.25)
            try:
                listener.connect(endpoint(root))
                if struct.unpack('3i', listener.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))[1] != os.getuid():
                    raise ValueError('Job summary event peer is not owned by this account')
                listener.sendall(b'{"operation":"summary_watch","after_sequence":0}\n')
                listener.setblocking(False); self._summary_socket = listener
            except (FileNotFoundError, ConnectionRefusedError, socket.timeout):
                listener.close()
            except BaseException:
                listener.close(); raise
        changed_hint = False
        if monitor and self._summary_socket is None and wait_ms:
            # Explicit bounded startup reconciliation, not a journal scan.
            time.sleep(wait_ms / 1000)
        if self._summary_socket is not None:
            # No SQLite polling on idle waits. A persistent existing-owner
            # listener emits initial state and actual metadata revisions only.
            if select.select([self._summary_socket], [], [], wait_ms / 1000)[0]:
                raw = self._summary_socket.recv(65536)
                if not raw:
                    self._summary_socket.close(); self._summary_socket = None
                    self._summary_cache.clear()
                    raise ValueError('Job summary notification owner disconnected')
                self._summary_buffer.extend(raw)
                if len(self._summary_buffer) > 131072:
                    raise ValueError('Job summary notification exceeds metadata bound')
                while b'\n' in self._summary_buffer:
                    line, _, rest = self._summary_buffer.partition(b'\n')
                    self._summary_buffer = bytearray(rest)
                    try:
                        frame = json.loads(base64.b64decode(line, validate=True))
                        revision = frame.get('state_revision')
                        if frame.get('schema') != 'gxtxt.job_summary.v1' or frame.get('node_id') != 'local' or frame.get('availability') != 'AVAILABLE' or not isinstance(revision, str) or len(revision) != 64 or any(c not in '0123456789abcdef' for c in revision):
                            raise ValueError('Invalid Job summary notification identity')
                    except (ValueError, TypeError, AttributeError):
                        self.summary_retire()
                        raise ValueError('Invalid Job summary notification identity') from None
                    if revision != self._summary_hint:
                        changed_hint = True; self._summary_hint = revision
            if changed_hint:
                # One shared wake invalidates EVERY grant-scoped snapshot;
                # the first client consuming it cannot strand another scope.
                self._summary_cache.clear()
        scope = hashlib.sha256(json.dumps([self.config['node_id'], client, sorted(set(self.config['clients'][client]['sessions'])), sessions, identity], separators=(',', ':')).encode()).hexdigest()
        if not monitor or changed_hint or scope not in self._summary_cache:
            summary = read_summary_root(root, sessions)
            if summary.get('availability') == 'AVAILABLE' and summary.get('journal_identity') != hashlib.sha256(json.dumps(identity, separators=(',', ':')).encode()).hexdigest():
                self.summary_retire()
                raise ValueError('Job summary journal changed during grant projection')
            summary = dict(summary, node_id=self.config['node_id'], coverage='granted_node_sessions')
            if monitor and self._summary_socket is None:
                summary.update(availability='INITIALIZING', complete=False)
                for key in ('counts', 'visible_counts', 'total', 'active', 'running', 'queued', 'failed', 'interrupted', 'unknown', 'attention'):
                    summary[key] = None
            self._summary_cache[scope] = summary
        summary = dict(self._summary_cache[scope])
        revision = hashlib.sha256(json.dumps([scope, summary.get('journal_identity'), summary.get('state_revision'), summary['availability']], separators=(',', ':')).encode()).hexdigest()
        return dict(summary, scope_key=scope, revision=revision, changed=revision != previous_revision,
                    observed_at=time.time(), notification_available=self._summary_socket is not None)

    def identity(self, host, dataset):
        host.call('::GX::loadDatasetRegistry', host.session)
        path = Path(str(host.call('::GX::datasetResolvePath', host.session, dataset)))
        stamp = path.stat(); key = (str(path), stamp.st_ino, stamp.st_size, stamp.st_mtime_ns)
        if key not in self.digests:
            with path.open('rb') as stream: digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            self.digests = {k:v for k,v in self.digests.items() if k[0] != str(path)}
            self.digests[key] = digest
        expected = str(host.call('::GX::datasetField', dataset, 'canonical_sha256', ''))
        if expected and expected != self.digests[key]: raise ValueError('Authoritative Dataset integrity mismatch')
        revision = str(host.call('format', '%s', host.call('::GX::datasetRevisionToken', dataset, host.session)))
        return hashlib.sha256((revision + '\0' + self.digests[key]).encode()).hexdigest()

    def native_identity(self, host, module, entrypoint, expected=None, *, build=False):
        """Inspect only an already installed entrypoint; never admit uploaded code.

        Descriptor verification and installed-module ownership remain in the
        native Job owner. This adapter compares both ends before preparation.
        """
        raw = host.call('::GX::nativeJobDescribe', module, entrypoint)
        actual = host.as_dict(raw)
        fields = {'module_id', 'entrypoint', 'artifact_sha256', 'source_sha256', 'abi', 'dependencies', 'runtime_dependencies'}
        if build:
            raw = host.call('::GX::_scientificExecutionNativeBuildIdentity', module, entrypoint, raw)
            actual = host.as_dict(raw)
            fields |= {'project_source_sha256', 'build_contract_sha256'}
        if not fields <= set(actual) or str(actual['module_id']) != module or str(actual['entrypoint']) != entrypoint:
            raise ValueError('Installed native entrypoint identity is incomplete')
        if expected is not None:
            requested = host.as_dict(expected)
            if set(requested) != fields:
                raise ValueError('Native remote admission requires exact ABI/source/artifact/dependency identity')
            for key in fields:
                left, right = requested[key], actual[key]
                if key in ('abi', 'dependencies', 'runtime_dependencies'):
                    left = {str(k): str(v) for k, v in host.as_dict(left).items()}
                    right = {str(k): str(v) for k, v in host.as_dict(right).items()}
                else:
                    left, right = str(left), str(right)
                if left != right:
                    raise ValueError('Native remote ' + key + ' identity mismatch')
        # Internal file names/module roots never cross the transport boundary.
        return host.tcl_arg({key: actual[key] for key in sorted(fields)})

    def native_build_pair(self, host, module, entrypoint, client_raw, target_raw):
        """Two verified builds share one source/SDK/parameter/ABI contract."""
        if len(str(client_raw).encode()) > 65536:
            raise ValueError('Native client build identity exceeds bound')
        fields = {'module_id', 'entrypoint', 'artifact_sha256', 'source_sha256', 'abi', 'dependencies', 'runtime_dependencies', 'project_source_sha256', 'build_contract_sha256'}
        client, target = host.as_dict(client_raw), host.as_dict(target_raw)
        if set(client) != fields or set(target) != fields:
            raise ValueError('Native paired build identity requires exact source/ABI/parameter fields')
        for identity in (client, target):
            if str(identity['module_id']) != module or str(identity['entrypoint']) != entrypoint:
                raise ValueError('Native paired build module/entrypoint mismatch')
            for key in ('artifact_sha256', 'source_sha256', 'project_source_sha256', 'build_contract_sha256'):
                value = str(identity[key])
                if len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
                    raise ValueError('Native paired build requires exact SHA256 identities')
            for key in ('abi', 'dependencies', 'runtime_dependencies'):
                inventory = host.as_dict(identity[key])
                if len(inventory) > 256:
                    raise ValueError('Native paired build inventory exceeds bound')
                if key != 'abi':
                    for name, digest in inventory.items():
                        name, digest = str(name), str(digest)
                        if not name or len(name) > 512 or '\0' in name or Path(name).is_absolute() or '..' in Path(name).parts or (key == 'runtime_dependencies' and '/' in name):
                            raise ValueError('Native paired build dependency identity is invalid')
                        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
                            raise ValueError('Native paired build dependency SHA256 is invalid')
        # This is narrowly the same task/artifact with independently verified
        # system runtimes. No different compiler artifact, UI/source project,
        # ABI or bundled dependency is admitted by runtime selection.
        for key in sorted(fields - {'runtime_dependencies'}):
            left, right = client[key], target[key]
            if key in ('abi', 'dependencies'):
                left = {str(k): str(v) for k, v in host.as_dict(left).items()}
                right = {str(k): str(v) for k, v in host.as_dict(right).items()}
            else:
                left, right = str(left), str(right)
            if left != right:
                raise ValueError('Native paired build ' + key + ' contract mismatch')
        return host.tcl_arg(dict(schema='gxtxt.native_remote_build.v1', node_id=self.config['node_id'],
                                 client_identity=client_raw, target_identity=target_raw))

    def native_request_client(self, host, job_id, client):
        status = host.as_dict(host.call('::GX::scientificExecutionStatus', job_id))
        if str(status.get('provider_id', '')).startswith('native.'):
            owner = host.as_dict(status.get('native_owner', ''))
            if str(owner.get('remote_client_id', '')) != client or 'client_origin' not in owner:
                raise ValueError('Native remote Job belongs to another client grant or requires origin readmission')
            if 'remote_build' in owner:
                pair = host.as_dict(owner['remote_build'])
                if set(pair) != {'schema', 'node_id', 'client_identity', 'target_identity'} or str(pair['schema']) != 'gxtxt.native_remote_build.v1' or str(pair['node_id']) != self.config['node_id']:
                    raise ValueError('Native remote build pair identity/node changed')
                target = host.as_dict(pair['target_identity'])
                self.native_build_pair(host, str(target['module_id']), str(target['entrypoint']), pair['client_identity'], pair['target_identity'])
                metadata = host.as_dict(host.call('::GX::_scientificExecutionNativeBuildMetadata', target['module_id'], target['entrypoint']))
                for key in ('project_source_sha256', 'build_contract_sha256'):
                    if str(metadata[key]) != str(target[key]):
                        raise ValueError('Native target build project/source/parameter identity changed')
        return status

    def event_page(self, host, job_id, after_sequence, limit, wait_ms, client):
        """Project the authoritative journal, optionally waiting for its socket.

        A short blocking notification wait bounds single-request server latency;
        no GUI/status timer or second event store is involved.
        """
        if not 0 <= after_sequence or not 1 <= limit <= 128 or not 0 <= wait_ms <= 1000:
            raise ValueError('Remote event cursor/page/wait exceeds bounds')
        status = self.native_request_client(host, job_id, client)
        if str(status.get('provider_id', '')).startswith('native.'):
            host.call('::GX::nativeJobStatus', job_id)
        import gxtxt_job_supervisor as supervisor
        from gxtxt_job_events import endpoint, read_events
        root = supervisor.root_path(os.environ['GXTXT_JOB_ROOT'])
        connection = supervisor.connect(root)
        try:
            events = read_events(connection, job_id, after_sequence, limit)
            terminal = str(status['state']) in ('COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED')
            if not events and not terminal and wait_ms:
                # The existing Supervisor event server performs journal replay
                # and wakeup. Do not poll SQLite or scientific status here.
                listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                listener.settimeout(wait_ms / 1000)
                try:
                    listener.connect(endpoint(root))
                    if struct.unpack('3i', listener.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))[1] != os.getuid():
                        raise ValueError('Supervisor event peer is not owned by this account')
                    listener.sendall(json.dumps(dict(job_id=job_id, after_sequence=after_sequence)).encode() + b'\n')
                    if not listener.recv(65536):
                        raise ValueError('Supervisor event transport closed; reconnect by retained Job ID')
                except socket.timeout:
                    pass
                except (FileNotFoundError, ConnectionRefusedError):
                    raise ValueError('Supervisor event transport unavailable; reconnect by retained Job ID')
                finally:
                    listener.close()
                events = read_events(connection, job_id, after_sequence, limit)
        finally:
            connection.close()
        result = []
        used = 0
        for item in events:
            if item.get('schema') != 'gxtxt.job_event.v1' or item.get('job_id') != job_id or type(item.get('sequence')) is not int or item['sequence'] <= after_sequence or type(item.get('terminal')) is not bool:
                raise ValueError('Supervisor event identity/sequence mismatch')
            event = dict(item, node_id=self.config['node_id'])
            size = len(json.dumps(event, separators=(',', ':'), ensure_ascii=False).encode())
            if size > 1048576:
                raise ValueError('Supervisor event exceeds bounded remote frame')
            if used + size > 1048576:
                break
            result.append(event); used += size
            after_sequence = event['sequence']
            terminal = bool(event.get('terminal', False))
        return dict(schema='gxtxt.remote_job_events.v1', node_id=self.config['node_id'],
                    job_id=job_id, after_sequence=after_sequence, events=result, terminal=terminal)

    def native_client_origin(self, host, raw, module, entrypoint):
        """Validate inert client source stamps; they never select node paths.

        The node cannot validate client-local Documents. It retains the exact
        bounded origin in the SAME native Job request for the client-side owner
        to revalidate on status/result/reconnect after a cold process reopen.
        """
        if len(raw.encode('utf-8')) > 16384:
            raise ValueError('Native client origin exceeds bounded identity metadata')
        origin = host.as_dict(raw)
        fields = {'schema', 'module_id', 'entrypoint', 'session_origin', 'session_fingerprint', 'source_identities'}
        if set(origin) != fields or str(origin['schema']) != 'gxtxt.native_client_origin.v1' or str(origin['module_id']) != module or str(origin['entrypoint']) != entrypoint:
            raise ValueError('Native client origin schema/module/entrypoint mismatch')
        fingerprint = str(origin['session_fingerprint'])
        if len(fingerprint) != 64 or any(c not in '0123456789abcdef' for c in fingerprint) or not str(origin['session_origin']):
            raise ValueError('Native client origin lacks exact Session identity')
        identities = host.as_dict(origin['source_identities'])
        if set(identities) - {'workspace', 'datasets'}:
            raise ValueError('Native client origin contains unsupported source identities')
        if 'workspace' in identities:
            workspace = host.as_dict(identities['workspace'])
            if set(workspace) != {'id', 'generation', 'revision', 'sha256'}:
                raise ValueError('Native client Document origin requires exact generation/revision/SHA')
        if 'datasets' in identities and len(host.as_dict(identities['datasets'])) > 256:
            raise ValueError('Native client Dataset origin exceeds bounds')
        return raw

    def dispatch(self, client, request, blobs=()):
        operation = request.get('operation'); args = request.get('arguments', [])
        if not isinstance(args, list) or len(args) > 12 or any(not isinstance(a, str) for a in args):
            raise ValueError('Invalid scoped CORE remote arguments')
        session = request.get('session_id', '')
        if operation == 'sessions':
            return dict(result=self.config['clients'].get(client, {}).get('sessions', [])), []
        if operation in ('jobs.summary', 'jobs.summary_events'):
            if blobs or session != '':
                raise ValueError('Job summary accepts no binary payload or single Session override')
            if operation == 'jobs.summary' and not args:
                return dict(summary_page=self.summary_page(client)), []
            if operation == 'jobs.summary_events' and len(args) == 3 and args[0].isdecimal() and args[2].isdecimal():
                return dict(summary_page=self.summary_page(client, int(args[0]), args[1], int(args[2]), monitor=True)), []
            raise ValueError('Invalid Job summary metadata request')
        host = self.host(client, session)
        text = lambda value: str(host.call('format', '%s', value))
        for token, stage in list(self.stages.items()):
            if time.monotonic()-stage['touched']>600:
                try:self.host(stage['client'],stage['session']).call('::GX::interactiveDocumentResourceAbort',stage['writer'])
                except Exception:pass
                del self.stages[token]
        if operation == 'resource.lookup' and len(args)==3:
            fingerprint=hashlib.sha256(('\0'.join(args)).encode()).hexdigest()
            prior=self.db.execute('SELECT reference FROM resources WHERE client=? AND session=? AND fingerprint=?',(client,session,fingerprint)).fetchone()
            if prior:
                try:
                    host.call('::GX::interactiveDocumentResourceInfo',prior[0])
                    return dict(result=prior[0]),[]
                except Exception:
                    self.db.execute('DELETE FROM resources WHERE client=? AND session=? AND fingerprint=?',(client,session,fingerprint));self.db.commit()
            return dict(result=''),[]
        if operation == 'resource.open':
            if len(args)!=3 or len(self.stages)>=16 or not 0<=int(args[2])<=8388608:
                raise ValueError('Remote staged input exceeds managed resource limits')
            document=host.as_dict(host.call('::GX::interactiveDocumentCreate','core.scientific_execution','managed_remote_input','binary',1,{}))
            writer=host.call('::GX::interactiveDocumentResourceOpenWriter',document['id'],args[0])
            token='stage-'+uuid.uuid4().hex
            self.stages[token]=dict(client=client,session=session,writer=writer,sha256=args[1],size=int(args[2]),offset=0,touched=time.monotonic(),fingerprint=hashlib.sha256(('\0'.join(args)).encode()).hexdigest())
            return dict(result=token),[]
        if operation.startswith('resource.'):
            if not args or args[0] not in self.stages: raise ValueError('Unknown remote resource stage')
            stage=self.stages[args[0]]
            if (stage['client'],stage['session'])!=(client,session): raise ValueError('Resource belongs to another grant')
            if operation=='resource.append' and len(args)==2 and len(blobs)==1:
                raw=blobs[0]
                if len(raw)>1048576 or int(args[1])!=stage['offset'] or stage['offset']+len(raw)>stage['size']:
                    raise ValueError('Invalid staged resource block offset/size')
                host.tcl.call('::GX::interactiveDocumentResourceAppend',stage['writer'],raw)
                stage['offset']+=len(raw);stage['touched']=time.monotonic()
                return dict(result=stage['offset']),[]
            if operation=='resource.finalize' and len(args)==1:
                if stage['offset']!=stage['size']: raise ValueError('Incomplete remote input')
                reference=host.call('::GX::interactiveDocumentResourceFinalize',stage['writer'])
                parsed=host.as_dict(reference)
                if str(parsed['sha256'])!=stage['sha256'] or int(parsed['size_bytes'])!=stage['size']:
                    raise ValueError('Staged input SHA/size disagrees with its source')
                self.db.execute('INSERT OR REPLACE INTO resources VALUES (?,?,?,?)',(client,session,stage['fingerprint'],text(reference)));self.db.commit()
                del self.stages[args[0]]
                return dict(result=reference),[]
            if operation=='resource.abort' and len(args)==1:
                host.call('::GX::interactiveDocumentResourceAbort',stage['writer']);del self.stages[args[0]]
                return dict(result='aborted'),[]
            raise ValueError('Unsupported managed resource operation')
        if blobs: raise ValueError('This operation does not accept arbitrary binary uploads')
        if operation == 'native.describe' and len(args) == 2:
            return dict(result=self.native_identity(host, *args)), []
        if operation == 'native.describe' and len(args) == 3 and args[2] == 'build.v1':
            return dict(result=self.native_identity(host, *args[:2], build=True)), []
        if operation == 'native.prepare' and len(args) in (5, 6):
            module, entrypoint, expected, parameters, options = args[:5]
            resources = args[5] if len(args) == 6 else ''
            scoped_options = host.as_dict(options)
            if set(scoped_options) - {'dataset_sources', 'client_origin', 'client_identity'}:
                raise ValueError('Remote native options require node-local source identities')
            client_identity = scoped_options.pop('client_identity', None)
            target_identity = self.native_identity(host, module, entrypoint, expected, build=client_identity is not None)
            pair = None if client_identity is None else self.native_build_pair(host, module, entrypoint, client_identity, target_identity)
            if 'client_origin' not in scoped_options:
                raise ValueError('Remote native admission requires durable client origin; readmit from the originating Viewer')
            origin = self.native_client_origin(host, str(scoped_options.pop('client_origin')), module, entrypoint)
            scoped_options['node_id'] = 'local'
            token = host.call('::GX::nativeJobPrepare', module, entrypoint, parameters, host.tcl_arg(scoped_options), resources)
            # Existing prepared metadata becomes part of the same journaled
            # request; no parallel client identity store or Job table is added.
            host.call('dict', 'set', '::GX::ScientificExecution::prepared', token, 'request', 'native_owner', 'client_origin', origin)
            host.call('dict', 'set', '::GX::ScientificExecution::prepared', token, 'request', 'native_owner', 'remote_client_id', client)
            if pair is not None:
                host.call('dict', 'set', '::GX::ScientificExecution::prepared', token, 'request', 'native_owner', 'remote_build', pair)
            return dict(result=token), []
        if operation == 'native.result' and len(args) == 2:
            if not args[1]:
                raise ValueError('Remote native result requires an explicit Viewer owner')
            self.native_request_client(host, args[0], client)
            return dict(result=host.call('::GX::nativeJobResult', *args)), []
        if operation == 'native.client_owner_claim' and len(args) == 4:
            # Script Bridge exposure: HOST_ONLY_JUSTIFIED. The trusted owning
            # GUI attests its client process/window lifetime after local checks;
            # worker scripts cannot provide Host liveness. Authenticated client
            # grant AND actual native module/source ownership precede the same
            # Supervisor CAS. The private keyword is not a CLI/Bridge grant.
            job_id, module, expected, proposed = args
            if not module:
                raise ValueError('Remote native client owner claim requires an explicit Viewer owner')
            self.native_request_client(host, job_id, client)
            host.call('::GX::nativeJobStatus', job_id, module)
            import gxtxt_job_supervisor as supervisor
            connection = supervisor.connect(supervisor.root_path(os.environ['GXTXT_JOB_ROOT']))
            try:
                result = supervisor.client_owner_claim(connection, job_id, expected, proposed, host_attested=True)
            finally:
                connection.close()
            return dict(result=host.tcl_arg(result)), []
        if operation == 'scientific.events' and len(args) == 4:
            if any(not value.isdecimal() for value in args[1:]):
                raise ValueError('Remote event cursor/page/wait must be nonnegative integers')
            return dict(event_page=self.event_page(host, args[0], *map(int, args[1:]), client=client)), []
        if operation == 'capabilities':
            providers = []
            for provider in host.as_list(host.call('::GX::scientificExecutionDiscover')):
                d = host.as_dict(host.call('::GX::scientificExecutionDescribe', provider)); tools = {}
                for tool in host.as_list(d['tools']):
                    try: tools[str(tool)] = bool(host.call('::GX::runtimeToolResolve', tool))
                    except Exception: tools[str(tool)] = False
                providers.append(dict(provider_id=str(provider), version=str(d['version']), available=all(tools.values()), tools=tools))
            import gxtxt_job_supervisor as supervisor
            c = supervisor.connect(supervisor.root_path(os.environ['GXTXT_JOB_ROOT']))
            policy = supervisor.policy(c); c.close()
            core_apis = host.call('::GX::scientificExecutionCoreCapabilities')
            # Availability advertises an installed service, never permission to
            # upload executable bytes. Exact artifacts use native.describe.
            native = dict(available=bool(host.call('info', 'commands', '::GX::nativeJobDescribe')),
                          descriptor_schema='gxtxt.native_job_artifact.v1', protocol=1,
                          admission='installed_module_only', event_protocol='gxtxt.remote_job_events.v1')
            summary = dict(protocol=1, schema='gxtxt.job_summary.v1', scope='granted_node_sessions', notifications='existing_supervisor', max_wait_ms=1000)
            return dict(result=host.tcl_arg(dict(node_id=self.config['node_id'], os=platform.system(), architecture=platform.machine(), cores=os.cpu_count(), providers=[host.tcl_arg(p) for p in providers], policy=policy, core_apis=core_apis, native_jobs=native, job_summary=summary))), []
        if operation == 'dataset.catalog':
            entries = []
            for dataset in host.as_list(host.call('::GX::datasetRegistryIds')):
                revision = self.identity(host, dataset)
                fields = host.call('array', 'get', '::GX::datasetRegistry', str(dataset) + ',*')
                parsed = host.as_dict(fields)
                fields = {k[len(str(dataset))+1:]:v for k,v in parsed.items()}
                for name in ('path', 'source_raw', 'structured_metadata_file'): fields.pop(name, None)
                handle = None
                try:
                    handle = host.call('::GX::datasetAccessOpen', host.session, dataset)
                    metadata = host.call('::GX::datasetAccessMetadata', handle)
                except Exception:
                    metadata = host.tcl_arg(dict(dataset_id=str(dataset), variables=[], capabilities={}, availability='metadata_only'))
                finally:
                    if handle is not None: host.call('::GX::datasetAccessClose', handle)
                metadata_values=host.call('::GX::datasetMetadataRead',host.session,dataset)
                entries.append(host.tcl_arg(dict(dataset_id=str(dataset), revision=revision, fields=fields, metadata=metadata, metadata_values=metadata_values, coordinate_context=host.call('::GX::_datasetCoordinateStored',host.session,dataset))))
            return dict(result=host.tcl_arg(entries)), []
        if operation.startswith('dataset.'):
            if len(args) < 2: raise ValueError('Dataset ID and source revision required')
            dataset, expected, *bounds = args
            if expected != self.identity(host, dataset): raise ValueError('Remote Dataset source revision changed; refresh its catalog')
            if operation == 'dataset.preview' and len(bounds)==1:
                key=host.call('::GX::datasetPreviewCacheKey',dataset,bounds[0])
                result=host.call('::GX::datasetPreviewCacheRead',dataset,key)
                if not str(result):
                    state=host.as_dict(host.call('::GX::datasetPreviewCacheStatus',key))
                    if str(state['status'])=='error': raise ValueError(str(state.get('message','Remote Preview preparation failed')))
                    if str(state['status'])!='preparing': host.call('::GX::datasetPreviewCacheRequest',dataset,bounds[0])
                    return dict(pending=True,key=str(key)),[]
                blocks=[];artifacts=[]
                if int(host.call('dict','exists',result,'digitizer','images')):
                    images=host.as_dict(host.call('dict','get',result,'digitizer','images'))
                    for image_id,image in images.items():
                        info=host.as_dict(image);name='image_'+str(len(artifacts))+'.png'
                        raw=Path(str(info['path'])).read_bytes()
                        if len(raw)>2097152: raise ValueError('Remote image derivative exceeds 2 MiB')
                        artifacts.append(dict(image_id=image_id,name=name,block=len(blocks)))
                        blocks.append(raw)
                        result=host.call('dict','replace',result,'digitizer',host.call('dict','replace',host.call('dict','get',result,'digitizer'),'images',host.call('dict','replace',host.call('dict','get',result,'digitizer','images'),image_id,host.call('dict','replace',image,'path',name))))
                if int(host.call('dict','exists',result,'media_artifact','path')):
                    media=host.call('dict','get',result,'media_artifact')
                    raw=Path(str(host.call('dict','get',media,'path'))).read_bytes()
                    if len(raw)>2097152:raise ValueError('Remote media derivative exceeds 2 MiB')
                    name='image_'+str(len(artifacts))+'.png'
                    artifacts.append(dict(target='media_artifact',name=name,block=len(blocks)));blocks.append(raw)
                    result=host.call('dict','replace',result,'media_artifact',host.call('dict','replace',media,'path',name))
                if expected!=self.identity(host,dataset): raise ValueError('Remote source changed during Preview preparation')
                index=len(blocks);blocks.append(text(result).encode())
                return dict(result_block=index,artifacts=artifacts),blocks
            handle = host.call('::GX::datasetAccessOpen', host.session, dataset)
            try:
                if operation == 'dataset.metadata':
                    return dict(result=host.call('::GX::datasetAccessMetadata', handle)), []
                if operation == 'dataset.range' and len(bounds) == 3:
                    ids, start, count = bounds
                    if not 0 <= int(count) <= 65536: raise ValueError('Remote range count must be bounded to 65536')
                    data = host.as_dict(host.call('::GX::datasetAccessReadRange', handle, ids, start, count))
                elif operation == 'dataset.hyperslab' and len(bounds) == 3:
                    variable, starts, counts = bounds
                    shape = [int(v) for v in host.as_list(counts)]
                    if any(v < 0 for v in shape) or math.prod(shape) > 65536: raise ValueError('Remote hyperslab exceeds 65536 elements')
                    data = {variable:host.call('::GX::datasetAccessReadHyperslab', handle, variable, starts, counts)}
                else: raise ValueError('Unsupported remote Dataset operation')
                # Metadata-only native launch guards must remain importable
                # without the optional numerical Dataset projection runtime.
                import numpy as np
                arrays = []; blobs = []
                for variable, raw in data.items():
                    item = host.as_dict(raw); values = host.as_list(item.pop('values'))
                    dtype_name=str(item['dtype'])
                    dtype = None if dtype_name in ('string','object') else np.dtype(dtype_name).newbyteorder('<')
                    if dtype is None or dtype.kind not in 'biuf':
                        # Text stays UTF-8 control data; numerical columns alone
                        # use raw typed blocks, including exact int64/uint64.
                        blob = json.dumps([str(v) for v in values], ensure_ascii=False).encode()
                        arrays.append(dict(variable_id=variable, text=True, block=len(blobs), receipt=text(host.tcl_arg(item))))
                    else:
                        missing = [i for i,v in enumerate(values) if str(v) == '']
                        if missing and dtype.kind not in 'f': raise ValueError('Missing integer values require a nullable provider contract')
                        converted = [str(v).lower() in ('1','true') if dtype.kind=='b' else ('nan' if str(v)=='' else str(v)) for v in values]
                        blob = np.asarray(converted, dtype=dtype).tobytes()
                        shape = [int(v) for v in str(item['shape']).split(';')]
                        if math.prod(shape) != len(values): raise ValueError('Remote shape/value mismatch')
                        arrays.append(dict(variable_id=variable, dtype=dtype.str, shape=shape, block=len(blobs), missing=missing, receipt=text(host.tcl_arg(item))))
                    blobs.append(blob)
                if expected != self.identity(host, dataset): raise ValueError('Dataset changed during bounded read')
                return dict(arrays=arrays, source_revision=expected), blobs
            finally: host.call('::GX::datasetAccessClose', handle)
        commands = {'scientific.prepare':('::GX::scientificExecutionPrepare', 4),
                    'job.describe':('::GX::scriptJobDescribe',1),
                    'job.inspect':('::GX::scriptJobInspect',1),
                    'job.log_read':('::GX::scriptJobLogRead',4),
                    'scientific.discard':('::GX::scientificExecutionDiscard', 1),
                    'scientific.status':('::GX::scientificExecutionStatus', 1),
                    'scientific.cancel':('::GX::scientificExecutionCancel', 1),
                    'scientific.log':('::GX::scientificExecutionLog', 4),
                    'scientific.outputs':('::GX::scientificExecutionOutputs', 1),
                    'scientific.read_output':('::GX::scientificExecutionReadOutput', 5),
                    'scientific.read_records':('::GX::scientificExecutionReadRecords', 5),
                    'scientific.import_results':('::GX::scientificExecutionImportResults', 3)}
        if operation=='scientific.freeze_output' and len(args)==5:
            status=self.native_request_client(host,args[0],client)
            if str(status['state']) not in ('COMPLETED','FAILED','CANCELLED','INTERRUPTED'):raise ValueError('Only terminal scientific output can be frozen')
            return dict(result=host.call('::GX::_scientificExecutionOutput',args[0],'freeze',*args[1:])),[]
        if operation == 'scientific.submit':
            if len(args) != 1: raise ValueError('Submit requires a prepared token')
            prepared=host.as_dict(host.call('set','::GX::ScientificExecution::prepared'))
            preparation=host.as_dict(prepared[args[0]]) if args[0] in prepared else {}
            prepared_request=host.as_dict(preparation.get('request',''))
            if 'native_owner' in prepared_request:
                owner=host.as_dict(prepared_request['native_owner'])
                if str(owner.get('remote_client_id',''))!=client or 'client_origin' not in owner:
                    raise ValueError('Native preparation belongs to another client grant or requires origin readmission')
                if 'remote_build' in owner:
                    pair = host.as_dict(owner['remote_build'])
                    if set(pair) != {'schema', 'node_id', 'client_identity', 'target_identity'} or str(pair['schema']) != 'gxtxt.native_remote_build.v1' or str(pair['node_id']) != self.config['node_id']:
                        raise ValueError('Native prepared target build pair/node changed')
                    target = host.as_dict(pair['target_identity'])
                    self.native_build_pair(host, str(target['module_id']), str(target['entrypoint']), pair['client_identity'], pair['target_identity'])
                    # Recheck the selected installed target, not a refreshed
                    # client runtime or replacement target snapshot. Ordinary
                    # scientific submit/worker still verify the original full
                    # native descriptor against actual runtime bytes as well.
                    self.native_identity(host, str(target['module_id']), str(target['entrypoint']), pair['target_identity'], build=True)
            nonce = request.get('nonce', '')
            if not nonce or len(nonce) > 128: raise ValueError('Durable submission nonce required')
            fingerprint = hashlib.sha256((session + '\0' + args[0]).encode()).hexdigest()
            prior = self.db.execute('SELECT fingerprint,state,job FROM requests WHERE client=? AND nonce=?', (client,nonce)).fetchone()
            if prior:
                if prior[0] != fingerprint: raise ValueError('Submission nonce was reused with different source identity')
                if prior[1] == 'completed': return dict(result=prior[2]), []
                raise ValueError('Submission outcome requires recovery; retry cannot create a duplicate Job')
            self.db.execute('INSERT INTO requests VALUES (?,?,?,?,?)',(client,nonce,fingerprint,'admitting','')); self.db.commit()
            result = text(host.call('::GX::scientificExecutionSubmit', args[0]))
            self.db.execute('UPDATE requests SET state=?,job=? WHERE client=? AND nonce=?',('completed',result,client,nonce));self.db.commit()
            return dict(result=result), []
        if operation not in commands or len(args) != commands[operation][1]: raise ValueError('Unregistered CORE remote operation')
        if operation=='scientific.prepare' and args[0].startswith('native.'):
            raise ValueError('Native remote provider requires pinned native.prepare artifact and client-origin admission')
        if operation.startswith(('scientific.','job.')) and operation not in ('scientific.prepare','scientific.discard'):
            job = host.as_dict(host.call('::GX::scriptJobDescribe',args[0]))
            # Grants bind both remote Session and the existing durable Job.
            if str(job['session']) != host.session: raise ValueError('Job belongs to another Session')
            if str(job.get('reference','')) in ('session:gx-core-scientific-execution','core-service:scientific-provider'):
                self.native_request_client(host,args[0],client)
        return dict(result=host.call(commands[operation][0], *args)), []

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--config',required=True);args=parser.parse_args()
    config=json.loads(Path(args.config).read_text());node=Node(config)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args): pass  # No request bodies or credentials in HTTP logs.
        def do_POST(self):
            try:
                self.connection.settimeout(15)
                if self.path != '/rpc': raise ValueError('Unknown CORE endpoint')
                length=int(self.headers.get('Content-Length','-1'))
                if not 0 < length <= MAX_BODY: raise ValueError('Invalid bounded request size')
                certificate=self.connection.getpeercert()
                client=next(v for section in certificate['subject'] for k,v in section if k=='commonName')
                if client not in config['clients']: raise ValueError('Client identity is not registered')
                request, blobs=unpack(self.rfile.read(length))
                result, blocks=node.dispatch(client,request,blobs)
                if 'result' in result and request.get('session_id'):
                    host=node.host(client,request['session_id'])
                    try:binary=host.call('dict','get',result['result'],'bytes_base64')
                    except Exception:binary=None
                    if binary is not None:
                        import base64
                        raw=base64.b64decode(str(binary),validate=True)
                        result['result']=host.call('dict','replace',result['result'],'bytes_base64','')
                        result['binary_field']='bytes_base64';result['binary_block']=len(blocks);blocks.append(raw)
                if 'result' in result: result['result']=str(node.host(client, request['session_id']).call('format','%s',result['result'])) if request.get('session_id') else json.dumps(result['result'])
                result.update(ok=True,node_id=config['node_id'])
                body=pack(result,blocks)
            except Exception as error:
                message=str(error)
                code='GX REMOTE REQUEST_FAILED'
                if 'revision changed' in message or 'source changed' in message:code='GX REMOTE STALE_SOURCE'
                elif 'integrity' in message or 'SHA/size' in message:code='GX REMOTE INTEGRITY'
                elif 'authorized' in message or 'another grant' in message or 'Client identity' in message:code='GX REMOTE DENIED'
                body=pack(dict(ok=False,node_id=config['node_id'],error=message,error_code=code))
            self.send_response(200);self.send_header('Content-Type','application/vnd.gxtxt.core-rpc');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
    class Server(HTTPServer):
        def service_actions(self):
            # Existing CORE asynchronous Job callbacks run between RPCs. Heavy
            # Preview preparation belongs to the same node-local Supervisor.
            for host in list(node.hosts.values()):
                for _ in range(8):
                    if not host.tcl.dooneevent(_tkinter.DONT_WAIT):break
            node.summary_idle()
    server=Server((config.get('bind','127.0.0.1'),int(config['port'])),Handler)
    context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.minimum_version=ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(config['server_cert'],config['server_key']);context.load_verify_locations(config['ca_file']);context.verify_mode=ssl.CERT_REQUIRED
    server.socket=context.wrap_socket(server.socket,server_side=True)
    print(json.dumps(dict(ready=True,node_id=config['node_id'],port=server.server_port)),flush=True)
    server.serve_forever(poll_interval=.05)

if __name__=='__main__':
    if len(sys.argv) == 5 and sys.argv[1] == '--native-build-metadata':
        from gxtxt_job_supervisor import tcl_result
        try:
            result = dict(ok=True, result=native_build_metadata(*sys.argv[2:]))
        except Exception as error:
            result = dict(ok=False, error=str(error))
        print(tcl_result(result))
    else:
        main()
