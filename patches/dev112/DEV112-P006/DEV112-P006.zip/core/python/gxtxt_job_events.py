"""Durable event projection inside the existing Job Supervisor and journal.

The socket is a local notification transport, never a second scheduler. Slow or
lost listeners reconnect by sequence and retained status/result, with duplicates
permitted and monotonically increasing journal sequence numbers.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import base64
import contextlib
import hashlib
import json
import math
import os
from pathlib import Path
import socket
import select
import stat
import struct
import sys
import time


SUMMARY_STATES = ('QUEUED', 'PREPARING', 'RUNNING', 'FINALIZING',
                  'COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'UNKNOWN')


def read_summary(connection, sessions=None):
    """Trusted counts-only projection of the existing journal, never Job access.

    None observes this configured journal; an explicit empty grant observes no
    Sessions. Compute Node callers must supply their admitted Session grants.
    This function creates neither schema nor a second counter. It deliberately
    returns no Job identifiers, Session paths, request or scientific payload.
    """
    if sessions is not None:
        if not isinstance(sessions, (list, tuple)) or any(
                not isinstance(item, str) or not item or '\x00' in item or
                '\n' in item or '\r' in item or not Path(item).is_absolute()
                for item in sessions):
            raise ValueError('Summary Session scope must contain admitted absolute Session identities')
        sessions = sorted(set(sessions))
    counts = dict.fromkeys(SUMMARY_STATES, 0)
    visible = dict(counts)
    revision = hashlib.sha256()
    own_transaction = not connection.in_transaction
    if own_transaction:
        connection.execute('BEGIN')
    try:
        # TEMP scope is unnecessary: consume grouped metadata rows in a single
        # read transaction without SQL-variable limits or arbitrary page caps.
        allowed = None if sessions is None else set(sessions)
        for row in connection.execute(
                "SELECT state,json_extract(record,'$.session') AS session,"
                "COALESCE(json_extract(record,'$.origin'),'user_script') AS origin,"
                "count(*) AS n FROM jobs GROUP BY state,session,origin ORDER BY state,session,origin"):
            if allowed is not None and row['session'] not in allowed:
                continue
            revision.update(json.dumps([row['state'],row['session'],row['origin'],row['n']],
                                       ensure_ascii=False,separators=(',',':')).encode('utf-8') + b'\n')
            state = row['state'] if row['state'] in counts else 'UNKNOWN'
            counts[state] += row['n']
            if row['origin'] != 'core_service':
                visible[state] += row['n']
        has_events = connection.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='job_events'").fetchone()
        sequence = 0
        if has_events:
            if allowed is None:
                sequence = connection.execute('SELECT COALESCE(MAX(sequence),0) FROM job_events').fetchone()[0]
            elif allowed:
                for event_scope in connection.execute(
                        "SELECT json_extract(j.record,'$.session') AS session,MAX(e.sequence) AS sequence "
                        "FROM job_events e JOIN jobs j ON j.id=e.job_id GROUP BY session"):
                    if event_scope['session'] in allowed:
                        sequence = max(sequence,event_scope['sequence'])
        return dict(schema='gxtxt.job_summary.v1', node_id='local', availability='AVAILABLE',
                    coverage='configured_uid_journal' if allowed is None else 'authorized_sessions',
                    complete=True, sequence=sequence, state_revision=revision.hexdigest(), counts=counts, visible_counts=visible,
                    total=sum(counts.values()), active=sum(counts[s] for s in SUMMARY_STATES[:4]),
                    queued=counts['QUEUED'], running=sum(counts[s] for s in SUMMARY_STATES[1:4]),
                    failed=counts['FAILED'], interrupted=counts['INTERRUPTED'],
                    unknown=counts['UNKNOWN'], attention=sum(counts[s] for s in ('FAILED','INTERRUPTED','UNKNOWN')))
    finally:
        if own_transaction:
            connection.execute('ROLLBACK')


def read_summary_root(root, sessions=None):
    """Read an existing journal without creating a root, database or schema."""
    import sqlite3
    unavailable = dict(schema='gxtxt.job_summary.v1', node_id='local',
                       availability='UNINITIALIZED', coverage='configured_uid_journal' if sessions is None else 'authorized_sessions',
                       complete=False, sequence=0, state_revision='', journal_identity='', counts=None, visible_counts=None,
                       total=None, active=None, queued=None, running=None, failed=None,
                       interrupted=None, unknown=None, attention=None)
    root = Path(root).absolute()
    try:
        for path in (*reversed(root.parents), root):
            if path.is_symlink():
                raise ValueError('Summary journal aliases are forbidden')
        if not root.exists():
            return unavailable
        root_info = root.stat()
        if not stat.S_ISDIR(root_info.st_mode) or root_info.st_uid != os.getuid():
            raise PermissionError('Summary journal ownership refused')
        database = root / 'jobs.sqlite'
        if not database.exists():
            return unavailable
        info = database.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
            raise PermissionError('Summary journal identity refused')
        connection = sqlite3.connect(database.as_uri() + '?mode=ro', uri=True, isolation_level=None)
        connection.row_factory = sqlite3.Row
        try:
            result = read_summary(connection, sessions)
            after = database.lstat();root_after = root.stat()
            if (after.st_dev,after.st_ino,root_after.st_dev,root_after.st_ino) != (info.st_dev,info.st_ino,root_info.st_dev,root_info.st_ino):
                raise ValueError('Summary journal changed during read')
            result['journal_identity'] = hashlib.sha256(json.dumps(
                [root_info.st_dev,root_info.st_ino,info.st_dev,info.st_ino],separators=(',',':')).encode()).hexdigest()
            return result
        finally:
            connection.close()
    except PermissionError:
        return dict(unavailable, availability='DENIED', diagnostic='Local Job metadata permission denied')
    except (OSError, ValueError, sqlite3.Error):
        return dict(unavailable, availability='UNKNOWN', diagnostic='Local Job metadata unavailable or invalid')


def schema(connection):
    connection.execute('CREATE TABLE IF NOT EXISTS job_events(sequence INTEGER PRIMARY KEY AUTOINCREMENT,job_id TEXT NOT NULL,payload TEXT NOT NULL)')
    connection.execute('CREATE INDEX IF NOT EXISTS job_events_job_sequence ON job_events(job_id,sequence)')
    connection.execute('CREATE TABLE IF NOT EXISTS job_event_heads(job_id TEXT PRIMARY KEY,signature TEXT NOT NULL)')


def read_events(connection, job_id, after_sequence=0, limit=256):
    if type(after_sequence) is not int or after_sequence < 0 or type(limit) is not int or not 1 <= limit <= 512:
        raise ValueError('Event sequence/page exceeds bound')
    if connection.execute('SELECT id FROM jobs WHERE id=?', (job_id,)).fetchone() is None:
        raise ValueError('Unknown Job ID')
    schema(connection)
    return [json.loads(row['payload']) for row in connection.execute(
        'SELECT payload FROM job_events WHERE job_id=? AND sequence>? ORDER BY sequence LIMIT ?',
        (job_id, after_sequence, limit))]


def sync_events(connection):
    schema(connection)
    for row in connection.execute('SELECT * FROM jobs').fetchall():
        record = json.loads(row['record'])
        event = dict(schema='gxtxt.job_event.v1', job_id=row['id'], node_id='local', state=row['state'],
                     terminal=row['state'] in ('COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED'),
                     source_sha256=record.get('source_sha256', ''), reference=record.get('reference', ''),
                     progress=record.get('progress', {}), diagnostic=row['error'] or '',
                     cancel_requested=bool(row['cancel']))
        event['stage'] = event['progress'].get('stage', row['state'].lower())
        if 'fraction' in event['progress']:
            try:
                fraction = float(event['progress']['fraction'])
                if math.isfinite(fraction) and 0 <= fraction <= 1:
                    event['progress'] = dict(event['progress'], fraction=fraction)
            except (ValueError, TypeError): pass
        if record.get('origin') == 'scientific_provider':
            try:
                from gxtxt_scientific_execution import decode_request
                request = decode_request(record['parameters']['request'])
                from gxtxt_scientific_execution import tdict
                event['source_identities'] = tdict(request.get('source_identities', ''))
                for field in ('native_artifact', 'workspace'):
                    if event['source_identities'].get(field): event['source_identities'][field] = tdict(event['source_identities'][field])
                event['provider_id'] = request['provider_id']
                if request.get('native_artifact'):
                    event['module_id'] = request['native_artifact'].get('module_id', '')
            except (KeyError, ValueError):
                event['source_identities'] = ''
        if event['state'] == 'COMPLETED':
            event['result_ref'] = dict(job_id=row['id'], kind='retained_job_result')
        signature = hashlib.sha256(json.dumps(event, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        previous = connection.execute('SELECT signature FROM job_event_heads WHERE job_id=?', (row['id'],)).fetchone()
        if previous is not None and previous['signature'] == signature:
            continue
        event['event'] = 'progress' if previous is not None and event['state'] == 'RUNNING' else 'state'
        event['timestamp'] = time.time()
        connection.execute('BEGIN IMMEDIATE')
        try:
            cursor = connection.execute('INSERT INTO job_events(job_id,payload) VALUES(?,?)', (row['id'], '{}'))
            event['sequence'] = cursor.lastrowid
            connection.execute('UPDATE job_events SET payload=? WHERE sequence=?', (json.dumps(event, sort_keys=True), event['sequence']))
            connection.execute('INSERT OR REPLACE INTO job_event_heads(job_id,signature) VALUES(?,?)', (row['id'], signature))
            connection.execute('COMMIT')
        except BaseException:
            connection.execute('ROLLBACK')
            raise


class EventServer:
    def __init__(self, root, connection):
        self.connection = connection
        self.listener = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.listener.bind(endpoint(root))
        self.listener.listen(32);self.listener.setblocking(False)
        self.clients = {}

    def close_client(self, client):
        self.clients.pop(client, None)
        client.close()

    def has_summary_clients(self):
        return any(state.get('route') == 'summary' for state in self.clients.values())

    def wait(self, timeout):
        """Idle owners wait for real admission/listener activity, not DB polling."""
        if any('route' not in state for state in self.clients.values()):
            timeout = min(10, timeout) if timeout is not None else 10
        readers = [self.listener, *self.clients]
        writers = [client for client, state in self.clients.items() if state['pending']]
        select.select(readers, writers, [], timeout)

    def step(self):
        while len(self.clients) < 128:
            try: client, _ = self.listener.accept()
            except BlockingIOError: break
            if struct.unpack('3i',client.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))[1] != os.getuid():
                client.close();continue
            client.setblocking(False)
            self.clients[client] = dict(request=bytearray(), pending=bytearray(), created=time.monotonic())
        summary = None
        for client, state in list(self.clients.items()):
            try:
                if 'route' not in state:
                    try: raw = client.recv(4096)
                    except BlockingIOError: raw = None
                    if raw == b'': self.close_client(client);continue
                    if raw is not None: state['request'].extend(raw)
                    if len(state['request']) > 4096 or time.monotonic() - state['created'] > 10:
                        self.close_client(client);continue
                    if b'\n' not in state['request']: continue
                    request = json.loads(state['request'].split(b'\n', 1)[0])
                    if request == {'operation': 'wake'}:
                        self.close_client(client);continue
                    if set(request) == {'operation', 'after_sequence'} and request['operation'] == 'summary_watch':
                        if type(request['after_sequence']) is not int or request['after_sequence'] < 0:
                            raise ValueError('Invalid summary cursor')
                        state.update(route='summary', signature=None)
                    elif set(request) == {'job_id', 'after_sequence'} and isinstance(request['job_id'], str):
                        read_events(self.connection, request['job_id'], request['after_sequence'], 1)
                        state.update(route='job', job_id=request['job_id'], sequence=request['after_sequence'])
                    else:
                        raise ValueError('Invalid event subscription')
                else:
                    try: disconnected = client.recv(1, socket.MSG_PEEK) == b''
                    except BlockingIOError: disconnected = False
                    if disconnected: self.close_client(client);continue
                if state['route'] == 'summary':
                    if summary is None:
                        summary = read_summary(self.connection)
                    # A new subscriber always gets an authoritative snapshot.
                    # Progress-only journal increments do not flood the GUI.
                    signature = summary['state_revision']
                    if signature != state['signature']:
                        raw = json.dumps(summary, sort_keys=True, separators=(',', ':')).encode()
                        state['pending'].extend(base64.b64encode(raw) + b'\n')
                        state['signature'] = signature
                    if len(state['pending']) > 2097152:
                        self.close_client(client);continue
                    if state['pending']:
                        try: sent = client.send(state['pending'])
                        except BlockingIOError: sent = 0
                        del state['pending'][:sent]
                    continue
                events = read_events(self.connection, state['job_id'], state['sequence'])
                for event in events:
                    raw = json.dumps(event, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
                    state['pending'].extend(base64.b64encode(raw) + b'\n')
                    state['sequence'] = event['sequence']
                    state['terminal'] = event['terminal']
                if len(state['pending']) > 2097152:
                    self.close_client(client);continue
                if state['pending']:
                    try: sent = client.send(state['pending'])
                    except BlockingIOError: sent = 0
                    del state['pending'][:sent]
                if not events and not state['pending']:
                    row = self.connection.execute('SELECT state FROM jobs WHERE id=?', (state['job_id'],)).fetchone()
                    if row['state'] in ('COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED'): state['terminal'] = True
                if state.get('terminal') and not state['pending']:
                    self.close_client(client)
            except (OSError, ValueError, TypeError, KeyError):
                self.close_client(client)

    def close(self):
        for client in list(self.clients): self.close_client(client)
        self.listener.close()


def endpoint(root):
    # Linux abstract sockets avoid the 108-byte pathname limit in long isolated
    # task roots. Both ends verify kernel-reported same-account credentials.
    return b'\x00gxtxt-job-events-' + hashlib.sha256(str(root.resolve()).encode()).hexdigest().encode()


def wake(root):
    """Wake the existing owner after a committed admission; no new daemon."""
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.settimeout(.2)
        try:
            client.connect(endpoint(root))
            if struct.unpack('3i', client.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))[1] != os.getuid():
                raise RuntimeError('Supervisor event peer is not owned by this account')
            client.sendall(b'{"operation":"wake"}\n')
        except (FileNotFoundError, ConnectionRefusedError, TimeoutError):
            # A daemon holding its lock may still be starting; its first pass
            # reads the already committed row. Existing recovery remains owner.
            pass


def watch_summary(root, after_sequence=0):
    """Trusted host monitor of the existing configured journal, not a Job grant."""
    if type(after_sequence) is not int or after_sequence < 0:
        raise ValueError('Invalid summary cursor')
    from gxtxt_job_supervisor import connect, ensure
    # Explicit trusted subscription initializes the existing journal if needed,
    # enabling an authoritative zero snapshot without creating a scientific Job.
    connection = connect(root)
    connection.close();ensure(root)
    _watch_pipe(root, dict(operation='summary_watch', after_sequence=after_sequence))


def _watch_pipe(root, request):
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    for attempt in range(100):
        try: client.connect(endpoint(root));break
        except (FileNotFoundError, ConnectionRefusedError): time.sleep(.05)
    else: raise RuntimeError('Supervisor event transport unavailable; reconnect with retained sequence')
    if struct.unpack('3i',client.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))[1] != os.getuid():
        client.close();raise RuntimeError('Supervisor event peer is not owned by this account')
    try:
        client.sendall(json.dumps(request).encode() + b'\n')
        while True:
            ready, _, _ = select.select([client, sys.stdin.buffer], [], [])
            if sys.stdin.buffer in ready and not os.read(sys.stdin.fileno(), 4096):
                break
            if client in ready:
                chunk = client.recv(65536)
                if not chunk: break
                try: sys.stdout.buffer.write(chunk);sys.stdout.buffer.flush()
                except BrokenPipeError: break
    finally: client.close()


def watch(root, job_id, after_sequence=0):
    from gxtxt_job_supervisor import connect, ensure
    connection = connect(root)
    read_events(connection, job_id, after_sequence, 1)
    connection.close();ensure(root)
    client = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    for attempt in range(100):
        try: client.connect(endpoint(root));break
        except (FileNotFoundError, ConnectionRefusedError): time.sleep(.05)
    else: raise RuntimeError('Supervisor event transport unavailable; reconnect with retained sequence')
    if struct.unpack('3i',client.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))[1] != os.getuid():
        client.close();raise RuntimeError('Supervisor event peer is not owned by this account')
    try:
        client.sendall(json.dumps(dict(job_id=job_id, after_sequence=after_sequence)).encode() + b'\n')
        while True:
            ready, _, _ = select.select([client, sys.stdin.buffer], [], [])
            if sys.stdin.buffer in ready:
                # Closing the GUI's duplex subscription pipe retires only this
                # listener, even while its durable Job is running silently.
                if not os.read(sys.stdin.fileno(), 4096): break
            if client in ready:
                chunk = client.recv(65536)
                if not chunk: break
                try: sys.stdout.buffer.write(chunk);sys.stdout.buffer.flush()
                except BrokenPipeError: break
    finally: client.close()
