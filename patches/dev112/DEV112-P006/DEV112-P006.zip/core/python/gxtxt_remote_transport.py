"""Authenticated bounded CORE RPC framing; no scientific dispatch or scheduler."""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import hashlib
import base64
import http.client
import json
import os
from pathlib import Path
import ssl
import struct
import sys
import tkinter
from urllib.parse import urlsplit

MAX_BODY = 32 * 1024 * 1024
MAX_CONTROL = 2 * 1024 * 1024
class RemoteOperationError(ValueError):
    def __init__(self,message,code='GX REMOTE REQUEST_FAILED'):
        super().__init__(message);self.code=code

class RemoteTransportError(RemoteOperationError):
    """Actual connection I/O, distinct from an authenticated protocol error."""
    def __init__(self, message):
        super().__init__(message, 'GX REMOTE UNAVAILABLE')

def pack(control, blobs=()):
    data = dict(control)
    data['blocks'] = [dict(size=len(b), sha256=hashlib.sha256(b).hexdigest()) for b in blobs]
    header = json.dumps(data, ensure_ascii=False, allow_nan=False, separators=(',', ':')).encode()
    result = struct.pack('!I', len(header)) + header + b''.join(blobs)
    if len(header) > MAX_CONTROL or len(result) > MAX_BODY:
        raise ValueError('CORE remote message exceeds bounded transport limits')
    return result

def unpack(body):
    if not 4 <= len(body) <= MAX_BODY:
        raise ValueError('Invalid CORE remote message size')
    size = struct.unpack('!I', body[:4])[0]
    if not 0 < size <= MAX_CONTROL or size + 4 > len(body):
        raise ValueError('Invalid CORE remote control frame')
    control = json.loads(body[4:4+size]); offset = size + 4; blobs = []
    for block in control.pop('blocks', []):
        length = block['size']
        if not isinstance(length, int) or length < 0 or offset + length > len(body):
            raise ValueError('Invalid CORE remote binary block')
        raw = body[offset:offset+length]; offset += length
        if hashlib.sha256(raw).hexdigest() != block['sha256']:
            raise ValueError('CORE remote block integrity failure')
        blobs.append(raw)
    if offset != len(body):
        raise ValueError('Unexpected trailing remote data')
    return control, blobs

def exchange(node, request, blobs=()):
    url = urlsplit(node['endpoint'])
    if url.scheme != 'https' or not url.hostname or url.username or url.password or url.query or url.fragment:
        raise ValueError('Compute node requires an explicit HTTPS endpoint')
    key = Path(node['client_key'])
    if os.name == 'posix' and key.stat().st_mode & 0o077:
        raise ValueError('Compute client key must be private to its owner')
    context = ssl.create_default_context(cafile=node['ca_file'])
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(node['client_cert'], key)
    connection = http.client.HTTPSConnection(url.hostname, url.port or 443, context=context, timeout=8)
    body = pack(request, blobs)
    try:
        connection.request('POST', (url.path or '/rpc'), body, {'Content-Type': 'application/vnd.gxtxt.core-rpc'})
        response = connection.getresponse()
        length = int(response.getheader('Content-Length', '-1'))
        if response.status != 200 or not 0 < length <= MAX_BODY:
            raise ValueError('Compute node refused the bounded authenticated request')
        data = response.read(length + 1)
        if len(data) != length:
            raise RemoteTransportError('Incomplete CORE remote response')
        result, blocks = unpack(data)
        if result.get('node_id') != node['node_id']:
            raise RemoteOperationError('Compute node identity disagrees with configured identity','GX REMOTE AUTHENTICATION')
        if not result.get('ok'):
            raise RemoteOperationError(result.get('error', 'Remote operation failed'),result.get('error_code','GX REMOTE REQUEST_FAILED'))
        return result, blocks, dict(sent_bytes=len(body), received_bytes=len(data))
    except (OSError, EOFError, http.client.HTTPException) as error:
        raise RemoteTransportError(str(error)) from None
    finally:
        connection.close()

def tcl_dict(tcl, value):
    parts = tcl.splitlist(value)
    if len(parts) % 2: raise ValueError('Expected a CORE dictionary')
    return dict(zip(parts[::2], parts[1::2]))

def tcl_value(tcl, value):
    if isinstance(value, dict):
        return tcl.call('dict', 'create', *[v for k, item in value.items() for v in (k, tcl_value(tcl, item))])
    if isinstance(value, (list, tuple)): return tuple(tcl_value(tcl, v) for v in value)
    if isinstance(value, bool): return int(value)
    if value is None: return ''
    return value

def session_fingerprint(session):
    """Opaque cold-stable projection of the existing Session scope identity.

    InteractiveDocument already identifies a Session by normalized directory,
    device and inode. Hash that projection without exporting the host path or
    writing any new Session identity/registry. A replaced/copied directory is
    deliberately a new admission context, even with identical legacy origin.
    """
    raw = Path(session).absolute()
    if any(component.is_symlink() for component in (raw, *raw.parents)):
        raise ValueError('Native Session identity forbids symlink aliases or ancestors')
    path = raw.resolve(strict=True)
    if not path.is_dir():
        raise ValueError('Native remote origin requires a Session directory')
    info = path.stat()
    projection = [str(path), info.st_dev, info.st_ino]
    return hashlib.sha256(json.dumps(projection, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()

def event_stream(node, request):
    """Adapt bounded authenticated journal waits to local push event lines.

    GUI callers attach a fileevent to this process, not a periodic status loop.
    The node waits on the existing Supervisor event socket between event pages.
    """
    arguments = request.get('arguments', [])
    if len(arguments) != 4 or any(not isinstance(v, str) for v in arguments):
        raise ValueError('Invalid remote event subscription arguments')
    job_id, sequence, limit, wait_ms = arguments
    if not sequence.isdecimal() or not limit.isdecimal() or not wait_ms.isdecimal():
        raise ValueError('Invalid remote event subscription cursor')
    cursor = int(sequence)
    if cursor < 0 or not 1 <= int(limit) <= 128 or not 1 <= int(wait_ms) <= 1000:
        raise ValueError('Remote event subscription exceeds bounds')
    while True:
        current = dict(request, operation='scientific.events', arguments=[job_id, str(cursor), limit, wait_ms])
        response, blocks, _ = exchange(node, current)
        page = response.get('event_page')
        if blocks or not isinstance(page, dict) or page.get('schema') != 'gxtxt.remote_job_events.v1' or page.get('job_id') != job_id or page.get('node_id') != node['node_id'] or type(page.get('terminal')) is not bool:
            raise ValueError('Remote event page identity mismatch')
        events = page.get('events')
        if not isinstance(events, list) or len(events) > int(limit):
            raise ValueError('Remote event page exceeds subscription bound')
        for event in events:
            if not isinstance(event, dict) or event.get('schema') != 'gxtxt.job_event.v1' or event.get('job_id') != job_id or event.get('node_id') != node['node_id'] or type(event.get('sequence')) is not int or event['sequence'] <= cursor or type(event.get('terminal')) is not bool:
                raise ValueError('Remote event sequence/owner mismatch')
            raw = json.dumps(event, separators=(',', ':'), ensure_ascii=False).encode()
            if len(raw) > 1048576:
                raise ValueError('Remote event exceeds stream control bound')
            sys.stdout.buffer.write(base64.b64encode(raw) + b'\n');sys.stdout.buffer.flush()
            cursor = event['sequence']
        if type(page.get('after_sequence')) is not int or page['after_sequence'] != cursor:
            raise ValueError('Remote event cursor disagrees with page')
        if page.get('terminal'):
            return

def summary_stream(node, request):
    """Trusted counts-only notification adapter, separate from Job events.

    The Node filters its existing journal by the authenticated client's current
    Session grants. No caller Job IDs, Session paths or execution verbs exist.
    """
    import math
    arguments = request.get('arguments', [])
    if len(arguments) != 3 or any(not isinstance(v, str) for v in arguments):
        raise ValueError('Invalid operational summary subscription arguments')
    sequence, revision, wait = arguments
    digest = lambda value: isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)
    if not sequence.isdecimal() or not wait.isdecimal() or not 1 <= int(wait) <= 1000 or (revision and not digest(revision)) or request.get('session_id', ''):
        raise ValueError('Invalid operational summary cursor/scope/wait')
    cursor = int(sequence); scope = None
    # One existing admitted Session capability request distinguishes an older
    # installed protocol from grant denial. It grants no global Script access.
    capability, blocks, _ = exchange(node, dict(operation='capabilities', session_id=node['session_id'], arguments=[]))
    tcl = tkinter.Tcl()
    try:
        metadata = tcl_dict(tcl, capability.get('result', ''))
        support = tcl_dict(tcl, metadata.get('job_summary', ''))
        supported = support.get('protocol') == '1' and support.get('schema') == 'gxtxt.job_summary.v1' and support.get('scope') == 'granted_node_sessions'
    except (ValueError, tkinter.TclError):
        supported = False
    if blocks or not supported:
        raise RemoteOperationError('Installed Compute Node does not advertise operational summary protocol', 'GX REMOTE UNSUPPORTED')
    states = {'QUEUED', 'PREPARING', 'RUNNING', 'FINALIZING', 'COMPLETED', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'UNKNOWN'}
    fields = {'schema', 'node_id', 'availability', 'coverage', 'complete', 'sequence', 'state_revision', 'journal_identity', 'counts', 'visible_counts', 'total', 'active', 'queued', 'running', 'failed', 'interrupted', 'unknown', 'attention', 'scope_key', 'revision', 'changed', 'observed_at', 'notification_available'}
    while True:
        response, blocks, _ = exchange(node, dict(request, operation='jobs.summary_events', arguments=[str(cursor), revision, wait]))
        page = response.get('summary_page')
        if blocks or not isinstance(page, dict) or page.get('schema') != 'gxtxt.job_summary.v1' or page.get('node_id') != node['node_id'] or type(page.get('sequence')) is not int or page['sequence'] < 0 or not digest(page.get('scope_key')) or not digest(page.get('revision')) or type(page.get('complete')) is not bool or type(page.get('changed')) is not bool:
            raise ValueError('Operational summary route/sequence identity mismatch')
        if not fields <= set(page) or set(page) - fields - {'diagnostic'} or type(page['notification_available']) is not bool:
            raise ValueError('Operational summary contains unexpected metadata')
        if type(page['observed_at']) not in (int, float) or not math.isfinite(page['observed_at']) or page['observed_at'] < 0:
            raise ValueError('Operational summary observation time is invalid')
        if scope == page['scope_key'] and page['sequence'] < cursor:
            raise ValueError('Operational summary cursor regressed within its journal scope')
        availability = page.get('availability')
        if availability not in ('AVAILABLE', 'UNINITIALIZED', 'INITIALIZING', 'DENIED', 'UNKNOWN') or page.get('coverage') != 'granted_node_sessions':
            raise ValueError('Invalid operational summary availability/coverage')
        if availability == 'AVAILABLE':
            if not page['complete'] or not digest(page.get('journal_identity')) or not digest(page.get('state_revision')):
                raise ValueError('Operational summary lacks authoritative journal identity')
            for field in ('counts', 'visible_counts'):
                values = page.get(field)
                if not isinstance(values, dict) or set(values) != states or any(type(n) is not int or n < 0 for n in values.values()):
                    raise ValueError('Invalid operational summary closed state counts')
            counts = page['counts']
            if not page['notification_available'] or any(page['visible_counts'][s] > counts[s] for s in states):
                raise ValueError('Operational summary visibility/notification coverage is invalid')
            expected = dict(total=sum(counts.values()), queued=counts['QUEUED'], running=sum(counts[s] for s in ('PREPARING', 'RUNNING', 'FINALIZING')), failed=counts['FAILED'], interrupted=counts['INTERRUPTED'], unknown=counts['UNKNOWN'])
            expected['active'] = expected['running'] + expected['queued']
            expected['attention'] = expected['failed'] + expected['interrupted'] + expected['unknown']
            if any(type(page.get(k)) is not int or page[k] != v for k, v in expected.items()):
                raise ValueError('Operational summary aggregate disagrees with state counts')
        elif page['complete'] or any(page.get(k) is not None for k in ('counts', 'visible_counts', 'total', 'active', 'running', 'queued', 'failed', 'interrupted', 'unknown', 'attention')):
            raise ValueError('Unavailable operational summary cannot fabricate zero counts')
        if page['changed'] != (revision != page['revision']):
            raise ValueError('Operational summary revision disagrees with changed marker')
        if page['changed']:
            raw = json.dumps(page, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()
            if len(raw) > 16384:
                raise ValueError('Operational summary exceeds metadata frame bound')
            sys.stdout.buffer.write(base64.b64encode(raw) + b'\n'); sys.stdout.buffer.flush()
        scope = page['scope_key']; cursor = page['sequence']; revision = page['revision']

def main():
    tcl = tkinter.Tcl()
    try:
        request = tcl_dict(tcl, sys.stdin.read(MAX_CONTROL + 1))
        if sys.argv[1:] == ['--session-identity']:
            if set(request) != {'session'}:
                raise ValueError('Session identity helper accepts one host Session directory')
            print(tcl.call('format', '%s', tcl_value(tcl, dict(ok=1, result=session_fingerprint(request['session'])))))
            return
        node = tcl_dict(tcl, request.pop('node'))
        artifact_directory=request.pop('artifact_directory',None)
        request['arguments'] = list(tcl.splitlist(request.get('arguments', '')))
        if len(sys.argv) > 1 and sys.argv[1] == 'events':
            try:
                event_stream(node, request)
            except Exception as error:
                # Transport loss is recoverable and is never a fabricated
                # terminal Job failure. Retained Job ID/cursor remain valid.
                event = dict(schema='gxtxt.job_transport_error.v1', event='transport_error',
                             job_id=request['arguments'][0] if request['arguments'] else '',
                             node_id=node.get('node_id', ''), diagnostic=str(error), terminal=False)
                sys.stdout.buffer.write(base64.b64encode(json.dumps(event).encode()) + b'\n');sys.stdout.buffer.flush()
            return
        if sys.argv[1:] == ['summary-events']:
            try:
                summary_stream(node, request)
            except Exception as error:
                code = error.code if isinstance(error, RemoteOperationError) else 'GX REMOTE PROTOCOL'
                availability = 'UNAVAILABLE' if isinstance(error, RemoteTransportError) else 'DENIED' if code == 'GX REMOTE DENIED' else 'UNSUPPORTED' if code == 'GX REMOTE UNSUPPORTED' else 'UNKNOWN'
                # No fabricated Job state, terminal flag or lifecycle cursor.
                frame = dict(schema='gxtxt.job_summary_transport_error.v1', node_id=node.get('node_id', ''),
                             availability=availability, error_code=code,
                             diagnostic='Operational summary transport unavailable' if availability == 'UNAVAILABLE' else 'Operational summary metadata unavailable or invalid')
                sys.stdout.buffer.write(base64.b64encode(json.dumps(frame).encode()) + b'\n'); sys.stdout.buffer.flush()
            return
        input_blocks = []
        if 'payload_base64' in request:
            input_blocks.append(base64.b64decode(request.pop('payload_base64'), validate=True))
        result, blocks, metrics = exchange(node, request, input_blocks)
        if result.get('pending'):
            import time
            deadline=time.monotonic()+240
            while result.get('pending'):
                if time.monotonic()>deadline:raise RemoteOperationError('Remote Preview preparation timed out','GX REMOTE TIMEOUT')
                time.sleep(.2)
                result,blocks,measured=exchange(node,request,input_blocks)
                for key,value in measured.items():metrics[key]+=value
        if 'result_block' in result:
            result['result'] = blocks[result['result_block']].decode('utf-8')
            if result.get('artifacts'):
                import re
                if not artifact_directory: raise ValueError('No authorized local Preview artifact destination')
                directory=Path(artifact_directory)
                if not directory.is_dir() or any(p.is_symlink() for p in (directory,*directory.parents)):
                    raise ValueError('Unsafe local Preview artifact directory')
                for artifact in result['artifacts']:
                    name=artifact['name']
                    if not re.fullmatch(r'image_[0-9]+\.png',name): raise ValueError('Invalid derived image filename')
                    path=directory/name;raw=blocks[artifact['block']]
                    if path.is_symlink() or len(raw)>2097152: raise ValueError('Unsafe or oversized derived image')
                    temporary=path.with_suffix('.pending')
                    with temporary.open('xb') as stream:stream.write(raw)
                    temporary.replace(path)
                    if artifact.get('target')=='media_artifact':
                        media=tcl.call('dict','get',result['result'],'media_artifact')
                        result['result']=tcl.call('format','%s',tcl.call('dict','replace',result['result'],'media_artifact',tcl.call('dict','replace',media,'path',str(path))))
                        continue
                    parsed=result['result'];digitizer=tcl.call('dict','get',parsed,'digitizer')
                    images=tcl.call('dict','get',digitizer,'images');info=tcl.call('dict','get',images,artifact['image_id'])
                    info=tcl.call('dict','replace',info,'path',str(path))
                    images=tcl.call('dict','replace',images,artifact['image_id'],info)
                    digitizer=tcl.call('dict','replace',digitizer,'images',images)
                    result['result']=tcl.call('format','%s',tcl.call('dict','replace',parsed,'digitizer',digitizer))
        if 'binary_field' in result:
            result['result']=tcl.call('format','%s',tcl.call('dict','replace',result['result'],result['binary_field'],base64.b64encode(blocks[result['binary_block']]).decode()))
        if 'arrays' in result:
            import numpy as np
            items = {}
            for array in result['arrays']:
                raw = blocks[array['block']]
                if array.get('text'):
                    item = tcl_dict(tcl, array['receipt']);item['values'] = json.loads(raw)
                    items[array['variable_id']] = item
                    continue
                dtype = np.dtype(array['dtype'])
                shape = array['shape']
                if dtype.kind not in 'biuf' or dtype.itemsize * __import__('math').prod(shape) != len(raw):
                    raise ValueError('Invalid typed remote Dataset array')
                values = np.frombuffer(raw, dtype=dtype)
                strings = [str(int(v)) if dtype.kind in 'biu' else repr(float(v)) for v in values]
                for index in array.get('missing', []): strings[index] = ''
                item = tcl_dict(tcl, array['receipt'])
                item['values'] = strings
                item['binary_block'] = dict(__gxtxt_binary_block=1, dtype=dtype.name, endian='little', shape=';'.join(str(v) for v in shape), byte_count=len(raw), base64=base64.b64encode(raw).decode())
                items[array['variable_id']] = item
            result['result'] = tcl_value(tcl, items)
        output = tcl_value(tcl, dict(ok=1, result=result.get('summary_page', result.get('event_page', result.get('result', ''))), metrics=metrics))
    except RemoteOperationError as error:
        output = tcl_value(tcl, dict(ok=0,error=str(error),error_code=error.code))
    except (OSError, ValueError, ssl.SSLError, http.client.HTTPException) as error:
        output = tcl_value(tcl, dict(ok=0, error=str(error), error_code='GX REMOTE UNAVAILABLE'))
    print(tcl.call('format', '%s', output))

if __name__ == '__main__': main()
