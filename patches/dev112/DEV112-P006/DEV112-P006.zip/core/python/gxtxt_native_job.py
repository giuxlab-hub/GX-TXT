"""Installed native scientific task adapter; the existing Supervisor owns jobs.

This cooperating-code boundary admits an installed, hashed ELF artifact. It is
not an OS sandbox and does not grant arbitrary paths to Viewer frontend code.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import base64
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import stat
import struct
import subprocess
import sys

MAX_CONTROL = 1048576


def descriptor_from_tcl(raw):
    from gxtxt_scientific_execution import tdict
    result = tdict(raw)
    result['abi'] = tdict(result['abi'])
    for key in ('protocol', 'pointer_bits', 'cpp_standard'):
        result['abi'][key] = int(result['abi'][key])
    if 'buffer_descriptor_version' in result['abi']: result['abi']['buffer_descriptor_version'] = int(result['abi']['buffer_descriptor_version'])
    for key in ('dependencies', 'sources', 'runtime_dependencies'):
        if key in result:
            result[key] = tdict(result[key])
    result['parameters'] = {k: tdict(v) for k, v in tdict(result['parameters']).items()}
    return result


def buffer_descriptors_from_tcl(raw):
    from gxtxt_scientific_execution import tdict
    import tkinter
    t = tkinter.Tcl();result = {}
    for alias, encoded in tdict(raw).items():
        descriptor = tdict(encoded)
        for key in ('version', 'count', 'byte_count'): descriptor[key] = int(descriptor[key])
        descriptor['shape'] = [int(v) for v in t.splitlist(descriptor['shape'])]
        validate_descriptor_metadata(descriptor)
        result[alias] = descriptor
    return result


def validate_descriptor_metadata(descriptor):
    from gxtxt_scientific_binary_v1 import DTYPES, shape_checked
    import numpy as np
    if descriptor.get('version') != 2 or descriptor.get('order') != 'F' or descriptor.get('endian') != 'little' or descriptor.get('dtype') not in DTYPES:
        raise ValueError('Native managed input requires original descriptor v2 dtype/order/endian')
    count = shape_checked(descriptor.get('shape'), np.dtype(DTYPES[descriptor['dtype']]).itemsize)
    if descriptor.get('count') != count or descriptor.get('byte_count') != count * np.dtype(DTYPES[descriptor['dtype']]).itemsize:
        raise ValueError('Native binary descriptor count/shape/byte_count mismatch')
    if not re.fullmatch(r'[a-f0-9]{32}\.bin', str(descriptor.get('resource_id', ''))):
        raise ValueError('Invalid native binary descriptor resource identity')


def owned_buffer(root, descriptor):
    from gxtxt_scientific_binary_v1 import open_buffer
    root = Path(root)
    if any(part.is_symlink() for part in (root, *root.parents)):
        raise ValueError('Native buffer scope has a symlink ancestor')
    fd, dtype, count = open_buffer(root, descriptor)
    if os.fstat(fd).st_nlink != 1:
        os.close(fd);raise ValueError('Native buffer must have one owned link')
    return fd, dtype, count


def native_runtime_dependencies(artifact, bundled_dependencies=None):
    """Pathless SHA inventory of actual ELF dependencies and program loader.

    ELF metadata is read, never executed (in particular this does not use ldd).
    The authenticated remote owner compares the same inventory before launch.
    """
    artifact = Path(artifact).resolve()
    bundled_dependencies = bundled_dependencies or {}
    readelf = shutil.which('readelf')
    ldconfig = shutil.which('ldconfig') or '/sbin/ldconfig'
    if not readelf or not Path(ldconfig).is_file():
        raise ValueError('Native runtime dependency inspection requires readelf and ldconfig')
    cache = subprocess.run([ldconfig, '-p'], check=True, capture_output=True, text=True, timeout=5).stdout
    candidates = {}
    for line in cache.splitlines():
        match = re.match(r'\s*(\S+)\s+\([^)]*\)\s+=>\s+(\S+)\s*$', line)
        if match: candidates.setdefault(match[1], []).append(Path(match[2]))
    expected_machine = {'x86_64': 62, 'aarch64': 183}.get(platform.machine())
    def compatible(path):
        try:
            with path.open('rb') as stream: header = stream.read(20)
            return len(header) == 20 and header[:4] == b'\x7fELF' and header[5] == 1 and int.from_bytes(header[18:20], 'little') == expected_machine
        except OSError: return False
    queue = [artifact];seen = set();result = {}
    while queue:
        binary = queue.pop()
        if str(binary) in seen: continue
        seen.add(str(binary))
        metadata = subprocess.run([readelf, '-d', '-l', str(binary)], check=True, capture_output=True, text=True, timeout=5).stdout
        if len(metadata) > MAX_CONTROL: raise ValueError('ELF dependency metadata exceeds bound')
        needed = re.findall(r'\(NEEDED\).*?\[([^\]]+)\]', metadata)
        loader = re.search(r'Requesting program interpreter:\s*([^\]]+)\]', metadata)
        if loader:
            path = Path(loader[1])
            if not compatible(path): raise ValueError('Native program loader CPU ABI unavailable')
            result[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
        for name in needed:
            if '/' in name: raise ValueError('Native dependency must use an admitted soname')
            if name in bundled_dependencies:
                path = Path(bundled_dependencies[name])
                if not compatible(path): raise ValueError('Bundled native dependency CPU ABI mismatch')
            else:
                path = next((p for p in candidates.get(name, []) if compatible(p)), None)
                if path is None: raise ValueError('Native runtime dependency unavailable: ' + name)
                value = hashlib.sha256(path.read_bytes()).hexdigest()
                if name in result and result[name] != value: raise ValueError('Conflicting native dependency identity')
                result[name] = value
            queue.append(path)
        if len(seen) > 128: raise ValueError('Native runtime dependency closure exceeds bound')
    return dict(sorted(result.items()))


def safe_file(root, relative):
    from gxtxt_scientific_execution import safe_file as owned_file
    path = owned_file(root, relative)
    info = path.stat()
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('Native artifact dependencies must be regular files')
    return path


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('Duplicate native control field')
            result[key] = value
        return result
    def invalid(value):
        raise ValueError('Nonfinite native control value')
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def file_sha256(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):value.update(chunk)
    return value.hexdigest()


def verify_artifact(root, descriptor):
    root = Path(root).resolve()
    required = {'schema', 'artifact', 'artifact_sha256', 'source_sha256', 'abi', 'dependencies', 'runtime_dependencies', 'sources', 'parameters'}
    if not isinstance(descriptor, dict) or not required <= set(descriptor) or descriptor['schema'] != 'gxtxt.native_job_artifact.v1':
        raise ValueError('Invalid installed native artifact descriptor')
    abi = descriptor['abi']
    expected = dict(protocol=1, platform=sys.platform, machine=platform.machine(), pointer_bits=struct.calcsize('P') * 8, cpp_standard=17)
    if not isinstance(abi, dict) or any(abi.get(k) != v for k, v in expected.items()):
        raise ValueError('Native artifact ABI/platform mismatch')
    for field in ('artifact_sha256', 'source_sha256'):
        value = descriptor[field]
        if not isinstance(value, str) or len(value) != 64 or any(c not in '0123456789abcdef' for c in value):
            raise ValueError('Native artifact requires exact source and binary SHA256')
    artifact = safe_file(root, descriptor['artifact'])
    if not artifact.stat().st_mode & stat.S_IXUSR or hashlib.sha256(artifact.read_bytes()).hexdigest() != descriptor['artifact_sha256']:
        raise ValueError('Native artifact is not executable or its SHA256 changed')
    with artifact.open('rb') as stream:
        header = stream.read(20)
    machine = {'x86_64': 62, 'aarch64': 183}.get(platform.machine())
    if len(header) != 20 or header[:4] != b'\x7fELF' or header[4] != (2 if expected['pointer_bits'] == 64 else 1) or header[5] != 1 or machine is None or int.from_bytes(header[18:20], 'little') != machine:
        raise ValueError('Native executable CPU/ELF ABI mismatch')
    dependencies = descriptor['dependencies']
    if not isinstance(dependencies, dict) or len(dependencies) > 128:
        raise ValueError('Native dependency inventory exceeds bounds')
    for relative, expected_sha in dependencies.items():
        dependency = safe_file(root, relative)
        if hashlib.sha256(dependency.read_bytes()).hexdigest() != expected_sha:
            raise ValueError('Native artifact dependency SHA256 changed')
    bundled = {Path(relative).name: safe_file(root, relative) for relative in dependencies}
    if len(bundled) != len(dependencies): raise ValueError('Ambiguous bundled dependency soname')
    if descriptor['runtime_dependencies'] != native_runtime_dependencies(artifact, bundled):
        raise ValueError('Native system runtime dependency SHA256/ABI changed')
    # Source inventory is optional for old descriptor readers, mandatory for
    # installed P006 projects: when present its canonical hash binds all units.
    sources = descriptor.get('sources')
    if sources is not None:
        if not isinstance(sources, dict) or not sources or len(sources) > 256:
            raise ValueError('Invalid native source inventory')
        for relative, expected_sha in sources.items():
            if hashlib.sha256(safe_file(root, relative).read_bytes()).hexdigest() != expected_sha:
                raise ValueError('Native project source SHA256 changed')
        actual = hashlib.sha256(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        if actual != descriptor['source_sha256']:
            raise ValueError('Native source inventory identity mismatch')
    return dict(descriptor, module_root=str(root))


def input_protocol(context):
    lines = ['gxtxt.native_job_request.v1', str(len(context.parameters))]
    for name, value in context.parameters.items():
        if isinstance(value, bool): kind, text = 'boolean', str(int(value))
        elif isinstance(value, int): kind, text = 'integer', str(value)
        elif isinstance(value, float): kind, text = 'number', repr(value)
        elif isinstance(value, str): kind, text = 'string', value
        else: raise ValueError('Native parameters must satisfy the registered scalar schema')
        lines.append(name + '\t' + kind + '\t' + base64.b64encode(text.encode()).decode())
    descriptors = getattr(context, 'native_buffers', {})
    lines.append(str(len(descriptors)))
    for alias, descriptor in descriptors.items():
        unit = getattr(context, 'native_buffer_units', {}).get(alias, '')
        fields = [alias, descriptor['dtype'], descriptor['endian'], descriptor['order'],
                  ','.join(map(str, descriptor['shape'])), str(descriptor['count']), str(descriptor['byte_count']),
                  descriptor['resource_id'], base64.b64encode(unit.encode()).decode() or '=']
        lines.append('\t'.join(fields))
    data = ('\n'.join(lines) + '\n').encode()
    if len(data) > MAX_CONTROL:
        raise ValueError('Native request exceeds control transport bound; use managed resources')
    return data


def _remote_build_launch_guard(request):
    """Recheck an admitted paired target at copy/launch; never reselect it."""
    from gxtxt_scientific_execution import tdict, tvalue
    owner = tdict(request.get('native_owner', ''))
    if 'remote_build' not in owner:
        return
    pair = tdict(owner['remote_build'])
    if set(pair) != {'schema', 'node_id', 'client_identity', 'target_identity'} or pair['schema'] != 'gxtxt.native_remote_build.v1':
        raise ValueError('Native paired build receipt is invalid before execution')
    target = tdict(pair['target_identity'])
    fields = {'module_id', 'entrypoint', 'artifact_sha256', 'source_sha256', 'abi', 'dependencies', 'runtime_dependencies', 'project_source_sha256', 'build_contract_sha256'}
    if set(target) != fields:
        raise ValueError('Native paired target identity is incomplete before execution')
    module, entrypoint = owner.get('module_id', ''), owner.get('entrypoint', '')
    if target['module_id'] != module or target['entrypoint'] != entrypoint or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', entrypoint):
        raise ValueError('Native paired target owner changed before execution')
    retained = request['native_artifact']
    # Preserve raw spelling: resolve() would erase a replaced alias ancestor.
    original = retained['module_root']
    from gxtxt_compute_node import native_build_metadata
    metadata = native_build_metadata(original, module, entrypoint)
    with safe_file(Path(original), 'native/jobs/' + entrypoint + '.json').open('rb') as stream:
        raw = stream.read(MAX_CONTROL + 1)
    if len(raw) > MAX_CONTROL:
        raise ValueError('Native installed descriptor exceeds control bound')
    current = verify_artifact(original, strict_json(raw))
    current.update(module_id=module, entrypoint=entrypoint,
                   project_source_sha256=metadata['project_source_sha256'],
                   build_contract_sha256=metadata['build_contract_sha256'])
    def identity(value, field):
        item = value[field]
        if field in ('abi', 'dependencies', 'runtime_dependencies'):
            return tdict(tvalue(item)) if isinstance(item, dict) else tdict(item)
        return str(item)
    for field in fields:
        if identity(current, field) != identity(target, field):
            raise ValueError('Native paired target ' + field + ' changed before execution')
        if field not in ('project_source_sha256', 'build_contract_sha256') and identity(retained, field) != identity(target, field):
            raise ValueError('Native retained target ' + field + ' differs from its admitted pair')
    def parameters(value):
        return {name: tdict(tvalue(schema)) for name, schema in value.items()}
    if parameters(current['parameters']) != parameters(retained['parameters']) or parameters(metadata['parameters']) != parameters(retained['parameters']):
        raise ValueError('Native paired target parameter schema changed before execution')


def run(context):
    _remote_build_launch_guard(context.request)
    artifact = verify_artifact(context.request['native_artifact']['module_root'], context.request['native_artifact'])
    original = Path(artifact['module_root'])
    snapshot = context.scratch / 'native-project'
    snapshot.mkdir(mode=0o700)
    for relative in {artifact['artifact'], *artifact['dependencies'], *artifact['sources']}:
        target = snapshot / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(safe_file(original, relative), target)
    artifact = verify_artifact(snapshot, artifact)
    executable = safe_file(snapshot, artifact['artifact'])
    import gxtxt
    from gxtxt_remote_transport import session_fingerprint
    from gxtxt_scientific_execution import tdict
    native_owner = tdict(context.request.get('native_owner', ''))
    if native_owner.get('session_fingerprint') != session_fingerprint(Path.cwd()):
        raise ValueError('Native task Session incarnation changed before worker execution')
    descriptors = context.request.get('native_input_descriptors') or {}
    if descriptors and artifact['abi'].get('buffer_descriptor_version') != 2:
        raise ValueError('Installed native task ABI does not declare typed buffer descriptor v2')
    context.native_buffers = descriptors
    context.native_buffer_units = context.request.get('native_input_units') or {}
    buffer_root = context.scratch / 'native-buffers';buffer_root.mkdir(mode=0o700)
    identities = tdict(context.request['source_identities'])
    for alias, descriptor in descriptors.items():
        raw = context.inputs[alias]
        source = tdict(identities[alias])
        if len(raw) != descriptor['byte_count'] or hashlib.sha256(raw).hexdigest() != source['sha256']:
            raise ValueError('Native resource snapshot SHA/byte count mismatch')
        path = buffer_root / descriptor['resource_id']
        if path.exists():
            if path.read_bytes() != raw: raise ValueError('Conflicting native resource buffer identity')
        else:
            with path.open('xb') as stream: stream.write(raw)
        fd, _, _ = owned_buffer(buffer_root, descriptor);os.close(fd)
    output = context.scratch / 'native-result.json'
    from gxtxt_job_supervisor import diagnostic_event, process_identity
    # Reuse the existing Job diagnostic owner and verified artifact identities.
    # Attempts are not starts; cancellation can kill this adapter before an
    # exit record, so the guardian's terminal/drain outcome remains authority.
    diagnostic_record = dict(output_dir=str(context.output), run_id=os.environ['GXTXT_JOB_ID'])
    execution_identity = dict(artifact_sha256=artifact['artifact_sha256'],
                              source_sha256=artifact['source_sha256'])
    # Child remains a descendant of the existing Script Job guardian. It has
    # the same policy, cancellation, resource lease and process-family cleanup.
    # Check the original installed metadata again after the owned copy and
    # input staging, before any diagnostic can claim an ELF attempt or start.
    _remote_build_launch_guard(context.request)
    with output.open('xb') as stream:
        environment = dict(os.environ)
        environment['GXTXT_NATIVE_BUFFER_ROOT'] = str(buffer_root)
        for key in ('LD_PRELOAD', 'LD_AUDIT', 'LD_LIBRARY_PATH'): environment.pop(key, None)
        if artifact['dependencies']:
            environment['LD_LIBRARY_PATH'] = ':'.join(sorted({str((snapshot/relative).parent) for relative in artifact['dependencies']}))
        diagnostic_event(diagnostic_record, 'native_execution_attempt', **execution_identity)
        child = subprocess.Popen([str(executable)], stdin=subprocess.PIPE, stdout=stream, stderr=None,
                                 cwd=context.scratch, env=environment, close_fds=True)
        child_identity = process_identity(child.pid)
        diagnostic_event(diagnostic_record, 'native_execution_start', native_pid=child.pid,
                         native_process_identity=child_identity, **execution_identity)
        child.communicate(input_protocol(context))
        diagnostic_event(diagnostic_record, 'native_execution_exit', native_pid=child.pid,
                         native_process_identity=child_identity, exit_code=child.returncode,
                         **execution_identity)
    if child.returncode:
        raise RuntimeError('Native task failed with exit code ' + str(child.returncode))
    if output.stat().st_size > MAX_CONTROL:
        raise ValueError('Native result exceeds control bound; return existing managed descriptors')
    result = strict_json(output.read_text(encoding='utf-8'))
    if not isinstance(result, dict):
        raise ValueError('Native result must be a typed object')
    retained = {}
    def retain(value):
        if isinstance(value, dict) and '__gxtxt_native_buffer__' in value:
            if artifact['abi'].get('buffer_descriptor_version') != 2:
                raise ValueError('Native task ABI does not declare typed buffer publication')
            descriptor = value['__gxtxt_native_buffer__'];validate_descriptor_metadata(descriptor)
            resource = descriptor['resource_id']
            if resource not in retained:
                fd, _, _ = owned_buffer(buffer_root, descriptor)
                directory = context.output / 'viewer_bridge_arrays';directory.mkdir(exist_ok=True)
                target = directory / resource
                try:
                    before = os.fstat(fd)
                    with os.fdopen(fd, 'rb', closefd=False) as source, target.open('xb') as destination: shutil.copyfileobj(source, destination, 1048576)
                    after = os.fstat(fd)
                    if (before.st_size,before.st_mtime_ns,before.st_ctime_ns)!=(after.st_size,after.st_mtime_ns,after.st_ctime_ns):
                        raise ValueError('Native output buffer changed while retaining')
                finally: os.close(fd)
                fd, _, _ = owned_buffer(directory, descriptor);os.close(fd)
                role = 'native_buffer_' + resource[:-4]
                context.publish_output('viewer_bridge_arrays/' + resource, role, 'gxtxt.binary.v2')
                retained[resource] = dict(schema='gxtxt.viewer_bridge_buffer.v1', descriptor=descriptor,
                                          output_role=role, units=str(value.get('units', '')),sha256=file_sha256(target))
                alias=value.get('source_alias','')
                if alias:
                    source_references=tdict(native_owner.get('resource_sources',''))
                    if alias not in source_references:raise ValueError('Native output has a foreign source-resource alias')
                    reference=tdict(source_references[alias]);reference['metadata']=tdict(reference['metadata'])
                    reference['metadata']['binary_descriptor']=descriptors[alias]
                    reference['size_bytes']=int(reference['size_bytes'])
                    retained[resource].update(source_alias=alias,source_resource=reference)
            return retained[resource]
        if isinstance(value, dict): return {k:retain(v) for k,v in value.items()}
        if isinstance(value, list): return [retain(v) for v in value]
        return value
    result = retain(result)
    if len(json.dumps(result,allow_nan=False,separators=(',',':')).encode())>MAX_CONTROL:
        raise ValueError('Native result metadata exceeds bounded control transport')
    if retained:
        projection = dict(schema='gxtxt.viewer_bridge_result.v1', module_id=artifact.get('module_id', ''),
                          run_id=os.environ.get('GXTXT_JOB_ID', ''), action='native_job', result=result)
        (context.output/'viewer_bridge_result.json').write_text(json.dumps(projection,allow_nan=False,separators=(',',':')))
    context.summary(dict(validation='native_task_completed', native_result=result,
                         artifact_sha256=artifact['artifact_sha256'], source_sha256=artifact['source_sha256'], abi=artifact['abi']))


if __name__ == '__main__':
    from gxtxt_scientific_execution import tvalue
    try:
        if sys.argv[1] == 'result':
            output = Path(sys.argv[2]) / 'scientific-outputs.json'
            if output.is_symlink() or output.stat().st_size > 2097152:
                raise ValueError('Invalid native retained result manifest')
            manifest = strict_json(output.read_text(encoding='utf-8'))
            raw = json.dumps(manifest['summary']['native_result'], ensure_ascii=False, allow_nan=False, separators=(',', ':'))
            print(tvalue(dict(ok=True, result=dict(json=raw))))
            raise SystemExit(0)
        if sys.argv[1] == 'validate_buffers':
            raw = sys.stdin.buffer.read(MAX_CONTROL + 1)
            if len(raw)>MAX_CONTROL: raise ValueError('Native buffer metadata exceeds control bound')
            descriptors = buffer_descriptors_from_tcl(raw.decode())
            print(tvalue(dict(ok=True,result=descriptors)));raise SystemExit(0)
        if sys.argv[1] not in ('verify', 'verify_tcl'):
            raise ValueError('Unknown native artifact operation')
        raw = sys.stdin.buffer.read(MAX_CONTROL + 1)
        if len(raw) > MAX_CONTROL:
            raise ValueError('Native artifact descriptor exceeds bound')
        descriptor = descriptor_from_tcl(raw.decode()) if sys.argv[1] == 'verify_tcl' else strict_json(raw)
        result = verify_artifact(Path(sys.argv[2]), descriptor)
        print(tvalue(dict(ok=True, result=result)))
    except Exception as exc:
        print(tvalue(dict(ok=False, error=str(exc))))
        raise SystemExit(1)
