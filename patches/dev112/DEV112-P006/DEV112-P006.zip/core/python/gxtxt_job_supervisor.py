#!/usr/bin/env python3
# Script Bridge source contract scope: gxtxt_job_supervisor.script_bridge_policy.json (exact operations; no added runtime authority).
"""Durable LOCAL script-job scheduler; scientific state stays in CORE APIs."""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations
import argparse, configparser, contextlib, fcntl, hashlib, json, os, signal, sqlite3
import subprocess, sys, time, uuid, io, stat
import tempfile, re
from pathlib import Path
# FUTURE WINDOWS PORTING REQUIREMENT (implementation intentionally deferred):
# LOCAL platform-independent CORE service, never remote job dispatch. Tk is not
# the process owner; closing GUI must not cancel jobs. A Windows adapter must
# run independently with a notification-area tray icon: reopen/focus GUI, inspect
# jobs, cancel selected/all (confirm cancel-all), safely exit supervisor. Reuse
# Job/Resource/Publication authorities and native Job Objects. No mandatory
# Windows service. Logout/shutdown may stop work; recover durable state next run.
ACTIVE=('QUEUED','PREPARING','RUNNING','FINALIZING')
TERMINAL=('COMPLETED','FAILED','CANCELLED','INTERRUPTED')
def root_path(root):
    p=Path(root).absolute()
    if p.is_symlink():raise ValueError('Job root cannot be a symlink')
    p.mkdir(parents=True,exist_ok=True,mode=0o700);st=p.stat()
    if st.st_uid!=os.getuid() or st.st_mode&0o077:raise ValueError('Job root must be owned by this account with mode 0700')
    return p.resolve()
def _client_owner_schema(c):
    # Existing databases gain only nullable client metadata. The fast read path
    # avoids taking a write lock on every ordinary status poll after migration.
    if any(row[1]=='client_owner' for row in c.execute('PRAGMA table_info(jobs)')):return
    c.execute('BEGIN IMMEDIATE')
    try:
        if not any(row[1]=='client_owner' for row in c.execute('PRAGMA table_info(jobs)')):
            c.execute('ALTER TABLE jobs ADD COLUMN client_owner TEXT')
        c.execute('COMMIT')
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def default_policy():
    # Single original owner default, shared with no-initialization policy reads.
    return dict(max_jobs=1,max_queue=64,threads=1,timeout_seconds=86400,memory_mib=4096,temp_mib=8192,max_processes=64)
def connect(root,*,existing_only=False,expected_scope=None,initialize=True):
    database=root/'jobs.sqlite'
    c=sqlite3.connect(database.as_uri()+'?mode=rw',uri=True,timeout=10,isolation_level=None) if existing_only else sqlite3.connect(database,timeout=10,isolation_level=None)
    c.row_factory=sqlite3.Row
    if expected_scope is not None:
        try:
            if _admission_scope(root)!=expected_scope:raise ValueError('Original admission database changed before connection')
        except BaseException:c.close();raise
    if not initialize:
        c.execute('PRAGMA synchronous=FULL')
        return c
    c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA synchronous=FULL')
    c.execute('CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,signature TEXT,state TEXT,created REAL,started REAL,finished REAL,pid INTEGER,cancel INTEGER DEFAULT 0,record TEXT,error TEXT DEFAULT "")')
    try:_client_owner_schema(c)
    except BaseException:c.close();raise
    c.execute('CREATE UNIQUE INDEX IF NOT EXISTS active_signature ON jobs(signature) WHERE state IN ("QUEUED","PREPARING","RUNNING","FINALIZING")')
    c.execute('CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY CHECK(id=1),value TEXT)')
    c.execute('CREATE TABLE IF NOT EXISTS job_waits(parent_id TEXT PRIMARY KEY,child_id TEXT UNIQUE,token TEXT UNIQUE,caller_pid INTEGER,caller_start TEXT,created REAL)')
    c.execute('INSERT OR IGNORE INTO settings VALUES(1,?)',(json.dumps(default_policy()),))
    return c
def policy(c):return json.loads(c.execute('SELECT value FROM settings').fetchone()[0])
def read_policy_root(root):
    """Trusted LOCAL snapshot; no root/database/schema/settings initialization.

    Ordinary SQLite mode=ro honors committed WAL. SQLite may maintain transient
    WAL/SHM bookkeeping for an existing WAL database; no filesystem-zero-write
    claim is made. This policy snapshot is not an admission/reservation lease.
    """
    root=Path(root).absolute();configured=False;p=default_policy()
    try:
        for path in (*reversed(root.parents),root):
            if path.is_symlink():raise ValueError('Job policy root aliases are forbidden')
        try:root_info=root.lstat()
        except FileNotFoundError:root_info=None
        if root_info is not None:
            if not stat.S_ISDIR(root_info.st_mode) or root_info.st_uid!=os.getuid() or root_info.st_mode&0o077:
                raise PermissionError('Job policy root ownership or permissions refused')
            database=root/'jobs.sqlite'
            if database.is_symlink():raise ValueError('Job policy database aliases are forbidden')
            try:before=database.lstat()
            except FileNotFoundError:before=None
            if before is not None:
                if not stat.S_ISREG(before.st_mode) or before.st_uid!=os.getuid() or before.st_nlink!=1:
                    raise PermissionError('Job policy database identity refused')
                c=sqlite3.connect(database.as_uri()+'?mode=ro',uri=True,isolation_level=None)
                try:
                    c.execute('BEGIN');p=policy(c)
                    after=database.lstat();root_after=root.lstat()
                    if not stat.S_ISDIR(root_after.st_mode) or root_after.st_uid!=os.getuid() or root_after.st_mode&0o077:
                        raise ValueError('Job policy root identity changed during read')
                    if not stat.S_ISREG(after.st_mode) or after.st_uid!=os.getuid() or after.st_nlink!=1:
                        raise ValueError('Job policy database identity changed during read')
                    if any(path.is_symlink() for path in (*root.parents,root)):
                        raise ValueError('Job policy root aliases changed during read')
                    if (before.st_dev,before.st_ino,root_info.st_dev,root_info.st_ino)!=(after.st_dev,after.st_ino,root_after.st_dev,root_after.st_ino):
                        raise ValueError('Job policy journal replaced during read')
                    configured=True
                finally:c.close()
        if not isinstance(p,dict) or set(p)!=set(default_policy()) or any(type(v) is not int or v<1 for v in p.values()):
            raise ValueError('Invalid stored Job policy')
    except (sqlite3.Error,TypeError,IndexError,json.JSONDecodeError):
        raise ValueError('Stored Job policy is unavailable or invalid') from None
    return dict(schema='gxtxt.job_policy.v1',configured=configured,origin='configured' if configured else 'owner_default',
                policy=p,policy_sha256=hashlib.sha256(json.dumps(p,sort_keys=True,separators=(',',':')).encode()).hexdigest())
def atomic_json(path,data):
    atomic_text(path,json.dumps(data,sort_keys=True))
def atomic_text(path,text):
    tmp=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with tmp.open('x',encoding='utf-8') as f:f.write(text);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path);fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    finally:
        with contextlib.suppress(FileNotFoundError):tmp.unlink()
def process_identity(pid):
    try:
        fields=Path(f'/proc/{int(pid)}/stat').read_text().rsplit(')',1)[1].split()
        if fields[0]=='Z':return ''
        return Path('/proc/sys/kernel/random/boot_id').read_text().strip()+':'+fields[19]
    except (OSError,ValueError,IndexError):return ''
def _client_owner_json(raw,allow_none=False):
    """Host metadata only; lifecycle record JSON is never its authority."""
    if not isinstance(raw,str):raise ValueError('Client owner must be bounded JSON text')
    try:encoded=raw.encode('utf-8')
    except UnicodeEncodeError:raise ValueError('Client owner must be valid UTF-8') from None
    if not encoded or len(encoded)>4096:raise ValueError('Client owner JSON exceeds its bound')
    def fields(pairs):
        result={}
        for key,value in pairs:
            if key in result:raise ValueError('Duplicate client owner field')
            result[key]=value
        return result
    def nonfinite(unused):raise ValueError('Nonfinite client owner JSON is refused')
    owner=json.loads(raw,object_pairs_hook=fields,parse_constant=nonfinite)
    if owner is None and allow_none:return None
    if type(owner) is not dict or set(owner)!={'pid','process','instance'}:
        raise ValueError('Client owner requires exactly pid, process and instance')
    if type(owner['pid']) is not int or owner['pid']<=0:raise ValueError('Client owner PID must be a positive integer')
    process=owner['process']
    if type(process) is not str or not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}:[0-9]+',process) or len(process)>128:
        raise ValueError('Client owner process must be an existing boot/start identity')
    instance=owner['instance']
    try:valid=type(instance) is str and 0<len(instance.encode('utf-8'))<=256 and not any(ord(ch)<32 or ord(ch)==127 for ch in instance)
    except UnicodeEncodeError:valid=False
    if not valid:raise ValueError('Client owner instance must be a bounded opaque token')
    return owner

def client_owner_claim(c,job_id,expected_json,proposed_json,*,host_attested=False):
    """Finite host CAS; trusted CORE separately admits the Canvas/Session owner.

    host_attested is private to the authenticated Compute Node adapter after
    native module/client/source guards. That remote GUI owner attests its own
    process/window liveness: client PIDs cannot be checked in the node's /proc.
    CLI and Script Bridge expose no attestation flag; local checks stay default.
    """
    if type(host_attested) is not bool:raise ValueError('Host attestation must be private Boolean metadata')
    expected=_client_owner_json(expected_json,allow_none=True)
    proposed=_client_owner_json(proposed_json)
    c.execute('BEGIN IMMEDIATE')
    try:
        row=c.execute('SELECT client_owner FROM jobs WHERE id=?',(job_id,)).fetchone()
        if row is None:raise ValueError('Unknown job ID')
        raw=row['client_owner']
        current=None if raw is None else _client_owner_json(raw)
        if current!=expected:raise ValueError('Client owner compare-and-swap mismatch')
        if not host_attested and current is not None and (current['pid'],current['process'])!=(proposed['pid'],proposed['process']):
            if process_identity(current['pid'])==current['process']:
                raise ValueError('Job belongs to another live client process')
        # Same-process transfer still requires the exact previous instance;
        # CORE, not this journal, verifies that the old Canvas was disposed.
        if not host_attested and process_identity(proposed['pid'])!=proposed['process']:
            raise ValueError('Proposed client owner process is not live')
        value=json.dumps(proposed,sort_keys=True,separators=(',',':'))
        c.execute('UPDATE jobs SET client_owner=? WHERE id=? AND client_owner IS ?',(value,job_id,raw))
        if c.execute('SELECT changes()').fetchone()[0]!=1:raise ValueError('Client owner compare-and-swap mismatch')
        c.execute('COMMIT')
        return dict(job_id=job_id,client_owner=proposed)
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def enable_subreaper():
    # Local Linux backend only. A future Windows adapter uses Job Objects and
    # the independent supervisor/tray specified above, not a second authority.
    import ctypes
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0:raise OSError(ctypes.get_errno(),'Cannot enable local child supervision')
def signal_tree(pid,start,sig):
    # POSIX backend boundary. Future Windows uses Job Objects, not PID-only kills.
    if start and process_identity(pid)==start:
        with contextlib.suppress(ProcessLookupError):os.killpg(pid,sig)
def status(row):
    d=json.loads(row['record']);d.pop('client_owner',None);d.pop('_tracked_admission',None)
    d.update({k:row[k] for k in ('id','state','created','started','finished','pid','cancel','error')})
    if 'client_owner' in row.keys() and row['client_owner'] is not None:d['client_owner']=_client_owner_json(row['client_owner'])
    if not d.get('script_version'):
        from gxtxt_script_inspection import submission_identity
        submission_identity(d)
    return d

# HOST_ONLY: opt-in admission metadata in this SAME original journal. These rows
# do not schedule work, change signatures or grant Script/Session authority.
def _admission_schema(c):
    c.execute('CREATE TABLE IF NOT EXISTS job_admissions(submission_id TEXT PRIMARY KEY,binding TEXT NOT NULL,binding_sha256 TEXT NOT NULL,scope TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ("OPEN","ACCEPTED","CLOSED")),job_id TEXT,created REAL NOT NULL,updated REAL NOT NULL,owner_key TEXT NOT NULL DEFAULT "",epoch TEXT NOT NULL DEFAULT "",handled INTEGER NOT NULL DEFAULT 0 CHECK(handled IN (0,1)))')
    columns={r[1] for r in c.execute('PRAGMA table_info(job_admissions)')}
    for key in {'owner_key','epoch'}-columns:c.execute('ALTER TABLE job_admissions ADD COLUMN '+key+' TEXT NOT NULL DEFAULT ""')
    if 'handled' not in columns:c.execute('ALTER TABLE job_admissions ADD COLUMN handled INTEGER NOT NULL DEFAULT 0 CHECK(handled IN (0,1))')
    c.execute('CREATE INDEX IF NOT EXISTS admission_owner_scope ON job_admissions(owner_key,state)')
    c.execute('CREATE TABLE IF NOT EXISTS job_admission_scopes(owner_key TEXT PRIMARY KEY,owner_scope TEXT NOT NULL,scope TEXT NOT NULL,epoch TEXT NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS job_admission_epochs(owner_key TEXT NOT NULL,epoch TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ("ACTIVE","CLOSED")),PRIMARY KEY(owner_key,epoch))')

def _admission_dict(raw):
    import tkinter
    if not isinstance(raw,str) or len(raw.encode('utf-8'))>8388608:raise ValueError('Tracked admission metadata exceeds its finite bound')
    parts=tkinter.Tcl().splitlist(raw)
    if len(parts)%2 or len(set(parts[::2]))!=len(parts)//2:raise ValueError('Invalid tracked admission dictionary')
    return dict(zip(parts[::2],parts[1::2]))

def _admission_scope(root):
    root=Path(root).absolute()
    for path in (*reversed(root.parents),root):
        if not stat.S_ISDIR(path.lstat().st_mode):raise ValueError('Tracked Job root has an aliased ancestor')
    a=root.lstat();b=(root/'jobs.sqlite').lstat()
    if a.st_uid!=os.getuid() or a.st_mode&0o077 or not stat.S_ISREG(b.st_mode) or b.st_nlink!=1 or b.st_uid!=os.getuid() or b.st_mode&0o022:
        raise ValueError('Original tracked Job root/database proof unavailable')
    return dict(root=str(root),root_dev=a.st_dev,root_ino=a.st_ino,database_dev=b.st_dev,database_ino=b.st_ino,uid=a.st_uid)

def _admission_scope_input(raw):
    if raw in ('',None):return None
    d=_admission_dict(raw) if isinstance(raw,str) else dict(raw)
    if set(d)!={'root','root_dev','root_ino','database_dev','database_ino','uid'}:raise ValueError('Invalid original admission scope')
    for key in set(d)-{'root'}:
        value=d[key]
        if isinstance(value,bool) or not re.fullmatch(r'[0-9]+',str(value)):raise ValueError('Invalid admission physical identity')
        d[key]=int(value)
    return d

def _admission_owner(raw):
    d=_admission_dict(raw) if isinstance(raw,str) else dict(raw)
    if set(d)!={'session','session_dev','session_ino','uid','document_id','document_generation','provider_id'}:raise ValueError('Invalid exact admission owner scope')
    for key in {'session_dev','session_ino','uid'}:
        if isinstance(d[key],bool) or not re.fullmatch('[0-9]+',str(d[key])):raise ValueError('Invalid owner Session identity')
        d[key]=int(d[key])
    if not Path(d['session']).is_absolute() or d['session_ino']<1 or d['uid']!=os.getuid():raise ValueError('Invalid owner Session scope')
    for key in {'document_id','document_generation','provider_id'}:
        if not isinstance(d[key],str) or not 0<len(d[key].encode())<=256 or any(ord(ch)<32 or ord(ch)==127 for ch in d[key]):raise ValueError('Invalid original owner field')
    if not re.fullmatch('[A-Za-z_][A-Za-z0-9_.-]*',d['provider_id']):raise ValueError('Invalid owner provider')
    text=json.dumps(d,sort_keys=True,separators=(',',':'));return d,text,hashlib.sha256(text.encode()).hexdigest()

def _admission_owner_session(owner):
    path=Path(owner['session'])
    for parent in (*reversed(path.parents),path):
        if not stat.S_ISDIR(parent.lstat().st_mode):raise ValueError('Owner Session aliases refused')
    s=path.lstat()
    if (s.st_dev,s.st_ino,s.st_uid)!=(owner['session_dev'],owner['session_ino'],owner['uid']):raise ValueError('Original owner Session changed')

def _admission_owner_payload(request,root,*,epoch=False,lookup=False):
    keys={'owner_scope','scope','supervisor_sha256'}|({'authority_epoch'} if epoch else set())|({'submission_id'} if lookup else set())
    if set(request)!=keys:raise ValueError('Invalid original owner request')
    if request['supervisor_sha256']!=hashlib.sha256(Path(__file__).read_bytes()).hexdigest():raise ValueError('Original Supervisor source changed')
    if epoch and not re.fullmatch('[a-f0-9]{32}',request['authority_epoch']):raise ValueError('Original owner epoch missing')
    if lookup and not re.fullmatch('job-admission-[a-f0-9]{32}',request['submission_id']):raise ValueError('Invalid original admission ID')
    owner,text,key=_admission_owner(request['owner_scope']);expected=_admission_scope_input(request['scope'])
    if expected is not None and expected['root']!=str(Path(root).absolute()):raise ValueError('Original owner root differs')
    return owner,text,key,expected

def _admission_authority(c,key,owner_text,scope,epoch):
    row=c.execute('SELECT * FROM job_admission_scopes WHERE owner_key=?',(key,)).fetchone()
    if row is None or row['owner_scope']!=owner_text or json.loads(row['scope'])!=scope:raise ValueError('Original owner authority unavailable')
    issued=c.execute('SELECT state FROM job_admission_epochs WHERE owner_key=? AND epoch=?',(key,epoch)).fetchone()
    if issued is None:raise ValueError('Unknown original owner epoch')
    if (issued['state']=='ACTIVE')!=(row['epoch']==epoch):raise ValueError('Original owner epoch history is inconsistent')
    return row

def admission_owner_open(c,root,request):
    owner,text,key,expected=_admission_owner_payload(request,root);current=_admission_scope(root)
    if expected is not None and expected!=current:raise ValueError('Original owner database changed')
    _admission_schema(c);c.execute('BEGIN IMMEDIATE')
    try:
        _admission_owner_session(owner)
        row=c.execute('SELECT * FROM job_admission_scopes WHERE owner_key=?',(key,)).fetchone()
        if row is None:
            epoch=uuid.uuid4().hex;c.execute('INSERT INTO job_admission_scopes VALUES(?,?,?,?)',(key,text,json.dumps(current,sort_keys=True),epoch))
            c.execute('INSERT INTO job_admission_epochs VALUES(?,?,?)',(key,epoch,'ACTIVE'))
        else:
            if row['owner_scope']!=text or json.loads(row['scope'])!=current:raise ValueError('Original owner scope changed')
            epoch=row['epoch']
        if _admission_scope(root)!=current:raise ValueError('Original owner database changed')
        c.execute('COMMIT');return dict(owner_scope=owner,scope=current,authority_epoch=epoch,can_admit=False)
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def admission_recover(c,root,request,*,cancel=False):
    if type(cancel) is not bool:raise ValueError('Original recovery cancellation must be Boolean')
    owner,text,key,expected=_admission_owner_payload(request,root,epoch=True);current=_admission_scope(root)
    if expected is None or expected!=current:raise ValueError('Recovery requires original physical database proof')
    _admission_schema(c);c.execute('BEGIN IMMEDIATE')
    try:
        row=_admission_authority(c,key,text,current,request['authority_epoch'])
        # A lost recovery reply is idempotently recoverable from its CLOSED old
        # epoch. It cannot rotate a newer active generation again or reopen it.
        epoch=row['epoch']
        if epoch==request['authority_epoch']:
            epoch=uuid.uuid4().hex
            c.execute("UPDATE job_admissions SET state='CLOSED',updated=? WHERE owner_key=? AND state='OPEN'",(time.time(),key))
            c.execute("UPDATE job_admission_epochs SET state='CLOSED' WHERE owner_key=? AND epoch=?",(key,row['epoch']))
            c.execute('INSERT INTO job_admission_epochs VALUES(?,?,?)',(key,epoch,'ACTIVE'))
            c.execute('UPDATE job_admission_scopes SET epoch=? WHERE owner_key=?',(epoch,key))
        cancelled=0
        if cancel:
            restriction='' if row['epoch']==request['authority_epoch'] else ' AND epoch=?'
            parameters=(key,) if not restriction else (key,request['authority_epoch'])
            c.execute("UPDATE jobs SET cancel=1 WHERE id IN (SELECT job_id FROM job_admissions WHERE owner_key=? AND state='ACCEPTED'"+restriction+") AND state IN (?,?,?,?)",(*parameters,*ACTIVE));cancelled=c.execute('SELECT changes()').fetchone()[0]
        # Counts cover the WHOLE exact original association. Bounded history is
        # only a projection; its absence/pagination never certifies nonadmission.
        total=c.execute('SELECT count(*) FROM job_admissions WHERE owner_key=?',(key,)).fetchone()[0]
        blocking=c.execute("SELECT count(*) FROM job_admissions a LEFT JOIN jobs j ON j.id=a.job_id WHERE a.owner_key=? AND (a.state='OPEN' OR (a.state='ACCEPTED' AND (a.handled=0 OR j.state IN (?,?,?,?))))",(key,*ACTIVE)).fetchone()[0]
        unscoped=c.execute("SELECT count(*) FROM job_admissions WHERE owner_key='' OR epoch=''").fetchone()[0]
        rows=[]
        for r in c.execute("SELECT a.submission_id,a.state,a.job_id,a.handled,j.state AS job_state FROM job_admissions a LEFT JOIN jobs j ON j.id=a.job_id WHERE a.owner_key=? ORDER BY CASE WHEN a.state='ACCEPTED' AND a.handled=0 THEN 0 ELSE 1 END,a.created,a.submission_id LIMIT 128",(key,)):
            rows.append(dict(submission_id=r['submission_id'],admission_state=r['state'],job_id=r['job_id'],job_state=r['job_state'],handled=bool(r['handled'])))
        if _admission_scope(root)!=current:raise ValueError('Original recovery database changed')
        c.execute('COMMIT');return dict(owner_scope=owner,scope=current,authority_epoch=epoch,admissions=rows,total=total,has_more=total>128,blocking_count=blocking,unscoped_count=unscoped,safe_to_start=blocking==0 and unscoped==0,cancel_requested_count=cancelled)
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def admission_lookup(c,root,request):
    owner,text,key,expected=_admission_owner_payload(request,root,epoch=True,lookup=True);current=_admission_scope(root)
    if expected is None or expected!=current:raise ValueError('Lookup requires original physical database proof')
    _admission_schema(c);c.execute('BEGIN')
    try:
        _admission_authority(c,key,text,current,request['authority_epoch'])
        row=c.execute('SELECT * FROM job_admissions WHERE submission_id=? AND owner_key=?',(request['submission_id'],key)).fetchone()
        if row is None:raise ValueError('Original scoped admission is unavailable; absence is not closure')
        result=_admission_receipt(c,row);result['binding']=json.loads(row['binding'])
        if _admission_scope(root)!=current:raise ValueError('Original lookup database changed')
        c.execute('COMMIT');return result
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def admission_wait(c,root,request,job_id,seconds):
    """Compact original-owner observation; event bytes are ONLY wakeups.

    No scheduler/worker/cancel or replacement journal is started here. Every
    authoritative read rechecks original physical generation and association.
    """
    if type(seconds) is not int or not 1<=seconds<=180:raise ValueError('Tracked observation bound must be1..180 seconds')
    binding,text,digest,expected=_admission_payload(request,root)
    if expected is None or expected!=_admission_scope(root):raise ValueError('Tracked observation requires its original database')
    owner,owner_text,key=_admission_owner(binding['_admission_owner_scope'])
    def scope_current():
        if _admission_scope(root)!=expected:raise ValueError('Original observation database was replaced')
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest()!=request['supervisor_sha256']:raise ValueError('Original observation source changed')
    def observe():
        scope_current();c.execute('BEGIN')
        try:
            _admission_authority(c,key,owner_text,expected,request['authority_epoch'])
            row=c.execute('SELECT state,job_id,binding_sha256,owner_key,scope,epoch FROM job_admissions WHERE submission_id=?',(request['submission_id'],)).fetchone()
            if row is None or row['state']!='ACCEPTED' or row['job_id']!=job_id or row['binding_sha256']!=digest or row['owner_key']!=key or row['epoch']!=request['authority_epoch'] or json.loads(row['scope'])!=expected:
                raise ValueError('Actual Job is not this original accepted admission')
            job=c.execute('SELECT state FROM jobs WHERE id=?',(job_id,)).fetchone()
            if job is None or job['state'] not in (*ACTIVE,*TERMINAL):raise ValueError('Original accepted Job state is unavailable')
            scope_current();result=dict(id=job_id,state=job['state']) if job['state'] in TERMINAL else None
            c.execute('COMMIT');return result
        except BaseException:
            if c.in_transaction:c.execute('ROLLBACK')
            raise
    result=observe()
    if result is not None:return result
    import select,socket,struct
    from gxtxt_job_events import endpoint
    deadline=time.monotonic()+seconds;client=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
    try:
        connected=False;connect_end=min(deadline,time.monotonic()+5)
        while time.monotonic()<connect_end:
            scope_current();client.settimeout(min(.25,max(.001,connect_end-time.monotonic())))
            try:client.connect(endpoint(root));connected=True;break
            except (FileNotFoundError,ConnectionRefusedError,TimeoutError):time.sleep(.05)
        if not connected:
            result=observe()
            if result is not None:return result
            raise ValueError('Original Supervisor event transport is unavailable')
        if struct.unpack('3i',client.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))[1]!=os.getuid():raise ValueError('Foreign original observation event peer')
        client.sendall(json.dumps(dict(job_id=job_id,after_sequence=0)).encode()+b'\n');client.setblocking(False)
        while time.monotonic()<deadline:
            scope_current()
            readable,_,_=select.select([client],[],[],min(.5,max(0,deadline-time.monotonic())))
            if not readable:continue
            chunk=client.recv(65536)
            result=observe()
            if result is not None:return result
            if not chunk:raise ValueError('Original event observer ended before a terminal state')
        raise ValueError('Original tracked observation exceeded its finite180second bound')
    finally:client.close()

def _admission_binding(raw,root):
    d=_admission_dict(raw)
    if d.get('root')!=str(Path(root).absolute()) or d.get('reference')!='core-service:scientific-provider' or d.get('core_service')!='scientific-provider':
        raise ValueError('Tracked admission requires its original LOCAL Scientific owner')
    if '_tracked_admission' in d or not d.get('session') or not Path(d['session']).is_absolute():raise ValueError('Invalid original admission intent')
    parameters=_admission_dict(d.get('parameters',''))
    if set(parameters)!={'request'} or not parameters['request']:raise ValueError('Tracked provider request is missing')
    import tkinter
    identity=tkinter.Tcl().splitlist(d.get('_admission_session_identity',''))
    if len(identity)!=3 or any(not re.fullmatch('[0-9]+',v) for v in identity):raise ValueError('Tracked Session physical identity missing')
    owner,text,key=_admission_owner(d.get('_admission_owner_scope',''))
    if owner['session']!=d['session'] or tuple(map(int,identity))!=(owner['session_dev'],owner['session_ino'],owner['uid']):raise ValueError('Tracked owner/Session binding mismatch')
    import base64
    provider=_admission_dict(base64.b64decode(parameters['request'],validate=True).decode('utf-8')).get('provider_id')
    if provider!=owner['provider_id']:raise ValueError('Tracked provider differs from original owner scope')
    encoded=json.dumps(d,sort_keys=True,separators=(',',':'))
    return d,encoded,hashlib.sha256(encoded.encode()).hexdigest()

def _admission_session_current(binding):
    import tkinter
    expected=tuple(map(int,tkinter.Tcl().splitlist(binding['_admission_session_identity'])))
    path=Path(binding['session'])
    for parent in (*reversed(path.parents),path):
        if not stat.S_ISDIR(parent.lstat().st_mode):raise ValueError('Tracked Session has an aliased ancestor')
    s=path.lstat()
    if (s.st_dev,s.st_ino,s.st_uid)!=expected or s.st_uid!=os.getuid():raise ValueError('Tracked Session generation changed')

def _admission_payload(request,root):
    if set(request)!={'submission_id','binding','scope','authority_epoch','supervisor_sha256'}:raise ValueError('Invalid tracked admission payload')
    if not re.fullmatch(r'job-admission-[a-f0-9]{32}',request['submission_id']):raise ValueError('Invalid original admission ID')
    if request['supervisor_sha256']!=hashlib.sha256(Path(__file__).read_bytes()).hexdigest():raise ValueError('Original Supervisor source changed')
    if not re.fullmatch('[a-f0-9]{32}',request['authority_epoch']):raise ValueError('Original authority epoch missing')
    binding,text,digest=_admission_binding(request['binding'],root)
    return binding,text,digest,_admission_scope_input(request['scope'])

def _admission_receipt(c,row):
    state=row['state'];result=dict(submission_id=row['submission_id'],admission_state=state,binding_sha256=row['binding_sha256'],scope=json.loads(row['scope']),authority_epoch=row['epoch'],handled=bool(row['handled']),retry_allowed=state=='CLOSED',closed_before_admission=state=='CLOSED')
    if state=='ACCEPTED':
        job=c.execute('SELECT * FROM jobs WHERE id=?',(row['job_id'],)).fetchone()
        result.update(job_id=row['job_id'],job_available=job is not None)
        if job is not None:result['job']=dict(id=job['id'],state=job['state'],cancel=bool(job['cancel']))
    return result

def admission_begin(c,root,request):
    binding,text,digest,expected=_admission_payload(request,root);current=_admission_scope(root)
    if expected is not None and current!=expected:raise ValueError('Original admission database was replaced')
    _admission_schema(c);c.execute('BEGIN IMMEDIATE')
    try:
        if _admission_scope(root)!=current:raise ValueError('Original admission scope changed')
        _admission_session_current(binding)
        owner,owner_text,owner_key=_admission_owner(binding['_admission_owner_scope'])
        authority=_admission_authority(c,owner_key,owner_text,current,request['authority_epoch'])
        row=c.execute('SELECT * FROM job_admissions WHERE submission_id=?',(request['submission_id'],)).fetchone()
        if row is None:
            if authority['epoch']!=request['authority_epoch']:raise ValueError('Original admission epoch was fenced before registration')
            now=time.time();c.execute('INSERT INTO job_admissions(submission_id,binding,binding_sha256,scope,state,job_id,created,updated,owner_key,epoch) VALUES(?,?,?,?,?,?,?,?,?,?)',(request['submission_id'],text,digest,json.dumps(current,sort_keys=True),'OPEN',None,now,now,owner_key,request['authority_epoch']))
        elif row['binding']!=text or json.loads(row['scope'])!=current or row['owner_key']!=owner_key or row['epoch']!=request['authority_epoch']:raise ValueError('Admission ID binding mismatch')
        elif row['state']=='OPEN' and authority['epoch']!=row['epoch']:raise ValueError('Original registration epoch was fenced')
        row=c.execute('SELECT * FROM job_admissions WHERE submission_id=?',(request['submission_id'],)).fetchone()
        result=_admission_receipt(c,row)
        if _admission_scope(root)!=current:raise ValueError('Original admission scope changed')
        c.execute('COMMIT');return result
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def admission_resolve(c,root,request,*,close=False,cancel=False,handled_job_id=None):
    if type(close) is not bool or type(cancel) is not bool:raise ValueError('Tracked resolution flags must be Boolean')
    binding,text,digest,expected=_admission_payload(request,root);current=_admission_scope(root)
    if expected is not None and expected!=current:raise ValueError('Original admission database was replaced')
    _admission_schema(c);c.execute('BEGIN IMMEDIATE')
    try:
        owner,owner_text,owner_key=_admission_owner(binding['_admission_owner_scope'])
        _admission_authority(c,owner_key,owner_text,current,request['authority_epoch'])
        row=c.execute('SELECT * FROM job_admissions WHERE submission_id=?',(request['submission_id'],)).fetchone()
        if row is None and (not close or expected is None):
            result=dict(submission_id=request['submission_id'],admission_state='UNKNOWN',retry_allowed=False,closed_before_admission=False)
        else:
            if row is None:
                now=time.time();c.execute('INSERT INTO job_admissions(submission_id,binding,binding_sha256,scope,state,job_id,created,updated,owner_key,epoch) VALUES(?,?,?,?,?,?,?,?,?,?)',(request['submission_id'],text,digest,json.dumps(current,sort_keys=True),'CLOSED',None,now,now,owner_key,request['authority_epoch']))
            else:
                if row['binding']!=text or json.loads(row['scope'])!=current or row['owner_key']!=owner_key or row['epoch']!=request['authority_epoch']:raise ValueError('Admission ID binding/scope mismatch')
                if close and row['state']=='OPEN':c.execute("UPDATE job_admissions SET state='CLOSED',updated=? WHERE submission_id=?",(time.time(),request['submission_id']))
            row=c.execute('SELECT * FROM job_admissions WHERE submission_id=?',(request['submission_id'],)).fetchone();result=_admission_receipt(c,row)
            if handled_job_id is not None:
                if row['state']!='ACCEPTED' or row['job_id']!=handled_job_id:raise ValueError('Handling acknowledgment requires the actual accepted Job ID')
                job=c.execute('SELECT state FROM jobs WHERE id=?',(handled_job_id,)).fetchone()
                if job is None or job['state'] not in TERMINAL:raise ValueError('Only an actual terminal Job can be acknowledged handled')
                c.execute('UPDATE job_admissions SET handled=1,updated=? WHERE submission_id=?',(time.time(),request['submission_id']));result['handled']=True
            if cancel and row['state']=='ACCEPTED':
                c.execute('UPDATE jobs SET cancel=1 WHERE id=? AND state IN (?,?,?,?)',(row['job_id'],*ACTIVE));result['cancel_requested']=bool(c.execute('SELECT changes()').fetchone()[0])
        if _admission_scope(root)!=current:raise ValueError('Original admission scope changed')
        c.execute('COMMIT');return result
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise

def _admission_parameters_digest(parameters):
    return hashlib.sha256(json.dumps(parameters,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def _admission_prepared_parameters(root,r):
    """Verify the registered image byte sealing before taking the write-lock.

    Original intent stays immutable. The existing materializer owns the full
    sealed-file verifier; no decoder/provider/math or substitute capture runs.
    """
    if '_tracked_admission' not in r:return None
    original,_,_,expected=_admission_payload(r['_tracked_admission'],root)
    parameters=_admission_dict(original['parameters'])
    if r['parameters']==parameters:return None
    if set(parameters)!={'request'} or set(r['parameters'])!={'request'}:raise ValueError('Prepared parameters changed outside original image seal')
    import base64
    before=_admission_dict(base64.b64decode(parameters['request'],validate=True).decode('utf-8'))
    after=_admission_dict(base64.b64decode(r['parameters']['request'],validate=True).decode('utf-8'))
    if (before.get('image_profile')!='image_resource_files_v1' or
        'image_input_sources' not in before or 'image_input_snapshot' in before or 'image_input_sources' in after or
        set(after)!=((set(before)-{'image_input_sources'})|{'image_input_snapshot'})):
        raise ValueError('Prepared request is not the original closed image seal transition')
    if any(after[key]!=value for key,value in before.items()if key!='image_input_sources'):
        raise ValueError('Image seal changed immutable original request fields')
    output=Path(r['output_dir'])
    if (not re.fullmatch(r'script-[0-9]{8}T[0-9]{6}Z-[0-9]+-[0-9]+',r['run_id']) or
        output!=Path(original['session'])/'analysis'/'scripts'/r['run_id']):raise ValueError('Image seal is outside the original fresh Job')
    from gxtxt_scientific_execution import image_provider_binding
    image_provider_binding(before)
    from scientific_image_materializer_v1 import verify_snapshot,native_source_binding
    files,records=verify_snapshot(output,_admission_dict(after['image_input_snapshot']),*native_source_binding(before))
    sources={key:_admission_dict(value)for key,value in _admission_dict(before['image_input_sources']).items()}
    if set(files)!=set(sources) or set(records)!=set(sources):raise ValueError('Image seal aliases differ from original sources')
    for alias,source in sources.items():
        if (set(source)!={'source_path','input_sha256','input_bytes','source_guard'} or
            not re.fullmatch('[0-9]+',source['input_bytes']) or
            records[alias]['sha256']!=source['input_sha256'] or records[alias]['size_bytes']!=int(source['input_bytes']) or
            records[alias]['source_guard']!=source['source_guard']):raise ValueError('Image seal differs from original source byte/guard identity')
    return (_admission_parameters_digest(parameters),_admission_parameters_digest(r['parameters']))

def _admission_claim(c,root,r,prepared_parameters=None):
    request=r.get('_tracked_admission')
    if request is None:return None
    binding,text,digest,expected=_admission_payload(request,root)
    if expected is None or expected!=_admission_scope(root):raise ValueError('Tracked admission requires its captured original database')
    row=c.execute('SELECT * FROM job_admissions WHERE submission_id=?',(request['submission_id'],)).fetchone()
    if row is None or row['binding']!=text or json.loads(row['scope'])!=expected:raise ValueError('Unreserved or mismatching tracked admission')
    original_parameters=_admission_dict(binding['parameters'])
    parameters_match=r['parameters']==original_parameters or prepared_parameters==(_admission_parameters_digest(original_parameters),_admission_parameters_digest(r['parameters']))
    if r['session']!=binding['session'] or r['reference']!=binding['reference'] or not parameters_match or r.get('service_id')!='scientific-provider':raise ValueError('Prepared Job differs from original tracked intent')
    owner,owner_text,key=_admission_owner(binding['_admission_owner_scope']);authority=_admission_authority(c,key,owner_text,expected,request['authority_epoch'])
    if row['owner_key']!=key or row['epoch']!=request['authority_epoch']:raise ValueError('Tracked original owner association changed')
    if row['state']=='OPEN' and authority['epoch']!=row['epoch']:raise ValueError('Original admission epoch was fenced before acceptance')
    _admission_session_current(binding)
    if row['state']=='CLOSED':raise ValueError('Original admission was closed before acceptance')
    return row

def _admission_accept(c,row,job_id):
    if row is not None:c.execute("UPDATE job_admissions SET state='ACCEPTED',job_id=?,updated=? WHERE submission_id=? AND state='OPEN'",(job_id,time.time(),row['submission_id']))

def admit(c,root,r):
    # Only the actual Supervisor allocation may issue cleanup provenance.
    for field in ('temporary_resource_scope','temporary_cleanup_pending','temporary_cleanup_retry_at','temporary_cleanup_recovery'):
        r.pop(field,None)
    if r.get('origin') == 'core_service':
        expected=Path(__file__).with_name('gxtxt_core_preview_service.py')
        if r.get('reference') != 'core-service:dataset-preview' or r.get('service_id') != 'dataset-preview' or hashlib.sha256(expected.read_bytes()).hexdigest()!=r.get('source_sha256'):
            raise ValueError('Invalid installed CORE service identity')
    elif r.get('origin') == 'scientific_provider':
        expected=Path(__file__).with_name('gxtxt_core_scientific_service.py')
        if r.get('reference')!='core-service:scientific-provider' or hashlib.sha256(expected.read_bytes()).hexdigest()!=r.get('source_sha256'):raise ValueError('Invalid scientific provider driver identity')
    elif r.get('reference','').startswith('core-service:'):raise ValueError('Private service admission required')
    prepared_parameters=_admission_prepared_parameters(root,r)
    parent=request_parent(c)
    r.pop('parent_job_id',None)
    if parent:r['parent_job_id']=parent['id']
    identity={k:r[k] for k in ('session','reference','source_sha256','parameters','execution_inputs')}
    if r.get('parameter_dataset'):
        identity['parameter_dataset'] = r['parameter_dataset']
    if r.get('parameter_schema'):identity['parameter_schema']=r['parameter_schema']
    if parent:identity['parent_job_id']=parent['id']
    identity['inputs']={k:{f:v for f,v in b.items() if f not in ('label','namespace')} for k,b in r['inputs'].items()}
    signature=hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    c.execute('BEGIN IMMEDIATE')
    try:
        admission=_admission_claim(c,root,r,prepared_parameters)
        if admission is not None and admission['state']=='ACCEPTED':
            previous=c.execute('SELECT * FROM jobs WHERE id=?',(admission['job_id'],)).fetchone()
            if previous is None:raise ValueError('Accepted admission history remains; Job payload is unavailable')
            c.execute('COMMIT');return status(previous)
        existing=c.execute('SELECT * FROM jobs WHERE signature=? AND state IN (?,?,?,?)',(signature,*ACTIVE)).fetchone()
        if existing:
            _admission_accept(c,admission,existing['id'])
            c.execute('COMMIT');d=status(existing);d['deduplicated']=True;return d
        p=policy(c)
        if c.execute('SELECT count(*) FROM jobs WHERE state IN (?,?,?,?)',ACTIVE).fetchone()[0]>=p['max_queue']:raise ValueError('Script queue admission limit reached')
        target=r.get('output',{}).get('dataset_id','')
        if target:
            for row in c.execute('SELECT * FROM jobs WHERE state IN (?,?,?,?)',ACTIVE):
                other=json.loads(row['record'])
                if other['session']==r['session'] and other.get('output',{}).get('dataset_id')==target:raise ValueError('Output Dataset reserved by active job '+row['id'])
        jobid=r['run_id'];r['policy']=p;r['signature']=signature
        c.execute('INSERT INTO jobs(id,signature,state,created,record) VALUES(?,?,?,?,?)',(jobid,signature,'QUEUED',time.time(),json.dumps(r)))
        _admission_accept(c,admission,jobid);c.execute('COMMIT')
        return status(c.execute('SELECT * FROM jobs WHERE id=?',(jobid,)).fetchone())
    except BaseException:
        if c.in_transaction:c.execute('ROLLBACK')
        raise
def ensure(root):
    # Fast attachment avoids spawning a throwaway daemon for every GUI poll or
    # duplicate submission. The kernel lock remains the final admission guard.
    with open(root/'supervisor.lock','a+b') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            from gxtxt_job_events import wake
            wake(root)
            return
        fcntl.flock(lock,fcntl.LOCK_UN)
    log=open(root/'supervisor.log','ab',buffering=0)
    subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'--root',str(root),'serve'],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,close_fds=True);log.close()
def diagnostic_event(r,event,**fields):
    path=Path(r['output_dir'])/'diagnostic.log'
    with path.open('a',encoding='utf-8') as stream:
        stream.write(json.dumps(dict(time=time.time(),job_id=r['run_id'],event=event,**fields),ensure_ascii=False)+'\n')

def write_report(r,state,reason):
    diagnostic_event(r,'terminal',state=state,reason=reason)
    cfg=configparser.ConfigParser(interpolation=None)
    cfg['execution']={k:str(v) for k,v in r.items() if isinstance(v,(str,int,float))}
    cfg['execution'].update(status='PASS' if state=='COMPLETED' else state,reason=reason,finished_at=str(time.time()),source_snapshot=r['snapshot'])
    cfg['parameters']={k:str(v) for k,v in r['parameters'].items()}
    text=io.StringIO();cfg.write(text);atomic_text(Path(r['output_dir'])/'execution.ini',text.getvalue())
def available_cpus():
    """Existing admission authority honors effective affinity and mounted cgroup quota."""
    count=max(1,os.cpu_count() or 1)
    try:count=min(count,len(os.sched_getaffinity(0)))
    except (AttributeError,OSError):pass
    locations=[Path('/sys/fs/cgroup')]
    try:
        for line in Path('/proc/self/cgroup').read_text().splitlines():
            _,controllers,relative=line.split(':',2)
            if not controllers or 'cpu' in controllers.split(','):
                locations.extend((Path('/sys/fs/cgroup')/relative.lstrip('/'),Path('/sys/fs/cgroup/cpu')/relative.lstrip('/')))
    except (OSError,ValueError):pass
    for root in locations:
        try:
            quota,period=(root/'cpu.max').read_text().split()
            if quota!='max':count=min(count,max(1,int(int(quota)/int(period))))
        except (OSError,ValueError,ZeroDivisionError):pass
        try:
            quota=int((root/'cpu.cfs_quota_us').read_text());period=int((root/'cpu.cfs_period_us').read_text())
            if quota>0:count=min(count,max(1,quota//period))
        except (OSError,ValueError,ZeroDivisionError):pass
    return max(1,count)

def physical_memory():
    amount=os.sysconf('SC_PHYS_PAGES')*os.sysconf('SC_PAGE_SIZE')
    for path in ('/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory/memory.limit_in_bytes'):
        try:
            limit=Path(path).read_text().strip()
            if limit!='max':amount=min(amount,int(limit))
        except (OSError,ValueError):pass
    return amount

def process_tree(pid):
    records={}
    boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            f=(path/'stat').read_text().rsplit(')',1)[1].split()
            records[int(path.name)]=(int(f[1]),int(f[2]),boot+':'+f[19],int(f[21])*os.sysconf('SC_PAGE_SIZE'),int(f[17]),(int(f[11])+int(f[12]))/os.sysconf('SC_CLK_TCK'),f[0])
        except (OSError,ValueError,IndexError):continue
    selected={pid}
    while True:
        more={p for p,v in records.items() if v[0] in selected or v[1]==pid}
        if more<=selected:break
        selected|=more
    return {p:records[p] for p in selected if p in records}

def usage(pid):
    tree={p:v for p,v in process_tree(pid).items() if v[6]!='Z'}
    return dict(rss_bytes=sum(v[3] for v in tree.values()),threads=sum(v[4] for v in tree.values()),processes=len(tree),cpu_seconds=sum(v[5] for v in tree.values()),identities={str(p):v[2] for p,v in tree.items()})

def request_parent(c):
    """Resolve an inherited Job identity only for its actual live process tree."""
    jid=os.environ.get('GXTXT_JOB_ID','')
    if not jid:return None
    row=c.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone()
    if row is None or row['state']!='RUNNING' or row['cancel']:
        raise ValueError('The submitting/waiting parent Job is not running')
    record=json.loads(row['record']);pid=row['pid'];caller=os.getppid()
    if not pid or process_identity(pid)!=record.get('pid_start') or caller not in process_tree(pid):
        raise ValueError('Caller does not belong to the claimed live parent Job')
    return row

def wait_begin(c,child_id):
    parent=request_parent(c)
    child=c.execute('SELECT * FROM jobs WHERE id=?',(child_id,)).fetchone()
    if child is None:raise ValueError('Unknown child Job')
    if parent is None:return dict(token='',parent_job_id='',child_job_id=child_id)
    record=json.loads(child['record']);owner=json.loads(parent['record'])
    if record.get('parent_job_id')!=parent['id'] or record['session']!=owner['session']:
        raise ValueError('A parent may yield its slot only to its own same-Session child')
    if child['state'] in TERMINAL:return dict(token='',parent_job_id=parent['id'],child_job_id=child_id)
    caller=os.getppid();start=process_identity(caller)
    if not start:raise ValueError('Waiting caller lifetime is unavailable')
    c.execute('BEGIN IMMEDIATE')
    try:
        if c.execute('SELECT 1 FROM job_waits WHERE parent_id=?',(parent['id'],)).fetchone():
            raise ValueError('Parent already has an active dependency wait')
        # Bound active waiting ancestry; historical asynchronous parent records
        # do not change canonical Job states or consume additional worker slots.
        seen={child_id};cursor=parent['id'];depth=1
        while True:
            if cursor in seen:raise ValueError('Job dependency cycle refused')
            seen.add(cursor)
            ancestor=c.execute('SELECT parent_id FROM job_waits WHERE child_id=?',(cursor,)).fetchone()
            if ancestor is None:break
            depth+=1;cursor=ancestor['parent_id']
        if depth>8:raise ValueError('At most eight active nested Job waits are supported')
        token=uuid.uuid4().hex
        c.execute('INSERT INTO job_waits VALUES(?,?,?,?,?,?)',(parent['id'],child_id,token,caller,start,time.time()))
        c.execute('COMMIT')
        return dict(token=token,parent_job_id=parent['id'],child_job_id=child_id)
    except BaseException:
        c.execute('ROLLBACK');raise

def wait_end(c,token):
    if not token:return dict(released=False)
    row=c.execute('SELECT * FROM job_waits WHERE token=?',(token,)).fetchone()
    if row is None:return dict(released=False)
    if row['caller_pid']!=os.getppid() or row['caller_start']!=process_identity(os.getppid()):
        raise ValueError('Dependency wait belongs to another caller lifetime')
    child=c.execute('SELECT state FROM jobs WHERE id=?',(row['child_id'],)).fetchone()
    if child is not None and child['state'] not in TERMINAL:
        raise ValueError('Cancel and drain the child before ending its dependency wait')
    c.execute('DELETE FROM job_waits WHERE token=?',(token,))
    return dict(released=True)

def dependency_maintenance(c):
    """Cancel owned descendants on failure/cancel; retire stale wait leases."""
    active=c.execute('SELECT * FROM jobs WHERE state IN (?,?,?,?)',ACTIVE).fetchall()
    # Iterate to propagate through queued descendants in this same scheduler
    # tick. Successful asynchronous submission does not cancel the child.
    for unused in range(len(active)+1):
        changed=False
        for row in active:
            parent_id=json.loads(row['record']).get('parent_job_id')
            if not parent_id:continue
            parent=c.execute('SELECT state,cancel FROM jobs WHERE id=?',(parent_id,)).fetchone()
            if parent is None or parent['cancel'] or parent['state'] in ('FAILED','CANCELLED','INTERRUPTED'):
                c.execute('UPDATE jobs SET cancel=1 WHERE id=? AND cancel=0',(row['id'],))
                changed|=bool(c.execute('SELECT changes()').fetchone()[0])
        if not changed:break
    waiting={};rows=c.execute('SELECT * FROM job_waits').fetchall()
    for row in rows:
        parent=c.execute('SELECT state,cancel FROM jobs WHERE id=?',(row['parent_id'],)).fetchone()
        child=c.execute('SELECT state,cancel,record FROM jobs WHERE id=?',(row['child_id'],)).fetchone()
        live=(parent is not None and parent['state']=='RUNNING' and not parent['cancel']
              and process_identity(row['caller_pid'])==row['caller_start'])
        owned=child is not None and json.loads(child['record']).get('parent_job_id')==row['parent_id']
        if live and owned and child['state'] in ACTIVE and not child['cancel']:
            waiting[row['parent_id']]=row['child_id'];continue
        if not live and owned and child['state'] in ACTIVE:
            c.execute('UPDATE jobs SET cancel=1 WHERE id=?',(row['child_id'],))
        # While cancellation drains an active child, the live parent remains
        # asleep and continues to reserve memory, but not an execution slot.
        if live and owned and child['state'] in ACTIVE:
            waiting[row['parent_id']]=row['child_id'];continue
        c.execute('DELETE FROM job_waits WHERE token=?',(row['token'],))
    return waiting

def owned_processes(r,pid):
    identities=dict(r.get('process_identities',{}))
    if pid and r.get('pid_start') and process_identity(pid)==r['pid_start']:
        identities.update({str(p):v[2] for p,v in process_tree(pid).items() if v[6]!='Z'})
    # If a guardian is forcibly killed, adopted descendants may no longer have
    # its PPID or process group. Match this job's inherited local execution
    # identity, never process names or a broad filename pattern.
    job=('GXTXT_JOB_ID='+r['run_id']).encode();root=('GXTXT_JOB_ROOT='+r.get('job_root','')).encode()
    if r.get('job_root'):
        for path in Path('/proc').iterdir():
            if not path.name.isdigit() or int(path.name)==os.getpid():continue
            try:
                if path.stat().st_uid!=os.getuid():continue
                env=(path/'environ').read_bytes().split(b'\0')
                if job in env and root in env:
                    identity=process_identity(path.name)
                    if identity:identities[path.name]=identity
            except (OSError,ValueError):continue
    r['process_identities']=identities
    return {int(p):start for p,start in identities.items() if start and process_identity(p)==start}

def terminate(r,pid,sig):
    identities=owned_processes(r,pid)
    # Nested process groups are still owned descendants. Start tokens prevent
    # PID reuse from targeting an unrelated user's process.
    # Signal descendants before the guardian. The guardian retains the scratch
    # lease and handles SIGTERM while draining its children.
    for child,start in sorted(identities.items(),key=lambda item:item[0]==pid):
        if child==pid and sig==signal.SIGKILL and any(p!=pid and process_identity(p)==s for p,s in identities.items()):continue
        if process_identity(child)==start:
            with contextlib.suppress(ProcessLookupError):os.kill(child,sig)

def reap_adopted(r,exclude=()):
    for child in r.get('process_identities',{}):
        if int(child) in exclude:continue
        with contextlib.suppress(ChildProcessError,ProcessLookupError):os.waitpid(int(child),os.WNOHANG)

def drain_tree(r,pid,timeout=4):
    terminate(r,pid,signal.SIGTERM)
    deadline=time.monotonic()+timeout
    force_at=time.monotonic()+min(1.,timeout/2)
    while time.monotonic()<deadline:
        reap_adopted(r,exclude=(pid,))
        if not owned_processes(r,pid):return True
        if time.monotonic()>=force_at:terminate(r,pid,signal.SIGKILL)
        time.sleep(.03)
    return not owned_processes(r,pid)


def _temporary_directory(path, private=False):
    text=os.fspath(path)
    if not os.path.isabs(text) or os.path.abspath(text)!=text or any(part in ('.','..') for part in text.split('/')):
        raise ValueError('Job temporary scope has a noncanonical directory')
    path=Path(text)
    for item in (*reversed(path.parents),path):
        if not stat.S_ISDIR(item.lstat().st_mode):raise ValueError('Job temporary scope has an aliased ancestor')
    value=path.lstat()
    if value.st_uid!=os.getuid() or (private and value.st_mode&0o022):raise ValueError('Job temporary scope ownership changed')
    return dict(path=text,dev=value.st_dev,ino=value.st_ino,uid=value.st_uid)

def _temporary_database(path):
    _temporary_directory(Path(path).parent,True)
    value=Path(path).lstat()
    if not stat.S_ISREG(value.st_mode) or value.st_nlink!=1 or value.st_uid!=os.getuid() or value.st_mode&0o022:
        raise ValueError('Job temporary registry identity unavailable')
    return dict(path=str(path),dev=value.st_dev,ino=value.st_ino,uid=value.st_uid)

def _temporary_resource_scope(root,r,manager,resource):
    binding={k:resource[k] for k in ('id','subsystem','category','job_id','session','owner_pid','owner_identity','path','envelope','identity','kind','managed','descendant_lease','created','lifetime')}
    if (binding['subsystem']!='script_jobs' or binding['category']!='temporary' or binding['job_id']!=r['run_id'] or
        binding['session']!=r['session'] or binding['owner_pid']!=r['worker_pid'] or binding['owner_identity']!=r['pid_start'] or
        type(r['worker_pid']) is not int or r['worker_pid']<1 or not re.fullmatch('[0-9a-f-]{36}:[0-9]+',r['pid_start']) or
        binding['lifetime']!='job' or binding['kind']!='directory' or binding['managed'] is not True or binding['descendant_lease'] is not True or
        binding['path']!=r['temp_dir'] or binding['envelope']!=r['temp_dir']):raise ValueError('Original temporary allocation binding differs')
    allocation=_temporary_directory(resource['path'],True)
    if resource['identity']!=[allocation['dev'],allocation['ino']]:raise ValueError('Original temporary allocation generation differs')
    return dict(schema='gxtxt.job_temporary_scope.v1',job_root=_admission_scope(root),session=_temporary_directory(r['session']),
                resource_root=_temporary_directory(manager.root,True),registry=_temporary_database(manager.root/'registry.sqlite3'),
                storage=_temporary_directory(manager.storage,True),allocation=allocation,binding=binding,source_sha256=r['source_sha256'])

def _temporary_scope_current(root,r,allocation=False):
    scope=r.get('temporary_resource_scope')
    fields={'schema','job_root','session','resource_root','registry','storage','allocation','binding','source_sha256'}
    if type(scope) is not dict or set(scope)!=fields or scope['schema']!='gxtxt.job_temporary_scope.v1':raise ValueError('Original temporary scope unavailable')
    if scope['job_root']!=_admission_scope(root) or r.get('job_root')!=str(root):raise ValueError('Original Job root generation changed')
    if scope['session']!=_temporary_directory(r['session']) or scope['source_sha256']!=r['source_sha256']:raise ValueError('Original Session/source binding changed')
    for key in ('resource_root','storage'):
        if scope[key]!=_temporary_directory(scope[key]['path'],True):raise ValueError('Original temporary root/storage changed')
    if scope['registry']!=_temporary_database(Path(scope['resource_root']['path'])/'registry.sqlite3'):raise ValueError('Original Resource database changed')
    binding=scope['binding']
    if (binding.get('id')!=r.get('temporary_resource') or binding.get('job_id')!=r.get('run_id') or binding.get('session')!=r.get('session') or
        binding.get('owner_pid')!=r.get('worker_pid') or binding.get('owner_identity')!=r.get('pid_start') or
        binding.get('path')!=r.get('temp_dir') or binding.get('envelope')!=r.get('temp_dir') or
        scope['allocation']['path']!=str(Path(scope['storage']['path'])/r['temporary_resource']) or
        binding.get('identity')!=[scope['allocation']['dev'],scope['allocation']['ino']]):raise ValueError('Original Job/resource binding changed')
    if allocation and scope['allocation']!=_temporary_directory(r['temp_dir'],True):raise ValueError('Original allocation generation changed')
    return scope

def _temporary_cleanup_indexes(c):
    # Existing journal metadata only; called by serve, never a status read.
    predicate="json_extract(record,'$.temporary_cleanup_pending')=1 AND state IN ('COMPLETED','FAILED','CANCELLED','INTERRUPTED')"
    c.execute("CREATE INDEX IF NOT EXISTS temporary_cleanup_due ON jobs(COALESCE(json_extract(record,'$.temporary_cleanup_retry_at'),0),id) WHERE "+predicate)
    c.execute("CREATE INDEX IF NOT EXISTS temporary_cleanup_root ON jobs(json_extract(record,'$.temporary_resource_scope.resource_root.path'),COALESCE(json_extract(record,'$.temporary_cleanup_retry_at'),0),id) WHERE "+predicate)

def terminal_temporary_maintenance(c,root,admission=None):
    """At most one original terminal temporary; never rerun science/publication."""
    now=time.time();where="json_extract(record,'$.temporary_cleanup_pending')=1 AND state IN ('COMPLETED','FAILED','CANCELLED','INTERRUPTED')"
    args=[]
    if admission is not None:
        if not isinstance(admission,str) or not os.path.isabs(admission) or os.path.abspath(admission)!=admission or '\x00' in admission:return None
        where+=" AND json_extract(record,'$.temporary_resource_scope.resource_root.path')=?"
        args=[admission]
    else:
        where+=" AND COALESCE(json_extract(record,'$.temporary_cleanup_retry_at'),0)<=?";args=[now]
    row=c.execute("SELECT * FROM jobs WHERE "+where+" ORDER BY COALESCE(json_extract(record,'$.temporary_cleanup_retry_at'),0),id LIMIT 1",args).fetchone()
    if row is None:return None
    r=json.loads(row['record']);manager=None;pending=True
    previous=r.get('temporary_cleanup_recovery',{})
    result=dict(status='protected',at=now,release_confirmed=previous.get('release_confirmed',False),cleanup_outcome=previous.get('cleanup_outcome','not_attempted'))
    from gxtxt_resource_manager import ResourceManager, _JobTemporaryDisposition
    try:
        if r.get('run_id')!=row['id'] or r.get('publication_recovery')!='PASS' or r.get('recovery_pending'):raise ValueError('Original terminal/publication recovery is incomplete')
        scope=_temporary_scope_current(root,r)
        process_record=dict(r);process_record['process_identities']=dict(r.get('process_identities',{}))
        if owned_processes(process_record,r.get('worker_pid')):raise RuntimeError('Worker descendants remain; temporary resources retained')
        manager=ResourceManager._open_existing(scope['resource_root']['path'],scope['storage']['path'],dict(root=scope['resource_root'],registry=scope['registry'],storage=scope['storage']))
        if str(manager.root)!=scope['resource_root']['path'] or str(manager.storage)!=scope['storage']['path']:raise ValueError('Original Resource authority changed')
        current=manager.inspect(r['temporary_resource'])
        # Compare immutable association before recognizing any owner decision.
        if any(current.get(k)!=v for k,v in scope['binding'].items()):raise ValueError('Original inspected Job/resource binding differs')
        if current.get('removed') is True:result['status']='already_removed_no_action';pending=False
        elif current.get('released') is True:result['status']='already_released_no_action';pending=False
        elif current.get('state') in ('retained_diagnostic','cache_reusable'):result['status']='owner_retained_no_action';pending=False
        else:
            _temporary_scope_current(root,r,True)
            manager.release(r['temporary_resource'],state='verified_orphan',_expected_job=scope['binding'])
            result['release_confirmed']=True;result['cleanup_outcome']='not_started'
            # Same original temporary owner only; no publication observation.
            _temporary_scope_current(root,r,True)
            result['cleanup_outcome']='unknown'
            cleaned=manager.cleanup([r['temporary_resource']]);r['resource_cleanup']=cleaned
            result['cleanup_outcome']='removed' if cleaned and cleaned[0]['result'] in ('removed','already_removed') else 'protected'
            result['status']='removed' if cleaned and cleaned[0]['result'] in ('removed','already_removed') else 'released_cleanup_protected'
            pending=False
        _temporary_scope_current(root,r)
    except _JobTemporaryDisposition as exc:
        result['status']=exc.disposition+'_no_action';pending=False
    except Exception as exc:
        result['error']=str(exc)[:2048]
    finally:
        if manager is not None:manager.close()
    r['temporary_cleanup_pending']=pending;r['temporary_cleanup_retry_at']=time.time()+30 if pending else 0;r['temporary_cleanup_recovery']=result
    # Cleanup is separate from science; never rewrite terminal state/reason/time.
    changed=c.execute('UPDATE jobs SET record=? WHERE id=? AND state=? AND finished IS ? AND record=?',
                      (json.dumps(r),row['id'],row['state'],row['finished'],row['record'])).rowcount
    return dict(id=row['id'],status=result['status'],pending=pending,metadata_updated=bool(changed))


def release_resources(r):
    from gxtxt_resource_manager import ResourceManager
    manager=ResourceManager(root=r.get('environment',{}).get('GXTXT_RESOURCE_ROOT'),storage_root=r.get('environment',{}).get('GXTXT_RESOURCE_STORAGE'))
    try:
        if owned_processes(r,r.get('worker_pid')):raise RuntimeError('Worker descendants remain; temporary resources retained')
        if r.get('temporary_resource'):
            manager.release(r['temporary_resource'],state='verified_orphan')
            r['resource_cleanup']=manager.cleanup([r['temporary_resource']])
        manager.observe(r['output_dir'],'script_jobs',category='protected_authoritative',job_id=r['run_id'],session=r['session'],recovery_required=True)
    finally:manager.close()

def publication_recover(r):
    # A retry must not retain an earlier PASS while recovery is unresolved.
    r['publication_recovery']='PENDING'
    framework=Path(__file__).resolve().parents[2]
    helper=framework/'core/tcl/script_job_recover.tcl'
    result=subprocess.run(['tclsh',str(helper),str(framework),r['session']],env={**os.environ,**r.get('environment',{})},capture_output=True,text=True,timeout=30)
    if result.returncode:raise RuntimeError('Publication recovery failed: '+result.stderr[-2000:])
    r['publication_recovery']='PASS'
    receipts=Path(r['output_dir'])/'published_datasets.json'
    if receipts.is_file():r['published_datasets']=json.loads(receipts.read_text())
    else:r['published_datasets']=[]

def progress(r):
    # Public Bridge progress is written to its diagnostic channel, while native
    # Octave progress uses the runner log. Read bounded tails from both owners.
    import re
    paths = [Path(r['log_path']), Path(r['output_dir'])/'bridge.log']
    paths = sorted((p for p in paths if p.is_file()), key=lambda p:p.stat().st_mtime_ns)
    for path in paths:
        try:
            with path.open('rb') as f:
                f.seek(max(0,os.fstat(f.fileno()).st_size-8192));lines=f.read().decode('utf-8','replace').splitlines()
        except FileNotFoundError:continue
        for line in reversed(lines):
            if line.startswith('@@GXTXT_PROGRESS_V1@@'):
                decode=lambda value:re.sub(r'\\([nrt\\])',lambda m:{'n':'\n','r':'\r','t':'\t','\\':'\\'}[m[1]],value)
                r['progress']={key:decode(value) for key,value in (field.split('=',1) for field in line.split('\t')[1:] if '=' in field)}
                break

def safe_report(r,state,reason):
    try:write_report(r,state,reason)
    except Exception as exc:r['report_error']=str(exc)

def terminal_commit(c,jid,r,state,reason):
    safe_report(r,state,reason)
    c.execute('UPDATE jobs SET state=?,finished=?,record=?,error=? WHERE id=?',
              (state,time.time(),json.dumps(r),reason,jid))

def module_projection(r):
    if not r.get('module_output'):return
    # Projection is derived UI convenience; immutable per-run files are always
    # authoritative. A failed projection cannot corrupt the scientific job.
    import shutil
    dest=Path(r['module_output']);dest.mkdir(parents=True,exist_ok=True)
    with (dest/'.script-result.lock').open('a+b') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        for name in ('execution.ini','python.log','octave.log','python_script_run_report.txt','octave_script_run_report.txt','executed_script.py','executed_script.m'):
            source=Path(r['output_dir'])/name
            if source.is_file():
                tmp=dest/(name+'.'+uuid.uuid4().hex+'.tmp')
                try:
                    shutil.copy2(source,tmp);os.replace(tmp,dest/name)
                finally:
                    with contextlib.suppress(FileNotFoundError):tmp.unlink()
        atomic_json(dest/'script_result.json',dict(run_id=r['run_id'],output_dir=r['output_dir']))

def finish_job(c,jid,r,state,reason,pid):
    r['terminal_intent']=state;r['terminal_reason']=reason
    c.execute('UPDATE jobs SET state="FINALIZING",record=?,error=? WHERE id=?',(json.dumps(r),reason,jid))
    if not drain_tree(r,pid):
        r['recovery_pending']='Worker descendants have not terminated; recovery and resource cleanup deferred'
        c.execute('UPDATE jobs SET record=?,error=? WHERE id=?',(json.dumps(r),r['recovery_pending'],jid))
        return False
    try:publication_recover(r)
    except Exception as exc:
        r['recovery_pending']=str(exc)
        c.execute('UPDATE jobs SET record=?,error=? WHERE id=?',(json.dumps(r),str(exc),jid))
        return False
    r.pop('recovery_pending',None)
    try:release_resources(r)
    except Exception as exc:
        r['resource_note']=str(exc)
        if r.get('temporary_resource_scope') and r.get('temporary_resource'):
            r['temporary_cleanup_pending']=True;r['temporary_cleanup_retry_at']=0
    safe_report(r,state,reason)
    try:module_projection(r)
    except Exception as exc:r['projection_error']=str(exc)
    terminal_commit(c,jid,r,state,reason)
    return True

def recover(c):
    for row in c.execute('SELECT * FROM jobs WHERE state IN ("PREPARING","RUNNING","FINALIZING")').fetchall():
        r=json.loads(row['record']);pid=row['pid']
        # FINALIZING was durably reached after observing the actual worker exit;
        # preserve that outcome across a crash in publication/report cleanup.
        state=r.get('terminal_intent','INTERRUPTED')
        reason=r.get('terminal_reason','Supervisor restarted; interrupted work was not replayed')
        try:finish_job(c,row['id'],r,state,reason,pid)
        except Exception as exc:
            r['recovery_pending']=str(exc)
            c.execute('UPDATE jobs SET state="FINALIZING",record=?,error=? WHERE id=?',(json.dumps(r),str(exc),row['id']))

def temporary_size(path):
    size=0
    if not path:return 0
    for base,dirs,files in os.walk(path,followlinks=False):
        dirs[:]=[d for d in dirs if not os.path.islink(os.path.join(base,d))]
        for name in files:
            try:
                st=os.stat(os.path.join(base,name),follow_symlinks=False)
                if stat.S_ISREG(st.st_mode):size+=st.st_size
            except FileNotFoundError:pass
    return size

def poll_job(c,jid,item):
    proc,r=item['proc'],item['record'];row=c.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone();now=time.time()
    # Poll first: a late Cancel after successful exit must not relabel completed
    # publication as cancelled when no signal was actually requested.
    rc=proc.poll()
    progress(r)
    if rc is None:
        u=usage(proc.pid);r['process_identities']={**r.get('process_identities',{}),**u.pop('identities')};r['usage']=u
        for k in ('rss_bytes','processes','threads'):r['peak_'+k]=max(r.get('peak_'+k,0),u[k])
        limit=''
        if now-row['started']>r['policy']['timeout_seconds']:limit='Job time limit exceeded'
        if u['rss_bytes']>r['policy']['memory_mib']*1024**2:limit='Job memory limit exceeded'
        if u['processes']>r['policy']['max_processes']:limit='Job process limit exceeded'
        if now-item.get('disk_check',0)>2:
            item['disk_check']=now;r['temporary_bytes']=temporary_size(r.get('temp_dir'))
            if r['temporary_bytes']>r['policy']['temp_mib']*1024**2:limit='Job temporary disk limit exceeded'
        if row['cancel'] or limit:
            if 'stop_time' not in item:
                item['stop_time']=now;item['reason']=limit or 'Cancellation requested';item['cancel_signalled']=bool(row['cancel'])
                r['stop_requested_at']=now;r['stop_reason']=item['reason'];r['cancel_signalled']=item['cancel_signalled']
                terminate(r,proc.pid,signal.SIGTERM)
            elif now-item['stop_time']>3:terminate(r,proc.pid,signal.SIGKILL)
        c.execute('UPDATE jobs SET record=? WHERE id=?',(json.dumps(r),jid))
        return False
    item['stream'].close();r['exit_code']=rc
    if row['cancel'] and not item.get('cancel_signalled'):r['late_cancel_request']=True
    state='CANCELLED' if item.get('cancel_signalled') else ('FAILED' if rc or item.get('reason') else 'COMPLETED')
    reason=item.get('reason','' if rc==0 else f'Worker exit status {rc}')
    return finish_job(c,jid,r,state,reason,proc.pid)

def launch_job(c,root,row):
    r=json.loads(row['record']);jid=row['id'];r['job_root']=str(root)
    for field in ('temporary_resource_scope','temporary_cleanup_pending','temporary_cleanup_retry_at','temporary_cleanup_recovery'):
        r.pop(field,None)
    c.execute('UPDATE jobs SET state="PREPARING",started=?,record=? WHERE id=?',(time.time(),json.dumps(r),jid))
    proc=stream=None
    try:
        if r.get('project_manifest'):
            from script_project import verify
            project,_,_=verify(Path(r['project_manifest']).parent)
            if project['sha256']!=r['source_sha256']:raise ValueError('Whole-project snapshot hash mismatch')
        elif hashlib.sha256(Path(r['snapshot']).read_bytes()).hexdigest()!=r['source_sha256']:raise ValueError('Source snapshot hash mismatch')
        env=dict(os.environ)
        # Optional diagnostics belongs to this submitted launch, not to the
        # possibly much older durable supervisor's inherited GUI environment.
        for key in ('GXTXT_STDERR_DIAGNOSTICS_DESCRIPTOR','GXTXT_STDERR_DIAGNOSTICS_LIBRARY'):env.pop(key,None)
        env.update(r.get('environment',{}));env.update(GXTXT_JOB_ID=jid,GXTXT_JOB_ROOT=str(root),GXTXT_PARALLEL_DEPTH='1',GXTXT_JOB_THREADS=str(r['policy']['threads']),GXTXT_JOB_INTERNAL_THREADS=str(r['policy']['threads']),GXTXT_SUPERVISOR_PID=str(os.getpid()),GXTXT_SUPERVISOR_START=process_identity(os.getpid()),PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1')
        for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):env[key]=str(r['policy']['threads'])
        if str(r.get('debug','0')) == '1':
            from gxtxt_debug_control import prepare
            prepare(r,env)
        directory=Path(r['output_dir'])
        atomic_json(directory/'streams.json',dict(schema='gxtxt.script_streams.v1',stdout='program.stdout',stderr='program.stderr',diagnostics='diagnostic.log'))
        for name in ('program.stdout','program.stderr','diagnostic.log'):
            with (directory/name).open('ab'):pass
        diagnostic_event(r,'launch',runtime=r['command'][0],source_sha256=r['source_sha256'])
        env['GXTXT_CAPTURE_DIR']=str(directory)
        stream=open(r['log_path'],'ab',buffering=0)
        command=[sys.executable,'-B',str(Path(__file__).with_name('gxtxt_job_worker.py')),r['runtime'],*r['command']]
        proc=subprocess.Popen(command,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,cwd=r['session'],env=env,start_new_session=True,close_fds=True)
        r['pid_start']=process_identity(proc.pid);r['worker_pid']=proc.pid;r['launched_at']=time.time()
        if not r['pid_start']:raise RuntimeError('Job guardian exited during preparation')
        # Persist the guardian before allocating/issuing its permit. A child in
        # the tiny spawn/record gap cannot execute science and exits on parent
        # loss; a recorded child is explicitly drained by recovery.
        c.execute('UPDATE jobs SET pid=?,record=? WHERE id=?',(proc.pid,json.dumps(r),jid))
        from gxtxt_resource_manager import ResourceManager
        manager=ResourceManager(root=env.get('GXTXT_RESOURCE_ROOT'),storage_root=env.get('GXTXT_RESOURCE_STORAGE'))
        try:
            resource=manager.allocate('script_jobs',job_id=jid,session=r['session'],kind='directory',owner_pid=proc.pid,
                                      expected_bytes=int(r.get('estimated_temporary_bytes',0)),descendant_lease=True)
            r['temporary_resource']=resource['id'];r['temp_dir']=resource['path']
            try:r['temporary_resource_scope']=_temporary_resource_scope(root,r,manager,resource)
            except Exception as exc:
                # Cleanup provenance is not permission to change scientific
                # launch semantics. An unproven birth remains non-recoverable.
                r['temporary_cleanup_recovery']=dict(status='birth_scope_unavailable',at=time.time(),error=str(exc)[:2048])
            # Normalize the actual shared authority into the durable request.
            r.setdefault('environment',{})['GXTXT_RESOURCE_ROOT']=str(manager.root)
            r['environment']['GXTXT_RESOURCE_STORAGE']=str(manager.storage)
        finally:manager.close()
        c.execute('UPDATE jobs SET state="RUNNING",record=? WHERE id=?',(json.dumps(r),jid))
        atomic_json(root/(jid+'.permit'),dict(pid=proc.pid,start=r['pid_start'],temp_dir=r['temp_dir'],
                    temp_identity=resource['identity'],resource_id=resource['id'],environment=r['environment']))
        return dict(proc=proc,record=r,stream=stream)
    except Exception as exc:
        reason='Launch failed: '+str(exc)
        if proc is not None:
            drain_tree(r,proc.pid)
            with contextlib.suppress(subprocess.TimeoutExpired):proc.wait(timeout=2)
        if stream is not None:stream.close()
        # Persist before any fallible report or resource cleanup, so no queued
        # restart can duplicate a partially launched worker.
        try:finish_job(c,jid,r,'FAILED',reason,proc.pid if proc else None)
        except Exception as cleanup:
            r['recovery_pending']=str(cleanup);r['terminal_intent']='FAILED';r['terminal_reason']=reason
            c.execute('UPDATE jobs SET state="FINALIZING",record=?,error=? WHERE id=?',(json.dumps(r),str(cleanup),jid))
        return None

def serve(root):
    lock=open(root/'supervisor.lock','a+b')
    c=None;event_server=None
    try:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        enable_subreaper()
        c=connect(root);recover(c);running={};last_session='';idle=time.monotonic();last_recovery=0
        _temporary_cleanup_indexes(c)
        from gxtxt_job_events import EventServer, sync_events
        event_server=EventServer(root,c)
        atomic_json(root/'supervisor.json',dict(pid=os.getpid(),pid_start=process_identity(os.getpid()),started=time.time()))
        while True:
            p=policy(c)
            dependency_maintenance(c)
            for jid,item in list(running.items()):
                try:
                    if poll_job(c,jid,item):del running[jid]
                except Exception as exc:
                    r=item['record'];r['supervision_error']=str(exc)
                    try:
                        if finish_job(c,jid,r,'FAILED','Job supervision failed: '+str(exc),item['proc'].pid):
                            item['proc'].wait(timeout=2);item['stream'].close();del running[jid]
                    except Exception as recovery:
                        r['recovery_pending']=str(recovery)
                        c.execute('UPDATE jobs SET state="FINALIZING",record=?,error=? WHERE id=?',(json.dumps(r),str(recovery),jid))
            # Previously crashed finalizations are retried without replaying the
            # script. Their active output reservation remains until recovery passes.
            temporary_due=time.monotonic()-last_recovery>2
            temporary_checked=False
            if temporary_due:
                for row in c.execute('SELECT * FROM jobs WHERE state="FINALIZING"').fetchall():
                    if row['id'] in running:continue
                    r=json.loads(row['record'])
                    try:finish_job(c,row['id'],r,r.get('terminal_intent','INTERRUPTED'),r.get('terminal_reason','Interrupted work recovery'),row['pid'])
                    except Exception as exc:
                        r['recovery_pending']=str(exc);c.execute('UPDATE jobs SET record=?,error=? WHERE id=?',(json.dumps(r),str(exc),row['id']))
                last_recovery=time.monotonic()
            for row in c.execute('SELECT * FROM jobs WHERE state="QUEUED" AND cancel=1').fetchall():
                terminal_commit(c,row['id'],json.loads(row['record']),'CANCELLED','Cancelled before execution')
            waiting=dependency_maintenance(c)
            if len(set(running)-set(waiting))<p['max_jobs']:
                rows=c.execute('SELECT * FROM jobs WHERE state="QUEUED" ORDER BY created').fetchall();rows.sort(key=lambda row:(row['id'] not in waiting.values(),json.loads(row['record'])['session']==last_session))
                for row in rows:
                    if len(set(running)-set(waiting))>=p['max_jobs']:break
                    pending=json.loads(row['record'])
                    reserved=sum(item['record']['policy']['memory_mib']*1024**2 for item in running.values())
                    cpus=sum(item['record']['policy']['threads'] for jid,item in running.items() if jid not in waiting)
                    if reserved+pending['policy']['memory_mib']*1024**2>physical_memory()*.8 or cpus+pending['policy']['threads']>available_cpus():
                        pending['queue_reason']='Waiting for CPU or memory reservation budget'
                        c.execute('UPDATE jobs SET record=? WHERE id=?',(json.dumps(pending),row['id']))
                        continue
                    if not temporary_checked:
                        env=pending.get('environment',{});target=None
                        if isinstance(env.get('GXTXT_RESOURCE_ROOT'),str) and env['GXTXT_RESOURCE_ROOT']:
                            target=os.path.abspath(env['GXTXT_RESOURCE_ROOT'])
                        if target is not None:
                            temporary_checked=terminal_temporary_maintenance(c,root,admission=target) is not None
                    last_session=pending['session']
                    item=launch_job(c,root,row)
                    if item is not None:running[row['id']]=item
            if temporary_due and not temporary_checked:terminal_temporary_maintenance(c,root)
            sync_events(c);event_server.step()
            pending=c.execute('SELECT count(*) FROM jobs WHERE state IN ("QUEUED","PREPARING","RUNNING","FINALIZING")').fetchone()[0]
            if running or pending or event_server.has_summary_clients():idle=time.monotonic()
            elif time.monotonic()-idle>60:
                # Close the idle-exit/submit race: submit cannot commit while this
                # check runs; release the daemon lock before allowing it to commit.
                c.execute('BEGIN IMMEDIATE')
                try:
                    empty=not c.execute('SELECT count(*) FROM jobs WHERE state IN ("QUEUED","PREPARING","RUNNING","FINALIZING")').fetchone()[0]
                    if empty:fcntl.flock(lock,fcntl.LOCK_UN)
                    c.execute('COMMIT')
                except BaseException:
                    c.execute('ROLLBACK');raise
                if empty:break
            if running or pending:
                time.sleep(.25)
            else:
                # Operational metadata listeners do not turn an idle owner into a
                # journal polling loop. Committed admission/recovery calls ensure,
                # which wakes this SAME socket; disposal restores normal idle exit.
                event_server.wait(None if event_server.has_summary_clients() else max(0,60-(time.monotonic()-idle)))
    finally:
        try:
            if event_server is not None:event_server.close()
        finally:
            try:
                if c is not None:c.close()
            finally:lock.close()

def request_process_group():
    """Own a bounded auxiliary request group before starting any subprocess.

    Tcl Script Job request cancellation may signal this group and its leader.
    Durable scientific Jobs keep their existing supervisor lifecycle.
    """
    if os.name == 'posix' and os.getpgrp() != os.getpid():
        os.setsid()


class AuxiliaryRequestError(RuntimeError):
    def __init__(self, category, message):
        super().__init__(message)
        self.category = category


def auxiliary_request_run(command, *, timeout_seconds=3, max_bytes=1048576, environment=None):
    """One bounded subprocess inside an explicitly owned auxiliary worker.

    Reuses the durable supervisor's identity, descendant and reaping primitives.
    The caller must establish its private request group before calling this.
    No scientific Job state or admission policy is introduced here.
    """
    if os.getpgrp() != os.getpid():
        raise RuntimeError('Auxiliary subprocess requires its own worker group')
    if not 0.05 <= timeout_seconds <= 300 or not 1024 <= max_bytes <= 16777216:
        raise ValueError('Invalid bounded auxiliary subprocess limits')
    enable_subreaper()
    record = dict(run_id='auxiliary', job_root='', process_identities={})
    with tempfile.TemporaryFile() as output:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=output,
                                 stderr=subprocess.STDOUT, env=environment)
        record['pid_start'] = process_identity(child.pid)
        started = time.monotonic()
        try:
            while child.poll() is None:
                record['process_identities'].update({str(pid):row[2] for pid,row in process_tree(os.getpid()).items() if pid != os.getpid() and row[6] != 'Z'})
                if output.tell() > max_bytes:
                    raise AuxiliaryRequestError('output_limit', 'Auxiliary command exceeded its output limit')
                if time.monotonic() - started >= timeout_seconds:
                    raise AuxiliaryRequestError('timeout', 'Auxiliary command timed out')
                time.sleep(.025)
            if output.tell() > max_bytes:
                raise AuxiliaryRequestError('output_limit', 'Auxiliary command exceeded its output limit')
            output.seek(0)
            text = output.read(max_bytes + 1).decode('utf-8', errors='replace')
            return dict(returncode=child.returncode, output=text, elapsed_ms=round((time.monotonic()-started)*1000))
        finally:
            # Include adopted descendants even when their original parent exited
            # before the next sample. The request worker is their subreaper.
            record['process_identities'].update({str(pid):row[2] for pid,row in process_tree(os.getpid()).items() if pid != os.getpid()})
            drain_tree(record, child.pid, timeout=.35)
            with contextlib.suppress(subprocess.TimeoutExpired): child.wait(timeout=.1)
            reap_adopted(record)


def tcl_result(value):
    import tkinter
    # Native Tcl chooses canonical braces/backslashes at each nesting level.
    # tkinter._join recursively backslash-quotes already quoted deep strings,
    # exponentially inflating authentic structured source responses.
    interpreter=tkinter.Tcl()
    interpreter.tk.wantobjects(False)
    def encode(item):
        if isinstance(item,dict):return interpreter.call('list',*(part for key,child in item.items() for part in (str(key),encode(child))))
        if isinstance(item,list):return interpreter.call('list',*(encode(child) for child in item))
        if item is None:return ''
        if isinstance(item,bool):return str(int(item))
        return str(item)
    return encode(value)
def read_request():
    import tkinter
    t=tkinter.Tcl()
    def d(v):
        a=t.splitlist(v);return dict(zip(a[::2],a[1::2]))
    r=d(sys.stdin.read())
    for key in ('parameters','output','execution_inputs','environment','parameter_dataset'):r[key]=d(r.get(key,''))
    r['parameter_schema']={k:d(v) for k,v in d(r.get('parameter_schema','')).items()}
    r['inputs']={k:d(v) for k,v in d(r.get('inputs','')).items()};r['command']=list(t.splitlist(r['command']))
    if '_tracked_admission' in r:r['_tracked_admission']=_admission_dict(r['_tracked_admission'])
    return r

def presentation_request():
    """The existing Tcl stdin protocol; bounded GUI metadata, never source/data."""
    import tkinter
    t=tkinter.Tcl();raw=sys.stdin.read(2097153)
    if len(raw.encode('utf-8'))>2097152:raise ValueError('Runner view request exceeds 2 MiB')
    parts=t.splitlist(raw)
    if len(parts)%2 or len(set(parts[::2]))!=len(parts)//2:raise ValueError('Invalid Runner view dictionary')
    request=dict(zip(parts[::2],parts[1::2]))
    for key in ('hidden_ids','ids','watched_ids'):
        import re
        request[key]=list(t.splitlist(request.get(key,'')))
        if len(request[key])>20000 or any(not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,191}',s) for s in request[key]):raise ValueError('Invalid Runner Job IDs')
    return request

def presentation_view(c,operation,request):
    """Read projection from the one Job journal, with transient visibility IDs."""
    if operation=='history_validate':
        ids=request['ids']
        for jid in ids:
            row=c.execute('SELECT state FROM jobs WHERE id=?',(jid,)).fetchone()
            if row is None:raise ValueError('Unknown Job ID: '+jid)
            if row['state'] not in TERMINAL:raise ValueError('Only finished Jobs can be hidden: '+jid)
        return ids
    mode=request.get('filter','All');scope=request.get('scope','all')
    if mode not in ('All','Active','Finished','Failed','Hidden'):raise ValueError('Invalid Runner state filter')
    if scope!='all' and (not Path(scope).is_absolute() or '\n' in scope or '\r' in scope):raise ValueError('Invalid Runner Session scope')
    show=int(request.get('show_hidden','0'));descending=int(request.get('descending','1'))
    offset=int(request.get('offset','0'));limit=int(request.get('limit','500'))
    if show not in (0,1) or descending not in (0,1) or offset<0 or not 1<=limit<=500:raise ValueError('Invalid Runner page request')
    sorts={'created':'j.created','name':"json_extract(j.record,'$.script_name')",'reference':"json_extract(j.record,'$.reference')",
        'language':"json_extract(j.record,'$.language')",'version':"json_extract(j.record,'$.script_version')",
        'revision':"CAST(json_extract(j.record,'$.script_revision') AS INTEGER)",'state':'j.state',
        'started':"COALESCE(json_extract(j.record,'$.launched_at'),j.started,j.created)",'finished':'j.finished',
        'duration':'COALESCE(j.finished,?)-COALESCE(j.started,j.created)',
        'session':"json_extract(j.record,'$.session')",'jobid':'j.id'}
    sort=request.get('sort','created')
    if sort not in sorts:raise ValueError('Invalid Runner sort')
    c.execute('CREATE TEMP TABLE view_hidden(id TEXT PRIMARY KEY)')
    c.executemany('INSERT OR IGNORE INTO view_hidden VALUES(?)',((jid,) for jid in request['hidden_ids']))
    terminal="j.state IN ('COMPLETED','FAILED','CANCELLED','INTERRUPTED')"
    hidden='(h.id IS NOT NULL AND '+terminal+')'
    source=' FROM jobs j LEFT JOIN view_hidden h ON h.id=j.id'
    where=["COALESCE(json_extract(j.record,'$.origin'),'user_script') != 'core_service'"];params=[]
    if scope!='all':where.append("json_extract(j.record,'$.session')=?");params.append(str(Path(scope).resolve()))
    clause=lambda conditions:' WHERE '+(' AND '.join(conditions) if conditions else '1')
    c.execute('BEGIN')
    try:
        total=c.execute('SELECT count(*) FROM jobs').fetchone()[0]
        scoped=c.execute('SELECT count(*)'+source+clause(where),params).fetchone()[0]
        hidden_count=c.execute('SELECT count(*)'+source+clause(where+[hidden]),params).fetchone()[0]
        if mode=='Active':where.append("j.state IN ('QUEUED','PREPARING','RUNNING','FINALIZING')")
        elif mode=='Finished':where.append(terminal)
        elif mode=='Failed':where.append("j.state='FAILED'")
        elif mode=='Hidden':where.append(hidden)
        if mode!='Hidden' and not show:where.append('NOT '+hidden)
        if operation=='history_candidates':
            ids=[r[0] for r in c.execute('SELECT j.id'+source+clause(where+[terminal,'NOT '+hidden])+' ORDER BY j.created,j.id LIMIT 20001',params)]
            if len(ids)>20000:raise ValueError('More than 20000 finished Jobs match; narrow the Session/state scope first')
            return ids
        count=c.execute('SELECT count(*)'+source+clause(where),params).fetchone()[0]
        offset=min(offset,((count-1)//limit)*limit) if count else 0
        order=sorts[sort]+(' DESC' if descending else ' ASC')+',j.id'
        arguments=params+([time.time()] if sort=='duration' else [])+[limit,offset]
        rows=c.execute('SELECT j.*,'+hidden+' AS view_hidden'+source+clause(where)+' ORDER BY '+order+' LIMIT ? OFFSET ?',arguments)
        jobs=[]
        for row in rows:
            item=status(row);item['hidden']=bool(row['view_hidden']);jobs.append(item)
        # Scientific refresh observes lifecycle independently of view filters.
        lifecycle={r['id']:dict(r) for r in c.execute("SELECT id,state,json_extract(record,'$.session') AS session FROM jobs WHERE state IN ('QUEUED','PREPARING','RUNNING','FINALIZING')")}
        for jid in request['watched_ids']:
            if jid in lifecycle:continue
            row=c.execute("SELECT id,state,json_extract(record,'$.session') AS session FROM jobs WHERE id=?",(jid,)).fetchone()
            if row:lifecycle[jid]=dict(row)
        return dict(jobs=jobs,lifecycle=list(lifecycle.values()),total_stored=total,total_scoped=scoped,hidden_scoped=hidden_count,matching=count,offset=offset,limit=limit)
    finally:c.execute('ROLLBACK')

def public_receipt(value):
    """Private debugger command credentials never belong in inspection/results."""
    if isinstance(value,dict):return {k:public_receipt(v) for k,v in value.items() if k not in {'debug_token','GXTXT_DEBUG_TOKEN'}}
    if isinstance(value,(list,tuple)):return [public_receipt(v) for v in value]
    return value

def main():
    a=argparse.ArgumentParser();a.add_argument('--root',required=True);a.add_argument('operation');a.add_argument('args',nargs='*');args=a.parse_args()
    if args.operation=='policy_read':
        if args.args:raise ValueError('Job policy read accepts no arguments')
        print(tcl_result(dict(ok=True,result=read_policy_root(Path(args.root)))));return
    if args.operation=='summary':
        if args.args:raise ValueError('Summary does not accept Job or Session identifiers')
        from gxtxt_job_events import read_summary_root
        print(tcl_result(dict(ok=True,result=read_summary_root(Path(args.root)))));return
    if args.operation in {'admission_begin','admission_resolve','admission_owner_open','admission_recover','admission_lookup','admission_wait'}:
        raw=sys.stdin.read(8388609)
        request=_admission_dict(raw)
        if args.operation in {'admission_begin','admission_resolve','admission_wait'}:
            binding,text,digest,expected=_admission_payload(request,Path(args.root).absolute())
        else:
            owner,text,key,expected=_admission_owner_payload(request,Path(args.root).absolute(),epoch=args.operation!='admission_owner_open',lookup=args.operation=='admission_lookup')
        if args.operation=='admission_owner_open':
            if args.args:raise ValueError('Original owner readiness accepts no flags')
            _admission_owner_session(owner)
            if expected is not None and _admission_scope(args.root)!=expected:raise ValueError('Original admission scope changed')
            root=Path(args.root).absolute() if expected is not None else root_path(args.root)
            observed=expected
        elif args.operation=='admission_begin':
            if args.args:raise ValueError('Tracked reservation accepts no flags')
            _admission_session_current(binding)
            if expected is None or _admission_scope(args.root)!=expected:raise ValueError('Tracked submission requires its durable original owner locator')
            root=Path(args.root).absolute()
            observed=expected
        else:
            required=2 if args.operation=='admission_resolve' else (1 if args.operation=='admission_recover' else 0)
            if args.operation=='admission_wait':
                if len(args.args)!=2 or not re.fullmatch('[A-Za-z0-9][A-Za-z0-9_.-]{0,191}',args.args[0]) or not re.fullmatch('[1-9][0-9]*',args.args[1]) or not 1<=int(args.args[1])<=180:raise ValueError('Invalid original observation arguments')
            elif args.operation=='admission_resolve':
                if len(args.args) not in {2,3} or any(x not in {'0','1'} for x in args.args[:2]) or (len(args.args)==3 and (not args.args[2] or len(args.args[2])>192 or any(ord(x)<32 for x in args.args[2]))):raise ValueError('Invalid original handling/control flags')
            elif len(args.args)!=required or any(x not in {'0','1'} for x in args.args):raise ValueError('Invalid original owner control flags')
            # Resolution never initializes a missing/replacement journal and
            # never consults current GUI/default destination configuration.
            root=Path(args.root).absolute();observed=_admission_scope(root)
            if expected is not None and observed!=expected:raise ValueError('Original admission scope changed')
        c=connect(root,existing_only=args.operation!='admission_owner_open' or expected is not None,expected_scope=observed,initialize=args.operation=='admission_owner_open')
        try:
            if args.operation=='admission_owner_open':result=admission_owner_open(c,root,request)
            elif args.operation=='admission_begin':result=admission_begin(c,root,request)
            elif args.operation=='admission_wait':result=admission_wait(c,root,request,args.args[0],int(args.args[1]))
            elif args.operation=='admission_lookup':result=admission_lookup(c,root,request)
            elif args.operation=='admission_recover':
                result=admission_recover(c,root,request,cancel=args.args[0]=='1')
                if result.get('cancel_requested_count'):
                    try:ensure(root)
                    except Exception as exc:result['cancellation_delivery_error']=str(exc)
            else:
                result=admission_resolve(c,root,request,close=args.args[0]=='1',cancel=args.args[1]=='1',handled_job_id=args.args[2] if len(args.args)==3 else None)
                if result.get('cancel_requested'):
                    try:ensure(root)
                    except Exception as exc:result['cancellation_delivery_error']=str(exc)
        finally:c.close()
        print(tcl_result(dict(ok=1,result=public_receipt(result))));return
    if args.operation in {'submit','admission_submit'}:
        # Read the private marker BEFORE any create-capable root/DB call. A
        # delayed tracked preparer may never initialize a replacement journal.
        submission=read_request()
        if args.operation=='admission_submit':
            if args.args or '_tracked_admission' not in submission:raise ValueError('Tracked submit requires its original reserved envelope')
            tracked=submission['_tracked_admission'];root=Path(args.root).absolute()
            binding,text,digest,expected=_admission_payload(tracked,root)
            if expected is None or _admission_scope(root)!=expected:raise ValueError('Tracked submit original database is missing or replaced')
            c=connect(root,existing_only=True,expected_scope=expected,initialize=False)
            try:
                result=admit(c,root,submission)
                if _admission_scope(root)!=expected:raise ValueError('Original admission database changed after acceptance')
                ensure(root)
            finally:c.close()
            print(tcl_result(dict(ok=1,result={key:result[key]for key in ('id','state','deduplicated')if key in result})));return
        if '_tracked_admission' in submission:raise ValueError('Tracked envelope requires the existing-only original admission route')
    root=root_path(args.root)
    if args.operation=='serve':serve(root);return
    if args.operation=='watch':
        from gxtxt_job_events import watch
        watch(root,args.args[0],int(args.args[1]) if len(args.args)>1 else 0);return
    if args.operation=='summary_watch':
        if len(args.args)>1:raise ValueError('Summary subscription accepts only a cursor')
        from gxtxt_job_events import watch_summary
        watch_summary(root,int(args.args[0]) if args.args else 0);return
    c=connect(root)
    try:
        if args.operation=='process_identity':
            if len(args.args)!=1 or not re.fullmatch(r'[1-9][0-9]*',args.args[0]):raise ValueError('process_identity requires one positive PID')
            result=process_identity(int(args.args[0]))
        elif args.operation=='client_owner_claim':
            if len(args.args)!=3:raise ValueError('client_owner_claim requires Job ID, expected JSON and proposed JSON')
            result=client_owner_claim(c,*args.args)
        elif args.operation=='submit':
            result=admit(c,root,submission);ensure(root)
        elif args.operation=='events':
            from gxtxt_job_events import read_events
            result=read_events(c,args.args[0],int(args.args[1]) if len(args.args)>1 else 0,int(args.args[2]) if len(args.args)>2 else 256)
        elif args.operation=='debug_capabilities':
            from gxtxt_debug_control import capabilities
            result=capabilities(args.args[0])
        elif args.operation=='list':result=[status(r) for r in c.execute("SELECT * FROM jobs WHERE COALESCE(json_extract(record,'$.origin'),'user_script') != 'core_service' ORDER BY created DESC LIMIT 100")]
        elif args.operation=='wait_begin':result=wait_begin(c,args.args[0]);ensure(root)
        elif args.operation=='wait_end':result=wait_end(c,args.args[0])
        elif args.operation in ('view_list','history_candidates','history_validate'):result=presentation_view(c,args.operation,presentation_request())
        elif args.operation in ('debug_read','debug_control'):
            row=c.execute('SELECT * FROM jobs WHERE id=?',(args.args[0],)).fetchone()
            if not row:raise ValueError('Unknown Debug Job')
            record=status(row)
            if str(record.get('debug','0'))!='1':raise ValueError('Job was not admitted in Debug mode')
            from gxtxt_debug_control import inspect,control
            result=inspect(record) if args.operation=='debug_read' else control(record,*args.args[1:])
        elif args.operation in ('describe','inspect','log_read','stream_read'):
            row=c.execute('SELECT * FROM jobs WHERE id=?',(args.args[0],)).fetchone()
            if not row:raise ValueError('Unknown job ID')
            result=status(row)
            dependency=c.execute('SELECT child_id FROM job_waits WHERE parent_id=?',(row['id'],)).fetchone()
            if dependency is not None:result['waiting_for_job']=dependency['child_id']
            if args.operation!='describe':
                from gxtxt_script_inspection import inspect_run, log_read
                if args.operation=='inspect':result=inspect_run(result['session'],result['id'],result)
                elif args.operation=='stream_read':result=log_read(result['session'],result['id'],result,*args.args[2:],stream_role=args.args[1])
                else:result=log_read(result['session'],result['id'],result,*args.args[1:])
        elif args.operation in ('inspect_run','run_log_read','run_stream_read'):
            from gxtxt_script_inspection import inspect_run, log_read
            session,run_id=args.args[:2]
            row=c.execute('SELECT * FROM jobs WHERE id=?',(run_id,)).fetchone()
            record=status(row) if row else None
            if record and Path(record['session']).resolve()!=Path(session).resolve():record=None
            result=inspect_run(session,run_id,record,verify=args.operation=='inspect_run')
            if args.operation=='run_log_read':result=log_read(session,run_id,result,*args.args[2:])
            elif args.operation=='run_stream_read':result=log_read(session,run_id,result,*args.args[3:],stream_role=args.args[2])
        elif args.operation=='run_summaries':
            from gxtxt_script_inspection import run_summaries
            result=run_summaries(args.args[0],[status(r) for r in c.execute("SELECT * FROM jobs WHERE json_extract(record,'$.session')=? LIMIT 4096",(str(Path(args.args[0]).resolve()),))])
        elif args.operation=='cancel':
            c.execute('UPDATE jobs SET cancel=1 WHERE id=? AND state IN (?,?,?,?)',(args.args[0],*ACTIVE));result={'cancel_requested':bool(c.execute('SELECT changes()').fetchone()[0])};ensure(root)
        elif args.operation=='recover':ensure(root);result={'recovery_requested':True}
        elif args.operation=='configure':
            p=policy(c)
            for field in args.args:
                k,v=field.split('=',1)
                if k not in p or int(v)<1:raise ValueError('Invalid job policy')
                p[k]=int(v)
            if p['memory_mib']*1024**2>physical_memory()*.8:raise ValueError('Per-job RAM reservation exceeds 80% of physical memory')
            if p['max_jobs']*p['threads']>available_cpus():raise ValueError('Concurrent thread budget exceeds available CPUs')
            c.execute('UPDATE settings SET value=? WHERE id=1',(json.dumps(p),));result=p
        else:raise ValueError('Unknown Job API operation')
    finally:c.close()
    print(tcl_result(dict(ok=1,result=public_receipt(result))))
if __name__=='__main__':
    os.umask(0o077)
    try:main()
    except Exception as exc:print(tcl_result(dict(ok=0,error=str(exc))));sys.exit(1)
