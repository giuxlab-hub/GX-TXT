"""Canonical optional UTF-8 encoding for existing Script Bridge String nodes.

The text codec has no API dispatch, resource or scientific authority.  Encoding
only NUL-bearing text avoids Octave JSON's NUL truncation while keeping legacy
plain String nodes unchanged.  Both endpoints must understand this facet.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import base64
import binascii


def pack(value):
    if not isinstance(value, str):
        raise ValueError('String payload must be text')
    if '\0' not in value:
        return {'kind': 'string', 'value': value}
    return {'kind': 'string', 'data_encoding': 'utf8-base64',
            'data': base64.b64encode(value.encode('utf-8')).decode('ascii')}


def unpack(node):
    if not isinstance(node, dict) or node.get('kind') != 'string':
        raise ValueError('Expected a String wire node')
    if 'data_encoding' not in node:
        if 'data' in node or not isinstance(node.get('value'), str):
            raise ValueError('Invalid plain String payload')
        return node['value']
    if (set(node) != {'kind', 'data_encoding', 'data'} or
            node['data_encoding'] != 'utf8-base64' or not isinstance(node['data'], str)):
        raise ValueError('Invalid or unknown String data encoding')
    try:
        raw = base64.b64decode(node['data'].encode('ascii'), validate=True)
        if base64.b64encode(raw).decode('ascii') != node['data']:
            raise ValueError('Noncanonical String Base64 payload')
        return raw.decode('utf-8')
    except (UnicodeError, binascii.Error) as error:
        raise ValueError('Invalid Base64 UTF-8 String payload') from error
