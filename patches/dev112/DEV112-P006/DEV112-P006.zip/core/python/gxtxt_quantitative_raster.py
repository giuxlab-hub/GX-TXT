"""Original raster samples inside the existing Scientific Execution Job owner.

This trusted provider accepts managed receipts, never caller paths or programs.
The C++17 CORE decoder extracts original typed channel samples. Public Numeric
APIs own all statistical facts; NumPy is used only for typed buffer transport.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from __future__ import annotations

import base64
import hashlib
import json
import math
import re
import stat
import time

from gxtxt_scientific_execution import tdict

SCHEMA = 'gxtxt.quantitative_raster.v1'
MAX_ENCODED = 64 * 1024 * 1024
MAX_DECODED = 128 * 1024 * 1024
MAX_PIXELS = 16777216
MAX_DIMENSION = 16384
MAX_ROW = 1048576
MAX_METADATA = 32768
MAX_SECONDS = 120
PARAMETERS = {'operation', 'source_resource', 'source_dataset_id',
              'expected_sha256', 'request_guard', 'x', 'y', 'width', 'height',
              'channels', 'frame', 'histogram_mode', 'bins',
              'domain_low', 'domain_high'}


class RasterError(ValueError):
    """Finite provider error codes remain distinguishable in the existing log."""

    def __init__(self, code, message):
        super().__init__('GXTXT:QuantitativeRaster:' + code + ': ' + message)


def require(condition, code, message):
    if not condition:
        raise RasterError(code, message)


class Deadline:
    """Cooperative elapsed bound; blocking calls retain the guardian's policy."""

    def __init__(self):
        self.started = time.monotonic()

    def check(self):
        require(time.monotonic() - self.started < MAX_SECONDS,
                'TIMEOUT', 'Cooperative worker elapsed limit reached')


class Progress:
    """Existing Job log protocol; row/page updates are limited to four per second."""

    def __init__(self):
        self.last_emit = -math.inf
        self.stage = ''
        self.message = ''
        self.current = self.total = 0

    def phase(self, stage, message, total=0, state='running', current=0):
        self.stage, self.message = stage, message
        self.current, self.total = current, total
        self.update(current, state=state, force=True)

    def update(self, current, state='running', force=False):
        self.current = current
        now = time.monotonic()
        if not force and now - self.last_emit < 0.25:
            return
        determinate = self.total > 0
        fields = dict(stage=self.stage, message=self.message,
                      mode='determinate' if determinate else 'indeterminate',
                      current=current, total=self.total,
                      percent=100 * min(current, self.total) / self.total if determinate else 0,
                      state=state)
        print('@@GXTXT_PROGRESS_V1@@\t' + '\t'.join(
            key + '=' + str(value) for key, value in fields.items()), flush=True)
        self.last_emit = now

    def step(self):
        self.update(self.current + 1)


def integer(value, name, low, high):
    require(type(value) is int and low <= value <= high,
            'PARAMETER', name + ' requires an exact bounded integer')
    return value


def materialize(context, parameters, deadline, progress):
    """Reuse public managed pages and Job scratch, without a second store."""
    import gxtxt

    receipt = tdict(parameters['source_resource'])
    required = {'api_id', 'document_id', 'owner_generation', 'sha256',
                'size_bytes', 'metadata'}
    require(set(receipt) == required
            and receipt['api_id'] == 'INTERACTIVE_DOCUMENT_RESOURCE_API_v1',
            'SOURCE', 'An exact managed original-source receipt is required')
    require(receipt['sha256'] == parameters['expected_sha256'],
            'SOURCE_SHA', 'Managed source SHA differs from the admitted source')
    try:
        size = int(receipt['size_bytes'])
    except (TypeError, ValueError):
        raise RasterError('SOURCE', 'Invalid managed source byte size') from None
    require(1 <= size <= MAX_ENCODED, 'LIMIT', 'Encoded source exceeds 64 MiB')
    receipt['size_bytes'] = size
    receipt['metadata'] = tdict(receipt['metadata'])
    source = context.scratch / 'quantitative-source.bin'
    digest = hashlib.sha256()
    progress.phase('materialize', 'Read original managed source bytes', size, 'start')
    with source.open('xb') as stream:
        for offset in range(0, size, MAX_ROW):
            deadline.check()
            count = min(MAX_ROW, size - offset)
            encoded = gxtxt.gxtxt_api_call('MANAGED_RESOURCE_API_v1', 'read',
                                         [receipt, offset, count])
            require(isinstance(encoded, str) and len(encoded) <= 4 * ((count + 2) // 3),
                    'SOURCE', 'Managed source page exceeds its byte contract')
            try:
                raw = base64.b64decode(encoded, validate=True)
            except (ValueError, TypeError):
                raise RasterError('SOURCE', 'Malformed managed source page') from None
            require(len(raw) == count, 'SOURCE', 'Incomplete managed source page')
            stream.write(raw)
            digest.update(raw)
            progress.update(offset + count)
    require(digest.hexdigest() == parameters['expected_sha256'],
            'SOURCE_SHA', 'Materialized original source SHA differs')
    deadline.check()
    return source


def numeric_scalar(value, name, integer_value=False):
    """Validate public Numeric facts at the finite raster wire boundary."""
    import numpy as np

    if isinstance(value, np.generic):
        value = value.item()
    require(type(value) in (int, float) and math.isfinite(value),
            'NUMERIC_OUTPUT', 'Numeric fact must be finite: ' + name)
    if integer_value:
        require(value == int(value) and 0 <= value <= MAX_PIXELS,
                'NUMERIC_OUTPUT', 'Numeric count is outside the sample contract: ' + name)
        return int(value)
    return value


COUNT_FIELDS = ('total_count', 'finite_count', 'nan_count',
                'positive_inf_count', 'negative_inf_count')


def numeric_statistics(values, channel):
    import gxtxt

    facts = gxtxt.gxtxt_api_call('NUMERIC_API_v1', 'statistics_summary',
                                [values, {'contract_version': 1}])
    require(isinstance(facts, dict)
            and facts.get('schema') == 'gxtxt.numeric.statistics_summary.v1',
            'NUMERIC_OUTPUT', 'Public Numeric summary contract differs')
    result = {key: numeric_scalar(facts[key], key, True) for key in COUNT_FIELDS}
    require(result['total_count'] == values.size,
            'NUMERIC_OUTPUT', 'Public Numeric sample count differs from extracted shape')
    result.update(channel=channel, availability=facts['availability'])
    require(facts['availability'] in ('available', 'no_finite_samples')
            and facts['variance'] == 'population'
            and facts['nonfinite_policy'] == 'exclude_and_count',
            'NUMERIC_OUTPUT', 'Public Numeric statistics semantics differ')
    for key in ('minimum', 'maximum', 'mean', 'stddev'):
        if facts['availability'] == 'no_finite_samples':
            require(result['finite_count'] == 0, 'NUMERIC_OUTPUT',
                    'Undefined Numeric facts have finite samples')
            result[key] = None
        else:
            result[key] = numeric_scalar(facts[key], key)
    return result, facts['arithmetic']


def extraction(context, source, parameters):
    """Call one fixed CORE native tool; only the Job owns these file paths."""
    from pathlib import Path

    destination = context.scratch / 'quantitative-native'
    destination.mkdir(mode=0o700)
    expected_tool = Path(__file__).resolve().parents[1] / 'quantitative_raster_native' / 'gxtxt_quantitative_extract'
    require(context.tools.get('quantitative_raster_native') == str(expected_tool),
            'BACKEND', 'Native extraction tool differs from the bundled CORE owner')
    arguments = [str(source), parameters['expected_sha256'], str(destination),
                 parameters['operation']]
    for key, low in (('x', 0), ('y', 0), ('width', 1), ('height', 1)):
        arguments.append(str(integer(parameters[key], key, low, MAX_DIMENSION)))
    arguments.extend([parameters['channels'], str(parameters['frame'])])
    reply = context.run('quantitative_raster_native', arguments)
    require(not reply['truncated'] and len(reply['stdout'].encode('utf-8')) <= MAX_METADATA,
            'DECODE', 'Native extractor metadata exceeds its bounded contract')
    facts = json.loads(reply['stdout'])
    require(isinstance(facts, dict)
            and facts.get('schema') == 'gxtxt.quantitative_raster.extract.v1',
            'DECODE', 'Native extraction contract differs')
    metadata = facts['metadata']
    dtype = {'uint8': '<u1', 'uint16': '<u2', 'int16': '<i2', 'float32': '<f4'}.get(metadata['dtype'])
    require(dtype is not None,
            'DECODE', 'Native extraction sample type differs')
    return facts, destination, dtype


def run(context):
    """Trusted execution adapter; public Numeric owns every statistical fact."""
    import gxtxt
    import numpy as np

    deadline = Deadline()
    progress = Progress()
    parameters = dict(operation='describe', request_guard='', x=0, y=0,
                      width=1, height=1, channels='all', frame=0,
                      histogram_mode='native', bins=256,
                      domain_low=0, domain_high=256)
    require(set(context.parameters) <= PARAMETERS, 'PARAMETER', 'Unknown quantitative parameter')
    parameters.update(context.parameters)
    for key in ('source_resource', 'source_dataset_id', 'expected_sha256', 'channels'):
        require(isinstance(parameters.get(key), str) and bool(parameters[key])
                and len(parameters[key]) <= 8192 and '\x00' not in parameters[key],
                'PARAMETER', 'Missing or invalid ' + key)
    require(re.fullmatch('[0-9a-f]{64}', parameters['expected_sha256']) is not None,
            'SOURCE_SHA', 'An exact lowercase source SHA256 is required')
    require(isinstance(parameters['request_guard'], str)
            and len(parameters['request_guard']) <= 8192 and '\x00' not in parameters['request_guard'],
            'PARAMETER', 'Invalid opaque request guard')
    operation = parameters['operation']
    require(operation in ('describe', 'pixel', 'statistics', 'histogram'),
            'OPERATION', 'Unknown finite quantitative operation')
    integer(parameters['frame'], 'frame', 0, 0)
    started = time.perf_counter()
    source = materialize(context, parameters, deadline, progress)
    materialize_ms = (time.perf_counter() - started) * 1000
    progress.phase('decoder_initialization', 'Extract original samples with the CORE native decoder')
    extracted, destination, dtype = extraction(context, source, parameters)
    deadline.check()
    roi = extracted['roi']
    buffers = extracted['buffers']
    require(isinstance(buffers, list) and len(buffers) <= 4
            and (operation == 'describe' or bool(buffers)),
            'DECODE', 'Native channel buffer count differs')
    metadata = dict(extracted['metadata'], intensity_unit='raw_sample',
                    spatial_unit='source_pixel', origin='top_left',
                    bounds='half_open_strict_containment',
                    color_conversion=False, luminance_conversion=False,
                    normalization='none', alpha_weighting=False,
                    physical_calibration_inferred=False,
                    native_precision_preserved=True,
                    numerical_api='NUMERIC_API_v1', numerical_contract_version=1)
    result = dict(schema=SCHEMA, source_dataset_id=parameters['source_dataset_id'],
                  source_sha256=parameters['expected_sha256'], operation=operation,
                  request_guard=parameters['request_guard'], metadata=metadata, roi=roi)
    if buffers:
        gxtxt.gxtxt_api_require([{'api_id': 'NUMERIC_API_v1', 'api_version': 1,
                                 'provider_id': 'math.numeric'}])
    summaries, pixels_out = [], []
    counts = None
    arithmetic = None
    progress.phase('measurement', 'Compute through the public Numeric API', len(buffers))
    started = time.perf_counter()
    for index, descriptor in enumerate(buffers):
        deadline.check()
        require(descriptor['file'] == 'samples-' + str(index) + '.bin'
                and descriptor['dtype'] == metadata['dtype'],
                'DECODE', 'Native channel descriptor differs')
        size = integer(descriptor['elements'], 'elements', 1, MAX_PIXELS)
        require(size == roi['width'] * roi['height'], 'DECODE', 'Native ROI shape differs')
        path = destination / descriptor['file']
        info = path.lstat()
        require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                and info.st_size == size * np.dtype(dtype).itemsize
                and descriptor['size_bytes'] == info.st_size,
                'DECODE', 'Native sample buffer is not an exact owned regular file')
        values = np.memmap(path, dtype=dtype, mode='r', shape=(size,))
        try:
            if operation in ('pixel', 'statistics'):
                facts, arithmetic = numeric_statistics(values, descriptor['channel'])
                if operation == 'pixel':
                    require(size == 1, 'DECODE', 'Pixel buffer must contain exactly one sample')
                    kind = 'finite'
                    for field in ('nan', 'positive_inf', 'negative_inf'):
                        if facts[field + '_count']:
                            kind = field
                    pixels_out.append(dict(channel=descriptor['channel'], classification=kind,
                                           value=values[0].item() if kind == 'finite' else None))
                else:
                    summaries.append(facts)
            elif operation == 'histogram':
                require(len(buffers) == 1, 'CHANNEL', 'Histogram requires one original channel')
                options = {'contract_version': 1, 'mode': parameters['histogram_mode']}
                if options['mode'] == 'bounded':
                    options.update(bins=parameters['bins'], domain_low=parameters['domain_low'],
                                   domain_high=parameters['domain_high'])
                facts = gxtxt.gxtxt_api_call('NUMERIC_API_v1', 'histogram_summary', [values, options])
                require(isinstance(facts, dict)
                        and facts.get('schema') == 'gxtxt.numeric.histogram_summary.v1',
                        'NUMERIC_OUTPUT', 'Public Numeric histogram contract differs')
                counts = np.asarray(facts.pop('counts'))
                require(counts.dtype.name == 'uint64' and counts.size <= 65536
                        and counts.size == facts['bins'] and facts['dtype'] == metadata['dtype']
                        and not np.any(counts > MAX_PIXELS),
                        'NUMERIC_OUTPUT', 'Public Numeric histogram counts differ')
                for key in COUNT_FIELDS + ('in_range_count', 'underflow_count', 'overflow_count', 'bins'):
                    facts[key] = numeric_scalar(facts[key], key, True)
                require(facts['total_count'] == size, 'NUMERIC_OUTPUT', 'Histogram source count differs')
                result['histogram'] = dict(facts, channel=descriptor['channel'])
            else:
                raise RasterError('DECODE', 'Describe must not extract sample buffers')
        finally:
            values._mmap.close()
        progress.update(index + 1)
    if operation == 'pixel':
        result['pixel'] = dict(x=roi['x'], y=roi['y'], channels=pixels_out)
    elif operation == 'statistics':
        result['statistics'] = dict(channels=summaries, variance='population',
                                    nonfinite_policy='exclude_and_count_per_channel', arithmetic=arithmetic)
    measurement_ms = (time.perf_counter() - started) * 1000
    timings = extracted['timings_ms']
    result['timings_ms'] = dict(materialize=materialize_ms,
                               decoder_initialization=timings['decoder_initialization'],
                               native_scanline_decode=timings['native_scanline_decode'],
                               native_extraction=timings['extraction'],
                               measurement_including_row_decode=measurement_ms + timings['native_scanline_decode'],
                               measurement_excluding_row_decode=measurement_ms)
    require(all(math.isfinite(value) and value >= 0 for value in result['timings_ms'].values()),
            'INTERNAL', 'Quantitative phase timings must be finite and nonnegative')
    deadline.check()
    encoded = (json.dumps(result, ensure_ascii=False, allow_nan=False,
                          separators=(',', ':')) + '\n').encode('utf-8')
    require(len(encoded) <= MAX_METADATA, 'LIMIT', 'Measurement metadata exceeds 32 KiB')
    with (context.output / 'measurement.json').open('xb') as output:
        output.write(encoded)
    if counts is not None:
        with (context.output / 'histogram.u64').open('xb') as output:
            np.asarray(counts, dtype='<u8').tofile(output)
    deadline.check()
    context.publish_output('measurement.json', 'measurement', 'json')
    if counts is not None:
        context.publish_output('histogram.u64', 'histogram', 'uint64_le')
    context.summary(dict(validation='validated_structure', schema=SCHEMA,
                         source_dataset_id=parameters['source_dataset_id'],
                         source_sha256=parameters['expected_sha256'],
                         operation=operation, request_guard=parameters['request_guard'],
                         native_precision_preserved=True, numerical_api='NUMERIC_API_v1'))
    progress.phase('complete', 'Original source measurement completed', 1, 'completed', 1)
