"""Original component/design operations; declaration DATA is not invocation.

Native validation, editing, bounds, defaults and local mutation stay in CORE.
The existing Viewer Workspace shape owns all declared design field annotations.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import tkinter
from gxtxt_script_bridge_server import BridgeError
from gxtxt_script_values_v1 import descriptor, invoke as _invoke, arguments, text

DESIGN_OPERATIONS = {
    'viewerGuiDesignAnalysisProfile': ['design', 'form', 'properties'],
    'viewerGuiDesignHandlerSource': ['module', 'provider'],
    'viewerGuiDesignModelCreate': ['design'],
    'viewerGuiDesignModelEdit': ['model', 'operation', 'args...'],
    'viewerGuiDesignValidate': ['design'],
    'viewerGuiIconEdit': ['design', 'operation', 'args...'],
    'viewerGuiIconsValidate': ['icons'],
    'viewerGuiTestFixtureValidate': ['window', 'options'],
}


def declarations():
    result = {}
    for name, fields in DESIGN_OPERATIONS.items():
        contract = ('Exact uint8 bytes from original registered fixed handlers.tcl; no evaluation' if name.endswith('HandlerSource') else
                    'Original boolean local fixture predicate only; true grants no replay/Window/command authority' if name.endswith('TestFixtureValidate') else
                    'Complete original typed design/model/icon map through its existing declared Workspace codec; no callbacks or rendering')
        row = descriptor(name, fields, contract)
        row['host_command'] = '::GX::' + name
        if name in ('viewerGuiDesignModelEdit', 'viewerGuiIconEdit'):
            row['arguments'][-1]['required'] = False
            row['argument_convention'] = 'model/design, original selector, then each original ordered selector argument; no reduced selector whitelist'
            row['variadic'] = True
        result[name] = row
    return result


def _raw(host, value):
    return arguments(host, [value])[0]


def _pack(host, value):
    packed = host.tcl.call('::GX::ScriptValueTransportV1::pack', value)
    return {str(k): str(host.tcl.call('format', '%s', v)) for k, v in host.as_dict(packed).items()}


def _string(host, value):
    raw = _pack(host, value)
    value = text(raw)
    try:
        value.encode('utf-8')
    except UnicodeError:
        return raw
    return value


def _model(host, raw):
    fields = host.as_dict(raw)
    gui = host.modules['VIEWER_GUI_HOST_API_v1']
    result = {}
    for key, value in fields.items():
        if key in ('design', 'saved'):
            # Encode each ORIGINAL field separately; never validate saved again
            # or substitute the updated design for the supplied saved value.
            result[key] = gui._design(host, value)
        elif key in ('past', 'future'):
            result[key] = [gui._design(host, item) for item in host.as_list(value)]
        elif key == 'revision':
            result[key] = int(host.tcl.call('format', '%s', value))
        elif key == 'schema':
            result[key] = _string(host, value)
        else:
            result[key] = _pack(host, value)  # Original open model metadata.
    return result


def _icons(host, raw):
    shape = ['map', ['record', {
        'title':'text', 'category':'text', 'license':'text', 'source_format':'text',
        'source_data':'text', 'sha256':'text', 'png':'text', 'png_sha256':'text',
        'width':'int', 'height':'int', 'alpha':'bool'}]]
    typed = host.call('::GX::nativeWorkspaceEncode', shape, raw)
    return host.modules['VIEWER_GUI_HOST_API_v1']._typed(host, typed)


def _spec(host, raw):
    fields = host.as_dict(raw)
    original_properties = fields['properties']
    try:
        properties = host.as_dict(original_properties)
        for key in properties:
            key.encode('utf-8')
    except (tkinter.TclError, UnicodeError):
        # Register accepts opaque properties. A result converter must not
        # turn its successful local mutation into a dictionary/type refusal.
        properties = _pack(host, original_properties)
    except BridgeError as error:
        # Host.as_dict uses this exact error for an odd-length Tcl dictionary.
        # Other Bridge failures keep their ordinary authority/error behavior.
        if (error.identifier != 'GXTXT:ScriptBridge:RemoteError' or
                str(error) != 'public API returned an invalid dictionary'):
            raise
        properties = _pack(host, original_properties)
    else:
        properties = {str(k): _pack(host, v) for k, v in properties.items()}
    return {'properties': properties,
            'instructions': _string(host, fields['instructions']),
            'states': [_string(host, v) for v in host.as_list(fields['states'])]}


def _public_strings(host, value):
    # Retain rare non-scalar native code units as explicit whole values; never
    # emit invalid UTF-8 JSON, replacement characters or guessed field types.
    if isinstance(value, str):
        try:
            value.encode('utf-8')
        except UnicodeError:
            return _pack(host, value)
        return value
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            key.encode('utf-8')  # An unrepresentable map key needs whole-value output.
            result[key] = _public_strings(host, item)
        return result
    if isinstance(value, list):
        return [_public_strings(host, item) for item in value]
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return _pack(host, value)


def component(host, operation, values):
    command = {'catalog':'viewerGuiComponentDemoCatalog', 'register':'viewerGuiComponentDemoRegister'}[operation]
    def convert(host, whole):
        raw = _raw(host, whole)
        if operation == 'register':
            # The ORIGINAL dict-set return is the ENTIRE current spec map.
            return {str(k): _spec(host, v) for k, v in host.as_dict(raw).items()}
        result = {}
        gui = host.modules['VIEWER_GUI_HOST_API_v1']
        for kind, row in host.as_dict(raw).items():
            fields = host.as_dict(row)
            capmap = gui._capabilities(host, host.tcl.call('dict', 'create', kind, fields['capability']))
            item = {'capability': capmap[str(kind)],
                    'fixture_version': int(host.tcl.call('format','%s',fields['fixture_version'])),
                    'provenance': _string(host, fields['provenance']),
                    'source_identity': _string(host, fields['source_identity'])}
            if 'example' in fields: item['example'] = _spec(host, fields['example'])
            if 'gap' in fields: item['gap'] = _string(host, fields['gap'])
            result[str(kind)] = item
        return result
    return _invoke(host, 'VIEWER_COMPONENT_DEMO_API_v1', command, values, convert, public_operation=operation)


def design(host, operation, values):
    def convert(host, whole):
        if operation == 'viewerGuiDesignHandlerSource':
            if whole['format'] != 'gxtxt.bytes.hex.v1':
                raise ValueError('Original handler source lost its binary result type')
            data = bytes.fromhex(whole['lexeme'])
            return host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(data)
        raw = _raw(host, whole)
        gui = host.modules['VIEWER_GUI_HOST_API_v1']
        if operation == 'viewerGuiTestFixtureValidate':
            return bool(host.tcl.getboolean(raw))
        if operation in ('viewerGuiDesignModelCreate', 'viewerGuiDesignModelEdit'):
            value = _model(host, raw)
        elif operation == 'viewerGuiIconsValidate':
            value = _icons(host, raw)
        else:
            value = gui._design(host, raw)
        try:
            return _public_strings(host, value)
        except UnicodeError:
            return whole  # Complete original value, no lossy map-key conversion.
    return _invoke(host, 'VIEWER_GUI_HOST_API_v1', operation, values, convert)
