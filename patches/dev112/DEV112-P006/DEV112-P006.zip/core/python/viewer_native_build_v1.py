"""Fixed native-task targets in the existing Viewer Project builder.

This builds source-bound artifacts only. Existing Scientific Execution and the
Job Supervisor are the sole execution, event, cancellation and result owners.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
import os
import platform
import tempfile
from pathlib import Path

from gxtxt_cpp_policy import COMPILER, DEVELOPMENT, FLAGS, bounded_command, digest, source_includes
from gxtxt_native_job import native_runtime_dependencies


def build(project, stage, meta, files):
    sdk = DEVELOPMENT / 'sdk/gxtxt_native_job_v1.hpp'
    result = {}
    task_files = {name: raw for name, raw in files.items() if name.startswith(('jobs/', 'include/'))}
    diagnostics = source_includes(task_files)
    if diagnostics:
        raise ValueError('Native task source admission failed: ' + json.dumps(diagnostics))
    for entry, item in meta.get('native_jobs', {}).items():
        target = stage / ('native-job-' + entry)
        # Exact same reviewed compiler/C++17/system runtime as the Viewer owner;
        # no authored flags, linker options, compiler plugins or extra libraries.
        command = [str(COMPILER), *FLAGS, '-O1', '-g0', '-fno-stack-protector',
                   '-ffile-prefix-map=' + str(stage) + '=.', '-Wl,--build-id=none',
                   '-I' + str(stage), '-I' + str(stage / 'include'), '-I' + str(stage / 'jobs'),
                   '-I' + str(sdk.parent), *[str(stage / name) for name in item['sources']],
                   '-lstdc++', '-lm', '-o', str(target)]
        code, output, errors = bounded_command(command, stage, 30)
        log = (output + errors).decode(errors='replace').replace(str(stage), '<controlled-build>')
        if code:
            raise ValueError('Native task build failed for ' + entry + ': ' + log)
        raw = target.read_bytes()
        sources = {'source/' + name: digest(data) for name, data in task_files.items()}
        sources['native/gxtxt_native_job_v1.hpp'] = digest(sdk.read_bytes())
        descriptor = {
            'schema': 'gxtxt.native_job_artifact.v1', 'artifact': 'native/jobs/' + entry,
            'artifact_sha256': digest(raw),
            'source_sha256': digest(json.dumps(sources, sort_keys=True, separators=(',', ':')).encode()),
            'sources': sources,
            'abi': {'protocol': 1, 'platform': platform.system().lower(), 'machine': platform.machine(), 'pointer_bits': 64, 'cpp_standard': 17, 'buffer_descriptor_version': 2},
            'dependencies': {}, 'runtime_dependencies': native_runtime_dependencies(target),
            'parameters': item.get('parameters', {}),
        }
        destination = project / 'derived/native-jobs' / entry
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(prefix='.native-job-', dir=destination.parent, delete=False) as stream:
            stream.write(raw)
            pending = Path(stream.name)
        pending.chmod(0o755)
        os.replace(pending, destination)
        result[entry] = {'descriptor': descriptor, 'log': log, 'compiler_argv': command}
    return result


def unchanged(project, built):
    for name, entry in built.get('native_jobs', {}).items():
        artifact = project / 'derived/native-jobs' / name
        if not artifact.is_file() or artifact.is_symlink() or digest(artifact.read_bytes()) != entry['descriptor']['artifact_sha256']:
            return False
        if entry['descriptor'].get('runtime_dependencies') != native_runtime_dependencies(artifact):
            return False
    return True
