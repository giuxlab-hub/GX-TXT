"""Optional canonical cell dimensions; flat items follow Octave column order.

The one-million-item bound applies only to new shape metadata on shared wire
values. Legacy unshaped lists and existing numeric/resource limits are unchanged.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from numbers import Integral

RESULT_CELL_LIMIT = 1_000_000


def cell_shape(shape, count, limit=RESULT_CELL_LIMIT):
    if not isinstance(shape, (list, tuple)) or not 2 <= len(shape) <= 16:
        raise ValueError('cell shape requires 2..16 dimensions')
    if any(isinstance(d, bool) or not isinstance(d, Integral) or d < 0 for d in shape):
        raise ValueError('cell shape requires nonnegative integer dimensions')
    dimensions = tuple(int(d) for d in shape)
    product = 1
    nonzero_product = 1
    for dimension in dimensions:
        product *= dimension
        if dimension:
            nonzero_product *= dimension
    if product != count or count > limit:
        raise ValueError('cell shape/item count mismatch or limit')
    if count == 0 and (any(d > limit for d in dimensions) or nonzero_product > limit):
        raise ValueError('empty cell shape exceeds dimension/index limit')
    return dimensions


class CellArray(list):
    """List-compatible flat cell items with explicit immutable dimensions."""
    def __init__(self, items, shape, *, max_items=RESULT_CELL_LIMIT):
        super().__init__(items)
        self._shape = cell_shape(shape, len(self), max_items)

    @property
    def shape(self):
        return self._shape

    def validated_shape(self, max_items=RESULT_CELL_LIMIT):
        return cell_shape(self._shape, len(self), max_items)

    def copy(self):
        return CellArray(self, self.validated_shape())
