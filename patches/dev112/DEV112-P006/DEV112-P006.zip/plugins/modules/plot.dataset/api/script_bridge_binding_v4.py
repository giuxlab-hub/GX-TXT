"""Native Plot Dataset v4 registration, retaining the established Script Bridge contracts."""
from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path
from copy import deepcopy
_spec = spec_from_file_location("gxtxt_plot_stable_script_contract", Path(__file__).with_name("script_bridge_binding.py"))
_stable = module_from_spec(_spec)
_spec.loader.exec_module(_stable)
REGISTRATION = deepcopy(_stable.V3_REGISTRATION)
REGISTRATION.update(api_id="PLOT_DATASET_API_v4", api_version=4, documentation_ref="docs/api/PLOT_DATASET_API_v4.md")
REGISTRATION['operations']['native_backend_info'] = {
    'name': 'native_backend_info', 'summary': 'Read installed native Plot backend identity and capabilities',
    'host_command': '::GX::PlotDatasetAPIv4::nativeBackendInfo',
    'arguments': [], 'argument_convention': 'no arguments',
    'result_contract': 'native backend metadata with explicit availability and capability IDs'}
class _NativeHost:
    def __init__(self, host): self._host=host
    def __getattr__(self, key): return getattr(self._host,key)
    def call(self, command, *args):
        if command == "::GX::modulePublicApiActivate" and args == ("plot.dataset", "PLOT_DATASET_API_v3"):
            return self._host.call(command, "plot.dataset", "PLOT_DATASET_API_v4")
        if command.startswith("::GX::PlotDatasetAPIv3::"):
            command=command.replace("::GX::PlotDatasetAPIv3::", "::GX::PlotDatasetAPIv4::", 1)
        return self._host.call(command,*args)

# Additive exact-cell spec construction. Stable v1/v2/v3 registrations and the
# original v4 operations retain their existing implementation and signatures.
REGISTRATION["operations"]["cell_field_spec"] = {
    "name": "cell_field_spec", "summary": "Construct an exact cell-associated triangular field specification",
    "arguments": [{"name": name, "kind": kind, "required": name != "title"}
                  for name, kind in (("dataset_id", "string"), ("x_variable_id", "string"),
                                     ("y_variable_id", "string"), ("binding", "struct"), ("title", "string"))],
    "result_contract": "PlotSpec with explicit GXTXT_CELL_FIELD_BINDING_v1; no interpolation"}


def _cell_fields(host, value):
    if isinstance(value, dict):
        for key in tuple(value):
            if key == "cell_field" and not isinstance(value[key], dict):
                binding = host.as_dict(value[key])
                if "node_variable_ids" in binding:
                    binding["node_variable_ids"] = host.as_list(binding["node_variable_ids"])
                value[key] = binding
            else:
                value[key] = _cell_fields(host, value[key])
    elif isinstance(value, list):
        value = [_cell_fields(host, item) for item in value]
    return value


def _original(host, operation, args):
    if operation == 'native_backend_info':
        from gxtxt_script_bridge_server import BridgeError
        if args:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'native_backend_info takes no arguments')
        host.call('::GX::modulePublicApiActivate', 'plot.dataset', 'PLOT_DATASET_API_v4')
        result = host.as_dict(host.call('::GX::PlotDatasetAPIv4::nativeBackendInfo'))
        result['available'] = bool(host.tcl.getboolean(result['available']))
        result['capabilities'] = [str(value) for value in host.as_list(result['capabilities'])]
        for key in ('api_version','abi_version'):
            if key in result:
                result[key] = int(result[key])
        return result
    if operation == "cell_field_spec":
        from gxtxt_script_bridge_server import BridgeError
        if len(args) not in (4, 5) or any(not isinstance(value, str) for value in args[:3]) or not isinstance(args[3], dict) or len(args) == 5 and not isinstance(args[4], str):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "cell_field_spec requires three identity strings, a typed binding and optional title")
        host.call("::GX::modulePublicApiActivate", "plot.dataset", "PLOT_DATASET_API_v4")
        return _cell_fields(host, _stable._plot_spec(host, host.call("::GX::PlotDatasetAPIv4::cellFieldSpec", *args)))
    return _cell_fields(host, _stable.invoke_api(_NativeHost(host), "PLOT_DATASET_API_v3", operation, args))

# Closed canonical projections of the original host preparation contracts.
# Raw prepared models, callback prefixes, contexts and output paths are never
# accepted. All numerical preparation/conversion remains with existing owners.
import hashlib
import tempfile
import uuid
from gxtxt_script_bridge_server import BridgeError, NumericArray, numeric_column_tokens
_NEW = {
    'cell_field_profile_spec': ('cellFieldProfileSpec', [('spec', 'complete canonical cell-field PlotSpec')]),
    'cell_field_source_identity': ('cellFieldSourceIdentity', [('spec', 'complete canonical cell-field PlotSpec')]),
    'cell_field_native_scene': ('cellFieldNativeScene', [('spec', 'complete canonical cell-field PlotSpec')]),
    'validate_sources': ('widgetValidateSources', [('spec', 'canonical PlotSpec; no prepared context')]),
    'xyz_source': ('xyzConsultationSource', [('dataset_id', 'canonical Dataset ID'), ('variable_ids', 'three explicit distinct Variable IDs')]),
    'xyz_coordinate_presentation': ('xyzCoordinatePresentation', [('dataset_id', 'canonical Dataset ID'), ('variable_ids', 'three explicit distinct Variable IDs'), ('options', 'optional bounded start/count/expected_stamp')]),
    'scientific_model': ('scientificModel', [('sources', 'existing execution-owned Curve Source tokens')]),
    'render_model': ('renderModel', [('model', 'execution-owned immutable scientific model'), ('options', 'optional bounded width/height')]),
}
for _name, (_command, _fields) in _NEW.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Existing canonical Plot v4 owner: '+_command,
        'host_command': '::GX::PlotDatasetAPIv4::'+_command,
        'arguments': [{'name': key, 'kind': kind, 'required': key != 'options'} for key, kind in _fields],
        'argument_convention': ', '.join(key for key, _ in _fields),
        'result_contract': 'Closed typed canonical source projection or execution-owned immutable display-model handle; XYZ canonical_columns retain original TableStream dtype/values/unit/value_kind/value_format; points are derived float64 display, not scientific source data; actual source/revision/coordinate/Session guards retained. Render returns bounded original native PNG bytes and cleans its temporary output. No caller arrays/model/context/path/callback, independent calibration or scientific publication.'}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _digest(host, value):
    return hashlib.sha256(_text(host, value).encode('utf-8')).hexdigest()


def _matrix(host, value, columns, dtype='float64'):
    rows = [host.as_list(row) for row in host.as_list(value)]
    convert = int if dtype == 'int64' else float
    if any(len(row) != columns for row in rows):
        raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Owner returned inconsistent numeric row width')
    return NumericArray([convert(row[column]) for column in range(columns) for row in rows], [len(rows), columns], dtype=dtype)


def _snapshot(host, datasets):
    token = _text(host, host.call('::GX::interactiveDocumentSessionToken'))
    values = []
    for dataset in sorted(set(datasets)):
        values.append((dataset, _text(host, host.call('::GX::datasetRevisionToken', dataset)),
                       _text(host, host.call('::GX::datasetCoordinateRead', host.session, dataset)),
                       _text(host, host.call('::GX::datasetViewerScientificIdentity', dataset))))
    if token != _text(host, host.call('::GX::interactiveDocumentSessionToken')):
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Session changed during source admission')
    return token, tuple(values)


def _check(host, snapshot):
    if snapshot != _snapshot(host, [row[0] for row in snapshot[1]]):
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Canonical source/revision/coordinates/Session changed; prepare again')


def _stamp(snapshot):
    return 'plot-source-sha256:'+hashlib.sha256(repr(snapshot).encode('utf-8')).hexdigest()


def _identities(host, datasets):
    return [{key: _text(host, value) for key, value in host.as_dict(
        host.call('::GX::curveSourceDatasetIdentity', host.session, dataset)).items()}
        for dataset in sorted(set(datasets))]


def _spec(host, spec):
    if not isinstance(spec, dict):
        _invalid('Canonical PlotSpec must be a struct')
    # Existing exact typed PlotSpec schema rejects hidden prepared buffers and
    # arbitrary extensions before the original scientific owner validates it.
    host.call('::GX::nativeWorkspaceEncode', ['named', 'plot_spec'], spec)
    return spec


def _field_identity(host, raw, snapshot):
    value = raw if isinstance(raw, dict) else host.as_dict(raw)
    return {'spec': _cell_fields(host, _stable._plot_spec(host, value['spec'])),
            'source_identities': _identities(host, [row[0] for row in snapshot[1]]),
            'source_stamp': _stamp(snapshot)}


def _field(host, operation, spec):
    _spec(host, spec)
    panels = spec.get('panels')
    if not isinstance(panels, list) or len(panels) != 1 or not isinstance(panels[0].get('series'), list) or len(panels[0]['series']) != 1:
        _invalid('Cell-field projection requires one complete canonical panel and field')
    series = panels[0]['series'][0]
    binding = series.get('cell_field', {})
    datasets = [series.get('dataset_id'), binding.get('nodes_dataset_id')]
    if any(not isinstance(dataset, str) or not dataset for dataset in datasets):
        _invalid('Cell-field projection requires actual canonical cells and nodes Dataset IDs')
    snapshot = _snapshot(host, datasets)
    identity = host.as_dict(host.call('::GX::PlotDatasetAPIv4::cellFieldSourceIdentity', spec))
    _check(host, snapshot)
    if operation == 'cell_field_source_identity':
        result = _field_identity(host, identity, snapshot)
    elif operation == 'cell_field_profile_spec':
        result = _cell_fields(host, _stable._plot_spec(host, host.call('::GX::PlotDatasetAPIv4::cellFieldProfileSpec', spec)))
    else:
        raw = host.as_dict(host.call('::GX::PlotDatasetAPIv4::cellFieldNativeScene', spec))
        scalar_variable = host.as_dict(host.call('::GX::datasetVariableV3ById', series['dataset_id'], binding['scalar_variable_id']))
        scalar_dtype = _text(host, scalar_variable['dtype'])
        layers = {}
        for name, layer in host.as_dict(raw['layers']).items():
            layer = host.as_dict(layer)
            nodes = [host.as_list(row) for row in host.as_list(layer['mesh_nodes'])]
            cells = [host.as_list(row) for row in host.as_list(layer['mesh_cells'])]
            result_layer = {key: _text(host, value) for key, value in layer.items() if key not in ('mesh_nodes', 'mesh_cells')}
            result_layer['nodes'] = {'node_id': NumericArray([int(row[0]) for row in nodes], [len(nodes), 1], dtype='int64'),
                                    'xy': NumericArray([float(row[column]) for column in (1, 2) for row in nodes], [len(nodes), 2])}
            result_layer['cells'] = {'cell_id': NumericArray([int(row[0]) for row in cells], [len(cells), 1], dtype='int64'),
                                    'node_ids': NumericArray([int(row[column]) for column in (1, 2, 3) for row in cells], [len(cells), 3], dtype='int64'),
                                    'scalar': numeric_column_tokens([_text(host, row[4]) for row in cells], scalar_dtype)[0],
                                    'scalar_dtype': scalar_dtype,
                                    'source_row': NumericArray([int(row[5]) for row in cells], [len(cells), 1], dtype='int64')}
            layers[str(name)] = result_layer
        scalar = host.as_dict(raw['scalar_display'])
        result = {'layers': layers, 'view': {key: _text(host, value) for key, value in host.as_dict(raw['view']).items()},
                  'source_identity': _field_identity(host, raw['source_identity'], snapshot),
                  'scalar_display': {'source_scalar_range': numeric_column_tokens([_text(host, v) for v in host.as_list(scalar['source_scalar_range'])], scalar_dtype)[0],
                                     'color_range': NumericArray([float(v) for v in host.as_list(scalar['color_range'])]),
                                     'display_range_expanded': bool(host.tcl.getboolean(scalar['display_range_expanded']))},
                  'caption': _text(host, raw['caption'])}
    _check(host, snapshot)
    return result


def _xyz(host, dataset, variables, options=None, presentation=False):
    if not isinstance(dataset, str) or not isinstance(variables, list) or any(not isinstance(v, str) for v in variables):
        _invalid('XYZ requires canonical Dataset and three explicit Variable IDs')
    snapshot = _snapshot(host, [dataset])
    source = host.as_dict(host.call('::GX::PlotDatasetAPIv4::xyzConsultationSource', dataset, variables))
    _check(host, snapshot)
    context = source['coordinate_context']
    result = {'dataset_id': dataset, 'variable_ids': variables, 'source_identity': _identities(host, [dataset])[0],
              'source_stamp': _stamp(snapshot),
              'coordinate_context': host.modules['DATASET_METADATA_API_v1']._coordinate_context(host, context),
              'renderer_owner': 'PLOT_DATASET_API_v4'}
    if presentation:
        options = {} if options is None else options
        if not isinstance(options, dict) or set(options)-{'start', 'count', 'expected_stamp'}:
            _invalid('XYZ presentation accepts bounded canonical start/count and expected_stamp only')
        start, count = options.get('start', 0), options.get('count', 12000)
        if any(isinstance(v, bool) or not isinstance(v, (int, float)) or int(v) != v for v in (start, count)) or start < 0 or not 1 <= count <= 12000:
            _invalid('XYZ canonical range requires start>=0 and count1..12000')
        if 'expected_stamp' in options and options['expected_stamp'] != result['source_stamp']:
            raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'XYZ source stamp is stale')
        stream = host.call('::GX::tableStreamOpenDataset', host.session, dataset, variables, int(count),
                           {'start': int(start), 'count': int(count), 'numeric_transport': 'values'})
        try:
            chunk = host.as_dict(host.call('::GX::tableStreamNext', stream))
            columns = host.as_dict(chunk['values'])
            rows = list(zip(*(host.as_list(columns[v]) for v in variables)))
            if len(rows) != int(chunk['row_count']):
                raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Canonical XYZ columns are inconsistent')
        finally:
            host.call('::GX::tableStreamClose', stream)
        _check(host, snapshot)
        metadata = {str(column['variable_id']): column for column in
                    (host.as_dict(value) for value in host.as_list(chunk['columns']))}
        canonical_columns = []
        for variable in variables:
            column = metadata[variable]
            dtype = _text(host, column['dtype'])
            values, missing = numeric_column_tokens([_text(host, value) for value in host.as_list(columns[variable])], dtype)
            canonical = {'variable_id': variable, 'dtype': dtype,
                         'unit': _text(host, column['unit']), 'values': values,
                         'value_kind': _text(host, column.get('value_kind', '')),
                         'value_format': _text(host, column.get('value_format', '')),
                         'values_contract': 'canonical_table_stream'}
            if missing is not None:canonical['missing_mask'] = missing
            canonical_columns.append(canonical)
        raw = host.as_dict(host.call('::GX::PlotDatasetAPIv4::xyzCoordinatePresentation', context, variables, rows))
        result.update(schema=_text(host, raw['schema']), points=_matrix(host, raw['points'], 3),
                      canonical_columns=canonical_columns, display_is_scientific_data=False,
                      source_rows=NumericArray(list(range(int(chunk['offset']), int(chunk['offset'])+len(rows))), [len(rows), 1], dtype='int64'),
                      local_transform=_text(host, raw['local_transform']),
                      view={key: _text(host, value) for key, value in host.as_dict(raw['view']).items()},
                      scientific_figure={key: _text(host, value) for key, value in host.as_dict(raw['scientific_figure']).items()},
                      calibration_applied=False, source_values_modified=False, caption=_text(host, raw['caption']))
    _check(host, snapshot)
    return result


def _models(host):
    return host.handles.setdefault('plot_v4_models', {})


def _model(host, tokens):
    if not isinstance(tokens, list) or not 1 <= len(tokens) <= 512 or any(not isinstance(token, str) for token in tokens):
        _invalid('Scientific model requires one to512 actual execution-owned Curve Source tokens')
    owned = host.handles.get('curve_source', {}).get('sources', set())
    if any(token not in owned for token in tokens) or len(set(tokens)) != len(tokens):
        _invalid('Curve Source token is foreign, closed or repeated')
    if len(_models(host)) >= 16:
        _invalid('At most16 immutable scientific models per execution')
    descriptors = [host.call('::GX::curveSourceDescribe', token) for token in tokens]
    requests = [host.as_dict(host.as_dict(d)['request']) for d in descriptors]
    dataset, x = _text(host, requests[0]['dataset_id']), _text(host, requests[0]['x_variable_id'])
    if any(_text(host, request['dataset_id']) != dataset or _text(host, request['x_variable_id']) != x for request in requests):
        _invalid('Scientific overlay sources require the same canonical Dataset and X')
    snapshot = _snapshot(host, [dataset]);context = host.call('::GX::datasetCoordinateRead', host.session, dataset)
    traces = []
    for index, (token, descriptor, request) in enumerate(zip(tokens, descriptors, requests)):
        y = _text(host, request['y_variable_id'])
        display = host.call('::GX::curveSourceDisplay', token)
        display = host.call('::GX::scientificDatasetCoordinateDisplay', context, x, y, display)
        traces.append({'id': 'source_'+str(index), 'y_variable_id': y, 'label': y,
                       'source_descriptor': descriptor, 'display': display})
    raw = host.call('::GX::PlotDatasetAPIv4::scientificModel', dataset, x, traces, context)
    _check(host, snapshot)
    handle = 'plot-model:'+uuid.uuid4().hex
    _models(host)[handle] = {'model': _text(host, raw), 'snapshot': snapshot}
    return {'model': handle, 'trace_count': len(traces), 'dataset_id': dataset, 'x_variable_id': x,
            'source_identities': _identities(host, [dataset]), 'source_stamp': _stamp(snapshot),
            'calibration_applied': False, 'source_values_modified': False, 'renderer_owner': 'PLOT_DATASET_API_v4'}


def _render(host, handle, options=None):
    if not isinstance(handle, str) or handle not in _models(host):
        _invalid('Use an immutable Plot model handle from this execution')
    options = {} if options is None else options
    if not isinstance(options, dict) or set(options)-{'width', 'height'}:
        _invalid('Render accepts bounded width/height only; no path, model or callback')
    width, height = options.get('width', 960), options.get('height', 580)
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or int(v) != v or not 64 <= v <= 2048 for v in (width, height)):
        _invalid('Native render dimensions must be integers64..2048')
    record = _models(host)[handle];_check(host, record['snapshot'])
    with tempfile.TemporaryDirectory(prefix='gxtxt-plot-v4-') as directory:
        path = Path(directory)/'render.png'
        receipt = host.as_dict(host.call('::GX::PlotDatasetAPIv4::renderModel', record['model'], str(path), int(width), int(height)))
        _check(host, record['snapshot'])
        if path.is_symlink() or not path.is_file() or path.stat().st_size > 16777216:
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Native renderer output exceeds bounded owned PNG contract')
        with path.open('rb') as stream:
            data = stream.read(16777217)
        if len(data) > 16777216 or not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Native renderer returned invalid/bounded PNG output')
        _check(host, record['snapshot'])
        axes = []
        for axis in host.as_list(receipt.get('axes', ())):
            axis = host.as_dict(axis)
            axes.append({key: NumericArray([float(v) for v in host.as_list(value)]) if key == 'limits' else _text(host, value)
                         for key, value in axis.items()})
        return {'format': 'png', 'media_type': 'image/png', 'sha256': hashlib.sha256(data).hexdigest(),
                'bytes': host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(data),
                'axes': axes, 'width': int(width), 'height': int(height),
                'source_stamp': _stamp(record['snapshot']), 'renderer_owner': 'PLOT_DATASET_API_v4'}


def _canonical(host, operation, args):
    if operation not in _NEW:
        return _original(host, operation, args)
    fields = _NEW[operation][1]
    if not sum(name != 'options' for name, _ in fields) <= len(args) <= len(fields):
        _invalid('Invalid closed Plot-v4 argument count')
    host.call('::GX::modulePublicApiActivate', 'plot.dataset', 'PLOT_DATASET_API_v4')
    if operation.startswith('cell_field_'):
        return _field(host, operation, args[0])
    if operation == 'validate_sources':
        raw = host.as_dict(host.call('::GX::PlotDatasetAPIv4::widgetValidateSources', _spec(host, args[0])))
        return {'valid': bool(host.tcl.getboolean(raw['valid'])), 'source_count': int(raw['source_count'])}
    if operation in ('xyz_source', 'xyz_coordinate_presentation'):
        return _xyz(host, *args, presentation=operation == 'xyz_coordinate_presentation')
    if operation == 'scientific_model':
        return _model(host, args[0])
    return _render(host, *args)


def cleanup(host):
    host.handles.pop('plot_v4_models', None)
    host.handles.pop('plot_v4_consultations', None)

# Managed counterpart of source/export-command/scene intake. The source owner
# supplies the exact installed exporter argv and verifies its producer/source
# expectation. No command, output directory or raw source_key crosses RPC.
import subprocess
import time
_CONSULT = {
    'consultation_source': ('consultationSource', 'reference', 'declared canonical provider Graph reference'),
    'consultation_scene': ('consultationScene', 'source', 'opaque consultation source from this execution'),
}
for _name, (_command, _argument, _kind) in _CONSULT.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Original managed scientific3D consultation: '+_command,
        'host_command': '::GX::PlotDatasetAPIv4::'+_command,
        'arguments': [{'name': _argument, 'kind': _kind, 'required': True}],
        'argument_convention': _argument,
        'result_contract': 'Current canonical provider source handle or bounded original verified VTP layer bytes and physical-unit/view metadata. Exact source-generated installed exporter argv executes without shell only in a private temporary directory, original producer/source expectation and consultationScene validation remain authoritative; source/revision/coordinates/Session rechecked before/after. No caller command/directory/key/receipt/path/arrays or durable scene/publication authority.'}


def _consultations(host):
    return host.handles.setdefault('plot_v4_consultations', {})


def _consultation_source(host, reference):
    if not isinstance(reference, dict) or set(reference)-{'kind', 'module_id', 'graph_id', 'variant_id', 'plot_id'} or any(not isinstance(v, str) for v in reference.values()):
        _invalid('Consultation requires a closed canonical provider Graph reference; no path, callback or prepared source')
    if len(_consultations(host)) >= 16:
        _invalid('At most16 consultation source handles per execution')
    held_session = _text(host, host.call('::GX::interactiveDocumentSessionToken'))
    raw = host.as_dict(host.call('::GX::PlotDatasetAPIv4::consultationSource', reference))
    if held_session != _text(host, host.call('::GX::interactiveDocumentSessionToken')):
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Session changed during provider source admission')
    info = host.as_dict(raw['source_info'])
    dataset = _text(host, info['source_dataset_id'])
    snapshot = _snapshot(host, [dataset])
    ref = host.as_dict(raw['original_reference'])
    summary = {'plot_ref': {key: _text(host, value) for key, value in ref.items()},
               'source_dataset_id': dataset, 'source_identity': _identities(host, [dataset])[0],
               'coordinate_context': host.modules['DATASET_METADATA_API_v1']._coordinate_context(host, raw['coordinate_context']),
               'source_stamp': _stamp(snapshot), 'fingerprint': _text(host, raw['fingerprint']),
               'renderer_owner': 'PLOT_DATASET_API_v4'}
    record = {'ref': _text(host, raw['original_reference']), 'source_key': _text(host, raw['source_key']),
              'snapshot': snapshot, 'summary': summary}
    _consultation_current(host, record)
    handle = 'plot-consultation:'+uuid.uuid4().hex
    _consultations(host)[handle] = record
    return dict(summary, source=handle)


def _consultation_current(host, record):
    _check(host, record['snapshot'])
    actual = host.as_dict(host.call('::GX::PlotDatasetAPIv4::consultationSource', record['ref']))
    if _text(host, actual['source_key']) != record['source_key'] or _text(host, actual['original_reference']) != record['ref']:
        raise BridgeError('GXTXT:ScriptBridge:SourceChanged', 'Provider Graph/source/producer/coordinate/Session changed; resolve again')
    _check(host, record['snapshot'])


def _figure(host, value):
    raw = host.as_dict(value);result = {}
    for key in ('title', 'x_label', 'y_label', 'z_label', 'legend', 'scalar_label', 'axis_min', 'axis_max', 'bounds_min', 'bounds_max'):
        if key in raw:result[key] = _text(host, raw[key])
    for key in ('scalar_min', 'scalar_max'):
        if key in raw:result[key] = float(raw[key])
    for key in ('axes_grid_visible', 'colorbar_visible'):
        if key in raw:result[key] = bool(host.tcl.getboolean(raw[key]))
    if 'tick_labels' in raw:
        result['tick_labels'] = [[_text(host, v) for v in host.as_list(row)] for row in host.as_list(raw['tick_labels'])]
    if 'physical_axis_ranges' in raw:
        result['physical_axis_ranges'] = _matrix(host, raw['physical_axis_ranges'], 2)
    if 'aspect_policy' in raw:
        aspect = host.as_dict(raw['aspect_policy'])
        result['aspect_policy'] = {'mode': _text(host, aspect['mode']),
                                  'normalized_box': NumericArray([float(v) for v in host.as_list(aspect['normalized_box'])])}
    if 'native_style' in raw:
        result['native_style'] = {key: _text(host, value) for key, value in host.as_dict(raw['native_style']).items()}
    return result


def _consultation_export(argv, directory):
    # The canonical Script Job/Viewer auxiliary owner owns the inherited group.
    # Never detach an exporter from that owner's cancellation lifetime. Local
    # cleanup uses only this exporter's recorded start identities, never the
    # parent/bridge process tree or its entire process group.
    from gxtxt_job_supervisor import (process_identity, process_tree, owned_processes,
                                     drain_tree, reap_adopted)
    record = dict(run_id='plot-consultation', job_root='', process_identities={})
    with tempfile.TemporaryFile() as output:
        process = subprocess.Popen(argv, cwd=directory, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=subprocess.STDOUT, shell=False)
        record['pid_start'] = process_identity(process.pid)
        def capture():
            live = owned_processes(record, process.pid)
            # A recorded child remains owned after its original parent exits.
            # Continue following that exact incarnation's children as well.
            for pid, start in live.items():
                if process_identity(pid) == start:
                    record['process_identities'].update(
                        {str(child): row[2] for child, row in process_tree(pid).items() if row[6] != 'Z'})
        deadline = time.monotonic()+120
        try:
            while True:
                capture()
                if output.tell() > 1048576:
                    raise BridgeError('GXTXT:ScriptBridge:NativeBackend', 'Original scientific3D preparation exceeded its output bound')
                if process.poll() is not None:
                    break
                if time.monotonic() >= deadline:
                    raise BridgeError('GXTXT:ScriptBridge:NativeBackend', 'Original scientific3D preparation exceeded its120s bound')
                time.sleep(.025)
            return process.returncode
        finally:
            # Keep the private files alive until the canonical identity-based
            # drain confirms no recorded exporter descendant is alive. An
            # uninterruptible child retains this scope; the existing outer
            # managed owner remains responsible for cancellation/escalation.
            while True:
                capture()
                if drain_tree(record, process.pid, timeout=.35):
                    break
            process.wait()
            reap_adopted(record)


def _consultation_scene(host, handle):
    if not isinstance(handle, str) or handle not in _consultations(host):
        _invalid('Use a consultation source handle owned by this execution')
    record = _consultations(host)[handle];_consultation_current(host, record)
    with tempfile.TemporaryDirectory(prefix='gxtxt-plot-consultation-') as directory:
        # This is the actual owner's exact installed exporter, including its
        # source expectation for immutable producer graphs. No shell or caller
        # argv, executable, environment, directory or scene dictionary is used.
        command = host.call('::GX::PlotDatasetAPIv4::consultationExportCommand', record['ref'], directory)
        argv = [_text(host, word) for word in host.as_list(command)]
        if not argv or not argv[0] or argv[0].startswith('::'):
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Source owner did not return its installed external scientific exporter')
        _consultation_current(host, record)
        if _consultation_export(argv, directory):
            raise BridgeError('GXTXT:ScriptBridge:NativeBackend', 'Original scientific3D exporter refused the admitted source preparation')
        _consultation_current(host, record)
        raw = host.as_dict(host.call('::GX::PlotDatasetAPIv4::consultationScene', record['ref'], record['source_key'], directory))
        _consultation_current(host, record)
        root = Path(directory).resolve();layers = host.as_dict(raw['layers'])
        if not 1 <= len(layers) <= 64:
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Managed consultation requires1..64 native layers')
        result_layers = {};total = 0
        fields = {'kind', 'format', 'representation', 'source_mode', 'source_dataset_id', 'source_dataset_sha256',
                  'source_update_policy', 'line_width', 'point_size', 'scalar_array', 'color_array', 'local_transform',
                  'base_color', 'opacity', 'visible', 'scalar_coloring', 'scalar_unit', 'coordinate_unit'}
        for name, value in layers.items():
            layer = host.as_dict(value);path = Path(_text(host, layer['absolute_path']))
            if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root) or any(p.is_symlink() for p in path.parents if p != root and p.is_relative_to(root)):
                raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Native layer escaped its actual private owner preparation')
            with path.open('rb') as stream:data = stream.read(16777217)
            total += len(data)
            if len(data) > 16777216 or total > 33554432 or hashlib.sha256(data).hexdigest() != _text(host, layer['sha256']):
                raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Native layer identity changed or exceeds managed byte bounds')
            result = {key: _text(host, layer[key]) for key in fields if key in layer}
            result.update(sha256=hashlib.sha256(data).hexdigest(), media_type='application/vnd.vtk.vtp',
                          bytes=host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(data))
            result_layers[str(name)] = result
        view = host.as_dict(raw['view'])
        view_fields = {'camera_position', 'camera_target', 'camera_up', 'projection', 'orthographic_height', 'near_clip',
                       'far_clip', 'clip_box', 'background_rgb', 'background_bottom_rgb', 'background_gradient',
                       'lighting', 'axes_world', 'orientation_indicator_visible', 'scene_mode'}
        presentation = host.as_dict(raw['presentation'])
        result = {'layers': result_layers, 'view': {key: _text(host, view[key]) for key in view_fields if key in view},
                  'caption': _text(host, raw['caption']), 'scientific_figure': _figure(host, raw['scientific_figure']),
                  'presentation': {key: _text(host, presentation[key]) for key in ('plot_type', 'source_owner') if key in presentation},
                  'source_info': dict(record['summary']), 'source_stamp': record['summary']['source_stamp'],
                  'renderer_owner': 'PLOT_DATASET_API_v4', 'native_preparation_completed': True}
        _consultation_current(host, record)
        return result


def invoke(host, operation, args):
    if operation not in _CONSULT:
        return _canonical(host, operation, args)
    if len(args) != 1:
        _invalid('Managed consultation takes exactly one closed source argument')
    host.call('::GX::modulePublicApiActivate', 'plot.dataset', 'PLOT_DATASET_API_v4')
    if operation == 'consultation_source':return _consultation_source(host, args[0])
    return _consultation_scene(host, args[0])
