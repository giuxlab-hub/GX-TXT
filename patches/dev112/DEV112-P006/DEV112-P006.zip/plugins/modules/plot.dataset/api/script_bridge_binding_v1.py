"""Retained Plot v1 metadata/canonical state; v2/v3/v4 contracts stay distinct."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_SCHEMA = {
    'PLOT_DATASET_API_v1': {'apiInfo': [], 'capabilities': [],
                          'supports': ['capability'], 'requireCapability': ['capability']},
    'PLOT_DATASET_3D_API_v1': {'apiInfo': []},
}
REGISTRATIONS = [{
    'api_id': api, 'api_version': 1, 'provider_kind': 'module', 'provider_id': 'plot.dataset',
    'documentation_ref': 'plugins/modules/plot.dataset/'+api+'.md',
    'operations': {operation: {'name': operation, 'summary': 'Inspect existing Plot owner '+operation,
        'arguments': [{'name': name, 'kind': 'string', 'required': True} for name in arguments],
        'argument_convention': ', '.join(arguments) or 'no arguments',
        'result_contract': 'Typed metadata, capability list or capability boolean; no plot creation'}
        for operation, arguments in operations.items()},
} for api, operations in _SCHEMA.items()]


def _metadata(host, api_id, operation, args):
    if api_id not in _SCHEMA or operation not in _SCHEMA[api_id]:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown Plot metadata operation')
    if len(args) != len(_SCHEMA[api_id][operation]) or any(not isinstance(value, str) for value in args):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid Plot metadata arguments')
    host.call('::GX::modulePublicApiActivate', 'plot.dataset', api_id)
    namespace = '::GX::PlotDatasetAPIv1::' if api_id == 'PLOT_DATASET_API_v1' else '::GX::PlotDataset3DAPIv1::'
    raw = host.call(namespace+operation, *args)
    if operation in ('supports', 'requireCapability'):
        return bool(int(raw))
    if operation == 'capabilities':
        return [str(value) for value in host.as_list(raw)]
    source = host.as_dict(raw)
    result = {str(key): str(value) for key, value in source.items()
              if key not in ('api_version', 'capabilities', 'plot_types')}
    result['api_version'] = int(source['api_version'])
    for key in ('capabilities', 'plot_types'):
        if key in source:
            result[key] = [str(item) for item in host.as_list(source[key])]
    return result


_V1_FIELDS={
 'createPlot':[('graphId','string',True),('kind','string',False),('sourceVariant','string',False)],
 'openPlot':[('graphId','string',True),('variantId','string',False)],
 'deletePlot':[('plotRef','ref',True)],'setPlotEnabled':[('plotRef','ref',True),('state','boolean',True)],
 'setConfig':[('plotRef','ref',True),('key','string',True),('value','scalar',True)],
 'getConfig':[('plotRef','ref',True),('key','string',True)],'setTitle':[('plotRef','ref',True),('title','string',True)],
 'setSeries':[('plotRef','ref',True),('seriesId','string',True),('fields','struct',True)],
 'getSeries':[('plotRef','ref',True),('seriesId','string',True)],
 'listSeries':[('plotRef','ref',True),('includeDisabled','boolean',False)],
 'removeSeries':[('plotRef','ref',True),('seriesId','string',True)],
 'artifacts':[('plotRef','ref',True)],
 'setSeriesEnabled':[('plotRef','ref',True),('seriesId','string',True),('state','boolean',True)],
 'moveSeries':[('plotRef','ref',True),('seriesId','string',True),('direction','string',True)],
 'setSeriesOrder':[('plotRef','ref',True),('orderedIds','strings',True)],'readPlot':[('plotRef','ref',True)],
}
for _registration in REGISTRATIONS:
 if _registration['api_id']=='PLOT_DATASET_API_v1':
  _registration['operations'].update({name:{'name':name,'summary':'Existing retained Plot v1 canonical owner: '+name,
   'host_command':'::GX::PlotDatasetAPIv1::'+name,
   'arguments':[{'name':field,'kind':kind,'required':required}for field,kind,required in fields],
   'argument_convention':', '.join(field for field,_,_ in fields),
   'result_contract':'Retained v1 persistent Plot/Variant/Graph Series metadata with original canonical Dataset/Variable IDs, units, filters and order. Resolved source paths and raw artifact paths are omitted; literal legacy configuration values remain strings. No renderer command, callback, GUI, new scientific algorithm or Plot-v4 parity claim.'}
   for name,fields in _V1_FIELDS.items()})

  _registration['operations']['artifacts']['result_contract']='Exact five-field retained-v1 metadata: output_dir, graph_artifact, render_cache and summary strings plus existing string list, from the current admitted Session and original fixed Plot/Variant owner. These inert values grant no arbitrary path, content read, renderer or callback invocation.'

def _invalid(message):raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)
def _text(host,value):return str(host.tcl.call('format','%s',value))

def _argument(value,kind):
 if kind=='string':return isinstance(value,str)
 if kind=='struct':return isinstance(value,dict)
 if kind=='ref':return isinstance(value,dict)and{'module_id','graph_id','variant_id'}<=set(value)<= {'module_id','graph_id','variant_id','plot_id'}and all(isinstance(v,str)for v in value.values())
 if kind=='boolean':return isinstance(value,bool)or type(value)in(int,float)and value in(0,1)
 if kind=='strings':return isinstance(value,(list,tuple))and all(isinstance(v,str)for v in value)
 if kind=='scalar':return isinstance(value,(str,bool,int,float))
 return False

def _series(host,raw):
 result={}
 for key,value in host.as_dict(raw).items():
  if key=='path':continue
  if key in('enabled','available'):result[key]=bool(host.tcl.getboolean(value))
  elif key=='order':result[key]=int(value)
  elif key=='manual_offset_seconds':result[key]=float(value)
  elif key=='row_filters':
   result[key]=[{field:([_text(host,v)for v in host.as_list(item)]if field=='values'else _text(host,item))for field,item in host.as_dict(f).items()}for f in host.as_list(value)]
  elif key=='source_row_ordinals':result[key]=[_text(host,v)for v in host.as_list(value)]
  else:result[key]=_text(host,value)
 return result

def invoke_api(host,api_id,operation,args):
 if api_id!='PLOT_DATASET_API_v1'or operation not in _V1_FIELDS:return _metadata(host,api_id,operation,args)
 fields=_V1_FIELDS[operation]
 if not sum(required for _,_,required in fields)<=len(args)<=len(fields)or any(not _argument(value,kind)for value,(_,kind,_)in zip(args,fields)):
  _invalid('Legacy Plot operation requires its declared canonical reference/identity/scalar/field arguments')
 host.call('::GX::modulePublicApiActivate','plot.dataset',api_id)
 raw=host.call('::GX::PlotDatasetAPIv1::'+operation,*args)
 if operation=='artifacts':return {key:([_text(host,item)for item in host.as_list(value)]if key=='existing'else _text(host,value))for key,value in host.as_dict(raw).items()}
 if operation in('createPlot','deletePlot','setPlotEnabled','setConfig','setTitle','setSeries','removeSeries','setSeriesEnabled','moveSeries','setSeriesOrder'):
  host.persist_manifest('legacy_plot_'+operation)
 if operation in('createPlot','openPlot'):return {key:_text(host,value)for key,value in host.as_dict(raw).items()}
 if operation in('deletePlot','setPlotEnabled','removeSeries'):return bool(host.tcl.getboolean(raw))
 if operation in('setConfig','getConfig','setTitle'):return _text(host,raw)
 if operation in('setSeries','getSeries','setSeriesEnabled'):return _series(host,raw)
 if operation=='listSeries':return [_series(host,item)for item in host.as_list(raw)]
 if operation in('moveSeries','setSeriesOrder'):return [_text(host,value)for value in host.as_list(raw)]
 result={}
 for key,value in host.as_dict(raw).items():
  if key=='artifacts':continue
  if key=='enabled':result[key]=bool(host.tcl.getboolean(value))
  elif key=='config':result[key]={field:_text(host,v)for field,v in host.as_dict(value).items()}
  elif key=='series':result[key]=[_series(host,v)for v in host.as_list(value)]
  else:result[key]=_text(host,value)
 return result
