# Scientific Spectrum Preview 1.0.1

This Builder-authored compiled C++ Preview consults the current canonical
spectrum.scientific Dataset through matching P033 CORE public facilities.
Its interface and source are included in the normal package. The module is
independent of importer identity/version. Enable it through ordinary Preview
Configuration; installation does not silently enable a newly installed Preview.

Plot uses the maintained public Plot owner and every admitted canonical point.
Axis defaults come from declared coordinate/quantity semantics. When these are
absent, choose actual X and Y Variables explicitly. Native Plot controls own
Fit/Zoom/navigation; source values and scientific payload stay unchanged.

Values has explicit First/Previous/Next Variable, values page and Variable batch
controls. First Variable is user enumeration. Exact C-order hyperslabs contain
at most512cells per request. CORE renders actual coordinate refs, dtype/units and
exact canonical numeric text including uint64, with source-bound page indices.
Metadata and Source tabs have their own First/Previous/Next batch controls.
Source distinguishes pinned CORE identity from original decoded source headers;
multiline legal/provenance metadata is retained by the canonical owner.

Only existing public CORE Plot, numeric-array and metadata services are used.
Unavailable, malformed, stale or oversized operations explicitly refuse and
retain the current source. This private candidate still requires actual native,
scientific, GUI, cold and independent qualification. Generic headless Test is a
compiled no-owner-context smoke; it cannot establish these feature gates.

Version 1.0.1 places binding controls in the existing Source tab and compacts existing local paging controls. The default Plot uses the whole declared notebook page. Source, numerical data, handlers, role identities and SDK remain unchanged; actual shared CORE viewport behavior and independent acceptance are separate.


## Script Bridge tab metadata

The existing `VIEWER_DEVELOPMENT_API_v1` version1 core provider
`viewer_development` exposes `preview_tabs("preview.scientific_spectrum", dataset_id)`.
It returns the complete ordered original tab dictionaries from this installed
Preview and the current execution's canonical Dataset. Dataset IDs use the
original canonical owner validator, including valid leading digits and long IDs.
The installed module selector keeps its existing128-character lexical bound.

This metadata read does not mount the Preview, create widgets, launch its compiled
runtime or grant scientific/source-write operations. The raw callback and typed
route retain different missing-ID behavior: the original may return no tabs,
while the typed route refuses an absent current Dataset. The signature has no
held Session, revision or SHA argument and provides no atomic source certificate;
source replacement between reads requires another current read. Associated-source
pane availability does not establish that the associated code is current.
No new `PREVIEW_COMPONENT_GUI_API_v1` Script registration is introduced.
Full raw contract/transport and final installed/controller qualification remain
separate from this guarded existing owner projection.
