# Provider-owned MAGNETICS_API_v1 Tcl binding.
# SPDX-License-Identifier: GPL-3.0-or-later
source [file normalize [file join [file dirname [info script]] .. .. .. .. core tcl scientific_provider_transport_v1.tcl]]
namespace eval ::GX::MagneticsAPIv1 {variable lastTypes [dict create]}
proc ::GX::MagneticsAPIv1::capabilities {} {
    set d [::GX::parseIni [::GX::moduleField math.magnetics descriptor ""]]
    return [::GX::splitList [::GX::descriptorValue $d public_api.MAGNETICS_API_v1 capabilities ""]]
}
proc ::GX::MagneticsAPIv1::apiInfo {} {
    return [dict create api_id MAGNETICS_API_v1 api_version 1 provider_id math.magnetics provider_version [::GX::moduleField math.magnetics version ""] capabilities [capabilities]]
}
proc ::GX::MagneticsAPIv1::listOperations {} {
    set path [file join [file dirname [::GX::moduleField math.magnetics descriptor ""]] api operations_v1.tsv]
    set fd [open $path r];set ids {}
    try {while {[gets $fd line]>=0} {if {$line eq "" || [string index $line 0] eq "#"} continue;lappend ids [lindex [split $line |] 0]}} finally {close $fd}
    return $ids
}
proc ::GX::MagneticsAPIv1::operationMetadata {id} {
    set path [file join [file dirname [::GX::moduleField math.magnetics descriptor ""]] api operations_v1.tsv]
    set fd [open $path r]
    try {while {[gets $fd line]>=0} {if {[lindex [split $line |] 0] eq $id} {set familyContract [_familyMetadata [lindex [split $id .] 0]]; return [dict merge [dict create id $id summary [lindex [split $line |] 1] api_id MAGNETICS_API_v1 api_version 1] $familyContract [::GX::ScientificTransportv1::operationHelp magnetics $id $familyContract]]}}} finally {close $fd}
    return -code error -errorcode {GXTXT SCIENTIFIC UnknownOperation} "unknown operation $id"
}
proc ::GX::MagneticsAPIv1::_familyMetadata {family} {
    set path [file join [file dirname [::GX::moduleField math.magnetics descriptor ""]] api family_contracts_v1.tsv]
    set fd [open $path r]
    try {
        while {[gets $fd line] >= 0} {
            if {$line eq "" || [string index $line 0] eq "#"} continue
            set parts [split $line |]
            if {[llength $parts] != 7} {error "invalid scientific family contract"}
            if {[lindex $parts 0] eq $family} {
                return [dict create operands [lindex $parts 1] input_shapes [lindex $parts 2] result_shapes [lindex $parts 3] units [lindex $parts 4] complex_behavior [lindex $parts 5] errors [lindex $parts 6]]
            }
        }
    } finally {close $fd}
    error "missing scientific family contract: $family"
}
proc ::GX::MagneticsAPIv1::call {family action a b c {options {kind struct fields {}}}} {
    set id "$family.$action"
    if {[lsearch -exact [listOperations] $id]<0} {return -code error -errorcode {GXTXT SCIENTIFIC UnknownOperation} "unknown operation $id"}
    set raw [::GX::ScientificTransportv1::call math.magnetics gxtxt_magnetics_v1 $family $action $a $b $c $options]
    variable lastTypes;set lastTypes [dict get $raw types]
    return [dict get $raw values]
}
proc ::GX::MagneticsAPIv1::resultTypes {} {variable lastTypes;return $lastTypes}


# Exact per-signature Script Bridge profiles; original owner procedures are unchanged.
# MAGNETICS_API_v1 / math.magnetics / apiInfo / REGISTERED_TYPED_ADAPTER
# The original math.magnetics owner reads its fixed installed descriptor/version and capabilities without caller-selected paths or numerical execution. The api_info adapter calls that literal original owner and preserves every field, original capability order and provider-version lexeme, typing only the declared API version. Shared registry describe metadata is a distinct contract, not a substitute for this source result. No GUI, Document mutation, callback or new scientific implementation is involved.
# MAGNETICS_API_v1 / math.magnetics / call / REGISTERED_TYPED_ADAPTER
# The original public call accepts family,action,a,b,c and optional typed options, checks the concatenated ID against its own source list and invokes unchanged ScientificTransportv1 and the original fixed module kernel. The new call profile forwards the exact signature; omitted options reach the original Tcl default. It uses the original resultTypes and unchanged existing result codec, preserving complete current result fields, binary64 real/complex components, shapes and unit strings in the original bounded transport profile. Existing per-family/action routes remain compatible qualified specializations; Signal bulk execution remains its separate original route. No new estimator, arbitrary Tcl prefix, scientific whitelist, local-only restriction or native-buffer/uint64 extension is introduced. Typed result representation is not a promise of raw Tcl lexical/state-interface equivalence.
# MAGNETICS_API_v1 / math.magnetics / listOperations / REGISTERED_TYPED_ADAPTER
# The original owner reads its fixed module operations TSV and preserves order and exact membership. list_operations calls it literally; it does not return or regenerate Script Bridge registration keys. Signal original membership appends only statistical_contract, while operation_schema, validate_operation and new adapter profiles remain separate registered names. Unknown arguments refuse; installed path/descriptor authority stays with the original module. No calculation or host GUI lifetime is required.
# MAGNETICS_API_v1 / math.magnetics / operationMetadata / REGISTERED_TYPED_ADAPTER
# The original owner admits an actual operation ID against its fixed TSV, merges its original family/help metadata, and for Signal includes the original complete operationSchema result. operation_metadata preserves every original field, ordered argument descriptors/result fields, exact unit/default/bound lexemes and keyed full Signal schema including ui_field and final_scientific_checks. Unknown IDs retain the original owner error. This is installed data discovery, with no provider-command execution, caller file path or scientific algorithm copy.
# Script Bridge operation policy: math_magnetics_api_v1.script_bridge_policy.json
