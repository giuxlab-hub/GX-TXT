"""Inert metadata supplied by the existing export.curve_dataset public owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError
import math

_OPERATIONS = ('apiInfo',)
REGISTRATION = {
    'api_id': 'CURVE_DATASET_EXPORT_API_v1', 'api_version': 1,
    'provider_kind': 'module', 'provider_id': 'export.curve_dataset',
    'documentation_ref': 'plugins/modules/export.curve_dataset/MANUAL.md',
    'operations': {name: {'name': name, 'summary': 'Read existing provider metadata: '+name,
        'arguments': [], 'argument_convention': 'no arguments',
        'result_contract': 'Typed inert public owner metadata; no GUI/scientific operation'}
        for name in _OPERATIONS},
}
REGISTRATION['operations']['publish'] = {
    'name': 'publish', 'summary': 'Publish the actual held saved CurveViewer selection through its exact owner',
    'arguments': [{'name': name, 'kind': 'public value', 'required': True}
                  for name in ('document_id', 'record_id', 'expectation', 'parameters')],
    'result_contract': 'Create-only canonical exact rows/units/int64 row continuity/provenance; actual producer Module required',
}


def _publish(host, args):
    if host.module_id != 'export.curve_dataset':
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Curve publication requires its actual export.curve_dataset runtime producer')
    if len(args) != 4 or any(not isinstance(x, str) for x in args[:2]) or not all(isinstance(x, dict) for x in args[2:]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Choose a held saved Document/record/receipt and declared publication fields')
    document, record_id, expected, parameters = args
    if set(expected) != {'generation', 'revision', 'sha256'} or set(parameters)-{'dataset_id', 'display_name'} or 'dataset_id' not in parameters or any(not isinstance(x, str) for x in parameters.values()):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Publication accepts only held source identity and declared text parameters')
    parameters = dict(parameters, display_name=parameters.get('display_name', ''))
    revision = expected['revision']
    if isinstance(revision, bool) or not isinstance(revision, (int, float)) or not math.isfinite(revision) or int(revision) != revision or revision < 1 or any(not isinstance(expected[k], str) for k in ('generation', 'sha256')):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Publication needs exact positive revision/generation/SHA')
    session = str(host.call('::GX::interactiveDocumentSessionToken'))
    def guard():
        raw = host.call('::GX::interactiveDocumentRead', document);owner = host.as_dict(raw)
        if any(str(owner[k]) != str(int(revision) if k == 'revision' else expected[k]) for k in ('generation', 'revision', 'sha256')) or str(host.call('::GX::interactiveDocumentSessionToken')) != session:
            raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'CurveViewer Document/Session changed')
        if (str(owner['module_id']), str(owner['provider_id']), str(owner['format'])) != ('viewer.curve_viewer', 'curve_viewer', 'gxtxt.curve_viewer.viewer'):
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Publication requires its actual saved CurveViewer owner')
        return owner
    owner = guard();payload = host.as_dict(owner['payload'])
    if [str(x) for x in host.as_list(payload.get('selected_ids', ''))] != [record_id]:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Publish exactly the actual saved single selected source record')
    records = [host.as_dict(x) for x in host.as_list(payload['records'])]
    matches = [r for r in records if str(r['id']) == record_id]
    if len(matches) != 1 or not host.tcl.getboolean(matches[0]['visible']):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Selected canonical source is hidden or unavailable')
    record = matches[0]
    validation = host.as_dict(host.call('::GX::curveSourceValidateSnapshot', host.session, record['descriptor']))
    if not host.tcl.getboolean(validation['valid']): raise BridgeError('GXTXT:ScriptBridge:StaleInput', 'Selected exact Curve Source changed')
    definition = host.as_dict(host.call('::GX::workbenchExtensionDescribe', 'export.curve_dataset', 'publish'))
    if str(definition['command']) != '::GX::CurveDatasetExport::publish' or host.tcl.getboolean(definition['mutates']):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Curve exporter no longer matches its fixed nonmutating Document contract')
    context = {'workbench_id': 'viewer.curve_viewer', 'workbench_version': str(host.call('::GX::moduleField', 'viewer.curve_viewer', 'version')),
               'document_id': document, 'revision': int(revision), 'parameters': parameters,
               'selection': {'kind': 'curve_source', 'source_id': record_id, 'request': record['request'],
                             'descriptor': record['descriptor'], 'session_token': session, 'document_generation': expected['generation']}}
    actor = host.dataset_private_context()
    raw = host.call('::GX::_datasetPrivateWithModule', host.module_id, '::GX::workbenchExtensionInvoke', 'export.curve_dataset', 'publish', context)
    guard();result = host.as_dict(raw);dataset = str(result['dataset_id'])
    namespace = str(host.call('::GX::datasetNamespaceGet', host.session, dataset))
    producer = str(host.call('::GX::datasetField', dataset, 'producer_module', ''))
    if producer != host.module_id or namespace != str(actor['dataset_namespace']):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Original publication producer/namespace differs from actual runtime authority')
    return {'status': str(result['status']), 'dataset_id': dataset, 'exact_rows': int(result['exact_rows']),
            'producer_module': producer, 'namespace': namespace, 'source_document_id': document,
            'provenance': host.as_dict(result['provenance'])}


def invoke(host, operation, args):
    if operation == 'publish': return _publish(host, args)
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown provider metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Provider metadata takes no arguments')
    host.call('::GX::modulePublicApiActivate', 'export.curve_dataset', 'CURVE_DATASET_EXPORT_API_v1')
    raw = host.call('::GX::CurveDatasetExport::'+operation)
    result = {str(key): str(value) for key, value in host.as_dict(raw).items()}
    result['api_version'] = int(result['api_version'])
    for key in ('operations', 'scientific_authorities'):
        result[key] = [str(item) for item in host.as_list(host.as_dict(raw)[key])]
    return result
