"""Inert metadata supplied by the existing viewer.3d_workbench public owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_OPERATIONS = ('apiInfo',)
REGISTRATION = {
    'api_id': 'WORKBENCH_3D_API_v1', 'api_version': 1,
    'provider_kind': 'module', 'provider_id': 'viewer.3d_workbench',
    'documentation_ref': 'plugins/modules/viewer.3d_workbench/MANUAL.md',
    'operations': {name: {'name': name, 'summary': 'Read existing provider metadata: '+name,
        'arguments': [], 'argument_convention': 'no arguments',
        'result_contract': 'Typed inert public owner metadata; no GUI/scientific operation'}
        for name in _OPERATIONS},
}


def invoke(host, operation, args):
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown provider metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Provider metadata takes no arguments')
    host.call('::GX::modulePublicApiActivate', 'viewer.3d_workbench', 'WORKBENCH_3D_API_v1')
    raw = host.call('::GX::Workbench3D::'+operation)
    source = host.as_dict(raw)
    result = {str(key): str(value) for key, value in source.items()
              if key not in ('api_version', 'operations', 'gui_commands', 'editable_hosts')}
    result['api_version'] = int(source['api_version'])
    result['editable_hosts'] = bool(int(source['editable_hosts']))
    for key in ('operations', 'gui_commands'):
        result[key] = [str(item) for item in host.as_list(source[key])]
    return result
