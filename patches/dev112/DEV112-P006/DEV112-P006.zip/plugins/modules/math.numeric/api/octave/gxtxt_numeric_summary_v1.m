% Public bounded selected-fact compositions of existing NUMERIC_API_v1 owners.
% SPDX-License-Identifier: GPL-3.0-or-later
function out=gxtxt_numeric_summary_v1(operation,values,options)
  if(!isstruct(options)||numel(options)!=1),error('GXTXT:Numeric:Summary','Options must be a scalar struct');endif
  if(!isnumeric(values)||!isreal(values)||issparse(values)||ndims(values)>2|| ...
     (!isempty(values)&&!isvector(values))||numel(values)>16777216|| ...
     !any(strcmp(class(values),{'uint8','uint16','int16','single','double'})))
    error('GXTXT:Numeric:Summary','A dense real uint8/uint16/int16/float32/float64 vector of at most16777216 samples is required');
  endif
  allowed={'contract_version'};
  if(strcmp(operation,'histogram_summary')),allowed=[allowed {'mode','bins','domain_low','domain_high'}];endif
  unknown=setdiff(fieldnames(options),allowed);
  if(!isempty(unknown)),error('GXTXT:Numeric:Summary','Unknown summary option: %s',unknown{1});endif
  if(isfield(options,'contract_version')&&(!isnumeric(options.contract_version)||!isreal(options.contract_version)||!isscalar(options.contract_version)||options.contract_version!=1))
    error('GXTXT:Numeric:Summary','Only summary contract_version1 is supported');
  endif
  values=values(:);out=classifications(values);
  if(strcmp(operation,'statistics_summary'))
    out.schema='gxtxt.numeric.statistics_summary.v1';
    out.minimum=NaN;out.maximum=NaN;out.mean=NaN;out.stddev=NaN;
    out.availability='no_finite_samples';out.variance='population';
    out.nonfinite_policy='exclude_and_count';
    integer_input=any(strcmp(class(values),{'uint8','uint16','int16'}));
    if(integer_input),out.arithmetic='numeric.array_reduce_mean_residual_rms';
    else out.arithmetic='numeric.faithful_expansion_mean_residual_rms';endif
    if(out.finite_count)
      opts=struct('nonfinite','omit');
      lo=gxtxt_numeric_v1('array_reduce','minimum',values,opts);
      hi=gxtxt_numeric_v1('array_reduce','maximum',values,opts);
      out.minimum=lo.values;out.maximum=hi.values;
      if(exist('gxtxt_numeric_faithful_native','file')!=3),error('GXTXT:Numeric:Summary','Required C++17 Numeric precision binding is unavailable');endif
      if(integer_input)
        mean_result=gxtxt_numeric_v1('array_reduce','mean',values,opts);
        precision=gxtxt_numeric_faithful_native(values,mean_result.values);
        if(precision.finite_count!=out.finite_count),error('GXTXT:Numeric:Summary','Native finite count differs from public masks');endif
        std_result=struct('values',precision.rmse);
      else
        precision=gxtxt_numeric_faithful_native(values);
        if(precision.finite_count!=out.finite_count),error('GXTXT:Numeric:Summary','Native finite count differs from public masks');endif
        mean_result=struct('values',precision.mean);std_result=struct('values',precision.stddev);
      endif
      out.mean=mean_result.values;out.stddev=std_result.values;out.availability='available';
    endif
  elseif(strcmp(operation,'histogram_summary'))
    out=histogram_facts(values,options,out);
  else error('GXTXT:Numeric:Summary','Unknown summary operation');endif
endfunction

function out=classifications(values)
  out=struct('total_count',numel(values),'finite_count',0,'nan_count',0,'positive_inf_count',0,'negative_inf_count',0);
  names={'is_finite','is_nan','is_pos_inf','is_neg_inf'};
  fields={'finite_count','nan_count','positive_inf_count','negative_inf_count'};
  for first=1:65536:numel(values)
    block=values(first:min(first+65535,numel(values)));
    for column=1:numel(names)
      mask=gxtxt_numeric_v1('array_unary',names{column},block);
      count=gxtxt_numeric_v1('array_reduce','count_true',mask.values);
      out.(fields{column})+=count.values;
    endfor
  endfor
endfunction

function out=histogram_facts(values,options,out)
  mode='native';if(isfield(options,'mode')),mode=options.mode;endif
  if(!ischar(mode)||!any(strcmp(mode,{'native','bounded'}))),error('GXTXT:Numeric:Summary','Histogram mode must be native or bounded');endif
  dtype=class(values);if(strcmp(dtype,'single')),dtype='float32';elseif(strcmp(dtype,'double')),dtype='float64';endif
  if(strcmp(mode,'native'))
    if(!any(strcmp(dtype,{'uint8','uint16','int16'}))),error('GXTXT:Numeric:Summary','Native histogram requires original uint8/uint16/int16 dtype');endif
    if(any(isfield(options,{'bins','domain_low','domain_high'}))),error('GXTXT:Numeric:Summary','Native histogram domain is determined by dtype');endif
    lower=0;bins=65536;if(strcmp(dtype,'int16')),lower=-32768;elseif(strcmp(dtype,'uint8')),bins=256;endif
    upper=lower+bins;width=1;
  else
    if(!all(isfield(options,{'bins','domain_low','domain_high'}))),error('GXTXT:Numeric:Summary','Bounded histogram requires bins, domain_low and domain_high');endif
    bins=options.bins;lower=options.domain_low;upper=options.domain_high;
    if(!isnumeric(bins)||!isscalar(bins)||!isreal(bins)||!isfinite(bins)||bins!=fix(bins)||bins<1||bins>4096|| ...
       !isnumeric(lower)||!isnumeric(upper)||!isscalar(lower)||!isscalar(upper)||!isreal(lower)||!isreal(upper)||!isfinite(lower)||!isfinite(upper))
      error('GXTXT:Numeric:Summary','Bounded histogram requires1..4096 bins and finite scalar edges');
    endif
    bins=double(bins);lower=double(lower);upper=double(upper);span=upper-lower;width=span/bins;
    if(!(lower<upper)||!isfinite(span)||span<=0||!isfinite(width)||width<=0),error('GXTXT:Numeric:Summary','Histogram domain must have a finite positive representable width');endif
  endif
  edges=lower+width*(0:bins).';edges(end)=upper;
  if(any(!isfinite(edges))||any(diff(edges)<=0)),error('GXTXT:Numeric:Summary','Histogram uniform edges are not representable');endif
  counts=zeros(bins,1);underflow=0;overflow=0;
  for first=1:65536:numel(values)
    block=values(first:min(first+65535,numel(values)));
    mask=gxtxt_numeric_v1('array_unary','is_finite',block);
    selected=gxtxt_numeric_v1('array_select',block,mask.values);
    if(isempty(selected.values)),continue;endif
    hist=gxtxt_numeric_v1('histogram',selected.values,edges,struct('bin_mode','edges'));
    combined=gxtxt_numeric_v1('array_binary','add',counts,hist.counts);counts=combined.values;
    below=gxtxt_numeric_v1('array_compare','less_than',selected.values,lower);
    above=gxtxt_numeric_v1('array_compare','greater_than',selected.values,upper);
    count=gxtxt_numeric_v1('array_reduce','count_true',below.values);underflow+=count.values;
    count=gxtxt_numeric_v1('array_reduce','count_true',above.values);overflow+=count.values;
  endfor
  inside=gxtxt_numeric_v1('array_reduce','sum',counts);
  if(inside.values+underflow+overflow!=out.finite_count),error('GXTXT:Numeric:Summary','Histogram finite accounting differs');endif
  out.schema='gxtxt.numeric.histogram_summary.v1';out.counts=uint64(counts);
  out.mode=mode;out.dtype=dtype;out.bins=bins;out.lower=lower;out.upper=upper;out.width=width;
  out.last_inclusive=strcmp(mode,'bounded');out.edge_rule='lower_plus_width_times_index';
  out.count_dtype='uint64';out.in_range_count=inside.values;out.underflow_count=underflow;out.overflow_count=overflow;
  out.count_endian='little';
  out.arithmetic='numeric.histogram_explicit_edges_exact_counts';
endfunction
