// NUMERIC_API_v1 native precision adapter; no image or lifecycle authority.
// SPDX-License-Identifier: GPL-3.0-or-later
#include <octave/oct.h>
#include "../c/gxtxt_numeric_faithful_v1.hpp"

namespace {
// Typed admission to the existing public residual authority, without a full
// binary64 conversion or an allocated constant-prediction vector.
template<class Array>
octave_value centered_residual(const Array& values,double center) {
  if(values.numel()>gxtxt_numeric_v1::summary_max_samples ||
     !std::isfinite(center) || std::abs(center)>std::numeric_limits<float>::max())
    error("GXTXT:Numeric:Summary: residual count/center domain exceeded");
  gx_numeric_residual_accumulator_v1 accumulator;
  gx_numeric_residual_init_v1(&accumulator);
  for(octave_idx_type i=0;i<values.numel();++i){
    if((i&65535)==0)OCTAVE_QUIT;
    if(gx_numeric_residual_push_v1(&accumulator,static_cast<double>(values(i))-center)!=GX_NUMERIC_OK_V1)
      error("GXTXT:Numeric:Summary: public residual accumulation refused");
  }
  gx_numeric_residual_result_v1 result;
  const auto status=gx_numeric_residual_finish_v1(&accumulator,&result);
  if(status!=GX_NUMERIC_OK_V1 && status!=GX_NUMERIC_EMPTY_V1)
    error("GXTXT:Numeric:Summary: public residual finalization refused");
  octave_scalar_map out;
  out.assign("finite_count",static_cast<double>(values.numel()));
  out.assign("center",center);
  out.assign("rmse",status==GX_NUMERIC_EMPTY_V1?std::numeric_limits<double>::quiet_NaN():result.rmse);
  return octave_value(out);
}
}

DEFUN_DLD(gxtxt_numeric_faithful_native,args,,
          "Public Numeric contract v1 faithful finite mean and residual RMS") {
  if((args.length()!=1 && args.length()!=2) || !args(0).isnumeric() || args(0).iscomplex() ||
     args(0).ndims()>2 || (args(0).numel() && !args(0).dims().isvector()))
    error("GXTXT:Numeric:Summary: a real vector is required");
  if(args.length()==2){
    if(!args(1).isnumeric() || args(1).iscomplex() || args(1).numel()!=1)
      error("GXTXT:Numeric:Summary: a finite scalar residual center is required");
    const double center=args(1).double_value();
    if(args(0).is_uint8_type())return centered_residual(args(0).uint8_array_value(),center);
    if(args(0).is_uint16_type())return centered_residual(args(0).uint16_array_value(),center);
    if(args(0).is_int16_type())return centered_residual(args(0).int16_array_value(),center);
    error("GXTXT:Numeric:Summary: centered residual binding requires uint8/uint16/int16");
  }
  gxtxt_numeric_v1::float_moments_result result;
  gx_numeric_status_v1 status;
  if(args(0).is_single_type()){
    const FloatNDArray values=args(0).float_array_value();
    status=gxtxt_numeric_v1::float_moments(values.data(),values.numel(),&result);
  }else if(args(0).is_double_type()){
    const NDArray values=args(0).array_value();
    status=gxtxt_numeric_v1::float_moments(values.data(),values.numel(),&result);
  }else error("GXTXT:Numeric:Summary: native precision requires single or double");
  if(status!=GX_NUMERIC_OK_V1 && status!=GX_NUMERIC_EMPTY_V1)
    error("GXTXT:Numeric:Summary: precision domain/count/state limit exceeded");
  octave_scalar_map out;
  out.assign("finite_count",static_cast<double>(result.finite_count));
  out.assign("mean",result.mean);out.assign("stddev",result.population_stddev);
  return octave_value(out);
}
