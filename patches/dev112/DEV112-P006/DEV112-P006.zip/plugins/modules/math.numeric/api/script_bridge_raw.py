"""Source-faithful Numeric raw contracts; original Tcl owns every computation."""
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
import importlib.util
from gxtxt_script_bridge_server import BridgeError

_RESULT_CONTRACTS = {
    'scientific': 'Complete original result with number/boolean/string/vector/matrix/tensor/struct/cell types from owner resultTypes immediately after call',
    'metadata': 'Exact owner boolean, ordered text list, text or current-interpreter type map; no inferred numerical alias',
    'pointwise_capture': 'Original expression or pointwise receipt plus row_count/unit, managed Resource reference, managed_array exact shape/dtype, transport counts and source revisions; bounded source/query/options retained',
    'statistical_capture': 'Original values/types/captured_statistics/transport envelope; canonical statistical result or Resource binding through existing CORE codecs, with captured_column references distinct from sample values',
}

def _contract(name, formals, arguments, codec):
    fields = [{'name': key, 'kind': 'exact original Tcl source value', 'required': required,
               'default_source': default} for key, required, default in arguments]
    return {'name': name, 'summary': 'Exact original Numeric ' + name, 'arguments': fields,
            'source_command': '::GX::NumericAPIv1::' + name,
            'host_command': '::GX::NumericAPIv1::' + name, 'source_formals': formals,
            'argument_convention': formals, 'result_convention': _RESULT_CONTRACTS[codec],
            'result_contract': _RESULT_CONTRACTS[codec], 'result_codec': codec,
            'unit_behavior': 'Exact original owner units and interpretation; no relabelling',
            'context_requirements': 'CORE current Session; canonical Document for captures; source owner validates all original context',
            'minimum_arguments': sum(required for _, required, _ in arguments),
            'maximum_arguments': len(arguments)}

# The registration table itself is the sole dispatch table. Original owners
# validate selectors/capabilities/models, so no parallel eligibility list exists.
OPERATIONS = {
    'supports': _contract('supports', 'capability', [('capability', True, None)], 'metadata'),
    'expressionDataset': _contract('expressionDataset', 'expression bindings parameters options', [('expression', True, None), ('bindings', True, None), ('parameters', True, None), ('options', True, None)], 'scientific'),
    'expressionDatasetCaptured': _contract('expressionDatasetCaptured', 'document expression bindings parameters options', [('document', True, None), ('expression', True, None), ('bindings', True, None), ('parameters', True, None), ('options', True, None)], 'pointwise_capture'),
    'callOperationCaptured': _contract('callOperationCaptured', 'document id operands context {options {kind struct fields {}}} {provenance {}}', [('document', True, None), ('id', True, None), ('operands', True, None), ('context', True, None), ('options', False, '{kind struct fields {}}'), ('provenance', False, '{}')], 'statistical_capture'),
    'interpolateDatasetCaptured': _contract('interpolateDatasetCaptured', 'document source query {options {method linear extrapolation error}}', [('document', True, None), ('source', True, None), ('query', True, None), ('options', False, '{method linear extrapolation error}')], 'pointwise_capture'),
    'complexDatasetCaptured': _contract('complexDatasetCaptured', 'document dataset realVariable imaginaryVariable projection options', [('document', True, None), ('dataset', True, None), ('realVariable', True, None), ('imaginaryVariable', True, None), ('projection', True, None), ('options', True, None)], 'pointwise_capture'),
    'modelKinds': _contract('modelKinds', 'id', [('id', True, None)], 'metadata'),
    'callModelOperation': _contract('callModelOperation', 'id model operands {options {kind struct fields {}}}', [('id', True, None), ('model', True, None), ('operands', True, None), ('options', False, '{kind struct fields {}}')], 'scientific'),
    'resultTypes': _contract('resultTypes', '', [], 'metadata'),
    'arrayUnary': _contract('arrayUnary', 'name operand {options {}}', [('name', True, None), ('operand', True, None), ('options', False, '{}')], 'scientific'),
    'arrayBinary': _contract('arrayBinary', 'name left right {options {}}', [('name', True, None), ('left', True, None), ('right', True, None), ('options', False, '{}')], 'scientific'),
    'arrayCompare': _contract('arrayCompare', 'name left right {options {}}', [('name', True, None), ('left', True, None), ('right', True, None), ('options', False, '{}')], 'scientific'),
    'arrayMask': _contract('arrayMask', 'name first {second {}}', [('name', True, None), ('first', True, None), ('second', False, '{}')], 'scientific'),
    'arraySelect': _contract('arraySelect', 'values mask', [('values', True, None), ('mask', True, None)], 'scientific'),
    'arrayWhere': _contract('arrayWhere', 'mask trueValues falseValues', [('mask', True, None), ('trueValues', True, None), ('falseValues', True, None)], 'scientific'),
    'arrayReduce': _contract('arrayReduce', 'name operand {options {}}', [('name', True, None), ('operand', True, None), ('options', False, '{}')], 'scientific'),
    'complexUnary': _contract('complexUnary', 'name realPart imaginaryPart {options {}}', [('name', True, None), ('realPart', True, None), ('imaginaryPart', True, None), ('options', False, '{}')], 'scientific'),
    'complexBinary': _contract('complexBinary', 'name realA imaginaryA realB imaginaryB {options {}}', [('name', True, None), ('realA', True, None), ('imaginaryA', True, None), ('realB', True, None), ('imaginaryB', True, None), ('options', False, '{}')], 'scientific'),
    'unwrap': _contract('unwrap', 'phase {options {}}', [('phase', True, None), ('options', False, '{}')], 'scientific'),
    'comparisonCurves': _contract('comparisonCurves', 'mode x1 y1 x2 y2 {options {}}', [('mode', True, None), ('x1', True, None), ('y1', True, None), ('x2', True, None), ('y2', True, None), ('options', False, '{}')], 'scientific'),
    'resample': _contract('resample', 'x y targetX {options {}}', [('x', True, None), ('y', True, None), ('targetX', True, None), ('options', False, '{}')], 'scientific'),
    'resampleUniform': _contract('resampleUniform', 'x y step {options {}}', [('x', True, None), ('y', True, None), ('step', True, None), ('options', False, '{}')], 'scientific'),
    'splineCreate': _contract('splineCreate', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'splineEvaluate': _contract('splineEvaluate', 'model xq {options {}}', [('model', True, None), ('xq', True, None), ('options', False, '{}')], 'scientific'),
    'splineIntegral': _contract('splineIntegral', 'model a b {options {}}', [('model', True, None), ('a', True, None), ('b', True, None), ('options', False, '{}')], 'scientific'),
    'integrate': _contract('integrate', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'cumulativeIntegrate': _contract('cumulativeIntegrate', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'differentiate': _contract('differentiate', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'gridInfo': _contract('gridInfo', 'x {options {}}', [('x', True, None), ('options', False, '{}')], 'scientific'),
    'validateMonotonic': _contract('validateMonotonic', 'x {options {}}', [('x', True, None), ('options', False, '{}')], 'scientific'),
    'uniformGrid': _contract('uniformGrid', 'start stop spacing {options {}}', [('start', True, None), ('stop', True, None), ('spacing', True, None), ('options', False, '{}')], 'scientific'),
    'commonRange': _contract('commonRange', 'x1 x2 {options {}}', [('x1', True, None), ('x2', True, None), ('options', False, '{}')], 'scientific'),
    'statisticsSummary': _contract('statisticsSummary', 'values {options {kind struct fields {}}}', [('values', True, None), ('options', False, '{kind struct fields {}}')], 'scientific'),
    'histogramSummary': _contract('histogramSummary', 'values {options {kind struct fields {}}}', [('values', True, None), ('options', False, '{kind struct fields {}}')], 'scientific'),
    'statisticsResponsive': _contract('statisticsResponsive', 'values {options {}} {progress {}}', [('values', True, None), ('options', False, '{}'), ('progress', False, '{}')], 'scientific'),
    'rank': _contract('rank', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'covariance': _contract('covariance', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'correlation': _contract('correlation', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'ecdf': _contract('ecdf', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'normalCdf': _contract('normalCdf', 'x mu sigma {options {}}', [('x', True, None), ('mu', True, None), ('sigma', True, None), ('options', False, '{}')], 'scientific'),
    'studentTCdf': _contract('studentTCdf', 't degreesOfFreedom {options {}}', [('t', True, None), ('degreesOfFreedom', True, None), ('options', False, '{}')], 'scientific'),
    'fCdf': _contract('fCdf', 'f df1 df2 {options {}}', [('f', True, None), ('df1', True, None), ('df2', True, None), ('options', False, '{}')], 'scientific'),
    'matrixSvd': _contract('matrixSvd', 'matrix {options {}}', [('matrix', True, None), ('options', False, '{}')], 'scientific'),
    'linearMatrix': _contract('linearMatrix', 'action matrix {other {}} {options {}}', [('action', True, None), ('matrix', True, None), ('other', False, '{}'), ('options', False, '{}')], 'scientific'),
    'foundationCaptured': _contract('foundationCaptured', 'document family action a b c context {options {kind struct fields {}}} {provenance {}}', [('document', True, None), ('family', True, None), ('action', True, None), ('a', True, None), ('b', True, None), ('c', True, None), ('context', True, None), ('options', False, '{kind struct fields {}}'), ('provenance', False, '{}')], 'statistical_capture'),
    'resampleIndices': _contract('resampleIndices', 'populationSize drawCount replicates seed {options {}}', [('populationSize', True, None), ('drawCount', True, None), ('replicates', True, None), ('seed', True, None), ('options', False, '{}')], 'scientific'),
    'residualMetrics': _contract('residualMetrics', 'observed predicted {options {}}', [('observed', True, None), ('predicted', True, None), ('options', False, '{}')], 'scientific'),
    'weightedQuantiles': _contract('weightedQuantiles', 'values weights probabilities {options {}}', [('values', True, None), ('weights', True, None), ('probabilities', True, None), ('options', False, '{}')], 'scientific'),
    'cumulativeSum': _contract('cumulativeSum', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'normalizeVector': _contract('normalizeVector', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'vectorSimilarity': _contract('vectorSimilarity', 'a b {options {}}', [('a', True, None), ('b', True, None), ('options', False, '{}')], 'scientific'),
    'weightedStatistics': _contract('weightedStatistics', 'values weights {options {}}', [('values', True, None), ('weights', True, None), ('options', False, '{}')], 'scientific'),
    'leastSquares': _contract('leastSquares', 'design response {weights {}} {options {}}', [('design', True, None), ('response', True, None), ('weights', False, '{}'), ('options', False, '{}')], 'scientific'),
    'fitInformationCriteria': _contract('fitInformationCriteria', 'plan', [('plan', True, None)], 'scientific'),
    'nestedFTest': _contract('nestedFTest', 'plan', [('plan', True, None)], 'scientific'),
    'parameterUncertainty': _contract('parameterUncertainty', 'plan', [('plan', True, None)], 'scientific'),
    'derivedProperties': _contract('derivedProperties', 'plan', [('plan', True, None)], 'scientific'),
    'fitBootstrap': _contract('fitBootstrap', 'model predictors response plan {options {kind struct fields {}}}', [('model', True, None), ('predictors', True, None), ('response', True, None), ('plan', True, None), ('options', False, '{kind struct fields {}}')], 'scientific'),
    'fitProfile': _contract('fitProfile', 'model predictors response plan {options {kind struct fields {}}}', [('model', True, None), ('predictors', True, None), ('response', True, None), ('plan', True, None), ('options', False, '{kind struct fields {}}')], 'scientific'),
    'predictionUncertainty': _contract('predictionUncertainty', 'model predictors plan {options {kind struct fields {}}}', [('model', True, None), ('predictors', True, None), ('plan', True, None), ('options', False, '{kind struct fields {}}')], 'scientific'),
    'linearRegression': _contract('linearRegression', 'x y {weights {}} {options {}}', [('x', True, None), ('y', True, None), ('weights', False, '{}'), ('options', False, '{}')], 'scientific'),
    'polynomialFit': _contract('polynomialFit', 'x y degree {weights {}} {options {}}', [('x', True, None), ('y', True, None), ('degree', True, None), ('weights', False, '{}'), ('options', False, '{}')], 'scientific'),
    'polynomialEvaluate': _contract('polynomialEvaluate', 'model xq {options {}}', [('model', True, None), ('xq', True, None), ('options', False, '{}')], 'scientific'),
    'digitalFilter': _contract('digitalFilter', 'y b a {options {}}', [('y', True, None), ('b', True, None), ('a', True, None), ('options', False, '{}')], 'scientific'),
    'findPeaks': _contract('findPeaks', 'x y {options {}}', [('x', True, None), ('y', True, None), ('options', False, '{}')], 'scientific'),
    'baselineAnchored': _contract('baselineAnchored', 'x y anchorX anchorY {options {}}', [('x', True, None), ('y', True, None), ('anchorX', True, None), ('anchorY', True, None), ('options', False, '{}')], 'scientific'),
    'propagateIndependentUncertainty': _contract('propagateIndependentUncertainty', 'jacobian standardUncertainty {options {}}', [('jacobian', True, None), ('standardUncertainty', True, None), ('options', False, '{}')], 'scientific'),
    'propagateCovariance': _contract('propagateCovariance', 'jacobian covariance {options {}}', [('jacobian', True, None), ('covariance', True, None), ('options', False, '{}')], 'scientific'),
    'fft': _contract('fft', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'ifft': _contract('ifft', 'realValues imaginaryValues {options {}}', [('realValues', True, None), ('imaginaryValues', True, None), ('options', False, '{}')], 'scientific'),
    'analyticSignal': _contract('analyticSignal', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'frequencyGrid': _contract('frequencyGrid', 'sampleRate nfft {options {}}', [('sampleRate', True, None), ('nfft', True, None), ('options', False, '{}')], 'scientific'),
    'oneSided': _contract('oneSided', 'realValues imaginaryValues {options {}}', [('realValues', True, None), ('imaginaryValues', True, None), ('options', False, '{}')], 'scientific'),
    'detrend': _contract('detrend', 'values {options {}}', [('values', True, None), ('options', False, '{}')], 'scientific'),
    'window': _contract('window', 'name length {options {}}', [('name', True, None), ('length', True, None), ('options', False, '{}')], 'scientific'),
    'integrateDataset': _contract('integrateDataset', 'session datasetId xVariableId yVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'cumulativeIntegrateDataset': _contract('cumulativeIntegrateDataset', 'session datasetId xVariableId yVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'differentiateDataset': _contract('differentiateDataset', 'session datasetId xVariableId yVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'interpolateDataset': _contract('interpolateDataset', 'session datasetId xVariableId yVariableId targetX {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('targetX', True, None), ('options', False, '{}')], 'scientific'),
    'resampleUniformDataset': _contract('resampleUniformDataset', 'session datasetId xVariableId yVariableId step {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('step', True, None), ('options', False, '{}')], 'scientific'),
    'resampleDataset': _contract('resampleDataset', 'session datasetId xVariableId yVariableId targetOrStep {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('targetOrStep', True, None), ('options', False, '{}')], 'scientific'),
    'resampleExplicitDataset': _contract('resampleExplicitDataset', 'session datasetId xVariableId yVariableId targetX {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('targetX', True, None), ('options', False, '{}')], 'scientific'),
    'statisticsDataset': _contract('statisticsDataset', 'session datasetId variableId {options {}}', [('session', True, None), ('datasetId', True, None), ('variableId', True, None), ('options', False, '{}')], 'scientific'),
    'reduceSummaryDataset': _contract('reduceSummaryDataset', 'session datasetId variableId {options {}}', [('session', True, None), ('datasetId', True, None), ('variableId', True, None), ('options', False, '{}')], 'scientific'),
    'weightedStatisticsDataset': _contract('weightedStatisticsDataset', 'session datasetId variableId weightVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('variableId', True, None), ('weightVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'gridInfoDataset': _contract('gridInfoDataset', 'session datasetId xVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'polynomialFitDataset': _contract('polynomialFitDataset', 'session datasetId xVariableId yVariableId degree {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('degree', True, None), ('options', False, '{}')], 'scientific'),
    'smoothDataset': _contract('smoothDataset', 'session datasetId xVariableId yVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'findPeaksDataset': _contract('findPeaksDataset', 'session datasetId xVariableId yVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'baselineDataset': _contract('baselineDataset', 'session datasetId xVariableId yVariableId {options {}}', [('session', True, None), ('datasetId', True, None), ('xVariableId', True, None), ('yVariableId', True, None), ('options', False, '{}')], 'scientific'),
    'arrayUnaryDataset': _contract('arrayUnaryDataset', 'session datasetId variableId name {options {}}', [('session', True, None), ('datasetId', True, None), ('variableId', True, None), ('name', True, None), ('options', False, '{}')], 'scientific'),
    'arrayBinaryDataset': _contract('arrayBinaryDataset', 'session datasetId leftVariableId rightVariableId name {options {}}', [('session', True, None), ('datasetId', True, None), ('leftVariableId', True, None), ('rightVariableId', True, None), ('name', True, None), ('options', False, '{}')], 'scientific'),
    'arrayScalarDataset': _contract('arrayScalarDataset', 'session datasetId variableId scalar name {options {}}', [('session', True, None), ('datasetId', True, None), ('variableId', True, None), ('scalar', True, None), ('name', True, None), ('options', False, '{}')], 'scientific'),
    'capabilities': _contract('capabilities', '', [], 'metadata'),
    'requireCapability': _contract('requireCapability', 'capability', [('capability', True, None)], 'metadata'),
    'octaveFunction': _contract('octaveFunction', '', [], 'metadata'),
    'octaveAvailable': _contract('octaveAvailable', '', [], 'metadata'),
    'octaveApiDir': _contract('octaveApiDir', '', [], 'metadata'),
}

_semantics = None


def _semantics_codec():
    """Reuse the canonical CORE record codecs without another semantics engine."""
    global _semantics
    if _semantics is None:
        path = Path(__file__).resolve().parents[4] / 'core/script_bindings/statistical_result_semantics.py'
        spec = importlib.util.spec_from_file_location('gxtxt_numeric_raw_statistics_codec', path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        _semantics = module
    return _semantics


def _session(host, value):
    # Explicit raw Session paths retain the current CORE authority only. Reject
    # other spellings before normalization, lookup, Selection reads or workers.
    if not isinstance(value, str) or not host.session or value != host.session:
        raise BridgeError('GXTXT:Numeric:Context', 'Session must equal the CORE-bound current Session')


def _text_map(host, raw):
    return {str(k): str(v) for k, v in host.as_dict(raw).items()}


def _number_map(host, raw, convert=float):
    return {str(k): convert(v) for k, v in host.as_dict(raw).items()}


def _transport(host, raw):
    # ScientificTransportv1::binaryCall owns these byte/count receipt fields.
    return _number_map(host, raw, int)


def _dimensions(host, raw):
    """Exact CORE expression-dimensional receipt, no dimensional computation."""
    out = host.as_dict(raw)
    for field in ('schema', 'expression', 'output_unit', 'dimension_label',
                  'normalization', 'variable_exponent_policy'):
        out[field] = str(out[field])
    out['symbol_units'] = _text_map(host, out['symbol_units'])
    out['symbol_scales'] = _number_map(host, out['symbol_scales'])
    out['dimensions'] = _number_map(host, out['dimensions'])
    for field in ('inferred_parameter_ids', 'used_symbols'):
        out[field] = [str(v) for v in host.as_list(out[field])]
    out['output_scale'] = float(out['output_scale'])
    out['constraint_count'] = int(out['constraint_count'])
    return out


def _expression_receipt(host, raw):
    """gxtxt_numeric_expression_v1 dataset result after captured values removal."""
    fields = raw if isinstance(raw, dict) else host.as_dict(raw)
    out = dict(fields)
    for field in ('schema', 'unit', 'expression', 'domain_policy', 'grammar_owner',
                  'numeric_owner', 'alignment'):
        out[field] = str(out[field])
    out['symbol_ids'] = [str(v) for v in host.as_list(out['symbol_ids'])]
    out['dimensions'] = _dimensions(host, out['dimensions'])
    out['sources'] = []
    for source in host.as_list(fields['sources']):
        item = host.as_dict(source)
        for key in ('row_start', 'row_count'):
            item[key] = int(item[key])
        out['sources'].append(item)
    out['parameter_metadata'] = {}
    for key, parameter in host.as_dict(fields['parameter_metadata']).items():
        value = host.as_dict(parameter)
        out['parameter_metadata'][str(key)] = {'value': float(value['value']), 'unit': str(value['unit'])}
    return out


def _pointwise_receipt(host, raw, operation):
    out = dict(raw) if isinstance(raw, dict) else host.as_dict(raw)
    if operation == 'interpolateDatasetCaptured':
        for key in ('n_source', 'n_query'):
            out[key] = int(out[key])
    return out


def _resource(host, raw, operation):
    # Same record produced by managedResourceWrite/ImportNumeric. Never expose
    # or accept the owner's temporary captured-file path.
    out = host.as_dict(raw)
    out['size_bytes'] = int(out['size_bytes'])
    metadata = host.as_dict(out['metadata'])
    metadata['row_count'] = int(metadata['row_count'])
    metadata['columns'] = [str(v) for v in host.as_list(metadata['columns'])]
    metadata['source_revisions'] = _text_map(host, metadata['source_revisions'])
    if operation == 'expressionDatasetCaptured':
        metadata['expression_receipt'] = _expression_receipt(host, metadata['expression_receipt'])
    else:
        metadata['pointwise_receipt'] = _pointwise_receipt(host, metadata['pointwise_receipt'], operation)
    out['metadata'] = metadata
    return out


def _row_spec(host, raw):
    out = host.as_dict(raw)
    for key in ('start', 'count'):
        out[key] = int(out[key])
    return out


def _pointwise_capture(host, raw, operation):
    fields = host.as_dict(raw)
    common = {'row_count', 'unit', 'resource', 'array', 'transport'}
    if operation == 'expressionDatasetCaptured':
        out = _expression_receipt(host, {key: value for key, value in fields.items()
                                         if key not in common or key == 'unit'})
    else:
        out = _pointwise_receipt(host, {key: value for key, value in fields.items() if key not in common}, operation)
    out['row_count'] = int(fields['row_count'])
    out['unit'] = str(fields['unit'])
    out['resource'] = _resource(host, fields['resource'], operation)
    array = host.as_dict(fields['array'])
    out['array'] = {'kind': str(array['kind']), 'reference': _resource(host, array['reference'], operation),
                    'shape': [int(v) for v in host.as_list(array['shape'])], 'dtype': str(array['dtype'])}
    out['transport'] = _transport(host, fields['transport'])
    if operation == 'interpolateDatasetCaptured':
        for field in ('source', 'query'):
            out[field] = _row_spec(host, fields[field])
        out['options'] = _text_map(host, fields['options'])
    elif operation == 'complexDatasetCaptured':
        out['options'] = _row_spec(host, fields['options'])
    return out


def _statistical_capture(host, raw, adapt):
    fields = host.as_dict(raw)
    types = _text_map(host, fields['types'])
    values = host.as_dict(fields['values'])
    shapes = host.as_dict(fields['cell_shapes']) if 'cell_shapes' in fields else {}
    arrays = host.as_dict(fields['array_shapes']) if 'array_shapes' in fields else {}
    out = {'values': adapt(host, values, types, cell_shapes=shapes, array_shapes=arrays), 'types': types,
           'transport': _transport(host, fields['transport'])}
    if 'cell_shapes' in fields:
        out['cell_shapes'] = {str(path): [int(d) for d in host.as_list(shape)]
                              for path, shape in shapes.items()}
    if 'array_shapes' in fields:
        out['array_shapes'] = {str(path): [int(d) for d in host.as_list(shape)]
                               for path, shape in arrays.items()}
    codec = _semantics_codec()
    captured = host.as_dict(fields['captured_statistics'])
    if captured.get('schema') == 'gxtxt.statistical_result.resource_binding.v1':
        out['captured_statistics'] = codec._resource_binding(host, fields['captured_statistics'])
        # The existing codec retains all fields; normalize the shape map that
        # the original provider added to canonical Resource metadata.
        metadata = out['captured_statistics']['resource']['metadata']
        if 'original_field_shapes' in metadata:
            metadata['original_field_shapes'] = {
                str(k): [int(v) for v in host.as_list(shape)]
                for k, shape in host.as_dict(metadata['original_field_shapes']).items()}
    else:
        out['captured_statistics'] = codec._result(host, fields['captured_statistics'])
    return out


def invoke(host, operation, args, adapt, operative):
    """Invoke the exact original contract, including default and context guards."""
    spec = OPERATIONS.get(operation)
    if spec is None or not spec['minimum_arguments'] <= len(args) <= spec['maximum_arguments']:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid exact Numeric source argument count')
    host.call('::GX::modulePublicApiActivate', 'math.numeric', 'NUMERIC_API_v1')
    args = list(args)
    if spec['result_codec'] in ('pointwise_capture', 'statistical_capture') and not isinstance(args[0], str):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Captured Numeric calls require a text canonical Document ID')
    if spec['arguments'] and spec['arguments'][0]['name'] == 'session':
        _session(host, args[0])
    if operation == 'statisticsResponsive' and len(args) == 3:
        # The original optional field is an executable Tcl progress prefix.
        # Only omission or its literal empty value belongs to this data facet.
        if not ((isinstance(args[2], str) and args[2] == '')
                or (isinstance(args[2], (list, tuple)) and len(args[2]) == 0)):
            raise BridgeError('GXTXT:Numeric:CallbackRequired', 'Executable Tcl progress prefixes remain in their owning Host')
        args[2] = ''
    if operation == 'callOperationCaptured':
        if not isinstance(args[1], str) or not isinstance(args[2], (list, tuple)):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Captured catalog calls require a text ID and ordered typed operands')
        operative.guard_catalog(host, args[1], args[2])
    elif operation == 'foundationCaptured':
        if not isinstance(args[1], str) or not isinstance(args[2], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Captured foundation family and action must be text')
        operative.guard_foundation(host, args[1], args[2], args[3])
    elif operation == 'callModelOperation':
        if not isinstance(args[0], str) or not isinstance(args[2], (list, tuple)):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Model calls require a text operation ID and ordered typed operands')
        if args[0] == 'dataset_nonlinear_fit':
            if not args[2]:
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Dataset model operands require their source Session node')
            operative.guard_session(host, args[2][0])
    raw = host.call(spec['source_command'], *args)
    if spec['result_codec'] == 'metadata':
        if operation in ('supports', 'requireCapability', 'octaveAvailable'):
            return bool(int(raw))
        if operation in ('modelKinds', 'capabilities'):
            return [str(v) for v in host.as_list(raw)]
        if operation == 'resultTypes':
            return _text_map(host, raw)
        return str(raw)
    if spec['result_codec'] == 'statistical_capture':
        return _statistical_capture(host, raw, adapt)
    if spec['result_codec'] == 'pointwise_capture':
        return _pointwise_capture(host, raw, operation)
    types = _text_map(host, host.call('::GX::NumericAPIv1::resultTypes'))
    return adapt(host, raw, types)
