"""Complete metadata records from the original NUMERIC_API_v1 Tcl owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError


# These are public Tcl method names in the existing math.numeric API. Catalog
# contents, scientific defaults, capabilities and availability remain owned by
# that API; this module only declares and serializes the shared client route.
_ARGUMENTS = {
    "listOperations": (),
    "operationMetadata": ("id",),
    "operationByExpressionName": ("name",),
    "listFoundationOperations": (),
    "foundationOperationMetadata": ("id",),
    "apiInfo": (),
}
_SUMMARIES = {
    "listOperations": "List every original Numeric operation catalog ID",
    "operationMetadata": "Read the complete original Numeric operation record",
    "operationByExpressionName": "Resolve one unambiguous original expression operation record",
    "listFoundationOperations": "List every original Numeric foundation action ID",
    "foundationOperationMetadata": "Read the complete original Numeric foundation action record",
    "apiInfo": "Read original Numeric API identity, capabilities and live availability",
}
OPERATIONS = {
    name: {
        "name": name,
        "summary": _SUMMARIES[name],
        "arguments": [{"name": argument, "kind": "string", "required": True}
                      for argument in arguments],
        "argument_convention": ", ".join(arguments) if arguments else "no arguments",
        "result_convention": "Complete original Tcl metadata with declared field types and original refusals",
        "result_contract": "Original NUMERIC_API_v1 metadata; no field omission or fabricated defaults",
        "unit_behavior": "Original record unit_behavior is preserved; metadata performs no numerical computation",
        "host_command": "::GX::NumericAPIv1::" + name,
    }
    for name, arguments in _ARGUMENTS.items()
}


def _record(host, raw, lists=(), integers=(), booleans=(), list_maps=()):
    """Apply the types declared by the owner's dict creation expressions.

    Tcl dict/list string representations alone cannot distinguish empty maps,
    lists, text and integer fields. Read every original field, then explicitly
    convert only its declared type. Never parse or duplicate a catalog here.
    """
    fields = host.as_dict(raw)
    result = {key: str(value) for key, value in fields.items()}
    for key in lists:
        result[key] = [str(value) for value in host.as_list(fields[key])]
    for key in integers:
        result[key] = int(fields[key])
    for key in booleans:
        result[key] = bool(host.tcl.getboolean(fields[key]))
    for key in list_maps:
        result[key] = {str(name): [str(value) for value in host.as_list(values)]
                       for name, values in host.as_dict(fields[key]).items()}
    return result


def invoke(host, operation, args):
    if operation not in _ARGUMENTS:
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", "Unknown Numeric metadata method")
    arguments = _ARGUMENTS[operation]
    if len(args) != len(arguments) or not all(isinstance(value, str) for value in args):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments",
                          operation + " requires " + (", ".join(arguments) if arguments else "no arguments"))
    host.call("::GX::modulePublicApiActivate", "math.numeric", "NUMERIC_API_v1")
    # Unknown/ambiguous identifiers and framework/catalog failures remain the
    # original owner's errors, propagated by the common Script Bridge wrapper.
    raw = host.call("::GX::NumericAPIv1::" + operation, *args)
    if operation in ("listOperations", "listFoundationOperations"):
        return [str(value) for value in host.as_list(raw)]
    if operation in ("operationMetadata", "operationByExpressionName"):
        return _record(host, raw,
                       lists=("bindings", "arguments", "accepted_kinds", "nonfinite_policies", "flags"),
                       integers=("arity_min", "arity_max", "api_version"),
                       list_maps=("options",))
    if operation == "foundationOperationMetadata":
        return _record(host, raw, lists=("arguments", "flags", "bindings"), integers=("api_version",))
    return _record(host, raw,
                   lists=("capabilities", "dataset_expression_methods", "dataset_pointwise_methods",
                          "octave_callback_operations"),
                   integers=("api_version",), booleans=("octave_available",))
