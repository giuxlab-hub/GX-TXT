"""Transport-only public Numeric catalog and declared foundation admission.

The original Tcl owners validate the original catalogs, typed operands, model
kinds and context. Their original Octave providers execute the mathematics.
"""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, CallbackRef


OPERATIONS = {
    "callOperation": {
        "name": "callOperation",
        "summary": "Invoke an original Numeric catalog selector using its typed owner contract",
        "argument_convention": "id, ordered typed operands, optional typed options struct",
        "result_convention": "original structured result with original ScientificTransport result types",
        "arguments": [
            {"name": "id", "kind": "original catalog selector", "required": True},
            {"name": "operands", "kind": "ordered typed operand nodes", "required": True},
            {"name": "options", "kind": "typed options struct", "required": False},
        ],
        "result_contract": "original catalog result and complete typed fields",
        "unit_behavior": "original per-selector Numeric contract",
    }
}


def _typed_options(args, index):
    return args[index] if len(args) > index else {"kind": "struct", "fields": {}}


def guard_session(host, node):
    """Keep the original explicit Session operand bound to this execution."""
    if not isinstance(node, dict) or node.get("kind") != "text" or node.get("value") != host.session:
        raise BridgeError("GXTXT:Numeric:SessionContext", "Numeric Session operand must equal the current execution Session exactly")


def guard_foundation(host, family, action, a):
    if not isinstance(family, str) or not isinstance(action, str):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "foundation family and action must be text")
    # The original foundation owner applies lower(strtrim(...)) before its
    # dispatch. Apply those same semantics to guards, leaving caller arguments
    # unchanged for the owner; otherwise mixed case could miss a path facet.
    normalized_family = family.strip().lower()
    normalized_action = action.strip().lower()
    selector = normalized_family + "." + normalized_action
    flags = []
    if selector in host.as_list(host.call("::GX::NumericAPIv1::listFoundationOperations")):
        metadata = host.as_dict(host.call("::GX::NumericAPIv1::foundationOperationMetadata", selector))
        flags = host.as_list(metadata["flags"])
    # Some original safe owner branches, such as family.parameter_interpolate,
    # predate their catalog entry. This guard does not authorize/register them
    # or replace the original provider's action validation with a new allowlist.
    # Original advanced_v1 geometry_action -> vtk_geometry_file_action:
    # geometry.mesh_smooth reads its path and writes options.output_path via
    # the external VTK helper; geometry.mesh_remesh does the same with remeshing.
    # geometry.mesh_boolean additionally reads a second_path mesh.
    # geometry.volume_slice reads a host volume path and executes that helper.
    # These original file_resource facets need host path/process authority,
    # which a Script argument does not grant. The original catalog is the sole
    # list of file_resource actions; do not maintain a second selector allowlist.
    if "file_resource" in flags:
        raise BridgeError("GXTXT:Numeric:HostPathRequired", family + "." + action + " requires host-owned geometry paths and process authority")
    # geometry.mesh_section has TWO original source branches: numeric vertices
    # and triangles remain admitted; char(a) instead enters the same host-file
    # VTK helper despite the catalog's data_only flag. Deny only that path facet.
    if normalized_family == "geometry" and normalized_action == "mesh_section":
        if isinstance(a, str) or isinstance(a, dict) and a.get("kind") == "text":
            raise BridgeError("GXTXT:Numeric:HostPathRequired", "geometry.mesh_section file-path facet requires host ownership; typed mesh arrays remain available")
        # Original scientific operands are typed nodes. A list posing as a
        # dictionary, or a list-valued kind, can otherwise become a text node
        # through Tcl string conversion and enter the same file-path branch.
        if not isinstance(a, dict) or not isinstance(a.get("kind"), str):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "geometry.mesh_section requires a typed mesh node with an actual text kind")


def guard_catalog(host, operation, operands):
    """Apply original catalog context without creating selector registrations."""
    if not isinstance(operation, str) or not isinstance(operands, (list, tuple)):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "catalog context requires a text selector and ordered typed operand nodes")
    if operation == "foundation":
        if len(operands) < 3:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "foundation catalog selector requires typed text family and action and its operands")
        family, action = operands[:2]
        # ScientificTransport's text node contract requires actual text.
        # Do not skip guards for malformed list/dict/number text values that
        # Tcl might stringify into a real original-owner dispatch keyword.
        if not all(isinstance(v, dict) and v.get("kind") == "text" and isinstance(v.get("value"), str) for v in (family, action)):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "foundation catalog family and action require text nodes with string values")
        guard_foundation(host, family["value"], action["value"], operands[2])
        # The original callOperation owner still decides whether this selector
        # exists; this check never invents a foundation catalog alias.
    metadata = host.as_dict(host.call("::GX::NumericAPIv1::operationMetadata", operation))
    names = host.as_list(metadata["arguments"])
    flags = host.as_list(metadata["flags"])
    # dataset_expression declares Session as its first operand without the
    # dataset flag. Use the original argument metadata for that existing facet.
    if "dataset" in flags or names and names[0] == "session":
        if not operands:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Dataset catalog operation requires its typed Session operand")
        guard_session(host, operands[0])
    # configure_fft_threads is the original worker-local process setting. This
    # catalog route uses ScientificTransport's per-call worker; its return is
    # not persistent Python/Octave frontend FFT configuration.


def _result(host, command, args, adapt):
    raw = host.call(command, *args)
    types = host.as_dict(host.call("::GX::NumericAPIv1::resultTypes"))
    return adapt(host, raw, types)


def invoke(host, operation, args, adapt):
    if operation != "callOperation":
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", "unknown Numeric catalog parent")
    if len(args) not in (2, 3) or not isinstance(args[0], str) or not isinstance(args[1], (list, tuple)):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "callOperation requires id, ordered typed operands and optional typed options")
    # Preserve the exact raw public parent, including callback rejection,
    # per-selector arity, Dataset/Selection resolution and typed option policy.
    guard_catalog(host, args[0], args[1])
    return _result(host, "::GX::NumericAPIv1::callOperation",
                   [args[0], args[1], _typed_options(args, 2)], adapt)


def invoke_foundation(host, args, adapt):
    """Admit existing data declarations for the two formerly refused families."""
    if len(args) not in (5, 6) or not all(isinstance(x, str) for x in args[:2]):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "foundation requires family, action, three typed operands and optional options")
    family, action, model, b, c = args[:5]
    if family not in ("equations", "variational"):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "declared foundation adapter requires its original family")
    guard_foundation(host, family, action, model)
    if isinstance(model, CallbackRef):
        # equations.solve, equations.multiple_start and equations.continuation
        # execute fsolve in the original Octave equations_action owner.
        # variational.action, variational.functional, variational.legendre,
        # variational.first_variation, variational.euler_lagrange_residual and
        # variational.constrained execute the original variational_action owner.
        # Each needs an Octave function_handle. CORE's existing binary Worker
        # packs data only and has no CallbackRef request/response relay into that
        # process. A live Python/Octave client callback cannot be serialized into
        # that owner. Safe original model declarations below remain available;
        # do not substitute a different Python scientific implementation.
        raise BridgeError("GXTXT:Numeric:CallbackRequired", family + "." + action + " requires the original in-process Octave function handle or its admitted typed model declaration")
    # callModelOperation/modelKinds is the existing sole declaration authority;
    # it constructs the function handle inside the scientific owner process.
    return _result(host, "::GX::NumericAPIv1::callModelOperation",
                   ["foundation." + family + "." + action, model, [b, c], _typed_options(args, 5)], adapt)
