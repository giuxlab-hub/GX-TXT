# Scientific Trace Preview 1.0.1

This genuine Builder-authored compiled C++ Preview uses the current canonical
Dataset and existing public Plot/Native2D, numeric-array and metadata owners.
It does not implement a parser, renderer, publication or private filesystem API.
The module is independent of importer identity/version. Install matching P033
CORE public native-client facilities and enable the module through ordinary
Preview Configuration; installation does not silently enable a new Preview.

Local controls browse actual Variable batches, exact C-order values hyperslabs,
Metadata and Source metadata. Explicit First Variable is user enumeration, not
a scientific-axis default. Canonical values/coordinates/units are rendered by
CORE; no first16 event sample, invented index X or flattened frame is substituted.
The frame uses actual Variable/dimension IDs and strict JSON fixed-axis indices.
All actions are presentation only; source/scientific payload remains unchanged.

This private candidate still requires actual native/public/scientific/GUI/cold
and independent gates. Source/AST or generic headless Test alone is not runtime
availability or scientific acceptance. Unavailable capabilities explicitly refuse.

Version 1.0.1 places binding controls in the existing Source tab and compacts existing local paging controls. The default Plot uses the whole declared notebook page. Source, numerical data, handlers, role identities and SDK remain unchanged; actual shared CORE viewport behavior and independent acceptance are separate.


## Script Bridge tab metadata

The existing `VIEWER_DEVELOPMENT_API_v1` version1 core provider
`viewer_development` exposes `preview_tabs("preview.scientific_trace", dataset_id)`.
It returns the complete ordered original tab dictionaries from this installed
Preview and the current execution's canonical Dataset. Dataset IDs use the
original canonical owner validator, including valid leading digits and long IDs.
The installed module selector keeps its existing128-character lexical bound.

This metadata read does not mount the Preview, create widgets, launch its compiled
runtime or grant scientific/source-write operations. The raw callback and typed
route retain different missing-ID behavior: the original may return no tabs,
while the typed route refuses an absent current Dataset. The signature has no
held Session, revision or SHA argument and provides no atomic source certificate;
source replacement between reads requires another current read. Associated-source
pane availability does not establish that the associated code is current.
No new `PREVIEW_COMPONENT_GUI_API_v1` Script registration is introduced.
Full raw contract/transport and final installed/controller qualification remain
separate from this guarded existing owner projection.
