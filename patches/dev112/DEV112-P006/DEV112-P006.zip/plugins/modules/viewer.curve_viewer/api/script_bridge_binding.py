"""Canonical eligible source IDs from the existing read-only Curve Viewer."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_API='CURVE_VIEWER_API_v1'
REGISTRATION={'api_id':_API,'api_version':1,'provider_kind':'module','provider_id':'viewer.curve_viewer',
 'documentation_ref':'plugins/modules/viewer.curve_viewer/README.md',
 'operations':{'datasetIds':{'name':'datasetIds','summary':'List existing canonical Curve Viewer source IDs',
 'host_command':'::GX::CurveViewer::datasetIds','arguments':[],'argument_convention':'no arguments',
 'result_contract':'Current canonical Dataset ID list selected by unchanged rank/dtype schema owner; no GUI instance or source mutation.'}}}

def invoke(host,operation,args):
 if operation!='datasetIds':raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
 if args:raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Curve Viewer datasetIds takes no arguments')
 host.call('::GX::modulePublicApiActivate','viewer.curve_viewer',_API)
 return [str(value)for value in host.as_list(host.call('::GX::CurveViewer::datasetIds'))]
