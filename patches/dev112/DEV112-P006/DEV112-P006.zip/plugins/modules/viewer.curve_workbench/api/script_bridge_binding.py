"""Canonical schema and exact bounded rows from the existing Curve Source owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_API='CURVE_WORKBENCH_API_v1';_OWNER='::GX::CurveWorkbench::'
_FIELDS={'datasetIds':[],'variables':[('datasetId',True)],
 'loadCurves':[('dataset',True),('x',True),('y',True),('filter',False),('value',False),('family',False),('order',False)]}
REGISTRATION={'api_id':_API,'api_version':1,'provider_kind':'module','provider_id':'viewer.curve_workbench',
 'documentation_ref':'plugins/modules/viewer.curve_workbench/CURVE_WORKBENCH_API_v1.md',
 'operations':{name:{'name':name,'summary':'Existing canonical Curve Workbench owner: '+name,'host_command':_OWNER+name,
  'arguments':[{'name':key,'kind':'canonical Dataset/Variable ID or literal filter value','required':required}for key,required in fields],
  'argument_convention':', '.join(key for key,_ in fields)or'no arguments',
  'result_contract':'Typed canonical schema or a list of {family_value, samples} groups with exact original source-row/point identity and literal order values; empty/arbitrary family values remain values. Unchanged units, filters, family and 65536-row-per-curve bound. No UI/native controller, callback or caller geometry transfer.'}for name,fields in _FIELDS.items()}}

def _identity(host,dataset):
 return {key:str(value)for key,value in host.as_dict(host.call('::GX::curveSourceDatasetIdentity',host.session,dataset)).items()}

def invoke(host,operation,args):
 if operation not in _FIELDS:raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
 fields=_FIELDS[operation]
 if not sum(required for _,required in fields)<=len(args)<=len(fields)or any(not isinstance(v,str)for v in args):
  raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Curve Workbench source IDs/filter values must be strings with the declared argument count')
 host.call('::GX::modulePublicApiActivate','viewer.curve_workbench',_API)
 if operation=='loadCurves':
  session=str(host.call('::GX::interactiveDocumentSessionToken'));identity=_identity(host,args[0])
 raw=host.call(_OWNER+operation,*args)
 if operation=='datasetIds':return [str(value)for value in host.as_list(raw)]
 if operation=='variables':
  return {key:({name:str(value)for name,value in host.as_dict(values).items()}if key=='labels'else[str(value)for value in host.as_list(values)])for key,values in host.as_dict(raw).items()}
 if str(host.call('::GX::interactiveDocumentSessionToken'))!=session or _identity(host,args[0])!=identity:
  raise BridgeError('GXTXT:ScriptBridge:Ownership','Canonical Curve Source changed during row loading; load current source again')
 return [{'family_value':group,'samples':[{key:float(value)if key in('x','y')else int(value)if key=='row'else str(value)for key,value in host.as_dict(row).items()}for row in host.as_list(rows)]}for group,rows in host.as_dict(raw).items()]
