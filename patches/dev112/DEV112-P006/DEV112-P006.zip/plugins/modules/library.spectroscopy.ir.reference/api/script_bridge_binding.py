"""Inert metadata supplied by the existing library.spectroscopy.ir.reference public owner."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_OPERATIONS = ('apiInfo',)
REGISTRATION = {
    'api_id': 'IR_LIBRARY_TYPE_PROVIDER_API_v1', 'api_version': 1,
    'provider_kind': 'module', 'provider_id': 'library.spectroscopy.ir.reference',
    'documentation_ref': 'plugins/modules/library.spectroscopy.ir.reference/IR_LIBRARY_TYPE_PROVIDER_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Read existing provider metadata: '+name,
        'arguments': [], 'argument_convention': 'no arguments',
        'result_contract': 'Typed inert public owner metadata; no GUI/scientific operation'}
        for name in _OPERATIONS},
}


# These are fixed aliases of the exact transparent Tcl owner delegates, using
# the existing Manager's typed projection and managed content/error guards.
_DATA_OPERATIONS = {
    'listLibraries': ('compatible_libraries', ()),
    'listEntries': ('legacy_entries', ('libraryId',)),
    'readSpectrum': ('read_spectrum', ('libraryId', 'spectrumId')),
}
for _name, (_method, _arguments) in _DATA_OPERATIONS.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Read original IR provider Library data: '+_name,
        'arguments': [{'name': arg, 'kind': 'logical identity string', 'required': True} for arg in _arguments],
        'argument_convention': ', '.join(_arguments) or 'no arguments',
        'result_contract': ('Existing Manager typed Spectrum with binary64 X/Y and textual metadata/provenance; known-field/frame bounds'
                            if _name == 'readSpectrum' else 'Original logical Library or ordered entry ID strings; discovery is not content admission'),
    }


def invoke(host, operation, args):
    if operation in _DATA_OPERATIONS:
        method, arguments = _DATA_OPERATIONS[operation]
        if len(args) != len(arguments) or any(not isinstance(value, str) for value in args):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'IR provider reads require exactly their logical identity strings')
        host.call('::GX::modulePublicApiActivate', 'library.spectroscopy.ir.reference', 'IR_LIBRARY_TYPE_PROVIDER_API_v1')
        values = ['spectroscopy.ir.reference'] if operation == 'listLibraries' else list(args)
        return host.modules['SCIENTIFIC_LIBRARY_MANAGER_API_v1'].invoke(host, method, values)
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown provider metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Provider metadata takes no arguments')
    host.call('::GX::modulePublicApiActivate', 'library.spectroscopy.ir.reference', 'IR_LIBRARY_TYPE_PROVIDER_API_v1')
    raw = host.call('::GX::IRLibraryTypeProviderAPIv1::'+operation)
    result = {str(key): str(value) for key, value in host.as_dict(raw).items()}
    result['api_version'] = int(result['api_version'])
    return result
