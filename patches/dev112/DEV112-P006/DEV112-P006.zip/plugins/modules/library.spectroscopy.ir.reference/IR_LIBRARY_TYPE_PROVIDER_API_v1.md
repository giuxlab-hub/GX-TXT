# IR Library Type Provider API v1

SPDX-License-Identifier: GPL-3.0-or-later

Provider module: `library.spectroscopy.ir.reference`.
Library type: `spectroscopy.ir.reference`.

The provider is discovered by Scientific Library Manager API v1 through the
normal installed module descriptor. Its Python provider entrypoint validates
GX-TXT Scientific Reference Library v1 data as IR spectra, including stable
spectrum IDs, valid source integrity, wavenumber or wavelength coordinates,
nonempty response representation and at least eight samples per spectrum.
The data package remains independent of this executable provider plugin.

The public Tcl API exposes `apiInfo`, `listLibraries`, `listEntries` and
`readSpectrum`. All accept logical IDs; consumers receive no managed storage
paths. The generic manager owns install, update, remove and verify.

| Exact signature in `::GX::IRLibraryTypeProviderAPIv1` | Result |
|---|---|
| `apiInfo` | Dictionary with `api_name`, `api_version`, `provider_id` and `library_type`. |
| `listLibraries` | List of compatible logical library ID strings, rather than library records. |
| `listEntries libraryId` | Ordered list of stable entry ID strings, rather than entry records. |
| `readSpectrum libraryId spectrumId` | Manager spectrum dictionary containing the actual arrays, metadata and provenance. |

Discovery uses the Manager's installed registry modes. A listed library does
not prove that remote access or another external runtime is currently available.

## Shared Script Bridge routes

The existing module-owned `IR_LIBRARY_TYPE_PROVIDER_API_v1` version1 registration
keeps `apiInfo()` and exposes the original camelCase methods `listLibraries()`,
`listEntries(libraryId)` and `readSpectrum(libraryId,spectrumId)`. The provider
identity remains `library.spectroscopy.ir.reference`; actual declared module API
activation and installed-owner checks remain required. There is no second API
registry, provider, scientific parser or arbitrary invocation route.

The three original Tcl methods are transparent Manager delegates. Their shared
routes reuse the existing Manager typed adapter: fixed IR compatible-library
filter, managed saved entry-ID discovery, and guarded spectrum content reads.
Library discovery includes supported installed registry modes and does not prove
content access. Entry discovery returns saved ordered logical IDs; it does not
perform live content verification or unlock credentials. `listEntries` and
`readSpectrum` retain their original generic managed-provider delegation; only
`listLibraries` has the fixed IR type filter. No extra IR-only whitelist is added.

Spectrum results retain known scientific scalar fields, integer sample count,
floating endpoint bounds, binary64 X/Y and actual textual metadata/provenance
under existing Manager frame limits. Extra arbitrary raw provider fields are not
a promised result. Callers supply only the declared identity strings, never
provider overrides, Session/storage paths, callbacks, credentials or options.
The original Manager owns locking, provider/record/source identity, content and
credential policy, integrity checks before/after the read and registry stability.

`SCIENTIFIC_REFERENCE_LIBRARY_API_v1/managed_read_spectrum` remains a distinct
counterpart: it additionally requires explicit managed Reference interoperability,
uses the Reference reader and runs the original Spectrum value validation. Shared
scientific meaning does not make it a full raw `readSpectrum` alias.
