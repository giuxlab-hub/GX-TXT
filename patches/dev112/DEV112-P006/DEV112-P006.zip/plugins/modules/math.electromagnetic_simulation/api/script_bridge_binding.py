"""Provider-owned public native EM scientific binding. GPL-3.0-or-later."""
import math
from gxtxt_script_bridge_server import BridgeError

_SIGNATURES = {
    "api_info": ("apiInfo", []), "default_model": ("defaultModel", [("kind", "string", True)]),
    "validate_model": ("validate", [("model", "struct", True)]),
    "save_model": ("saveModel", [("model", "struct", True), ("document_id", "string", False), ("workspace_name", "string", False)]),
    "list_models": ("listModels", []), "load_model": ("loadModel", [("document_id", "string", True)]),
    "run_async": ("runAsync", [("model", "struct", True)]),
    "job_status": ("jobStatus", [("job_id", "string", True)]), "cancel": ("cancel", [("job_id", "string", True)]),
    "job_log": ("jobLog", [("job_id", "string", True), ("offset", "integer", False), ("count", "integer", False)]),
    "result_describe": ("resultDescribe", [("job_id", "string", True)]),
    "result_preview": ("resultPreview", [("job_id", "string", True), ("offset", "integer", False), ("count", "integer", False)]),
    "publish": ("publish", [("job_id", "string", True), ("dataset_id", "string", True)]),
    "field_describe": ("fieldDescribe", [("dataset_id", "string", True)]),
}
REGISTRATION = {"api_id": "ELECTROMAGNETIC_SIMULATION_API_v1", "api_version": 1,
                "provider_kind": "module", "provider_id": "math.electromagnetic_simulation",
                "documentation_ref": "plugins/modules/math.electromagnetic_simulation/README.md", "operations": {
                    name: {"name": name, "summary": "Public native electromagnetic " + name.replace("_", " "),
                           "arguments": [{"name": n, "kind": k, "required": r} for n, k, r in fields],
                           "result_contract": "Typed existing CORE/domain result; SI science and stable canonical identities"}
                    for name, (_, fields) in _SIGNATURES.items()}}


def _typed_result(host, operation, raw):
    if operation == "job_log":
        result = host.as_dict(raw)
        for key in ("offset", "next_offset", "size"):
            if key in result:
                result[key] = int(result[key])
        for key in ("available", "eof", "complete", "cursor_reset"):
            if key in result:
                result[key] = bool(host.tcl.getboolean(result[key]))
        return result
    if operation == "result_describe":
        result = host.as_dict(raw)
        for key in ("free_nodes", "mesh_nodes", "mesh_triangles"):
            result[key] = int(result[key])
        for key in ("max_field_gradient_relative_error", "solver_residual_absolute",
                    "independent_relative_weak_residual", "analytic_max_relative_field_error",
                    "analytic_area_rms_relative_field_error", "mesh_current_A", "nominal_circle_current_A",
                    "ampere_loop_T_m", "ampere_mesh_expected_T_m", "ampere_mesh_relative_error"):
            if key in result:
                result[key] = float(result[key])
        result["solver_versions"] = host.as_dict(result["solver_versions"])
        return result
    if operation == "result_preview":
        result = host.as_dict(raw)
        header = [str(value) for value in host.as_list(result["header"])]
        rows = []
        for raw_row in host.as_list(result["rows"]):
            values = host.as_list(raw_row)
            if len(values) != len(header):
                raise BridgeError("GXTXT:ScriptBridge:Transport", "Native electromagnetic preview row shape differs")
            rows.append([int(value) if name.endswith("_id") else float(value)
                         for name, value in zip(header, values)])
        return {"header": header, "rows": rows, "offset": int(result["offset"]), "total": int(result["total"])}
    return host.normalize(raw)


def invoke(host, operation, args):
    command, fields = _SIGNATURES[operation]
    if not sum(required for _, _, required in fields) <= len(args) <= len(fields):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Invalid electromagnetic operation arity")
    args = list(args)
    for index, (value, (_, kind, _)) in enumerate(zip(args, fields)):
        if kind == "struct" and not isinstance(value, dict) or kind == "string" and not isinstance(value, str) or kind == "integer" and (isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or int(value) != value):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Invalid typed electromagnetic operand")
        if kind == "integer":
            args[index] = int(value)
    if operation == "job_log":
        offset, count = (args[1] if len(args) > 1 else 0), (args[2] if len(args) > 2 else 65536)
        if not 0 <= offset <= 9223372036854775807 or not 1 <= count <= 65536:
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Electromagnetic log requires a nonnegative int64 offset and1..65536bytes")
    host.call("::GX::modulePublicApiActivate", "math.electromagnetic_simulation", "ELECTROMAGNETIC_SIMULATION_API_v1")
    result = host.call("::GX::ElectromagneticSimulation::" + command, *args)
    if operation in ("save_model", "publish"):
        host.persist_manifest(operation)
    return _typed_result(host, operation, result)
