"""Provider-owned Script Bridge binding for SIGNAL_API_v1."""
# SPDX-License-Identifier: GPL-3.0-or-later
from pathlib import Path
from gxtxt_script_bridge_server import BridgeError, NumericArray

_OPERATIONS = {}
for line in (Path(__file__).with_name("operations_v1.tsv")).read_text(encoding="utf-8").splitlines():
    if line and not line.startswith("#"):
        name, summary = line.split("|", 1)
        _OPERATIONS[name] = {"name": name, "summary": summary, "argument_convention": "a, b, c typed operands; optional typed options struct", "result_convention": "typed numeric result struct", "arguments": [{"name": key, "kind": "typed operand", "required": key != "options"} for key in ("a","b","c","options")], "result_contract": "numeric and diagnostic fields", "unit_behavior": "Operation-specific; see provider documentation"}
_FAMILIES = {}
for line in (Path(__file__).with_name("family_contracts_v1.tsv")).read_text(encoding="utf-8").splitlines():
    if line and not line.startswith("#"):
        fields = line.split("|")
        if len(fields) != 7:
            raise RuntimeError("invalid scientific family contract")
        family, operands, input_shapes, result_shapes, units, complex_behavior, errors = fields
        _FAMILIES[family] = {"operands": operands, "input_shapes": input_shapes,
                             "result_shapes": result_shapes, "units": units,
                             "complex_behavior": complex_behavior, "errors": errors.split(";")}
for name, operation in _OPERATIONS.items():
    operation.update(_FAMILIES[name.split(".", 1)[0]])

_OPERATIONS["statistical_contract"] = {
    "operation_kind": "metadata",
    "name": "statistical_contract", "summary": "Resolve a Signal operation's registered CORE statistical contract",
    "argument_convention": "signal_operation string", "result_convention": "bounded public contract dictionary",
    "arguments": [{"name": "signal_operation", "kind": "string", "required": True}],
    "result_contract": "Numeric operation and CORE model identity; no calculation or interpretation copy",
    "unit_behavior": "Actual units and availability are supplied by the public CORE API"}

_OPERATIONS['operation_schema'] = {
    'operation_kind':'metadata', 'name':'operation_schema',
    'summary':'Read the provider validator typed operation schema',
    'arguments':[{'name':'signal_operation','kind':'string','required':True}],
    'result_contract':'typed fields, defaults, units and conditional requirements'}
_OPERATIONS['validate_operation'] = {
    'operation_kind':'validation', 'name':'validate_operation',
    'summary':'Validate typed admission without numerical calculation',
    'arguments':[{'name':name,'kind':'typed operand' if name != 'operation' else 'string','required':True}
                 for name in ('operation','a','b','c','options')],
    'result_contract':'validation facts; final data-dependent checks remain in the numerical owner'}


# Fixed source-owned profiles. Shared registry discovery is not an alias for
# these complete original metadata results or the original call signature.
_CONTROL_ARGUMENTS = {
    'api_info': [], 'list_operations': [], 'operation_metadata': ['operation'],
    'call': ['family', 'action', 'a', 'b', 'c', 'options'],
}
_CONTROL_ARGUMENTS.update({'operation_schema_full':['operation'], 'validate_operation_full':['operation','a','b','c','options'], 'interpret_result':['operation','raw','context','provenance']})

for _name, _arguments in _CONTROL_ARGUMENTS.items():
    _OPERATIONS[_name] = {
        'name': _name, 'summary': 'Original provider owner profile: '+_name,
        'operation_kind': 'metadata' if _name in ('api_info','list_operations','operation_metadata','operation_schema_full') else 'validation' if _name == 'validate_operation_full' else 'interpretation' if _name == 'interpret_result' else 'scientific',
        'arguments': [{'name': value, 'kind': 'public typed owner argument',
                       'required': value not in ('options','provenance')} for value in _arguments],
        'result_contract': 'Complete original owner result through existing typed transport; no new numerical or provenance authority',
        'argument_convention': ', '.join(_arguments),
    }

REGISTRATION = {"api_id": "SIGNAL_API_v1", "api_version": 1, "provider_kind": "module", "provider_id": "math.signal", "documentation_ref": "plugins/modules/math.signal/SIGNAL_API_v1.md", "operations": _OPERATIONS}

def _adapt(host, raw, types):
    out = {}
    for key, value in host.as_dict(raw).items():
        kind = types.get(key)
        if kind == "number":
            out[key] = float(value)
        elif kind == "boolean":
            out[key] = str(value).lower() in ("1", "true", "yes", "on")
        elif kind == "string":
            out[key] = str(value)
        elif kind == "vector":
            values = [float(x) for x in host.as_list(value)]
            out[key] = NumericArray(values, [len(values), 1])
        elif kind == "matrix":
            rows = [host.as_list(row) for row in host.as_list(value)]
            nr = len(rows); nc = len(rows[0]) if rows else 0
            if any(len(row) != nc for row in rows):
                raise BridgeError("GXTXT:ScriptBridge:Transport", "matrix rows differ")
            out[key] = NumericArray([float(rows[r][c]) for c in range(nc) for r in range(nr)], [nr, nc])
        elif kind == "tensor":
            tensor = host.as_dict(value)
            shape = [int(x) for x in host.as_list(tensor["shape"])]
            values = [float(x) for x in host.as_list(tensor["values"])]
            out[key] = NumericArray(values, shape)
        else:
            raise BridgeError("GXTXT:ScriptBridge:Transport", f"unsupported result field {key} type {kind}")
    return out


def _owner_text(host, value):
    return str(host.tcl.call('format', '%s', value))


def _owner_metadata(host, raw):
    result = {str(key): _owner_text(host, value) for key,value in host.as_dict(raw).items()}
    if 'api_version' in result: result['api_version'] = int(result['api_version'])
    if 'capabilities' in result: result['capabilities'] = [_owner_text(host,v) for v in host.as_list(host.as_dict(raw)['capabilities'])]
    for key in ('arguments','result_fields'):
        if key in result: result[key] = [_owner_text(host,v) for v in host.as_list(host.as_dict(raw)[key])]
    if 'argument_descriptors' in result:
        result['argument_descriptors'] = [{str(k):_owner_text(host,v) for k,v in host.as_dict(item).items()} for item in host.as_list(host.as_dict(raw)['argument_descriptors'])]
    return result


def _owner_profile(host, operation, args):
    namespace = '::GX::SignalAPIv1::'
    host.call('::GX::modulePublicApiActivate', 'math.signal', 'SIGNAL_API_v1')
    if operation == 'call':
        if len(args) not in (5,6) or not all(isinstance(v,str) for v in args[:2]):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','call requires family,action,a,b,c and optional original typed options')
        # Omission really reaches the original Tcl default, not a copied default.
        raw = host.call(namespace+'call', *args)
        return _adapt(host, raw, host.as_dict(host.call(namespace+'resultTypes')))
    if operation in ('api_info','list_operations'):
        if args: raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','Original metadata owner takes no arguments')
        raw = host.call(namespace+('apiInfo' if operation=='api_info' else 'listOperations'))
        return [_owner_text(host,v) for v in host.as_list(raw)] if operation=='list_operations' else _owner_metadata(host,raw)
    if operation == 'operation_metadata':
        if len(args)!=1 or not isinstance(args[0],str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','operation_metadata requires an original operation ID')
        raw = host.call(namespace+'operationMetadata',args[0]); result = _owner_metadata(host,raw)
        if 'operation_schema' in host.as_dict(raw): result['operation_schema'] = _owner_schema(host,host.as_dict(raw)['operation_schema'])
        return result
    raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)


def _owner_schema(host, raw):
    original = host.as_dict(raw)
    result = {str(k):_owner_text(host,v) for k,v in original.items()}
    result['schema_version'] = int(original['schema_version'])
    fields = {}
    for name, raw_field in host.as_dict(original['fields']).items():
        source = host.as_dict(raw_field)
        field = {str(k):_owner_text(host,v) for k,v in source.items()}
        if 'choices' in source: field['choices'] = [_owner_text(host,v) for v in host.as_list(source['choices'])]
        ui = host.as_dict(source['ui_field'])
        field['ui_field'] = {str(k):_owner_text(host,v) for k,v in ui.items()}
        if 'values' in ui: field['ui_field']['values'] = [_owner_text(host,v) for v in host.as_list(ui['values'])]
        fields[str(name)] = field
    result['fields'] = fields
    # Decode the original declared constraint kinds; generate no schema or rule.
    kinds = {}
    for line in Path(__file__).with_name('operation_constraints_v1.tsv').read_text(encoding='utf-8').splitlines():
        if not line or line.startswith('#'): continue
        operation,name,kind,_ = line.split('|')
        if operation == result['operation']: kinds[name] = kind
    constraints = {}
    for name,value in host.as_dict(original['constraints']).items():
        kind = kinds[str(name)]
        constraints[str(name)] = ({str(k):_owner_text(host,v) for k,v in host.as_dict(value).items()} if kind=='map' else
                                  [_owner_text(host,v) for v in host.as_list(value)] if kind=='list' else _owner_text(host,value))
    result['constraints'] = constraints
    return result


def _signal_owner_profile(host, operation, args):
    host.call('::GX::modulePublicApiActivate','math.signal','SIGNAL_API_v1')
    if operation == 'operation_schema_full':
        if len(args)!=1 or not isinstance(args[0],str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','operation_schema_full requires an original operation ID')
        return _owner_schema(host,host.call('::GX::SignalAPIv1::operationSchema',args[0]))
    if operation == 'validate_operation_full':
        if len(args) not in (4,5) or not isinstance(args[0],str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','validate_operation_full requires operation,a,b,c and optional original typed options')
        # The original owner first resolves its schema and then invokes the
        # unchanged provider contract; its omission/default/error order stays.
        raw = host.as_dict(host.call('::GX::SignalAPIv1::validateOperation',*args))
        return {'valid':bool(host.tcl.getboolean(raw['valid'])), 'field_count':float(raw['field_count'])}
    if operation == 'interpret_result':
        if len(args) not in (3,4) or not isinstance(args[0],str) or any(not isinstance(v,dict) for v in args[1:]):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','interpret_result requires operation,original result,context and optional provenance structs')
        # Literal original Signal adaptation preserves its model/context guards.
        # Reuse only the existing CORE result codec, never an estimator copy or
        # the separate from_numeric route's optional field-pruning policy.
        raw = host.call('::GX::SignalAPIv1::interpretResult',*args)
        return host.modules['STATISTICAL_RESULT_SEMANTICS_API_v1']._result(host,raw)
    return _owner_profile(host,operation,args)

def invoke(host, operation, args):
    if operation in _CONTROL_ARGUMENTS:
        return _signal_owner_profile(host,operation,args)
    if operation not in _OPERATIONS:
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", operation)
    if operation == 'operation_schema':
        if len(args)!=1 or not isinstance(args[0],str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','operation_schema requires an operation ID')
        host.call('::GX::modulePublicApiActivate','math.signal','SIGNAL_API_v1')
        raw=host.as_dict(host.call('::GX::SignalAPIv1::operationSchema',args[0]))
        fields=[]
        for name,value in host.as_dict(raw['fields']).items():
            field=host.as_dict(value)
            field={str(k):str(v) for k,v in field.items() if k!='ui_field'}
            field['required']=field['required']=='1'
            if 'choices' in field:field['choices']=host.as_list(field['choices'])
            fields.append(field)
        constraints={}
        for key,value in host.as_dict(raw['constraints']).items():
            if str(key) in ('cutoff_length_by_band','cutoff_unit_by_domain','discrete_cutoff_range'):
                constraints[str(key)]={str(k):str(v) for k,v in host.as_dict(value).items()}
            else:constraints[str(key)]=host.as_list(value)
        return {'api_id':'SIGNAL_API_v1','schema_version':int(raw['schema_version']),
                'operation':str(raw['operation']),'fields':fields,
                'validation_owner':str(raw['validation_owner']),
                'constraints':constraints}
    if operation == 'validate_operation':
        if len(args)!=5 or not isinstance(args[0],str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments','validate_operation requires operation,a,b,c,options')
        from gxtxt_scientific_binary_v1 import call,native
        return call(host,'gxtxt_signal_v1',['contract',args[0]]+[native(v) for v in args[1:]])
    if operation == "statistical_contract":
        if len(args) != 1 or not isinstance(args[0], str):
            raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "statistical_contract requires one Signal operation string")
        host.call("::GX::modulePublicApiActivate", "math.signal", "SIGNAL_API_v1")
        result = {str(k): str(v) for k, v in host.as_dict(host.call("::GX::SignalAPIv1::statisticalContract", args[0])).items()}
        result["api_version"] = int(result["api_version"])
        return result
    if len(args) not in (3,4):
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "scientific operation requires a, b, c and optional options")
    host.call("::GX::modulePublicApiActivate", "math.signal", "SIGNAL_API_v1")
    family, action = operation.split(".", 1)
    if len(args) == 3:
        args.append({"kind": "struct", "fields": {}})
    # CORE bulk channel calls this provider's unchanged public Octave function.
    # Legacy Tcl callers continue to use ScientificTransportv1.
    try:
        from gxtxt_scientific_binary_v1 import call, native
    except ImportError:
        pass
    else:
        options = dict(args[3])
        fields = dict(options.get("fields", {}))
        projection_node = fields.pop("result_fields", None)
        projection = None
        if projection_node is not None:
            projected = native(projection_node)
            projection = projected.split(",") if isinstance(projected, str) else projected
            if not isinstance(projection, list) or not all(isinstance(x, str) and x for x in projection):
                raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "result_fields must name result fields")
        options["fields"] = fields
        return call(host, "gxtxt_signal_v1", [family, action] + [native(v) for v in args[:3]] + [native(options)], projection)
    raw = host.call("::GX::SignalAPIv1::call", family, action, *args)
    types = host.as_dict(host.call("::GX::SignalAPIv1::resultTypes"))
    return _adapt(host, raw, types)
