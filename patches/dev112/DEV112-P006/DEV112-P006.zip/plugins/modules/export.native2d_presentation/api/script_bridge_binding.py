"""Owned native display snapshots through the existing Workbench exporters."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_MODULE = 'export.native2d_presentation'
_API = 'NATIVE2D_EXPORT_API_v1'
REGISTRATION = {
    'api_id': _API, 'api_version': 1, 'provider_kind': 'module', 'provider_id': _MODULE,
    'documentation_ref': 'plugins/modules/export.native2d_presentation/MANUAL.md',
    'operations': {operation: {
        'name': operation, 'summary': 'Export the execution-owned Native2D display as ' + operation,
        'arguments': [{'name': 'scene', 'kind': 'execution-owned Native2D scene', 'required': True},
                      {'name': 'expectation', 'kind': 'held canonical Document generation/revision/sha256', 'required': True},
                      {'name': 'parameters', 'kind': 'existing exporter declared parameters', 'required': False},
                      {'name': 'presentation_options', 'kind': 'bounded snapshot caption/budget options', 'required': False}],
        'argument_convention': 'scene, expectation, optional parameters, optional presentation_options',
        'result_contract': 'uint8 presentation bytes and source identity; no output path or scientific materialization',
    } for operation in ('svg', 'png')},
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', message)


def _guard(host, scene, expected):
    scope = host.as_dict(host.call('::GX::_native2DGeometryRequire', scene))
    owner = host.as_dict(host.call('::GX::interactiveDocumentMetadata', scope['document_id']))
    if any(str(owner[key]) != str(expected[key]) for key in ('generation', 'revision', 'sha256')):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Presentation export Document changed; read its current receipt again')
    return scope, owner


def invoke(host, operation, args):
    if operation not in ('svg', 'png') or len(args) not in (2, 3, 4):
        _invalid('Presentation export requires scene/receipt and optional parameters/options')
    scene, expected = args[:2]
    if not isinstance(scene, str) or scene not in host.handles.get('native2d_geometry', {}).get('scenes', set()):
        _invalid('Presentation scene is not owned by this execution')
    if not isinstance(expected, dict) or set(expected) != {'generation', 'revision', 'sha256'}:
        _invalid('Presentation export requires exactly generation/revision/sha256')
    revision = expected['revision']
    if isinstance(revision, bool) or not isinstance(revision, (int, float)) or int(revision) != revision or revision < 1:
        _invalid('Presentation export revision must be a positive integer')
    expected = {**expected, 'revision': int(revision)}
    scope, owner = _guard(host, scene, expected)
    if not host.tcl.getboolean(host.call('::GX::_nativeWorkspaceExists', scope['document_id'])):
        _invalid('Presentation export requires the canonical native Workbench Workspace')
    definition = host.as_dict(host.call('::GX::workbenchExtensionDescribe', _MODULE, operation))
    workbench = str(owner['module_id'])
    if workbench not in host.as_list(definition['workbenches']) or str(definition['mutates']) != '0' or str(definition['command']) != '::GX::Native2DExport::' + operation:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Presentation exporter does not match this nonmutating Workbench owner')
    provider = host.as_dict(host.call('::GX::_workspaceProvider', owner['provider_id']))
    if str(provider['module_id']) != workbench or str(provider['schema']) != str(owner['format']):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Presentation Document has a different registered scientific owner')
    parameters = args[2] if len(args) > 2 else {}
    options = args[3] if len(args) > 3 else {}
    if not isinstance(parameters, dict) or any(type(value) not in (str, int, float, bool) for value in parameters.values()):
        _invalid('Exporter parameters must be scalar declared fields, without paths or snapshots')
    allowed = {'point_budget', 'title', 'x_label', 'y_label', 'legend', 'font_size', 'include_construction_reference', 'axes_visible'}
    if not isinstance(options, dict) or set(options) - allowed or any(type(value) not in (str, int, float, bool) for value in options.values()):
        _invalid('Snapshot options require bounded scalar caption/budget fields')
    snapshot = host.call('::GX::native2DPresentationSnapshot', scope['native'], options)
    context = {'workbench_id': workbench, 'workbench_version': str(host.call('::GX::moduleField', workbench, 'version')),
               'document_id': scope['document_id'], 'revision': expected['revision'],
               'parameters': parameters, 'presentation_snapshot': snapshot}
    _guard(host, scene, expected)
    raw = host.call('::GX::workbenchExtensionInvoke', _MODULE, operation, context)
    _guard(host, scene, expected)
    result = host.as_dict(raw);policy = host.as_dict(result['export_policy'])
    policy['point_budget'] = int(policy['point_budget'])
    for key in ('scientific_materialization', 'vector'): policy[key] = bool(host.tcl.getboolean(policy[key]))
    view = host.as_list(host.as_dict(snapshot)['view'])
    return {'status': str(result['status']), 'format': str(result['format']),
            'bytes': host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']._byte_result(result['bytes']),
            'warnings': [str(item) for item in host.as_list(result['warnings'])], 'export_policy': policy,
            'source_document_id': scope['document_id'], 'source_generation': str(expected['generation']),
            'source_revision': expected['revision'], 'source_sha256': str(expected['sha256']),
            'viewport_width': int(float(view[0])), 'viewport_height': int(float(view[1]))}
