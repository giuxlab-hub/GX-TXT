"""Canonical object admission for the existing complete Native3D exporters."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_MODULE='export.native3d_geometry'
_API='NATIVE3D_GEOMETRY_EXPORT_API_v1'
_OPS=('step','stl','vtp','publish')
REGISTRATION={
    'api_id':_API,'api_version':1,'provider_kind':'module','provider_id':_MODULE,
    'documentation_ref':'plugins/modules/export.native3d_geometry/MANUAL.md',
    'operations':{operation:{
        'name':operation,'summary':'Complete canonical Native3D geometry: '+operation,
        'host_command':'::GX::Native3DGeometryExport::'+operation,
        'arguments':[{'name':'document_id','kind':'canonical Workbench3D Document ID','required':True},
                     {'name':'object_id','kind':'canonical object ID in the current stored model','required':True},
                     {'name':'expectation','kind':'exact generation/revision/sha256 receipt','required':True},
                     {'name':'parameters','kind':'existing exporter typed fields; no snapshot/path/callback','required':False}],
        'argument_convention':'document_id, object_id, expectation, optional parameters',
        'result_contract':'Exact complete-world geometry uint8 bytes and sidecar bytes, or canonical Dataset publication; units/source identity retained. Snapshot/resource/geometry are read from the current canonical Document, never caller supplied.',
    }for operation in _OPS},
}


def _invalid(message):
    raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)


def _guard(host,document,expected):
    actual=host.as_dict(host.call('::GX::interactiveDocumentMetadata',document))
    if str(host.call('::GX::interactiveDocumentSessionToken'))!=expected['session_token']:
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Geometry export Session lifetime changed')
    if any(str(actual[key])!=expected[key]for key in ('generation','revision','sha256')):
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Geometry export Document changed; read its current receipt again')


def _context(host,document,object_id,expectation,parameters):
    if not isinstance(document,str)or not isinstance(object_id,str):
        _invalid('Geometry export needs canonical Document/object IDs')
    if not isinstance(expectation,dict)or set(expectation)!={'generation','revision','sha256'}:
        _invalid('Geometry export expectation requires exactly generation, revision and sha256')
    if not isinstance(expectation['generation'],str)or not isinstance(expectation['sha256'],str):
        _invalid('Geometry export generation/SHA receipt fields must be strings')
    revision=expectation['revision']
    if isinstance(revision,bool)or not isinstance(revision,(int,float))or int(revision)!=revision or revision<1:
        _invalid('Geometry export revision must be a positive integer')
    expected={'generation':expectation['generation'],'revision':str(int(revision)),
              'sha256':expectation['sha256'],
              'session_token':str(host.call('::GX::interactiveDocumentSessionToken'))}
    _guard(host,document,expected)
    record=host.as_dict(host.call('::GX::interactiveDocumentRead',document))
    if (str(record.get('module_id'))!='viewer.3d_workbench'or
        str(record.get('provider_id'))!='workbench_3d'or
        str(record.get('format'))!='workbench3d.document.v1'):
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Geometry export requires its canonical Workbench3D Document owner')
    payload=host.as_dict(record['payload'])
    model=host.as_dict(payload['model'])
    if str(model.get('format'))!='workbench3d.document.v1':
        _invalid('Canonical Workbench3D model format is invalid')
    objects=host.as_dict(model['objects'])
    if object_id not in objects:
        _invalid('Object does not belong to the current canonical Workbench3D model')
    if not isinstance(parameters,dict)or any(type(value)not in(str,int,float,bool)for value in parameters.values()):
        _invalid('Exporter parameters must be scalar public values; snapshots/resources/callbacks/paths are not admitted')
    context={
        'workbench_id':'viewer.3d_workbench',
        'workbench_version':str(host.call('::GX::moduleField','viewer.3d_workbench','version')),
        'document_id':document,'revision':int(revision),
        'selection':{'kind':'object','ids':[object_id],'point_indices':[]},
        'active_object':object_id,'active_group':'','working_plane':'',
        'units':{'working_unit':model['working_unit']},'parameters':parameters,
        'presentation_snapshot':{'api_id':'NATIVE3D_GEOMETRY_EXPORT_SNAPSHOT_v1','api_version':1,
                                 'document_id':document,'working_unit':model['working_unit'],
                                 'object_id':object_id,'object':objects[object_id]},
    }
    _guard(host,document,expected)
    return context,expected


def invoke(host,operation,args):
    if operation not in _OPS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
    if len(args)not in(3,4):_invalid('Geometry export requires Document/object/receipt and optional parameters')
    context,expected=_context(host,*args[:3],args[3]if len(args)>3 else{})
    definition=host.as_dict(host.call('::GX::workbenchExtensionDescribe',_MODULE,operation))
    if str(definition['mutates'])!='0'or str(definition['command'])!='::GX::Native3DGeometryExport::'+operation:
        raise BridgeError('GXTXT:ScriptBridge:Ownership','Exporter no longer matches its nonmutating declared owner contract')
    # This existing authority normalizes exact module-declared parameter fields,
    # defaults, units/budgets and dependencies before invoking the fixed exporter.
    raw=host.call('::GX::workbenchExtensionInvoke',_MODULE,operation,context)
    _guard(host,args[0],expected)
    value=host.as_dict(raw)
    result={'status':str(value['status']),'source_document_id':args[0],'source_object_id':args[1],
            'source_generation':expected['generation'],'source_revision':int(expected['revision']),
            'working_unit':str(context['presentation_snapshot']['working_unit']),
            'geometry_policy':'complete_native_world_geometry'}
    if operation=='publish':
        result['dataset_id']=str(value['dataset_id'])
        result['created_ids']=[str(v)for v in host.as_list(value['created_ids'])]
        return result
    resources=host.modules['INTERACTIVE_DOCUMENT_RESOURCE_API_v1']
    result.update(format=str(value['format']),bytes=resources._byte_result(value['bytes']),
                  warnings=[str(v)for v in host.as_list(value['warnings'])],sidecars=[])
    for item in host.as_list(value['sidecars']):
        sidecar=host.as_dict(item)
        result['sidecars'].append({'suffix':str(sidecar['suffix']),'bytes':resources._byte_result(sidecar['bytes'])})
    return result
