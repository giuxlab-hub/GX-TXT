# Trusted operational Job summary

The existing Job journal and Supervisor supply counts across the configured
local UID journal. Authorized Node grants define remote Session coverage. This
service exposes no Job IDs, Session paths, parameters, outputs or execution
authority. It is a trusted host service; no global Script Bridge grant is added.

`::GX::scriptJobSummary callback` asynchronously reads a **local** snapshot using
the existing managed request owner. An absent journal is UNINITIALIZED with
unknown counts. A metadata read creates no root, database or schema.

`::GX::scriptJobSummarySubscribe widget callback ?afterSequence?` returns an
opaque monitor token. The widget must exist. It receives asynchronous initial
local and remote coverage, then owner notifications through the existing socket
and fileevents. The callback prefix should carry the consumer's widget epoch.
`::GX::scriptJobSummaryUnsubscribe token` and widget destruction dispose only
the monitor, leaving durable Jobs intact. Existing Jobs management is
`::GX::scriptJobsDialog`.

Combined callbacks are `{ok 1 result DTO}` with schema
`gxtxt.operational_job_summary.v1`, per-route `sequence`, `local`, `remote` and
`attention`. Local running combines PREPARING, RUNNING and FINALIZING; queued
means QUEUED. FAILED, INTERRUPTED and unknown states remain distinct. `counts`
includes all journal rows; `visible_counts` applies the existing exclusion of
internal core_service rows. The main header uses raw ALL-row counts. Retained
failures are not silently acknowledged or removed by this service. Existing
Runner history hiding is a view preference; no alert acknowledgment is inferred
and no new acknowledgment store is introduced.

Pending, denied, offline, uninitialized or unknown coverage is never a zero/OK
claim. Attention totals are confirmed subtotals and carry `complete=false` while
any route is unknown. `attention.unknown_jobs` preserves actual UNKNOWN execution
states separately from `attention.unavailable_routes` (nonavailable observation
routes). `lost_connections` counts only actual transport failure after an
authoritative AVAILABLE snapshot established that route. Pending, disabled,
denied, unsupported, config/tool/parser/schema errors are not connection loss.
`complete` describes coverage, so unknown_jobs>0 still requires attention when
complete is true. Transport failure retires the failed local stream, keeps
remote coverage truthful and reports reconnection needed; explicit disposal
closes both. The remote owner alone can confirm zero configured routes.
The remote monitor subscribes to the existing execution.nodes Configuration
events. Changes rebuild transient routes under the same external token with
fresh generations/expected pipes and synchronously invalidate coverage inside
the canonical configuration-change callback before queued GUI rendering; initial
constructor delivery remains asynchronous. Old callbacks cannot replace the new
route. Widget disposal also unsubscribes that
configuration observer. This adds no polling or durable configuration mirror.

`gxtxt_job_events.read_summary(connection,sessions=None)` is the shared counts
reader. None means this configured journal; an explicit empty grant counts no
Sessions. Counts and cursor share one read transaction without row/page caps.
An opaque `state_revision` captures scoped metadata changes even when opposing
Session transitions leave global totals unchanged. A granted scope's cursor is
the maximum existing authorized event sequence, not the unrestricted cursor.
`read_summary_root(root,sessions=None)` also reports an opaque physical journal
identity and rejects aliases/replacement. Global socket snapshots are internal
wake hints for Node; they are never forwarded as granted client counts.

The SAME Supervisor/EventServer accepts `summary_watch` and admission wake
messages with same-UID peer checks and bounded clients/frames. Explicit trusted
monitoring may initialize the existing empty journal to obtain authoritative
zero counts without creating a scientific Job. Initial snapshots are always
sent; progress-only changes do not flood counts. An idle owner blocks on socket
readiness while monitored. Disposing the last monitor restores its original
60-second idle exit. No second scheduler, durable counter or polling UI is used.

Current author proofs separately cover the actual reader, socket protocol,
empty Supervisor lifecycle and Tk/codec/widget cleanup. Inert remote fixtures
do not establish actual Node or final status-bar acceptance. Remote aggregation,
same-artifact GUI witnesses and independent final acceptance require their
respective owners' evidence.
