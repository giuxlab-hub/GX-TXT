# NATIVE2D_API_v1

The additive [multilayer Canvas contract](NATIVE2D_MULTILAYER_CANVAS_v1.md)
documents the DEV112-P003 native controller, trusted host and typed C++ binding.

SPDX-License-Identifier: GPL-3.0-or-later

Native2D C remains the scientific geometry, constraint, coordinate and snapping
authority. `native2DCadApiInfo` reports the installed native capabilities and
additive managed host operations. No raw native address is a public Tcl handle.

The existing contracts remain authoritative:

- [CAD controller](NATIVE2D_CAD_CONTROLLER_v1.md): scientific object/component
  references, selection, native manipulation transactions and relationships.
- [Embedded Canvas](NATIVE2D_CAD_CANVAS_HOST_v1.md): pointer/keyboard routing,
  admission, preview, commit/cancel and independently chosen GUI placement.
- [Advanced tools](NATIVE2D_ADVANCED_CAD_TOOLS_v1.md): exact construction,
  defining controls, topology and native constraint/dimension workflows.
- [Relationships](NATIVE2D_CAD_TOOLS_RELATIONSHIPS_v1.md): scientific relationship
  identity and shared presentation/editor ownership.
- [Retained sprites](NATIVE2D_SPRITE_SCENE_API_v1.md): native scientific references,
  selective synchronization, hit testing and existing Cairo presentation.

## Managed Sketch and contextual actions (P020)

`nativeCadSketchCreate parent ?options?` returns a managed component with an
editable plane inside one existing Native3D Canvas. The caller chooses the
parent. Exact definitions and P017 History use an existing Interactive Document;
the Native3D plane-frame service owns local/world conversion. Working units must
be length units. No new geometry engine, canonical store or History stack is
introduced. See [full Sketch contract](NATIVE_CAD_SKETCH_P020.md).

`native2DCadActions`, `native2DCadActionState sketch action` and
`native2DCadActionInvoke sketch action` expose the current common action catalog,
its authoritative enabled/selected facts and finite invocation. Menus, external
palettes and Canvas-owned ViewportHost controls use those same facts and the
existing shared icon catalog. The catalog is an admitted GUI action surface;
the underlying advanced controller retains its broader documented native API.

The restricted Viewer SDK declares `NATIVE2D_API_v1@1` and explicitly requests
`cad_sketch_create`, `cad_sketch_command` and `cad_sketch_state`. A Builder
`cad_sketch` component owns the managed instance; `Host::cad_command(component,
action)` invokes it without exposing Tk paths or scientific memory addresses.

## Single Native3D Canvas (P021)

[Surface integration](NATIVE_CAD_SURFACE_P021.md) borrows an existing Native3D
Canvas; the default factory creates one ordinary Native3D component. Shared
CAD tools, retained transparent presentation and native camera receipts operate
on that same Canvas. The P020 mirror is no longer an update path. The existing
`world_scene` method remains an explicit bounded compatibility snapshot only.


The Script Bridge `api_info` operation takes no arguments and returns the complete
original discovery dictionary. Nested metadata remains dictionaries, command and
field names remain ordered text arrays, versions/limits are integers, and flags
are logical values. Listed commands and source-relative documentation names are
data; reading metadata executes none of those actions and grants no GUI, process,
publication, callback or native receiver authority. The CAD metadata getter keeps
the original installed native adapter activation/capability checks and errors.


## Completed Canvas raster provenance (DEV112-P006)

The trusted host command `native2DCanvasRasterProvenance reference` reports the
original producer of an already owned Canvas raster Resource. The reference must
carry its original producing Job, output token and positive output generation.
Only completed `core.native2d.raster` operations `canvas_filter` and
`canvas_flatten` are accepted.

The result is a dictionary containing `operation`, the original captured
`manifest`, the fixed completed `output` descriptor without `bytes_base64`, and
`source_bindings`. The bindings contain the original image-child Resource aliases
and captured canonical Dataset revision tokens. The original owner checks verify
output identity, SHA-256, size, availability and completion; the exact UTF-8
composition; captured child input bytes and Resource identities; and current
Session, Resource, Job and canonical Source state. After those observations it
repeats the original Session, Source, output-Resource and producing-Job guards.
Foreign, changed, incomplete or unrelated producers are refused.

This is a host-only Native2D discovery entry. It adds no Script Bridge operation,
Python/Octave callable, typed C++ SDK method, arbitrary Job reader, output-freeze
authority, scientific processing, adoption or publication. An application
backend uses its own declared public API and the original Resource ownership
checks; a restricted frontend does not receive raw native handles or interpreter
access. Reading `api_info` lists the command as inert metadata and grants none
of those capabilities.
