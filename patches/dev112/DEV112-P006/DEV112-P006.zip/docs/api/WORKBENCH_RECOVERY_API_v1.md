# Workbench Recovery API v1

CORE host API `WORKBENCH_RECOVERY_API_v1`, provider `workbench_recovery`.
Raw legacy journal mutation/restoration and modal choices retain their original
host lifecycle authority. The shared worker projection below exposes bounded
read-only inspection and explicitly native-Workspace-only status/flush facets.

`workbenchRecoveryBegin document_id` opens the recovery lifecycle.
`workbenchRecoveryCheckpoint document_id ?receipt?` records a committed semantic
Interactive Document snapshot and a recent operation receipt.
`workbenchRecoveryInspect document_id` is read-only and returns absent, clean,
unclean or corrupt status. It cannot write the Session.
`workbenchRecoveryResolve document_id recover|saved` explicitly restores the
chosen snapshot through the normal Interactive Document Update API.
`workbenchRecoveryMarkSaved document_id` / `workbenchRecoveryClose document_id`
compact a valid journal and mark the current committed state clean. Explicit
Save can create an absent journal from the current valid Document. A corrupt
existing journal returns `status corrupt` with its reason and remains unchanged;
callers must inspect that status as well as exceptions.
`workbenchRecoveryForget document_id` explicitly removes only the recovery journal.

The inert journal retains complete UTF-8 semantic snapshots. The existing raw
`GXTXT_RECOVERY_V1` encoding remains readable. If the full envelope would exceed
the stored-byte budget, CORE writes a lossless `GXTXT_RECOVERY_ZLIB_V1` body;
it does not omit saved/latest snapshots or shorten their History. The envelope
SHA-256 checks the stored body before decoding. Each saved/latest snapshot's
SHA-256 separately checks its exact uncompressed UTF-8 payload. The same
Document/provider generation guards and same-directory atomic replacement
apply to both encodings. The journal has a 16 MiB stored-file budget and at most
128 recent semantic receipts. If the compressed envelope still exceeds the
budget, the write fails visibly and preserves the previous checkpoint. It
retains the last saved snapshot separately from the latest consistent checkpoint,
including provider/Document generation, revision, format, payload fingerprint,
source identities, geometry references and operation provenance. Native geometry
remains in owned content-addressed resources. Resource collection includes valid
saved/checkpoint references without duplicating large coordinate or mesh blobs.

Curve Workbench and 3D Workbench offer a real recovery dialog after unclean exit:
**Recover**, **Open last saved state** and inspection details. Cancel leaves the
saved Session untouched. A recovery choice does not advance the saved snapshot;
explicit Save or normal close does. A corrupt journal yields a visible diagnostic
and allows ordinary Document open/save/close. It is retained for inspection;
normal save does not claim that an invalid journal was repaired. A journal-write
failure after a scientific commit reports that the action committed and leaves
the previous consistent checkpoint intact. Failed scientific/checkpoint staging
does not advance the journal.

The shared Session Save hook marks existing valid Workbench journals clean.
Workbench controllers checkpoint semantic geometry/Undo/Redo boundaries rather
than pointer-movement events. Journals are recovery aids and do not replace the
normal Session save workflow.


## Shared bounded Script Bridge facets

Provider `workbench_recovery` exposes `api_info()`, `inspect(expected)` and
`native_lifecycle(expected, action)` for both Python and Octave. `expected` is
exactly `{id, generation, revision}`, held from the current Document/Workspace
owner. Admission checks the current Session and generation/revision before and
after the original owner. These checks are observation guards, not a new
transaction or journal CAS.

`inspect` returns original factual scalar status/owner/revision/SHA fields and
receipt count. Raw snapshot payloads, receipt contents and filesystem diagnostic
text are not transported; corrupt status indicates diagnostics are available
from the host. Inspection does not write the journal or scientific Document.

`native_lifecycle` accepts only `begin`, `checkpoint`, `mark_saved`, `close` and
only an actual native Workspace. Begin/checkpoint read original Store recovery
status; mark_saved/close call original Store flush and then status. It calls the
original native branch owners directly, so a replacement cannot dispatch into
a legacy journal write. Flush durability is distinct from a user Session Save,
legacy journal clean state or a GUI close. No native data/history engine changed.

Raw legacy begin/checkpoint/mark_saved/close still select or advance saved/latest
recovery snapshots and retention roots. Forget deletes recovery evidence without
a held journal-generation contract; Resolve restores legacy payload through the
original Document Update and host recovery lifetime. These raw operations are
not registered as worker aliases. Native Workspace explicitly refuses obsolete
Tcl snapshot restoration and uses its original committed Store/History owners.
`api_info` declares these availability distinctions; safe native facets do not
claim full raw/retired lifecycle equivalence.

Author evidence covers actual dual-client metadata/status/flush/inspection and
strict stale/foreign/argument refusals, including an actual native revision
advance and unchanged legacy journals. Raw host restoration/disposal, provider
actions, GUI/native SDK event lifetimes and final independent approval are not
claimed by this focused campaign.
