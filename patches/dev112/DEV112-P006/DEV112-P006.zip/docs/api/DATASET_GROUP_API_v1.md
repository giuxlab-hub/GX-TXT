# Dataset Group API v1

`::GX::datasetGroupApiInfo` describes the public storage/lifecycle owner. A Group is a
Session-local aggregate of existing canonical Dataset IDs, with ordered roles,
one Namespace and source provenance. It adds no scientific payload and is
independent of Variable Schema `group_id` and Library graph relationships.

All commands use the existing Dataset authority lock and durable recovery
journal. `metadata/dataset_groups.tcldict` is a bounded inert UTF-8 dictionary,
never sourced. Existing Sessions without this file have no Groups.

| Host operation | Behavior |
| --- | --- |
| `datasetGroupList session` | Ordered stored descriptors. |
| `datasetGroupGet session groupId` | Descriptor plus `status=COMPLETE|DEGRADED` and exact member issues. |
| `datasetGroupForDataset session datasetId` | Group ID or empty. One Dataset belongs to at most one Group. |
| `datasetGroupCreate session definition` | Validate all actual registered members and persist one new Group. |
| `datasetGroupMove session groupId namespace expectedRevision` | Move every member through the existing Namespace owner and advance Group revision atomically. |
| `datasetGroupDetach session groupId datasetId expectedRevision` | Remove only membership; preserve the Dataset. Last detach removes the wrapper. |
| `datasetGroupUngroup session groupId expectedRevision` | Remove wrapper only; preserve every Dataset. |

Creation requires `group_id`, `display_name`, qualified `group_contract`,
`primary_dataset_id` and `members`. Each member declares `dataset_id`, qualified
`role` and boolean `required`. CORE pins its actual contract, canonical SHA and
source-module/RAW SHA. IDs/roles/contracts are extensible declarations, without
domain-specific CORE vocabulary. All members must exist in one Namespace, the
primary must be a member, and duplicates/collisions are refused. Bounds: 1000
Groups, 1000 members per Group, 1 MiB total descriptor, 512-character labels.

The same descriptor retains creation time and the last128 inert history events
(create, move, detach, member rename and import), each with timestamp, revision
and bounded identity/Namespace details. History is diagnostic provenance, never
executable replay or scientific data. Group ZIP preserves it and original creation
time; import appends an explicit new event while retaining source revision/origin.
Old descriptors/packages without history remain compatible. The existing Dataset
authority journal rolls history back with membership and Namespace changes.

Move/detach/ungroup require the exact integer revision returned by Get. An error
rolls back all enlisted sidecars and the Group descriptor. Legacy single-member
`datasetNamespaceSet` refuses grouped members: explicitly move the whole Group
or detach first. Individual deletion similarly requires explicit detach/ungroup.
Normal Dataset rename retains membership/primary/source references and increments
Group revision inside its existing transaction. No payload SHA changes.

In the existing Dataset Browser, dragging a Group row onto a visible Namespace
asks for confirmation of the whole Group move. The gesture pins its Session
lifetime and Group revision at press; the normal `datasetGroupMove` authority
performs the move after review. Escape, an outside drop, unmapping, stale state
or a rejected review performs no move. Disclosure clicks and individual Dataset
activation retain their existing behavior; the older single-Dataset Namespace
Manager gesture is unchanged.

Acquisition handlers may return optional `dataset_group` with this creation
definition. Membership must exactly equal the handler's actual returned Dataset
IDs. The existing Acquisition transaction creates the Group after member
registration; any failure aborts the entire import. Handlers without this key
retain their existing behavior. A read-only Library relation does not create a
Group or canonical Dataset.

`datasetCatalogSnapshot` additively includes `dataset_groups`. Group-only changes
also notify existing subscribers; highlight alone does not activate members.
Source changes/missing members are reported as degraded; no guessed repair or
implicit retarget is performed. These host mutation commands are not Script
Bridge or restricted C++ filesystem capabilities.

The existing Dataset Browser measures its bounded recursive identity/role text
through the shared UI Field inspection-column owner. Horizontal scrolling reaches
the full measured text at the actual font instead of a fixed420pixel extent;
the nominal navigator width stays independent from that scrollable extent. The
existing Current Namespace/Active Dataset button wraps its complete caption
through the native button-label style. Main and Dataset-page notebooks use the
existing public compact selector when captions cannot fit, preserving notebook
paths, page identities, callbacks and normal tabs when sufficient room returns.
These are presentation changes; Group membership, activation, source bytes,
Namespace and scientific/portable transaction owners remain unchanged.

P030 additively exposes producer-scoped review/create and optional atomic batch
grouping through [Dataset Group Producer API v1](DATASET_GROUP_PRODUCER_API_v1.md).
These admitted facades serve all legitimate registered producer categories;
legacy host/admin mutation commands retain their authority restrictions.

## Create a Group in the Dataset Browser

Open a Session, then choose **Dataset actions → Create Dataset Group…** in the
Dataset Browser. Select 1–64 ungrouped canonical Datasets from one Namespace.
The dialog suggests an editable **Group ID** and **Display name**. The suggested
ID avoids existing Group and Dataset identities; it is checked again at review
and creation, rather than reserved when the dialog opens. Custom IDs are accepted:
1–256 letters, digits, `.`, `_` or `-`, without surrounding spaces; `.` and `..`
alone are invalid. An invalid or duplicate Group ID produces an inline **Group
ID** error and focuses/selects that field without losing the selected members.

**Display name** is a human-readable label, independent of the Group ID. It may
be blank, following CORE semantics, or contain up to 512 characters without NUL
or line breaks. **Group contract** is the qualified Group declaration (default
`scientific.dataset_group`); **Primary Dataset** must be a selected member.

The table's **Role** and **Required** columns are the actual per-member values.
**Bulk member role** and **Required (bulk value)** are pending edits: changing
them does not change any row until **Apply to selected** is pressed. That button
updates only the highlighted rows. It does not change a scientific Dataset.

Choose **Review and create…** to review the exact selected IDs, Namespace,
primary, contract, roles, Required flags, canonical fingerprints and source
provenance. **Cancel** in either dialog creates no Group. **Create Group** uses
`datasetGroupHostCreateV1` with a review validated by the public
`datasetGroupHostReviewV1`, retaining the original dialog-open Dataset revisions
and the existing Session,
payload and transaction guards. Invalid selection, stale Session/revisions,
existing membership or a conflicting identity is refused without creating a
Group; the safe draft remains available with an inline explanation.

After creation the Dataset Browser refreshes and shows the Group with its
original Dataset IDs. The existing Namespace Manager also refreshes its Dataset
placement. **Inspect Group…** shows the stored identity and current integrity
status. Normal Session reopen retains the Group. **Detach this member from
Group…** and **Ungroup (keep Datasets)…** remove membership or the wrapper through
the existing revision-checked authority; they preserve scientific payloads.

## Script Bridge membership lookup

The existing `DATASET_GROUP_API_v1` provider `dataset_group` exposes
`for_dataset(dataset_id)`. It calls the same `datasetGroupForDataset` owner with
the execution Session supplied internally and returns the original Group ID as
text, or empty text for no membership (including an unknown ID). It does not
create/repair a Group, select another Session or replace `get` integrity checks.
The existing `review`, `create`, `get` and `list` contracts remain unchanged.
