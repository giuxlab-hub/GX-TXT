# C++ Viewer Script Bridge frontend

This additive SDK-v1 facade uses the existing Script Bridge provider registry,
Script Projects, Script Execution and Job Supervisor. It adds no API operation
whitelist and no alternate scientific algorithms. A registered script-callable
operation is selected by public API ID and operation in an inert typed request.
The shared provider remains responsible for its version, capabilities, source,
Session and resource admission. Host-only APIs remain host-only.

```cpp
auto request = gx::workspace_object({
    {"api_id", gx::workspace_text("NUMERIC_API_v1")},
    {"language", gx::workspace_text("Octave")}
});
host.script_bridge("describe", request);
// Read the immutable result on a following owning-thread Viewer event.
if (const auto* receipt = host.script_bridge_result()) {
    // Inspect receipt fields; long work is represented by its actual Job ID.
}
```

Transport actions are `list`, `describe`, `require`, `call`, `run`, `status`,
`cancel`, `result`, `read_resource`, `reconnect`, `subscribe` and `unsubscribe`. These verbs do
not enumerate or restrict scientific API names or provider operations. The
request and response use existing `gx::WorkspaceValue` scalar/object/array
types. Scientific bulk data retains the existing managed binary descriptor;
no raw native pointer, filesystem authority or display projection is granted.

Generic `list`, `describe`, `require` and `call` accept optional `language`,
either `Python` (the default) or `Octave`. This selects the actual ordinary
Script Project and Script Job runtime, including its provider language context.
Both runtimes use the same public provider registry and version, capability and
`required_apis` admission policy. Dynamic registrations need no C++ SDK change.
Language selection grants no additional API or provider authority. A bundled
`run` takes its language from the declared `script_entries` entry instead.

Receipts use schema `gxtxt.viewer_bridge_receipt.v1`. Each carries `operation`
and `status`. A pending scientific submission carries `submission_id` until
Supervisor acceptance supplies the actual `job_id`, `state` and `node_id`.
Lifecycle actions `status`, `cancel`, `result`, `read_resource`, `reconnect`,
`subscribe` and `unsubscribe` use the existing managed asynchronous request
owner. Their immediate pending receipt carries `request_id` and the already
known `job_id`. Completion or failure arrives later on the owning thread through
`__script_bridge_event__`; consume that operation's following receipt rather
than reading a result synchronously after dispatch. Event receipts
retain `job_id`, `sequence`, `terminal`, `state`, `stage` and source/module
correlation. Sequence comes from the durable Supervisor journal; delivery may
be duplicated, and reconnect resumes after an explicitly retained sequence.
Terminal states are `COMPLETED`, `FAILED`, `CANCELLED` and `INTERRUPTED`.

While an event guard is validating, the Host may coalesce transient progress
delivery. The complete durable Supervisor journal remains available for replay;
terminal delivery, source checks and ownership compare-and-swap checks remain
guarded. Same-process reconnect may perform an internal owner-review refresh
and bounded retry against the exact owner tuple. It requests no additional user
permission and continues to refuse another live Viewer.

A completed `result` receipt carries the retained typed result under `result`.
Both `result` and `read_resource` receipts carry the exact original invocation
under outer `request`, decoded from that Job's guarded immutable request
snapshot. Resource-backed submissions pin `viewer_control_snapshot` in the
original execution inputs; legacy inline submissions retain
`execution_inputs.provided_api.request_json`. It identifies the original API,
operation, arguments and any explicit language/provider/version selection;
fetching a result does not replace it with the fetch request. Scientific scalar
results therefore retain their request correlation without adding fields to a
provider-owned result schema.
Receiving a terminal event does not imply the result body was already fetched.
Request `result` for that exact Job ID and consume the following result callback.
The owning-thread snapshot is immutable until the next event. Generic result
metadata for newly built clients uses a small captured Resource descriptor,
then reconstructs the complete immutable receipt through the additive internal
context-v2 setter. The compiled getter receives every original outer request,
argument and retained result field, including the inner runner receipt's
`request`; it does not receive only a descriptor or a projected subset.
The existing ScalarBroker child, captured GUI/Session lifetime, ResourceManager
reservation/lease and asynchronous Script Job preparer own control transfer.
The Tk callback handles bounded metadata while the existing worker performs
control decoding. Resource allocations reserve the declared byte total before
writing, seal it with a complete SHA256 and retain protection until snapshot
acknowledgment and reader drain. The Job owns its immutable input/result files.

The historical 48 KiB inline request and 1 MiB/8,192-node Workspace-v1 limits
remain applicable to legacy finite forms and old context-v1 transport. They are
not additional limits on the resource-backed generic request/receipt tree.
Existing precompiled context-v1 clients retain their small-value behavior;
normal Build supplies context-v2 support without changing the SDK-v1 source
facade, WorkspaceValue layout or public operation registry. Resource policy,
ordinary Bridge framing and the native worker's existing 3 s CPU/256 MiB address
space/1 MiB file-size limits still apply. There is no unlimited-size guarantee:
full owning-tree reconstruction and the compiled callback must fit those
budgets, and an admission/transfer failure returns an error without truncation.
Bulk arrays use managed scientific descriptors;
`read_resource` reads an authorized retained binary descriptor in pages of at
most 16 KiB. Each page carries its offset, actual byte count, base64 bytes,
end-of-resource flag, original descriptor and producer `resource_sha256`.
Consumers reconstruct the exact bytes and compare their complete SHA256 with
that retained producer hash; the hash describes the whole resource, not one
page. Original dtype, shape, endian and column-major order remain in the binary
descriptor. Floating-point nonfinite values and complex arrays are not flattened
into lossy JSON numbers.

A generic `call` can reuse an admitted retained buffer through this logical
argument value:

```json
{
  "schema": "gxtxt.viewer_bridge_input_buffer.v1",
  "job_id": "existing-owned-job-id",
  "resource_id": "0123456789abcdef0123456789abcdef.bin"
}
```

These three fields identify an existing Job resource; they grant no path
authority. Existing Job/module/Session/source guards admit the producer and
recheck the consumer. Preparation freezes verified producer bytes into the
consumer's ordinary managed Job snapshot, retaining the original binary-v2
descriptor and data SHA256. The snapshot buffers and manifest are read-only;
the runtime configuration pins the manifest SHA256 and the runtime verifies it
before resolving references through the same public Bridge codecs. The shared
aggregate generic-reference snapshot budget is 512 MiB, including repeated
occurrences, for Python and Octave consumers. A producer may be an admitted
native task. Direct native-task preparation retains the existing Scientific
Execution input-resource cap of 8 MiB; this reference transport does not raise it.

`source_files` retains the ordered C++ project closure and additionally accepts
`scripts/*.py`, `scripts/*.m`, `jobs/*.cpp` and `jobs/*.hpp`. The optional
`script_entries` map declares each logical entrypoint:

```json
{
  "analysis": {
    "language": "Python",
    "entrypoint": "scripts/analysis.py",
    "required_apis": "NUMERIC_API_v1;DATASET_PUBLICATION_API_v2",
    "parameters": {}
  }
}
```

The referenced files must be in the same source manifest. Save All, import and
export preserve their bytes and metadata; changing any source invalidates its
compiled-source identity. A single standard Plugin Manager package carries the
Viewer plus its scripts. The shared Script Project/Execution owner supplies the
immutable execution snapshot; an unrelated external Script Library package is
not required.

Execution-scoped handles belong to their owning Bridge execution for every
frontend and language. Separate generic calls run as separate ordinary Jobs;
they do not transfer live handles between Jobs. Put a stateful sequence of
public calls in one bundled script to retain one Bridge context throughout the
workflow. Its declared `required_apis` uses the existing shared policy, including
version, provider and capability requirements, before execution.

`native_jobs` optionally declares compiled task targets, each containing
`sources` (declared `jobs/*.cpp` units) and the existing Scientific Execution
`parameters` schema. The normal builder compiles a separate C++17 executable
using `gxtxt_native_job_v1.hpp`; GUI units still compile against the Viewer SDK.
The package carries `native/jobs/NAME`, its exact artifact/source/ABI descriptor
and executable mode. System ELF dependencies and loader have a pathless SONAME
to SHA inventory and must match the target runtime; this does not itself prove
authorized remote admission. `Host::native_job` and `native_job_result` adapt the same
Supervisor lifecycle; the GUI callback CPU/wall budget does not execute the
computational task.

Existing Event, State and Host layouts, C entrypoints and legacy operations are
unchanged. Five meaningful C++ translation units are a P006 demonstration
requirement, not a minimum imposed on ordinary Viewer projects.


Generic typed values retain null, empty array/object, exact strings and dictionary
keys, scalar kinds and canonical shaped cells through both managed Python and
Octave runners. A shaped cell uses the existing `WorkspaceValue::Kind::array`
with `fields["shape"]` containing the exact integer dimension array; its elements
remain flat column-major values. Copying WorkspaceValue copies that metadata.
Unshaped arrays retain their original behavior. Canonical cell shape validation
and public per-argument depth 32 apply unchanged; fixed CORE request/receipt
wrappers do not consume application depth. Scientific arrays keep their original
dtype, dimensions and binary descriptor instead of becoming cell arrays.

The Octave generic runner forwards canonical packets through the same private
Script Bridge send/callback/error/EOF path and retains the original terminal
response JSON before native Octave conversion. The shared canonical Python
codec and original numerical retention owner then preserve types such as null
and int16[1,1], which a native Octave scalar round trip could change. This private
transport adds no public Host action, API family, operation grant or second
executor; Python and Octave still execute the original admitted provider in the
ordinary managed Job. Application dictionaries cannot select resource/context
transport by containing a marker: only captured CORE metadata and validated
root manifests select these internal representations.
