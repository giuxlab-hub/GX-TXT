# Scientific Spectrum API v1

SPDX-License-Identifier: GPL-3.0-or-later

CORE owner `core/tcl/scientific_spectrum_api_v1.tcl`, namespace
`::GX::SpectrumAPIv1`, defines an inert one-dimensional `spectrum.scientific`
value. It does not import files, publish Datasets, convert units or validate a
domain-specific measurement by itself.

| Public signature | Required arguments / result |
|---|---|
| `apiInfo` | none; dict with api_name SCIENTIFIC_SPECTRUM_API_v1, api_version1, contract spectrum.scientific |
| `create fields` | required Tcl dict; returns normalized/derived Spectrum dict below |
| `validate spectrum` | required Spectrum dict; returns1 or raises an explicit mismatch/error |
| `axisInfo spectrum` | required validated Spectrum; returns sample_count, x_ordering, x_min, x_max, x_quantity, x_unit, y_quantity, y_representation, y_unit |

No optional positional arguments/defaults exist. `create` requires nonempty
spectrum_id, display_name, spectrum_kind, x_quantity, x_unit, y_quantity,
y_representation, y_unit, x and y. Use an explicit unit token such as `1` for
dimensionless data, not an empty unit field. x/y are Tcl lists of equal length,
at least2 samples, converted to finite Tcl doubles. X must be strictly increasing
or strictly decreasing, without duplicates or direction reversal; irregular
spacing is allowed. Y need not be monotonic. No resampling or reordering occurs.

Optional fields metadata and provenance default to empty Tcl dicts and are
checked as dicts. source_identity, source_hash and entity_id default to empty
strings. The result contains those fields, the eight required identity/meaning
strings, normalized x/y, contract spectrum.scientific, sample_count,
x_ordering ascending/descending, endpoint-derived x_min/x_max and spectrum_hash.
Unknown caller fields are not copied into the result.

The numerical SHA-256 hashes LF-separated spectrum_kind, x_quantity, x_unit,
y_quantity, y_representation and y_unit followed by each paired double formatted
with %.17g separated by a tab. Identity/name/provenance/metadata are excluded;
sample order is retained. This detects matching represented traces, not
equivalence under unit conversion, reversal or scientific preprocessing. Hashing
uses a temporary UTF-8 file which is removed by the owner; the value is not a
managed Session resource.

`validate` rebuilds the value and requires exact string equality for
sample_count, ordering, min/max and hash, plus the exact contract. It does not
prove source_hash against an external file, resolve an entity, validate the
meaning/unit strings in a Unit Registry or measure uncertainty. `axisInfo`
performs that same validation first. Units remain explicitly supplied scientific
labels; domain conventions and any controlled conversion belong to their owner.

Synthetic in-memory host example, not an executed scientific test:

```tcl
set s [::GX::SpectrumAPIv1::create [dict create \
    spectrum_id synthetic display_name {Synthetic trace} spectrum_kind example \
    x_quantity frequency x_unit Hz y_quantity amplitude y_representation linear \
    y_unit 1 x {1 2 4} y {0 1 0}]]
set axis [::GX::SpectrumAPIv1::axisInfo $s]
```

No Session/Tk is required for these value operations. The materialized value methods declare no maximum sample count or independent
precision/coverage guarantee; their values are materialized lists and hashes. Errors identify missing fields,
malformed dict/list, nonfinite values, sample mismatch, duplicate/nonmonotonic
X, wrong contract or derived-field mismatch. There is no result-wrapper schema
for failure beyond the actual Tcl error.

This family has no registered Python/Octave Script Bridge operation or typed
C++ SDK method in the retained binding/current SDK scope. Catalog presence is
not language admission, and no generic C++ invoke exists. Import and normal
Session publication are separate
[Spectrum Import](SCIENTIFIC_SPECTRUM_IMPORT_API_v1.md) and
[Spectrum Session](SCIENTIFIC_SPECTRUM_SESSION_API_v1.md) contracts. Numerical
normalization/hash validation is not independent scientific validation.

## Trusted bounded page validation

`validatePages(fields, count, reader)` is a distinct original owner contract.
Count is an exact integer from2 through536870912. Each requested page has at most
4096 pairs; the trusted Tcl command prefix `reader` receives offset/count and
must return exactly `x` and `y` with the requested lengths. CORE applies the same
finite/strict-monotonic/hash routines as `create` and returns sample_count,
spectrum_hash, x_ordering and endpoint bounds. Temporary hash files are cleaned
up on success or failure. No samples, IDs or scientific labels are invented.

The reader is executed with `uplevel #0` in the owning Tcl interpreter. This raw
callback is not a Script Bridge argument or source/file/channel grant. Prepared
Acquisition uses the fixed internal page reader only after its original admitted
module/output/Session, safe staging path, dtype/schema/unit/coordinate and pre/post
SHA checks. Those held channels are not transferable caller-created receipts.

Existing `SCIENTIFIC_REFERENCE_LIBRARY_API_v1/managed_read_spectrum` is a distinct
guarded data counterpart: stable managed Library/spectrum IDs and original
content policy, followed by this owner's materialized `validate/create`. It is not
a generic callback alias and does not return the raw page-validation receipt. A
future fixed canonical Dataset reader requires its own source/revision/schema/
lifetime review and would retain this same scientific owner. This raw-prefix
boundary does not exclude pure `apiInfo/create/validate/axisInfo` value contracts.


## Script Bridge contract metadata

The existing `SCIENTIFIC_SPECTRUM_API_v1` version1 CORE owner exposes only the added `api_info()` metadata operation through this adapter. It takes no arguments and returns the full original declared contract with explicit text/list/integer/logical shapes. Feature and operation names are inert data; their presence does not grant execution or establish configured tool availability. The original scientific, Session, publication and trusted-reader owners keep their existing contracts.

The original api_name, api_version and spectrum.scientific contract are preserved. Spectrum metadata also retains host_validation_operations and page_samples_max when returned by that owner; naming validatePages does not transport or execute its trusted reader callback. No samples, units or scientific dtype are transformed by this getter.
