# Script Bridge String wire facet v1

SPDX-License-Identifier: GPL-3.0-or-later

This is an optional representation of the existing typed `kind="string"`
node, not another API, value kind, scientific policy or execution grant. The
CORE Python server, Python client and Octave client share it in both directions.
Existing recursion, frame, result and resource limits remain in force.

Ordinary strings retain the established node:

```json
{"kind":"string","value":"plain text or literal \\u0000"}
```

An actual U+0000 in String data selects the encoded representation before JSON
serialization. For example, the three characters A, NUL, B use:

```json
{"kind":"string","data_encoding":"utf8-base64","data":"QQBC"}
```

`data` is canonical standard Base64 of the complete UTF-8 byte sequence. It is
not a numeric array, path, resource, JSON subdocument or escaped replacement for
the logical String. Decoding returns the original Python `str` or Octave
character row, including NUL, Unicode and controls. Nested String values use
the same existing recursive codec. Literal backslash-u text stays literal.
This facet applies to String data nodes; operation identities and JSON object
field names retain their owning contracts.

The encoded node has exactly `kind`, `data_encoding` and `data`. Unknown
encoding, ambiguous `value` plus encoded data, wrong payload types, malformed or
noncanonical Base64, overlong/truncated UTF-8, surrogate encodings and codepoints
above U+10FFFF fail with `GXTXT:ScriptBridge:Transport`. No replacement
characters or normalization repair an invalid byte sequence. A valid encoded
empty or NUL-free String is readable, although current emitters select encoding
only for actual NUL. Plain nodes still read their String `value`.

The internal shared Python owner is `core/python/gxtxt_string_wire_v1.py`
(`pack`, `unpack`). The Octave owner is `core/octave/gxtxt_string_wire_v1.m`
(`pack`, `unpack`). Their clients preserve String type rather than inspecting
arbitrary dictionaries for an encoding marker. The matching framework server
and clients must be deployed together. An older peer does not understand the
new encoded representation; a legacy plain NUL string already truncated by an
older Octave JSON parser cannot be reconstructed afterward.

The same Octave owner provides internal `quote` for a caller that already owns
logical JSON String serialization, including a JSON field name. It delegates
escaping of each NUL-free segment to the original `jsonencode`, then joins the
quoted contents with a literal JSON `\u0000` escape. The result is ordinary
full logical JSON, not a typed node. This does not replace `jsondecode`, rewrite
arbitrary user dictionaries or change a caller's schema. In particular,
feeding that logical JSON back through an affected Octave `jsondecode` still
has the original primitive NUL limitation; the caller must use its actual
lossless downstream decoder. No new callback or public operation is registered.

Focused author evidence uses ordinary public Python and Octave calls with
NUL, Unicode, literal escapes and all C0 control bytes, plus shared codec
cross-language JSON readback, legacy strings and malformed payload controls.
It does not imply independent C/W06 acceptance or a scientific campaign.
