# Supplied-value bindings (P006, f26 additive)

All six operations use the existing API family, provider and original Tcl owner.
No scientific implementation, CORE service, source/CPP permission, renderer,
GUI/Window, Job or callback is added. Registry descriptors are shared by Python
and Octave through the existing normal Script Bridge admission.

| API / provider | Operation and original arguments | Result |
| --- | --- | --- |
| OCR_LAYOUT_API_v1 / CORE | toText(layoutOrDocument, options omitted by default) | Original text; a whole TclValue only for non-scalar native Unicode |
| OCR_LAYOUT_API_v1 / CORE | filterRoi(layout, roi) | Whole original filtered layout, including copied open fields/words |
| TABLE_EXTRACTOR_API_v1 / CORE | extractLayout(layout, options omitted by default) | Whole original table extraction result, source/provenance, cells and copied words |
| MATHEMATICS_EXPLORER_API_v1 / viewer.mathematics_explorer | nativeModel(state, computed) | Whole original model, including empty/ragged behavior and nonfinite sentinels; no rendering |
| REPLICATE_VIEWER_API_v1 / viewer.replicate_curve_analysis | historyValidate(record) | Integer1 or original error; this only checks workbench identity |
| REPLICATE_VIEWER_API_v1 / viewer.replicate_curve_analysis | validate(payload) | Integer1 or original error; required fields/format only, not scientific validation |

SCIENTIFIC_RECIPE_API_v1 keeps provider `scientific_recipe` and operation
`rebase(record, current, context)`. An encoded history String retains the legacy
encoded-result convention. A raw record Struct or whole TclValue returns the
complete original candidate as whole TclValue. Current/context accept normal
values or whole TclValue. The original owner must register its actual validator
through normal installed activation; no caller callback or fake Document is
installed. The unchanged original rebase checks owner/document/retention, calls
its registered validator and returns a candidate, without durable mutation.

## Representation and use

Structured raw Tcl results have no universal high-level schema. Their result is
an ordinary public Struct with exactly four String fields:

```
format = gxtxt.inert_tcl_value.v2
representation = tcl_unicode_hex_le  (or tcl_unicode_hex_be)
shape = unresolved
lexeme = complete lowercase hex of original native 16-bit Unicode bytes
```

The same Struct can be passed unchanged to any of these operations, also nested
inside a normal Struct/Cell. Input representation `unicode_text` accepts its
entire literal Tcl lexeme instead of hex. No Tcl text is evaluated. For example,
Python can call `filtered = gxtxt_api_call('OCR_LAYOUT_API_v1', 'filterRoi',
[layout, ['0','0','1','1']])`, then pass `filtered` directly to `toText` or
`extractLayout`. Octave uses the same calls with cells and structs. A carrier
is literal data even when it looks like a callback, path, Resource, command,
number or null. Unknown metadata is not projected, interpreted or truncated.
Duplicate-key spellings/unquoted values and NUL/Unicode code units survive the
opaque representation; the original Tcl operation still controls effective dict
semantics. No recovered Python/Octave scientific type is claimed for an opaque
value. Full structured equivalence is not inferred from a fixed field subset.

Ordinary Struct/Cell/scalars use existing Host Tcl argument conversion, including
signed zero/nonfinite numeric spellings. Tcl has no distinct null: existing
Script Bridge null arguments have no generic Tcl representation and are refused;
pass empty text for the original empty value. Use an opaque lexeme when exact
numeric/text spellings, duplicate keys or native Unicode code units matter.
Optional arguments stay omitted; no supplied schema/default/normalization is
inserted ahead of the owner. Malformed layout/ROI/options/model fields reach the
original owner rather than a stronger authored validator.

Original errors retain `GXTXT:ScriptBridge:RemoteError` and the normal contextual
`API/operation: original message` convention. Error responses additionally retain
`native_outcome` with the actual catch code, complete result and ENTIRE options
as whole TclValues. Existing clients keep their normal error behavior. Resource
refusals have ResourceLimit, never a fabricated successful native outcome.

## Ordinary resource and authority boundaries

Arguments are limited to16MiB aggregate encoded content, depth64 and100000 nodes;
complete result plus options hex is limited to48MiB. The actual typed JSON
response is also checked against the existing64MiB Octave limit including LF,
control escaping, NUL Base64 and complete native error details. No output is truncated or clamped.
Native algorithm complexity and unchanged native errors remain owner behavior.
These ordinary safeguards are not complete physical allocator/ABI/error proofs.
No SourceHold or inactive proof prerequisite is present in this implementation.
The old private proof candidates are not copied into release content.

The focused reusable check is documented in
`validation/dev112_p006_working_values01/SCRIPT_CATALOG.md`. It compares direct
original-owner results/errors to one normal consumer per language, without
replaying the accepted nine. Author results are separate from Bridge review.
