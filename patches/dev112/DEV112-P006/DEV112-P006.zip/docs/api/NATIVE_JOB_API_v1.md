# Native Job API v1

Native tasks are ordinary installed Viewer Project C++17 targets. The Viewer
builder compiles declared `native_jobs` sources with the native task SDK and
exports source, executable, ABI and dependency SHA manifests in one normal
Plugin Manager package. Native tasks run under Scientific Execution and its
existing Script Job Supervisor, guardian, journal and Resource Manager.

The common Script Bridge provider `native_jobs` exposes `info()`,
`describe(entrypoint)`, `prepare(entrypoint, parameters, options, resources={})`,
`submit(prepared_token)`, `status(job_id)`, `cancel(job_id)`, `result(job_id)`,
`reconnect(job_id)`, `events(job_id, after_sequence, limit)` and
`read_buffer(job_id, resource_id)`. Python, Octave and
the generic C++ frontend use this same operation registry. The installed Viewer
module derives from the existing execution context; callers cannot select a
foreign module or executable path. Source, Session origin, optional Document
generation/revision/SHA and Dataset revision guards remain authoritative.

Host registration resolves `native/jobs/ENTRY.json` only beneath the installed
module. It verifies source closure, ELF architecture, protocol, C++ ABI fields,
binary SHA, bundled dependency SHA, system runtime dependency/loader SHA and
typed scalar parameter schema. Execution copies admitted files into the
Supervisor-owned managed scratch allocation and reverifies before launch.
Native code remains cooperating code, not an operating-system sandbox.
Document-bound tasks supply `options.source_guard` containing document_id,
generation, revision and sha256. The same guard protects generic Scientific
Execution calls; an equivalent foreign module cannot use a lower-level operation
to bypass native ownership. Session incarnation is the shared opaque hash of its
normalized directory/device/inode; manifest saves do not change that identity.

The C++ task includes `gxtxt_native_job_v1.hpp`, implements a function returning
`gx::native_job::Result` and declares `GXTXT_NATIVE_JOB_MAIN(function)`. Context
provides typed scalar parameters and monotonic progress. Bounded result objects
preserve JSON int64, real, boolean, text and nested value types.

Typed numeric inputs reuse Scientific Execution's `resources` map: each logical
alias references an existing Document-managed resource with
`metadata.binary_descriptor` holding the unchanged binary descriptor v2 and
optional `units`/source Variable metadata. Existing source SHA, owner generation,
Session and bounded resource snapshot checks run before admission. The established
Scientific preparation cap is8MiB of input resources. The task ABI declares
`buffer_descriptor_version=2`; scalar-only older artifacts continue to work and
refuse typed-buffer requests explicitly.

`context.buffer(alias)` exposes dtype, shape, units, exact bytes and checked
`values<T>()` in the managed worker scope. `context.publish_buffer(buffer)` or
`publish_buffer(buffer, values)` publishes original-dtype bytes through descriptor
v2; no binary layout or numerical engine is duplicated. uint64 endpoints,
float32, nonfinite values and multidimensional column order remain exact.
The adapter validates owner/type/size and retains outputs through the existing
Scientific output manifest and Job retention. The pathless result wrapper uses
the same `gxtxt.viewer_bridge_buffer.v1` descriptor plus original byte SHA and
source resource/Variable lineage. `read_buffer` retrieves the original typed array
through existing bounded Scientific output paging into the client's managed
Bridge workspace. Public callers receive opaque references, never worker paths.

Accepted submission returns the Supervisor's `job_id`. Ordinary GUI submission
and guarded lifecycle requests use the existing trusted auxiliary request owner.
Their immediate receipt has a distinct `submission_id` and `state=PENDING`;
clients wait for the authoritative callback before dependent Job operations.
A pending request never claims an accepted Job ID. Parent process identity is
captured while the actual GUI is alive, and source/lifetime/owner checks finish
before C++ delivery. Progress may coalesce while one validation is active; the
complete journal and first terminal event remain authoritative.

Explicit GUI `prepare` tokens remain in their original owning Tcl interpreter.
`submit(prepared_token)` consumes that same admitted preparation with its
Session/source guards; tokens are not copied between workers or silently
reprepared. This explicit preparation path retains synchronous admission costs;
the auxiliary path's latency benefit does not cover every explicit-token call.

Host `scriptJobSubscribe`/`nativeJobSubscribe` callbacks run through nonblocking
Tcl `fileevent` on the owning GUI thread. Native task progress and terminal state
events carry authoritative Job ID, source correlation, node, strictly increasing
journal sequence and distinct COMPLETED/FAILED/CANCELLED/INTERRUPTED states.
Delivery permits duplicates and reconnect replay. Retained status/results remain
available after a lost callback; reconnect does not recompute the task.

For paired remote native GUI Jobs, the private pre-admitted watcher routes raw
frames only into the existing asynchronous pending validator. Full native,
project/target, Session, source and owner checks finish before C++ delivery.
An offline transport diagnostic instead validates the retained admission against
full local origin/source/build authority; it claims no fresh target state or
remote owner CAS, and carries no scientific state or journal sequence.

Public subscriptions and explicit legacy seven-field remote admissions retain
their full synchronous per-frame origin guards and associated latency costs.
A present invalid paired admission never falls back to the legacy watcher.
Superseding or failing a watch admission retires the previous stream authority
without changing the retained Job or result. Use an explicit new subscribe or
reconnect to obtain a current watcher. Automatic EOF may still deliver its
guarded transport diagnostic; explicit unsubscribe, disposal or a newer request
suppresses an older pending callback.

`register`, `subscribe` and `unsubscribe` are host-only: registration mutates the
installed executable/provider authority, and callback subscriptions own a live
Tcl command/channel lifetime. Script workers use the same durable `events`
journal operation instead of passing host callback prefixes.

Remote native admission reuses configured authenticated Scientific Execution
nodes and the existing `prepare`/`submit` flow. Normal native preparation derives
the installed client build identity and requests authenticated
`native.describe(module, entrypoint, "build.v1")` for the installed target.
Both identities have exactly these nine keys:

- `module_id`, `entrypoint`: installed logical owner and task.
- `artifact_sha256`, `source_sha256`: executable and declared C++/SDK source closure.
- `abi`: protocol, platform, machine, pointer size, C++ standard and declared extensions.
- `dependencies`: bundled dependency SHA map.
- `runtime_dependencies`: verified system-library/loader SHA map for that side.
- `project_source_sha256`: normal compilation inputs plus raw project metadata,
  design and module descriptor, including version/UI identity.
- `build_contract_sha256`: canonical `native_jobs[entrypoint]` source selection
  and parameter contract.

The two builds must match every field except `runtime_dependencies`. That sole
exception permits independently verified system runtimes; it does not admit a
different executable, SDK/source, ABI, bundled dependency, project/version/design
or parameter contract. Each side's complete descriptor and actual runtime bytes
must independently verify. The legacy two-argument `native.describe` exposes the
original seven fields and retains exact runtime equality. Failed `build.v1`
admission never silently falls back to legacy admission.

The same durable request stores `native_owner.remote_build` with exactly
`schema=gxtxt.native_remote_build.v1`, `node_id`, `client_identity` and
`target_identity`. No additional Job store or scheduler is introduced. Client
and target source/identity checks run during prepare and submit. The worker
rechecks the saved target identity, installed descriptor, project/build metadata
and parameter schema on the original module root before copy and again after
copy immediately before a native execution attempt. Result and cold reconnect
revalidate the retained identities, source context and ownership.

A protected retained Job does not adopt changed source/runtime/metadata by
refreshing its pins. Drift refuses guarded reuse; outputs and diagnostics remain
retained, with no repin or recomputation. Use a matching admitted installation or
an explicit new preparation through normal reviewed packaging. Editing descriptor
hashes, uploading an arbitrary executable, or selecting another target artifact
cannot satisfy this contract. A local fixture is not evidence of an actual
authorized remote run.

When the normal Viewer GUI owns a native Session Workspace writer, its trusted
auxiliary admission process and the fresh Script Job preparer use the existing
Workspace read-only Store for source, Document and resource validation. The GUI
keeps its writer and every generation, SHA, owner and Session guard remains in
the existing public service. No writer lock is released or replaced.

Reader selection is internal to these admission interpreters. Each initializes
the pipeline under the existing reader mode and restores the exact original
environment before creating a Job envelope or starting a Supervisor. A fixed
preparer argument carries this private choice to the second interpreter; it is
not a frontend request field, worker grant or persistent mode. An intentional
caller-provided read-only execution environment retains its previous behavior.
Public Host signatures, SDK ABI, Job schemas and worker execution policy are
unchanged.
