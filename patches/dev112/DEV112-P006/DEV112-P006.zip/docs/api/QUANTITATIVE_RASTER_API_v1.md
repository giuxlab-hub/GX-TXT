# QUANTITATIVE_RASTER_API_v1

This CORE service measures original canonical scientific raster samples. Native2D remains the image/ROI owner; Dataset remains the canonical identity/schema authority; Document Resource supplies original bytes; Scientific Execution and Script Job own execution, cancellation, temporary allocations and durable job receipts. Public `math.numeric / NUMERIC_API_v1` owns all reusable mathematics. SII is not a dependency. No measurement changes the source, publishes a Dataset, changes History or installs a persistent pixel cache.

Discover availability with `workbenchExtensionRequireApi QUANTITATIVE_RASTER_API_v1`, `quantitativeRasterApiInfo`, the public API Catalog, or the normal Viewer Development capability browser. Restricted C++ uses the `scientific_view_v1` profile, explicit `QUANTITATIVE_RASTER_API_v1@1/command`, and the existing Scientific Execution `submit` grant for measurements. Source binding continues to require existing Canvas/Host capabilities. The added SDK methods preserve existing Host layout, methods and C entry ABI:

```cpp
void Host::quantitative_raster_command(unsigned canvas, const char* operation,
                                      const WorkspaceValue& request) const;
const WorkspaceValue* Host::quantitative_raster_result() const noexcept;
```

The target is an exact declared `native2d` component with `source_kind=canvas`. Requests are typed `WorkspaceValue` objects, at most 48 KiB/8,192 nodes. Paths, executable names, native pointers and caller-created Resource values are not admitted by the C++ transport. The owning Tk thread resolves the original managed source binding; full canonical SHA/revision reads run in the managed adapter. Blocking admission/status/result/page I/O uses a fixed finite headless adapter through existing `scriptJobAsync`; Tk events remain serviced while awaiting its reply. The live Canvas/Session/source/ROI guards are rechecked before adoption, and cancellation/disposal during admission cancels a late created Job. This adapter adds no queue, source registry or scientific owner. The returned immutable receipt becomes available on the next event; it is transient consultation state, not a second Workspace or scientific authority. An earlier receipt is not evidence that a new command succeeded. Long calculations run in the existing managed provider Job. Command wall latency, Tk event service and worker computation remain distinct measurements.

| Command | Required request fields | Result |
| --- | --- | --- |
| `discover` | `object` | `dataset_id`, `source_sha256`, `source_revision` |
| `map_roi` | `object`, `roi_id` | Integer `x,y,width,height`, retained `roi_id` |
| `submit` | `object`, `operation`, `expected_sha256`, `expected_revision` | Existing `job_id`, `state` |
| `status` | `job_id` | `job_id`, `state`, `source_current`, `diagnostic`, `progress_stage`, `progress_percent` |
| `cancel` | `job_id` | Same lifecycle receipt; no partial measurement |
| `result` | `job_id` | Completed, current typed measurement |
| `reconnect` | `job_id` | Explicit durable Job ownership transfer after the former view closes |
| `histogram_page` | `job_id`, `token`, `generation`, `offset`, `count` | Measurement identity plus ordered integer count page |

`object` is an existing stable Canvas image identity, never object selection interpreted as a pixel ROI. It must retain a canonical `image.raster` source. Display-derived Canvas filter/flatten outputs cannot substitute for that source. `source_revision` is an opaque SHA-256 over the complete existing Dataset revision token, with a versioned domain prefix, using the already shipped native SHA-256 implementation. It covers canonical descriptor, structured metadata and schema, including edits that leave payload SHA unchanged. The job independently captures the full canonical revision and Document receipt through Scientific Execution. Another Session, Canvas, replaced Document, changed image, changed ROI, changed source SHA or changed schema cannot adopt a result.

For `submit`, `operation` is `describe`, `pixel`, `statistics` or `histogram`. Optional measurement fields are `x,y,width,height,channels,frame,histogram_mode,bins,domain_low,domain_high`, or an existing `roi_id`. Explicit pixel/statistical requests require integer `x,y`; statistics and histograms also require positive integer `width,height`. Frame is exactly 0. An explicit rectangle is half-open `[x,x+width) × [y,y+height)`, wholly contained in the original image; it is never silently clipped. Pixel reads return the pixel at `(x,y)`, including the admitted ROI origin when `roi_id` is supplied.

Retained Canvas ROIs use existing `raster_roi_geometry` in original source pixels. Only a validated source-axis-aligned rectangle is admitted. Its lower edges are floored, upper edges ceiled, then intersected with source bounds: every intersecting pixel cell is included. Empty intersections fail. Polygon and source-rotated rectangles fail explicitly; their bounding boxes are never substituted. Image world rotation/scale, device pan/zoom and DPI are separate from the retained source-pixel coordinates. Image mapping/calibration and ROI validation remain Native2D operations. The service reports raw intensity samples and source-pixel spatial units; it infers no physical distance or intensity calibration from DPI.

Channels are original `Gray`, `R`, `G`, `B`, `A`, or `all` where supported. Histograms require exactly one resolved channel. Missing channels fail. Alpha is an independently requested raw component; statistics include all admitted ROI pixels with no alpha masking/weighting, unpremultiplication or background compositing. Stored WhiteIsZero and associated-alpha samples retain their stored numerical codes and explicitly declared interpretation. No automatic luminance, ICC/gamma conversion, normalization, radiometry or wavelength is applied.

Measurement metadata identifies native dtype/depth/components, stored dimensions/orientation, frame, photometric interpretation, alpha association, original Dataset/SHA, admitted rectangle, units and conversion policy. Pixel values use finite typed integers/reals or explicit nonfinite classifications. Per-channel statistics include total, finite, NaN, positive-infinity and negative-infinity counts; extrema, mean and population standard deviation use finite samples only. A channel without finite samples has unavailable/null numeric statistics. The raster provider delegates to public Numeric `statistics_summary` and `histogram_summary`, contract version 1. Numeric composes existing public masks, extrema, reductions and histogram operations. Integer means use the existing binary64 reduction; the admitted integer sum range is exactly representable. Population standard deviation delegates to the existing public native residual RMS about that mean through a typed C++17 binding, avoiding the demonstrated large-ROI squared-sum precision loss. A new Numeric C++17 faithful expansion supplies the demonstrated missing cancellation-safe floating mean; floating population standard deviation also reuses the existing residual RMS. Original float32 values convert exactly to binary64. Arithmetic metadata names the actual Numeric implementation. The Python raster adapter contains no summation, variance or histogram algorithm. JSON NaN/Infinity and fabricated zero statistics are prohibited.

Native integer histograms preserve the complete admitted sample domain: unsigned 8-bit has 256 bins, unsigned 16-bit has 65,536, signed 16-bit has 65,536 with origin −32,768; unit step is one. Float native histograms fail. Bounded histograms require explicit finite increasing domain edges and 1–4,096 bins, with a finite representable uniform bin width. Compact metadata declares uniform edges and the inclusive final edge; an implicit 256-bin scientific projection is never used. Finite underflow/overflow and all nonfinite classes are counted separately. In-range count sum plus underflow/overflow equals finite count; finite plus nonfinite equals ROI sample count.

Counts are an immutable `uint64_le` output, at most 65,536 × 8 bytes, not a 65,536-element control packet. `result` supplies `histogram_output.token`, `source_generation`, and `size_bytes`. Page `offset` is a bin index, `count` is 1–256, and the final page may be shorter. A page includes original measurement/job/ROI/channel/domain identity, output token/generation, ordered counts, total bins and `next_offset`. Consumers reconstruct a histogram with sequential nonoverlapping pages and verify the full count identity. Source and output generation are checked on every page.

The source size limit is 64 MiB encoded; the worker bounds decoded extent, pixels, rows, channels and metadata separately. Original bytes are materialized through existing bounded public Resource reads into Job-owned scratch and rehashed. The generic inline 8 MiB preparation limit is unchanged. Worker elapsed checks are cooperative; blocking bridge/native decoder/tool calls and total process memory are governed by the existing configured Script Job guardian. Its actual policy is available in the normal Job status. A 120-second cooperative check is not a hard 120-second guardian deadline. Cancel, Session expiry and disposal use existing job/resource owners; failed, cancelled, interrupted and incomplete outputs never become measurements. Only the matching terminal job retires its Canvas pending slot, even when its source is stale. Status/cancel remain available for stale jobs; measurements remain rejected.

Host errors retain finite validation/capability errors; CORE errors use `{GXTXT QUANTITATIVE CODE}` with `SOURCE`, `LIMIT`, `OWNER`, `STALE_SOURCE`, `STALE_ROI`, `UNSUPPORTED_ROI`, `ROI`, `DOMAIN`, `BUSY`, `NOT_COMPLETED`, `OUTPUT`, `STALE_OUTPUT`, `PAGE`, `OPERATION` or `CAPABILITY`. Existing Dataset/Resource/Scientific Execution owners may return their own more specific integrity/Session errors. Decoder errors are terminal Job failures, never a numeric fallback.

Trusted Tcl hosts may use `quantitativeRasterSourceInfo`, `quantitativeRasterSubmit document dataset expectedSha expectedRevision originalResource parameters`, `quantitativeRasterStatus`, `quantitativeRasterCancel`, `quantitativeRasterResult` and `quantitativeRasterHistogramPage`. The equivalent Script Bridge family registers `source_info`, `submit`, `status`, `cancel`, `result`, `histogram_page`. Canonical identity and Document Resource ownership are mandatory on these routes too. Script operation metadata does not grant C++ privileges.

The qualified decoder subset is explicit. PNG admits noninterlaced unsigned 8/16-bit Gray, RGB and RGBA with checked signature, chunk bounds and CRCs; palette/sub-8-bit/gray-alpha/transparency-key/APNG/EXIF/iCCP inputs refuse. Qualified gAMA/sRGB metadata does not transform stored sample codes. The bundled C++17 decoder uses libpng native scanlines without gamma, palette, alpha or depth conversion; no user executable or filename enters the request. Classic little/big-endian TIFF admits one top-left IFD, contiguous strips, Gray/RGB/RGBA uint8/uint16/int16/float32, None/LZW/Deflate8 compression and declared RGBA association. BigTIFF, tiles, planar-separate, nonidentity orientation, mixed sample definitions, other photometrics/compression and unknown extra channels refuse. The same C++17 decoder uses native libtiff scanlines with 32 MiB single-allocation and 128 MiB cumulative allocation limits. Generic CORE worker support and the existing Canvas image-info/preview owner's reachable subset are distinct: worker float32 RGB/RGBA support alone does not establish C++ Canvas admission. Actual supported client formats must be checked through normal binding; an unsupported preview admission never fabricates a measurement.

The existing Job progress record reports fixed stages `materialize`, `decoder_initialization`, `measurement`, `complete` (or `waiting` before a worker record is available) and a bounded percentage. Status is lifecycle/binding consultation; result and histogram-page adoption additionally verify the actual canonical payload SHA, including same-size rewrites within coarse filesystem timestamp resolution. A timestamp-derived identity is never substituted for scientific content integrity.

Successful measurements include finite nonnegative `timings_ms`: `materialize`, `decoder_initialization`, `native_extraction`, `native_scanline_decode`, `measurement_including_row_decode`, `measurement_excluding_row_decode`. C++ decoding/extraction precedes public Numeric computation. `measurement_excluding_row_decode` reports the public Numeric adapter interval, including its transport/startup work. The retained `measurement_including_row_decode` adds the separately measured native scanline-call cost; it is a composed cost across these sequential phases, not the total Job wall time. `native_extraction` reports the enclosing native extraction interval separately. These worker stage measurements exclude Job queue/scheduling, source admission, Tk service and physical display latency; those require separate client measurements. No correctness result establishes an unmeasured frame rate or latency guarantee.

Job view ownership uses additive nullable metadata on the existing Script Job row, with atomic compare-and-set claims. A live Canvas view, including another view of the same Document, cannot access or cancel another view's Job. `reconnect` is explicit: the old process must have ended, or its exact NativeCanvas instance must be disposed; the new live view must match the original Session, Document, logical Canvas, source and ROI guards. A cold process must reconnect before reading a retained Job. This changes neither the existing scientific record nor its result. The backend has no new scheduler, registry or Dataset authority.

The extractor writes only original-dtype per-channel buffers into existing Job scratch. The trusted Python provider remains the existing Scientific Execution `run(context)` adapter and uses NumPy memory maps for typed transport only. Each channel has at most 16,777,216 samples. Existing public binary transport preserves dtype and nonfinite samples; no large numeric arrays enter Tcl or JSON. Summaries accept bounded complete channel vectors, with blockwise classifications/histograms; this is not a constant-total-memory or public serialized streaming-state claim. The existing 512 MiB transport bound is per buffer, not an aggregate memory limit. Actual guardian policy and focused RSS evidence must be consulted separately.

Saved Sessions retain the existing native Workspace writer in the GUI. Fixed quantitative auxiliaries and their computational Job select the existing Store's additive committed read-only context before Session loading. They neither unlock that writer nor copy/migrate/recover its database. Each reader uses one consistent SQLite WAL snapshot for metadata and lazy bodies, rejects writes and closes promptly; the Script Bridge ends its read context at public request boundaries, including before lengthy Numeric computation. A reader observes committed state. Requests carrying a newer undurable GUI receipt fail the existing identity checks until ordinary Save/flush completes. Pending recovery or incompatible schemas require the normal writer and refuse in a reader. All canonical Dataset/Resource/source SHA and parent live guards remain mandatory. The default GUI and other existing writable hosts retain their original admission behavior.


## Script-owned Canvas projection

The shared `quantitative_raster` provider additionally exposes `api_info` and
`canvas_command(canvas, operation, request)`. `api_info` copies the original
owner's exact metadata, including typed limits and operation lists.

`canvas` must already belong to this Bridge execution through
`NATIVE_2D_GEOMETRY_API_v1/canvas_create`. The adapter captures and rechecks the
actual Module, Document generation, native Canvas/geometry and Session lease
around the original command. The existing finite request validator admits the
eight commands in the table above. Caller paths, callbacks, programs, worker
arguments, process/owner overrides, Resource objects and internal claim actions
are refused. Existing canonical Dataset/Resource/source-pixel ROI owners derive
all source authority from the actual bound Canvas object.

An unmounted owned Canvas supports the original data facets. `submit` still
requires the real configured Scientific Execution provider, decoder and Numeric
owners; it returns an actual managed Job. `result` and `histogram_page` require
validated completed outputs and current source/ROI/Document guards. `status`
and `cancel` retain lifecycle consultation when the source becomes stale;
cancellation reports the original owner state, including an already terminal
Job. `reconnect` uses the original durable compare-and-set only after the prior
process or exact Canvas instance closes, with matching logical Canvas,
Document/source/ROI guards. It accepts no caller owner or process identity.

The Viewer Development command facade separately requires its actual declared
GUI component, capability and semantic/window lifetime checks. The script-owned
Canvas projection supplies no ownership of a different Viewer window or Canvas
and grants no new process, Job, publication or scientific authority. The six
existing direct scientific operations retain their original contracts.
