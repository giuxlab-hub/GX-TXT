# P006 additive original-owner value facets

SPDX-License-Identifier: GPL-3.0-or-later

Source proposal against `1084faa75da196f46806cf003730e3dcd0cb2b51`;
new adapters have not been executed or independently accepted. Existing
registrations, callable owner bodies, native kernels, GUI, transport, restricted
C++ SDK and Host grants retain their baseline definitions. Catalog regeneration,
installation and runtime checks require separate MAIN authorization.

Python and Octave use the same existing registry. Its generic C++ route needs
no new whitelist/source grant. Module operations use normal
`modulePublicApiActivate` for their original declared API/provider. No invented
Window, Host configuration or callback is supplied.

## Added operations

| API / existing registered provider | Operation / positional arguments | Original typed result |
|---|---|---|
| DOCUMENTATION_BROWSER_API_v1 / documentation_browser | `documentationBrowserRefresh()` | ordered original document ID text list, not descriptors or paths |
| MATHEMATICS_EXPLORER_API_v1 / viewer.mathematics_explorer | `finiteNumber(value, label)` | finite double or original labelled error |
| same | `tokenize(expression)` | ordered two-text token cells including final end/empty token |
| same | `parseExpression(source)` | tagged nested AST cells; double constants and text names/operators |
| OCR_LAYOUT_API_v1 / CORE | `supports(capability)` | original exact capability membership Boolean |
| same | `requireCapability(capability)` | original integer 1 or original unsupported-capability error |
| TABLE_EXTRACTOR_API_v1 / CORE | `supports(capability)` | original exact capability membership Boolean |
| same | `tableToMatrix(table)` | original matrix field, ragged ordered text rows |
| same | `tableToCsv(table, options?)` | original CSV text, no file write |

Documentation refresh retains raw CORE ownership. Its new typed route is an
explicit alternative on existing provider `documentation_browser`; CORE's raw
identity is not renamed. The other eight additions retain their exact original
provider identities. Refresh rebuilds the original interpreter's installed
descriptor index, accepts no path, activates no scientific module and opens no
GUI. Result limits: 8,192 IDs, 1,024 UTF-8 bytes per ID, 4 MiB combined ID text.
Excessive results error without truncation.

Mathematics arguments are text, each at most 1 MiB. The original lexer/parser
owns its 180-character/55-token/nesting/32-node rules and errors. The adapter
only transports returned tags and declared scalar types; it does not parse or
evaluate expressions. Numeric token spelling stays text; AST constants become
doubles. These methods do not call Numeric algorithms or publish results.

Capability text is limited to 4,096 UTF-8 bytes. These methods do not probe
external tools, invoke extraction or establish scientific availability.

The Table profile supports at most 256 rows, 256 cells per row, 4,096 cells
total and 1 MiB combined UTF-8 cell text. Empty/ragged rows, empty cells,
whitespace, Unicode and numeric-looking text retain exact spelling/order.
Numeric JSON cells are refused rather than inferred as text/scientific arrays.
Other table fields pass through to the owner and are ignored there. Missing
`matrix` reaches the original owner's error. Arbitrary non-matrix Tcl values
are a broader raw contract and are not claimed as a full alias of this profile.

CSV options default by omission to the original `{}`. The original Tcl owner
checks a text separator's one-character requirement, quotes cells and joins
rows without a trailing newline. The adapter implements no CSV algorithm and
limits returned UTF-8 text to 2 MiB. Original errors propagate; there is no
file export, OCR, clustering or inference call.

## Attribution and held tasks

Native2D policy records 25 exact published host signatures under source-registered
CORE ownership, traced through `workbenchExtensionCoreApis`, `native2DCadApiInfo`,
the nested Canvas command list and original catalog provider row. Existing
`native2d` metadata and `native2d_geometry` projections remain distinct from raw
aliases. Per-operation acquired-handle, held-edit, extension, Resource,
pending-operation and callback constraints do not create worker grants. The
earlier `{canvas snapshot}` presentation declaration and later `{handle}`
Snapshot facade retain their different signatures and recorded source order.

Acquisition cancellation documents its already-acquired process-local request
token, original phases/lease/request cancellation and default reason. The exact
callable has no WorkerOwner argument or check. A token string does not acquire
another interpreter's request or an admitting-caller capability.

Eight exact-17 rows remain held: Mathematics `nativeModel`; OCR `filterRoi` and
`toText`; Project `projectCurrentId`; Replicate `historyValidate` and `validate`;
Scientific Recipe `rebase`; Table `extractLayout`. The durable pre-code table
retains each source, baseline, codec/context gap and next decision. The 23
independent wrong-scope policy findings remain individually open. No count is
converted into a missing-binding verdict or general HOST exemption.

## Deferred focused checks

These instructions grant no runtime budget and are not executed by this batch.
After independent source review and a separate MAIN gate, use normal newly
installed private Python/Octave Bridge clients. No fake Host/cfg context,
source-grant alteration, frozen provider or broad historical campaign.

1. Compare all prior 1,755 registration keys/descriptors with their pinned
   baseline; only these nine additions are proposed. Verify ordinary module
   declaration/activation and unchanged generic C++ registry eligibility.
2. Through `gxtxt_api_call`, compare the same bounded fixtures in both clients
   with the exact original Tcl owners in an independently admitted reference
   context: finite text `"1.25"`, labelled invalid/nonfinite errors, `"1e2+x"`
   token spelling, nested tagged ASTs and malformed expressions. Do not use
   the adapter as its own reference oracle.
3. Check known/unknown/case-varied capabilities and require errors without
   starting external tools or scientific workers.
4. Compare empty/ragged text matrices, `"001"`, quote/separator/newline/Unicode
   cells, omitted/empty CSV options; include nontext/missing matrix, malformed
   separator and finite budget boundaries. Verify shape/text, never truncation.
5. Compare the entire refreshed ordered ID result to the original documentation
   owner; check path-free results, strict arity and unknown-operation refusals.

Any failure retains its own source/clock/custody scope. Original Bridge reviews
independently; MAIN alone integrates. No scientific/pixel/frozen-provider/global
C/W06/full-scope/release acceptance follows from this source proposal.
