# Script Parameter Dataset API v1

Save additively accepts final `?invocationSchema?` after `?reviewed?`, preserving
manual invocation-only declarations alongside the saved schema. Load additionally
returns `invocation_parameters`. Structured metadata separates
`registry_declarations` and `invocation_declarations` while `declarations` remains
the complete effective typed schema. Existing declaration-only presets retain
compatibility. See [source and invocation parameter contract](SCRIPT_PARAMETER_DECLARATIONS_v1.md).

SPDX-License-Identifier: GPL-3.0-or-later

`gxtxt.script_parameters.v1` is an ordinary canonical typed Dataset for one
reviewed Script invocation. It extends the Script Registry/Execution owner;
Dataset Publication API v2, Variable Schema v3, Metadata, Namespace and Canonical
Dataset access retain all persistence, integrity and authorization authority.
The numeric CSV `PARAMETER_SET_API_v1` contract remains separate.

Host review operations are:

- `scriptParameterDatasetSave session reference supplied dataset_id ?label? ?reviewed? ?invocationSchema?`
  validates effective typed values and creates a new Dataset. Optional reviewed
  metadata pins SHA/revision/declarations; Script identity is checked again
  before finalization. Existing IDs are
  refused; no implicit replacement, automatic Save or execution occurs.
- `scriptParameterDatasetLoad session reference dataset_id` validates the whole
  preset before returning `parameters`, `dataset_id`, opaque `revision`, `sha256`
  and `variable_ids`. The caller applies values only after success.

The raw signatures are trusted host invocation-review contracts. Script Bridge
also offers the closed current-Script projection below; it does not acquire
interactive Registry mutation, caller-selected review state or another producer.
Canonical Dataset APIs and `gxtxt_context().parameter_dataset` remain available
with their original data/provenance contracts.

The registered `SCRIPT_PARAMETER_DATASET_API_v1` version1 provider
`script_execution` exposes:

- `save({dataset_id, parameters, label?})` creates a new canonical preset for
  only this owner-prepared registered Script snapshot. Parameter values are
  inert scalar text, integer, finite number or Boolean values. Original Registry
  normalization decides required/default/range/choice/color and integer storage
  semantics. Label is optional UTF-8 text up to4096 bytes without NUL. Caller
  manual invocation declarations are excluded; the original Registry schema is
  used. Existing Dataset IDs refuse rather than replace.
- `load({dataset_id})` invokes the original canonical preset validator for this
  same Script. It returns typed `parameters`, `variable_ids`, `dataset_id`,
  `sha256`, `script_sha256` and `script_revision`. Manual invocation declarations
  present in a valid preset remain data used by the original normalizer; they do
  not change this Job's parameters, grant callbacks or authorize execution.

Both require prepared `registered_script` mode, exact frozen reference/source
SHA/revision/language and the actual runtime Analysis module selected by the
original Script owner. CORE service/package/custom/foreign-module contexts are
excluded. No caller reference, Session, source/root pathname, language/module,
reviewed metadata, schema, owner context, callback, namespace or publication
override is accepted. Any active DatasetPrivate Module must already match the
runtime identity; it is never cleared or switched to another producer.

The wrapper derives and pins the current full Registry record/root context at
call entry, as the existing static inventory adapter does. Existing runtime
fields do not attest a historical launch-time Registry root. Load rechecks that
held owner after reading. Save internally supplies all four original expected
fields; the original owner takes the existing source-authoring lock, checks
identity before preparation and immediately before finalize, aborts its writer
on failure, and releases only its owned lock. Legacy host calls without expected
fields keep their previous signatures and behavior. There is no new Registry or
transaction coordinator, and no atomicity claim across separate Registry and
Dataset owners. Save has no post-finalize wrapper Registry refusal that would
misrepresent a committed publication as an uncommitted operation.

Save returns committed `dataset_id`, `sha256`, `script_sha256` and
`script_revision`, and records only that committed Dataset through existing Job
publication tracking. Raw writer paths, provider process diagnostics and the
raw Dataset revision (which contains an absolute Session path) are omitted from
both public results. This is an explicit projection of the raw host contract;
the original owner still uses the complete raw revision for its internal checks.
Path/file/command declared parameter values are inert normalized text here;
neither preset operation follows a supplied pathname or executes a command.

The Dataset contains one row with a stable Variable ID `p_<parameter_name>` for
every effective parameter. Integers use int64, finite real numbers float64,
booleans bool, strings and choices string. Original declaration type, constraints,
required/default rules and choice vocabulary are preserved in structured metadata;
a string-backed choice is still validated against its exact declaration. An
out-of-range integer is refused by Publication, rather than narrowed. Existing
UI Field normalization maps whitespace-only optional strings to empty; other
Unicode, quotes and embedded newlines retain their exact text. Unset
optional numeric values remain absent. A script with no effective values has
only the bool `preset_marker` Variable and an empty names list. Every preset
includes that true marker to retain a physical row even when its only parameter
is an empty or whitespace-only string.

Structured metadata `script_parameters.*` records schema
`gxtxt.script_parameters.v1`, qualified `reference`, `source_sha256`,
`script_revision`, canonical sorted `declarations` and effective `names`.
Metadata and typed payload commit atomically through Publication. The owning
producer is the language's existing Analysis module. Save defaults to that
producer's private namespace; cross-namespace reading does not grant writes.
The display label is presentation only. No private preset file/registry exists.

Load requires the reviewed current Session, exact contract, compatible qualified
Script reference/source SHA/revision/declarations, exact Variable IDs/dtypes and
one-row shape, complete effective names, valid current required/type/range/choice
rules, matching canonical payload SHA and an unchanged Dataset revision through
readback. Missing/extra/duplicate names, wrong types, altered payload, incompatible
Script or foreign Session refuse without applying partial values. Loading a
moved preset explicitly is permitted in its current namespace; an already loaded
review becomes stale if that identity/revision changes.

Runner values remain editable after Load. Run passes effective values separately
from the preset provenance. Job preparation reloads and verifies the exact preset
revision/SHA/Variable IDs, then freezes those identities in the immutable receipt
and runtime. A later Bridge call rejects a changed preset. Choosing a different
Script or Session requires a new review. Preset editing never updates a registered
Script's source, schema/defaults or debugger state.
