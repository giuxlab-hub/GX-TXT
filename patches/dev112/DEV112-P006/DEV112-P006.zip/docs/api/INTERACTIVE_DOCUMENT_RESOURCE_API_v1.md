# Interactive Document Resource API v1

An optional derivative may declare both `disposable=1` and
`scientific_authority=0` in its metadata. Workspace preflight/reference discovery
still validates logical owner/generation and SHA syntax, but permits a missing
or corrupt optional blob so its owning service can rebuild. Reader/Info remain
strict and verify complete size/SHA. Scientific resources retain strict
preflight. `interactiveDocumentResourceFinalize writer ?repair_disposable?` and
`interactiveDocumentNative2DStore document scene object ?metadata?
?repair_disposable?` default to false; true can atomically repair only a freshly
verified derivative with those two explicit flags. Symlinks are always rejected.
This adds no caller-selected storage path or scientific mutation authority.

CORE owns content-addressed binary resources associated with a real Session
Interactive Document. These resources do not register Datasets. References
contain the document ID, SHA-256, byte size, format and public metadata; no
private storage path is returned.

Open a writer with `interactiveDocumentResourceOpenWriter document metadata`.
Append binary chunks of at most 1 MiB, then finalize or abort. Finalization
verifies an existing content-addressed object before deduplicating it. Writer
tokens are process-local and Session-scoped. A failed writer can be aborted.

`interactiveDocumentResourceInfo` verifies identity, size and hash.
`interactiveDocumentResourceReadChunk reference start count` bounds arbitrary
reads to 1 MiB. For sequential bulk transfer, OpenReader/Next/CloseReader verify
the hash on opening and completion and keep bounded buffers. Reader tokens are
Session-scoped. Missing/corrupt resources and cross-Session use raise explicit
errors.

`interactiveDocumentResourceReaderInfo token` returns the admitted `reference`
and current byte `offset`, without a filename or resource bytes. It does not
advance the reader or hash its complete content again. OpenReader verifies the
SHA and captures the regular file's device, inode, size, mtime and ctime before
and after admission; ReaderInfo and Next reject changed file versions, replaced
Document generations and expired Session lifetimes. Next still verifies the
complete SHA at EOF. These checks rely on the managed resource's immutable
content contract; ReaderInfo is a live admitted-handle check, not a new hash
verification receipt. CloseReader remains valid after expiry for cleanup.
An image controller may retain this existing reader for repeated bounded
metadata operations and close it with its object/scene, avoiding full-image
hash subprocesses on each pointer update. No pixel cache is created.

`interactiveDocumentResourceReadRanges reference {{start count} ...}` reads
an ordered sparse page with one verification transaction. It validates all
ranges first, permits at most 65536 ranges and 1 MiB total output, and returns
binary blocks in request order. This supports exact row locators without
repeated full-resource hashes or exposing a storage path.

`interactiveDocumentResourceCollect document ?live_references?` removes complete
blobs that are referenced by neither the current document payload/history nor
the supplied live preview references. It validates the full reference/deletion
set first, retains pending writers and rejects symlinks. The scan has explicit
depth and node limits. Close discarded previews before collecting; an accepted
geometry resource remains referenced in the saved document. Append accepts
binary byte values only; encode Unicode explicitly before calling it.
Singleton lists of accepted records retain nested resources during collection.

Collection also retains references from committed Dataset metadata, other
documents and active readers in the current Session lifetime. Deleting a
document closes its current reader/writer handles and removes unreferenced
blobs. Scientific blobs still referenced by published Datasets or other
documents remain readable under a retired resource owner, which accepts no new
writes and is not an Interactive Document entry. `Collect` also accepts such an
owner and removes it after its last reference is released. New references carry
the owner's persistent `owner_generation`; explicit document-ID reuse cannot
revive a former generation's reference. Opaque handle scope changes on Session
switch/return and same-path directory replacement. Portable content references
can be reopened in a newly opened copy of the Session.

The Native2D Store/Restore adapters stream complete geometry as interleaved
float64 little-endian XY, without a whole-geometry Tcl list. Failed restore
removes its partial native object. ImportNumeric streams an explicitly supplied
owned Numeric runtime artifact into CORE storage; it does not reconstruct any
canonical Dataset or Session target path.
Native2DRestoreWithGaps additionally consumes an owned
`native2d.uint8_break_before_v1` resource, one 0/1 byte per finite point. It
preserves missing-pair gaps across chunk boundaries and rolls back partial
geometry on any XY/mask shape, content or lifecycle failure.

Interactive Document metadata now includes a positive monotonic `revision`.
Older documents start at revision 1. Changed payload/format increments it;
an unchanged save preserves it. Extension contexts validate document ownership
and revision before execution.


## Registry ownership and bounded verification

Owner generation resolves against the authoritative Document registry without reading/hashing complete scientific payload for each receipt. Resource collection validates each distinct receipt identity once per complete bounded scan; a same-SHA receipt with changed size/generation is independently validated and rejected. Full SHA/corruption/symlink/lifetime validation is retained. Scientific arrays remain in owned resources rather than repeated GUI/history lists.


## Read-only dependency discovery and retired opaque remapping

`interactiveDocumentResourceReferences value ?document?` returns the original
full verified resource receipts nested in an inert value. An optional Document
ID restricts results to that owner. It reuses the same existing bounded validation scanner as Collect,
including nested metadata, Session/generation checks, SHA verification and
optional-derivative policy. It writes, deletes and allocates nothing. Scientific
interpretations and origins are preserved in the complete returned metadata.

`interactiveDocumentResourceRemapReferences value references` retains its public
signature and registration. The full raw opaque Tcl Workspace remap profile is
`UNAVAILABLE_DEPRECATED_OWNER_CONTRACT` and deprecated in the owning host and
all shared Script Bridge frontends. `api_info.operation_availability` and the
`remap_references` descriptor report this full-raw scope explicitly. The
registered entrypoint still validates supplied current receipts. Marker/escape-free inert text is returned exactly,
without a parse/rebuild. Resource-bearing opaque Tcl Workspace snapshots use a
retired format and explicitly refuse; no implicit Workspace conversion is
restored. Adopt resources in an explicitly typed native graph through the
existing `NATIVE_WORKSPACE_API_v1/resource_copy_tree` operation. That owner
streams verified bytes, preserves per-occurrence scientific metadata and changes
only the destination Document/generation. An unsupported legacy-format refusal
is not a successful remap qualification. Empty text and marker/escape-free
inert text retain their existing exact identity behavior. Operation discovery
continues to report the registered entrypoint; discovery alone does not promise
availability of its deprecated full-raw profile. Native `resource_copy_tree`
accepts explicit typed nodes and is a separate contract, with no opaque-format
equivalence.

The pinned public r2 and P001–P005 sources all retain an unconditional retired
remap helper. This establishes unavailability by r2; pre-r2 behavior and the
retirement date are unknown. The full public row remains in the API census and
unavailable inventory; the classification grants no host-only exemption.

Python and Octave share `INTERACTIVE_DOCUMENT_RESOURCE_API_v1` provider
`interactive_document_resources`. The script operations are `open_writer`,
`append`, `finalize`, `abort`, `info`, `read_chunk`, `read_ranges`, `open_reader`,
`reader_info`, `next`, `close_reader`, `references`, `remap_references` and
`api_info`. Binary input/output uses bounded typed `uint8` vectors, retaining NUL
and every byte value; offsets and receipts are structured values. Append accepts
at most 1 MiB, and the existing owner validates ranges, Session lifetime,
Document generation and complete SHA. Reader/writer tokens belong to one Bridge
execution and provider cleanup drains its remaining handles on normal stop.

`references` accepts inert UTF-8 or an explicit receipt-containing struct plus
an optional owner string; it returns the serialized list of original verified
receipts. Distinct metadata interpretations are preserved; duplicate identical
receipts are coalesced. `remap_references` retains its two-string convention.
The owning source lists exact technical reasons for the five remaining
host-only operations: global live-preview collection, trusted file import and
three process-local Native2D scene/object adapters. Public metadata exposes each
reason separately; this is not a blanket exclusion of bounded data operations.

## Compact scientific provenance during reference collection (dev108)

Scientific Job provenance uses an exact compact identity containing `api_id`,
`document_id`, `owner_generation`, `sha256`, `size_bytes`, without duplicating
resource metadata. Reference collection recognizes that exact shape and pins
its original blob after conservative generation/size/SHA verification. It does
not assume disposable-cache semantics or invent source metadata. Foreign
Document/Workspace provenance also retains the original owner's blob. Missing
identity fields, stale generation, wrong size and corrupt bytes reject instead
of permitting collection. Full receipts still recurse through their metadata;
ordinary public resource read APIs still require full receipts with metadata.
