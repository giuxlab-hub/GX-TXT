# Complete component/design Script Bridge operations

These ten bindings implement the original Bridge context decision. They use
existing CORE providers and unchanged Tcl owners; no Viewer Window, new native
algorithm, source/CPP grant, renderer or replay authority is created. Normal
Registry admission is identical for Python and Octave.

`VIEWER_COMPONENT_DEMO_API_v1` / `CORE`:

- `catalog()` returns every original capability/example/gap row, fixture integer,
  provenance and source identity. Original defaults initialize local inert specs.
- `register(type, spec)` forwards the original properties/instructions/states
  map, including original optional states default. Its result is the ENTIRE
  updated interpreter-local spec map, not a Boolean or only the submitted spec.
  Properties have no universal scientific schema: a dictionary retains its
  existing map of whole TclValues. Non-dictionary properties, or properties with
  keys unrepresentable in UTF-8, retain the entire original properties value as
  one opaque TclValue. No admission or original local mutation is changed.
  The original <=16384-byte, key/type/state guards remain unchanged.

`VIEWER_GUI_HOST_API_v1` / `viewer_gui_host`:

- `viewerGuiDesignAnalysisProfile(design, form, properties)` forwards all original
  analysis_* authoring fields, checks references/collisions and returns the full
  validated updated design/handler/menu declarations. No Analysis runs.
- `viewerGuiDesignHandlerSource(module, provider)` returns EXACT original binary
  handlers.tcl bytes as a shared uint8 vector. Original installed enabled provider,
  gui_roundtrip/gui_design, fixed module-directory path, nonlink and4MiB guards
  remain. No byte decoding or code evaluation occurs; no caller path is accepted.
- `viewerGuiDesignModelCreate(design)` returns schema, validated `design`, original
  `saved` input, empty typed `past`/`future` arrays and integer revision0. Saved is
  encoded separately, never substituted with the validated design.
- `viewerGuiDesignModelEdit(model, selector, ...original arguments)` directly
  forwards the complete original switch: icon, add, analysis_profile,
  comparison_browser_only, properties, property, layout, constraints, bind,
  reparent, remove, duplicate, reorder, swap, paste, target and metadata.
  Arguments are separate entries in the public call argument cell/list, exactly
  as Tcl variadic arguments; no adapter selector subset is introduced. Original
  validation/errors, unchanged/no-op behavior, bounded undo/future/revision rules
  and generated inert handler declarations remain owner behavior.
- `viewerGuiDesignValidate(design)` returns the full validated design; original
  schema/reference/icon/API/4MiB/1000-component guards remain. It is distinct from
  the earlier narrower manifest_validate operation.
- `viewerGuiIconEdit(design, selector, ...arguments)` forwards original put,
  rename and remove, including reference rewrites and referenced-remove refusal.
- `viewerGuiIconsValidate(icons)` returns all original embedded assets/provenance,
  bytes/Base64, hashes, dimensions and Boolean alpha. The original installed
  validation helper checks exact fields/PNG/SVG/hashes, <=64 icons/2MiB. No import
  path, rasterizer, GUI photo or rendering action is added.
- `viewerGuiTestFixtureValidate(window, options)` returns the ORIGINAL BOOLEAN.
  Window is unused by that owner. Missing options/marker/current Session yield
  false; current Session must be a strict descendant of fixture_root and marker
  must be regular/single-link/<=1024 bytes. `permitted_commands` is tested only
  for presence. True proves no Window, marker-content authentication, permitted
  command authorization or replay eligibility. No replay operation is added.

All typed design/model/icon results reuse the existing original Viewer Workspace
codec and shared field decoder. Unknown model-root fields and undeclared types
remain complete TclValues; they are not discarded or inferred. Non-scalar native
Unicode fields use the same explicit whole-value representation, and a map with
an unrepresentable UTF-8 key retains the complete whole result rather than a
lossy key. Standard UTF-8 typed results remain ordinary nested Struct/Cell,
Boolean, integer, real and String values. Callers can pass TclValues back through
these bindings. Original null/empty distinctions follow the shared value contract.
Ordinary16MiB/depth64/node and64MiB-LF response safeguards are shared with the
six-value batch; no inactive proof gate is imported. Handler bytes use the
existing exact uint8/resource encoder once, under the original4MiB source bound.

Focused command: `python3 -I -B validation/dev112_p006_working_values01/check.py
NEW_OUTPUT --domain design`. Uses one normal registered consumer per language,
direct original-owner reference values/types and relevant errors; no accepted
nine or six-value rerun, no Window, scientific producer or frozen module test.
Independent Bridge review and MAIN integration remain separate.
