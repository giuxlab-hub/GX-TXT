# Current C/C++ Viewer support catalog

Derived from the distributed Development policy, SDK and runtime owners. Open this catalog from **Develop → C/C++ support catalog** in the Viewer Development Workspace. The existing rendered Markdown manual window provides find, links and scrolling.

P006 synchronization draft: the complete generic control transport is integrated in MAIN `d446ace3796669efb751d87b1064684b7248a183`; the three additional SDK policy-reference comments are integrated in `97e06838dac4b61970843df0263d9582e42d9b06`. Public SDK declarations and layouts remain unchanged. Current API policies, metadata, patch marker006 and release fingerprint sealing remain pending; these development source references do not establish final SDK/ABI or installed-package qualification.

## Language and ownership

C++17 including C facilities.

functions, pointers/references, classes/structs/enums/unions, inheritance/virtual dispatch/RTTI, overloads/templates, recursion, callbacks/lambdas, malloc/free/new/delete/RAII, containers/algorithms, preprocessing/macros/assert, exceptions, threads/synchronization, fork/wait.

Debian system libc/libstdc++/libm/pthread; extra libraries and compiler options require purpose-specific review

Local project logic/data/concurrency are allowed. Canonical Dataset/Schema/Publication/Session/Workspace/History/Job/scientific Plot remain public CORE responsibilities. Language admission does not approve an architectural bypass.

The compiler performs real Clang parsing and checks the fixed public on_event ABI and typed Host calls. Ordinary local C/C++ functions and standard library facilities supplied by the admitted headers are available, subject to their actual Debian implementation. Headers below are the exact direct-include admission list; transitive system dependencies are supplied by those headers. A new direct header, dependency or compiler/link option requires a concrete purpose and MAIN architectural review. Language availability does not grant a competing canonical store, scheduler or scientific renderer.

## Project source closure

One existing Viewer project contains `handlers.cpp`, declared `src/**/*.cpp` translation units and `include/**/*.hpp` local headers. Its ordered `source_files` also admits `scripts/**/*.py`, `scripts/**/*.m`, `jobs/**/*.cpp` and `jobs/**/*.hpp`. The unique `handlers.cpp` entrypoint comes first; the entire mixed-language closure has at most 32 files, 64 KiB per file and 1 MiB total. The official C++ lexer/AST admits the GUI translation units and their headers against that immutable source snapshot. Script sources remain inputs of the existing Script Project/Execution owner; native task units compile separately against the native Job SDK. They are not linked as GUI translation units.

`script_entries` declares at most 32 named Python or Octave entrypoints, each with `language`, a declared `scripts/` `entrypoint`, optional `required_apis` and the existing `parameters` schema. `native_jobs` declares at most 32 named targets, each with 1..32 unique declared `jobs/` C++ `sources` and optional `parameters`. Names match `[A-Za-z][A-Za-z0-9_]{0,63}`; the parameter schema is bounded to 32 KiB. A declaration supplies no execution grant. Save All, Build, Export, checked import and the normal Plugin Manager preserve one project/package containing the Viewer, scripts, native tasks and all source identities. Bundled script execution requires no unrelated external Script Library package.

Source manifests retain path, role, byte size, SHA256 and complete source/project digests. A declared source/header/script/task edit invalidates stale runtime/build/package/debug identities. Literal reviewed includes use `#` or `%:` directives with phase2 splices; macro/external/escaped includes, numeric source remapping, trigraph/embed and header-existence queries require review. Ordinary/raw string content is inert. No authored compiler/build hook is available.

Independent Source Surface tabs retain per-file dirty state and Save All preimages; file add/rename/move/remove and checked editable package reimport delegate to the same Development owner. Original GDB/MI frames retain authentic full source names and normalized project_file identities across helper translation units and executable headers. External/native frames stay external; pending breakpoints do not establish an executable stop.

## Admitted headers and review decisions

The policy lists exactly 46 reviewed system header identities below. Each row records facilities and the architectural decision for local project logic; CORE ownership remains authoritative. Source admission additionally permits the fixed `gxtxt_native_job_v1.hpp` SDK include only from declared `jobs/` sources. The Viewer SDK is automatically supplied. A task SDK's own implementation includes do not add reviewed direct system includes for authored sources. Admission is not exhaustive functional or platform acceptance.

| Exact header | Facilities, purpose and architectural review |
| --- | --- |
| `vector` | Reviewed local application containers; canonical Dataset access stays in public CORE |
| `array` | Reviewed local fixed-size application containers |
| `list` | Reviewed local application sequences |
| `deque` | Reviewed local application queues |
| `map` | Reviewed local application key/value state, not a canonical store |
| `unordered_map` | Reviewed local application indexes, not a canonical store |
| `set` | Reviewed local application sets |
| `unordered_set` | Reviewed local application sets |
| `queue` | Reviewed local application traversal/queues, not a CORE Job scheduler |
| `stack` | Reviewed local algorithm/application stacks |
| `memory` | Reviewed RAII and smart pointers for project memory |
| `utility` | Reviewed move/forward/pair facilities |
| `algorithm` | Reviewed local application algorithms; no replacement scientific service |
| `functional` | Reviewed callable wrappers/callbacks |
| `string` | Reviewed project strings; SDK transport remains bounded |
| `string_view` | Reviewed non-owning strings; respect lifetime and SDK transport |
| `tuple` | Reviewed local typed values |
| `type_traits` | Reviewed templates/type introspection |
| `typeinfo` | Reviewed ordinary RTTI/polymorphism |
| `exception` | Reviewed C++ exception lifecycle |
| `stdexcept` | Reviewed project error handling |
| `new` | Reviewed allocation/placement/lifetime |
| `limits` | Reviewed type bounds |
| `thread` | Reviewed local application threads; managed CORE Jobs remain authoritative |
| `mutex` | Reviewed local synchronization |
| `condition_variable` | Reviewed local synchronization |
| `atomic` | Reviewed local synchronization |
| `chrono` | Reviewed local time/duration measurement |
| `cassert` | Reviewed genuine native assertions |
| `assert.h` | Reviewed genuine native assertions |
| `cstddef` | Reviewed size/pointer types |
| `stddef.h` | Reviewed size/pointer types |
| `cstdint` | Reviewed exact-width local types |
| `stdint.h` | Reviewed exact-width local types |
| `cstdlib` | Reviewed allocation/conversion; inspect actual process/file use for CORE ownership |
| `stdlib.h` | Reviewed allocation/conversion; inspect actual process/file use for CORE ownership |
| `cstring` | Reviewed bounded project memory/string handling |
| `string.h` | Reviewed bounded project memory/string handling |
| `cstdio` | Reviewed project-scoped I/O; never private canonical Dataset/Workspace access |
| `stdio.h` | Reviewed project-scoped I/O; never private canonical Dataset/Workspace access |
| `cerrno` | Reviewed native operation diagnostics |
| `errno.h` | Reviewed native operation diagnostics |
| `unistd.h` | Reviewed fork/_exit local process workflow; not a replacement CORE execution service or canonical file bypass |
| `sys/types.h` | Reviewed native pid/type declarations |
| `sys/wait.h` | Reviewed wait/waitpid for own forked child lifecycle |
| `pthread.h` | Reviewed ordinary local thread/synchronization facilities |

## Supported public Host functions

The SDK provides a first-class generic C++ Script Bridge frontend in addition to its existing finite GUI facades. The generic frontend selects the same union of registered script-callable operations as Python and Octave through the shared provider registry; it has no C++ per-API or per-operation whitelist. Each provider still owns version, capabilities, module context, Session/source/resource admission and any precise host-only exclusion. Discovering a public Tcl command does not make that command a registered script-callable operation.

The following are the public `Host` declarations. Existing finite facades remain supported and retain their declared component/form, exact version and operation grants. Generic Bridge discovery grants no bypass of those owners.

```cpp
void script_bridge(const char* action, const WorkspaceValue& request) const;
const WorkspaceValue* script_bridge_result() const noexcept;
void native_job(const char* action, const WorkspaceValue& request) const;
const WorkspaceValue* native_job_result() const noexcept;
void text(unsigned component, const char* value) const;
void number(unsigned component, double value) const;
void flag(unsigned component, bool value) const;
double numeric_add(double left, double right) const;
double numeric_sqrt(double value) const;
double numeric_exp(double value) const;
void diagram_open(unsigned component) const;
void diagram_tool(unsigned component, const char* tool) const;
void diagram_command(unsigned component, const char* command) const;
void scientific_discover(unsigned form) const;
void scientific_prepare(unsigned diagram, unsigned form) const;
void scientific_submit(unsigned form) const;
void scientific_status(unsigned form) const;
void scientific_cancel(unsigned form) const;
void scientific_reconnect(unsigned form) const;
void scientific_log(unsigned form) const;
void scientific_import(unsigned form, unsigned dataset_selector) const;
void plot_discover(unsigned form) const;
void plot_bind(unsigned plot, unsigned form) const;
void documents_command(unsigned form, const char* operation) const;
void canvas_command(unsigned component, const char* operation, const WorkspaceValue& request) const;
const WorkspaceValue* canvas_result() const noexcept;
void quantitative_raster_command(unsigned component, const char* operation, const WorkspaceValue& request) const;
const WorkspaceValue* quantitative_raster_result() const noexcept;
void document_bind(unsigned document, unsigned dataset_selector) const;
void document_command(unsigned document, const char* operation) const;
void raster_bind(unsigned viewport, unsigned dataset_selector) const;
void raster_tool(unsigned viewport, const char* tool) const;
void raster_command(unsigned viewport, const char* command) const;
void tex_command(unsigned form, const char* operation) const;
void em_command(unsigned form, const char* operation) const;
void workbench_command(unsigned form, const char* operation) const;
const char* input(unsigned component) const;
const char* data() const;
void cad_command(unsigned component, const char* action) const;
void diagnostics_command(unsigned form, const char* operation, const char* request = "{}") const;
void text_runs(unsigned component, const char* runs_json) const;
void table(unsigned component, const char* rows_json) const;
void catalog_refresh(unsigned form) const;
void catalog_inspect(unsigned form) const;
void catalog_action(unsigned form, const char* action) const;
void numeric_discover(unsigned form) const;
void numeric_evaluate(unsigned form) const;
void numeric_statistics(unsigned form) const;
void numeric_compare(unsigned form) const;
void numeric_publish(unsigned form, unsigned dataset_selector) const;
void dataset_group_review(const WorkspaceValue& dataset_ids) const;
void dataset_group_create(const WorkspaceValue& definition, const WorkspaceValue& review) const;
void dataset_publish_batch(const WorkspaceValue& request) const;
WorkspaceValue dataset_producer_result() const;
void script_library_command(unsigned form, const char* operation, const WorkspaceValue& request) const;
const WorkspaceValue* script_library_result() const noexcept;
void scientific_preview_command(unsigned form, const char* operation, const WorkspaceValue& request) const;
const WorkspaceValue* scientific_preview_result() const noexcept;
void scientific_frame_bind(unsigned viewport, unsigned form) const;
void comparison_command(unsigned form, const char* operation) const;
const WorkspaceValue* comparison_result() const noexcept;
void analysis_command(unsigned form, const char* operation) const;
const WorkspaceValue* analysis_result() const noexcept;
void demo(unsigned component, unsigned fixture) const;
Workspace workspace() const;
```

Presentation operations run through the shared GUI Host. Numerical methods use Numeric; canonical diagrams use Native2D/Interactive Document; scientific forms use Scientific Execution/Jobs; scientific graphs use Plot v4. document_bind uses existing HTML/PDF/Source Surface/paged Dataset consultation. catalog_refresh/inspect/action use a declared GUI Host section and the existing Scientific Library Manager, with exact per-action grants; they do not expose a generic invoke or scientific library parser. demo is explicitly a RAM demonstration and cannot establish scientific acceptance.

## Generic Script Bridge and native Jobs

`script_bridge` accepts transport/lifecycle actions `list`, `describe`, `require`, `call`, `run`, `status`, `cancel`, `result`, `read_resource`, `reconnect`, `subscribe` and `unsubscribe`. These verbs route discovery, exact version/provider selection and calls through the same registry used by Python and Octave. They are not a list of permitted scientific APIs. `run` selects an installed project's declared script entrypoint. The existing Script Project/Execution and Job Supervisor own source admission, execution, resource limits, durable state and results. Operations requiring a shared stateful handle must remain in one ordinary Script Job; bundled scripts provide that execution context.

Generic `list`, `describe`, `require` and `call` requests accept optional `language="Python"|"Octave"`, defaulting to Python. The language selects the actual ordinary Script Job runtime and its shared Bridge client, not a new set of eligible operations or a permission override. `call` requires `api_id`, `operation` and ordered typed `args`, with optional `api_version`, `provider_id`, canonical `inputs` and `language`; `require` carries an ordered `requirements` array. `run` takes its language from the selected declared `script_entries` record and does not accept a separate language override. Lifecycle/resource requests keep their exact Job/cursor fields and accept no language override. Unknown fields and other language values refuse.

The framework-owned runners are `core/python/viewer_bridge_job_v1.py` and `core/octave/viewer_bridge_job_v1.m`. Existing Script Project admission pins the selected runner and complete source closure. Generic resource-backed submissions freeze the exact inert request in the Job's immutable control snapshot and pin its manifest in the execution inputs; legacy inline submissions retain `parameters.request_json`. Python invokes the existing `gxtxt` client. Octave uses the same original request/response packet through its shared client transport and callback/error/EOF loop. `viewer_bridge_request_v1.py` owns envelope/installed-source admission; `viewer_bridge_buffers_v1.py` verifies the immutable input manifest and resolves retained references before provider invocation. The internal `viewer_bridge_control_v1.py` delegates control transfer, retained receipts and context reconstruction to the existing ScalarBroker, ResourceManager and Script Job owners. It introduces no API registry or scientific implementation. Both runners retain typed arrays in existing Job outputs and the same complete `gxtxt.viewer_bridge_result.v1` control receipt. Nonfinite scalar values use an explicit classification tag; exact integer scalars outside int64 use a decimal-string tag. Managed buffers retain original dtype, shape and nonfinite payload bytes.

`native_job` accepts `prepare`, `submit`, `status`, `cancel`, `result`, `reconnect`, `subscribe` and `unsubscribe`. Its Host submit request selects a declared entrypoint, typed parameters and optional admitted source options/managed resources, or consumes its own prepared token retained for the same Viewer/Session lifetime. The shared `native_jobs` provider exposes `info`, `describe`, `prepare`, `submit`, `status`, `cancel`, `result`, `reconnect`, `events` and `read_buffer`; provider submit consumes the prepared token. `read_buffer` validates the completed native Job's retained descriptor, output generation and SHA before returning an original-dtype array through the ordinary descriptor-capable Bridge transport. Both paths delegate to existing Scientific Execution and the same Supervisor rather than executing a task inside a GUI callback. The normal builder packages `native/jobs/NAME` and its source, executable, ABI and dependency identities. Task code includes `gxtxt_native_job_v1.hpp`, returns `gx::native_job::Result` and declares `GXTXT_NATIVE_JOB_MAIN(function)`. Exact typed arrays use the task SDK's managed binary descriptors. See [Native Job API](NATIVE_JOB_API_v1.md).

Requests are typed `WorkspaceValue` objects. The historical 48 KiB inline, 8,192-node and NUL restrictions belong to finite clients and context-v1 transport; they are not global limits on the resource-backed generic frontend. Newly built generic clients transfer captured control resources and reconstruct the complete request/result through the internal context-v2 setter, preserving NUL in exact strings and dictionary keys. Existing precompiled context-v1 clients retain their small-value behavior. Resource reservation, source/Session/Job/lease admission, shared per-argument depth32 and existing native CPU/address-space/file-size budgets still apply. Complete tree reconstruction and the owning compiled callback must fit those budgets; there is no unlimited-size guarantee and failures do not truncate values. Raw `WorkspaceValue::Kind::resource` is not an arbitrary path grant. Scientific bulk arrays retain dtype, shape, byte order and nonfinite values through the existing managed binary descriptor. `read_resource` consults an authorized retained descriptor in pages of at most 16,384 bytes. See the [complete frontend contract](CPP_SCRIPT_BRIDGE_FRONTEND_v1.md).

A reusable managed input is the inert logical reference `{schema: "gxtxt.viewer_bridge_input_buffer.v1", job_id, resource_id}`, with exactly those three fields. References can occur inside ordered `call.args` arrays and nested inert structs/arrays; scanning applies depth32 to each argument and refuses cycles. The owner verifies the originating completed Job, Viewer/module/client, Session/source guards and descriptor integrity before freezing the original bytes into the next Job's existing managed retention. The generic runner resolves those frozen descriptors without per-API conversion or a numerical implementation. At most 256 references and 512 MiB aggregate referenced bytes are accepted; repeated references count toward the aggregate. Manifest file SHA and producer/result/buffer SHA, generation and owner identities are checked before an API sees data. Neither a returned descriptor nor a copied `WorkspaceValue` grants arbitrary filesystem, credential, native-pointer or foreign-Job access. Public requests contain no source filesystem paths. Source-specific provider grants remain mandatory.

Canonical shaped cells use the existing `WorkspaceValue::Kind::array` with integer dimensions in `fields["shape"]`; elements remain flat column-major values. Copying the value preserves this metadata. Both runners retain null, empty arrays/objects, scalar kinds, exact dictionary keys and the original cell shape. Unshaped arrays retain their existing behavior. Scientific arrays keep their separate original binary dtype/shape descriptors. Fixed CORE envelopes do not consume application argument depth.

Submission first returns a pending receipt with `submission_id`; only acceptance supplies the authoritative Supervisor `job_id`. Terminal event receipt and fetched result body are distinct: after COMPLETED, request `result` for that Job and consume the result receipt. `script_bridge_result()` and `native_job_result()` are borrowed immutable pointers into the owning event snapshot; do not retain the pointer or a nested reference across another event. Copy inert receipt fields into project-owned state when needed; copies do not extend a live handle, lease or grant.

The host dispatches `__script_bridge_event__` and `__native_job_event__` through nonblocking channel notification and owning-thread idle delivery. Durable events retain Job identity and sequence, source/module correlation and distinct COMPLETED, FAILED, CANCELLED and INTERRUPTED states. Consumers handle duplicate delivery and reconnect from a retained sequence. Backlog overflow reports recovery required; durable status/event replay remains authoritative. Closing a Viewer retires its subscriptions and live callbacks while retained work/results remain available for explicit guarded reconnect. Admission rechecks the installed enabled module, source/package closure, current Session origin and directory identity, optional Document/Dataset revisions and current client ownership. A callback name, method declaration, copied receipt or discovered operation supplies no grant. Host callback/channel APIs retain their owning-thread lifetime; script workers use the same durable event journal instead of Tcl callback prefixes. The [C++ frontend contract](CPP_SCRIPT_BRIDGE_FRONTEND_v1.md) describes the owning services.

## Native computational task SDK

The separate `gx::native_job` SDK belongs to installed computational tasks under the existing Supervisor, not the GUI Host callback. `Value` is an owned control value; `Result` is `Value::Object`. These are its public aliases, storage and constructors (definitions are inline in the supplied header):

```cpp
using Object = std::map<std::string, Value>;
using Array = std::vector<Value>;
std::variant<std::nullptr_t, bool, std::int64_t, double, std::string, Object, Array> data;
Value();
Value(bool v);
template<class T, typename std::enable_if<std::is_integral<T>::value && !std::is_same<T,bool>::value,int>::type = 0> Value(T v);
Value(double v);
Value(const char* v);
Value(std::string v);
Value(Object v);
Value(Array v);
```

Control integers are exact int64; an unsigned constructor value beyond int64 refuses, and scalar real constructors require finite values. Use typed managed descriptors for larger unsigned or nonfinite scientific arrays. `Buffer` exposes original managed metadata and these read methods:

```cpp
std::string dtype,units,source_alias;
std::vector<std::size_t> shape;
std::size_t count=0,byte_count=0;
std::vector<unsigned char> bytes() const;
template<class T> std::vector<T> values() const;
```

`bytes()` reads exactly the admitted byte count and refuses a changed size or payload beyond512MiB. `values<T>()` requires exact dtype, element count and byte size; it does not silently cast scientific values. Dtype-name specializations are:

| C++ element type | Exact dtype |
| --- | --- |
| `std::int8_t` | `int8` |
| `std::uint8_t` | `uint8` |
| `std::int16_t` | `int16` |
| `std::uint16_t` | `uint16` |
| `std::int32_t` | `int32` |
| `std::uint32_t` | `uint32` |
| `std::int64_t` | `int64` |
| `std::uint64_t` | `uint64` |
| `float` | `float32` |
| `double` | `float64` |
| `std::complex<float>` | `complex64` |
| `std::complex<double>` | `complex128` |

The existing binary owner additionally accepts `bool` descriptors; this native SDK declares no `dtype_name<bool>()` specialization, so no `values<bool>()` convenience is claimed. `Context` exposes:

```cpp
explicit Context(std::istream& input=std::cin);
std::int64_t integer(const std::string& name) const;
double number(const std::string& name) const;
bool flag(const std::string& name) const;
std::string text(const std::string& name) const;
const Buffer& buffer(const std::string& name) const;
Value publish_bytes(const Buffer& source,const std::vector<unsigned char>& raw);
Value publish_buffer(const Buffer& source);
template<class T> Value publish_buffer(const Buffer& source,const std::vector<T>& values);
void progress(double fraction,const std::string& stage) const;
```

The generated task main constructs Context from the admitted `gxtxt.native_job_request.v1` control input. The registered `parameters` schema supplies scalar named fields, at most256 fields and1MiB control input; integer/number/flag/text select those exact parameter types. `number()` also accepts an admitted integer as a double conversion. Managed array inputs are separate named `resources` carrying existing Document Resource receipts with `metadata.binary_descriptor` and optional units/source Variable metadata; they do not become scalar parameters or caller paths. Native preparation retains the existing Scientific Execution aggregate8MiB resource-snapshot cap; the512MiB binary transport ceiling does not raise that preparation limit. Document-bound tasks pass `options.source_guard` with document_id, generation, revision and sha256; original Session incarnation and source/module guards remain authoritative. Context exposes at most256 buffers by their admitted alias; `buffer(name)` returns a reference owned by that Context. Typed publication matches the supplied Buffer dtype/count/byte size; raw publication matches its byte size. Existing CORE validates the emitted descriptor, admitted source alias, ownership and retained output SHA, rather than trusting a returned control object as scientific authority. `progress()` is finite, monotonic and bounded to[0,1] with an escaped stage label on the original progress protocol.

Native task artifacts declare `abi.buffer_descriptor_version=2`. Managed descriptors retain the original version/dtype/endian/order/shape/count/byte_count/resource_id fields: version2, little endian, column-major F order,1..16 dimensions and bounded exact byte counts. Resource IDs are logical32-hex `.bin` names. Older scalar-only artifacts retain their existing scalar protocol and refuse typed-buffer requests lacking the version2 ABI field. The SDK emits `__gxtxt_native_buffer__` version2 control descriptors; CORE retains the bytes in the existing Job outputs and returns a `gxtxt.viewer_bridge_buffer.v1` receipt with SHA/units and guarded source metadata. `publish_buffer(source)` copies the admitted bytes; the typed overload publishes matching typed output bytes. Provider `read_buffer` can recover the original typed array through the existing Bridge descriptor transport, and a retained result's logical input reference can be reused by a later generic Python or Octave call under the same manifest/Job/source guards described above. A returned alias, edited public metadata or copied Buffer supplies no foreign resource grant.

Namespace wire helpers and entry factory remain public inline implementation facilities; use `GXTXT_NATIVE_JOB_MAIN(function)` for the standard entrypoint rather than replacing the owner protocol. Their source-derived declarations are:

```cpp
inline std::string quote(const std::string& v);
inline std::string json(const Value& v);
inline std::string unbase64(const std::string& s);
template<class T> inline std::string dtype_name();
template<class Function> int main(Function function);
```

`dtype_name` has exactly the12 explicit specializations listed above. The native result control object is bounded to1MiB; bulk bytes remain separate managed outputs. Serialization helpers implement this fixed transport and grant no new filesystem/source/capability authority. Native cooperating code is not an operating-system sandbox. Exact SDK declarations, task artifact identity and source/runtime dependency admission remain mandatory; this catalog provides no claim of final installed or remote acceptance.

## Workspace values and owning-thread facade

`Host::workspace()` exposes these public methods; it retains the same native Workspace/History owner and immutable event read snapshot. Mutations are validated and applied by CORE after the native event.

```cpp
WorkspaceValue state() const;
WorkspaceValue property(const std::string& name) const;
WorkspaceStatus status() const;
std::vector<WorkspaceEntry> query(const std::string& prefix = "") const;
void set_state(const WorkspaceValue& value) const;
void set_property(const std::string& name, const WorkspaceValue& value) const;
void save(bool asynchronous = false) const;
void save_as(const std::string& name) const;
void rename(const std::string& name) const;
void open(const std::string& id) const;
void close() const;
```

The value factories and optional model hooks are declared as follows. Resource fields remain logical managed references, subject to the original resource owner. The hooks must restore atomically or compensate with a previously captured value; missing hooks use the safe facade defaults.

Authored Workspace hooks require the explicit `NATIVE_WORKSPACE_API_v1` `get` and `save` lifecycle grants. Their presence or a restored value does not create those grants. Ordinary finite Host/Workspace methods retain the compiler's exact capability mapping; generic Bridge/native methods defer operation admission to their shared owners instead of a second C++ capability table.

```cpp
WorkspaceValue workspace_text(std::string);
WorkspaceValue workspace_integer(std::int64_t);
WorkspaceValue workspace_number(double);
WorkspaceValue workspace_flag(bool);
WorkspaceValue workspace_object(std::map<std::string, WorkspaceValue> = {});
WorkspaceValue workspace_array(std::vector<WorkspaceValue> = {});
WorkspaceValue workspace_resource(std::map<std::string, WorkspaceValue>);
WorkspaceValue on_workspace_capture() __attribute__((weak));
void on_workspace_validate(const WorkspaceValue&) __attribute__((weak));
void on_workspace_restore(const WorkspaceValue&) __attribute__((weak));
void on_workspace_committed(const WorkspaceStatus&) __attribute__((weak));
```

`WorkspaceValue` is ordinary owned inert client data with null, text, boolean, int64, real, object, array and resource kinds. Its fieldwise copy/move assignment, including assignment of an authored aggregate containing such a value, carries data rather than Host authority. The committed policy correction admits only Clang's actual SDK `WorkspaceValue` implicit defaulted copy/move assignment declaration IDs; it does not grant every implicit SDK method or match arbitrary `operator=` names. `Host` capability assignment remains outside the public SDK method policy. This is the precise SDK-member admission boundary, not a general restriction on ordinary authored C++ assignment. The rule is retained in integrated runtime checkpoint `abcfbf7`; final release-source applicability remains pending.

`documents_command` uses the existing declared document-extraction form and
finite GUI Host commands for canonical PDF/image sources, page/ROI presentation,
OCR, table review, publication and cancellation. Source selection, processing
and publication retain their separate Session, source-SHA and capability checks.
See [Viewer GUI Host](VIEWER_GUI_HOST_API_v1.md) for the exact form roles and
operation names; a method declaration supplies no implicit grant.

tex_command uses a complete declared TeX form and finite GUI Host operations. Source Surface, canonical TeX Workspace/Resource, managed native TeX builds, PDF consultation and File Publication retain their existing ownership. Build saves the guarded draft before running the typesetter; installed C++ execution still uses the packaged binary. The additive nonvirtual method/opcode30 preserves old Event/State/Host storage and operations1–29. See VIEWER_GUI_HOST_API_v1 for exact form and lifecycle contracts; source admission is not installed Viewer acceptance.

New Viewer scientific 2D and 3D graphs require PLOT_DATASET_API_v4. PLOT_DATASET_API_v3 is deprecated and denied for new restricted declarations/source/build/export/runtime admission; preserved historical consumers keep their existing compatibility API.

## Canvas and original-sample measurements

`canvas_command` targets one declared `native2d` component with
`source_kind=canvas`, using bounded typed `WorkspaceValue` requests. Existing
Native2D/Interactive Document, Resource, Workspace and History owners implement
editing, source binding, layers, view state and persistence. Scientific Execution
and Dataset Publication retain their explicit additional grants. The borrowed
immutable `canvas_result()` is next-event consultation state for the last explicit
target, not an unrestricted feed of every Canvas. See the
[multilayer Canvas contract](NATIVE2D_MULTILAYER_CANVAS_v1.md) for finite operations,
receipt lifetime, diagnostics limits and source/Document guards.

`quantitative_raster_command` targets that declared Canvas's original canonical
scientific raster source. Its finite commands are `discover`, `map_roi`, `submit`,
`status`, `cancel`, `result`, `histogram_page` and `reconnect`. Requests require
`QUANTITATIVE_RASTER_API_v1@1/command`; measurements additionally require the
existing Scientific Execution `submit` grant and source SHA/revision admission.
Native2D owns ROI geometry, the existing Job Supervisor owns execution, and
public Numeric owns statistics and histograms. Display-preview pixels never
replace original measurements. `quantitative_raster_result()` exposes the next
event's borrowed immutable receipt. The
[Quantitative Raster contract](QUANTITATIVE_RASTER_API_v1.md) defines supported
formats, coordinate/channel/alpha/nonfinite semantics, result paging, lifecycle
and explicit refusals. Both typed clients bound requests to48KiB/8192nodes and
refuse authored paths, native pointers and Resource values. These additive
methods preserve Host/State/Event layout and the original entry ABI; source
discovery alone does not qualify an installed consumer or a platform.


## ABI, compiler and runtime

```text
--no-default-config
-std=c++17
-x
c++
-Werror
-fno-color-diagnostics
-pthread
-isystem
/usr/lib/gcc/x86_64-linux-gnu/14/include
```

The trusted adapter links a shared library with system libstdc++, libm and pthread (-shared -pthread -Wl,-z,defs -lstdc++ -lm). The SDK is automatically supplied. The event handler is `void on_event(gx::Host&, gx::State&, const gx::Event&)`. `Event` retains `EventKind kind; unsigned component; double value;`; `State` retains `double values[16]; unsigned counter;`. `Host` retains one context pointer and one dispatch function pointer. Additive nonvirtual generic/native methods use opcodes 53/54 without replacing operations 1–52 or changing these fields or the original entry ABI. These bounded public event structures do not restrict ordinary local C++ types or project memory. Layout declarations and retained old-package runtime acceptance are separate evidence; this catalog does not infer platform-independent byte sizes.

Development validates and builds once per actual source/build dependency version. Preview, Test and Export reuse the retained binary; closing and reopening an unchanged project does not rebuild it. Installed packages distribute native/viewer.so. Plugin admission verifies that artifact and SDK compatibility; normal installed startup/events load it directly without compiler/linker invocation or a silent rebuild fallback. Missing/incompatible artifacts require a precise error and a compatible package. No development compiler is needed to execute a compatible installed Viewer. Local compiled events use the existing managed persistent worker and apply their public GUI plan before the next queued pointer action; scientific Jobs remain asynchronous.

Current GUI admission/build budgets: each source 65,536 bytes within the complete 1 MiB project closure; compile timeout 30 seconds; active GUI event wall budget 12 seconds. The GUI native worker applies CPU3s, address-space256MiB, output-file1MiB and no core dumps. Native scientific tasks run separately under the existing Supervisor/Scientific Execution admitted resource policy and may outlive a GUI callback. The GUI limits do not become native task limits. Neither cooperating native code nor these budgets establish an operating-system sandbox. Purpose-specific legitimate workload changes need owner review.

## Scalar Numeric transport

Persistent native author limits remain CPU3s/address-space256MiB/file-size1MiB and wall12s. Explicit scalar add/sqrt/exp grants use a conditional pre-limit trusted transport to the exact original broker_message/core Numeric owner, matching the nonpersistent broker boundary. It is not a numerical implementation, scheduler, registry, compiler or new SDK permission. Bounded typed framing/frozen hashes/exact grants and existing supervisor identities/subreaping drain broker plus CORE groups on normal close, failure, cancellation and parent death. A Viewer without scalar grants starts no child. Domain failure discards event UI/state and permits a later valid event in the same native library. Cancellation cannot unwind through ctypes as an uninitialized success.

## Producer-scoped Dataset Groups

Producer-scoped Dataset Group clients add `Host::dataset_group_review`,
`Host::dataset_group_create`, `Host::dataset_publish_batch` and
`Host::dataset_producer_result` under existing Group v1/Publication v2 explicit
capabilities. They use finite typed requests to the existing owning-thread
producer service, with no Numeric form or hidden component. Requests are at most
48 KiB; Review accepts 0..64 IDs and batches 1..64 outputs. Full revisions remain
opaque UTF-8 strings. Native typed numbers remain finite double/int64; Script
Bridge numeric arrays retain the existing writer's NaN/missing-value policy.
Receipts arrive for the next event and identify operation, status, increasing
sequence and event generation. Failures replace old success with a fresh failed
receipt and null result. Grouped batches require explicit Group Create as well
as Review and Publication; ungrouped batches need no Group Create. Original ABI 1
package binaries remain compatible without rebuild. Full flow and limits are in
[VIEWER_DEVELOPMENT_API_v1](VIEWER_DEVELOPMENT_API_v1.md).

## Finite Script Library and scientific Preview clients

The admitted `script_library_command` / `script_library_result` methods use
[SCRIPT_LIBRARY_API_v1](SCRIPT_LIBRARY_API_v1.md), with actual module, declared
form, event, Session and Registry admission. Source-file read availability is
distinct from canonical writer authority. Restored drafts require explicit
current-owner review before a separate Save; a Workspace never carries that
authority. This host/native interface is not a generic Script Bridge Tcl command.

`scientific_preview_command`, `scientific_preview_result` and
`scientific_frame_bind` are finite clients of
[PREVIEW_COMPONENT_GUI_API_v1](PREVIEW_COMPONENT_GUI_API_v1.md); their typed
contracts are detailed in the
[scientific managed Preview client](SCIENTIFIC_PREVIEW_NATIVE_CLIENT_v1.md).
CORE owns exact canonical reads, scientific scope, plane rendering and temporary
presentation. Method discovery grants no filesystem, mutation or publication
authority. Actual supported operations require their explicit admitted grants.

## Integrated debugger

GDB/MI supports breakpoints, Continue, Step Into/Over/Out, Pause/Stop and stack-frame selection through the managed Development owner. Read-only opaque variable identities provide real struct/array children: all aggregates initially collapsed; click to expand vertical fields/elements, click again to collapse. Children load only on request, in pages of at most64; maximum depth8 and512 displayed nodes per stop/frame. A further page is explicit. Each new stop/frame/continuation invalidates old child identities. Unavailable or optimized-out values retain actual debugger diagnostics. No arbitrary GDB console/expression injection is exposed.

Threads and fork/wait are admitted ordinary project logic. This catalog does not promise additional debugger thread-switch or follow-fork controls: the present enumerated control contract remains authoritative. Authors are encouraged to use the integrated debugger for actual development problems and report reproducible CPP_DEBUGGER_BUGs.

## Generic comparison client

`Host::comparison_command(form, operation)` and `Host::comparison_result()` use
the declared reciprocal Builder Comparison profile. CORE validates actual source
IDs/revisions/SHA/provenance, owns bounded read-only Library consultation, delegates
all numerical preparation to Numeric and mounts the same native Plot v4. No raw
samples, Tcl, paths, administrative commands or implicit Dataset publication are
granted to C++. Request the actual `COMPARISON_PLOT_API_v1/comparison_command`,
`NUMERIC_API_v1/comparison_curves` and Plot `widgetCreate` capabilities. Library
use additionally needs the five explicit read-only discovery/content operations
listed in COMPARISON_PLOT_API_v1.md. Missing grants refuse explicitly. Normal
compiled Workspace lifecycle uses the existing native get/save grant and actual
Workspace component; History retains its separate Recipe grants.

The normal Builder File menu creates the discoverable profile. Source selection
is a Workspace UI draft; the prepared scientific configuration is the existing
PlotSpec. Details and scientific limits: [Comparison API](COMPARISON_PLOT_API_v1.md).

## Synchronization fingerprints

Final release source pins are **pending**. The current generic control semantics are documented against merged source `d446ace3796669efb751d87b1064684b7248a183` and SDK reference-comment composition `97e06838dac4b61970843df0263d9582e42d9b06`. The previous finite-only fingerprint table must not qualify the generic resource-backed route. These development source epochs are not the final release freeze; the complete declaration, implementation, policy and catalog projection must be sealed together.

Before shipping this catalog, MAIN must complete pending API policies, metadata/catalog and006 marker, then regenerate the complete fingerprint table against the clean final integrated checkpoint. Compare every exact public Host/Workspace declaration, factory/hook, native task SDK public declaration and dtype specialization, direct admitted header and policy call with the owning sources. Record the actual commit plus each input SHA256; do not copy hashes from a different worktree or infer working bytes from HEAD alone. The census also captures the original Event/State/Host declarations and generic/native opcodes. It does not replace a compiled layout or retained old-package runtime witness.

The inputs include `core/development/policy_v1.json`, `core/development/sdk/gxtxt_viewer_sdk_v1.hpp`, `core/development/sdk/trusted_adapter_v1.cpp`, `core/development/sdk/gxtxt_native_job_v1.hpp`, the existing compiler/Project/GUI Host/Workspace owners, `viewer_project_entries_v1.py`, `viewer_bridge_request_v1.py`, `core/python/viewer_bridge_job_v1.py`, `core/octave/viewer_bridge_job_v1.m`, `viewer_bridge_buffers_v1.py`, `viewer_bridge_control_v1.py`, the shared Cell/string and Python/Octave binary codecs, the original shared Script Bridge server, native/Script Job and Scientific Execution owners, and the current owning API documents. Source hashes are extraction evidence until the final checkpoint is recorded here. Independent scientific, original-ABI, remote and normally installed-package acceptance remains in release evidence.

## UML Document client

ABI-v1 `Host.document_bind`/`Host.document_command` (operations26/41) add declared
`kind=uml`, with `mode=read_only|editable` and readonly `pane=diagram|source|metadata`.
The current `document_view_v1` policy admits explicit `UML_DOCUMENT_API_v1` grants:
`umlDocumentRead`, `umlDocumentParse`, `umlDocumentLayout`, `umlDocumentEdit`,
`umlDocumentWrite`, `umlDocumentExport`. Read/Parse/Layout are the minimum; edits,
canonical saves and exports require their corresponding extra operation. A kind
or SDK call-list declaration never supplies a grant. Actual design admission and
each finite native intent enforce them. Same-ID save also retains original
Document producer/grant/Session/full-revision/source-SHA/namespace checks.

C++ routes primary actions; shared CORE owns literal SourceSurface, semantic
parser/editor, Native2D shaped painter, File Publication and typed UML draft
Workspace/History. No source body, Tcl, renderer path or new native ABI is added.
New finite action names and exact bounded subset are documented in
[UML Document API](UML_DOCUMENT_API_v1.md). Existing native Markdown packages and
old ABI signatures remain unchanged; actual old-package smoke and genuine
Builder-authored UML modules are separate acceptance gates.

## Acquisition target (P032 additive)

The genuine `acquisition_v1` target uses a separate
`gxtxt_acquisition_sdk_v1.hpp` and finite compiler-checked free callback factory;
it does not change this catalog's original Viewer SDK or ABI. Module/profile
capabilities name exact operations of `ACQUISITION_HANDLER_PLUGIN_API_v1`:
source_info, source_read, progress, cancelled, prepare_output, output_write,
output_finish, helper_call. Actual CORE admission intersects profile/module/
phase grants. The metadata browser exposes only this target's actual typed
methods and current saved closure, without compiling or activating a grant.

Selected source bytes use a separate live CORE broker; native actors receive no
source paths/FDs. Typed numeric chunks remain local in CORE-created write-only
buffers, with provisional references and existing Publication/RAW/Group owners.
The new target alone requires pre-CDLL Landlock and seccomp process restrictions;
ordinary same-process threads remain supported, fork/process descendants do not.
See [Native Acquisition SDK](NATIVE_ACQUISITION_SDK_v1.md) for exact signatures,
limits, staged-output handshake and actual registered Python/Tcl helper
dispatcher under the same Acquisition Job. Module/profile capabilities and
live roster/source/lease admission remain mandatory; helper presence alone
grants nothing. Source Note and independent runtime qualification stay separate.
Discovery is not functional acceptance or proof of normal installation.
