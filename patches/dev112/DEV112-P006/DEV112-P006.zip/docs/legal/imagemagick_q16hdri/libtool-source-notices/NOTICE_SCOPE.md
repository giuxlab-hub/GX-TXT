# Original notices preserved

The exact original ltdl.c source header and COPYING.LIB are supplied alongside unchanged Debian libltdl7 copyright. Source header describes LGPLv2+ with specialexception; Debian package notice records GPL2+ with exception/GFDL fordocs. Both are preserved without rewriting or adjudication. Exact reusedlibrary/package/source hashes are in SOURCE_REFERENCES.json.
