# ORION Scientific Image Inspector — P006 package guide

**Carried package:** the corrected normal Builder export is included below.
Its SHA-256 is
`bac8ba95ad80889cc0ee3ec60a775832b7ad483d842e0e202365c555cf05b0da`.
The manual-only successor preserves the original source/design/SDK and ELF bytes.
Its stored compilation receipt is historical; no fresh compilation or runtime
acceptance is asserted here. The cumulative source/archive freeze and independent
installation/qualification remain separate.

## One cumulative release and one normal Viewer package

The P006 carrier includes these files:

- `distribution/packages/viewer.orion_sii_canvas_1.0.7.zip`
- `distribution/packages/viewer.orion_sii_canvas_1.0.7.zip.sha256`

The module ID is `viewer.orion_sii_canvas`, version `1.0.7`. The Viewer package
comes from the normal Viewer Builder export. It includes its actual C++ source,
Builder design, project metadata, manual, SDK contract, compiled Viewer and build
receipt. The original A7 export is preserved; the carried successor corrects the
manual through the original authoring/export workflow. It does not replace the
source, design, compiled ELF, SDK, capability grants or module version.

The package uses the P006 CORE image, Canvas, History, Resource, Workspace,
Scientific Execution and Publication services. The compiled artifact is the
existing Linux x86-64 Viewer ELF; package presence is not a claim of another
platform's binary or of completed scientific/GUI qualification.

## Install through Plugin Manager

1. Install the cumulative P006 framework using its supplied guarded installation
   instructions and exact supported r2 or P005 route. Preserve the actual external
   apply receipt and its checksum. The framework installation carries the Viewer
   ZIP; it does not prepopulate an installed ORION module or private registry.
2. Verify the carried ZIP against its sidecar and release inventory. Start the
   P006 framework and use **Plugin Manager** to install that ZIP. The package ID
   and version must be `viewer.orion_sii_canvas` / `1.0.7`.
3. Let the existing Plugin Manager validate the package/source/native/SDK
   contracts and perform its normal staging, registry and activation lifecycle.
   Follow its actual activation or restart result. Do not copy `native/viewer.so`,
   create a registry entry or force an incompatible package past admission.
4. Open the installed Viewer through the normal Viewer selection with an active
   Session. Its normal Help uses the corrected packaged manual. The scientific
   runtime must satisfy the installed CORE's configured-runtime admission;
   selecting a publication format alone does not establish numerical accuracy.

Plugin Manager derives the installation target from package type and ID. A
pre-existing unmanaged directory is not the same as a managed installation:
ordinary Install requires an absent target, and explicit Update must be newer.
Keep the existing package/version/ownership refusals rather than renaming a
package, fabricating a version or adopting a foreign tree manually.

The stock `distribution/manifests` and registry seed retain their original
accepted-source provenance. They are not a newly generated ORION installation
record. This P006 package-only carrier is bound by the cumulative inventory and
then installed by Plugin Manager; no private installation state is shipped.

## Reopen the real editable project

Use the normal Viewer Development Workspace **Import** workflow with the same
carried ZIP and a new owned project location. The export contains `source/` with
`project.json`, `design.gxtxt-viewer`, `MANUAL.md` and all five declared C++
source/header files. Its existing source and package manifests bind those bytes.
Normal source Import restores editable sources; it does not install a binary or
pretend that an imported project has already been compiled. Use the original
Builder/Workspace owners for later source edits, Build and Export.

## Shared Canvas History and Workspace History

Image **Undo/Redo**, figure **Undo/Redo** and native Canvas **Undo/Redo** navigate
the same Canvas document History. They are not independent image/figure stacks.
A successful new Canvas edit after Undo clears that Canvas redo branch. A failed
or cancelled staged edit preserves the accepted scene and its redo history.

**Restore original (keep source Dataset)** and **Reset image** use the guarded
selected-image restoration path. It requires the real retained original geometry
or proven same-object canonical ancestor. A flattened composition is restored
through original Canvas Undo only when the actual immediately preceding flatten
transition is proven; a later or copied transition is refused with an actionable
message. There is no hidden multi-step rewind or invented single source origin.
**Reset figure** is an accepted Canvas edit and can be undone through that owner.

The outer Workspace History archive has its own admission rules. Browsing an old
Workspace state is read-only until you return to latest or explicitly restart
there. Removing a Canvas branch prompt does not bypass that Workspace rule.
Use normal Workspace Save, Close and Open; do not invoke private Restore calls.

## Scientific source and publication scope

The full original image Resource and its current source/Document guards remain
authoritative; display/LOD images do not replace scientific pixels. Selected-image
processing/publication and whole-Canvas figure publication are distinct actions.
A selected processed Resource must have verified canonical source lineage for
canonical publication. A transient local image does not borrow an old Dataset
selector's identity; import the source through the normal Acquisition/Dataset
workflow when canonical source publication is required.

Whole-Canvas figure publication captures actual Document layers and painted
objects through the shared owners. A vector-only Document can have no image
source IDs; a painted image still requires its own verified source lineage.
Lineage does not imply equality of processed and original pixels. Precision and
format claims must retain the independently checked range/channel/operation
qualifications of the final release; the original and derived images remain
separate scientific identities.

## Installation and rollback records

The cumulative installer and Plugin Manager own different transactions. The
cumulative installer accepts only its exact route/postimage and retained
receipt/installation instance. Its original per-file atomicity and rollback
rules remain unchanged. Newly added carrier files are part of that inventory;
there is no plugin install/uninstall callback inside `apply.py`.

Normal Plugin Manager installation subsequently creates a module and private
registry/staging/runtime state. The cumulative exact-inventory guard must refuse
such a changed framework tree. Plugin Manager uninstall alone is not proof that
the original complete cumulative postimage has been restored. Retain the real
receipts and preserve user modules/Sessions. Use clean isolated copies for the
cumulative dual-route rollback checks, and original owner-controlled restoration
for a modified installation; never delete registries or relax preservation guards.

## Freeze and qualification

The corrected Viewer ZIP, source/design/native identities, checksum sidecar,
this guide and the six truthful qualification-input documents must be included
before one final source/archive freeze. Independent normal installation, GUI,
science/precision, lifecycle and original 119/W obligations use that same immutable
P006 archive and exact carried package. A matching SDK or successful Export is
not those results. Final reports and the actual archive checksum/owner handoff
remain externally bound acceptance records; the tested ZIP is not rewritten to
insert later PASS or self-hash claims.
