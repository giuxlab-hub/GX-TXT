# SPDX-License-Identifier: GPL-3.0-or-later
rename ::GX::launchGui ::GX::launchGui_before_session_menus065
proc ::GX::launchGui {} {
    launchGui_before_session_menus065
    set bar .top.nb.sessionfiles.bar
    ttk::button $bar.projectHome -text {⌂ Project Home} -command ::GX::projectGuiCurrentHome -state disabled
    pack $bar.projectHome -side left -padx 3 -before $bar.refresh
    foreach {key title entries} {
        session Session {{{New Session...} ::GX::newSessionDialog} {{Duplicate Experiment...} ::GX::newExperimentDialog} {{Open Session...} ::GX::chooseSession} {{Session information} ::GX::showCurrentSessionInfo} {{Save configuration} ::GX::saveCurrentSessionConfig} {{Delete Session...} ::GX::resourceLifecycleSessionDialog} {{Duplication report...} ::GX::experimentDuplicationReportDialog}}
        instruments Instruments {{{Add Instrument...} ::GX::sessionInstrumentAddDialog} {{Open Library...} ::GX::instrumentLibraryOpenWindow}}
        configuration Configuration {{{Export configuration (.ini)...} ::GX::saveManifestDialog} {{Load configuration only (.ini)...} ::GX::loadManifestDialog}}
    } {
        ttk::menubutton $bar.$key -text $title -menu $bar.$key.menu
        menu $bar.$key.menu -tearoff 0
        foreach entry $entries {lassign $entry label command;$bar.$key.menu add command -label $label -command $command}
        pack $bar.$key -side left -padx 3 -before $bar.refresh
    }
    # OWNER-RESERVED MAIN STATUS BAR.
    # Do not add menus or alter this bar without explicit owner approval.
    # Reserved for authoritative Session/Project and Job/attention status.
    mainStatusBarCreate .top.sessionbar
    sessionActionGuiRefresh
    .top.nb.sessionfiles.navigation configure -values {{Session files} {Session scripts} Workspaces {Configuration / Manifest} {Session Parameters} Experiment Instrumentation {Preview Cache}}
    # Remove the notebook entry only after the established panel and Session
    # content host exist. Forget does not destroy/recreate the Experiment UI.
    .top.nb forget .top.nb.exp
    .top.nb forget .top.nb.instr
    sessionPageSelect
    updateSessionUi
}

# This state contains only widget/subscription lifetimes and presentation.
# Session, Project membership and Jobs remain with their existing CORE owners.
namespace eval ::GX::MainStatusBar {variable serial 0;variable state {};variable projectText {};variable jobsText {Jobs: unavailable};variable attentionText {}}
proc ::GX::mainStatusBarCurrent {bar epoch} {
    set state $::GX::MainStatusBar::state
    return [expr {$state ne {} && [dict get $state bar] eq $bar && [dict get $state epoch]==$epoch && [winfo exists $bar] && [winfo id $bar] eq [dict get $state incarnation]}]
}
proc ::GX::mainStatusBarChanged {bar epoch args} {
    # A presentation failure must never turn the Session/Project owner's
    # already committed variable write into an error or apparent rollback.
    if {[catch {mainStatusBarCurrent $bar $epoch} current] || !$current} return
    if {[catch {guiUpdateSchedulerRequest [dict get $::GX::MainStatusBar::state scheduler] normal} message]} {
        catch {grid remove $bar.project}
        catch {set ::GX::MainStatusBar::jobsText {Jobs: unavailable}}
        catch {set ::GX::MainStatusBar::attentionText {! Context status unavailable}}
        catch {dict set ::GX::MainStatusBar::state context_error $message}
    }
}
proc ::GX::mainStatusBarContext {} {
    set result [dict create project {} project_id {} diagnostic {}]
    if {$::GX::currentSession eq {}} {return $result}
    set project [projectCurrentId]
    # CORE defines Default / Unassigned as Sessions outside named Projects.
    if {$project eq {} || $project eq [projectDefaultId]} {return $result}
    if {[catch {
        if {![projectExists $project] || ![info exists ::GX::cfg(experiment_id)]} {error {Project association is unavailable}}
        set experiment $::GX::cfg(experiment_id)
        if {[projectMembershipField $experiment project_id] ne $project ||
            [projectMembershipField $experiment session_path] eq {} ||
            [file normalize [projectMembershipField $experiment session_path]] ne [file normalize $::GX::currentSession]} {
            error {Project association does not match the current Session}
        }
        dict set result project [projectField $project name]
        dict set result project_id $project
    } message]} {dict set result diagnostic $message}
    return $result
}
proc ::GX::mainStatusBarJobsOpen {bar epoch} {
    if {![mainStatusBarCurrent $bar $epoch]} return
    set state $::GX::MainStatusBar::state
    set summary [dict get $state summary]
    if {$summary eq {}} {
        set retry [expr {[dict get $state summary_error] ne {Job status pending}}]
    } else {
        set retry [expr {![dict get $summary local available] || ![dict get $summary remote available]}]
    }
    # Explicit user activation is the only retry. Retained Job failures do
    # not restart an otherwise healthy observation or acknowledge its alerts.
    if {$retry} {mainStatusBarJobsSubscribe $bar $epoch}
    scriptJobsDialog
}
proc ::GX::mainStatusBarJobsSubscribe {bar epoch} {
    if {![mainStatusBarCurrent $bar $epoch]} return
    set prior [dict get $::GX::MainStatusBar::state subscription]
    set generation [expr {[dict get $::GX::MainStatusBar::state summary_generation]+1}]
    # Retire the prior callback identity before closing its monitor. Even a
    # late response to this same live widget cannot replace the new snapshot.
    dict set ::GX::MainStatusBar::state summary_generation $generation
    dict set ::GX::MainStatusBar::state subscription {}
    dict set ::GX::MainStatusBar::state summary {}
    dict set ::GX::MainStatusBar::state summary_error {Job status pending}
    if {$prior ne {}} {catch {scriptJobSummaryUnsubscribe $prior}}
    set failed [catch {scriptJobSummarySubscribe $bar [list ::GX::mainStatusBarJobsChanged $bar $epoch $generation]} token]
    if {![mainStatusBarCurrent $bar $epoch] || [dict get $::GX::MainStatusBar::state summary_generation]!=$generation} {
        if {!$failed} {catch {scriptJobSummaryUnsubscribe $token}}
        return
    }
    if {$failed} {
        dict set ::GX::MainStatusBar::state summary_error {Job status unavailable}
    } else {
        dict set ::GX::MainStatusBar::state subscription $token
    }
    mainStatusBarChanged $bar $epoch
}
proc ::GX::mainStatusBarJobsChanged {bar epoch generation response} {
    if {[catch {mainStatusBarCurrent $bar $epoch} current] || !$current} return
    if {[dict get $::GX::MainStatusBar::state summary_generation]!=$generation} return
    # This is a presentation snapshot from the original trusted CORE owner,
    # never a Job registry or a source of execution/cancellation authority.
    if {[catch {
        if {![dict get $response ok]} {error {Job summary unavailable}}
        set summary [dict get $response result]
        if {[dict get $summary schema] ne {gxtxt.operational_job_summary.v1}} {error {Unknown Job summary schema}}
        dict get $summary sequence local
        dict get $summary sequence remote
        foreach route {local remote} {
            set value [dict get $summary $route]
            foreach field {available complete} {
                if {![string is boolean -strict [dict get $value $field]]} {error {Invalid Job coverage}}
            }
            if {[dict get $value available] && ![dict get $value complete]} {error {Incomplete Job coverage}}
            foreach field {running queued} {
                set count [dict get $value $field]
                if {$count eq {} && ![dict get $value available]} continue
                if {![string is entier -strict $count] || $count<0} {error {Invalid Job count}}
            }
        }
        set attention [dict get $summary attention]
        if {![string is boolean -strict [dict get $attention complete]] ||
            !![dict get $attention complete] != ([dict get $summary local available] && [dict get $summary remote available])} {error {Invalid attention coverage}}
        foreach field {failed interrupted unknown_jobs unavailable_routes lost_connections} {
            set count [dict get $attention $field]
            if {![string is entier -strict $count] || $count<0} {error {Invalid attention count}}
        }
        dict get $attention diagnostic
    }]} {
        dict set ::GX::MainStatusBar::state summary {}
        dict set ::GX::MainStatusBar::state summary_error {Job status unavailable}
    } else {
        dict set ::GX::MainStatusBar::state summary $summary
        dict set ::GX::MainStatusBar::state summary_error {}
    }
    mainStatusBarChanged $bar $epoch
}
proc ::GX::mainStatusBarJobsView {} {
    set summary [dict get $::GX::MainStatusBar::state summary]
    if {$summary eq {}} {
        set message [dict get $::GX::MainStatusBar::state summary_error]
        return [dict create routes {} text {Jobs: unavailable} attention [list $message] diagnostic $message]
    }
    set routes {}
    foreach {route label} {local Local remote Remote} {
        set value [dict get $summary $route]
        if {[dict get $value available]} {
            lappend routes "${label}: [dict get $value running] running, [dict get $value queued] queued"
        } elseif {$route eq {remote} && [dict get $value running] ne {} && [dict get $value queued] ne {} &&
                  ([dict get $value running]>0 || [dict get $value queued]>0)} {
            # An incomplete route aggregate is a confirmed subtotal. A zero
            # subtotal says nothing about unobserved Jobs and stays unknown.
            set running [expr {[dict get $value running]>0 ? "≥[dict get $value running]" : {?}}]
            set queued [expr {[dict get $value queued]>0 ? "≥[dict get $value queued]" : {?}}]
            lappend routes "${label}: $running running, $queued queued (partial)"
        } else {
            lappend routes "${label}: unavailable"
        }
    }
    set value [dict get $summary attention]
    set attention {}
    foreach {field label} {failed failed interrupted interrupted unknown_jobs {Jobs with unknown state} unavailable_routes {unavailable routes} lost_connections {lost connections}} {
        set count [dict get $value $field]
        if {$count==0} continue
        if {![dict get $value complete] && $field in {failed interrupted unknown_jobs}} {set count ≥$count}
        lappend attention "$count $label"
    }
    if {![dict get $value complete]} {lappend attention {Job coverage incomplete}}
    return [dict create routes $routes text {} attention $attention diagnostic [string range [dict get $value diagnostic] 0 511]]
}
proc ::GX::mainStatusBarRender {bar epoch} {
    if {![mainStatusBarCurrent $bar $epoch]} return
    set context [mainStatusBarContext]
    set project [dict get $context project]
    if {$project eq {}} {
        grid remove $bar.project
    } else {
        set ::GX::MainStatusBar::projectText "Project: $project"
        grid $bar.project
        native2DViewportTooltip $bar.project "$::GX::MainStatusBar::projectText\nProject ID: [dict get $context project_id]\nVerified by the current Session membership."
    }
    native2DViewportTooltip $bar.loadedSession "Session: [currentSessionDisplayName]\n$::GX::currentSession"
    set jobs [mainStatusBarJobsView]
    set routes [dict get $jobs routes]
    if {$routes eq {}} {
        set ::GX::MainStatusBar::jobsText [dict get $jobs text]
    } else {
        set font [ttk::style lookup TButton -font]
        if {$font eq {}} {set font TkDefaultFont}
        set limit [expr {max(1,[winfo width $bar]-40)}]
        set text "Jobs · [join $routes { · }]"
        if {[font measure $font $text]>$limit} {
            set lines [list "Jobs · [lindex $routes 0]" [lindex $routes 1]]
            set wrapped {}
            foreach line $lines {
                if {[font measure $font $line]>$limit} {set line [string map [list {, } \n] $line]}
                lappend wrapped $line
            }
            set text [join $wrapped \n]
        }
        set ::GX::MainStatusBar::jobsText $text
    }
    # No global dirty flag or acknowledgment is inferred from document state
    # or history hiding. These are raw ALL-row counts supplied by CORE.
    set attention [dict get $jobs attention]
    if {[dict get $context diagnostic] ne {}} {lappend attention {Project association unavailable}}
    set ::GX::MainStatusBar::attentionText [expr {$attention eq {} ? {} : "! [join $attention { · }]"}]
    native2DViewportTooltip $bar.jobs "All local Sessions and authorized remote Sessions; all operational Jobs. Running includes preparation and finalization. Partial counts are confirmed subtotals.\n[join $routes \n]\n[dict get $jobs diagnostic]\nOpen the Jobs manager; also retry the status observation if it is unavailable."
    native2DViewportTooltip $bar.attention "[join $attention { · }]\n[dict get $jobs diagnostic]\n[dict get $context diagnostic]\nRetained Job alerts are not acknowledged by hiding history."
    mainStatusBarLayout $bar [expr {$project ne {}}]
}
proc ::GX::mainStatusBarLayout {bar hasProject} {
    # Use the actual font/widget requests. Large fonts and long owner labels
    # need additional rows rather than pushing attention outside the window.
    set available [expr {max(1,[winfo width $bar])}]
    set sessionMinimum [expr {max(90,[font measure TkHeadingFont {Session alpha}])}]
    foreach widget {project attention} {$bar.$widget configure -wraplength $available}
    set contextWidth [expr {[winfo reqwidth $bar.context]+4}]
    set projectWidth [expr {$hasProject ? [winfo reqwidth $bar.project]+10 : 0}]
    set jobsWidth [expr {[winfo reqwidth $bar.jobs]+6}]
    set attentionWidth [winfo reqwidth $bar.attention]
    foreach column {0 1 2 3 4} {grid columnconfigure $bar $column -weight 0 -minsize 0}
    grid columnconfigure $bar 1 -weight 1
    foreach widget {context loadedSession project jobs attention} {grid remove $bar.$widget}
    grid $bar.context -row 0 -column 0 -columnspan 1 -sticky w -padx {0 4}
    if {$contextWidth+$sessionMinimum+10+$projectWidth+$jobsWidth+$attentionWidth <= $available} {
        grid columnconfigure $bar 1 -minsize $sessionMinimum
        grid $bar.loadedSession -row 0 -column 1 -columnspan 1 -sticky ew -padx {0 10}
        if {$hasProject} {grid $bar.project -row 0 -column 2 -columnspan 1 -sticky w -padx {0 10}}
        grid $bar.jobs -row 0 -column 3 -columnspan 1 -sticky e -padx {0 6}
        grid $bar.attention -row 0 -column 4 -columnspan 1 -sticky w
    } else {
        grid $bar.loadedSession -row 0 -column 1 -columnspan 4 -sticky ew -padx 0
        if {$projectWidth+$jobsWidth+$attentionWidth <= $available} {
            if {$hasProject} {grid $bar.project -row 1 -column 0 -columnspan 2 -sticky w -padx {0 10}}
            grid $bar.jobs -row 1 -column 2 -columnspan 1 -sticky w -padx {0 6}
            grid $bar.attention -row 1 -column 3 -columnspan 2 -sticky w
        } else {
            if {$hasProject} {grid $bar.project -row 1 -column 0 -columnspan 5 -sticky w -padx 0}
            set row [expr {$hasProject?2:1}]
            grid $bar.jobs -row $row -column 0 -columnspan 2 -sticky w -padx {0 6}
            if {$jobsWidth+$attentionWidth <= $available} {
                grid $bar.attention -row $row -column 2 -columnspan 3 -sticky w
            } else {
                grid $bar.attention -row [expr {$row+1}] -column 0 -columnspan 5 -sticky w
            }
        }
    }
}
proc ::GX::mainStatusBarDestroyed {bar epoch actual} {
    if {$actual ne $bar} return
    mainStatusBarDispose $bar $epoch
}
proc ::GX::mainStatusBarDispose {bar epoch} {
    set state $::GX::MainStatusBar::state
    if {$state eq {} || [dict get $state bar] ne $bar || [dict get $state epoch]!=$epoch} return
    set ::GX::MainStatusBar::state {}
    if {[dict get $state subscription] ne {}} {catch {scriptJobSummaryUnsubscribe [dict get $state subscription]}}
    foreach variable [dict get $state traces] {
        catch {trace remove variable $variable write [list ::GX::mainStatusBarChanged $bar $epoch]}
    }
    set tag [dict get $state tag]
    bind $tag <Destroy> {}
    bind $tag <Configure> {}
    if {[winfo exists $bar]} {bindtags $bar [lsearch -all -inline -not -exact [bindtags $bar] $tag]}
    catch {guiUpdateSchedulerDispose [dict get $state scheduler]}
}
proc ::GX::mainStatusBarCreate {bar} {
    if {$::GX::MainStatusBar::state ne {}} {
        mainStatusBarDispose [dict get $::GX::MainStatusBar::state bar] [dict get $::GX::MainStatusBar::state epoch]
    }
    set epoch [incr ::GX::MainStatusBar::serial]
    foreach widget [pack slaves $bar] {pack forget $widget}
    foreach widget [grid slaves $bar] {grid remove $widget}
    foreach widget {context loadedSession project jobs attention} {if {[winfo exists $bar.$widget]} {destroy $bar.$widget}}
    ttk::label $bar.context -text {Session:}
    ttk::label $bar.loadedSession -textvariable ::GX::ui(sessionPath) -font TkHeadingFont -anchor w -width 1
    ttk::label $bar.project -textvariable ::GX::MainStatusBar::projectText -anchor w
    ttk::button $bar.jobs -textvariable ::GX::MainStatusBar::jobsText -command [list ::GX::mainStatusBarJobsOpen $bar $epoch] -takefocus 1
    ttk::label $bar.attention -textvariable ::GX::MainStatusBar::attentionText -anchor w
    grid $bar.context -row 0 -column 0 -sticky w -padx {0 4}
    grid $bar.loadedSession -row 0 -column 1 -sticky ew -padx {0 10}
    grid $bar.project -row 0 -column 2 -sticky w -padx {0 10}
    grid $bar.jobs -row 0 -column 3 -sticky e -padx {0 6}
    grid $bar.attention -row 0 -column 4 -sticky e
    grid columnconfigure $bar 1 -weight 1 -minsize 90
    set scheduler [guiUpdateSchedulerCreate $bar [list ::GX::mainStatusBarRender $bar $epoch] {normal_ms 30 adaptive_ms 100 policy coalesced}]
    # The Project owner reloads elements with array unset ... *. Observe the
    # array so its generation notification survives those canonical reloads.
    set traces {::GX::ui(sessionPath) ::GX::ui(experimentProjectDisplay) ::GX::projectOrganization}
    set tag GXMainStatusBar:$epoch
    set ::GX::MainStatusBar::state [dict create bar $bar incarnation [winfo id $bar] epoch $epoch scheduler $scheduler traces $traces tag $tag subscription {} summary_generation 0 summary {} summary_error {Job status pending}]
    foreach variable $traces {trace add variable $variable write [list ::GX::mainStatusBarChanged $bar $epoch]}
    bindtags $bar [concat [bindtags $bar] [list $tag]]
    bind $tag <Destroy> [list ::GX::mainStatusBarDestroyed $bar $epoch %W]
    bind $tag <Configure> [list ::GX::mainStatusBarChanged $bar $epoch]
    mainStatusBarJobsSubscribe $bar $epoch
    mainStatusBarRender $bar $epoch
}
proc ::GX::sessionActionGuiRefresh {} {
    set w .top.nb.sessionfiles.bar.tools
    if {![winfo exists .top.nb.sessionfiles.bar]} return
    if {[winfo exists $w]} {destroy $w}
    set actions [sessionActionProviderList]
    ttk::menubutton $w -text Tools -menu $w.menu;menu $w.menu -tearoff 0
    $w.menu add command -label {Export Session...} -command ::GX::sessionPortableGuiExport
    $w.menu add command -label {Import Session...} -command ::GX::sessionPortableGuiImport
    if {[llength $actions]} {$w.menu add separator}
    foreach action $actions {$w.menu add command -label [dict get $action name] -command [list ::GX::sessionActionGuiInvoke [dict get $action module_id] [dict get $action action_id]]}
    pack $w -side left -padx 3 -before .top.nb.sessionfiles.bar.refresh
}

# Accessible completion diagnostics: no modal acknowledgement or approval flow.
proc ::GX::experimentDuplicationReportDialog {} {
    set path [file join $::GX::currentSession metadata experiment_preparation.txt]
    if {![file isfile $path]} {setStatus {This Session has no duplication report.};return}
    set w .gxDuplicationReport;catch {destroy $w};toplevel $w;wm title $w {Experiment duplication report}
    text $w.text -wrap word -width 100 -height 28
    ttk::scrollbar $w.scroll -command [list $w.text yview];$w.text configure -yscrollcommand [list $w.scroll set]
    set ch [open $path r];fconfigure $ch -encoding utf-8;try {$w.text insert end [read $ch]} finally {close $ch}
    $w.text configure -state disabled
    pack $w.scroll -side right -fill y;pack $w.text -fill both -expand 1
    bind $w <Escape> [list destroy $w]
}
