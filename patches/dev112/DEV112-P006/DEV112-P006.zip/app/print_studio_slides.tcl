# SPDX-License-Identifier: GPL-3.0-or-later
# Slides are an ordered mode of the existing Print Document and its editor.
proc ::GX::printStudioIsSlides {} {
    return [expr {[info exists ::GX::PrintStudio::state(recipe)] && [datasetPublicationV2DictDefault [dict get $::GX::PrintStudio::state(recipe) page] layout_mode grid] eq {slides}}]
}
proc ::GX::printStudioSlideControlsLayout {frame} {
    if {![winfo exists $frame]} return
    set layout [uiFieldControlsLayout $frame [winfo width $frame]]
    grid propagate $frame 0
    if {[$frame cget -height]!=[dict get $layout height]} {$frame configure -height [dict get $layout height]}
}
proc ::GX::printStudioSlideCurrent {} {
    variable ::GX::PrintStudio::state
    if {![printStudioIsSlides]} {error {Choose New Slides deck first.}}
    return [lindex [dict get $state(recipe) slides] [expr {$state(currentPage)-1}]]
}
proc ::GX::printStudioSlideOwn {item} {
    if {[printStudioIsSlides]} {dict set item slide_id [dict get [printStudioSlideCurrent] id]}
    return $item
}
proc ::GX::printStudioSlideEdit {operation {options {}}} {
    variable ::GX::PrintStudio::state
    printStudioDocumentSession
    set slide [printStudioSlideCurrent];set id [dict get $slide id]
    if {$operation in {earlier later}} {
        set position [expr {$state(currentPage)+($operation eq {earlier} ? -1 : 1)}]
        if {$position<1 || $position>[llength [dict get $state(recipe) slides]]} return
        set operation move;set options [dict create position $position]
    }
    set edit [printRecipeSlideEdit $state(recipe) $operation $id $options]
    set ids {};foreach slide [dict get $edit recipe slides] {lappend ids [dict get $slide id]}
    set state(currentPage) [expr {1+[lsearch -exact $ids [dict get $edit selected_slide_id]]}]
    set state(posterSelection) {}
    printStudioEdit [dict get $edit recipe] "Slide $operation"
    printStudioSlidesRefresh
    printStudioPageShow
}
proc ::GX::printStudioSlideProperties {} {
    variable ::GX::PrintStudio::state
    set slide [printStudioSlideCurrent]
    set state(slidePropertyId) [dict get $slide id]
    set state(slidePropertyRevision) $state(revision)
    set state(slidePropertyToken) [interactiveDocumentSessionToken]
    set fields [dict create title {type string label {Slide title}} background {type color label {Slide background}}]
    uiFieldFormCreate .gxPrintSlideProperties {Slide properties} $fields $slide ::GX::printStudioSlidePropertiesApply .
}
proc ::GX::printStudioSlidePropertiesApply {values} {
    variable ::GX::PrintStudio::state
    if {$state(revision)!=$state(slidePropertyRevision) || [interactiveDocumentSessionToken] ne $state(slidePropertyToken) || [dict get [printStudioSlideCurrent] id] ne $state(slidePropertyId)} {error {The slide or Session changed; reopen its properties.}}
    printStudioSlideEdit update [dict create title [dict get $values title] background [dict get $values background]]
    set state(slidePropertyRevision) $state(revision)
}
proc ::GX::printStudioSlidesRefresh {} {
    variable ::GX::PrintStudio::state;variable ui
    if {![printStudioIsSlides]} return
    set slides [dict get $state(recipe) slides]
    set state(pageCount) [llength $slides]
    set state(currentPage) [expr {max(1,min($state(pageCount),$state(currentPage)))}]
    if {![info exists ui(printPages)] || ![winfo exists $ui(printPages)]} return
    set tree $ui(printPages);set n 0;set existing [$tree children {}];set wanted {}
    ttk::style configure PrintSlides.Treeview -rowheight 34
    $tree configure -style PrintSlides.Treeview
    $tree column #0 -width 160 -minwidth 90 -stretch 1
    foreach slide $slides {lappend wanted page:[incr n]}
    if {$existing ne $wanted} {$tree delete $existing;foreach id $wanted {$tree insert {} end -id $id}}
    set n 0
    foreach slide $slides {
        incr n
        $tree item page:$n -text "$n. [dict get $slide title]" -image {}
    }
    if {[$tree selection] ne [list page:$state(currentPage)]} {$tree selection set page:$state(currentPage)}
    $tree see page:$state(currentPage)
    $ui(printPageNumber) configure -to $state(pageCount)
}
proc ::GX::printStudioQueueRefreshForSlide {} {
    variable ::GX::PrintStudio::state
    if {![info exists state(queueSlidePage)] || $state(queueSlidePage)!=$state(currentPage)} {
        set state(posterSelection) {};printStudioQueueRefresh
    }
}
proc ::GX::printStudioObjectNudge {dx dy {resize 0}} {
    variable ::GX::PrintStudio::state
    if {![printStudioIsPoster] || $state(posterSelection) eq {}} return
    printStudioDocumentSession
    set item [printStudioPosterItem $state(posterSelection)]
    foreach key [expr {$resize ? {width_mm height_mm} : {x_mm y_mm}}] amount [list $dx $dy] {
        dict set item frame $key [expr {[dict get $item frame $key]+$amount}]
    }
    if {[catch {printStudioPosterReplace $state(posterSelection) $item {Keyboard object layout changed}} message]} {set ::GX::ui(printStatus) $message}
}
