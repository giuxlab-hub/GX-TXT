# C++ native Workspace example

This is the complete author input for `viewer.p006_oo_native_example` 1.0.1:
eleven editable project files, the unchanged normal exported package, and the
unchanged plain-source archive. It demonstrates used C++ headers/classes and
native Jobs owned by the existing Supervisor. It adds no executor, persistent
Job queue, source allowlist or runtime registration.

Import `SOURCE_PROJECT_1.0.1_5a6abbdc2a9999ca.zip` into a new Viewer Development
Workspace outside the framework installation. Alternatively copy `project/`
outside the installation and open its `project.json`. Inspect
[the original manual](project/MANUAL.md), then use the ordinary
Validate/Build/Test/Export workflow with the intended framework and toolchain.
The plain-source archive is not an installable module package.

`packages/viewer.p006_oo_native_example_1.0.1.zip` is the exact supplied author
package. Any installation and enabling must use the normal Plugin Manager and
Modules controls. This directory does not install, enable or activate anything.
Do not edit an installed module or adopt older Jobs by changing their recorded
project/version identities. The separately prepared remote 1.0.2 fixture remains
a different module and evidence context.

| Source | Role |
| --- | --- |
| `handlers.cpp`, `src/controller.cpp`, `include/controller.hpp` | Two compiled GUI units and a used controller header; per-View presentation records keyed by accepted Job IDs |
| `jobs/analyze.cpp`, `jobs/workload.cpp`, `jobs/workload.hpp` | Registered class-backed native task and used workload class/header |
| `jobs/long.cpp` | Native success, requested failure and cancellation fixture |
| `jobs/typed.cpp` | Fixed original-dtype edge-value fixture |

The typed worker expects the documented five genuine Workspace Document refs
and their specific edge values. It uses unchecked `front`, `back` and indexed
accesses: the source predicates require at least two `i16` values, one `u16`, one
`i64`, three `u64`, and four `f32` values. These are source-derived fixture
preconditions, not new runtime guards. Do not treat this unchanged fixture as a
general arbitrary-array processor or as proof of short-array refusal. Original
dtype, shape and authority checks still belong to the existing owners.

The pinned final-package author run records three **long** Jobs reaching
COMPLETED, CANCELLED and FAILED, physical UI action after native starts/progress,
independent selected-ID panels, and separate-process cold reconnect with retained
result `328350` and unchanged Job/attempt/result snapshots. Cancellation has no
fabricated native-exit record. Class result `165`/checksum `133` and mapped-header
evidence belong to the qualified same-version predecessor. Earlier typed/raw-byte
evidence belongs to version 1.0.0. Neither establishes a whole-final-package
class/typed runtime run. The INTERRUPTED replay check is synthetic.

Two-View/instance behavior, active-View disposal, strict responsiveness, remote
execution, independent frozen W01/C gates and release acceptance remain pending
in this delivery. Historical author receipts are pinned by
`SOURCE_PROVENANCE.json`; they are not rewritten or promoted to independent
qualification. Later author tests require their own exact receipts and scope.

The two archive `.sha256` files support ordinary `sha256sum -c` verification;
check the package checksum from `packages/`. `SOURCE_PROVENANCE.json` records
every copied source hash, native artifact identity and mode distinction. The
plain-source design has mode 0664 while its packaged copy has mode 0644; Git
records regular files as 100644 and does not preserve group-write permission.
All source and archive bytes remain exact. The three native task executables
retain their predecessor bytes; the GUI shared library is newly built.
