#include "gxtxt_native_job_v1.hpp"
#include "workload.hpp"
gx::native_job::Result analyze(gx::native_job::Context& context) {
    const auto count=context.integer("count");
    const auto scale=context.integer("scale");
    context.progress(0.15,"native main validated parameters");
    const BoundedWorkload workload(scale);
    const WorkloadMetrics metrics=workload.evaluate(count);
    context.progress(0.85,"separate workload class completed");
    return {{"count",count},{"scale",scale},{"scaled_square_sum",metrics.scaled_square_sum},{"checksum",metrics.checksum}};
}
GXTXT_NATIVE_JOB_MAIN(analyze)
