#include "gxtxt_native_job_v1.hpp"
#include <chrono>
#include <thread>
gx::native_job::Result long_task(gx::native_job::Context& c){
    auto rounds=c.integer("rounds");auto seed=c.integer("seed");auto seconds=c.number("seconds");
    std::int64_t sum=0;for(std::int64_t i=0;i<rounds;++i)sum+=i*i;
    for(int i=0;i<40;++i){c.progress(double(i)/40,"native supervised compute");std::this_thread::sleep_for(std::chrono::milliseconds(int(seconds*25)));}
    if(c.flag("fail"))throw std::runtime_error("requested native failure");
    c.progress(1,"native complete");return {{"seed",seed},{"sum_squares",sum},{"rounds",rounds}};
}
GXTXT_NATIVE_JOB_MAIN(long_task)
