#include "gxtxt_native_job_v1.hpp"
gx::native_job::Result analyze(gx::native_job::Context& c){
    auto s=c.buffer("i16").values<std::int16_t>();auto u=c.buffer("u16").values<std::uint16_t>();
    auto f=c.buffer("f32").values<float>();auto wide=c.buffer("u64").values<std::uint64_t>();
    auto exact=c.buffer("i64").values<std::int64_t>();
    if(s.front()!=-32768||s.back()!=32767||u.back()!=65535||wide[1]!=9007199254740993ULL||wide.back()!=std::numeric_limits<std::uint64_t>::max()||exact.front()!=std::numeric_limits<std::int64_t>::min()||!std::isnan(f[2])||!std::isinf(f[3]))throw std::runtime_error("Native original-dtype input failed");
    c.progress(0.5,"native original-dtype identity");
    return {{"i16",c.publish_buffer(c.buffer("i16"),s)},{"u16",c.publish_buffer(c.buffer("u16"),u)},
            {"f32",c.publish_buffer(c.buffer("f32"))},{"u64",c.publish_buffer(c.buffer("u64"),wide)},
            {"i64",c.publish_buffer(c.buffer("i64"),exact)},{"typed_checks",true}};
}
GXTXT_NATIVE_JOB_MAIN(analyze)
