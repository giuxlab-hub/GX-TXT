#pragma once
#include <cstdint>
struct WorkloadMetrics {
    std::int64_t scaled_square_sum;
    std::int64_t checksum;
};
class BoundedWorkload final {
    std::int64_t scale_;
public:
    explicit BoundedWorkload(std::int64_t scale);
    WorkloadMetrics evaluate(std::int64_t count) const;
};
