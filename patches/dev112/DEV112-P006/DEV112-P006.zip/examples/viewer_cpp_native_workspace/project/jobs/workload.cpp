#include "workload.hpp"
#include <stdexcept>
BoundedWorkload::BoundedWorkload(std::int64_t scale):scale_(scale) {
    if(scale_<1 || scale_>7)throw std::runtime_error("bounded scale outside fixture domain");
}
WorkloadMetrics BoundedWorkload::evaluate(std::int64_t count) const {
    if(count<1 || count>64)throw std::runtime_error("bounded count outside fixture domain");
    WorkloadMetrics result{0,0};
    for(std::int64_t i=0;i<count;++i) {
        result.scaled_square_sum+=scale_*i*i;
        result.checksum+=(i+1)*(i+scale_);
    }
    return result;
}
