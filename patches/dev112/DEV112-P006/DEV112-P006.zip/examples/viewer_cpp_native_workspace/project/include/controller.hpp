#pragma once
#include <stdexcept>
struct JobPresentation final {
    std::string id, state, node, stage, diagnostic, summary;
    double fraction = 0;
    std::int64_t sequence = 0;
    bool result_requested = false, has_result = false;
    gx::WorkspaceValue result;
};
struct ViewPresentation final {
    std::map<std::string, JobPresentation> jobs;
    std::vector<std::string> order;
    std::string selected;
};
class JobController final {
    const gx::Host& host_;
    gx::State& state_;
    static unsigned next_token_;
    static std::map<unsigned, ViewPresentation> views_;
    ViewPresentation& model();
    JobPresentation& record(const std::string& id);
    void render();
    void request_result(const std::string& id, bool force = false);
public:
    JobController(const gx::Host& host, gx::State& state);
    void open();
    void close();
    void select(unsigned slot);
    void submit_long(bool fail);
    void submit_class(std::int64_t count, std::int64_t scale);
    void submit_typed();
    void lifecycle(const char* action, const char* id);
    void selected_lifecycle(const char* action);
    void consume();
};
