#include "controller.hpp"
namespace {
const gx::WorkspaceValue* field(const gx::WorkspaceValue& object,const char* key){auto i=object.fields.find(key);return i==object.fields.end()?nullptr:&i->second;}
bool text_is(const gx::WorkspaceValue* value,const char* expected){return value&&value->kind==gx::WorkspaceValue::Kind::text&&value->text==expected;}
bool terminal(const std::string& state){return state=="COMPLETED"||state=="FAILED"||state=="CANCELLED"||state=="INTERRUPTED";}
std::string text(const gx::WorkspaceValue* value){return value&&value->kind==gx::WorkspaceValue::Kind::text?value->text:std::string();}
}
unsigned JobController::next_token_=1;
std::map<unsigned,ViewPresentation> JobController::views_;
JobController::JobController(const gx::Host& host,gx::State& state):host_(host),state_(state){}
ViewPresentation& JobController::model(){
 const unsigned token=static_cast<unsigned>(state_.values[14]);
 auto i=views_.find(token);if(token==0||i==views_.end())throw std::runtime_error("This View has no active presentation lifetime; reopen it");return i->second;
}
JobPresentation& JobController::record(const std::string& id){
 auto& view=model();auto i=view.jobs.find(id);
 if(i==view.jobs.end()){JobPresentation item;item.id=id;i=view.jobs.emplace(id,item).first;view.order.push_back(id);}
 state_.values[13]=double(view.jobs.size());return i->second;
}
void JobController::open(){
 if(next_token_==0)throw std::runtime_error("Presentation lifetime counter exhausted; reopen the process");
 const unsigned token=next_token_++;state_.values[14]=double(token);views_.emplace(token,ViewPresentation());
 host_.text(1,"No retained Job selected");host_.text(2,"Submit native work or reconnect an accepted retained Job ID");host_.text(5,"Failure panel follows actual FAILED Job IDs");host_.text(13,"Choose explicit local or a configured logical Node");
 for(unsigned i=0;i<3;++i)host_.text(23+i,(std::string("Job ")+std::to_string(i+1)+": no accepted ID").c_str());
 host_.text(29,"No selected retained result");state_.values[13]=0;
}
void JobController::close(){const unsigned token=static_cast<unsigned>(state_.values[14]);views_.erase(token);state_.values[14]=0;}
void JobController::render(){
 auto& view=model();
 for(unsigned i=0;i<3&&i<view.order.size();++i){const auto& row=view.jobs.at(view.order[i]);std::string line="Job "+std::to_string(i+1)+": "+row.id+" | "+row.state+" | "+row.summary;if(!row.diagnostic.empty())line+=" | "+row.diagnostic;host_.text(23+i,line.c_str());}
 auto found=view.jobs.find(view.selected);if(found==view.jobs.end())return;const auto& row=found->second;
 host_.text(1,row.id.c_str());host_.text(2,(row.stage.empty()?row.state:row.stage).c_str());host_.text(13,("Observed Node: "+row.node+" / "+row.state).c_str());host_.number(15,row.fraction*100);
 std::string line=row.id+" | "+row.state+" | "+row.summary;if(!row.diagnostic.empty())line+=" | "+row.diagnostic;host_.text(29,line.c_str());
}
void JobController::select(unsigned slot){auto& view=model();if(slot>=view.order.size()){host_.text(2,"This slot has no accepted Job");return;}view.selected=view.order[slot];render();}
void JobController::lifecycle(const char* action,const char* id){if(!id||!*id){host_.text(2,"Enter the full accepted retained Job ID");return;}host_.native_job(action,gx::workspace_object({{"job_id",gx::workspace_text(id)}}));}
void JobController::selected_lifecycle(const char* action){auto& view=model();if(view.selected.empty()){host_.text(2,"Select an accepted Job slot or reconnect its full ID first");return;}lifecycle(action,view.selected.c_str());}
void JobController::submit_long(bool fail){
 const std::string node=host_.input(12);if(node.empty()){host_.text(2,"Select a registered logical Node");return;}
 host_.native_job("submit",gx::workspace_object({{"entrypoint",gx::workspace_text("long")},{"parameters",gx::workspace_object({{"seed",gx::workspace_integer(fail?99:17)},{"rounds",gx::workspace_integer(100)},{"seconds",gx::workspace_number(std::stod(host_.input(14)))},{"fail",gx::workspace_flag(fail)}})},{"options",gx::workspace_object({{"node_id",gx::workspace_text(node)}})}}));
}
void JobController::submit_class(std::int64_t count,std::int64_t scale){
 host_.native_job("submit",gx::workspace_object({{"entrypoint",gx::workspace_text("analyze")},{"parameters",gx::workspace_object({{"count",gx::workspace_integer(count)},{"scale",gx::workspace_integer(scale)}})},{"options",gx::workspace_object({{"node_id",gx::workspace_text(host_.input(12))}})}}));
}
void JobController::submit_typed(){
 const auto resources=host_.workspace().property("typed_resources");const auto guard=host_.workspace().property("source_guard");
 if(resources.kind!=gx::WorkspaceValue::Kind::object||resources.fields.size()!=5||guard.kind!=gx::WorkspaceValue::Kind::object){host_.text(2,"Open a normal Workspace with canonical typed resources/source guard");return;}
 host_.native_job("submit",gx::workspace_object({{"entrypoint",gx::workspace_text("typed")},{"parameters",gx::workspace_object()},{"options",gx::workspace_object({{"node_id",gx::workspace_text(host_.input(12))},{"source_guard",guard}})},{"resources",resources}}));
}
void JobController::request_result(const std::string& id,bool force){auto& row=record(id);if(force||!row.result_requested){row.result_requested=true;lifecycle("result",id.c_str());}}
void JobController::consume(){
 const auto* root=host_.native_job_result();if(!root)return;const auto* action=field(*root,"action");const auto* receipt=field(*root,"receipt");if(!action||!receipt)return;
 const std::string id=text(field(*receipt,"job_id"));const auto* status=field(*receipt,"state");if(text_is(status,"PENDING"))return;
 const auto* error=field(*receipt,"error");const bool terminal_diagnostic=!id.empty()&&(text_is(status,"CANCELLED")||text_is(status,"FAILED")||text_is(status,"INTERRUPTED"));
 if(error&&!error->text.empty()&&!terminal_diagnostic){state_.values[15]+=1;host_.text(2,error->text.c_str());return;}
 if(id.empty())return;auto& row=record(id);auto& view=model();
 if(terminal_diagnostic&&error&&!error->text.empty())row.diagnostic=error->text;
 if(text_is(field(*receipt,"event"),"transport_error")){row.diagnostic=text(field(*receipt,"diagnostic"));if(view.selected.empty())view.selected=id;render();return;}
 const auto* sequence=field(*receipt,"sequence");if(sequence&&sequence->kind==gx::WorkspaceValue::Kind::integer){if(sequence->integer<row.sequence)return;row.sequence=sequence->integer;}
 const bool historical_active=terminal(row.state)&&status&&!terminal(status->text);
 if(!historical_active){
 if(status&&!(action->text=="submit"&&row.sequence>0))row.state=status->text;
 const auto node=text(field(*receipt,"node_id"));if(!node.empty())row.node=node;
 const auto stage=text(field(*receipt,"stage"));if(!stage.empty())row.stage=stage;
 const auto diagnostic=text(field(*receipt,"diagnostic"));if(!diagnostic.empty())row.diagnostic=diagnostic;
 const auto* progress=field(*receipt,"progress");const auto* fraction=progress?field(*progress,"fraction"):nullptr;
 if(fraction){if(fraction->kind==gx::WorkspaceValue::Kind::real)row.fraction=fraction->real;else if(fraction->kind==gx::WorkspaceValue::Kind::integer)row.fraction=double(fraction->integer);}
 }
 if(view.selected.empty()||action->text=="submit"||action->text=="reconnect")view.selected=id;
 if(action->text=="reconnect"){state_.values[12]+=1;if(row.state=="COMPLETED")request_result(id,true);}
 if(action->text=="result"){
  const auto* result=field(*receipt,"result");if(result){row.result=*result;row.has_result=true;
   if(const auto* sum=field(*result,"scaled_square_sum")){const auto* checksum=field(*result,"checksum");if(!checksum)throw std::runtime_error("Class native result lacks checksum");row.summary="class sum="+std::to_string(sum->integer)+" checksum="+std::to_string(checksum->integer);host_.number(20,double(sum->integer));host_.number(21,double(checksum->integer));state_.values[2]+=1;}
   else if(const auto* typed=field(*result,"typed_checks")){bool valid=typed->kind==gx::WorkspaceValue::Kind::boolean&&typed->integer==1;const char* aliases[]={"i16","u16","f32","u64","i64"};const char* dtypes[]={"int16","uint16","float32","uint64","int64"};for(unsigned i=0;i<5;++i){const auto* buffer=field(*result,aliases[i]);const auto* descriptor=buffer?field(*buffer,"descriptor"):nullptr;valid=valid&&buffer&&text_is(field(*buffer,"schema"),"gxtxt.viewer_bridge_buffer.v1")&&descriptor&&text_is(field(*descriptor,"dtype"),dtypes[i]);}if(!valid)throw std::runtime_error("Native typed resource result contract failed");row.summary="five original-dtype resource wrappers retained";state_.values[3]+=1;}
   else if(const auto* sum=field(*result,"sum_squares")){if(sum->integer!=328350)throw std::runtime_error("Native long result contract failed");row.summary="sum_squares="+std::to_string(sum->integer);state_.values[9]+=1;}
  }
 }
 if(action->text=="event"){
  state_.values[11]+=1;
  if(row.state=="RUNNING")state_.values[1]=1;
  if(row.state=="FAILED"){state_.values[7]=1;host_.text(5,id.c_str());}
  if(row.state=="CANCELLED")state_.values[8]=1;
  if(row.state=="COMPLETED"){state_.values[5]=1;request_result(id);}
 }
 render();
}
