#include "controller.hpp"
#include <stdexcept>
namespace {
struct ClassParameters {std::int64_t count;std::int64_t scale;};
ClassParameters class_parameters(const gx::Host& host){const auto count=std::stoll(host.input(18));const auto scale=std::stoll(host.input(19));if(count<1||count>64||scale<1||scale>7)throw std::runtime_error("Class workload parameters outside declared domain");return {count,scale};}
}
void on_event(gx::Host& host,gx::State& state,const gx::Event& event){
 ++state.counter;JobController controller(host,state);
 if(event.kind==gx::EventKind::open){controller.open();return;}
 if(event.kind==gx::EventKind::close){controller.close();return;}
 if(event.component==4){controller.submit_long(false);return;}
 if(event.component==6){controller.submit_long(true);return;}
 if(event.component==7){controller.selected_lifecycle("cancel");return;}
 if(event.component==8){state.values[10]+=1;host.text(2,"Object-oriented GUI action serviced");return;}
 if(event.component==10){controller.lifecycle("reconnect",host.input(9));return;}
 if(event.component==11){controller.selected_lifecycle("result");return;}
 if(event.component==16){const auto parameters=class_parameters(host);controller.submit_class(parameters.count,parameters.scale);return;}
 if(event.component==17){controller.submit_typed();return;}
 if(event.component>=26&&event.component<=28){controller.select(event.component-26);return;}
 controller.consume();
}
