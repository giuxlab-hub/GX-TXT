// SPDX-License-Identifier: GPL-3.0-or-later
#include "observatory.hpp"
#include <cstdio>
#include <stdexcept>

namespace observatory {
const Value& field(const Value& value, const char* key) {
    static const Value empty;
    if (value.kind != Value::Kind::object && value.kind != Value::Kind::resource) return empty;
    const auto found = value.fields.find(key);
    return found == value.fields.end() ? empty : found->second;
}
std::string text(const Value& value, const std::string& key) {
    const auto& child = field(value, key.c_str());
    return child.kind == Value::Kind::text ? child.text : std::string();
}
std::string scalar(const Value& value) {
    if (value.kind == Value::Kind::text) return value.text;
    if (value.kind == Value::Kind::integer) return std::to_string(value.integer);
    if (value.kind == Value::Kind::boolean) return value.integer ? "true" : "false";
    if (value.kind == Value::Kind::real) {
        char out[64];std::snprintf(out,sizeof(out),"%.17g",value.real);return out;
    }
    return value.kind == Value::Kind::null ? "unavailable" : "[typed structure]";
}
namespace {
std::string quote(const std::string& value) {
    std::string out="\"";const char digits[]="0123456789abcdef";
    for (const unsigned char c : value) {
        if (c == '"' || c == '\\') {out += '\\';out += c;}
        else if (c < 32) {out += "\\u00";out += digits[c >> 4];out += digits[c & 15];}
        else out += c;
    }
    return out + '"';
}
}
std::string json(const Value& value) {
    if (value.kind == Value::Kind::null) return "null";
    if (value.kind == Value::Kind::text) return quote(value.text);
    if (value.kind == Value::Kind::integer || value.kind == Value::Kind::real || value.kind == Value::Kind::boolean) return scalar(value);
    std::string out;bool first=true;
    if (value.kind == Value::Kind::array) {
        out="[";
        for (const auto& child : value.elements) {if(!first)out+=',';first=false;out+=json(child);}
        return out+"]";
    }
    out="{";
    for (const auto& child : value.fields) {if(!first)out+=',';first=false;out+=quote(child.first)+":"+json(child.second);}
    return out+"}";
}
void report(gx::Host& host, unsigned component, const std::string& content) {
    const std::string bounded=content.size()>28000 ? content.substr(0,28000)+"\nDisplay bounded; typed receipt retains authority." : content;
    const auto runs=gx::workspace_object({{"replace",gx::workspace_flag(true)},
        {"autoscroll",gx::workspace_flag(false)},
        {"runs",gx::workspace_array({gx::workspace_object({{"text",gx::workspace_text(bounded)},
            {"style",gx::workspace_text("normal")}})})}});
    const auto encoded=json(runs);host.text_runs(component,encoded.c_str());
}
void status(gx::Host& host,const std::string& message) {
    host.text(GlobalStatus,message.substr(0,250).c_str());
    host.text(EventStatus,message.substr(0,250).c_str());
}
Application& application() {static Application instance;return instance;}

void Application::dispatch(gx::Host& host,const gx::Event& event) {
    Value completed;
    if (bridge.receive(host,source,completed)) {
        numeric.accept(host,completed,source);plot.accept(host,completed);
    }
    if (event.kind == gx::EventKind::open) {
        status(host,numeric.latest.kind==Value::Kind::object?
            "Saved analysis restored. Inspect the retained Plot; bind the source for a new analysis.":
            "Select a Dataset and bind its original scientific identity.");
        bridge.describe(host);numeric.present(host);plot.present(host);
        report(host,ProjectReport,"One ordinary C++ Viewer project; five compiled translation units.\n"
            "Bundled Python and Octave use public Numeric, Dataset Publication and Plot Dataset v4.\n"
            "Save a Workspace after completion. On cold reopen, reconnect retained Job IDs explicitly.");
        return;
    }
    if (event.kind == gx::EventKind::close) return;
    if (event.kind != gx::EventKind::invoke && event.kind != gx::EventKind::changed && event.kind != gx::EventKind::selection) return;
    switch (event.component) {
    case BindSource:
        source.select(host);numeric.clear();plot.reference=Value();plot.derived_dataset.clear();
        bridge.call(host,"CANONICAL_DATASET_API_v2","describe",gx::workspace_array({gx::workspace_text(source.dataset_id)}));
        bridge.call(host,"CURVE_SOURCE_API_v1","dataset_identity",gx::workspace_array({gx::workspace_text(source.dataset_id)}));
        bridge.call(host,"DATASET_NAMESPACE_API_v1","get",gx::workspace_array({gx::workspace_text(source.dataset_id)}));
        break;
    case DiscoverBridge:bridge.discover(host);break;
    case RequireBridge:bridge.require(host);break;
    case SubmitAnalysis:bridge.submit(host,source,false);break;
    case SubmitSmoke:bridge.submit(host,source,true);break;
    case JobStatus:bridge.command(host,"status");break;
    case JobCancel:bridge.command(host,"cancel");break;
    case JobResult:bridge.command(host,"result");break;
    case JobReconnect:bridge.command(host,"reconnect");break;
    case PlotInspect:plot.invoke(host,bridge,"read_plot");break;
    case PlotRerender:plot.invoke(host,bridge,"rerender");break;
    case PlotDiscover:host.plot_discover(PlotForm);break;
    case PlotBind:host.plot_bind(PlotView,PlotForm);break;
    case WorkspaceSave:{
        const std::string name=host.input(WorkspaceName);
        host.workspace().set_property("observatory",capture());
        host.workspace().save_as(name.empty()?"Bridge Observatory analysis":name);break;
    }
    case WorkspaceOpen:{
        const std::string id=host.input(WorkspaceId);
        if(id.empty())throw std::runtime_error("Enter an existing Workspace ID before opening it.");
        host.workspace().open(id);break;
    }
    case WorkspaceList:{
        std::string out="Saved analyses in the current Session:\n";
        for(const auto& entry:host.workspace().query())out+=entry.id+" | "+entry.name+" | revision "+std::to_string(entry.revision)+"\n";
        report(host,ProjectReport,out);break;
    }
    default:break;
    }
}
Value Application::capture() const {
    return gx::workspace_object({{"schema",gx::workspace_text("gxtxt.observatory.state.v1")},
        {"source",source.capture()},{"jobs",bridge.capture()},{"result",numeric.latest},{"plot",plot.capture()}});
}
void Application::restore(const Value& state) {
    if(text(state,"schema")!="gxtxt.observatory.state.v1")throw std::runtime_error("Unsupported Observatory Workspace state.");
    SourceBinding restored_source;restored_source.restore(field(state,"source"));
    BridgeJobs restored_jobs;restored_jobs.restore(field(state,"jobs"));
    PlotPublication restored_plot;restored_plot.restore(field(state,"plot"));
    source=restored_source;bridge=restored_jobs;plot=restored_plot;numeric.latest=field(state,"result");
}
}
void on_event(gx::Host& host,gx::State& state,const gx::Event& event) {
    try {observatory::application().dispatch(host,event);++state.counter;}
    catch(const std::exception& error) {
        observatory::application().last_error=error.what();
        observatory::status(host,std::string("Action refused: ")+error.what());
        observatory::report(host,observatory::JobReport,std::string("The action did not complete.\n")+error.what());
    }
}
namespace gx {
WorkspaceValue on_workspace_capture(){return observatory::application().capture();}
void on_workspace_validate(const WorkspaceValue& state){observatory::Application candidate;candidate.restore(state);}
void on_workspace_restore(const WorkspaceValue& state){observatory::application().restore(state);}
}
