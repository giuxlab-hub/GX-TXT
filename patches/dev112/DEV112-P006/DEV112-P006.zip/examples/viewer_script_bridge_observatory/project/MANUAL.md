# Script Bridge Observatory

This Viewer binds a canonical Dataset, analyzes its original Y values through
public Numeric, publishes a canonical histogram Dataset, and registers a
persistent Plot Dataset v4 graph. Its ordinary project contains five C++
translation units and bundled Python and Octave entrypoints.

Install this single ZIP through Plugin Manager, enable Script Bridge Observatory
through the normal Modules controls, and open its Viewer. Both language
entrypoints are included; no separate Script Library project is required.
To edit the project, use **File → Import project package** in Viewer Development
Workspace. Its five C++ units, headers, Builder design, scripts and parameter
declarations remain editable together. Build and export a changed version there,
then promote it through Plugin Manager.

Open a Session containing a rank-one numerical table. In **Dataset & Variables**,
select the Dataset and enter its stable X and Y Variable IDs. The complete source
must contain 1–65,536 rows. Select **Bind source identity** to review the original
payload SHA, scientific schema identity and physical Y unit. Changing a source
or Variable selection requires binding it again.

In **Bridge & Jobs**, select **Discover registered APIs** and **Check scientific
providers**. These use the same registered Script Bridge operations as ordinary
Python/Octave clients. Select a language and **Analyze and publish**. An initial
submission identity means admission is pending; the managed Job report displays
the authoritative Job ID when the Supervisor accepts the work. Keep that ID to
inspect, cancel or reconnect a retained Job. Ordinary progress and terminal
updates arrive through managed events.
Progress fractions describe completed workflow stages; they do not predict elapsed
time or an estimated completion time.

**Other-language smoke** executes the bundled entrypoint in the other language
against the same original source, without publishing another Dataset or Plot.
The full workflow uses mean, descriptive population standard deviation and an
eight-bin bounded histogram. Nonfinite values are excluded and counted by the
Numeric contract. A source with no finite samples is refused. The histogram
domain spans the finite source minimum and maximum; a constant source uses an
explicit one-unit presentation span starting at its constant value.

Review **Numeric Results** for the actual provider facts and original source
identity. The derived Dataset stores original-dtype `uint64` counts and physical
bin centers, together with source lineage, mean, population SD and units. This
Viewer does not infer a standard error, uncertainty, calibration or probability
distribution from descriptive statistics.

**Persistent Plot** shows the registered graph reference. The same graph is
discoverable in the main GX-TXT Plots browser. **Inspect persistent graph** reads
its retained definition; **Rerender retained graph** renders that definition
without rerunning analysis. For consultation inside the Viewer, select the
derived Dataset, discover its variables, choose `bin_center` and `count`, and
select **Show canonical graph**.

In **Project & Reopen**, save the analysis through the existing Workspace owner.
Keep the returned Workspace ID. Close the Viewer and Session, then reopen that
Session and Workspace. Recorded Numeric facts and the persistent Plot reference
remain available. A retained Job requires explicit guarded reconnect; saved
receipts grant no authority to a different Session, changed source or updated
package. A new analysis needs a fresh source binding and an unused derived
Dataset ID.

The supported population-summary dtypes are original `uint8`, `uint16`, `int16`,
`float32` and `float64`. Other dtypes, multidimensional flattening, missing
Variables, changed source/schema, foreign ownership, undeclared entrypoints,
missing providers and cancelled work refuse explicitly. No scientific result is
substituted with a screenshot or a display buffer.
