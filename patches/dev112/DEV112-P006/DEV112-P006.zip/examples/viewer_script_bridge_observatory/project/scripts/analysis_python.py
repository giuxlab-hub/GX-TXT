"""Canonical statistics and persistent Plot publication through public APIs."""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
from pathlib import Path
from gxtxt import gxtxt_api_require, gxtxt_api_call, gxtxt_context, gxtxt_parameter_declare

gxtxt_api_require('CANONICAL_DATASET_API_v2@2')
gxtxt_api_require('CURVE_SOURCE_API_v1@1')
gxtxt_api_require('NUMERIC_API_v1@1:math.numeric')
gxtxt_api_require('DATASET_PUBLICATION_API_v2@2')
gxtxt_api_require('PLOT_DATASET_API_v4@4:plot.dataset')
gxtxt_parameter_declare('dataset_id','string',required=True,description='Original canonical Dataset ID')
gxtxt_parameter_declare('x_variable_id','string',required=True,description='Original stable X Variable ID')
gxtxt_parameter_declare('y_variable_id','string',required=True,description='Original stable Y Variable ID')
gxtxt_parameter_declare('expected_sha256','string',required=True,description='Admitted original payload SHA256')
gxtxt_parameter_declare('expected_schema_identity','string',required=True,description='Admitted scientific schema identity')
gxtxt_parameter_declare('max_rows','integer',default=65536,min=1,max=65536,description='Whole-source row admission limit')
gxtxt_parameter_declare('output_dataset_id','string',required=True,description='Derived canonical histogram Dataset ID')
gxtxt_parameter_declare('smoke_only','boolean',default=False,description='Compute the other-language statistics without publication')

def call(api,operation,*args):
    return gxtxt_api_call(api,operation,list(args))

def progress(stage,fraction):
    # Existing Supervisor V1 protocol: escaped tab-separated key/value fields.
    print('@@GXTXT_PROGRESS_V1@@\tstage='+stage+'\tfraction='+str(fraction),flush=True)

def verify_source(parameters):
    actual=call('CURVE_SOURCE_API_v1','dataset_identity',parameters['dataset_id'])
    if (actual.get('sha256')!=parameters['expected_sha256'] or
        actual.get('schema_identity')!=parameters['expected_schema_identity']):
        raise ValueError('The canonical payload or scientific Variable schema changed; bind the source again.')
    return actual

def run():
    context=gxtxt_context()
    parameters=context['parameters']
    dataset=parameters['dataset_id']
    identity=verify_source(parameters)
    description=call('CANONICAL_DATASET_API_v2','describe',dataset)
    variables={v['variable_id']:v for v in description['variables']}
    xid,yid=parameters['x_variable_id'],parameters['y_variable_id']
    if xid==yid or xid not in variables or yid not in variables:
        raise ValueError('The selected source requires distinct stable X and Y Variable IDs.')
    count=int(description['row_count'])
    if not 1<=count<=int(parameters['max_rows']):
        raise ValueError('The complete source is empty, unknown or exceeds the declared row limit; no partial statistics are substituted.')
    if int(variables[yid].get('rank',1))!=1:
        raise ValueError('The demo requires a rank-one Y variable; multidimensional source shape is not flattened.')
    progress('Reading original canonical values',0.1)
    values=call('CANONICAL_DATASET_API_v2','read_range',dataset,[xid,yid],0,count)
    y=values[yid]['values']
    if values[yid]['dtype'] not in ('uint8','uint16','int16','float32','float64'):
        raise ValueError('This population-summary contract requires original uint8/uint16/int16/float32/float64 values; no implicit dtype conversion.')
    verify_source(parameters)
    progress('Public Numeric population statistics',0.3)
    statistics=call('NUMERIC_API_v1','statistics_summary',y,{'contract_version':1})
    if statistics['availability']!='available':
        raise ValueError('No finite source samples are available; undefined statistics are not published as zero.')
    lower=float(statistics['minimum'])
    upper=float(statistics['maximum'])
    # This declared constant-source presentation span does not alter any sample.
    if upper==lower:upper=lower+1.0
    histogram=call('NUMERIC_API_v1','histogram_summary',y,
                   {'contract_version':1,'mode':'bounded','bins':8,'domain_low':lower,'domain_high':upper})
    unit=variables[yid].get('unit','')
    result={'schema':'gxtxt.observatory.analysis.v1','language':'Python',
            'source_identity':identity,'x_variable_id':xid,'y_variable_id':yid,'y_unit':unit,
            'statistics':statistics,'histogram':{k:v for k,v in histogram.items() if k!='counts'},
            'publication':None,'plot_ref':None}
    result['histogram']['counts']=[int(v) for v in histogram['counts'].reshape(-1,order='F')]
    verify_source(parameters)
    if parameters.get('smoke_only',False):return result
    progress('Publishing canonical histogram Dataset',0.6)
    centers=call('NUMERIC_API_v1','uniform_grid',
                 histogram['lower']+histogram['width']/2,
                 histogram['upper']-histogram['width']/2,
                 int(histogram['bins']),{'mode':'count'})['x']
    definition={'dataset_id':parameters['output_dataset_id'],'contract':'table.generic','storage':'hdf5',
                'expected_rows':int(histogram['bins']),'estimated_numeric_bytes':int(histogram['bins'])*16,
                'producer_version':'1.0.0','source_dataset_ids':[dataset],'source_variable_ids':[xid,yid],
                'source':'Original canonical source '+dataset,
                'provenance':json.dumps(identity,sort_keys=True),
                'structured_metadata':{'observatory.mean':str(statistics['mean']),
                    'observatory.population_stddev':str(statistics['stddev']),
                    'observatory.response_unit':unit,'observatory.source_sha256':identity['sha256'],
                    'observatory.source_schema_identity':identity['schema_identity'],
                    'observatory.numeric_api':'NUMERIC_API_v1','observatory.language':'Python'}}
    writer=call('DATASET_PUBLICATION_API_v2','begin',definition)
    try:
        bins=int(histogram['bins'])
        call('DATASET_PUBLICATION_API_v2','declare_dimension',writer,'bin',bins,{})
        call('DATASET_PUBLICATION_API_v2','declare_variable',writer,'bin_center',
             {'dtype':'float64','rank':1,'dimension_ids':'bin','coordinate_role':'coordinate',
              'display_label':'Y bin center','unit':unit})
        call('DATASET_PUBLICATION_API_v2','declare_variable',writer,'count',
             {'dtype':'uint64','rank':1,'dimension_ids':'bin','coordinate_role':'data',
              'display_label':'Finite sample count','unit':'1'})
        call('DATASET_PUBLICATION_API_v2','write_variable',writer,'bin_center',centers,[bins])
        call('DATASET_PUBLICATION_API_v2','write_variable',writer,'count',histogram['counts'],[bins])
        verify_source(parameters)
        result['publication']=call('DATASET_PUBLICATION_API_v2','finalize',writer)
        writer=None
    finally:
        if writer is not None:call('DATASET_PUBLICATION_API_v2','abort',writer)
    progress('Publishing registered Plot Dataset v4 graph',0.85)
    spec=call('PLOT_DATASET_API_v4','new_spec','plot.dataset.xy','Canonical Y histogram')
    spec['panels'][0]['series']=[{'id':'histogram','dataset_id':parameters['output_dataset_id'],
        'x_variable_id':'bin_center','y_variable_id':'count','axis':'left','kind':'bar',
        'label':'Finite sample count','enabled':1}]
    call('PLOT_DATASET_API_v4','validate_spec',spec)
    result['plot_ref']=call('PLOT_DATASET_API_v4','upsert_plot','histogram.'+parameters['output_dataset_id'],spec)
    call('PLOT_DATASET_API_v4','render',result['plot_ref'])
    return result

if __name__=='__main__':
    context=gxtxt_context()
    result=run()
    # This is the ordinary Job's public output directory, never a source path.
    receipt={'schema':'gxtxt.viewer_bridge_result.v1','module_id':context['module_id'],
             'run_id':context['run_id'],'action':'run','result':result}
    payload=json.dumps(receipt,allow_nan=False,separators=(',',':'))
    if len(payload.encode())>1048576:raise ValueError('Demo control result exceeds the managed receipt bound.')
    (Path(context['output_dir'])/'viewer_bridge_result.json').write_text(payload)
    progress('Canonical statistics and Plot workflow completed',1.0)
