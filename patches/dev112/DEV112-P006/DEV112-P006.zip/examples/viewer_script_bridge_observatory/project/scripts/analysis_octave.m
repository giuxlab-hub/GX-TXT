% Canonical statistics and persistent Plot publication through public APIs.
% SPDX-License-Identifier: GPL-3.0-or-later
1; % This is an ordinary admitted Script Project entrypoint, not a function loader.

function identity=observatory_verify_source(parameters)
  identity=gxtxt_api_call('CURVE_SOURCE_API_v1','dataset_identity',{parameters.dataset_id});
  if(!strcmp(identity.sha256,parameters.expected_sha256)||!strcmp(identity.schema_identity,parameters.expected_schema_identity))
    error('Observatory:SourceChanged','The original payload or scientific Variable schema changed; bind the source again.');
  endif
endfunction

function observatory_progress(stage,fraction)
  % Existing Supervisor V1 protocol, not an unparsed stdout status message.
  printf('@@GXTXT_PROGRESS_V1@@\tstage=%s\tfraction=%.6f\n',stage,fraction);fflush(stdout);
endfunction

gxtxt_api_require('CANONICAL_DATASET_API_v2@2');
gxtxt_api_require('CURVE_SOURCE_API_v1@1');
gxtxt_api_require('NUMERIC_API_v1@1:math.numeric');
gxtxt_api_require('DATASET_PUBLICATION_API_v2@2');
gxtxt_api_require('PLOT_DATASET_API_v4@4:plot.dataset');
gxtxt_parameter_declare('dataset_id','string','required',true,'description','Original canonical Dataset ID');
gxtxt_parameter_declare('x_variable_id','string','required',true,'description','Original stable X Variable ID');
gxtxt_parameter_declare('y_variable_id','string','required',true,'description','Original stable Y Variable ID');
gxtxt_parameter_declare('expected_sha256','string','required',true,'description','Admitted original payload SHA256');
gxtxt_parameter_declare('expected_schema_identity','string','required',true,'description','Admitted scientific schema identity');
gxtxt_parameter_declare('max_rows','integer','default',65536,'min',1,'max',65536,'description','Whole-source row admission limit');
gxtxt_parameter_declare('output_dataset_id','string','required',true,'description','Derived canonical histogram Dataset ID');
gxtxt_parameter_declare('smoke_only','boolean','default',false,'description','Compute other-language statistics without publication');

context=gxtxt_context();parameters=context.parameters;
identity=observatory_verify_source(parameters);
description=gxtxt_api_call('CANONICAL_DATASET_API_v2','describe',{parameters.dataset_id});
x_variable=struct();y_variable=struct();
for variable_index=1:numel(description.variables)
  variable=description.variables{variable_index};
  if(strcmp(variable.variable_id,parameters.x_variable_id)),x_variable=variable;endif
  if(strcmp(variable.variable_id,parameters.y_variable_id)),y_variable=variable;endif
endfor
if(isempty(fieldnames(x_variable))||isempty(fieldnames(y_variable))||strcmp(parameters.x_variable_id,parameters.y_variable_id))
  error('Observatory:Variables','The source requires distinct, present stable X/Y Variable IDs.');
endif
count=description.row_count;if(ischar(count)),count=str2double(count);endif
if(count<1||count>parameters.max_rows||count!=fix(count))
  error('Observatory:Rows','The complete source is empty, unknown or exceeds its declared row limit.');
endif
rank=y_variable.rank;if(ischar(rank)),rank=str2double(rank);endif
if(rank!=1),error('Observatory:Shape','A rank-one Y variable is required; multidimensional values are not flattened.');endif
observatory_progress('Reading original canonical values',0.1);
values=gxtxt_api_call('CANONICAL_DATASET_API_v2','read_range', ...
  {parameters.dataset_id,{parameters.x_variable_id,parameters.y_variable_id},0,count});
y=values.(parameters.y_variable_id).values;
dtype=values.(parameters.y_variable_id).dtype;
if(!any(strcmp(dtype,{'uint8','uint16','int16','float32','float64'})))
  error('Observatory:Dtype','The public population summary does not admit this original dtype; no implicit conversion.');
endif
observatory_verify_source(parameters);
observatory_progress('Public Numeric population statistics',0.3);
statistics=gxtxt_api_call('NUMERIC_API_v1','statistics_summary',{y,struct('contract_version',1)});
if(!strcmp(statistics.availability,'available'))
  error('Observatory:NoFiniteSamples','Undefined statistics are not published as zero.');
endif
lower=statistics.minimum;upper=statistics.maximum;
if(upper==lower),upper=lower+1;endif
histogram=gxtxt_api_call('NUMERIC_API_v1','histogram_summary', ...
  {y,struct('contract_version',1,'mode','bounded','bins',8,'domain_low',lower,'domain_high',upper)});
unit=y_variable.unit;
result=struct('schema','gxtxt.observatory.analysis.v1','language','Octave', ...
  'source_identity',identity,'x_variable_id',parameters.x_variable_id,'y_variable_id',parameters.y_variable_id, ...
  'y_unit',unit,'statistics',statistics,'histogram',histogram,'publication',[],'plot_ref',[]);
observatory_verify_source(parameters);
if(!parameters.smoke_only)
  observatory_progress('Publishing canonical histogram Dataset',0.6);
  grid=gxtxt_api_call('NUMERIC_API_v1','uniform_grid', ...
    {histogram.lower+histogram.width/2,histogram.upper-histogram.width/2,histogram.bins,struct('mode','count')});
  metadata=struct();
  metadata.('observatory.mean')=sprintf('%.17g',statistics.mean);
  metadata.('observatory.population_stddev')=sprintf('%.17g',statistics.stddev);
  metadata.('observatory.response_unit')=unit;
  metadata.('observatory.source_sha256')=identity.sha256;
  metadata.('observatory.source_schema_identity')=identity.schema_identity;
  metadata.('observatory.numeric_api')='NUMERIC_API_v1';metadata.('observatory.language')='Octave';
  definition=struct('dataset_id',parameters.output_dataset_id,'contract','table.generic','storage','hdf5', ...
    'expected_rows',histogram.bins,'estimated_numeric_bytes',histogram.bins*16,'producer_version','1.0.0', ...
    'source_dataset_ids',{{parameters.dataset_id}},'source_variable_ids',{{parameters.x_variable_id,parameters.y_variable_id}}, ...
    'source',['Original canonical source ' parameters.dataset_id],'provenance',jsonencode(identity),'structured_metadata',metadata);
  writer=gxtxt_api_call('DATASET_PUBLICATION_API_v2','begin',{definition});
  unwind_protect
    gxtxt_api_call('DATASET_PUBLICATION_API_v2','declare_dimension',{writer,'bin',histogram.bins,struct()});
    gxtxt_api_call('DATASET_PUBLICATION_API_v2','declare_variable', ...
      {writer,'bin_center',struct('dtype','float64','rank',1,'dimension_ids','bin','coordinate_role','coordinate', ...
      'display_label','Y bin center','unit',unit)});
    gxtxt_api_call('DATASET_PUBLICATION_API_v2','declare_variable', ...
      {writer,'count',struct('dtype','uint64','rank',1,'dimension_ids','bin','coordinate_role','data', ...
      'display_label','Finite sample count','unit','1')});
    gxtxt_api_call('DATASET_PUBLICATION_API_v2','write_variable',{writer,'bin_center',grid.x,histogram.bins});
    gxtxt_api_call('DATASET_PUBLICATION_API_v2','write_variable',{writer,'count',histogram.counts,histogram.bins});
    observatory_verify_source(parameters);
    result.publication=gxtxt_api_call('DATASET_PUBLICATION_API_v2','finalize',{writer});writer='';
  unwind_protect_cleanup
    if(!isempty(writer)),gxtxt_api_call('DATASET_PUBLICATION_API_v2','abort',{writer});endif
  end_unwind_protect
  observatory_progress('Publishing registered Plot Dataset v4 graph',0.85);
  spec=gxtxt_api_call('PLOT_DATASET_API_v4','new_spec',{'plot.dataset.xy','Canonical Y histogram'});
  series=struct('id','histogram','dataset_id',parameters.output_dataset_id,'x_variable_id','bin_center', ...
    'y_variable_id','count','axis','left','kind','bar','label','Finite sample count','enabled',1);
  spec.panels{1}.series={series};
  gxtxt_api_call('PLOT_DATASET_API_v4','validate_spec',{spec});
  result.plot_ref=gxtxt_api_call('PLOT_DATASET_API_v4','upsert_plot',{['histogram.' parameters.output_dataset_id],spec});
  gxtxt_api_call('PLOT_DATASET_API_v4','render',{result.plot_ref});
endif
receipt=struct('schema','gxtxt.viewer_bridge_result.v1','module_id',context.module_id, ...
  'run_id',context.run_id,'action','run','result',result);
payload=jsonencode(receipt);
if(numel(unicode2native(payload,'UTF-8'))>1048576),error('Observatory:ResultBound','Managed control receipt exceeds1MiB.');endif
output=fullfile(context.output_dir,'viewer_bridge_result.json');
[fd,message]=fopen(output,'w');if(fd<0),error('Observatory:Output','Cannot write owned Job result: %s',message);endif
unwind_protect
  count=fwrite(fd,unicode2native(payload,'UTF-8'),'uint8');
  if(count!=numel(unicode2native(payload,'UTF-8'))),error('Observatory:Output','Incomplete managed result write.');endif
unwind_protect_cleanup
  fclose(fd);
end_unwind_protect
observatory_progress('Canonical statistics and Plot workflow completed',1.0);
