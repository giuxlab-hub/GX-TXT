// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "components.hpp"
#include <map>
#include <string>
#include <vector>

namespace observatory {
using Value = gx::WorkspaceValue;
const Value& field(const Value&, const char*);
std::string text(const Value&, const std::string&);
std::string scalar(const Value&);
std::string json(const Value&);
void report(gx::Host&, unsigned, const std::string&);
void status(gx::Host&, const std::string&);

struct SourceBinding {
    std::string dataset_id, x_variable_id, y_variable_id, sha256, schema_identity, y_unit, namespace_id;
    Value descriptor, identity;
    bool described = false;
    bool identified = false;
    bool namespace_known = false;
    bool ready() const;
    void select(gx::Host&);
    void accept(gx::Host&, const std::string&, const std::string&, const Value&);
    Value parameters(gx::Host&, bool smoke) const;
    Value capture() const;
    void restore(const Value&);
};

struct JobRecord {
    std::string job_id, state, stage, language, diagnostic;
    std::string source_dataset, source_sha256, source_schema_identity;
    Value result;
    double progress = 0;
    bool terminal = false;
};

class BridgeJobs {
public:
    std::map<std::string, JobRecord> jobs;
    std::string active_id;
    void call(gx::Host&, const char*, const char*, const Value&);
    void discover(gx::Host&);
    void require(gx::Host&);
    void submit(gx::Host&, const SourceBinding&, bool smoke);
    void command(gx::Host&, const char*);
    bool receive(gx::Host&, SourceBinding&, Value&);
    void describe(gx::Host&) const;
    Value capture() const;
    void restore(const Value&);
private:
    unsigned request_sequence_ = 0;
    std::string last_receipt_;
    std::string selected(gx::Host&) const;
    void send(gx::Host&, const char*, Value);
};

class NumericResults {
public:
    Value latest;
    void accept(gx::Host&, const Value&, const SourceBinding&);
    void present(gx::Host&) const;
    void clear();
};

class PlotPublication {
public:
    Value reference;
    std::string derived_dataset;
    void accept(gx::Host&, const Value&);
    void invoke(gx::Host&, BridgeJobs&, const char*) const;
    void present(gx::Host&) const;
    Value capture() const;
    void restore(const Value&);
};

struct Application {
    SourceBinding source;
    BridgeJobs bridge;
    NumericResults numeric;
    PlotPublication plot;
    std::string last_error;
    void dispatch(gx::Host&, const gx::Event&);
    Value capture() const;
    void restore(const Value&);
};
Application& application();
}
