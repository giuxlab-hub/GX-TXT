// SPDX-License-Identifier: GPL-3.0-or-later
#include "observatory.hpp"
#include <stdexcept>

namespace observatory {
namespace {
bool terminal(const std::string& state) {
    return state=="COMPLETED" || state=="Completed" || state=="FAILED" || state=="Failed" ||
           state=="CANCELLED" || state=="Cancelled" || state=="INTERRUPTED" || state=="Interrupted";
}
bool complete(const std::string& state){return state=="COMPLETED" || state=="Completed";}
const Value& result_body(const Value& value) {
    const auto& body=field(value,"result");
    if(text(body,"schema")=="gxtxt.viewer_bridge_result.v1")return field(body,"result");
    return body.kind==Value::Kind::null?value:body;
}
}
void BridgeJobs::send(gx::Host& host,const char* action,Value request) {
    // The SDK delegates this typed envelope to the single Script Bridge owner.
    // Request counters are local UI bookkeeping and never claimed as Job IDs.
    ++request_sequence_;host.script_bridge(action,request);
    status(host,std::string("Requested ")+action+" through the managed Script Bridge.");
}
void BridgeJobs::call(gx::Host& host,const char* api,const char* operation,const Value& args) {
    send(host,"call",gx::workspace_object({{"api_id",gx::workspace_text(api)},
        {"operation",gx::workspace_text(operation)},{"args",args}}));
}
void BridgeJobs::discover(gx::Host& host){send(host,"list",gx::workspace_object());}
void BridgeJobs::require(gx::Host& host) {
    std::vector<Value> requirements;
    for(const std::string declaration:{"CANONICAL_DATASET_API_v2@2","CURVE_SOURCE_API_v1@1",
        "DATASET_NAMESPACE_API_v1@1","NUMERIC_API_v1@1:math.numeric","DATASET_PUBLICATION_API_v2@2","PLOT_DATASET_API_v4@4:plot.dataset"})
        requirements.push_back(gx::workspace_text(declaration));
    send(host,"require",gx::workspace_object({{"requirements",gx::workspace_array(requirements)}}));
}
void BridgeJobs::submit(gx::Host& host,const SourceBinding& source,bool smoke) {
    const std::string selected_language=host.input(JobLanguage);
    const bool python=(selected_language=="Python")!=smoke;
    const auto parameters=source.parameters(host,smoke);
    send(host,"run",gx::workspace_object({{"entrypoint",gx::workspace_text(python?"analysis_python":"analysis_octave")},
        {"parameters",parameters},{"inputs",gx::workspace_object({{"source",gx::workspace_object({
            {"dataset_id",gx::workspace_text(source.dataset_id)},
            {"namespace",gx::workspace_text(source.namespace_id)}})}})}}));
}
std::string BridgeJobs::selected(gx::Host& host) const {
    const std::string input=host.input(JobId);
    return input.empty()?active_id:input;
}
void BridgeJobs::command(gx::Host& host,const char* operation) {
    const auto id=selected(host);
    if(id.empty())throw std::runtime_error("Choose an authoritative Job ID from the managed Job report.");
    send(host,operation,gx::workspace_object({{"job_id",gx::workspace_text(id)}}));
}
bool BridgeJobs::receive(gx::Host& host,SourceBinding& source,Value& completed) {
    const auto* value=host.script_bridge_result();
    if(!value || value->kind!=Value::Kind::object || value->fields.empty())return false;
    const auto& envelope=*value;
    const auto encoded_receipt=json(envelope);
    if(encoded_receipt==last_receipt_)return false;
    last_receipt_=encoded_receipt;
    const auto& retained=field(envelope,"result");
    const auto& request=field(envelope,"request").kind==Value::Kind::object?
        field(envelope,"request"):field(retained,"request");
    const auto action=text(envelope,"action");
    const auto id=text(envelope,"job_id");
    const auto state=text(envelope,"state");
    // The outer operation is the frontend lifecycle action (e.g. result).
    // Provider identity belongs to the original validated generic request.
    std::string api=text(request,"api_id"),operation=text(request,"operation");
    const auto& body=result_body(envelope);
    if(!id.empty()){
        active_id=id;auto& job=jobs[id];job.job_id=id;
        // A duplicated or out-of-order active event cannot downgrade a terminal receipt.
        const bool was_terminal=job.terminal;
        if(!was_terminal || terminal(state)){if(!state.empty())job.state=state;job.terminal=terminal(job.state);}
        // Lifecycle/result receipts need not repeat the last observed stage.
        // Keep genuine event metadata when a sparse result receipt arrives.
        const auto stage=text(envelope,"stage"),diagnostic=text(envelope,"diagnostic");
        if(!stage.empty())job.stage=stage;
        if(!diagnostic.empty())job.diagnostic=diagnostic;
        const auto& progress=field(envelope,"progress");
        if(progress.kind==Value::Kind::real)job.progress=100.0*progress.real;
        else if(progress.kind==Value::Kind::integer)job.progress=100.0*double(progress.integer);
        if(job.progress<0 || job.progress>100)job.progress=0;
        host.number(JobProgress,job.progress);
        const auto short_id=id.size()>14?id.substr(id.size()-14):id;
        const auto label="Job: "+job.state+" / "+short_id;
        host.text(ActiveJob,label.substr(0,250).c_str());
        if(!was_terminal && job.terminal && !complete(job.state))
            status(host,"Job "+job.state+". Review its diagnostic; no completed result was accepted.");
        if(!was_terminal && complete(job.state) && field(envelope,"result").kind==Value::Kind::null)
            host.script_bridge("result",gx::workspace_object({{"job_id",gx::workspace_text(id)}}));
        if(field(envelope,"result").kind!=Value::Kind::null)job.result=field(envelope,"result");
    }
    if(api.empty() && text(body,"dataset_id")==source.dataset_id){
        // The two existing owner result contracts are structurally distinct.
        // No new API dispatch is introduced; this is consumer receipt interpretation.
        if(field(body,"variables").kind==Value::Kind::array){api="CANONICAL_DATASET_API_v2";operation="describe";}
        else if(!text(body,"sha256").empty() && !text(body,"schema_identity").empty()){
            api="CURVE_SOURCE_API_v1";operation="dataset_identity";
        }
    }
    bool source_request_current=true;
    if(api=="DATASET_NAMESPACE_API_v1"){
        const auto& args=field(request,"args");
        source_request_current=args.kind==Value::Kind::array && !args.elements.empty() &&
            args.elements.front().kind==Value::Kind::text && args.elements.front().text==source.dataset_id;
    }
    if(!api.empty() && source_request_current)source.accept(host,api,operation,body);
    describe(host);
    std::string roster="Managed Jobs retained by this Viewer:\n";
    for(const auto& pair:jobs)roster+=pair.first+" | "+pair.second.state+" | "+pair.second.stage+"\n";
    report(host,JobReport,roster+"\nLast actual managed receipt:\n"+encoded_receipt+"\n\n"+
        "Job IDs are Supervisor-issued; reopening requires explicit guarded reconnect.\n"+
        "Ordinary updates are event driven; status is an explicit inspection action.");
    if(text(body,"schema")=="gxtxt.observatory.analysis.v1"){
        completed=body;return true;
    }
    if(!text(envelope,"error").empty())status(host,"Bridge refusal: "+text(envelope,"error"));
    return false;
}
void BridgeJobs::describe(gx::Host& host) const {
    std::string out="Managed Jobs retained by this Viewer:\n";
    for(const auto& pair:jobs){const auto& job=pair.second;out+=job.job_id+" | "+job.state+" | "+job.stage+"\n";}
    if(jobs.empty())out+="None. Admission is pending until the Supervisor returns a real Job ID.\n";
    report(host,JobReport,out);
}
Value BridgeJobs::capture() const {
    std::vector<Value> saved;
    for(const auto& pair:jobs){const auto& job=pair.second;saved.push_back(gx::workspace_object({
        {"job_id",gx::workspace_text(job.job_id)},{"state",gx::workspace_text(job.state)},
        {"stage",gx::workspace_text(job.stage)},{"terminal",gx::workspace_flag(job.terminal)}}));}
    return gx::workspace_object({{"active_job_id",gx::workspace_text(active_id)},{"records",gx::workspace_array(saved)}});
}
void BridgeJobs::restore(const Value& value) {
    if(value.kind!=Value::Kind::object)throw std::runtime_error("Workspace Job state must be a typed object.");
    const auto& records=field(value,"records");
    if(records.kind!=Value::Kind::array || records.elements.size()>256)throw std::runtime_error("Workspace Job roster is outside its bound.");
    std::map<std::string,JobRecord> restored;
    for(const auto& item:records.elements){
        const auto id=text(item,"job_id");
        if(id.empty() || id.size()>256 || restored.count(id))throw std::runtime_error("Workspace contains invalid or repeated Job identities.");
        JobRecord job;job.job_id=id;job.state=text(item,"state");job.stage="Explicit reconnect required";job.terminal=terminal(job.state);restored[id]=job;
    }
    jobs=restored;active_id=text(value,"active_job_id");
    if(!active_id.empty() && !jobs.count(active_id))throw std::runtime_error("Active Workspace Job ID is absent from its exact roster.");
}
}
