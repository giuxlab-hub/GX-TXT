// SPDX-License-Identifier: GPL-3.0-or-later
#include "observatory.hpp"
#include <stdexcept>

namespace observatory {
bool SourceBinding::ready() const {
    return described && identified && namespace_known && !dataset_id.empty() && !sha256.empty() && !schema_identity.empty();
}
void SourceBinding::select(gx::Host& host) {
    const std::string selected=host.input(SourceDataset), x=host.input(SourceX), y=host.input(SourceY);
    if(selected.empty() || x.empty() || y.empty() || x==y)
        throw std::runtime_error("Select one canonical Dataset and distinct stable X/Y Variable IDs.");
    *this=SourceBinding();dataset_id=selected;x_variable_id=x;y_variable_id=y;
    host.text(SourceIdentity,"Source: awaiting authoritative identity");
    report(host,SourceReport,"Reading the canonical source and schema. No scientific values are calculated in C++.");
}
void SourceBinding::accept(gx::Host& host,const std::string& api,const std::string& operation,const Value& value) {
    if(api=="DATASET_NAMESPACE_API_v1" && operation=="get"){
        if(value.kind!=Value::Kind::text)throw std::runtime_error("Dataset namespace must be the public opaque namespace string.");
        namespace_id=value.text;namespace_known=true;
    }else if(text(value,"dataset_id")!=dataset_id)return;
    if(api=="CANONICAL_DATASET_API_v2" && operation=="describe") {
        const auto& variables=field(value,"variables");
        if(variables.kind!=Value::Kind::array)throw std::runtime_error("Canonical schema did not return typed Variable descriptors.");
        bool has_x=false,has_y=false;
        for(const auto& variable:variables.elements){
            const auto id=text(variable,"variable_id");
            if(id==x_variable_id)has_x=true;
            if(id==y_variable_id){has_y=true;y_unit=text(variable,"unit");}
        }
        if(!has_x || !has_y)throw std::runtime_error("A selected stable Variable ID is absent from the source schema.");
        descriptor=value;described=true;
    }
    if(api=="CURVE_SOURCE_API_v1" && operation=="dataset_identity") {
        sha256=text(value,"sha256");schema_identity=text(value,"schema_identity");
        if(sha256.size()!=64 || schema_identity.empty())throw std::runtime_error("The source owner returned an incomplete payload/schema identity.");
        identity=value;identified=true;
    }
    if(ready()){
        host.text(SourceIdentity,"Source: payload and schema bound");
        status(host,"Source bound. Check providers, then submit the bundled analysis.");
    }
    report(host,SourceReport,"Canonical Dataset: "+dataset_id+"\nX Variable: "+x_variable_id+"\nY Variable: "+y_variable_id+
        "\nY unit: "+y_unit+"\nNamespace: "+namespace_id+"\nOriginal payload SHA256: "+sha256+"\nScientific schema identity: "+schema_identity+
        "\n\nCanonical descriptor:\n"+json(descriptor));
}
Value SourceBinding::parameters(gx::Host& host,bool smoke) const {
    if(!ready())throw std::runtime_error("Bind the source identity before submitting analysis.");
    if(dataset_id!=host.input(SourceDataset) || x_variable_id!=host.input(SourceX) || y_variable_id!=host.input(SourceY))
        throw std::runtime_error("The Dataset or Variable selection changed. Bind the source again.");
    const std::string count=host.input(SourceLimit),output=host.input(SourceOutput);
    std::size_t end=0;const auto limit=std::stoll(count,&end);
    if(end!=count.size() || limit<1 || limit>65536 || output.empty())throw std::runtime_error("Use a bounded whole-source row limit and a derived Dataset ID.");
    return gx::workspace_object({{"dataset_id",gx::workspace_text(dataset_id)},
        {"x_variable_id",gx::workspace_text(x_variable_id)},{"y_variable_id",gx::workspace_text(y_variable_id)},
        {"expected_sha256",gx::workspace_text(sha256)},{"expected_schema_identity",gx::workspace_text(schema_identity)},
        {"max_rows",gx::workspace_integer(limit)},{"output_dataset_id",gx::workspace_text(output)},
        {"smoke_only",gx::workspace_flag(smoke)}});
}
Value SourceBinding::capture() const {
    return gx::workspace_object({{"dataset_id",gx::workspace_text(dataset_id)},
        {"x_variable_id",gx::workspace_text(x_variable_id)},{"y_variable_id",gx::workspace_text(y_variable_id)},
        {"identity",identity},{"descriptor",descriptor},{"y_unit",gx::workspace_text(y_unit)},
        {"namespace",gx::workspace_text(namespace_id)}});
}
void SourceBinding::restore(const Value& saved) {
    if(saved.kind!=Value::Kind::object)throw std::runtime_error("Workspace source binding must be a typed object.");
    dataset_id=text(saved,"dataset_id");x_variable_id=text(saved,"x_variable_id");y_variable_id=text(saved,"y_variable_id");
    identity=field(saved,"identity");descriptor=field(saved,"descriptor");y_unit=text(saved,"y_unit");
    namespace_id=text(saved,"namespace");
    sha256=text(identity,"sha256");schema_identity=text(identity,"schema_identity");
    // Restored receipts are evidence, not admission to a new Session lifetime.
    described=false;identified=false;namespace_known=false;
}
}
