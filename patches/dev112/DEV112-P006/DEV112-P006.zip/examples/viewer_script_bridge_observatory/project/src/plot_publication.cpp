// SPDX-License-Identifier: GPL-3.0-or-later
#include "observatory.hpp"
#include <stdexcept>

namespace observatory {
void PlotPublication::accept(gx::Host& host,const Value& result) {
    if(text(result,"schema")!="gxtxt.observatory.analysis.v1")return;
    const auto& candidate=field(result,"plot_ref");
    if(candidate.kind==Value::Kind::null || (candidate.kind==Value::Kind::array && candidate.elements.empty()))return;
    if(text(candidate,"module_id")!="plot.dataset" || text(candidate,"graph_id").empty())
        throw std::runtime_error("Plot publication returned no registered Plot Dataset reference.");
    const auto& dataset=field(result,"publication");
    const auto id=text(dataset,"dataset_id");
    if(id.empty())throw std::runtime_error("Plot publication did not retain its derived canonical Dataset ID.");
    reference=candidate;derived_dataset=id;present(host);
    report(host,ProjectReport,"Derived canonical Dataset: "+derived_dataset+
        "\nPersistent Plot Dataset v4 reference:\n"+json(reference)+
        "\n\nThe graph is registered in GX-TXT Plots. Save the Workspace and reopen the same Session to recover this identity without recomputing statistics.");
}
void PlotPublication::invoke(gx::Host& host,BridgeJobs& bridge,const char* operation) const {
    if(reference.kind!=Value::Kind::object || text(reference,"graph_id").empty())
        throw std::runtime_error("Complete a publishing analysis or reopen its saved Workspace first.");
    bridge.call(host,"PLOT_DATASET_API_v4",operation,gx::workspace_array({reference}));
}
void PlotPublication::present(gx::Host& host) const {
    const auto graph=text(reference,"graph_id"),variant=text(reference,"variant_id");
    const auto line=graph.empty()?"No registered Plot has been published.":"Plot: "+graph+" / "+variant+" | Dataset: "+derived_dataset;
    host.text(PlotIdentity,line.substr(0,250).c_str());
}
Value PlotPublication::capture() const {
    return gx::workspace_object({{"reference",reference},{"derived_dataset_id",gx::workspace_text(derived_dataset)}});
}
void PlotPublication::restore(const Value& value) {
    if(value.kind!=Value::Kind::object)throw std::runtime_error("Workspace Plot state must be a typed object.");
    const auto& candidate=field(value,"reference");
    if(candidate.kind!=Value::Kind::null && (candidate.kind!=Value::Kind::object || text(candidate,"module_id")!="plot.dataset"))
        throw std::runtime_error("Workspace Plot reference is not a public registered Plot Dataset identity.");
    reference=candidate;derived_dataset=text(value,"derived_dataset_id");
}
}
