// SPDX-License-Identifier: GPL-3.0-or-later
#include "observatory.hpp"
#include <stdexcept>

namespace observatory {
void NumericResults::clear(){latest=Value();}
void NumericResults::accept(gx::Host& host,const Value& result,const SourceBinding& source) {
    if(text(result,"schema")!="gxtxt.observatory.analysis.v1")return;
    const auto& source_identity=field(result,"source_identity");
    if(text(source_identity,"dataset_id")!=source.dataset_id || text(source_identity,"sha256")!=source.sha256 ||
       text(source_identity,"schema_identity")!=source.schema_identity ||
       text(result,"x_variable_id")!=source.x_variable_id || text(result,"y_variable_id")!=source.y_variable_id)
        throw std::runtime_error("The completed result belongs to a different source or scientific schema.");
    const auto& statistics=field(result,"statistics");
    if(text(statistics,"schema")!="gxtxt.numeric.statistics_summary.v1" || text(statistics,"variance")!="population" ||
       text(statistics,"availability")!="available")throw std::runtime_error("The Numeric result lacks defined population statistics.");
    const auto& histogram=field(result,"histogram");
    if(text(histogram,"schema")!="gxtxt.numeric.histogram_summary.v1" || text(histogram,"count_dtype")!="uint64")
        throw std::runtime_error("The histogram result lost its exact count contract.");
    latest=result;present(host);status(host,"Analysis completed through public Numeric. Review the derived Dataset and persistent Plot.");
}
void NumericResults::present(gx::Host& host) const {
    const auto& summary=field(latest,"statistics");
    if(summary.kind!=Value::Kind::object){host.table(ResultSummary,"[]");return;}
    const std::string unit=text(latest,"y_unit");
    std::vector<Value> rows;
    for(const std::string key:{"mean","stddev","minimum","maximum","total_count","finite_count","nan_count","positive_inf_count","negative_inf_count"}){
        const bool count=key.find("count")!=std::string::npos;
        rows.push_back(gx::workspace_array({gx::workspace_text(key),gx::workspace_text(scalar(field(summary,key.c_str()))),
            gx::workspace_text(count?"1":unit),gx::workspace_text(key=="stddev"?"Descriptive population standard deviation":count?"Original source classification":"Public Numeric fact")}));
    }
    const std::string encoded=json(gx::workspace_array(rows));host.table(ResultSummary,encoded.c_str());
    report(host,HistogramReport,"Authoritative histogram (exact uint64 counts; finite-domain policy retained):\n"+
        json(field(latest,"histogram"))+"\n\nSource identity:\n"+json(field(latest,"source_identity"))+
        "\nUnit: "+unit+"\nBridge language: "+text(latest,"language"));
}
}
