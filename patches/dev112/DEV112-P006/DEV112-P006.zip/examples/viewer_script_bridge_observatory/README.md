# Script Bridge Observatory

A complete ordinary Viewer Development Workspace project with five substantive
C++ translation units, a 60-component Viewer Interface Builder design, and bundled
Python and Octave analysis entrypoints. It demonstrates the public Script Bridge,
managed Jobs, Numeric population statistics, canonical Dataset Publication and
persistent Plot Dataset v4. The supplied data is synthetic, not acquired science.

## Install and open

Use P006 with its normal Python and Octave scientific runtimes available. In
Configuration → Modules → Plugin Manager, select
`packages/viewer.script_bridge_observatory_1.0.0.zip`. Enable Script Bridge
Observatory through the ordinary Modules controls, then open it from Viewers.
The example directory performs no installation, enabling or activation itself.
No separate Script Library project is required.

The ZIP is the unchanged tested package, SHA-256
`b1f65760b9f73f5bbf83ed928c3f48b01ba1c17f7c88fecf673eae267f9bdb53`.
Its sibling `.sha256` file can be checked from `packages/` with
`sha256sum -c viewer.script_bridge_observatory_1.0.0.zip.sha256`.

## Import and edit

In Viewer Development Workspace choose **File → Import project package**, select
the ZIP and choose a new project folder outside the framework installation.
Alternatively copy the entire `project/` directory to your own development folder
and open its `project.json` through the ordinary workspace. The framework's shipped
example location is not an editable project scope; import or copy it first.
The ordinary workspace establishes the project write grant and supports Validate,
Build and Export. Native builds require the framework's supported C++17 compiler
toolchain. Open `design.gxtxt-viewer` in Viewer Interface Builder for graphical
editing, and edit the C++/Python/Octave files through the normal source editor.

`project/MANUAL.md` is also the installed module manual. The source manifest and
`SOURCE_PROVENANCE.json` pin the exact editable files from this ZIP. Their
historical authoring metadata is preserved verbatim; it is not a final release
acceptance certificate. No Session, Workspace identity or derived science is
bundled in the editable project.

| Compiled unit | Responsibility |
| --- | --- |
| `handlers.cpp` | GUI dispatch, typed presentation, Workspace capture/restore |
| `src/dataset_binding.cpp` | Canonical Dataset/Variable identity and source guards |
| `src/bridge_jobs.cpp` | Generic Bridge discovery/calls, real Job IDs, events, cancel/reconnect |
| `src/numeric_results.cpp` | Validate and present public Numeric receipts |
| `src/plot_publication.cpp` | Validate publication/Plot references, inspect/rerender, save state |

The bundled scripts call registered scientific providers. They do not implement
a parallel statistics engine, executor, Dataset registry or Plot renderer.

## Try the synthetic input

Create or open a Session and import `input/four_samples.csv` through the ordinary
CSV acquisition owner. Review the resulting canonical Dataset and actual stable
Variable IDs. In normal scientific metadata controls explicitly set X to seconds
(`s`) and Y to volts (`V`) for this demonstration; the CSV header alone does not
declare units, calibration or uncertainty. Use those actual IDs in the Viewer.

In **Dataset & Variables**, choose the Dataset, enter its X/Y Variable IDs and an
unused output Dataset ID, then select **Bind source identity**. Review the original
payload SHA and schema identity. In **Bridge & Jobs**, discover registered APIs,
check scientific providers, select a language and **Analyze and publish**. The
Supervisor supplies the authoritative Job ID after admission; progress and
terminal results arrive through managed events. Inspect, cancel or reconnect by
that real ID. **Other-language smoke** checks the other bundled language without
publishing another Dataset or Plot.

The four Y samples are 1, 2, 3, 4 V: mean 2.5 V and population SD
1.1180339887498949 V. The eight-bin histogram counts are
`[1, 0, 1, 0, 0, 1, 0, 1]`. Publication stores `uint64` counts and `float64` bin
centers in the Y unit, with source lineage. The registered Plot is also available
in the main Plots browser. **Inspect persistent graph** and **Rerender retained
graph** use the retained definition. For the embedded canonical graph choose the
derived Dataset, discover its variables, select `bin_center` and `count`, then
**Show canonical graph**.

Save through **Project & Reopen**, retain the returned Workspace ID, close the
Viewer and Session, and reopen that same Session and Workspace. Numeric receipts
and the persistent Plot reference remain available without reanalysis. Explicit
guarded reconnect is required for a retained Job; a new analysis needs a fresh
source binding and unused output Dataset ID. Changed source/schema, missing
Variables/providers, foreign ownership and cancelled work refuse explicitly.
See the manual for supported dtypes, whole-source limits and nonfinite handling.
