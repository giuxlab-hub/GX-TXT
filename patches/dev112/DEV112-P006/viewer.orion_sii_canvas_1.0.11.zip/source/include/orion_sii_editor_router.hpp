// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// gx public types are provided by the normal Builder's injected Viewer SDK.
// Returns false for events outside the exact Contract17 component/kind map.
bool orion_sii_editor_event(gx::Host& host, const gx::Event& event);
