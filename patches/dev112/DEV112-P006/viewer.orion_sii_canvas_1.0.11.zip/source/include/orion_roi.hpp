// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
// Copy of original current-event Canvas metadata, not an identity generator.
// Returns null unless original selection/page/source selector agree.
gx::WorkspaceValue orion_roi_source(const gx::Host& host);
bool orion_roi_event(gx::Host& host, gx::State& state, const gx::Event& event);
