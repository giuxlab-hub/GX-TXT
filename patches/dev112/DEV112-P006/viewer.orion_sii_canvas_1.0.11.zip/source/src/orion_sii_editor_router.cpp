// SPDX-License-Identifier: GPL-3.0-or-later
#include "orion_sii_editor_router.hpp"

bool orion_sii_editor_event(gx::Host& host, const gx::Event& event) {
    const char* action = nullptr;
    if (event.kind == gx::EventKind::changed) {
        switch (event.component) {
        case 87: case 88: case 99: action = "editor_changed"; break;
        case 89: action = "page_changed"; break;
        case 90: case 91: case 92: case 93: action = "value_changed"; break;
        default: return false;
        }
    } else if (event.kind == gx::EventKind::invoke) {
        switch (event.component) {
        case 4: action = "source_changed"; break;
        case 5: action = "grayscale"; break;
        case 6: action = "invert"; break;
        case 100: action = "validate"; break;
        case 101: action = "preview"; break;
        case 102: action = "status"; break;
        case 103: action = "accept"; break;
        case 104: action = "discard"; break;
        case 105: action = "cancel"; break;
        case 106: action = "reset_image"; break;
        case 107: action = "remove_step"; break;
        case 111: action = "publish"; break;
        case 112: action = "upsert_entity"; break;
        case 113: action = "remove_entity"; break;
        case 118: action = "run_analysis"; break;
        case 122: action = "reset_figure"; break;
        case 123: action = "figure_undo"; break;
        case 124: action = "figure_redo"; break;
        case 126: action = "refresh_sources"; break;
        case 127: action = "copy_report"; break;
        case 128: action = "close"; break;
        case 129: action = "annotation_select_all"; break;
        case 130: action = "annotation_select_none"; break;
        case 131: action = "annotation_copy"; break;
        case 132: action = "annotation_paste"; break;
        case 133: action = "image_undo"; break;
        case 134: action = "image_redo"; break;
        case 135: action = "comparison_toggle"; break;
        case 136: action = "grid_toggle"; break;
        case 137: action = "history_toggle"; break;
        case 138: action = "pending_toggle"; break;
        case 139: action = "actual_pixels"; break;
        case 140: action = "basic_editor"; break;
        case 141: action = "advanced_editor"; break;
        case 142: action = "figure_studio"; break;
        case 143: action = "edit_source"; break;
        case 144: action = "annotation_mode"; break;
        case 145: action = "annotation_tools"; break;
        case 146: action = "restore_original"; break;
        case 147: action = "sidebar_settings"; break;
        case 148: action = "viewer_settings"; break;
        case 149: action = "open_local"; break;
        default: return false;
        }
    } else {
        return false;
    }
    // CORE reads complete declared field values and invokes original validators.
    // In particular, shared changed87 carries no original field/value identity.
    host.canvas_command(1, "extension",
        gx::workspace_object({
            {"extension", gx::workspace_text("viewer.scientific_image_inspector.canvas")},
            {"command", gx::workspace_text(action)},
            {"arguments", gx::workspace_object({})}
        }));
    return true;
}
