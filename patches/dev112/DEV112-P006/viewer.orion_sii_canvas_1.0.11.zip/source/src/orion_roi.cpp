// SPDX-License-Identifier: GPL-3.0-or-later
#include "orion_roi.hpp"
#include <stdexcept>
namespace {
using V=gx::WorkspaceValue;
constexpr unsigned Canvas=1, Output=61;
const V& field(const V& v,const char* key){static const V empty;if(v.kind!=V::Kind::object)return empty;auto it=v.fields.find(key);return it==v.fields.end()?empty:it->second;}
std::string text(const V& v,const char* key){const auto& x=field(v,key);return x.kind==V::Kind::text?x.text:std::string();}
const V& instance(const gx::Host& host){static const V empty;const auto* receipt=host.canvas_result();return receipt?field(field(*receipt,"instances"),"canvas_scene"):empty;}
V request(const V& source){return gx::workspace_object({{"object",field(source,"object")},{"expected_revision",field(source,"canvas_revision")},{"expected_source_sha256",field(source,"source_sha256")},{"expected_source_revision",field(source,"source_revision")}});}
void show_error(gx::Host& host,const char* message){
 std::string quoted;const char digits[]="0123456789abcdef";
 for(const unsigned char ch:std::string(message)){
  if(ch=='"'||ch=='\\'){quoted+='\\';quoted+=ch;}
  else if(ch<32){quoted+="\\u00";quoted+=digits[ch>>4];quoted+=digits[ch&15];}
  else quoted+=ch;
 }
 const std::string runs="{\"replace\":true,\"runs\":[{\"text\":\""+quoted+"\",\"style\":\"normal\"}],\"autoscroll\":true}";
 host.text_runs(Output,runs.c_str());
}
}
gx::WorkspaceValue orion_roi_source(const gx::Host& host){
 const auto& canvas=instance(host);const auto& selection=field(canvas,"selection");const auto& pages=field(canvas,"roi_pages");
 if(selection.kind!=V::Kind::array||selection.elements.size()!=1||selection.elements[0].kind!=V::Kind::text||pages.kind!=V::Kind::array||pages.elements.size()!=1)return V();
 const auto& page=pages.elements[0];if(page.kind!=V::Kind::object||text(page,"object")!=selection.elements[0].text||field(page,"dataset_id").kind!=V::Kind::text||text(page,"source_sha256").empty()||text(page,"source_revision").empty())return V();
 // CORE binds the page to this selected original image Resource. A Resource
 // without canonical identity has an empty Dataset ID; it never becomes one.
 // The diagnostic objects list may be truncated and is not absence authority.
 if(field(canvas,"revision").kind!=V::Kind::integer||field(page,"collection_revision").kind!=V::Kind::integer)return V();
 V copied=page;copied.fields["canvas_revision"]=field(canvas,"revision");copied.fields["canvas_id"]=field(canvas,"canvas_id");copied.fields["document_id"]=field(canvas,"document_id");copied.fields["canvas_generation"]=field(canvas,"generation");return copied;
}
bool orion_roi_event(gx::Host& host,gx::State& state,const gx::Event& event){
 if(event.kind!=gx::EventKind::invoke||event.component<78||event.component>85)return false;
 ++state.counter;
 try {
 if(event.component<=81){const char* tool=event.component==78?"roi_rectangle":event.component==79?"roi_select":event.component==80?"roi_translate":"roi_vertex";host.canvas_command(Canvas,"tool_set",gx::workspace_object({{"tool",gx::workspace_text(tool)}}));return true;}
 const V source=orion_roi_source(host);if(source.kind!=V::Kind::object)throw std::runtime_error("Select one current original image in the Canvas first.");
 V value=request(source);
 if(event.component==82){const auto id=text(source,"selected_roi_id");if(id.empty())throw std::runtime_error("Select an existing retained source ROI first.");value.fields["roi_id"]=gx::workspace_text(id);value.fields["expected_roi_revision"]=field(source,"collection_revision");host.canvas_command(Canvas,"roi_delete",value);return true;}
 std::int64_t offset=0;
 if(event.component==84){const auto& next=field(source,"next_offset");const auto& total=field(source,"total");if(next.kind!=V::Kind::integer||total.kind!=V::Kind::integer||next.integer>=total.integer)return true;offset=next.integer;}
 if(event.component==85){const auto& current=field(source,"offset");if(current.kind!=V::Kind::integer)return true;offset=current.integer>16?current.integer-16:0;}
 value.fields["offset"]=gx::workspace_integer(offset);value.fields["count"]=gx::workspace_integer(16);host.canvas_command(Canvas,"roi_list",value);return true;
 } catch(const std::exception& error){show_error(host,error.what());return true;}
}
