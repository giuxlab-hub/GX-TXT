// SPDX-License-Identifier: GPL-3.0-or-later
// Exact public P005 quantitative client logic adapted from shipped probe v0.2.1.
enum Component : unsigned {
    Canvas = 1,
    Source = 2,
    Bind = 0,
    Inspect = 51,
    Discover = 52,
    Operation = 38,
    X = 40,
    Y = 41,
    Width = 42,
    Height = 43,
    Channels = 39,
    Roi = 44,
    HistogramMode = 45,
    Bins = 46,
    DomainLow = 47,
    DomainHigh = 48,
    Offset = 50,
    Submit = 53,
    Status = 54,
    Cancel = 56,
    Result = 55,
    Page = 57,
    MapRoi = 58,
    Receipt = 60,
    Output = 61,
    JobInput = 49,
    Reconnect = 59,
    QuickStatistics = 62,
    QuickHistogram = 63,
    QuickPixelROI = 64,
    QuickDescribe = 65,
    CanvasDocument = 0,
    SaveCanvas = 0,
    OpenCanvas = 0,
};
const char CanvasName[] = "canvas_scene";
// SPDX-License-Identifier: GPL-3.0-or-later
// The component enum above comes from the actual Builder declaration order.
#include "orion_roi.hpp"
#include "orion_sii_editor_router.hpp"
#include <cstdio>
#include <limits>
#include <stdexcept>
#include <string>

namespace {
using Value = gx::WorkspaceValue;
std::string object_id, source_id, source_sha, source_revision, job_id, token, generation;
Value last_received, last_canvas;

const Value& field(const Value& value, const std::string& key) {
    static const Value absent;
    if (value.kind != Value::Kind::object) return absent;
    const auto found = value.fields.find(key);
    return found == value.fields.end() ? absent : found->second;
}
std::string text(const Value& value, const std::string& key) {
    const auto& item = field(value, key);
    return item.kind == Value::Kind::text ? item.text : std::string();
}
void clear_source() {
    source_id.clear(); source_sha.clear(); source_revision.clear();
    job_id.clear(); token.clear(); generation.clear();
}
// Proposed insert after original clear_source(), retaining its original body.
// MAIN will compose with ROI/processing helpers; these are inert consumer caches.
enum ReceiptInput : unsigned {ReceiptDataset=72, ReceiptSHA=73,
    ReceiptRevision=74, HistogramToken=75, HistogramGeneration=76};
void project_receipt(gx::Host& host,unsigned component,const std::string& value) {
    if(std::string(host.input(component))!=value)host.input_text(component,value);
}
void project_source_receipts(gx::Host& host) {
    project_receipt(host,ReceiptDataset,source_id);
    project_receipt(host,ReceiptSHA,source_sha);
    project_receipt(host,ReceiptRevision,source_revision);
    project_receipt(host,JobInput,job_id);
    project_receipt(host,HistogramToken,token);
    project_receipt(host,HistogramGeneration,generation);
}
void clear_source_inputs(gx::Host& host) {
    clear_source();
    host.input_text(Roi,"");
    // Always clear, even if a user entered a value beyond legacy input readback.
    host.input_text(ReceiptDataset,"");host.input_text(ReceiptSHA,"");
    host.input_text(ReceiptRevision,"");host.input_text(JobInput,"");
    host.input_text(HistogramToken,"");host.input_text(HistogramGeneration,"");
}

void render(const Value& value, std::string& out, unsigned depth = 0) {
    if (out.size() > 20000 || depth > 32) return;
    if (value.kind == Value::Kind::text) {out += value.text; return;}
    if (value.kind == Value::Kind::integer) {out += std::to_string(value.integer); return;}
    if (value.kind == Value::Kind::real) {
        char buffer[64]; std::snprintf(buffer, sizeof(buffer), "%.17g", value.real);
        out += buffer; return;
    }
    if (value.kind == Value::Kind::boolean) {out += value.integer ? "true" : "false"; return;}
    if (value.kind == Value::Kind::null) {out += "null"; return;}
    if (value.kind == Value::Kind::array) {
        out += "[\n";
        for (const auto& item : value.elements) {
            out += std::string(depth + 1, ' '); render(item, out, depth + 1); out += "\n";
            if (out.size() > 20000) break;
        }
        out += std::string(depth, ' ') + "]"; return;
    }
    out += "{\n";
    for (const auto& item : value.fields) {
        out += std::string(depth + 1, ' ') + item.first + ": ";
        render(item.second, out, depth + 1); out += "\n";
        if (out.size() > 20000) break;
    }
    out += std::string(depth, ' ') + "}";
}
void display_text(gx::Host& host, const std::string& value) {
    std::string escaped;
    const char digits[] = "0123456789abcdef";
    for (const unsigned char ch : value) {
        if (ch == '"' || ch == '\\') {escaped += '\\'; escaped += ch;}
        else if (ch < 32) {
            escaped += "\\u00"; escaped += digits[ch >> 4]; escaped += digits[ch & 15];
        } else escaped += ch;
    }
    const std::string runs = "{\"replace\":true,\"runs\":[{\"text\":\"" + escaped +
        "\",\"style\":\"normal\"}],\"autoscroll\":true}";
    host.text_runs(Output, runs.c_str());
}
void show(gx::Host& host, const std::string& heading) {
    std::string out = heading + "\nLast explicit Canvas receipt (Document ID is reusable by Open):\n";
    render(last_canvas, out);
    out += "\nLast typed quantitative CORE receipt; source identities remain explicit:\n";
    render(last_received, out);
    if (out.size() > 20000) {
        out.resize(20000);
        out += "\nDisplay truncated. The typed API receipt remains the authoritative result.\n";
    }
    display_text(host, out);
}
void receive(gx::Host& host) {
    const auto* canvas = host.canvas_result();
    if (canvas) {
        last_canvas = *canvas;
        const auto& instance = field(field(*canvas, "instances"), CanvasName);
        const auto& selected = field(instance, "selection");
        const auto& objects = field(instance, "objects");
        std::string candidate;
        if (selected.kind == Value::Kind::array && selected.elements.size() == 1 &&
            selected.elements.front().kind == Value::Kind::text) {
            const auto wanted = selected.elements.front().text;
            for (const auto& item : objects.elements) {
                if (text(item, "logical_id") == wanted && text(item, "kind") == "image") candidate = wanted;
            }
        }
        const auto source_page = orion_roi_source(host);
        if (source_page.kind == Value::Kind::object) candidate = text(source_page, "object");
        if (candidate != object_id) {
            const bool changing_known_object = !object_id.empty();
            object_id = candidate;
            // A cold-open cache is empty: preserve restored presentation fields
            // until a real source/object transition or authoritative rediscovery.
            if (changing_known_object) clear_source_inputs(host);
            else clear_source();
        }
    }
    const auto* receipt = host.quantitative_raster_result();
    if (!receipt || receipt->kind != Value::Kind::object) return;
    last_received = *receipt;
    // Discovery must match the selected CORE image, independently of the
    // import dropdown. These presentation caches confer no source authority.
    const auto discovered = text(*receipt, "dataset_id");
    const auto selected_source = orion_roi_source(host);
    if (!discovered.empty() && selected_source.kind == Value::Kind::object &&
        discovered == text(selected_source, "dataset_id")) {
        source_id = discovered; source_sha = text(*receipt, "source_sha256");
        source_revision = text(*receipt, "source_revision");



    }
    const auto received_job = text(*receipt, "job_id");
    const std::string explicit_job = host.input(JobInput);
    if (!source_id.empty() || (!received_job.empty() && received_job == explicit_job)) {
        const auto returned_job = received_job;
        if (!returned_job.empty()) job_id = returned_job;
        const auto& output = field(*receipt, "histogram_output");
        if (output.kind == Value::Kind::object) {
            token = text(output, "token"); generation = text(output, "source_generation");


        }
    }
    if (!source_id.empty()) {
        const auto current = orion_roi_source(host);
        if (current.kind != Value::Kind::object || text(current,"dataset_id") != source_id ||
            text(current,"source_sha256") != source_sha || text(current,"source_revision") != source_revision) {
            clear_source_inputs(host);
        } else {
            project_source_receipts(host);
            const std::string selected_roi=text(current,"selected_roi_id");
            if (!selected_roi.empty()) project_receipt(host,Roi,selected_roi);
        }
    } else if (!job_id.empty()) {
        project_receipt(host,JobInput,job_id);
        project_receipt(host,HistogramToken,token);
        project_receipt(host,HistogramGeneration,generation);
    }
}
const char* numeric_field_name(unsigned component) {
    switch (component) {
        case X: return "X";
        case Y: return "Y";
        case Width: return "Width";
        case Height: return "Height";
        case Bins: return "Histogram bins";
        case Offset: return "Histogram page offset";
        case DomainLow: return "Histogram lower edge";
        case DomainHigh: return "Histogram upper edge";
        default: return "Numeric field";
    }
}
std::runtime_error numeric_input_error(unsigned component, const char* requirement) {
    return std::runtime_error(std::string(numeric_field_name(component)) + ": " + requirement +
        " No request was submitted.");
}
std::int64_t integer_input(gx::Host& host, unsigned component) {
    const std::string value = host.input(component);
    std::size_t end = 0;
    std::int64_t result;
    try {
        result = std::stoll(value, &end);
    } catch (const std::invalid_argument&) {
        throw numeric_input_error(component, "Enter an exact integer.");
    } catch (const std::out_of_range&) {
        throw numeric_input_error(component, "Enter a signed 64-bit integer within range.");
    }
    if (end != value.size()) throw numeric_input_error(component, "Enter an exact integer without trailing characters.");
    return result;
}
double real_input(gx::Host& host, unsigned component) {
    const std::string value = host.input(component);
    std::size_t end = 0;
    double result;
    try {
        result = std::stod(value, &end);
    } catch (const std::invalid_argument&) {
        throw numeric_input_error(component, "Enter an explicit finite number.");
    } catch (const std::out_of_range&) {
        throw numeric_input_error(component, "Enter a finite number within the representable range.");
    }
    if (end != value.size()) throw numeric_input_error(component, "Enter a finite number without trailing characters.");
    const double largest = std::numeric_limits<double>::max();
    if (!(result >= -largest && result <= largest)) throw numeric_input_error(component, "Enter a finite number.");
    return result;
}

void require_object() {
    if (object_id.empty()) throw std::runtime_error("Bind and select one canonical source image in the Canvas first.");
}
Value job_request(gx::Host& host) {
    const std::string entered=host.input(JobInput);
    if (!job_id.empty() && entered!=job_id)
        throw std::runtime_error("Read the current Job receipt or explicitly reconnect the entered Job ID.");
    const std::string selected = entered;
    if (selected.empty()) throw std::runtime_error("Submit a measurement or enter its durable Job ID first.");
    return gx::workspace_object({{"job_id", gx::workspace_text(selected)}});
}
}

bool orion_quantitative_event(gx::Host& host, gx::State& state, const gx::Event& event) {
    if (event.kind == gx::EventKind::open) {
        object_id.clear(); clear_source(); last_received = Value(); last_canvas = Value();
        host.canvas_command(Canvas, "inspect", gx::workspace_object({}));
        display_text(host, "Select a canonical raster, then Bind source and Discover source.");
        return true;
    }
    if (event.kind != gx::EventKind::invoke ||
        !((event.component >= Inspect && event.component <= Receipt) ||
          event.component == QuickStatistics || event.component == QuickHistogram ||
          event.component == QuickPixelROI || event.component == QuickDescribe)) return false;
    ++state.counter;
    try {
        receive(host);
        if (event.component == Bind) {
            object_id.clear(); clear_source(); last_received = Value();
            host.canvas_command(Canvas, "bind_source", gx::workspace_object({
                {"source_selector", gx::workspace_integer(Source)}
            }));
            show(host, "Canonical source bind requested. Discover source reads the next CORE receipt.");
        } else if (event.component == Inspect) {
            host.canvas_command(Canvas, "inspect", gx::workspace_object());
            show(host, "Canvas inspection requested. Show received data reads the next receipt.");
        } else if (event.component == SaveCanvas) {
            host.canvas_command(Canvas, "save", gx::workspace_object());
            show(host, "Canvas Save requested. Show received data exposes its exact Document ID.");
        } else if (event.component == OpenCanvas) {
            const std::string document = host.input(CanvasDocument);
            if (document.empty()) throw std::runtime_error("Enter the existing Canvas Document ID first.");
            object_id.clear(); clear_source(); last_received = Value(); last_canvas = Value();
            host.canvas_command(Canvas, "open", gx::workspace_object({
                {"document_id", gx::workspace_text(document)}
            }));
            show(host, "Canvas Open requested. Inspect Canvas and Show received data expose its retained identity.");
        } else if (event.component == Discover) {
            require_object();
            host.quantitative_raster_command(Canvas, "discover", gx::workspace_object({
                {"object", gx::workspace_text(object_id)}
            }));
            show(host, "Source discovery requested.");
        } else if (event.component == Submit || event.component == QuickStatistics ||
                   event.component == QuickHistogram || event.component == QuickPixelROI ||
                   event.component == QuickDescribe) {
            require_object();
            if (source_id.empty() || source_sha.empty() || source_revision.empty())
                throw std::runtime_error("Discover the selected canonical source before submitting.");
            const auto current_source = orion_roi_source(host);
            const std::string field_source=host.input(ReceiptDataset), field_sha=host.input(ReceiptSHA), field_revision=host.input(ReceiptRevision);
            if (current_source.kind != Value::Kind::object || field_source!=source_id ||
                field_sha!=source_sha || field_revision!=source_revision ||
                text(current_source,"dataset_id")!=field_source ||
                text(current_source,"source_sha256")!=field_sha ||
                text(current_source,"source_revision")!=field_revision)
                throw std::runtime_error("Read the current source receipt, then submit with its unchanged typed fields.");
            const std::string operation = event.component == QuickStatistics ? "statistics"
                : (event.component == QuickHistogram ? "histogram"
                : (event.component == QuickPixelROI ? "pixel"
                : (event.component == QuickDescribe ? "describe" : host.input(Operation))));
            std::string requested_roi=text(current_source,"selected_roi_id");
            if (requested_roi.empty()) requested_roi=host.input(Roi);
            if (event.component == QuickPixelROI && requested_roi.empty())
                throw std::runtime_error("Read pixel at ROI origin requires an existing retained source ROI ID.");
            auto request = gx::workspace_object({
                {"object", gx::workspace_text(object_id)},
                {"operation", gx::workspace_text(operation)},
                {"expected_sha256", gx::workspace_text(field_sha)},
                {"expected_revision", gx::workspace_text(field_revision)},
                {"channels", gx::workspace_text(host.input(Channels))},
                {"frame", gx::workspace_integer(0)}
            });
            if (operation != "describe") {
                const std::string roi = requested_roi;
                if (!roi.empty()) request.fields["roi_id"] = gx::workspace_text(roi);
                else {
                    request.fields["x"] = gx::workspace_integer(integer_input(host, X));
                    request.fields["y"] = gx::workspace_integer(integer_input(host, Y));
                    if (operation != "pixel") {
                        request.fields["width"] = gx::workspace_integer(integer_input(host, Width));
                        request.fields["height"] = gx::workspace_integer(integer_input(host, Height));
                    }
                }
            }
            if (operation == "histogram") {
                const std::string mode = host.input(HistogramMode);
                request.fields["histogram_mode"] = gx::workspace_text(mode);
                if (mode == "bounded") {
                    request.fields["bins"] = gx::workspace_integer(integer_input(host, Bins));
                    request.fields["domain_low"] = gx::workspace_number(real_input(host, DomainLow));
                    request.fields["domain_high"] = gx::workspace_number(real_input(host, DomainHigh));
                }
            }
            host.quantitative_raster_command(Canvas, "submit", request);
            show(host, std::string("Original-source ") + operation +
                " measurement requested. The managed CORE Job must reach COMPLETED; use Job status, then Get result.");
        } else if (event.component == Status || event.component == Cancel || event.component == Result) {
            const char* operation = event.component == Status ? "status" : event.component == Cancel ? "cancel" : "result";
            host.quantitative_raster_command(Canvas, operation, job_request(host));
            if (event.component == Cancel) clear_source_inputs(host);
            show(host, std::string("Requested ") + operation + ". Show received data reads the next receipt.");
        } else if (event.component == Page) {
            auto request = job_request(host);
            if (token.empty() || generation.empty()) throw std::runtime_error("Get a completed histogram result before requesting its count page.");
            const std::string field_token=host.input(HistogramToken), field_generation=host.input(HistogramGeneration);
            if (field_token!=token || field_generation!=generation)
                throw std::runtime_error("Read the completed histogram receipt before using its unchanged typed fields.");
            request.fields["token"] = gx::workspace_text(field_token);
            request.fields["generation"] = gx::workspace_text(field_generation);
            request.fields["offset"] = gx::workspace_integer(integer_input(host, Offset));
            request.fields["count"] = gx::workspace_integer(256);
            host.quantitative_raster_command(Canvas, "histogram_page", request);
            show(host, "Requested at most 256 original-domain histogram counts.");
        } else if (event.component == MapRoi) {
            require_object();
            std::string roi=text(orion_roi_source(host),"selected_roi_id");
            if (roi.empty()) roi=host.input(Roi);
            if (roi.empty()) throw std::runtime_error("Enter or select an existing retained source ROI ID to map.");
            host.quantitative_raster_command(Canvas, "map_roi", gx::workspace_object({
                {"object", gx::workspace_text(object_id)}, {"roi_id", gx::workspace_text(roi)}
            }));
            show(host, "Retained source ROI mapping requested.");
        } else if (event.component == Reconnect) {
            const std::string requested = host.input(JobInput);
            if (requested.empty()) throw std::runtime_error("Enter the durable Job ID to reconnect.");
            host.quantitative_raster_command(Canvas, "reconnect", gx::workspace_object({
                {"job_id", gx::workspace_text(requested)}
            }));
            show(host, "Reconnection requested. CORE verifies the matching saved Canvas and closed earlier view owner.");
        } else if (event.component == Receipt) {
            show(host, "Received typed CORE data; no additional measurement or polling was requested.");
        }
    } catch (const std::exception& error) {
        display_text(host, error.what());
    }
    return true;
}

// ORION-SII Canvas 1.0.6. This is a restricted C++ Viewer handler.
// All Canvas editing and scientific resources belong to GX-TXT P003 CORE.
// No Tcl/Tk calls, file access, private native pointers, custom spline
// interpolation, independent layer model, or background rendering pipeline.
void on_event(gx::Host& host, gx::State& state, const gx::Event& event) {
    if (event.kind==gx::EventKind::changed && event.component==Source) {
        clear_source_inputs(host); object_id.clear(); last_received=Value(); last_canvas=Value();
    }
    // Processing's source/reset and event hooks are added at its owner handoff.
    if (orion_roi_event(host,state,event)) return;
    if (orion_quantitative_event(host, state, event)) return;
    if (event.kind == gx::EventKind::invoke && event.component == 4) {
        clear_source_inputs(host); object_id.clear(); last_received=Value(); last_canvas=Value();
    }
    if (orion_sii_editor_event(host, event)) return;
    if (event.kind != gx::EventKind::invoke) return;
    if (event.component == 4) {
        clear_source_inputs(host); object_id.clear(); last_received=Value(); last_canvas=Value();
        host.canvas_command(1, "bind_source",
            gx::workspace_object({{"source_selector", gx::workspace_integer(2)}}));
    } else if (event.component == 5) {
        host.canvas_command(1, "filter",
            gx::workspace_object({{"name", gx::workspace_text("grayscale")}}));
    } else if (event.component == 6) {
        host.canvas_command(1, "filter",
            gx::workspace_object({{"name", gx::workspace_text("invert")}}));
    } else if (event.component == 7) {
        host.canvas_command(1, "save", gx::workspace_object({}));
    } else if (event.component == 8) {
        host.canvas_command(1, "undo", gx::workspace_object({}));
    } else if (event.component == 9) {
        host.canvas_command(1, "redo", gx::workspace_object({}));
    } else if (event.component == 10) {
        host.canvas_command(1, "fit", gx::workspace_object({}));
    } else if (event.component == 11) {
        host.canvas_command(1, "new",
            gx::workspace_object({
                {"width", gx::workspace_integer(1600)},
                {"height", gx::workspace_integer(1000)}
            }));
    } else if (event.component == 12) {
        // Explicitly derive a NEW RGBA8/sRGB image; never overwrite the
        // canonical scientific Dataset or claim floating-point precision.
        host.canvas_command(1, "publish",
            gx::workspace_object({
                {"dataset_id", gx::workspace_text(host.input(3))},
                {"name", gx::workspace_text("ORION Canvas derived image")},
                {"format", gx::workspace_text("png")},
                {"precision", gx::workspace_text("rgba8")}
            }));
    } else if (event.component == 13) {
        host.canvas_command(1, "cancel", gx::workspace_object({}));
        clear_source_inputs(host);
    } else if (event.component == 19) {
        host.canvas_command(1, "copy", gx::workspace_object({}));
    } else if (event.component == 20) {
        host.canvas_command(1, "cut", gx::workspace_object({}));
    } else if (event.component == 21) {
        host.canvas_command(1, "paste", gx::workspace_object({}));
    } else if (event.component == 22) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("select")}}));
    } else if (event.component == 23) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("spline")}}));
   
    } else if (event.component == 25) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("rectangle")}}));
    } else if (event.component == 26) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("ellipse")}}));
    } else if (event.component == 27) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("line")}}));
    } else if (event.component == 28) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("arrow")}}));
    } else if (event.component == 29) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("text")}}));
    } else if (event.component == 30) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("translate")}}));
    } else if (event.component == 31) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("rotate")}}));
    } else if (event.component == 32) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("pivot")}}));
    } else if (event.component == 33) {
        host.canvas_command(1, "layer_create",
            gx::workspace_object({{"name", gx::workspace_text("New layer")}}));
    } else if (event.component == 34) {
        host.canvas_command(1, "selection_set",
            gx::workspace_object({
                {"objects", gx::workspace_array({})},
                {"mode", gx::workspace_text("replace")}
            }));
    } else if (event.component == 35) {
        host.canvas_command(1, "tool_set",
            gx::workspace_object({{"tool", gx::workspace_text("pan")}}));
    }
}
