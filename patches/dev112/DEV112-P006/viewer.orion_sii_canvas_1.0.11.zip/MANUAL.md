# ORION Scientific Image Inspector — Native Canvas 1.0.7

This Viewer targets the cumulative GX-TXT DEV112-P006 framework. Install its
standard module ZIP through Plugin Manager. Use an active Session and keep the
configured scientific runtimes available. CORE activates the declared Scientific
Image Inspector service independently of selecting its older Viewer.
Image processing requires an HDRI ImageMagick runtime; an incompatible runtime
is refused before processing. Managed image processing currently uses local
execution. Choosing a remote destination does not silently switch it to local.

## Source images and scientific identity

Select a canonical image Dataset in **Scientific raster Dataset**, then use
**Place image**. **Open image read-only** provides an explicit local-file chooser;
GX-TXT captures the selected image through its existing ScientificIO and Document
Resource services. Cancelling the chooser preserves the current image. Opening
an image does not publish a Dataset or change the selected file.

The full original source and its identity remain authoritative. Display previews,
comparison views and level-of-detail crops are presentation images. They do not
replace source pixels or provide a measurement calibration. A local Resource is
not treated as a previously selected canonical Dataset. Use an explicitly
published canonical Dataset when the quantitative operation requires one.

## Canvas and retained source ROIs

Use the Native2D multilayer Canvas for selection, layers, native vector objects,
text, transforms, pan, fit and native Undo/Redo. Select the source image before
creating a retained source ROI.

- **Draw source rectangle** creates a retained rectangle on the original source.
- **Select source ROI**, **Move source ROI** and **Edit ROI vertex** use the
  existing Canvas tools. **Delete selected ROI** removes the selected ROI.
- **List source ROIs**, **Next ROI page** and **Earlier ROIs** browse the retained
  list. The selected ROI ID is supplied by CORE, not inferred from a display box.

Quantitative operations accept only their supported source ROI geometries.
Unsupported polygons or rotated measurement regions are refused rather than
approximated. Source image bytes remain unchanged by ROI and Canvas edits.

## Image processing

Choose **Basic Editor** or **Advanced Editor**, then select an **Editor mode**
and an **Original catalog/preset/annotation item**. The original SII catalog
provides supported operations, presets and parameter constraints. Select a
**Parameter page** to edit the displayed parameter names and values; subsequent
pages retain earlier values. Invalid parameters are rejected by the original
scientific service.

Choose **Processing scope** (`all` or `selected ROI`) and use **Validate** before
**Preview**. Processing is a managed asynchronous Job. Use **Job status** to
follow it, **Cancel processing** to request cancellation, and **Accept preview**
or **Discard preview** after completion. A pending preview does not overwrite the
accepted working image or original source. Editing is guarded while processing
is pending.

**Step index** and **Remove selected step** edit the original processing sequence.
Image **Undo** and **Redo** navigate the shared native Canvas History.
For an image with a verified retained original, **Restore original (keep source
Dataset)** and **Reset image** restore that selected image through the guarded
original-source Canvas snapshot. Accepted changes enter the shared Canvas History.
For a flattened result, those actions instead undo only a proven immediate
flatten transition, restoring the entire pre-flatten composition. They navigate
existing Canvas History rather than add a restoration edit. Later, copied or
unproven transitions are refused; use Canvas Undo explicitly to reach the
pre-flatten composition.

**Synchronized comparison**, **Pixel grid**, **Show / Hide pending adjustment**
and **Actual display pixels (1:1 LOD preview)** control presentation. A cropped
LOD image remains positioned within the full source geometry.

## Figure Studio and analysis

Use **Figure Studio** with **Figure settings**, **Panel** or **Annotation** mode.
Edit the displayed parameter pages, then use **Add/update selected panel or
annotation** or **Remove selected panel or annotation**. **Panel index or
Annotation ID** identifies the entity. **Figure Undo** and **Figure Redo** navigate the same native Canvas History.
**Reset figure** is recorded as an accepted Canvas edit and can be undone there. Annotation selection and
Copy/Paste remain separate from source ROI selection.

For the original SII analysis, choose **Analysis target**, **Analysis channel**
and **Original SII analysis**, then **Run original SII analysis**. Pixel analysis
uses **Pixel X** and **Pixel Y**; palette analysis uses **Palette colors**. The
report identifies the chosen Source, Working or Preview target. Display-channel
previews do not change the full scientific source.

## Original-source quantitative measurements

Select the canonical source image in the Canvas, then use **Inspect image** and
**Discover source**. The import dropdown does not determine the measurement
target. Choose `describe`, `pixel`, `statistics` or `histogram`, the supported
source channel, and the required integer source coordinates and dimensions.
A retained ROI ID must identify a real ROI belonging to that source.

**Submit measurement** returns a managed Job ID. Use **Job status**, **Get result**
and **Show receipt** to inspect the typed response. Receipt Dataset ID, SHA-256
and revision fields are supplied through controlled typed field updates and do
not grant authority to alter a source. Invalid or stale identities are refused.

Native integer histograms use their supported exact domain. Bounded histograms
require an explicit bin count and finite edges. **Histogram page** retrieves a
bounded page of exact counts. **Cancel Job** and **Reconnect Job** use the
existing Job owner and its durable source/view guards.

## Publication, Workspace and History

Publication requires a canonical source Dataset. If you opened a local image
read-only, first import its source through the normal Acquisition workflow and
select that canonical Dataset before processing. Direct publication from a
transient local source is refused; there is no implicit source import.

Set **New Dataset ID** and **Publication format**, then **Publish derived result**.
The scientific publication formats are `png16`, `tiff16` and `tiff32f`. Integer
formats and floating-point formats have different numerical meanings; select the
format appropriate to the result. Publication creates a separate canonical
Dataset with provenance and leaves the original Dataset unchanged. Preview and
acceptance alone do not publish it. The older Canvas Publish action is a display
raster derivative and is separate from scientific processing publication.

Use normal Workspace Save, Close and Open. Canvas objects, retained ROIs,
processing/figure state and declared quantitative inputs belong to CORE's
Workspace lifecycle. A successful new Canvas edit after Undo clears that Canvas
redo branch; a failed or cancelled staged edit preserves it. Outer Workspace
History browsing remains read-only until you return to latest or explicitly
restart there. Opening a Workspace does not grant
permission to rerun a Job or bypass a changed source revision.

Build and export this project using the normal Viewer Builder workflow. Package
construction and successful compilation are separate from scientific and GUI
acceptance; the final P006 handoff records validation for the frozen release.
