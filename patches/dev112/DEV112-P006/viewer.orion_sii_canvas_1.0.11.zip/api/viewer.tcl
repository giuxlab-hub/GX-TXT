# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted generated facade; author logic is restricted C++ in a separate worker.
::GX::workbenchExtensionRequireApi VIEWER_DEVELOPMENT_API_v1
namespace eval ::GX::Restricted_viewer_orion_sii_canvas {variable root [file dirname [file dirname [info script]]]}
proc ::GX::Restricted_viewer_orion_sii_canvas::handlers {} {return [::GX::viewerDevelopmentInstalledBindings viewer.orion_sii_canvas orion_sii_canvas [set ::GX::Restricted_viewer_orion_sii_canvas::root]]}
proc ::GX::Restricted_viewer_orion_sii_canvas::dispatch {operation scene} {return [::GX::viewerDevelopmentInstalledOpen viewer.orion_sii_canvas orion_sii_canvas [set ::GX::Restricted_viewer_orion_sii_canvas::root] [::GX::datasetPublicationV2DictDefault $scene open_context {}]]}
proc ::GX::Restricted_viewer_orion_sii_canvas::workspaceOpen {context} {return [::GX::viewerDevelopmentInstalledOpen viewer.orion_sii_canvas orion_sii_canvas [set ::GX::Restricted_viewer_orion_sii_canvas::root] $context]}
proc ::GX::Restricted_viewer_orion_sii_canvas::texOpen {document} {return [::GX::viewerDevelopmentInstalledOpen viewer.orion_sii_canvas orion_sii_canvas [set ::GX::Restricted_viewer_orion_sii_canvas::root] [dict create tex_document_id $document]]}
::GX::viewerBackendRegister viewer_orion_sii_canvas_restricted_cpp_v1 ::GX::Restricted_viewer_orion_sii_canvas::dispatch
