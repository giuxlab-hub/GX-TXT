# P006 acceptance results

Source: `6498d8d241e3fb8e8c48db1e9d3ce3dd0c2d393e`; 6,362 managed source files. Patch SHA256: `d62ff22bd824e1dcdfaece27243ae958a5d20d1ec624d0b33d45be79fc2a7ed6`.

| Revised matrix area | Actual evidence |
| --- | --- |
| Installation, rollback, compatibility | Exact new archive installed and authentically rolled back on both r2 and post-P005. Complete bytes/modes and unrelated Session preservation passed. SDK/native binaries are unchanged. |
| Science and precision | Independent f32/u64/i64 exact-byte, descriptor, units and source-identity acceptance; unchanged prior science and i16/u16 evidence reused. |
| Security and ownership | Existing shared guard/ownership evidence reused; new bindings independently reviewed and scoped refusal checks retained. No new grants. |
| Jobs and recovery | Accepted execution/progress/cancel/terminal evidence reused. Unchanged recovery source retains PENDING/FINALIZING and resources until recovery succeeds. |
| Five-file C++ demonstration and GUI | Accepted original Numeric/Plot workflow, build, installation and persistence evidence reused. |
| Required API coverage | Six value bindings, raw/legacy recipe support, three Native3D and ten corrected design operations implemented and independently accepted. Catalog adds exactly19 script operations; 1,800 script descriptors total. No functionality deferred. |
| Persistence and Slides | Accepted Workspace/Plot and W03/S01-S20 evidence reused. |
| Release integrity | Exact source/manifest/archive checks complete. Final independent decision binds the actual patch and outer bundle in adjacent FINAL_ACCEPTANCE.json. |

This is the pre-publication result snapshot. The original revised matrix and historical 100-ID map remain unchanged for traceability. Actual accepted, failed and unexecuted evidence remains distinct. A02 is withdrawn; ORION/SII remain frozen. No production activation.
