# P006 API contracts

The shared Script Bridge registry retains existing API/version/provider identities and declaring-owner activation. Generic C++ calls use the same eligible descriptors and capability/source checks as Python and Octave. Native Job requests retain canonical local/registered remote Node ownership; exact typed bytes, descriptors, units and provenance are preserved.

The six supplied-value bindings and raw/legacy recipe path are documented in docs/api/P006_SUPPLIED_VALUE_BINDINGS.md. Structured native Tcl results use an explicit four-String whole-value carrier when no universal high-level schema exists. It is inert data, never a callback, command, Resource grant or recovered scientific type. Original defaults and weak predicates remain original behavior. Transport limits refuse oversized outcomes instead of truncating them.

Native3D load_mesh/load_step/restore_step use the existing owned scene and managed Resource intake. Component/design operation contracts identify original arguments, full result representation and provider context. Viewer gui_test.close remains a host-only attached-window lifecycle action with its original connection/snapshot/Session/fixture guards.

No C++ facade, metadata declaration or whole-value carrier bypasses host authority. Existing SDK ABI and legacy encoded recipe input/output remain compatible. Exact operation contracts and source provenance are recorded in the regenerated shared catalog and source manifest.
