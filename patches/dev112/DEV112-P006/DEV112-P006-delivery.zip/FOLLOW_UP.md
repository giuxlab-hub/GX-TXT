# Nonblocking follow-up and retained limitations

The full required P006 functionality remains in this release. No missing public API has been assigned to a later patch.

- ORION 1.0.11 and SII 0.4.37 remain frozen under the owner's separate decision. Their unfinished development belongs to a future patch.
- Optional symbolic Tcl/allocator proofs, diagnostic instrumentation campaigns and broader publication permission-fault coverage remain retained engineering work. Their historical failed/unexecuted statuses are preserved; they are not prerequisites for this risk-based release and are not reported as PASS.
- The original values of the two historical shared cache/temp Configuration fields remain unknown. No guessed restoration or other-profile investigation was performed. Future restoration requires an authentic retained configuration value or an explicit owner decision.
- The cumulative installer is atomic per file. An interrupted mixed state requires retained receipts and explicit restoration from backup; no whole-tree atomicity or automatic interrupted-install continuation is claimed. Normal installation and authentic receipt-based rollback are checked separately.

Original technical evidence remains available in the retained DEV112-P006 scratch tree. The historical 100-ID map is included for traceability. Current release acceptance uses the revised eight-row matrix and archive-bound records; historical labels are not rewritten.
