# GX-TXT DEV112-P006

Cumulative framework patch for DEV112.r2 or the exact post-P005 baseline. The framework remains version 0.9.8.10-dev-112; the patch level is 006.

P006 provides shared C++ Script Bridge access, supervised local and remote Jobs with correlated callbacks and typed results, the five-file Numeric/Plot demonstration, required public API bindings, and scientific 16:9 slide editing and export. Added value and design adapters call the existing owners; they do not duplicate scientific engines or grant host input authority.

Use INSTALLAZIONE.md in the delivery root for checks, installation and receipt-based rollback. FILES.json records the exact managed postimage and both admitted baselines. ASSEMBLY.json records the source commit and archive identities.

ORION 1.0.11 and Scientific Image Inspector 0.4.37 are supplied unchanged under the owner's freeze decision. Their further development belongs to a separate patch.

Acceptance follows the owner-authorized eight-row risk matrix. Historical failures and unexecuted checks retain their original statuses; they are not converted to PASS. See VALIDATION.json and the delivery acceptance record for actual results. A02 was withdrawn by the owner. Depositing this release does not activate an installation.
