# Owner handoff

Deliver the cumulative P006 archive using the exact source, manifest, helper and checksums recorded alongside it. Keep the completed installation receipt and its independently retained SHA256 for rollback. The patch accepts only DEV112.r2 or exact post-P005, including the managed file modes; it does not force a modified installation into an accepted state.

The revised eight-row acceptance matrix retains the full required P006 implementation scope. No API functionality has been assigned to a future patch. A02 remains withdrawn. ORION 1.0.11 and SII 0.4.37 remain frozen under the separate owner decision.

Reuse of independently accepted evidence is explicit. The nine prior adapters, unchanged scientific/GUI/Slides behavior and earlier Job checks are not replayed solely to refresh a label. The new six-value/recipe, Native3D and component/design batches have their own scoped author and independent review records. Typed f32/u64/i64 results were retrieved through the normal installed C++ SDK workflow and compared byte-for-byte with retained references; the UI's structural UNVERIFIED label was not rewritten into scientific approval.

The two historical shared Configuration cache/temp values remain unknown. No guessed restoration was attempted. This delivery does not change scientific data or activate the framework. Installation and rollback apply only to the stopped operator-selected target.
