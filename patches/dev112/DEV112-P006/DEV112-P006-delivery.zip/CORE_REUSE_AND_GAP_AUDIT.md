# CORE reuse and remaining limitations

The adapters reuse the original CORE/module algorithms, owner registrations and normal shared Script Bridge admission. No duplicate Numeric, OCR, table, geometry, recipe, Workspace or Job engine is introduced. The generic C++ frontend consumes the same eligible catalog; no discretionary C++ API allowlist is added.

Opaque whole Tcl values preserve native structured results, open fields and Unicode spellings without inventing scientific schemas. The existing scalar/array/Struct transport remains available. Resource, Session, provider and capability checks remain authoritative. Design value helpers do not create host windows or mint GUI attachment authority. Native3D file intake requires the existing canonical Resource/scene ownership route.

Original 100-ID and campaign evidence is retained for traceability. Its historical procedural statuses are not additional automatic release gates under the owner's redesign. Optional allocator proofs, diagnostic campaigns and unexecuted permission-fault coverage remain engineering evidence/backlog; their statuses are not PASS. Required product functionality remains in P006.

Publication recovery preserves FINALIZING/PENDING and original terminal intent until recovery succeeds; failures are not reported as successful recovery or used to release authoritative resources prematurely. The source-risk disposition and retained runtime evidence are identified in the acceptance packet.

Known historical Configuration preference custody remains disclosed. Frozen ORION/SII development is outside this patch under the owner's explicit decision.
