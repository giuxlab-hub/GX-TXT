# SPDX-License-Identifier: GPL-3.0-or-later
# Run in the normal trusted CORE host with a current disposable Session.
# No optional Viewer supplies these services. The module/provider must be an
# existing admitted Interactive Document contributor in that host.
proc canvasExample {module provider parent} {
    set handle [::GX::native2DCanvasCreate $module $provider \
        {width 800 height 600 background {1 1 1 1}}]
    ::GX::native2DCanvasMount $handle $parent
    ::GX::native2DCanvasCommand $handle object_create \
        {definition {family rectangle controls {{50 50} {250 180}}} fill {0.1 0.4 0.8 0.5}}
    ::GX::native2DCanvasCommand $handle object_create \
        {definition {family spline controls {{50 220} {200 350} {400 100} {650 420}}} style {color {0.8 0.1 0.2 1}}}
    ::GX::native2DCanvasCommand $handle fit
    return $handle
}
