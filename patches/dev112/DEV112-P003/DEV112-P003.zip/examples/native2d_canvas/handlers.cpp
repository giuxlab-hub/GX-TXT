// SPDX-License-Identifier: GPL-3.0-or-later
// Declare native2d source_kind canvas at design index1, canonical raster
// dataset_selector content_kind raster at index2, action at index3.
// Request VIEWER_GUI_HOST_API_v1 canvas_command and raster_bind explicitly.
void on_event(gx::Host& host, gx::State&, const gx::Event& event) {
    if (event.kind != gx::EventKind::invoke || event.component != 3) return;
    host.canvas_command(1, "bind_source", gx::workspace_object({
        {"source_selector", gx::workspace_integer(2)}
    }));
}
