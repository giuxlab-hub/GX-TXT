# DEV112-P003 owner-review boundary

Source pin: `349a10dc94b813abd60a2721015358b1e87b2faa`. Runtime source is
unchanged from `78e2c59c51616783288b8ac81b444a7a6bd5cd01`; the last commit only
clarifies the public guide. Sole predecessor: exact DEV112.r2 → P001 → corrected
P002, full5457-file identity inventory pinned in FILES.json and the installer.

This is a strictly incremental CORE candidate. The separate original ordinary
Viewer ZIP is `viewer.canvas_demonstrator_1.0.0.zip`, SHA256
`68f3f821754703ed01cf06bcbd9544e27f90ef79c92929934b15eb13861f848c`.
Its actual Builder design is two columns/three action rows; all14 declaration
identities/order and C++ handlers/compiled output match the original authored
demo. It is a consumer, never a CORE implementation dependency.

The rebuilt Native2D binary is SHA256
`aaf33b6a89aba6aaab0b4db2fb2ffcbaf9994332f19e322e23bf2b3a930721c0`;
the rebuilt Document binary is
`62f2345aee77acaa6eb565e3ee35d7033811c15b3c5564d389bbbd037817691c`.
Both carry exact source/build receipts in their payload directories.

Public additions extend existing `NATIVE2D_API_v1@1` and
`VIEWER_GUI_HOST_API_v1@1`: finite Canvas lifecycle/commands/capture, opt-in
Builder `native2d` source_kind canvas, and finite Restricted C++
`Host::canvas_command`/borrowed `canvas_result` through opcode51. Existing SDK
layouts/opcodes and legacy default composition remain unchanged. The existing
typed Resource copier additionally admits owned Interactive Documents. Cached
Document read has an optional metadata-only projection with its default full
payload and old-native fallback preserved. Exact signatures, limits and reasons
are in the accompanying audit, architecture and public API documents.

Corrective evidence includes native retained mixed order/pixel/hit correctness,
source lineage, source-free/multiple instances, real spline/affine editing,
History/Workspace and cold identity, post-Undo presenter/current metrics/first
frame, locked reconstruction/copy, pending/running cancellation and photo
lifetime. The independent validator's four reports distinguish current checks
from historical failures, specialist evidence and harness corrections.

Measured limits are material: large1280-object selected scenes take about200ms
complete Tk service; mixed shape/spline commit releases have p95 about62/86ms.
Warm paint timings alone do not establish responsiveness. Paired legacy raster
preparation improves, but outer Tk-service tails vary on both baseline and
candidate; a blanket whole-service non-regression PASS is not asserted. The
performance report gives exact scope, percentiles, viewport differences,
CPU/RSS/resource ownership and criterion-level qualifications. No physical FPS
or leak-free process-memory claim is inferred from these measurements.

Derived display/filter/flatten/publication is RGBA8 sRGB with explicit provenance;
original scientific source bytes remain immutable. The tested float32 TIFF is
source-admissible but unsupported by the installed display/output decoder and
fails explicitly without adoption. Flat same-layer groups, similarity-only
calibrated raster transforms, bounded requests and full admitted flatten are
documented policies. New Canvas data requires P003 even if retained through a
framework rollback.

The external checksum-bound `OWNER_HANDOFF.md`, evidence inventory and
`SHA256SUMS` bind the actual final patch, independent chain results, separate demo
and portable evidence ZIP. They are delivered adjacent to this patch. This note
does not embed its containing archive's own hash. Follow README for read-only
check and separately authorized stopped-target apply/rollback.

Review deposit only: no official merge, active-framework update, plugin
activation, existing Viewer migration or user Session modification is authorized
or performed. The owner alone decides acceptance and integration. Qualified
performance findings and unsupported formats are not relabeled owner acceptance.
