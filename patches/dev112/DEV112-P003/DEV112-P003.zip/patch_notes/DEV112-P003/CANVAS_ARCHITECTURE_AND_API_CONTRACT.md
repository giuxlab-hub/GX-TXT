# Native Canvas architecture and public contract — DEV112-P003

2026-11-02, implementation contract revision 3. Derived from the completed
CORE_REUSE_AND_GAP_AUDIT.md and bounded Sol6.1 High review in
`../DEV112-P003-HIGH-20261102/NATIVE_CANVAS_DESIGN_REVIEW.md`. This document is a
design/implementation contract, not a claim that its operations already pass.
Any changed contract must update this document and its focused tests.

## Existing authorities and native responsibilities

Each Canvas is a native C++ facade over an existing independently owned gx2d
scene, first-class native layers/objects, compact existing identity attributes,
native CAD selection/controller and native SpriteScene source lease. Native C++
owns active layer, tool, selection orchestration, construction, provisional
gesture and native edit dispatch. Geometry/affine/control/spline math remains
the existing native scientific kernel. There is no second layer POD, geometry
engine, store, scheduler or History implementation.

Trusted CORE Tcl binds the facade to existing Interactive Document, Geometry
tokens, canonical Dataset/resource owners, native viewport, GUI scheduler,
Scientific History and native Workspace. It binds native input events and
receives native commit/cancel receipts; it does not implement shape algorithms
or retain a competing geometry model. The installable demo owns only declared
controls and a finite typed C++ client.

The Canvas document format is `gxtxt.native2d.canvas_scene.v1`, stored through
the existing Interactive Document owner. The creating module/provider remains
its normal author context; the CORE format/renderer/controller/codecs never
depend on that module's implementation. Explicit open checks document format,
owner/generation and source receipts before replacing a live instance. Instance
handles, native IDs, geometry tokens, widget paths and process resources are
transient. Stable Canvas/layer/object logical IDs survive ordinary/cold reopen.

Exactly one existing `gx.canvas` identity attribute per scene/layer/object holds
compact presentation/logical metadata. The scene entry holds stable Canvas ID,
extent/background and allocation metadata. Layer entries add logical ID, name
and compatible blend; native visible/selectable/locked/order/opacity remain
native fields. Object entries add logical ID, kind, local order, fill or bounded
text annotation. Existing 4096-attribute/16384-byte-value limits remain enforced;
ordinary bounded scene capacity is derived from those real limits, not a
one/two-Canvas restriction. Numeric native IDs are never public client targets.

## Native facade and renderer contract

The internal bridge creates `gx2d_canvas_v1_create(interp, sourceLease,
sceneId, backend, backendData)` through the existing `canvas_create` native
bridge operation. Its command exposes only:

```tcl
$native state
$native state scalar
$native command FINITE_OPERATION REQUEST_DICTIONARY
$native event down|move|up|key|wheel|resize EVENT_DICTIONARY
$native presentation
$native dispose
```

Finite native operations: configure, tool_set, layer_create, layer_update,
layer_delete, layer_assign, layer_select, object_create, object_adopt,
object_update, object_delete, object_affine, object_duplicate, object_group,
object_ungroup, selection_set, selection_pick, cancel. Exact fields are those
in the specialist contract; layer_select takes the one owned native `layer`.
Unknown fields, foreign IDs, invalid finite values and incompatible gestures
refuse before mutation. Native state enumerates actual scene objects/layers,
not a private replacement registry. The private scalar projection returns the
same nine header fields (alive, scene, tool, active_layer, gesture, revision,
extent, background, canvas_id) without traversing scene collections. Full state
retains its previous contract. Logical-ID collision checks use only a transient
owner-aware map for the current command; no persisted registry is introduced.
Presentation emits bottom-to-top descriptors
using stable logical IDs and the existing native objects.

The native facade reuses cancel-safe CAD translate/rotate/pivot and exact control
editing. Resize previews retain a presenter transform without retessellating
the source; release performs one existing native affine edit. Escape/tool
transition/unbind/source death cancels. Matrix layout is the existing kernel's
x'=m0*x+m1*y+m4; y'=m2*x+m3*y+m5. Calibrated images retain the existing
orientation-preserving similarity constraint; anisotropic/reflected raster
edits reject explicitly rather than falsifying calibration.

Extend the existing SpriteScene opt-in with `composition canvas`. Legacy mode,
ABI and source sampling retain their behavior. All vector/image/text/spline
rows share one retained sorted native item. Image surfaces are premultiplied
RGBA8 display derivatives keyed by verified resource/display identity, independent
of camera/gesture transforms. Text reuses the existing shaped text-photo/font
coverage engine and native retained glyph surfaces. A native anchor/rectangle
provides text bounds and transforms; no replacement spline/text engine.

Each contiguous native layer is painted to a Cairo group with object opacity,
then composed once using layer opacity and admitted blend. This preserves the
distinction between layer opacity and multiplying every object's ink. Initial
exact compatible modes are Over, Multiply, Screen, Overlay and SoftLight. Mask
and DstIn semantics cannot silently erase unrelated layers; unsupported output
or modes refuse. Dirty redraw recomposes intersecting contributors with the
necessary backdrop and retained native caches. Native source-close removes
all bound image/text/vector rows and releases their assets synchronously.

Native topmost picking follows the actual rendered order and existing semantic
hit services, skipping hidden/unselectable/locked objects/layers. Ordinary
selection is distinct from image-local scientific ROI. Grouping reuses native
flat groups of unique nongroup members; nested groups are unsupported and
explicitly rejected. Grouping keeps geometry editable. Clipboard/duplicate
allocates fresh logical IDs and raster UUIDs, remapping compatible mask links
or rejecting an unsafe foreign reference.

## Public host and Restricted C++ binding

Additive public host functions stay under existing `NATIVE2D_API_v1@1` and
`VIEWER_GUI_HOST_API_v1@1`; no new API identity or unbounded dispatcher.

```tcl
::GX::native2DCanvasCreate module provider ?options?
::GX::native2DCanvasMount handle parent ?options?
::GX::native2DCanvasCommand handle operation ?request?
::GX::native2DCanvasDescribe handle
::GX::native2DCanvasCapture handle
::GX::native2DCanvasRestore handle snapshot
::GX::native2DCanvasDispose handle
::GX::viewerGuiDesignCanvasCommand window component operation ?request?
::GX::viewerGuiDesignCanvasDescribe window component
```

Create requires an ordinary current Session for durable scientific editing, not
an imported image/Dataset. A source-free document has explicit finite positive
width/height, native coordinate frame and optional background. Mounting/sizing
uses ordinary native UI containers. Preview without scientific context displays
an explicit inactive state. Builder Design Preview remains an inert layout;
its ordinary compiled Runtime Test uses the installed matching Viewer package
and marked private GUI fixture/current Session for native editing.
Unbind/dispose cancels owned work and releases view resources without deleting
the authoritative Document or accepted History resources.

```cpp
void gx::Host::canvas_command(unsigned component, const char* operation,
                              const gx::WorkspaceValue& request) const;
const gx::WorkspaceValue* gx::Host::canvas_result() const noexcept;
```

Use existing typed client_request/client_result transport and a new unused
opcode51; preserve all existing layouts/opcodes/ABI. Explicit
VIEWER_GUI_HOST_API_v1 canvas_command grant, declared native2d component with
source_kind canvas, and the relevant scientific service grants are rechecked
by the ordinary compiler/runtime/host. Requests are finite dictionaries under
the existing 48KiB typed bound; resources/arrays are never smuggled as paths or
pixels. Result is borrowed immutable metadata for the last successful explicit
Canvas target in the next event. Before the first command, or after disposal of
that target, its existing instances map is empty. The map holds at most that
target. Layer/object/selection diagnostics shorten under the existing48KiB bound
with diagnostics_complete=false and exact layer/object totals; full trusted
Capture and Describe remain complete. Command-only clients receive no unused
context. Result is not a native pointer or mutation authority.
Component references retain the Builder's normal
one-based identities and existing SDK resource bounds.

Public finite operations: new, bind_source, tool_set, selection_set,
object_create, object_update, object_delete, object_affine, object_duplicate,
object_group, object_ungroup, copy, cut, paste, layer_create, layer_update,
layer_delete, layer_assign, layer_select, layer_reorder, merge, flatten,
filter, undo, redo, fit, zoom, pan, save, open, cancel, dispose, inspect,
publish. Native edits map to the exact native enums above; source, History,
filter, persistence/publication operations remain with their existing owners.
SDK requests use stable logical object/layer/document IDs and finite values;
the trusted host resolves them to owned native IDs. Source binding accepts a
declared compatible Dataset selector/logical canonical identity, never a path.
Publication needs its existing explicit canonical publication grant.

Every public mutator validates current Session lifetime, instance incarnation,
Document owner/generation/revision and request/source state before commit. An
optional supplied expected_revision must match; the actual host-held receipt is
always checked. `interactiveDocumentMetadata` supplies cheap owner metadata for
input admission; explicit snapshot/read boundaries retain full integrity checks.
Neither a stale asynchronous receipt nor a forged logical ID authorizes a write.

## Builder, controls, multiple instances and lifecycle

Extend existing `native2d` with `source_kind canvas` and bounded Canvas extent,
background and control-visibility properties. Existing native2d declaration,
duplicate/reparent/grid/pack/tab/splitter/identity rules remain authoritative.
The actual Builder exposes the Canvas mode/preset through its generic public
capability properties. No existing optional Viewer implementation is edited or
loaded as the Canvas implementation.

CORE offers reusable modest tool/layer/property controls, keyboard focus,
Escape/cancel and diagnostics scoped to that instance. Narrow actions use the
existing overflow menu; the inspector uses the existing horizontal scroll
container and focus reveal. Its allocation leaves a positive native viewport
at the actual supported font/DPI configurations. Status is one line with full
focus/F1 diagnostic text. These are opt-in extensions of the existing private
UiField owners, preserving their default callers; no new public GUI factory.
They invoke the public
Canvas owner; the demo does not implement the editor. All native callbacks,
selection, History records, current layer/tool, pending requests, image/text
assets and scheduler handles are per instance. Global registry variables may
map opaque handles to owners; they cannot hold shared active Canvas state.

One existing GUI_UPDATE_SCHEDULER handle per mounted Canvas presents the latest
native state. Motion changes native provisional state and requests that existing
scheduler; release Finish flushes the final frame. No private frame timer,
polling renderer, per-motion worker, full-widget replacement or panel reopening
is permitted. Window/Document/Session lifecycle invalidation cancels the exact
instance. Independent B remains usable when A changes, closes or fails.

## Complete snapshot, History and Workspace

Versioned Canvas snapshot uses existing scalar geometry/resource references and
exact native definitions, with finite fields:

```text
schema, document_id, generation, canvas_id, extent, background
layers [{logical_id name attributes properties blend}]
objects [{logical_id name resource style layer_logical_id source?}]
groups [{logical_id members name attributes style layer_logical_id}]
view_state, selection, active_layer, tool, retained_outputs
```

No native IDs, geometry/runtime tokens, widget paths or scheduler/reader handles
are persisted. Existing interactiveDocumentNative2DStore/Restore streams leaves
and exact sketch/tangent/image metadata. Save groups as logical memberships;
restore native groups after leaves and apply their own style/identity. Validate
the whole bounded referential graph before creating the provisional scene.
Restore into a fresh empty scene, verify sources/resources and renderer admission,
then swap; preserve the old valid scene until successful admission. Failure
closes the provisional scene and leaves visible state and durable science intact.

Register finite native Workspace shapes/codecs through existing
viewerWorkspaceCodecRegister and nativeWorkspaceEncode. Keep science/resource
types explicit; no parse-guessed strings or opaque scientific shadow store.
Viewer Workspace save captures every Canvas document/binding and independent
History coherently. Ordinary/cold reopen remaps logical IDs and re-admits actual
source generations/resources. Each Canvas uses its own existing Scientific
History record and cursor; Undo in A cannot advance B. Semantic commit creates
one History edit; provisional pointer motion creates none. Prior snapshot
resources remain retained by existing History/resource collection.

The enclosing Viewer History receives the Canvas contribution at completed
commits and through its existing before_transition hook before Save, Close or
navigation. Existing PrepareEdit enforces global browsing/read-only and explicit
branch review before mutation. Per-Canvas Undo/Redo records its contribution
after its document checkpoint completes. Operational document_receipt revisions
are excluded only from temporary semantic comparisons; persisted captures keep
complete actual receipts. No automatic append at a past cursor or while restoring.
During a held native gesture, Capture returns its original accepted snapshot
and enclosing capture retains the original nested History. Other Canvas results
cannot publish provisional coordinates or discard that held redo branch.
Fresh documents fit once before the first checkpoint; Mount preserves a saved
requested-world camera. Device viewport dimensions remain presentation state.
Restoration resizes the provisional native context to the current mapped widget
before renderer admission, binds the existing presenter, and synchronously
finishes its first frame before disposing the retired context. Pending work is
invalidated monotonically; current request sequence/cancellation state survives
the swap, while obsolete gesture checkpoints do not. Cancel tests the native
gesture flag so a post-commit callback cannot roll back an accepted edit.
Locked leaves and layers are provisionally unlocked only during reconstruction;
after grouping, their exact saved styles and properties are restored before
selection, presentation and adoption. Clipboard follows the same ordering.
Public lock guards remain unchanged.

Display-photo maps describe current admitted presentation ownership, not all
History resources. Successful presentation/document swaps retire obsolete photo
values, including same-key replacement; failed staging releases only newly
created values and preserves the accepted rows. Initially hidden raster content
does not decode until needed. Existing native aggregate32MP/128MiB admission is
checked before Tk allocation. No new scientific resource registry is introduced.

Layer duplication is a public composition recipe: copy complete groups and
ungrouped members, layer_create, paste into the returned new logical layer ID,
then layer_update. It produces ordinary separate edits; layer_create does not
change the active layer. Exact native definitions, fresh copied identities,
saved locked styles, Undo/Redo and cold reopen are tested without a new API.

Merge moves compatible native objects into one admitted target layer, retains
their editability and records one edit. Flatten explicitly materializes full
document/layer composition into a new managed raster result with provenance,
retaining/retiring old content according to the accepted snapshot/History.
Grouping does not rasterize. Interactive preview composition is not an accepted
derived raster. Hidden/locked states and incompatible layers must be handled
explicitly; no silently omitted native spline/object in output.

## Filters, output precision, cancellation and resource limits

Reuse existing core.native2d.raster managed provider and fixed ImageMagick
supervision. Add only finite image-object filter semantics for grayscale,
invert/negate, brightness/contrast, blur and sharpen, with bounded typed
parameters and explicit pixel/color units. Source-free/mixed flatten needs
explicit document extent/full mixed inclusion; screen pixels are not scientific
export. Actual output format/depth/alpha/profile, source SHAs, transforms,
parameters, software and output SHA must be recorded. Original bytes/precision
remain immutable. RGBA8 sRGB display/flatten output never claims original
16-bit/floating scientific value preservation. Unsupported precision/output
rejects clearly; existing native calibration constraints remain intact. Source
admission does not promise decoder support: the actual float32 TIFF fixture
retains its verified source reference but the installed Tk decoder reports an
encoding error and RGBA8 publication fails without adoption or Dataset mutation.
PNG16 input is tested with immutable original depth16 and explicit derived8.

Prepared work captures instance incarnation, Session token, Document ID,
generation/revision, request sequence and source manifest. Revalidate all before
freeze/adoption/History append. Cancellation invalidates adoption first, uses
existing scientificExecutionDiscard/Cancel and releases stale success leases.
No stale callback may update another/reopened Canvas. Respect actual provider
16-image/16777216-pixel, input8MiB, terminal16MiB and ordinary History/Workspace
bounds unless a separately justified compatible owner extension is recorded.

Snapshots retain the existing8MiB bound and at most4000 combined native layer,
leaf and group identities. The request bound can limit a single bulk operation
before that capacity (for example a large list of long logical IDs); this is an
explicit request refusal, not a lost scene. Typed Workspace resource-copy now
also admits an active Interactive Document destination through the same existing
copier and ownership guards. Nested raster/geometry clipboard uses that path.

Measured optimization reuses verified Resource/Document owners: existing cached
Document read optionally omits payload after the same integrity checks; default
full read and old-native fallback stay compatible. Resource hashing uses the
already present native immutable capture/digest for files up to4MiB, with the
original SHA helper fallback; no cache entry or source activation is created.
Per-capture provenance is computed once only when exporting new resources, using
the already supported metadata.origin parameter. No persistent identity cache.

## Implementation ownership and evidence obligations

MAIN owns Tcl Canvas/service/source/resource/History/Workspace integration,
Builder/SDK/policy/docs, fixed raster provider extension, demo authoring and
strict incremental patch preparation. Sol6.1 High owns native facade, compositor
and minimal bridge/CMake registration as an exclusive coherent batch. It may
delegate exclusive native-file subsets to its own subagents. Shared files are
edited only by their assigned owner; kernel changes need explicit MAIN review.

Independent Sol6.1 Low and its subagents own validation, not implementation.
All failed probes/builds/GUI attempts remain evidence. Final integrated tests
must cover every mandate criterion, actual GUI Builder/Development authoring,
two and third Canvas, screenshot theme/window/font matrix, source/negative/
History/cold lifecycle, historical regressions, correctness gold and measured
baseline comparisons. Compile or unit-test success is insufficient. No current
document implies those unexecuted tests passed.

P003 changes only post-P002 deltas and pins the full exact predecessor.
P001/P002 original archives and payloads are not repackaged. Check/apply/rollback
reuse the existing guarded overlay approach with exact before/after manifests;
independent clean-chain, negative-prerequisite and byte-exact P002 rollback tests
are mandatory. Demo standard Viewer ZIP stays separate. Owner review deposit
is authorized; official integration/activation and final acceptance are not.
