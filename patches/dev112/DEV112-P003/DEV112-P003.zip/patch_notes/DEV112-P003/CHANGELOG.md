# DEV112-P003 changes

- Extend the existing Native2D scene with a C++ Canvas facade/controller and
  opt-in retained mixed vector/raster/text/spline composition. Reuse existing
  native sketch, affine, CAD, layers, flat groups and scientific geometry.
- Bind source-free/multilayer editing, stable identities, calibrated raster
  sources, text, clipboard, merge, flatten, filters and publication through the
  existing Document, Resource, History, Workspace and Scientific Execution owners.
- Enhance the existing Builder `native2d` component with `source_kind canvas`.
  Reuse ordinary duplication, tabs/splitters, Runtime Test and C++ Development
  Validate/Build/Test/Preview/Export. Keep ordinary Design Preview inert.
- Add finite `Host::canvas_command` and borrowed `canvas_result` to the existing
  Restricted C++ SDK/GUI Host transport. Preserve Host/State/Event layouts and
  old opcodes. Reuse existing grants, source and lifetime checks, request bounds
  and typed Workspace codecs.
- Reuse global adaptive scheduling and existing CORE controls. Correct camera
  restoration, selection/inspector refresh, multi-click spline construction,
  provisional gesture capture, keyboard ownership and enclosing History capture.
- Remove measured repeated whole-state traversal, quadratic identity joins and
  per-resource installation lookups. Reuse verified cached Document reads with
  an optional compatible metadata projection, and existing native immutable
  capture/digest for small Resource hashes with the original fallback. Retain
  source integrity and default/old-native reader behavior.
- Deliver rebuilt native libraries with exact source/build receipts, public API
  documentation and examples. The original minimal demonstration Viewer remains
  a separate normal installable ZIP; its C++ handlers contain finite API calls.

Explicit bounds/policies remain visible: request48KiB, snapshot8MiB/4000 combined
identities, existing pixel/resource limits, flat same-layer contiguous groups,
calibrated-image similarity transforms, five admitted blend modes, compatible
editable merge and full admitted flatten. Unsupported policies refuse. Derived
filter/flatten/publication is RGBA8 sRGB and never claims original scientific
16-bit/float preservation; original sources remain immutable.

All changes are review candidates. Completed evidence and residual limitations
are stated in the checksum-bound external reports. No owner acceptance, official
activation or optional-Viewer migration is declared.
