# CORE reuse and gap audit — DEV112-P003

2026-11-02. MAIN preimplementation gate, revision 1. Product implementation has
not begun. This report records verified reuse and demonstrated gaps, not Canvas
acceptance. The owner mandate remains complete and authoritative.

## Exact predecessor and evidence

The supplied `/mnt/gxtxt-server/work-agent/compito/...` mount is absent. The
identically named complete owner mandate was read at the canonical server path
`/srv/gxtxt/main/work-agent/compito/GXTXT_DEV112_CORE_MULTILAYER_OBJECT_CANVAS_EXTENDED_MANDATE_20261102.md`.

Fresh reconstruction used the accepted public DEV112.r2 tar followed by both
delivered patch guards, in order, exclusively in a new private RAID task root.

| Input | SHA-256 |
|---|---|
| DEV112.r2 public tar | `8fda1fd6e485d9d917adfb08d64991c2403f8faf19ed10f4770565d8afcdbaa0` |
| DEV112-P001 | `b73fd26aaf6e8d3950de355988640bce0c6f0180e0ccc18aa5a19962e8f68d4b` |
| Corrected DEV112-P002 | `022d5af77a5660a87a48193293240de9cffb9ecb6d5f421f5fc0dd4fbd54aaa6` |

`BASELINE_VERIFICATION.json`, `P002_POSTIMAGE.json` and `BASELINE_COMMANDS.json`
pin all 5,457 resulting file SHA/size/modes. Sole admitted predecessor Git
checkpoint: `5df708478b74cb629db7914bbc422146738a908b`. Baseline is `baseline/`;
isolated development worktree is `framework/`. No accepted repository history
was rewritten. The retained P002 candidate matches byte/mode exactly.

Independent Sol 6.1 Low reconstructed the actual archive overlay rules and
compared every file independently, including both fresh and retained trees:
`../DEV112-P003-LOW-20261102/LINEAGE_02.json`. This checks bytes, not merely
developer assertions. Its first archival-note inventory assumption and correction
are preserved in LINEAGE_01 and the independent report.

MAIN directly reviewed Builder/Host/SDK, Interactive Document/Resource,
Workspace codecs, History, scheduler, P002 extraction and managed raster source.
The MAIN-owned audit specialist reviewed native geometry, CAD, retained renderer,
Curve Workbench consumers and Print Studio. Its full requirement/source matrix,
exact signatures, source lines and actual gap results are retained at
`../DEV112-P003-AUDIT-20261102/CORE_NATIVE_REUSE_AND_GAP_NOTES.md` and `gaps01/`.
That report is a required companion to this report; its cited files were checked
against the exact predecessor. Independent source review and executable public
SDK probes are in `../DEV112-P003-LOW-20261102/BASELINE_AUDIT_REPORT_01.md`.

All source references below are relative to the exact baseline. Public trusted
Tcl exposure is distinguished from Restricted C++ admission. Native runtime
probes alone never establish a public SDK grant or actual GUI workflow.

## Existing owners, contracts and decisions

| Requirement | Existing API/signature and actual owner | Exposure and verified facts | Reuse/gap decision and compatibility impact |
|---|---|---|---|
| Empty document, dimensions and multiple instances | `INTERACTIVE_DOCUMENT_API_v1`, `interactiveDocumentCreate(module,provider,format,version,payload)`; `NATIVE_2D_GEOMETRY_API_v1`, `native2DGeometryOpen(document)`; `native2d_geometry_api_v1.tcl:25–42` | Trusted Tcl; each scene has its own guarded Document generation/revision and Session token. MAIN `audit_probe02` created a source-free scene, two native layers and native sketches. | Reuse Document and native scene. A bounded Canvas-format payload for extent/background and complete logical structure is needed; a second geometry/document registry is unjustified. |
| Layers, naming and identity | Geometry `layer_create/get/list/update/delete/assign`; request `properties`, `layer_token`, `object_tokens`; `native2d_geometry_api_v1.tcl:720–757`; native `gx2d_layer_style` in `gx2d.h:258` | Public trusted; real native visibility/selectability/lock/order/opacity plus existing identity name/attributes. Invalid opacity rejects without mutation in specialist probe. | Reuse native layers and identity attributes. Name/blend/logical IDs do not justify duplicate layer classes or changing the existing layer POD ABI. Persist logical IDs because runtime tokens intentionally change on reopen. |
| Line, rectangle, ellipse, path, spline, arrow | Geometry `sketch`, `control_edit`, `spline_tangent_edit`, `affine`, direction-marker APIs; `gx2d_sketch_tcl.inc:8–83`, `gx2d.h:69–106` | Native C scientific kernel and trusted Tcl; spline controls/tangents, all listed geometric primitive families and arrow markers exist. Actual spline/group/copy probes succeed. | Reuse exact native definitions, transforms, sampling and controls. No substitute spline/geometry code. Text needs a retained presentation binding to existing text services/identity metadata, not a spline-derived substitute. |
| Selection, topmost picking and grouping | Geometry `selection_pick`, `selection_set_*`, `group*`; native `gx2d_collections.inc:153–174`; native C++ CAD controller | Independent native selection sets and groups exist. MAIN and specialist coincident-curve probes show scope-order tie breaking, not scene Z. Sprite hit returns descending visual Z correctly. | Compose actual renderer order with existing per-candidate hit/semantic selection. No replacement hit kernel or ROI-as-selection. Keep groups native and persist membership explicitly. |
| Provisional transforms, cancel, pivot, resize, clipboard | `NATIVE2D_API_v1` CAD context; `native2DCadCreate(scene,selection,owner)`, `native2DCadCanvasAttach(canvas,scene,options)`; `gx2d_cad_controller_v1.cpp:57–115` | Trusted host with native C++ semantic selection and cancel-safe gestures; source leases invalidate correctly in source. Affine copy allocates fresh IDs and preserves original in probe. | Reuse CAD/affine/drag commit/cancel. Resize and clipboard orchestration require finite adapters; no second gesture geometry/undo implementation. Cross-instance paste must validate compatible layer/source/resource ownership. Full gesture acceptance remains pending. |
| Retained rendering, cache, pan/zoom/fit | `NATIVE2D_SPRITE_SCENE_API_v1`, `native2DSpriteSceneCreate/Attach/Sync/Hit/Describe`; native C++ `gx2d_sprite_scene_v1.cpp` | Host-only; native source leases, dirty raster, exact revision observations and caches already exist. Repeated unchanged sync yields hits with no extra sampling. | Extend the existing retained renderer only where necessary. Reuse viewport coordinate mappings. Preserve legacy default appearance and source-lease invalidation. |
| Arbitrary mixed raster/vector/text order and alpha | Same SpriteScene, manual parser `:311–327`; native sync `composed()` around `:208`; `native2d_preview_v1.tcl:104–130` | Current scene is one Tk item and only line/polygon/rectangle/ellipse are admitted. Actual image/text admission rejects. Separate raster photo is placed below vector scene. Native sync currently bakes alpha against a background. | Confirmed need for a narrow opt-in native image/text/alpha composition extension. A photo above/below the whole scene is insufficient. Reuse retained Cairo owner and existing native image transforms; preserve existing consumers by opt-in behavior. No preview-only substitute may claim real composition. |
| Canonical source, resource ownership, calibration and immutable originals | Geometry `raster_dataset_bind`, `image_attach/get/update/calibrate/map`; `native2d_raster_api_v1.tcl:3–85`; `INTERACTIVE_DOCUMENT_RESOURCE_API_v1` | Actual Dataset/schema/SHA checks, immutable managed resources and retained reader-handle validation. Original and display bytes are distinct. | Reuse these exact owners/guards on bind, async dispatch/adoption, restoration and publication. No Viewer file paths/pixels or shadow Dataset store. Full changed/missing/foreign source tests remain pending. |
| Scientific ROI versus ordinary selection | Geometry `raster_roi_*`; native image-local `gx.image.rois` attributes | ROI feeds source-pixel processing; public raster tool names rectangle/polygon are ROI tools. | Keep semantically separate. Only geometry/mapping may be shared. Do not relabel existing ROI controller as general object editor. |
| Raster filters and blends | Existing `core.native2d.raster` provider, `raster_prepare/submit/freeze`; `native2d_raster_api_v1.tcl:126–169,294–319`; `gxtxt_native2d_raster.py:29–106` | Trusted typed scientific execution; existing Over/Multiply/Screen/Overlay/SoftLight/DstIn; negate/grayscale/blur. Existing effects require ROI and base image; composer skips nonimages. | Extend only fixed parameter/filter coverage for brightness/contrast/sharpen and whole-layer use. Explicit source-free/mixed output extent and inclusion are gaps. Reuse managed Scientific Execution, ImageMagick supervision and existing output freeze/publication; no arbitrary command/argv/path admission. |
| Depth, alpha, color and provenance | Same raster owner, `gxtxt_native2d_raster.py:61–106`; raster composition documentation | Verified source code uses explicit sRGB, 16-bit intermediate operations, normal RGBA8 export and mask16. It records actual output depth/color and input SHAs. | Define rendered RGBA8 output separately from original 16-bit/float scientific values. Explicit conversion and unsupported-output rejection required. No precision-preservation claim follows from an intermediate depth or screenshot. |
| Full document save/cold reopen | Geometry `export_resource/restore_resource`; `interactive_document_resource_api_v1.tcl:344–390`; `raster_snapshot/save/restore` | Existing resource stream preserves exact sketch definition/tangents and numeric payload. MAIN source-free probe proves raster_snapshot retains two layers but serializes zero of two vectors. Native group restore is not accepted by scalar resource restore. | A complete bounded Canvas snapshot schema using existing resource references, native layer properties, logical IDs and native group membership is justified. No second persistence engine; do not serialize private presentation-state visitor bytes. Preserve existing raster schema. |
| Undo/Redo and Workspace | `SCIENTIFIC_RECIPE_API_v1`, `scientificHistoryCreate/Append/Navigate/Branch`, `scientificHistoryViewerAttach`; `NATIVE_WORKSPACE_API_v1`; `viewer_workspace_native_v1.tcl:1–120` | Common native C++ Workspace store, typed codecs and guarded History are real owners. `viewerWorkspaceCodecRegister(kind,key,callback)` already admits bounded contributed domains/bindings. | Reuse History and native Workspace, register exact typed Canvas codecs rather than opaque parse-guessed blobs. Per-Canvas History must remain independent; shared Viewer Save must capture each instance coherently. No parallel undo stack. |
| Repaint cadence/lifecycle | `GUI_UPDATE_SCHEDULER_API_v1`, `guiUpdateSchedulerCreate(owner,callback,options)`, Request/Flush/Finish/Cancel/Dispose/Describe; `gui_update_scheduler_v1.tcl` | Host-only; independent owner incarnation/guard, callback and configuration per handle. Supports existing global graphics profile. | Use one existing scheduler handle per Canvas. Cancel on unbind/Session/close; stale callbacks must release owned output. No parallel timer/frame loop. Source-reviewed; Canvas adoption still untested. |
| Existing Curve Workbench | Actual native SpriteScene consumer `viewer.curve_workbench/api/curve_workbench_api_v1.tcl:900–979`; scene/workspace/history/persistence adapters documented in companion audit | Public CORE geometry/CAD/renderer/History owners are reusable. `_draw`, `_record`, `_cadState`, `_imageSnapshot` and `_history*` are private Viewer controllers. | Reuse CORE APIs and source-guard patterns only. CORE cannot load optional Workbench implementation. No Workbench migration or consumer mutation is justified. |
| Print Studio/PDF Composer | `PRINT_DOCUMENT_API_v1`: printRecipePosterNew/Validate/AssetIdentity/HistoryCreate/HistoryEdit/DocumentSave/Read/SourceSignature; `printDocumentRequest/Cancel/Release`; `print_document_api_v1.tcl` | Public trusted-only contracts; paper model 8MiB/200 items, source fingerprints, immutable prepared assets and resource leases. Private `app/print_studio_poster.tcl:89–230` owns global UI/gestures. | Reuse public source/provisional/lifetime patterns and common owners. Paper recipe is not a native Canvas geometry model. No private Print UI calls, whole-canvas redraw or transplanted timers. |
| P002 OCR/table/document source processing | `OCR_LAYOUT_API_v1`, `TABLE_EXTRACTOR_API_v1`; `ocr_layout_api_v1.tcl:109–120,284–319`; `viewer_gui_documents_v1.tcl:6–8,46–85`; managed extraction worker | Typed canonical image/PDF admission, normalized ROI with crop-before-OCR, original/display distinction, request cancellation, private native mounts, guarded `document_extraction` typed Workspace domain. SDK documents_command finite actions in Python dispatch `:1566–1587`. | Useful existing CORE guard/async/codec patterns. OCR/table recognition are not general drawing tools; no requirement or justification to couple Canvas to OCR or Unified Documents module. P001 icons/catalog and P002 consumers must remain unchanged. |
| Authorable multi-Canvas component | `VIEWER_GUI_DESIGN_v1` facade of `VIEWER_GUI_HOST_API_v1`; `viewerGuiComponentCapabilities`, `viewerGuiDesignModelEdit`, Compose; design source `:79–180,1554–1585` | Native2D components already non-singleton; ordinary panel/section/splitter/tab parents, stable declaration IDs/indexes and subtree duplicate/reparent. Existing source_kind allows scientific raster binding but has no Canvas mode. | Prefer an opt-in Canvas mode/preset on existing native2d component, preserving layout/identity rules. A new component type is unjustified unless an actual validation/mount gap is shown. Source-free mount and finite typed Canvas operations are missing. Actual GUI authoring still required, no hand-generated model substitute. |
| Restricted C++ capability and ABI | `gxtxt_viewer_sdk_v1.hpp:37–128`, `trusted_adapter_v1.cpp`, Python dispatch/policy | Host has raster_bind/tool/command, documents_command and typed WorkspaceValue clients; no admitted full Canvas/layer/object command. Independent Clang validation accepts raster_tool, rejects absent Canvas method, private dispatch_ and raw Tcl_Eval. Public CORE API discovery is not SDK admission. | Add only demonstrably required finite typed binding(s), exact declared component scope/grants and bounded request/result. Existing raster strings are source-required and cannot express typed independent layer/object edits. Preserve Host/State ABI and existing opcode meanings. No arbitrary Tcl/operation escape. |
| Theme/DPI/focus/icons/diagnostics | `CONFIGURATION_API_v1`; `ui_field_api_v1.tcl:709–739`; `viewerGuiRuntimeInspect`, traces, monitor and official GUI test harness | Actual available themes are alt/clam/classic/default; config fonts 8–24. Existing X11 harness uses real xdotool motion/button/key. Source and context probes are distinct from genuine GUI tests. | Reuse native controls, shared icons, keyboard/focus and configuration. Test actual supported themes and font/DPI/window sizes. No invented dark/high-contrast theme or screenshot-only acceptance. |

## Focused executable proof, limitations and pre-code decision

MAIN `audit_probe02/` verifies source-free native scene/layers, exact geometry
resource export/restore, raster snapshot omission and stale revision rejection;
closing after expiry succeeds. The first harness supplied `object_token` to
layer_assign instead of required `object_tokens`; its failure is retained in
`audit_probe01/`, fixed against source, then rerun once into new evidence.

Specialist `gaps01/` demonstrates image/text sprite rejection, native topmost
policy gap, native spline/group/copy reuse and unchanged native sync cache hits.
Independent Low `BASELINE_CONTRACTS_03.tcldict` records actual public source-free
raster tool rejection. `sdk_evidence/SDK_NEGATIVES_01.json` records compiler-backed
SDK boundary tests. These probes establish gaps; they do not validate proposed
new methods, actual Builder authoring, filter results or complete persistence.

Independent mapped baseline `native_audit/BASELINE_PERFORMANCE_01.md` records
two visible retained SpriteScenes, 200 rectangles each, 200 update samples and
actual native diagnostics. p50=100µs, p95=118µs, p99=141µs measure batch plus Tk
event servicing only. They are not input-to-present, physical latency or FPS.
Source-backed/spline/cold/resource/load baselines and justified acceptance
criteria remain required before performance claims.

The audit supports reuse of all existing scientific authorities with narrow
composition, complete snapshot, typed host binding and fixed filter extensions.
It does not support a new geometry engine, scheduler, storage owner, Dataset
registry, global Canvas singleton or demo-owned editor. MAIN may now develop
the architecture from these verified facts, reconcile a bounded native renderer
specialist review, and record exact final signatures before implementation.
Uncertainties above remain explicit test obligations; none reduces the mandate.

No P003 implementation, official integration, activation or owner acceptance
is claimed by this audit. All prior releases, patches, Viewers and user Sessions
are preserved.

## Independent integration addendum — existing typed resource admission

Independent Low source02 found that the advertised
`interactiveDocumentResourceRemapReferences(value,references)` in exact P002
calls the intentionally retired `_workspaceRemapResources` converter
(`session_workspace_api_v1.tcl:409`). Thus the earlier source-reviewed remap
contract is not executable reuse evidence; it was explicitly untested in the
pre-code audit. A real image-bearing clipboard reproducer fails at that boundary.
No claim is made that the unrelated legacy public remap operation is repaired.

The existing **typed** `managedResourceCopyTree(document,typed_graph)` and its
native validated resource-node copier already perform exact nested reference
adoption and source/generation/SHA-checked streaming. Its only incompatible
precondition is that the destination must be a native Workspace, while a Canvas
is an already valid Interactive Document. The smallest justified extension is
to admit an existing active Interactive Document through its metadata owner,
retaining native Workspace admission and the exact same typed graph copier,
writer, bounds and integrity checks. Signature/version and all old callers remain
unchanged. Canvas now encodes the declared resource_metadata shape and delegates
to that existing copier, removing its initially duplicated streaming/remap code.

This is a target-owner binding extension, not an untyped converter, new resource
grammar/store or SDK authority. It is justified by the failed exact-P002 image
paste reproducer plus source review of the existing typed implementation at
`session_workspace_api_v1.tcl:223–278`. Required corrective tests include nested
image/geometry ownership, source SHA/precision, ordinary/cold reopen, text
preservation, corrupt/foreign resources and both existing Workspace and new
Interactive Document targets. Independent revalidation remains pending.

## Corrective capacity audit — bounded typed diagnostic receipts

Actual public Composer fixture `AUDIT/capacity02` admits two independent native
Canvas components, each with65layers and129rectangle leaves. The current
per-instance diagnostic caps64/128 already mark diagnostics_complete=false,
but serializing both together produces62051bytes and fails the existing48KiB
client receipt admission before the compiled event runs. Empty8/16/32/64Canvas
fixtures serialize4927/9891/19782/39621bytes; no two-instance hard limit exists
in native allocation. The ordinary SDK form bound is512, distinct from the
GUI design's1000components/4MiB. Larger global summaries cannot be admitted by
this existing transport. This is an executable gap, not a speculative limit.

Source review also finds `canvas_input` enabled for command-only clients,
although only Host::canvas_result consumes the diagnostic context. Reuse the
existing compiler SDK-call analysis to request input only for actual result
readers. Scope the documented transient next-event receipt to the last successful
explicit Canvas command target (inspect is already a finite public operation).
Use a single logical-component diagnostic cursor in the existing runtime window
record, after its existing incarnation/lifetime guard. This cursor is not scene
state, a new store, target authority or a persisted property. Failed commands
must not change it; no command yet or disposed target returns an empty instances
map. Existing public SDK signature and instances-map schema remain unchanged.

Even a single diagnostic page must respect actual encoded bytes: cap selection
as well as existing layer/object arrays, trim these bounded lists until the
existing48KiB envelope fits, and use existing diagnostics_complete=false with
unchanged exact layer/object counts. Complete trusted Describe/Capture and all
scientific commands retain their existing owners/guards. No larger transport,
new public pagination API, global Canvas feed or SDK raw-resource access is
justified. Corrective tests must include the original2large fixture, command-only
compiled client with observer-only serializer tracing, explicit result-reader
inspectA/inspectB, maximum names/selection, foreign/grant/stale failures and
close/reopen cursor lifetime. Independent artifact tests must rerun after fixing.

## Performance corrective audit — serialization lookup complexity

Independent actual public capacity/large-pan observations preserve21.99s for
320→640objects, ~69s for640→1280, and280–310ms pan-command service plus~310ms
presentation with1280native splines/640selected. The separate xdotool15s wait
for an unchanged pointer coordinate is a fixture artifact, excluded from these
public service timings. These are measured limitations, not responsiveness PASS.

Source identifies avoidable Tcl quadratic joins: Describe/Capture translate each
selected native ID by scanning the whole native object list; Capture scans all
Geometry owner entries again for every leaf to find optional raster source
metadata; reconciliation rescans all adopted entries for each native object and
uses repeated linear live-ID membership. The selected640/1280fixture entails
~819k selected-ID comparisons before rendering. Existing scene/object identity
and Geometry owner dictionaries already contain every necessary fact.

The smallest correction is transient per-call dictionary indexing of those
existing IDs/metadata while serializing/reconciling. Native state, stable IDs,
opaque Geometry tokens, Document/Resource and History remain sole authorities;
no persistent cache, resource registry, new public method, geometry structure or
changed scientific payload is needed. Existing unknown/foreign ID refusal must
remain. Profile the immutable59 predecessor and corrected code with the same
actor; exact native/cold/resource regression checks remain required. These
changes alone do not establish that all resource/checkpoint/compositor costs
are resolved; quantify remaining phases before acceptance.

### Measured resource-read amplification and verified existing cache reuse

Immutable59 diagnostic profile pipeline_profile59_01 (instrumentation overhead
explicit) observes640→1280 duplication at96.89s:1921full Document reads,
6,512,814,325prior-document bytes hashed/read,3192SHA subprocesses. Two Capture
calls consume93.29s;640adoptions22.64s and640Native2DStore calls69.20s. History
Append0.402s and Checkpoint0.096s are not the dominant cost. Each new leaf causes
one owner payload read in Geometry admission and two in resource provenance
(`_scientificResourceOrigin` then `documentOriginRead`). Parent origin is already
present in the first validated owner receipt.

ExactP002 already publicly declares `interactiveDocumentReadCached(document,
?stored|current?)` and ships its native Document snapshot cache. Its stored
policy matches the old default; native Workspaces fall back to the original
owner, cache/size/platform limitations fall back to original reads, and expected
SHA plus complete native no-follow file/ancestor identity validate cache hits.
This is verified baseline functionality; the historical EXP01 document still
states NOT ACCEPTED/NOT FOR INSTALLATION, so no historical owner acceptance is
inferred. P003 proposes private-candidate reuse and supplies fresh integrity,
compatibility and performance evidence; official integration remains owner-only.

Smallest existing-owner reuse: Geometry's normal generation/revision guard reads
through that existing validated cache; resource provenance reads that same owner
once and derives both parent revision and origin_snapshot from the one receipt.
Public documentOriginRead remains unchanged. No new cache, registry, document
format or API is introduced. Required corruption/same-size replacement, Session/
generation/revision, cache-bound fallback and old Workspace/Resource tests must
still pass. Before59 versus corrected profiles must distinguish instrumentation
from final uninstrumented GUI/performance acceptance.

## Atomic cross-instance capture corrective audit

Actual installed compiled demo on immutablee03, HIGH/demo_provisional01, proves
that while A holds a native translate preview, B's managed Flatten completion
captures A's live provisional coordinates into the shared Viewer Workspace
domain and exports a new geometry resource, although A's History remains
unchanged. Resource definition equals the held preview exactly; genuine Escape
restores A, establishing that the captured state was uncommitted. Pending spline
construction is already excluded by native state and was separately SAFE.
The failing actor and precise before/after SHAs/matrix are retained.

The gap is trusted orchestration, not a native geometry algorithm: global
Viewer capture calls every Canvas public Capture. The existing gesture_before
snapshot and gesture_history already retain the accepted state/redo owner for
that same multi-event transaction. Reuse them only while native gesture=true;
after native commit=false transition, normal Capture must export the committed
scene even before the GUI handler clears its gesture keys. Preserve the original
History record while another Canvas captures an active provisional transaction.
No new snapshot store or History authority is necessary. Required regression:
unchanged genuine mixed A-held/B-async-completion actor must retain accepted
A geometry/resources/History/domain snapshot, then Escape restores exact A;
Return/release must still persist one valid native edit.

## Scientific lineage correction — identical bytes are distinct source identities

MAIN/source_lineage01 reproduces a real failure through normal publication,
public bind_source and object_duplicate: two distinct canonical Dataset IDs
contain the same PNG bytes; duplicating the second image incorrectly assigns
the first Dataset's source receipt. The old reconciliation infers source wrapper
metadata from image SHA, which identifies content but not scientific lineage.

The existing native affine/duplicate result already returns exact paired
source_ids/object_ids (including group leaves); no new native/public API is
needed. The trusted adapter must reuse that map to bind each new image's managed
reference and adopt the exact original Geometry wrapper metadata before normal
reconciliation. This preserves Dataset ID/revision/generation/SHA lineage and
uses the existing source/resource/Geometry owners. It does not infer origin
from equal bytes, create a source registry or expose native IDs to the SDK.
The same failed public fixture must pass unchanged, with Undo/Redo and cold
resource ownership covered by the existing resource regression campaign.

### Remaining per-resource provenance cost — existing metadata argument reuse

Actual tiny origin_probe987_01 creates40new resources in1.303719s without large
payload tracing. installationIdentity host resolution launches40Python processes
and consumes1.039325s (~79.7%); ScientificResourceOrigin40calls1.053558s;
Finalize156603µs and71sha256File calls141327µs are separate smaller phases.
Native2DStore already accepts metadata.origin, and OpenWriter skips provenance
construction when that existing field is supplied. No API extension is needed.

A Capture is one guarded materialization under one Document revision. Lazily
capture its existing managed_resource origin once, only if a new resource is
needed, and pass it through the already-supported metadata argument for those
new geometry resources. This consistently records creator/operation timestamp/
parent revision/origin snapshot for the single operation. Original nested image
origins and existing immutable resource references remain unchanged. Other
Native2DStore callers retain their existing default provenance behavior. This
is operation-scoped reuse, not an installation identity cache or new authority.
The unchanged public duplication actor and source/ownership/History tests must
establish actual benefit and no provenance/precision regression.

## Existing global scheduler wiring correction

Independent diagnostics/source review confirms Canvas selected profile global but
inherited policy coalesced, so its intensive hints never activated the advertised
Low/Medium/Fast adaptive cadence. Existing native CADCanvas already selects
global+adaptive through GUI_UPDATE_SCHEDULER_API_v1. Reuse that exact option for
the opt-in Canvas; existing terminal Finish, cancellation, guards, subscriptions
and shared timer owner remain unchanged. No new scheduler/timer/rate algorithm.
Measure actual normal16ms and configured intensive Low200/Medium100/Fast50ms,
separating scheduled delay from callback cost. This wiring must not disguise
unresolved synchronous large-edit or paint costs; independent criteria still
apply to measured operations and actual profiles.

## Native state projection and command-local identity joins

Coarse native-only state_before01 (stage04a699, no tracing/payload serialization
or concurrent GUI/build) measures640→1280 native duplicate2.694927s, and full
selected1280 state24.82675ms average12calls. Tcl guards repeatedly request that
whole state only for alive/scene/gesture; the existing facade has no scalar
projection. Extracting a field after traversal cannot avoid its cost. A narrow
optional private `state scalar` mode must reuse the same header builder and
source lease checks, with ordinary `state` unchanged. No new scientific schema,
public SDK method or model/cache is needed. Replace only caller sites that need
existing scalar facts; full Describe/Capture still obtains full native state.

Native fresh/unique currently enumerate and parse every object's/layer's logical
metadata for every generated identity, making a bulk duplication quadratic.
An owner-aware per-command transient map logical-ID→native-owner-set derived
from that same authoritative metadata can preserve exact collision/except-owner
semantics while updating assigned IDs and clearing on every success/error.
It is not a persistent ID registry. Existing cold collision, duplicate identity,
invalid-definition atomicity, source expiry, groups/masks, full state and output
regressions must remain; reuse the same coarse before actor for after evidence.
These source/proof-based changes target measured cost and do not imply whole
GUI/performance acceptance without the final independent campaign.

## Workspace History lifecycle correction (pre-code audit)

Independent Low's workspace_semantic04 reads the saved Workspace BEFORE opening:
the current native2d_canvas snapshot and its nested Canvas History each retain
one rectangle; enclosing History cursor0/steps0 retains the empty initial Canvas.
The existing scientificHistoryViewerAttach recovery restores its journal state
when capture differs, explaining loss after reopen without a new geometry defect.
Source confirms _viewerCanvasEvent only captures the domain, and existing
_viewerGuiHistoryBeforeTransition flushes ScriptLibrary/Documents, not Canvas.
Reuse scientificHistoryViewerRecordOperation at completed Canvas commits and
the existing before_transition hook for presentation changes before navigation,
Save and Close. Reuse scientificHistoryViewerPrepareEdit before Canvas mutations
so browsing and explicit branch consent retain their existing authority. No new
History implementation, journal, schema, timer, or public interface is justified.
For comparison only, remove operational document_receipt fields from temporary
copies of the Canvas contributions: restore increments the owner revision and
must not append another semantic edit merely for that receipt. Persist captures
with complete current receipts. Do not append automatically at a past cursor or
during restoration, browsing, or pending hooks. Record Canvas Undo/Redo only after
its Store, not its intermediate restored notification. Validate actual ordinary
and cold Workspace reopen, global/per-Canvas navigation, branch/read-only guards,
camera preservation and unchanged-repeat Save without spurious History churn.

The Mount source unconditionally fits an already restored camera, independently
of the History mismatch. Move fit to the fresh-document branch before its first
Capture/Store and remove it from Mount; existing documents keep their view_state.
This reuses existing native fit and document snapshot fields without a new flag.

## Compiled Viewer initial History identity (pre-code audit)

Low's real d1 branch-to0, accepted new rectangle, normal Workspace Save, then
fresh-process cold05 is refused by the existing source guard: Workspace lacks a
restricted C++ source identity. Earlier ordinary pre-branch reopen passes.
Source shows viewer_gui_design_v1 Compose attaches initial History before
viewer_development_api_v1 initializes domain_state.restricted_cpp after Compose.
Branch0 legitimately restores that initial domain without its authenticated
native-client envelope; Canvas UI edits do not execute a C++ event to refill it.
Save must not synthesize an unverified source identity or weaken cold admission.
Instead initialize a freshly composed compiled runtime's already validated
existing envelope before its first saved capture/History attachment. Reuse the
current ViewerDevelopment window record, existing StateEnvelope and ContextSet;
prepare its admitted restored state before Compose. Restrict initialization to
fresh payload-free runtime construction and matching module/provider. Existing
saved payloads/source guards remain authoritative; no automatic historical
record migration, alternate identity, new codec or public context key is needed.
Validate genuine branch0/new edit/Save/cold with the original prebuilt demo and
legacy compiled consumers; source/design mismatch and missing saved identity
must continue to refuse. This closes a demonstrated initialization-order gap,
not a Canvas-owned C++ state/history implementation.

## Deferred active-layer tree echo (pre-code audit)

Low's demo97e_e499_past_trace08 enter-only stack proves an ordinary saved-past
Workspace Open queues _nativeCanvasLayerSelected → _nativeCanvasSafe layer_select
→ native2DCanvasCommand → existing Workspace PrepareEdit for both Canvases,
triggering branch dialogs despite no user edit. Initial __open__ is not the
cause. ControlsRefresh sets the already active tree row programmatically;
Tk delivers TreeviewSelect after updating_controls has been removed. The object
tree already compares actual selection before dispatch, but layer tree does not.
Reuse that no-op pattern. Read the actual active layer using existing native
scalar state plus its existing gx.canvas identity attribute; do not capture an
entire large scene, cache a second active layer, or weaken global branch guards.
Only genuine different-layer selection reaches the public command. Validate the
same past Open/Save/Undo/Redo cases without unexpected dialog/cursor changes;
ordinary real edit branch consent must still work. Disposed/expired callbacks
return safely without touching another Canvas.

## Existing retained Sprite pure-pan reuse (pre-adoption review)

Independent e499 untraced/observer-corrected selected1280 preparation p95
130.361ms remains real. High's NATIVE_PAN_SOURCE_REVIEW proves any effective
view translation increments viewportGeneration, clears existing NativeBinding
Samples and rebuilds every Sprite, despite unchanged authoritative geometry.
Use existing retained Sprite geometry/position and exact state/descriptor/group/
budget/source checks. Admit only identical Cartesian presentation frame,
dimensions/margins/spans, background and identity preview. Construction lines
(including constituents) are view-clipped and must rebuild. Any uncertain view,
style, geometry, source, zoom, resize, frame/polar or preview change follows the
existing native build. No change to kernel evaluation, sampling tolerance or
scientific resources. Cairo still repaints; no translated screen pixels are
treated as geometry or scientific output.

The existing presenter knows only its current view/generation, not the view
where retained device geometry was built. Two constant-size derived fields in
NativeBinding (preparedView, preparedBounds) retain that fixed reference so
position/bounds are recalculated from the original instead of accumulating
floating-point offsets. They are display cache metadata, retired with the same
binding/source, not another geometry model. A transient Translation vector stages
position/bounds until whole-frame admission; existing Samples are invalidated
after translation so later restyle cannot consume old device coordinates.

Reviewed dd5eb5a source on d702: only47 changed Sprite source lines, no new public
interface, kernel/header/SDK/view/History edits. Stage06 source/binary receipts
and native source equality are verified. Unchanged full native contracts12/gold
pass. Same native actor before05/after02 passes70 assertions,59 exact warmed/
forced-fresh RGBA pairs,59 exact baseline/candidate fresh pairs,3304 matching hit
probes, frame/ROI/huge-origin/fractional/roundtrip/construction/fallback/edit/font/
preview/source-expiry/invalid-admission cases. These are author proofs, not an
independent public performance/cold claim. Adopt only this coherent artifact;
Low must repeat public selected/unselected large pans and ordinary320, final
GUI/source/History/cold and legacy scopes on the actual adopted native hash.

## Locked content reconstruction order (pre-code audit)

MAIN layer_recipe02 uses only existing public copy/layer_create/paste/layer_update
to duplicate a compatible layer with exact native definitions, then Undo exposes
a required restore defect: native2DCanvasRestore creates the original locked
layer before object_adopt, which correctly refuses edits into a locked layer.
Thus valid locked-layer snapshots cannot currently replay/ordinary-cold restore.
The edit guard is correct and must not be weakened. The same grouping guard
requires unlocked members while reconstructing native membership, so original
leaf locks must be finalized after groups are rebuilt, not before.

Reuse the current fresh provisional scene/objectIds/layerIds and complete snapshot
instead of new state/API. Build provisional layers/leaves with only locked=0,
reconstruct groups, then apply exact saved leaf styles and layer properties before
source/presentation admission and the atomic visible swap. The accepted source
scene remains untouched on failure. Resource cache signatures already exclude
style, so immutable native definitions/attributes/references remain exact.
Apply the same reconstruction discipline to clipboard groups only if a focused
public reproducer confirms its currently eager leaf lock prevents group creation.
Public mutation/lock refusals remain; recovery alone reconstructs validated state.
Validate exact locked leaf/group/layer Undo/Redo, source independence, unchanged
references/styles/definitions, ordinary+cold reopen and failed restore preservation.

Follow-up layer_recipe04 independently confirms the clipboard variant using a
valid public group with a locked member: copy is read-only and succeeds, while
paste eagerly applies member.locked=1 then native object_group correctly refuses.
Use the same existing composition transaction to assemble new copied members
with locked=0, then restore exact copied member styles after all membership is
built and before selection/acceptance. Keep original source locks and all target
admission checks; no new API or bypass of public mutation guards. This evidence
justifies the clipboard reconstruction extension separately from scene recovery.

## Restored scene/current widget device metrics (pre-code audit)

Independent mixed_roi_tail_d318_01 shows Undo retains exact scientific content,
requested world and margins but leaves native viewport800x600 on an unchanged
mapped680x484 Tk canvas. After100ms natural service it remains wrong; actual
screenshots show enlarged/clipped content. native2DViewportHostScene only replaces
the scene reference; its layout intentionally never edits native view state.
No Configure event is guaranteed when replacing a scene on the same widget.
Reuse the existing Canvas native resize event on the private reconstructed scene
with the actual current widget width/height before presentation admission/swap.
That event preserves requested camera and derives the same effective view as
ordinary native Configure. Skip only unavailable/less-than2px unmounted metrics;
normal Configure handles first mapping. No fake test resize, new camera model,
refit or geometry change. Verify same actor's full preflatten/Undo snapshot,
genuine view/pick alignment and cold/History after current-host restoration.

## Compact high-DPI chrome: existing UI Field owner extension

Low's actual144DPI/font24/supportedClassic case leaves a1.75px native plot:
five locally wrapped toolbar rows plus fixed380px instruction wrapping consume
height, and the inspector grants its full font-derived width to the detriment
of the scientific view. Source audit shows the existing UI Field single-row
toolbar always wraps; its menu overflow already exists for a different multirow
header policy. The public scrollable factory is vertical-only, while the shared
shell already implements minimum-width content, horizontal scrollbar and focus
reveal. Merely clipping/shrinking configured fonts is not an adequate solution.

Reviewed Core commit91e3751: reuse existing toolbar menu through an optional
private boolean preferMenu(default0 preserves every old caller); Canvas alone
opts in, retaining original button commands and full menu labels. Existing
scroll factory/signature stays unchanged. A private opt-in horizontal attachment
reuses shell geometry/xbar/focus policy, with no new registry or persisted model.
Canvas shares its available width between viewport and inspector allocation;
full-font inspector content stays available through mouse/keyboard scrolling.
Status remains a complete stored message, normalized to a single display line
with focus/F1 access to existing full tooltip. No font, native math, scientific
schema, public component type or SDK change.

Author final144DPI/font24 PASS144 and96DPI/font18 PASS142 cover four actual themes,
compact/wide genuine A/B/third drawing, five action menu mouse/keyboard access,
actual unclipped More caption, full multiline diagnostics/F1, horizontal mouse/
Tab reveal and wide xbar retirement. Default old scroll/toolbar positive behavior
and invalid private options tested. Intermediate real Classic collapse and
caption/harness failures remain. Independent final matrix on the adopted pin is
still required; these author results do not imply owner acceptance.

## Reconstructed runtime presentation and transaction lifetime

Independent childundo_xtest_d318_02 proves real XTest selection after Undo fails
with "Canvas presenter is not bound". New native contexts in Restore omit the
existing presenter binding that Mount and SwapDocument already establish. The
same actor observes zero native bound rows after only idle service, followed by
four after the16ms timer. Source detach erases bound Sprites. Reuse the existing
presenter configuration plus Scheduler Request/Finish at the accepted scene
handoff before notifications; no new drawing loop, timer or geometry interface.

High's RESTORE_PRESENTER_GESTURE_SOURCE_REVIEW also identifies stale runtime fields:
Restore derives its provisional row before CancelPending, then overwrites the
new sequence/cleared pending state with old values. Carry the existing post-cancel
runtime facts; never resurrect a canceled request. Replacement contexts must not
inherit gesture_before/history keys from an old native transaction. Error input
recovery retains its original History locally and reapplies it only to the same
document lifetime after successful scene recovery. CancelGesture must test actual
native gesture state: keys can temporarily remain after a committed release
during notification, when cancellation must not roll back accepted History.

SwapDocument should admit its resized private presentation before canceling old
work or removing old subscriptions, then reuse the same current-widget sizing,
presenter and terminal scheduler handoff. Keep the old scene until the new frame
is admitted. Validate immediate bound rows/pick and current device metrics, no
blank idle interval, postcommit callback cancellation, active gesture/history
replacement, pending job/history replacement and invalid admission preservation.
All runtime fields/owners already exist; no scientific schema or public API grows.

## Decoded photo ownership at scene/document retirement

High's actual swap_photos_before02 (19 assertions) proves bind→New×3 leaves an
empty current scene retaining three live Tk photos under retired document keys.
delete_photos_before01 (22 assertions) proves same-document bind→delete×3 also
retains three live decoded photos with zero current objects. Dispose alone frees
them; scientific History/resources/source SHAs are independently intact. This is
display-cache lifetime, not a reason to delete scientific data or History.

Reuse the existing row.photos owner with a current-presentation projection.
Keep active hidden photos for reuse, and lazily prepare initially hidden images
through the same native object/layer/group visibility facts. Retire obsolete Tk
photo values only after successful frame handoff. Document replacements start a
fresh display map while the old row keeps its photos through staging. Cleanup
must compare photo identity, not just equal resource keys: reopening the same
document can prepare a different Tk photo under the same key. Preparation must
also clean newly created photos if Rows itself throws before returning them.
Bound preparatory Tk decoding by the already existing native display-asset128MiB
ceiling (Sprite checkAssetCapacity), rather than allocating unbounded raw photos
before that native check. No new cache service, scientific authority or API.
Failed frame preparation retains the old photo map/visible rows; close/restore/
Undo can reload immutable resources through existing guards. Validate tiny
before/after lifetime probes, same-document reopen/failure, hidden reuse and
source/History invariance; resource budget rejection must occur before decoding.
