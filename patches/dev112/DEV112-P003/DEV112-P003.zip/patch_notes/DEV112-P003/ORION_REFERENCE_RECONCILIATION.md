# Supplementary ORION evidence reconciliation — 2026-11-02

Owner-supplied archive SHA-256:
`b2ab159707764fc7649928b3aeaf1c16826d31b5fd983e504dfe417e02cb12c0`
(686588 bytes). Read directly as ZIP data; no extraction, sourcing, import,
patch application, old test execution or runtime dependency. The README's
analysis-only boundary agrees with the owner's instruction. DEV112.r2→P001→
correctedP002 remains the sole predecessor; the P003 mandate is unchanged.

Historical statements below are attributed to archive reports. They are not
independent validation of P003 and are not owner acceptance. Historic screenshots
are reference only. `ORION_REFERENCE_INVENTORY.json` records actual member hashes
and agreement with the supplied manifest without exposing historical origin
paths outside the task.

| Reference finding | Comparison with exact DEV112 post-P002 | P003 use and required fresh regression |
|---|---|---|
| SR20 CORE composition request: separate Tk reference image cannot interleave between vector sprites. | Confirmed independently by P002 SpriteScene finite parser/source and actual image/text rejection probes. Native layer identity already exists. | Confirms narrow native mixed-compositor extension; do not import the transitional source-Figure layer manifest. Test vector A/image B/text C/spline D actual pixels, hit order and reorder. |
| SR21: Select/Move incorrectly route to image ROI; outline interiors and rounded X11 spline coordinates miss. | Existing public raster tools are source-required ROI/annotation tools. Native semantic selection differs from visual-Z policy; exact baseline probes show scope-order ties. | Separate ROI from ordinary object selection; native topmost pick with documented bounded device tolerance and filled-interior policy. Test genuine integer X11 input on fractional native spline projections, filled shapes, hidden/locked/occluding layers. |
| SR21: unchanged paint replayed source mapping/spline discovery/z batches; historical samples show expensive stable frames. | Existing P002 native retained cache works in focused tests, while independent2×1000-spline changed-view baseline still shows ~125ms service time. Historical values do not substitute for this baseline. | Reuse retained native revisions/source leases and avoid unchanged image decode or native resampling. Test raw cache/paint/event-loop/resource metrics; no FPS claim from harness duration. |
| SR22: whole-canvas clearing during navigation causes white flashes even though raster worker is cached. | Exact P002 `native2d_presentation_v1.tcl:358–361` calls `$canvas delete all` in legacy snapshot; raster dispatch also has a destructive path. New opt-in Canvas must avoid that route. | Native retained Canvas keeps its widget/item and prior complete scene during wheel/pan/fit/tool changes. Fresh GUI burst-wheel/zoom roundtrip/middle-pan tests inspect widget identity, actual screenshots and clear counts. Preserve existing consumers' legacy path. |
| SR23/SR24: editor begin/end and layer panel hide/show cause first-entry/repeated selection reflow; queued full layout can replace an in-flight spline preview. | Private archived adapters wrap many private procedures. They demonstrate a race/policy issue but are not reusable public contracts. Existing native CAD/provisional transforms and scheduler can support one stable input owner. | CORE-native per-instance gesture/controller remains mounted. Test first tool entry and repeated selection without panel recreation, held spline drag with queued resize/render, final exact resource update and cold reopen. Do not port rename/monkey-patch chains or asynchronous photo raise workarounds. |
| SR24: raising a raster photo can occlude the entire vector scene; linked spline/official Figure History and output remain separate. | Exact P002 confirms mixed-composition and full mixed snapshot/output gaps. New Canvas uses one native compositor and one complete snapshot over existing resources. | No independent photo stacking authority, fake Figure spline kind or silently omitted spline output. Full mixed flatten must use native compositor at explicit document extent and explicit precision. |
| ORION005 History audit: declarative lifecycle components and Build/Test/Export do not prove domain History or cold persistence. | P002 native Workspace has contributed typed domain/binding codecs; existing Scientific History/Document guards are adequate but need real Canvas integration. | Each Canvas needs actual semantic History commits/restoration and typed resource retention. Fresh two-process save/open/Undo/Redo tests check exact IDs, resources, source SHA and independent cursors. A UI component/compile PASS never counts as scientific History PASS. |
| ORION005 implementation: immutable managed checkpoints, expected document generation/revision, all panel-source SHA and source-bound restoration. | Same validated owners already exist in P002; no need for experimental service or store. | Reuse existing DocumentResource, ScientificRecipe and native Workspace. Validate complete snapshot/dependency graph before provisional restore/adoption; cancel pending work and reject stale/foreign/tampered state. |
| ORION002: provider-specific chunked scientific source materialization, high-depth/image-size tests and cancel/discard/accept separation. | Current ordinary core.native2d.raster still has its actual8MiB preparation,16MiB terminal,16-image/16777216-pixel bounds and PNG/sRGB/RGBA8 output policy. Archived100MP/TIFF/float support belongs to an experimental service and is not current generic CORE admission. | Reuse existing supervised execution/materializers where admitted; preserve originals and exact actual output depth/provenance. Keep true source/display/preview/accepted/output distinctions. Explicitly refuse unsupported precision/format/size; no importing service-specific allowlists or claiming archived100MP tests passed here. |
| ORION004: source-lineage guards and transformed geometric hit testing; alpha/text/glyph/GUI limitations explicitly open. | Native2D already owns affine/native selection; P002 native opacity and shaped text services exist. | Use native math and retained text engine; actual layer alpha/glyph hit/arrowhead and output pixel tests required. A changed output SHA alone is not a pixel oracle. |

Read relevant SR20–24 reports, ORION002 contract, ORION004 validation and
ORION005 audit/checkpoint; inspected bounded procedure/signature/regression
references in archived SR22/SR24 and History source as text. The archive's
candidate adapters include cumulative private `rename` wrappers and test
instrumentation overrides; none is copied into product code or executed.

The useful validated solutions are existing CORE services and principles already
confirmed in the P002 audit: retained frames, native exact geometry, source guards,
provisional-versus-accepted edits, managed resources and typed History/Workspace.
Their P003 implementation and fresh independent regression evidence remain
required. No scope/baseline/delivery requirement or acceptance boundary changes.
