# DEV112-P003 incremental CORE candidate

This patch's sole predecessor is the exact cumulative tree:
DEV112.r2 → DEV112-P001 → corrected DEV112-P002. It is not a complete framework
distribution. The separately delivered original Canvas demonstration Viewer ZIP
is installed by the normal Plugin Manager after an authorized framework update.
Owner review deposit does not authorize integration, activation or acceptance.

Verify the adjacent archive checksum before extracting its inert notes. The
installer is `patch_notes/DEV112-P003/apply.py` inside the archive:

```text
sha256sum -c DEV112-P003.zip.sha256
python3 -I -B apply.py FRAMEWORK DEV112-P003.zip --check
python3 -I -B apply.py FRAMEWORK DEV112-P003.zip --apply --stopped
python3 -I -B apply.py FRAMEWORK DEV112-P003.zip --rollback --stopped
```

The first command assumes the checksum file and ZIP share a directory. Use full
paths for the installer, framework and ZIP when running from another directory.
Check is read-only and is the default mode. Apply/rollback require a separately
authorized stopped target; `--stopped` acknowledges that condition. It does not
detect or stop processes, grant owner permission, activate releases, install the
demo or edit installed-module registries.

The manifest contains all5457 exact P002 predecessor identities plus only P003
deltas. Its canonical predecessor inventory SHA256 is
`9ffdd681eb9499fafd574b8fe8bd76aaa1f489ab682c5f9173d90bbf0c52bc39`.
The installer pins that digest independently, verifies the complete coherent
predecessor/postimage, and validates every payload/preimage byte, size and mode
before writing. Plain r2, P001-only, incomplete P002, altered guarded files,
unsafe paths/links and mixed states refuse. Unrelated extra files and Sessions
are preserved. Rollback restores exact P002 bytes/modes and removes only newly
added P003 files; empty directories can remain.

New Canvas Documents and the demonstration Viewer require P003. Rollback
preserves their Session data; P002 does not gain support for the new Canvas
format or SDK methods. Reinstating the matching framework capability is required
to continue editing that data after a framework rollback.

File replacements are individually atomic. The complete patch is a sequence of
writes, not an atomic filesystem transaction. An interruption can leave a mixed
tree that automatic invocations refuse. No automatic hardware-failure recovery
or permission to discard unrelated work is implied.

`FILES.json` is the exact changed-file/preimage/postimage inventory. Build receipts
are delivered beside each changed native library. Technical architecture, public
contracts, validation scope and supplementary-reference reconciliation accompany
the patch notes. Raw GUI/performance/chain evidence and checksum-bound final
reports are separate from this incremental payload, as indexed by
`EVIDENCE_INDEX.json` and the external `OWNER_HANDOFF.md`. The external handoff
and checksum manifest identify the actual final tested ZIPs, avoiding embedding
an archive's own hash inside itself.

The original r2/P001/corrected-P002 archives remain unchanged and are not bundled
as payloads. Optional Viewers, user Sessions and official releases are not patch
targets. All execution and installation evidence uses private synthetic Sessions
and private framework copies. Follow the external handoff's owner boundary.
