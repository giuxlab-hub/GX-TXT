/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef GX2D_CANVAS_V1_H
#define GX2D_CANVAS_V1_H
#include "gx2d_sprite_scene_v1.h"
#ifdef __cplusplus
extern "C" {
#endif
/* Host-only native facade over the existing scene, CAD and source lease.
 * No document, geometry, resource, History or scheduling authority is added. */
int gx2d_canvas_v1_create(Tcl_Interp *,gx2d_sprite_source_v1 *,uint64_t,
    Tcl_ObjCmdProc *,ClientData);
#ifdef __cplusplus
}
#endif
#endif
