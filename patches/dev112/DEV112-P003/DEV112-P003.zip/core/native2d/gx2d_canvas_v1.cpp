/* SPDX-License-Identifier: GPL-3.0-or-later
 * Per-instance Canvas orchestration over authoritative Native2D objects.
 * Scientific construction/selection/affine mathematics remain in gx2d.
 */
#include "gx2d_canvas_v1.h"
#include "gx2d_cad_controller_v1.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>
namespace {
struct Error {};
struct Obj {
 Tcl_Obj *p; explicit Obj(Tcl_Obj *o):p(o){Tcl_IncrRefCount(p);}
 Obj(const Obj &o):Obj(o.p){} Obj(Obj &&o):Obj(o.p){}
 ~Obj(){Tcl_DecrRefCount(p);} Obj &operator=(const Obj &o){Tcl_IncrRefCount(o.p);Tcl_DecrRefCount(p);p=o.p;return *this;}
};
Obj word(const std::string &s){return Obj(Tcl_NewStringObj(s.data(),(int)s.size()));}
void fail(Tcl_Interp *ip,const char *s){Tcl_SetObjResult(ip,Tcl_NewStringObj(s,-1));throw Error{};}
void status(Tcl_Interp *ip,gx2d_status s){if(s!=GX2D_OK)fail(ip,gx2d_status_text(s));}
Tcl_Obj *get(Tcl_Interp *ip,Tcl_Obj *d,const char *key,bool required=false){auto k=word(key);Tcl_Obj *v=nullptr;if(Tcl_DictObjGet(ip,d,k.p,&v)!=TCL_OK)throw Error{};if(!v&&required)fail(ip,"Missing Canvas field");return v;}
void put(Tcl_Obj *d,const char *k,Tcl_Obj *v){auto key=word(k);Tcl_DictObjPut(nullptr,d,key.p,v);}
std::vector<Tcl_Obj *> list(Tcl_Interp *ip,Tcl_Obj *o){int n;Tcl_Obj **v;if(Tcl_ListObjGetElements(ip,o,&n,&v)!=TCL_OK)throw Error{};return {v,v+n};}
void fields(Tcl_Interp *ip,Tcl_Obj *d,std::initializer_list<const char *> allowed){Tcl_DictSearch search;Tcl_Obj *k,*v;int done;if(Tcl_DictObjFirst(ip,d,&search,&k,&v,&done)!=TCL_OK)throw Error{};bool bad=false;for(;!done;Tcl_DictObjNext(&search,&k,&v,&done)){std::string s=Tcl_GetString(k);bool found=false;for(auto a:allowed)if(s==a)found=true;if(!found)bad=true;}Tcl_DictObjDone(&search);if(bad)fail(ip,"Unknown Canvas field");}
double number(Tcl_Interp *ip,Tcl_Obj *o,double limit=1e12){double n;if(Tcl_GetDoubleFromObj(ip,o,&n)!=TCL_OK||!std::isfinite(n)||std::abs(n)>limit)fail(ip,"Canvas number must be finite and bounded");return n;}
int integer(Tcl_Interp *ip,Tcl_Obj *o){int n;if(Tcl_GetIntFromObj(ip,o,&n)!=TCL_OK)throw Error{};return n;}
gx2d_id identity(Tcl_Interp *ip,Tcl_Obj *o,bool zero=false){Tcl_WideInt n;if(Tcl_GetWideIntFromObj(ip,o,&n)!=TCL_OK||n<(zero?0:1))fail(ip,"Invalid native Canvas identity");return (gx2d_id)n;}
bool boolean(Tcl_Interp *ip,Tcl_Obj *o){int n;if(Tcl_GetBooleanFromObj(ip,o,&n)!=TCL_OK)throw Error{};return n;}
gx2d_point point(Tcl_Interp *ip,Tcl_Obj *o){auto a=list(ip,o);if(a.size()!=2)fail(ip,"Canvas point needs two coordinates");return {number(ip,a[0]),number(ip,a[1])};}
Tcl_Obj *xy(gx2d_point p){Tcl_Obj *v[]={Tcl_NewDoubleObj(p.x),Tcl_NewDoubleObj(p.y)};return Tcl_NewListObj(2,v);}
Tcl_Obj *idsObj(const std::vector<gx2d_id> &ids){auto o=Tcl_NewListObj(0,nullptr);for(auto id:ids)Tcl_ListObjAppendElement(nullptr,o,Tcl_NewWideIntObj(id));return o;}
std::vector<gx2d_id> ids(gx2d_scene *s,Tcl_Interp *ip,bool layers=false){size_t n=0;status(ip,layers?gx2d_layer_ids(s,nullptr,0,&n):gx2d_object_ids(s,nullptr,0,&n));if(n>65536)fail(ip,"Canvas scene exceeds native enumeration capacity");std::vector<gx2d_id> a(n);status(ip,layers?gx2d_layer_ids(s,a.data(),n,&n):gx2d_object_ids(s,a.data(),n,&n));return a;}
std::array<double,6> matrix(Tcl_Interp *ip,Tcl_Obj *o){auto a=list(ip,o);if(a.size()!=6)fail(ip,"Canvas affine needs six native coefficients");std::array<double,6> m;for(size_t i=0;i<6;i++)m[i]=number(ip,a[i]);if(std::abs(m[0]*m[3]-m[1]*m[2])<1e-15)fail(ip,"Canvas affine must be nonsingular");return m;}
Tcl_Obj *matrixObj(const std::array<double,6> &m){auto o=Tcl_NewListObj(0,nullptr);for(auto n:m)Tcl_ListObjAppendElement(nullptr,o,Tcl_NewDoubleObj(n));return o;}
bool logicalIdentity(const std::string &s){if(s.empty()||s.size()>128||!((s[0]>='A'&&s[0]<='Z')||(s[0]>='a'&&s[0]<='z')))return false;for(unsigned char ch:s)if(!((ch>='A'&&ch<='Z')||(ch>='a'&&ch<='z')||(ch>='0'&&ch<='9')||ch=='_'||ch=='.'||ch==':'||ch=='#'||ch=='-'))return false;return true;}
bool blend(const std::string &v){return v=="Over"||v=="Multiply"||v=="Screen"||v=="Overlay"||v=="SoftLight";}
void rgba(Tcl_Interp *ip,Tcl_Obj *o,double *out){auto a=list(ip,o);if(a.size()!=4)fail(ip,"Canvas color needs normalized RGBA");for(size_t i=0;i<4;i++){out[i]=number(ip,a[i],1);if(out[i]<0)fail(ip,"Canvas color needs normalized RGBA");}}
struct Canvas;
std::map<gx2d_id,gx2d_id> groupOwners(Canvas *c);
struct IdentityScratch {bool ready=false;std::map<std::string,std::set<gx2d_id>> owners;};
struct Canvas {
 Tcl_Interp *ip;gx2d_sprite_source_v1 *source;uint64_t sceneId;Tcl_ObjCmdProc *backend;ClientData backendData;
 Tcl_Command command=nullptr;std::string name,cad,presenter,tool="select",canvasId;gx2d_id activeLayer=0,previewObject=0;
 uint64_t revision=0,serial=0;gx2d_point extent{640,480};gx2d_color background{1,1,1,1};
 bool gesture=false,changed=false,cadGesture=false;std::string gestureKind;gx2d_point startDevice{},startWorld{},lastDevice{},controlTarget{};gx2d_id controlObject=0;std::unique_ptr<Obj> controlReference;
 gx2d_view_state startView{};std::vector<gx2d_id> targets;std::vector<gx2d_point> constructionKnots;std::array<double,6> previewMatrix{1,0,0,1,0,0},worldMatrix{1,0,0,1,0,0};gx2d_rect resizeBounds{};
 IdentityScratch *identityScratch=nullptr;
 gx2d_scene *scene(){auto s=gx2d_sprite_source_v1_scene(source);if(!s)fail(ip,"Canvas scientific scene has closed");return s;}
 Obj call(const char *op,const std::vector<Tcl_Obj *> &args={}){scene();auto c=word("::GX::Native2D::core"),operation=word(op);Obj sn(Tcl_NewWideIntObj(sceneId));std::vector<Tcl_Obj *> a{c.p,operation.p,sn.p};a.insert(a.end(),args.begin(),args.end());Tcl_ResetResult(ip);if(backend(backendData,ip,(int)a.size(),a.data())!=TCL_OK)throw Error{};return Obj(Tcl_GetObjResult(ip));}
 Obj cadCall(const char *family,const char *op,const std::vector<Tcl_Obj *> &args={}){Tcl_CmdInfo info;if(!Tcl_GetCommandInfo(ip,cad.c_str(),&info)||!info.objProc)fail(ip,"Canvas CAD controller has closed");auto c=word(cad),f=word(family),o=word(op);std::vector<Tcl_Obj *> a{c.p,f.p,o.p};a.insert(a.end(),args.begin(),args.end());Tcl_ResetResult(ip);if(info.objProc(info.objClientData,ip,(int)a.size(),a.data())!=TCL_OK)throw Error{};return Obj(Tcl_GetObjResult(ip));}
 Obj metadata(gx2d_id owner){const char *text=nullptr;auto code=gx2d_attribute_get(scene(),owner,"gx.canvas",&text);if(code==GX2D_NOT_FOUND)return Obj(Tcl_NewDictObj());status(ip,code);Obj d(Tcl_NewStringObj(text,-1));int n;if(Tcl_DictObjSize(ip,d.p,&n)!=TCL_OK)fail(ip,"Invalid retained Canvas metadata");return d;}
 void identityProjection(){
  if(!identityScratch||identityScratch->ready)return;
  for(bool layer:{false,true})for(auto id:ids(scene(),ip,layer)){auto meta=metadata(id);if(auto logical=get(ip,meta.p,"logical_id"))identityScratch->owners[Tcl_GetString(logical)].insert(id);}
  identityScratch->ready=true;
 }
 void saveMetadata(gx2d_id owner,Tcl_Obj *d){
  int n;const char *s=Tcl_GetStringFromObj(d,&n);if(n>16384)fail(ip,"Canvas presentation metadata exceeds native identity bound");
  std::string previous,next;bool indexed=owner&&identityScratch&&identityScratch->ready;
  if(indexed){
   auto old=metadata(owner);if(auto logical=get(ip,old.p,"logical_id"))previous=Tcl_GetString(logical);
   // Reserve scratch storage before the native write. An allocation failure
   // must not turn a completed native metadata assignment into a failed edit.
   if(auto logical=get(ip,d,"logical_id")){next=Tcl_GetString(logical);identityScratch->owners[next].insert(owner);}
  }
  status(ip,gx2d_attribute_set(scene(),owner,"gx.canvas",s));
  if(indexed&&previous!=next&&!previous.empty()){auto found=identityScratch->owners.find(previous);if(found!=identityScratch->owners.end()){found->second.erase(owner);if(found->second.empty())identityScratch->owners.erase(found);}}
 }
 std::string fresh(const char *kind){
  identityProjection();for(size_t attempt=0;attempt<65537;++attempt){auto candidate=canvasId.substr(0,80)+":"+kind+":"+std::to_string(++serial);bool found=false;
   if(identityScratch)found=identityScratch->owners.count(candidate)!=0;
   else for(bool layer:{false,true})for(auto id:ids(scene(),ip,layer)){auto meta=metadata(id);auto logical=get(ip,meta.p,"logical_id");if(logical&&candidate==Tcl_GetString(logical)){found=true;break;}}
   if(!found)return candidate;
  }fail(ip,"Canvas logical identity capacity exceeded");return {};
 }
 void unique(const std::string &logical,gx2d_id except=0){
  if(!logicalIdentity(logical))fail(ip,"Canvas logical identity must match the bounded SDK identity grammar");identityProjection();
  if(identityScratch){auto found=identityScratch->owners.find(logical);if(found!=identityScratch->owners.end()&&(found->second.size()!=1||!found->second.count(except)))fail(ip,"Duplicate Canvas logical identity");return;}
  for(bool layer:{false,true})for(auto id:ids(scene(),ip,layer)){if(id==except)continue;auto d=metadata(id);auto v=get(ip,d.p,"logical_id");if(v&&logical==Tcl_GetString(v))fail(ip,"Duplicate Canvas logical identity");}
 }
 void ownedObject(gx2d_id id,bool editable=false){gx2d_style st;status(ip,gx2d_get_style(scene(),id,&st));if(editable){if(st.locked)fail(ip,"Canvas object is locked");if(st.layer){gx2d_layer_style ls;status(ip,gx2d_get_layer(scene(),st.layer,&ls));if(ls.locked)fail(ip,"Canvas layer is locked");}}}
 void ownedLayer(gx2d_id id,bool editable=false){gx2d_layer_style st;status(ip,gx2d_get_layer(scene(),id,&st));if(editable&&st.locked)fail(ip,"Canvas layer is locked");}
 std::vector<gx2d_id> requestObjects(Tcl_Obj *r,bool editable=true){auto a=list(ip,get(ip,r,"objects",true));if(a.empty()||a.size()>4096)fail(ip,"Canvas object list needs 1..4096 identities");std::vector<gx2d_id> out;std::set<gx2d_id> seen;std::map<gx2d_id,gx2d_id> owners;if(editable)owners=groupOwners(this);for(auto o:a){auto id=identity(ip,o);ownedObject(id,editable);auto parent=owners.find(id);if(parent!=owners.end())ownedObject(parent->second,true);if(!seen.insert(id).second)fail(ip,"Duplicate Canvas object identity");out.push_back(id);}return out;}
 Obj selectionSnapshot(){
  auto raw=cadCall("selection","get");Obj out(Tcl_DuplicateObj(raw.p)),objects(Tcl_NewListObj(0,nullptr)),references(Tcl_NewListObj(0,nullptr));std::set<gx2d_id> owners;
  for(auto member:list(ip,get(ip,raw.p,"members",true))){if(!boolean(ip,get(ip,member,"valid",true)))continue;auto id=identity(ip,get(ip,member,"id",true));auto kind=get(ip,member,"kind",true);std::string semantic=Tcl_GetString(kind);if(semantic=="fragment"){Obj native(Tcl_NewWideIntObj(id));auto fragment=call("fragment_get",{native.p});owners.insert(identity(ip,get(ip,fragment.p,"parent",true)));continue;}ownedObject(id);owners.insert(id);gx2d_kind nativeKind;status(ip,gx2d_kind_of(scene(),id,&nativeKind));if(nativeKind==GX2D_GROUP)continue;auto ref=cadCall("selection","reference",{get(ip,member,"id",true),kind,get(ip,member,"index",true)});Obj copy(Tcl_DuplicateObj(ref.p));put(copy.p,"semantic_kind",kind);Tcl_ListObjAppendElement(ip,references.p,copy.p);}
  for(auto id:owners)Tcl_ListObjAppendElement(ip,objects.p,Tcl_NewWideIntObj(id));put(out.p,"objects",objects.p);put(out.p,"references",references.p);return out;
 }
 Obj selected(){auto s=selectionSnapshot();return Obj(get(ip,s.p,"objects",true));}
 void select(const std::vector<gx2d_id> &a,const std::string &mode="replace"){Obj members(Tcl_NewListObj(0,nullptr));for(auto id:a){ownedObject(id);Obj m(Tcl_NewDictObj());put(m.p,"kind",Tcl_NewStringObj("object",-1));put(m.p,"id",Tcl_NewWideIntObj(id));Tcl_ListObjAppendElement(ip,members.p,m.p);}auto m=word(mode=="remove"?"subtract":mode);cadCall("selection","apply",{members.p,m.p});}
 void cancel(){if(!gesture)return;if(source&&gx2d_sprite_source_v1_scene(source)){if(cadGesture){try{cadCall("gesture","cancel");}catch(...){Tcl_ResetResult(ip);}}if(previewObject){gx2d_delete_object(scene(),previewObject);previewObject=0;}if(gestureKind=="pan")gx2d_view_state_set(scene(),&startView);}gesture=changed=cadGesture=false;targets.clear();constructionKnots.clear();controlReference.reset();controlObject=0;previewMatrix={1,0,0,1,0,0};worldMatrix=previewMatrix;}
 ~Canvas(){try{cancel();}catch(...){Tcl_ResetResult(ip);}if(!Tcl_InterpDeleted(ip)&&!cad.empty())Tcl_DeleteCommand(ip,cad.c_str());if(source)gx2d_sprite_source_v1_unlisten(source,this);}
};
// Rebuilt lazily from native attributes for this invocation only. Copied stale
// IDs can have multiple owners until each native metadata assignment succeeds.
struct IdentityScope {
 Canvas *canvas;IdentityScratch scratch;IdentityScratch *previous;
 explicit IdentityScope(Canvas *c):canvas(c),previous(c->identityScratch){c->identityScratch=&scratch;}
 ~IdentityScope(){canvas->identityScratch=previous;}
};
void validateMetadata(Canvas *c,Tcl_Obj *d,gx2d_id owner,bool layer=false){fields(c->ip,d,{"logical_id","kind","z","fill","text","font","font_size","anchor","name","blend"});if(auto o=get(c->ip,d,"logical_id"))c->unique(Tcl_GetString(o),owner);if(auto o=get(c->ip,d,"z"))number(c->ip,o);if(auto o=get(c->ip,d,"blend"))if(!blend(Tcl_GetString(o)))fail(c->ip,"Unsupported Canvas blend");if(auto o=get(c->ip,d,"fill")){double color[4];rgba(c->ip,o,color);}if(auto o=get(c->ip,d,"font_size")){double n=number(c->ip,o,512);if(n<1)fail(c->ip,"Canvas font size must be 1..512");}if(auto o=get(c->ip,d,"text")){int bytes;Tcl_GetStringFromObj(o,&bytes);if(bytes>8192)fail(c->ip,"Canvas text exceeds 8192 UTF8 bytes");}if(auto o=get(c->ip,d,"font")){int bytes;Tcl_GetStringFromObj(o,&bytes);if(bytes<1||bytes>512)fail(c->ip,"Canvas font descriptor exceeds 512 bytes");}if(auto o=get(c->ip,d,"anchor")){std::string s=Tcl_GetString(o);if(s!="nw"&&s!="n"&&s!="ne"&&s!="w"&&s!="center"&&s!="e"&&s!="sw"&&s!="s"&&s!="se")fail(c->ip,"Invalid Canvas text anchor");}int bytes;Tcl_GetStringFromObj(d,&bytes);if(bytes>16384)fail(c->ip,"Canvas metadata exceeds native identity bound");(void)layer;}
Obj mergedMetadata(Canvas *c,gx2d_id id,Tcl_Obj *request,const char *kind,bool layer=false){Obj old(id?c->metadata(id):Obj(Tcl_NewDictObj()));Obj d(Tcl_DuplicateObj(old.p));if(auto x=get(c->ip,request,"metadata")){Tcl_DictSearch it;Tcl_Obj *k,*v;int done;if(Tcl_DictObjFirst(c->ip,x,&it,&k,&v,&done)!=TCL_OK)throw Error{};for(;!done;Tcl_DictObjNext(&it,&k,&v,&done))Tcl_DictObjPut(c->ip,d.p,k,v);Tcl_DictObjDone(&it);}for(auto key:{"logical_id","kind","font","font_size","anchor","fill","z","name","blend"})if(auto v=get(c->ip,request,key))put(d.p,key,v);if(auto text=get(c->ip,request,"text")){fields(c->ip,text,{"value","font","font_size","anchor"});put(d.p,"text",get(c->ip,text,"value",true));if(!get(c->ip,request,"kind"))put(d.p,"kind",Tcl_NewStringObj("text",-1));for(auto key:{"font","font_size","anchor"})if(auto v=get(c->ip,text,key))put(d.p,key,v);if(!get(c->ip,d.p,"font_size"))put(d.p,"font_size",Tcl_NewDoubleObj(12));if(!get(c->ip,d.p,"anchor"))put(d.p,"anchor",Tcl_NewStringObj("nw",-1));}if(!get(c->ip,d.p,"logical_id"))put(d.p,"logical_id",Tcl_NewStringObj(c->fresh(layer?"layer":"object").c_str(),-1));if(!get(c->ip,d.p,"kind"))put(d.p,"kind",Tcl_NewStringObj(kind,-1));if(layer&&!get(c->ip,d.p,"blend"))put(d.p,"blend",Tcl_NewStringObj("Over",-1));validateMetadata(c,d.p,id,layer);return d;}
void validatePresentation(Canvas *c,gx2d_id id,Tcl_Obj *meta,Tcl_Obj *definition){
 auto ip=c->ip;gx2d_reference_image image;bool raster=id&&gx2d_image_get(c->scene(),id,&image)==GX2D_OK;auto kind=get(ip,meta,"kind");bool text=kind&&std::string(Tcl_GetString(kind))=="text";
 if(kind&&std::string(Tcl_GetString(kind))=="image"&&!raster)fail(ip,"Canvas image kind requires an existing managed native image");
 Obj existing(Tcl_NewDictObj());if(!definition&&id&&!raster){Obj native(Tcl_NewWideIntObj(id));existing=c->call("sketch_definition",{native.p});definition=existing.p;}
 std::string family;if(definition)if(auto f=get(ip,definition,"family"))family=Tcl_GetString(f);
 if(text&&(raster||family!="rectangle"))fail(ip,"Canvas text requires an exact native rectangle anchor");
 if(auto f=get(ip,meta,"fill")){double color[4];rgba(ip,f,color);if(color[3]>0&&!text){if(raster)fail(ip,"Raster tint fill is unsupported");bool closed=family=="rectangle"||family=="circle"||family=="ellipse";if(definition)if(auto value=get(ip,definition,"closed"))closed=closed||boolean(ip,value);if(!closed)fail(ip,"Canvas fill requires an explicitly closed native path");}}
}

gx2d_style style(Canvas *c,gx2d_style s,Tcl_Obj *d){fields(c->ip,d,{"visible","selectable","selected","locked","layer","order","color","opacity","line_width","line_style","marker"});for(auto key:{"visible","selectable","selected","locked"})if(auto v=get(c->ip,d,key)){int b=boolean(c->ip,v);if(!strcmp(key,"visible"))s.visible=b;else if(!strcmp(key,"selectable"))s.selectable=b;else if(!strcmp(key,"selected"))s.selected=b;else s.locked=b;}if(auto v=get(c->ip,d,"layer")){s.layer=identity(c->ip,v,true);if(s.layer)c->ownedLayer(s.layer,true);}if(auto v=get(c->ip,d,"order"))s.order=integer(c->ip,v);if(auto v=get(c->ip,d,"line_style")){int n=integer(c->ip,v);if(n<0||n>2)fail(c->ip,"Invalid Canvas line style");s.line_style=(gx2d_line_style)n;}if(auto v=get(c->ip,d,"marker")){int n=integer(c->ip,v);if(n<0||n>3)fail(c->ip,"Invalid Canvas marker");s.marker=(gx2d_marker)n;}if(auto v=get(c->ip,d,"line_width")){s.line_width=number(c->ip,v,256);if(s.line_width<=0)fail(c->ip,"Canvas line width must be positive");}if(auto v=get(c->ip,d,"color")){double a[4];rgba(c->ip,v,a);s.red=a[0];s.green=a[1];s.blue=a[2];s.opacity=a[3];}if(auto v=get(c->ip,d,"opacity")){s.opacity=number(c->ip,v,1);if(s.opacity<0)fail(c->ip,"Invalid Canvas opacity");}return s;}
gx2d_layer_style layerStyle(Canvas *c,gx2d_layer_style s,Tcl_Obj *d){fields(c->ip,d,{"visible","selectable","locked","order","opacity"});if(auto v=get(c->ip,d,"visible"))s.visible=boolean(c->ip,v);if(auto v=get(c->ip,d,"selectable"))s.selectable=boolean(c->ip,v);if(auto v=get(c->ip,d,"locked"))s.locked=boolean(c->ip,v);if(auto v=get(c->ip,d,"order"))s.order=integer(c->ip,v);if(auto v=get(c->ip,d,"opacity")){s.opacity=number(c->ip,v,1);if(s.opacity<0)fail(c->ip,"Invalid Canvas layer opacity");}return s;}
Obj state(Canvas *c,bool includeObjects=true){Obj out(Tcl_NewDictObj());put(out.p,"alive",Tcl_NewBooleanObj(c->source&&gx2d_sprite_source_v1_scene(c->source)));put(out.p,"scene",Tcl_NewWideIntObj(c->sceneId));put(out.p,"tool",Tcl_NewStringObj(c->tool.c_str(),-1));put(out.p,"active_layer",Tcl_NewWideIntObj(c->activeLayer));put(out.p,"gesture",Tcl_NewBooleanObj(c->gesture));put(out.p,"revision",Tcl_NewWideIntObj(c->revision));put(out.p,"extent",xy(c->extent));Tcl_Obj *rgba[]={Tcl_NewDoubleObj(c->background.red),Tcl_NewDoubleObj(c->background.green),Tcl_NewDoubleObj(c->background.blue),Tcl_NewDoubleObj(c->background.alpha)};put(out.p,"background",Tcl_NewListObj(4,rgba));put(out.p,"canvas_id",Tcl_NewStringObj(c->canvasId.c_str(),-1));if(!includeObjects||!c->source||!gx2d_sprite_source_v1_scene(c->source))return out;
 auto selection=c->selectionSnapshot();put(out.p,"selection",selection.p);put(out.p,"selected_objects",get(c->ip,selection.p,"objects",true));Obj layers(Tcl_NewListObj(0,nullptr)),objects(Tcl_NewListObj(0,nullptr)),groups(Tcl_NewListObj(0,nullptr));
 for(auto id:ids(c->scene(),c->ip,true)){Obj n(Tcl_NewWideIntObj(id));auto row=c->call("layer_info",{n.p}),meta=c->metadata(id),attrs=c->call("identity_attributes",{n.p});Obj e(Tcl_NewDictObj());put(e.p,"id",n.p);auto nativeId=word("id");Obj properties(Tcl_DuplicateObj(row.p));Tcl_DictObjRemove(c->ip,properties.p,nativeId.p);put(e.p,"properties",properties.p);put(e.p,"attributes",attrs.p);put(e.p,"canvas_metadata",meta.p);for(auto key:{"logical_id","name","blend"})put(e.p,key,get(c->ip,meta.p,key)?get(c->ip,meta.p,key):Tcl_NewStringObj(!strcmp(key,"blend")?"Over":"",-1));Tcl_ListObjAppendElement(c->ip,layers.p,e.p);}
 for(auto id:ids(c->scene(),c->ip)){if(id==c->previewObject)continue;Obj n(Tcl_NewWideIntObj(id));auto st=c->call("object_style",{n.p}),attrs=c->call("identity_attributes",{n.p}),meta=c->metadata(id),kind=c->call("kind",{n.p});Obj e(Tcl_NewDictObj());put(e.p,"id",n.p);put(e.p,"style",st.p);put(e.p,"attributes",attrs.p);put(e.p,"canvas_metadata",meta.p);put(e.p,"logical_id",get(c->ip,meta.p,"logical_id")?get(c->ip,meta.p,"logical_id"):Tcl_NewStringObj("",0));put(e.p,"layer",get(c->ip,st.p,"layer",true));put(e.p,"kind",get(c->ip,meta.p,"kind")?get(c->ip,meta.p,"kind"):kind.p);if(std::string(Tcl_GetString(kind.p))=="group"){auto members=c->call("group_members",{n.p});put(e.p,"members",members.p);Tcl_ListObjAppendElement(c->ip,groups.p,e.p);}Tcl_ListObjAppendElement(c->ip,objects.p,e.p);}
 put(out.p,"layers",layers.p);put(out.p,"objects",objects.p);put(out.p,"groups",groups.p);return out;
}
Obj receipt(bool changed=false,bool provisional=false,bool committed=false,bool canceled=false,bool selected=false){Obj o(Tcl_NewDictObj());put(o.p,"changed",Tcl_NewBooleanObj(changed));put(o.p,"provisional",Tcl_NewBooleanObj(provisional));put(o.p,"committed",Tcl_NewBooleanObj(committed));put(o.p,"canceled",Tcl_NewBooleanObj(canceled));put(o.p,"selection_changed",Tcl_NewBooleanObj(selected));return o;}
std::vector<gx2d_id> pick(Canvas *c,gx2d_point p,double tolerance){
 if(c->presenter.empty())fail(c->ip,"Canvas presenter is not bound");auto handle=word(c->presenter);Obj pt(xy(p)),tol(Tcl_NewDoubleObj(tolerance));if(gx2d_sprite_scene_v1_pick(c->ip,handle.p,c->source,pt.p,tol.p)!=TCL_OK)throw Error{};Obj hits(Tcl_GetObjResult(c->ip));
 auto allowed=[&](gx2d_id id){gx2d_style st;status(c->ip,gx2d_get_style(c->scene(),id,&st));if(!st.visible||!st.selectable||st.locked)return false;if(st.layer){gx2d_layer_style l;status(c->ip,gx2d_get_layer(c->scene(),st.layer,&l));if(!l.visible||!l.selectable||l.locked)return false;}return true;};
 auto all=ids(c->scene(),c->ip);
 for(auto v:list(c->ip,hits.p)){
  auto id=identity(c->ip,v);if(!allowed(id))continue;gx2d_id owner=0;bool blocked=false;
  for(auto group:all){gx2d_kind k;status(c->ip,gx2d_kind_of(c->scene(),group,&k));if(k!=GX2D_GROUP)continue;int contains;status(c->ip,gx2d_group_contains(c->scene(),group,id,&contains));if(!contains)continue;if(!allowed(group)){blocked=true;break;}owner=std::max(owner,group);}
  if(!blocked)return {owner?owner:id};
 }
 return {};
}
std::vector<gx2d_id> groupMembers(Canvas *c,gx2d_id group){size_t n;status(c->ip,gx2d_group_members(c->scene(),group,nullptr,0,&n));std::vector<gx2d_id> out(n);status(c->ip,gx2d_group_members(c->scene(),group,out.data(),n,&n));return out;}
std::map<gx2d_id,gx2d_id> groupOwners(Canvas *c){std::map<gx2d_id,gx2d_id> owners;for(auto id:ids(c->scene(),c->ip)){gx2d_kind kind;status(c->ip,gx2d_kind_of(c->scene(),id,&kind));if(kind!=GX2D_GROUP)continue;gx2d_style group;status(c->ip,gx2d_get_style(c->scene(),id,&group));for(auto member:groupMembers(c,id)){gx2d_style leaf;status(c->ip,gx2d_get_style(c->scene(),member,&leaf));if(leaf.layer!=group.layer)fail(c->ip,"Canvas group and members must share a native layer");if(!owners.emplace(member,id).second)fail(c->ip,"Canvas leaf may belong to one compatible flat group");}}return owners;}
void deleteObjects(Canvas *c,const std::vector<gx2d_id> &input){
 groupOwners(c);std::set<gx2d_id> groups,leaves;for(auto id:input){c->ownedObject(id,true);gx2d_kind kind;status(c->ip,gx2d_kind_of(c->scene(),id,&kind));if(kind==GX2D_GROUP){groups.insert(id);for(auto member:groupMembers(c,id)){c->ownedObject(member,true);leaves.insert(member);}}else leaves.insert(id);}
 /* Delete containers first: the native owner automatically retires an empty
  * group after its last member, so a later container delete would be stale. */
 for(auto id:groups)status(c->ip,gx2d_delete_object(c->scene(),id));for(auto id:leaves)status(c->ip,gx2d_delete_object(c->scene(),id));
 auto remaining=c->selected();std::vector<gx2d_id> selection;for(auto v:list(c->ip,remaining.p))selection.push_back(identity(c->ip,v));c->select(selection);
}
Obj presentation(Canvas *c);

Obj command(Canvas *c,const std::string &op,Tcl_Obj *r){auto ip=c->ip;c->scene();if(c->gesture&&op!="cancel"&&op!="tool_set")fail(ip,"Finish or cancel the Canvas gesture first");Obj out=receipt();bool model=false;
 if(op=="cancel"){fields(ip,r,{});bool active=c->gesture;c->cancel();return receipt(false,false,false,active);}
 if(op=="configure"){fields(ip,r,{"extent","background","presenter","canvas_id"});auto extent=c->extent;auto bg=c->background;std::string presenter=c->presenter,canvasId=c->canvasId;if(auto v=get(ip,r,"extent")){extent=point(ip,v);if(extent.x<=0||extent.y<=0||extent.x>1e9||extent.y>1e9)fail(ip,"Canvas extent must be positive and bounded");}if(auto v=get(ip,r,"background")){double a[4];rgba(ip,v,a);bg={a[0],a[1],a[2],a[3]};}if(auto v=get(ip,r,"presenter"))presenter=Tcl_GetString(v);if(auto v=get(ip,r,"canvas_id")){if(!ids(c->scene(),ip).empty()||!ids(c->scene(),ip,true).empty())fail(ip,"Canvas identity may only be configured on an empty scene");canvasId=Tcl_GetString(v);if(!logicalIdentity(canvasId))fail(ip,"Canvas identity must match the bounded SDK identity grammar");}auto old=c->metadata(0);Obj meta(Tcl_DuplicateObj(old.p));put(meta.p,"canvas_id",Tcl_NewStringObj(canvasId.c_str(),-1));put(meta.p,"extent",xy(extent));Tcl_Obj *a[]={Tcl_NewDoubleObj(bg.red),Tcl_NewDoubleObj(bg.green),Tcl_NewDoubleObj(bg.blue),Tcl_NewDoubleObj(bg.alpha)};put(meta.p,"background",Tcl_NewListObj(4,a));c->saveMetadata(0,meta.p);status(ip,gx2d_background_set(c->scene(),bg));c->extent=extent;c->background=bg;c->presenter=presenter;c->canvasId=canvasId;model=get(ip,r,"extent")||get(ip,r,"background")||get(ip,r,"canvas_id");}
 else if(op=="tool_set"){fields(ip,r,{"tool"});std::string t=Tcl_GetString(get(ip,r,"tool",true));static const std::set<std::string> tools{"select","line","rectangle","ellipse","arrow","text","spline","translate","resize","rotate","pivot","pan"};if(!tools.count(t))fail(ip,"Unsupported Canvas tool");c->cancel();c->tool=t;}
 else if(op=="layer_select"){fields(ip,r,{"layer"});auto id=identity(ip,get(ip,r,"layer",true));c->ownedLayer(id);c->activeLayer=id;}
 else if(op=="layer_create"||op=="layer_update"){bool create=op=="layer_create";fields(ip,r,{"layer","properties","name","logical_id","blend","metadata"});gx2d_id id=create?0:identity(ip,get(ip,r,"layer",true));gx2d_layer_style s{1,1,0,0,1};if(!create)status(ip,gx2d_get_layer(c->scene(),id,&s));if(auto p=get(ip,r,"properties"))s=layerStyle(c,s,p);auto meta=mergedMetadata(c,id,r,"layer",true);if(create){status(ip,gx2d_add_layer(c->scene(),&s,&id));try{c->saveMetadata(id,meta.p);}catch(...){gx2d_delete_layer(c->scene(),id);throw;}if(!c->activeLayer)c->activeLayer=id;}else{auto old=c->metadata(id);c->saveMetadata(id,meta.p);auto code=gx2d_set_layer(c->scene(),id,&s);if(code!=GX2D_OK){c->saveMetadata(id,old.p);status(ip,code);}}put(out.p,"layer",Tcl_NewWideIntObj(id));model=true;}
 else if(op=="layer_delete"){fields(ip,r,{"layer","delete_objects"});auto id=identity(ip,get(ip,r,"layer",true));c->ownedLayer(id,true);std::vector<gx2d_id> members;for(auto object:ids(c->scene(),ip)){gx2d_style s;status(ip,gx2d_get_style(c->scene(),object,&s));if(s.layer==id){c->ownedObject(object,true);members.push_back(object);}}bool remove=get(ip,r,"delete_objects")&&boolean(ip,get(ip,r,"delete_objects"));if(!members.empty()&&!remove)fail(ip,"Canvas layer is not empty");deleteObjects(c,members);status(ip,gx2d_delete_layer(c->scene(),id));if(c->activeLayer==id)c->activeLayer=0;model=true;}
 else if(op=="layer_assign"){
  fields(ip,r,{"layer","objects"});auto target=identity(ip,get(ip,r,"layer",true));c->ownedLayer(target,true);auto objects=c->requestObjects(r);std::set<gx2d_id> moving(objects.begin(),objects.end());
  for(auto id:objects){gx2d_kind kind;status(ip,gx2d_kind_of(c->scene(),id,&kind));if(kind==GX2D_GROUP)for(auto member:groupMembers(c,id)){c->ownedObject(member,true);moving.insert(member);}}
  auto owners=groupOwners(c);for(auto id:std::vector<gx2d_id>(moving.begin(),moving.end())){auto parent=owners.find(id);if(parent==owners.end())continue;for(auto member:groupMembers(c,parent->second))if(!moving.count(member))fail(ip,"Move the whole native group to a layer");c->ownedObject(parent->second,true);moving.insert(parent->second);}
  for(auto id:moving){gx2d_style st;status(ip,gx2d_get_style(c->scene(),id,&st));st.layer=target;status(ip,gx2d_set_style(c->scene(),id,&st));}model=true;
 }
 else if(op=="object_create"||op=="object_adopt"){bool create=op=="object_create";fields(ip,r,{"definition","object","style","layer","kind","text","font","font_size","anchor","fill","z","name","logical_id","metadata"});gx2d_id id=create?0:identity(ip,get(ip,r,"object",true));if(!create)c->ownedObject(id);gx2d_style s{1,1,0,0,c->activeLayer,0,0.15,0.2,0.3,2,1,GX2D_LINE_SOLID,GX2D_MARKER_NONE};if(!create)status(ip,gx2d_get_style(c->scene(),id,&s));if(auto l=get(ip,r,"layer")){s.layer=identity(ip,l,true);if(s.layer)c->ownedLayer(s.layer,true);}else if(create&&s.layer)c->ownedLayer(s.layer,true);if(auto v=get(ip,r,"style"))s=style(c,s,v);if(auto z=get(ip,r,"z"))s.order=integer(ip,z);auto meta=mergedMetadata(c,id,r,"shape");validatePresentation(c,id,meta.p,get(ip,r,"definition"));if(create){Obj budget(Tcl_NewIntObj(257));auto created=c->call("sketch_create",{get(ip,r,"definition",true),budget.p});id=identity(ip,created.p);}try{status(ip,gx2d_set_style(c->scene(),id,&s));c->saveMetadata(id,meta.p);}catch(...){if(create)gx2d_delete_object(c->scene(),id);throw;}put(out.p,"object",Tcl_NewWideIntObj(id));model=true;}
 else if(op=="object_update"){
  fields(ip,r,{"object","definition","style","kind","text","font","font_size","anchor","fill","z","name","metadata"});auto id=identity(ip,get(ip,r,"object",true));c->ownedObject(id);gx2d_style before;status(ip,gx2d_get_style(c->scene(),id,&before));if(before.locked){fields(ip,r,{"object","style"});auto change=get(ip,r,"style",true);fields(ip,change,{"locked"});if(boolean(ip,get(ip,change,"locked",true)))fail(ip,"Canvas object is locked");if(before.layer)c->ownedLayer(before.layer,true);}else c->ownedObject(id,true);auto owners=groupOwners(c);auto inherited=owners.find(id);if(inherited!=owners.end())c->ownedObject(inherited->second,true);auto st=before;if(auto v=get(ip,r,"style"))st=style(c,st,v);if(auto z=get(ip,r,"z"))st.order=integer(ip,z);gx2d_kind kind;status(ip,gx2d_kind_of(c->scene(),id,&kind));auto meta=mergedMetadata(c,id,r,"shape");
  if(st.layer!=before.layer){auto owners=groupOwners(c);if(kind==GX2D_GROUP||owners.count(id))fail(ip,"Use layer_assign to move a whole native group");}
  if(kind==GX2D_GROUP){if(get(ip,r,"definition")||get(ip,meta.p,"fill")||get(ip,meta.p,"text")||get(ip,meta.p,"font")||st.red!=before.red||st.green!=before.green||st.blue!=before.blue||st.line_width!=before.line_width||st.line_style!=before.line_style||st.marker!=before.marker)fail(ip,"Native group supports visibility, selection, lock, order and scalar opacity; edit leaf color/geometry explicitly");auto type=get(ip,meta.p,"kind");if(type&&std::string(Tcl_GetString(type))!="group")fail(ip,"Native group kind cannot change");}
  else validatePresentation(c,id,meta.p,get(ip,r,"definition"));
  Obj n(Tcl_NewWideIntObj(id)),budget(Tcl_NewIntObj(257));auto old=c->metadata(id);c->saveMetadata(id,meta.p);try{if(auto d=get(ip,r,"definition"))c->call("sketch_update",{n.p,d,budget.p});}catch(...){c->saveMetadata(id,old.p);throw;}status(ip,gx2d_set_style(c->scene(),id,&st));model=true;
 }
 else if(op=="object_delete"){fields(ip,r,{"objects"});auto objects=c->requestObjects(r);deleteObjects(c,objects);model=true;}
 else if(op=="object_affine"||op=="object_duplicate"){
  bool copy=op=="object_duplicate";fields(ip,r,{"objects","matrix","layer"});auto objects=c->requestObjects(r);groupOwners(c);std::vector<gx2d_id> sourceGroups;for(auto id:objects){gx2d_kind kind;status(ip,gx2d_kind_of(c->scene(),id,&kind));if(kind==GX2D_GROUP)sourceGroups.push_back(id);}std::array<double,6> m{1,0,0,1,0,0};if(auto v=get(ip,r,"matrix"))m=matrix(ip,v);gx2d_id layer=0;if(auto v=get(ip,r,"layer")){layer=identity(ip,v);c->ownedLayer(layer,true);}Obj a(idsObj(objects)),b(matrixObj(m)),flag(Tcl_NewBooleanObj(copy));auto transformed=c->call("affine",{a.p,b.p,flag.p});Obj outputs(get(ip,transformed.p,"object_ids",true));
  std::vector<gx2d_id> newGroups;
  if(copy){
   try{
    std::map<std::string,std::string> rasterIds;
    for(auto v:list(ip,outputs.p)){
     auto id=identity(ip,v);auto meta=c->metadata(id);Obj fresh(Tcl_DuplicateObj(meta.p));put(fresh.p,"logical_id",Tcl_NewStringObj(c->fresh("object").c_str(),-1));validateMetadata(c,fresh.p,id);c->saveMetadata(id,fresh.p);gx2d_reference_image image;
     if(gx2d_image_get(c->scene(),id,&image)==GX2D_OK){const char *previous=nullptr;auto uuid=c->fresh("raster");if(gx2d_attribute_get(c->scene(),id,"gx.raster.uuid",&previous)==GX2D_OK)rasterIds.emplace(previous,uuid);status(ip,gx2d_attribute_set(c->scene(),id,"gx.raster.uuid",uuid.c_str()));}
     if(layer){gx2d_style st;status(ip,gx2d_get_style(c->scene(),id,&st));st.layer=layer;status(ip,gx2d_set_style(c->scene(),id,&st));}
    }
    for(auto v:list(ip,outputs.p)){
     auto id=identity(ip,v);const char *value=nullptr;if(gx2d_attribute_get(c->scene(),id,"gx.raster.layer",&value)!=GX2D_OK)continue;Obj props(Tcl_NewStringObj(value,-1));auto mask=get(ip,props.p,"mask_uuid");if(!mask||std::string(Tcl_GetString(mask)).empty())continue;auto mapped=rasterIds.find(Tcl_GetString(mask));if(mapped==rasterIds.end())fail(ip,"Raster copy requires copying its mask in the same admitted set");Obj updated(Tcl_DuplicateObj(props.p));put(updated.p,"mask_uuid",Tcl_NewStringObj(mapped->second.c_str(),-1));status(ip,gx2d_attribute_set(c->scene(),id,"gx.raster.layer",Tcl_GetString(updated.p)));
    }
    std::map<gx2d_id,gx2d_id> copies;auto sourceIds=list(ip,get(ip,transformed.p,"source_ids",true));auto copiedIds=list(ip,outputs.p);for(size_t i=0;i<sourceIds.size();++i)copies.emplace(identity(ip,sourceIds[i]),identity(ip,copiedIds[i]));std::set<gx2d_id> grouped;
    for(auto original:sourceGroups){std::vector<gx2d_id> members;for(auto member:groupMembers(c,original)){auto found=copies.find(member);if(found==copies.end())fail(ip,"Native group copy has an incomplete member map");members.push_back(found->second);grouped.insert(found->second);}gx2d_id group;status(ip,gx2d_add_group(c->scene(),members.data(),members.size(),&group));newGroups.push_back(group);gx2d_style st;status(ip,gx2d_get_style(c->scene(),original,&st));st.selected=0;if(layer)st.layer=layer;status(ip,gx2d_set_style(c->scene(),group,&st));auto meta=c->metadata(original);Obj fresh(Tcl_DuplicateObj(meta.p));put(fresh.p,"logical_id",Tcl_NewStringObj(c->fresh("group").c_str(),-1));put(fresh.p,"kind",Tcl_NewStringObj("group",-1));validateMetadata(c,fresh.p,group);c->saveMetadata(group,fresh.p);}
    std::vector<gx2d_id> selection=newGroups;for(auto v:copiedIds){auto id=identity(ip,v);if(!grouped.count(id))selection.push_back(id);}c->select(selection);put(out.p,"selection_changed",Tcl_NewBooleanObj(true));
   }catch(...){for(auto id:newGroups)gx2d_delete_object(c->scene(),id);for(auto v:list(ip,outputs.p))gx2d_delete_object(c->scene(),identity(ip,v));throw;}
  }
  put(out.p,"group_ids",idsObj(newGroups));put(out.p,"source_group_ids",idsObj(sourceGroups));put(out.p,"object_ids",outputs.p);put(out.p,"source_ids",get(ip,transformed.p,"source_ids",true));model=true;
 }
 else if(op=="object_group"){
  fields(ip,r,{"objects","layer"});auto objects=c->requestObjects(r);auto owners=groupOwners(c);gx2d_id layer=0;bool haveLayer=false;int order=std::numeric_limits<int>::max();std::set<gx2d_id> members(objects.begin(),objects.end());
  for(auto id:objects){gx2d_kind kind;status(ip,gx2d_kind_of(c->scene(),id,&kind));if(kind==GX2D_GROUP)fail(ip,"Nested Canvas groups are unsupported");if(owners.count(id))fail(ip,"Ungroup an existing member before regrouping");gx2d_style st;status(ip,gx2d_get_style(c->scene(),id,&st));order=std::min(order,st.order);if(!haveLayer){layer=st.layer;haveLayer=true;}else if(layer!=st.layer)fail(ip,"Canvas group members must share a layer");}
  if(auto v=get(ip,r,"layer")){auto target=identity(ip,v);if(layer!=target)fail(ip,"Canvas group target differs from member layer");c->ownedLayer(target,true);}
  auto rows=presentation(c);size_t index=0,first=SIZE_MAX,last=0,found=0;for(auto row:list(ip,rows.p)){auto id=identity(ip,get(ip,row,"object",true));gx2d_style st;status(ip,gx2d_get_style(c->scene(),id,&st));if(st.layer!=layer)continue;if(members.count(id)){first=std::min(first,index);last=index;++found;}++index;}if(found!=objects.size()||last-first+1!=found)fail(ip,"Canvas group members must be contiguous in their native layer");
  gx2d_id id;status(ip,gx2d_add_group(c->scene(),objects.data(),objects.size(),&id));try{Obj empty(Tcl_NewDictObj());auto meta=mergedMetadata(c,id,empty.p,"group");c->saveMetadata(id,meta.p);gx2d_style st;status(ip,gx2d_get_style(c->scene(),id,&st));st.layer=layer;st.order=order;status(ip,gx2d_set_style(c->scene(),id,&st));c->select({id});}catch(...){gx2d_delete_object(c->scene(),id);throw;}put(out.p,"object",Tcl_NewWideIntObj(id));put(out.p,"selection_changed",Tcl_NewBooleanObj(true));model=true;
 }
 else if(op=="object_ungroup"){fields(ip,r,{"object"});auto id=identity(ip,get(ip,r,"object",true));c->ownedObject(id,true);status(ip,gx2d_ungroup(c->scene(),id));model=true;}
 else if(op=="selection_set"){fields(ip,r,{"objects","mode"});auto values=list(ip,get(ip,r,"objects",true));std::vector<gx2d_id> a;for(auto v:values){auto id=identity(ip,v);c->ownedObject(id);a.push_back(id);}std::string mode=get(ip,r,"mode")?Tcl_GetString(get(ip,r,"mode")):"replace";if(mode!="replace"&&mode!="add"&&mode!="remove"&&mode!="subtract")fail(ip,"Unsupported Canvas selection mode");c->select(a,mode);put(out.p,"selection_changed",Tcl_NewBooleanObj(true));}
 else if(op=="selection_pick"){fields(ip,r,{"position","tolerance","mode"});auto p=point(ip,get(ip,r,"position",true));double t=get(ip,r,"tolerance")?number(ip,get(ip,r,"tolerance"),256):5;if(t<0)fail(ip,"Negative Canvas hit tolerance");auto a=pick(c,p,t);std::string mode=get(ip,r,"mode")?Tcl_GetString(get(ip,r,"mode")):"replace";if(mode!="replace"&&mode!="add"&&mode!="remove")fail(ip,"Unsupported Canvas selection mode");c->select(a,mode);put(out.p,"selection_changed",Tcl_NewBooleanObj(true));put(out.p,"objects",idsObj(a));}
 else fail(ip,"Unsupported native Canvas operation");
 if(model){++c->revision;put(out.p,"changed",Tcl_NewBooleanObj(true));put(out.p,"committed",Tcl_NewBooleanObj(true));}put(out.p,"revision",Tcl_NewWideIntObj(c->revision));return out;
}

Obj construction(Canvas *c,gx2d_point end){
 Obj d(Tcl_NewDictObj()),controls(Tcl_NewListObj(0,nullptr));auto a=c->startWorld;
 std::string family=c->tool=="arrow"?"line":c->tool=="text"?"rectangle":c->tool;
 put(d.p,"family",Tcl_NewStringObj(family.c_str(),-1));
 if(family=="spline"){for(auto p:c->constructionKnots)Tcl_ListObjAppendElement(c->ip,controls.p,xy(p));if(std::hypot(end.x-c->constructionKnots.back().x,end.y-c->constructionKnots.back().y)>1e-12)Tcl_ListObjAppendElement(c->ip,controls.p,xy(end));}
 else if(family=="ellipse"){Tcl_ListObjAppendElement(c->ip,controls.p,xy({(a.x+end.x)/2,(a.y+end.y)/2}));put(d.p,"radius_x",Tcl_NewDoubleObj(std::abs(end.x-a.x)/2));put(d.p,"radius_y",Tcl_NewDoubleObj(std::abs(end.y-a.y)/2));}
 else {Tcl_ListObjAppendElement(c->ip,controls.p,xy(a));Tcl_ListObjAppendElement(c->ip,controls.p,xy(end));}
 put(d.p,"controls",controls.p);return d;
}
void constructionMove(Canvas *c,gx2d_point p){
 auto ip=c->ip;gx2d_point end;status(ip,gx2d_device_to_world(c->scene(),p,&end));
 if(c->tool=="spline"){if(c->constructionKnots.size()<2&&std::hypot(end.x-c->constructionKnots.front().x,end.y-c->constructionKnots.front().y)<=1e-12)return;}
 else if(std::hypot(p.x-c->startDevice.x,p.y-c->startDevice.y)<1)return;
 if((c->tool=="rectangle"||c->tool=="ellipse"||c->tool=="text")&&(std::abs(end.x-c->startWorld.x)<1e-12||std::abs(end.y-c->startWorld.y)<1e-12))return;
 auto definition=construction(c,end);Obj budget(Tcl_NewIntObj(257));
 if(!c->previewObject){auto id=c->call("sketch_create",{definition.p,budget.p});c->previewObject=identity(ip,id.p);try{gx2d_style st;status(ip,gx2d_get_style(c->scene(),c->previewObject,&st));st.layer=c->activeLayer;st.red=.1;st.green=.25;st.blue=.5;st.line_width=2;status(ip,gx2d_set_style(c->scene(),c->previewObject,&st));Obj r(Tcl_NewDictObj());put(r.p,"kind",Tcl_NewStringObj(c->tool.c_str(),-1));if(c->tool=="text"){Obj text(Tcl_NewDictObj());put(text.p,"value",Tcl_NewStringObj("Text",-1));put(r.p,"text",text.p);}auto meta=mergedMetadata(c,c->previewObject,r.p,c->tool.c_str());c->saveMetadata(c->previewObject,meta.p);if(c->tool=="arrow"){gx2d_direction_marker marker;status(ip,gx2d_direction_marker_get(c->scene(),c->previewObject,&marker));marker.present=marker.visible=marker.forward=1;marker.fraction=1;marker.offset_px=0;marker.length_px=20;marker.color={.1,.25,.5,1};status(ip,gx2d_direction_marker_set(c->scene(),c->previewObject,&marker));}}catch(...){gx2d_delete_object(c->scene(),c->previewObject);c->previewObject=0;throw;}}
 else {Obj id(Tcl_NewWideIntObj(c->previewObject));c->call("sketch_update",{id.p,definition.p,budget.p});}
 c->changed=true;
}
void controlMove(Canvas *c,gx2d_point p){
 auto ip=c->ip;gx2d_point target;status(ip,gx2d_device_to_world(c->scene(),p,&target));Obj pt(xy(target));auto definition=c->cadCall("control","preview",{c->controlReference->p,pt.p});Obj budget(Tcl_NewIntObj(257));
 if(!c->previewObject){auto created=c->call("sketch_create",{definition.p,budget.p});c->previewObject=identity(ip,created.p);try{gx2d_style s;status(ip,gx2d_get_style(c->scene(),c->controlObject,&s));s.selectable=s.selected=0;status(ip,gx2d_set_style(c->scene(),c->previewObject,&s));auto original=c->metadata(c->controlObject);Obj meta(Tcl_DuplicateObj(original.p));put(meta.p,"logical_id",Tcl_NewStringObj(c->fresh("preview").c_str(),-1));c->saveMetadata(c->previewObject,meta.p);}catch(...){gx2d_delete_object(c->scene(),c->previewObject);c->previewObject=0;throw;}}
 else {Obj id(Tcl_NewWideIntObj(c->previewObject));c->call("sketch_update",{id.p,definition.p,budget.p});}
 c->controlTarget=target;c->changed=std::hypot(p.x-c->startDevice.x,p.y-c->startDevice.y)>.5;
}
Obj event(Canvas *c,const std::string &kind,Tcl_Obj *r){auto ip=c->ip;c->scene();
 if(kind=="key"){fields(ip,r,{"key","modifiers"});std::string key=Tcl_GetString(get(ip,r,"key",true));if(key=="Escape"){bool active=c->gesture;c->cancel();return receipt(false,false,false,active);}if(key=="Return"&&c->gesture&&c->gestureKind=="spline"){
   if(c->constructionKnots.size()<2)fail(ip,"Spline needs at least two distinct clicked knots before Return");
   gx2d_point end;status(ip,gx2d_world_to_device(c->scene(),c->constructionKnots.back(),&end));constructionMove(c,end);
   gx2d_id created=c->previewObject;c->previewObject=0;c->gesture=c->changed=false;c->constructionKnots.clear();++c->revision;c->select({created});auto out=receipt(true,false,true,false,true);put(out.p,"object",Tcl_NewWideIntObj(created));put(out.p,"revision",Tcl_NewWideIntObj(c->revision));return out;
  }if(c->gesture)fail(ip,"Cancel the Canvas gesture before this key");if(key=="Delete"||key=="BackSpace"){auto a=c->selected();if(list(ip,a.p).empty())return receipt();Obj request(Tcl_NewDictObj());put(request.p,"objects",a.p);return command(c,"object_delete",request.p);}return receipt();}
 if(kind=="resize"){
  fields(ip,r,{"width","height"});double w=number(ip,get(ip,r,"width",true),16384),h=number(ip,get(ip,r,"height",true),16384);if(w<1||h<1||w*h>32000000)fail(ip,"Canvas viewport exceeds native presentation bounds");
  /* Equal-aspect expansion is a derived presentation view. Reaccepting that
   * expanded world as the next requested camera accumulates zoom-out across
   * dimension changes. Preserve the existing requested camera, including any
   * explicit native pan/zoom, and derive its new effective view once. */
  gx2d_view v;status(ip,gx2d_view_requested(c->scene(),&v));v.width=w;v.height=h;v.left=std::min(v.left,w/4);v.right=std::min(v.right,w/4);v.top=std::min(v.top,h/4);v.bottom=std::min(v.bottom,h/4);status(ip,gx2d_view_set(c->scene(),&v));return receipt(true);
 }
 if(kind=="wheel"){fields(ip,r,{"position","delta","modifiers"});if(c->gesture)fail(ip,"Cancel the Canvas gesture before zoom");auto p=point(ip,get(ip,r,"position",true));double d=number(ip,get(ip,r,"delta",true),12000);status(ip,gx2d_view_zoom(c->scene(),std::pow(1.2,-d/120),p));return receipt(true);}
 if(kind!="down"&&kind!="move"&&kind!="up")fail(ip,"Unsupported Canvas event");fields(ip,r,{"position","modifiers"});auto p=point(ip,get(ip,r,"position",true));int modifiers=get(ip,r,"modifiers")?integer(ip,get(ip,r,"modifiers")):0;
 if(kind=="down"){
  if(c->gesture&&c->gestureKind=="spline"){
   gx2d_point knot;status(ip,gx2d_device_to_world(c->scene(),p,&knot));auto previous=c->constructionKnots.back();
   if(std::hypot(knot.x-previous.x,knot.y-previous.y)>1e-12){if(c->constructionKnots.size()>=256)fail(ip,"Spline construction is bounded to256 clicked knots");c->constructionKnots.push_back(knot);}
   constructionMove(c,p);c->lastDevice=p;return receipt(true,true);
  }
  if(c->gesture)fail(ip,"Canvas gesture already active");c->startDevice=c->lastDevice=p;status(ip,gx2d_device_to_world(c->scene(),p,&c->startWorld));c->changed=false;c->targets.clear();
  if(c->tool=="select"){
   auto picked=pick(c,p,5);std::string mode=(modifiers&1)?"add":"replace";c->select(picked,mode);
   if(picked.empty()||(modifiers&1))return receipt(false,false,false,false,true);
   gx2d_kind pickedKind;status(ip,gx2d_kind_of(c->scene(),picked.front(),&pickedKind));if((modifiers&4)&&pickedKind!=GX2D_GROUP){Obj scope(idsObj(picked)),at(xy(p)),tol(Tcl_NewDoubleObj(6));auto detail=word("detail");auto ref=c->cadCall("selection","pick",{scope.p,at.p,tol.p,detail.p});auto semantic=get(ip,ref.p,"semantic_kind");if(semantic&&std::string(Tcl_GetString(semantic))=="control"){c->controlReference.reset(new Obj(Tcl_DuplicateObj(ref.p)));c->controlObject=picked.front();c->gestureKind="control";c->gesture=true;return receipt(false,true,false,false,true);}}
  }
  if(c->tool=="select"||c->tool=="translate"||c->tool=="rotate"||c->tool=="pivot"||c->tool=="resize"){
   auto selected=c->selected();auto editableOwners=groupOwners(c);for(auto o:list(ip,selected.p)){auto id=identity(ip,o);c->ownedObject(id,true);auto owner=editableOwners.find(id);if(owner!=editableOwners.end())c->ownedObject(owner->second,true);c->targets.push_back(id);}if(c->targets.empty())return receipt();
   if(c->tool=="resize"){
    auto snap=c->cadCall("selection","get");auto sid=identity(ip,get(ip,snap.p,"id",true));status(ip,gx2d_selection_set_bounds(c->scene(),sid,&c->resizeBounds));
    if(c->resizeBounds.x1-c->resizeBounds.x0<=1e-12||c->resizeBounds.y1-c->resizeBounds.y0<=1e-12)fail(ip,"Canvas resize requires nonzero bounds");c->gestureKind="resize";c->previewMatrix={1,0,0,1,0,0};c->worldMatrix=c->previewMatrix;
   }else {
    auto handle=word(c->tool=="rotate"?"rotate":c->tool=="pivot"?"pivot":"free");Obj at(xy(p)),targets(idsObj(c->targets));c->cadCall("gesture","begin",{handle.p,at.p,targets.p});c->cadGesture=true;c->gestureKind="cad";
   }
  }else if(c->tool=="pan"){status(ip,gx2d_view_state_get(c->scene(),&c->startView));c->gestureKind="pan";}
  else {if(c->activeLayer)c->ownedLayer(c->activeLayer,true);c->gestureKind=c->tool=="spline"?"spline":"construction";if(c->tool=="spline")c->constructionKnots={c->startWorld};}
  c->gesture=true;return receipt(false,true,false,false,c->tool=="select");
 }
 if(!c->gesture)return receipt();
 if(kind=="up"&&c->gestureKind=="construction"&&c->tool=="text"&&!c->previewObject){gx2d_point end;status(ip,gx2d_world_to_device(c->scene(),{c->startWorld.x+96,c->startWorld.y-24},&end));p=end;}
 if(kind=="move"||kind=="up"){
  if(c->gestureKind=="construction"||c->gestureKind=="spline")constructionMove(c,p);
  else if(c->gestureKind=="control")controlMove(c,p);
  else if(c->gestureKind=="pan"){status(ip,gx2d_view_state_set(c->scene(),&c->startView));status(ip,gx2d_view_pan(c->scene(),p.x-c->startDevice.x,p.y-c->startDevice.y));c->changed=std::hypot(p.x-c->startDevice.x,p.y-c->startDevice.y)>.5;}
  else if(c->gestureKind=="cad"){Obj at(xy(p)),snap(Tcl_NewBooleanObj(1));c->cadCall("gesture","plan",{at.p,snap.p});c->cadCall("gesture","apply");c->changed=std::hypot(p.x-c->startDevice.x,p.y-c->startDevice.y)>.5;}
  else if(c->gestureKind=="resize"){
   gx2d_point now;status(ip,gx2d_device_to_world(c->scene(),p,&now));auto b=c->resizeBounds;double sx=1+(now.x-c->startWorld.x)/(b.x1-b.x0),sy=1+(now.y-c->startWorld.y)/(b.y1-b.y0);sx=std::max(.001,std::min(1000.,sx));sy=std::max(.001,std::min(1000.,sy));
   Obj targets(idsObj(c->targets));auto expanded=c->call("expand_objects",{targets.p});for(auto o:list(ip,expanded.p)){gx2d_reference_image image;if(gx2d_image_get(c->scene(),identity(ip,o),&image)==GX2D_OK){sy=sx;break;}}
   double m[6];status(ip,gx2d_scaling_matrix({b.x0,b.y0},{sx,sy},m));std::copy(m,m+6,c->worldMatrix.begin());
   gx2d_point a,ex,ey,ta,tx,ty;status(ip,gx2d_device_to_world(c->scene(),{0,0},&a));status(ip,gx2d_device_to_world(c->scene(),{1,0},&ex));status(ip,gx2d_device_to_world(c->scene(),{0,1},&ey));
   auto transform=[&](gx2d_point q){return gx2d_point{m[0]*q.x+m[1]*q.y+m[4],m[2]*q.x+m[3]*q.y+m[5]};};status(ip,gx2d_world_to_device(c->scene(),transform(a),&ta));status(ip,gx2d_world_to_device(c->scene(),transform(ex),&tx));status(ip,gx2d_world_to_device(c->scene(),transform(ey),&ty));c->previewMatrix={tx.x-ta.x,ty.x-ta.x,tx.y-ta.y,ty.y-ta.y,ta.x,ta.y};c->changed=std::abs(sx-1)>1e-12||std::abs(sy-1)>1e-12;
  }
  c->lastDevice=p;
 }
 if(kind=="move"||c->gestureKind=="spline")return receipt(c->changed,true);
 bool changed=c->changed,model=c->gestureKind!="pan";gx2d_id created=c->previewObject;
 if(!changed){c->cancel();return receipt(false,false,false,true);}
 try{if(c->cadGesture)c->cadCall("gesture","commit");else if(c->gestureKind=="control"){Obj target(xy(c->controlTarget));c->cadCall("control","edit",{c->controlReference->p,target.p});if(c->previewObject)status(ip,gx2d_delete_object(c->scene(),c->previewObject));created=0;}else if(c->gestureKind=="resize")status(ip,gx2d_affine_objects(c->scene(),c->targets.data(),c->targets.size(),c->worldMatrix.data()));}
 catch(...){c->cancel();throw;}
 c->previewObject=0;c->gesture=c->changed=c->cadGesture=false;c->targets.clear();c->controlReference.reset();c->controlObject=0;c->previewMatrix={1,0,0,1,0,0};c->worldMatrix=c->previewMatrix;if(model)++c->revision;if(created)c->select({created});auto out=receipt(true,false,model);if(created)put(out.p,"object",Tcl_NewWideIntObj(created));put(out.p,"revision",Tcl_NewWideIntObj(c->revision));return out;
}
Obj presentation(Canvas *c){
 auto ip=c->ip;auto owners=groupOwners(c);auto selected=c->selected();std::set<gx2d_id> chosen;for(auto o:list(ip,selected.p))chosen.insert(identity(ip,o));if(!chosen.empty()){auto expanded=c->call("expand_objects",{selected.p});for(auto o:list(ip,expanded.p))chosen.insert(identity(ip,o));}std::set<gx2d_id> preview;if(c->gestureKind=="resize"&&c->gesture&&!c->targets.empty()){Obj a(idsObj(c->targets));auto expanded=c->call("expand_objects",{a.p});for(auto o:list(ip,expanded.p))preview.insert(identity(ip,o));}
 struct Row {gx2d_id id,layer,group,key;int layerOrder,ownerOrder,objectOrder;Obj metadata;std::string logical;};std::vector<Row> rows;
 for(auto id:ids(c->scene(),ip)){
  if(c->gesture&&c->gestureKind=="control"&&c->previewObject&&id==c->controlObject)continue;gx2d_kind kind;status(ip,gx2d_kind_of(c->scene(),id,&kind));if(kind==GX2D_GROUP)continue;gx2d_style st;status(ip,gx2d_get_style(c->scene(),id,&st));gx2d_layer_style ls{1,1,0,0,1};if(st.layer)status(ip,gx2d_get_layer(c->scene(),st.layer,&ls));auto meta=c->metadata(id);auto logical=get(ip,meta.p,"logical_id");if(!logical)continue;gx2d_id group=0,key=id;int ownerOrder=st.order;auto parent=owners.find(id);if(parent!=owners.end()){group=parent->second;gx2d_style gs;status(ip,gx2d_get_style(c->scene(),group,&gs));ownerOrder=gs.order;auto members=groupMembers(c,group);key=*std::min_element(members.begin(),members.end());}rows.push_back({id,st.layer,group,key,ls.order,ownerOrder,st.order,std::move(meta),Tcl_GetString(logical)});
 }
 std::sort(rows.begin(),rows.end(),[](const Row &a,const Row &b){if(a.layerOrder!=b.layerOrder)return a.layerOrder<b.layerOrder;if(a.layer!=b.layer)return a.layer<b.layer;if(a.ownerOrder!=b.ownerOrder)return a.ownerOrder<b.ownerOrder;if(a.key!=b.key)return a.key<b.key;if(a.objectOrder!=b.objectOrder)return a.objectOrder<b.objectOrder;return a.id<b.id;});Obj out(Tcl_NewListObj(0,nullptr));int z=0;
 for(auto &r:rows){Obj d(Tcl_NewDictObj());put(d.p,"id",Tcl_NewStringObj(r.logical.c_str(),-1));put(d.p,"object",Tcl_NewWideIntObj(r.id));put(d.p,"z",Tcl_NewIntObj(z++));put(d.p,"canvas_metadata",r.metadata.p);if(r.group)put(d.p,"group",Tcl_NewWideIntObj(r.group));put(d.p,"controls",Tcl_NewBooleanObj(chosen.count(r.id)!=0));if(preview.count(r.id))put(d.p,"preview_matrix",matrixObj(c->previewMatrix));Tcl_ListObjAppendElement(ip,out.p,d.p);}return out;
}
void closed(void *p){auto c=(Canvas *)p;auto source=c->source;c->source=nullptr;c->gesture=c->changed=c->cadGesture=false;c->previewObject=0;c->targets.clear();gx2d_sprite_source_v1_unlisten(source,c);}
void deleted(ClientData p){delete (Canvas *)p;}
int dispatch(ClientData data,Tcl_Interp *ip,int n,Tcl_Obj *const a[]){
 auto c=(Canvas *)data;
 try{
  if(n==2&&std::string(Tcl_GetString(a[1]))=="dispose"){Tcl_DeleteCommandFromToken(ip,c->command);return TCL_OK;}
  Obj result(Tcl_NewDictObj());std::string op=n>1?Tcl_GetString(a[1]):"";
  if(op=="state"&&n==2)result=state(c);
  else if(op=="state"&&n==3&&std::string(Tcl_GetString(a[2]))=="scalar")result=state(c,false);
  else if(op=="presentation"&&n==2)result=presentation(c);
  else if(op=="command"&&n==4){IdentityScope identities(c);result=command(c,Tcl_GetString(a[2]),a[3]);}
  else if(op=="event"&&n==4){IdentityScope identities(c);result=event(c,Tcl_GetString(a[2]),a[3]);}
  else fail(ip,"Canvas needs state ?scalar?, command operation dictionary, event kind dictionary, presentation or dispose");
  Tcl_SetObjResult(ip,result.p);return TCL_OK;
 }catch(const Error &){return TCL_ERROR;}catch(const std::exception &e){Tcl_SetObjResult(ip,Tcl_NewStringObj(e.what(),-1));return TCL_ERROR;}
}
}
extern "C" int gx2d_canvas_v1_create(Tcl_Interp *ip,gx2d_sprite_source_v1 *source,uint64_t scene,Tcl_ObjCmdProc *backend,ClientData backendData){
 try{if(!source||!gx2d_sprite_source_v1_scene(source)||!backend)fail(ip,"Canvas requires a live existing native scene");static uint64_t serial=0;auto c=std::unique_ptr<Canvas>(new Canvas{ip,source,scene,backend,backendData});auto stamp=(uint64_t)std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count();c->name="::gx::native2d::canvas"+std::to_string(++serial);c->canvasId="canvas-"+std::to_string(stamp)+"-"+std::to_string(serial);c->serial=stamp;
  if(gx2d_cad_controller_v1_create(ip,source,scene,0,backend,backendData)!=TCL_OK)throw Error{};c->cad=Tcl_GetString(Tcl_GetObjResult(ip));auto meta=c->metadata(0);if(auto o=get(ip,meta.p,"canvas_id"))c->canvasId=Tcl_GetString(o);if(auto o=get(ip,meta.p,"extent"))c->extent=point(ip,o);if(auto o=get(ip,meta.p,"background")){double a[4];rgba(ip,o,a);c->background={a[0],a[1],a[2],a[3]};}
  gx2d_sprite_source_v1_listen(source,c.get(),closed);c->command=Tcl_CreateObjCommand(ip,c->name.c_str(),dispatch,c.get(),deleted);Tcl_SetObjResult(ip,Tcl_NewStringObj(c->name.c_str(),-1));c.release();return TCL_OK;
 }catch(const Error &){return TCL_ERROR;}catch(const std::exception &e){Tcl_SetObjResult(ip,Tcl_NewStringObj(e.what(),-1));return TCL_ERROR;}
}
