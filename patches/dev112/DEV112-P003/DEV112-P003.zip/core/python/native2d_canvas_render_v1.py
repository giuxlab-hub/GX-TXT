# SPDX-License-Identifier: GPL-3.0-or-later
"""Frozen Canvas → existing native retained compositor, inside a managed Job.

This rebuilds the exact existing geometry/resource definitions in an isolated
native scene. It provides no scientific geometry, pixel engine or shadow store.
"""
import hashlib
from pathlib import Path
import time
import tkinter
from gxtxt_scientific_execution import tdict, tvalue


def materialize(context, manifest):
    framework = Path(__file__).resolve().parents[2]
    snapshot = tdict(manifest['snapshot'])
    width, height = map(int, tkinter.Tcl().splitlist(snapshot['extent']))
    if not 1 <= width <= 16384 or not 1 <= height <= 16384 or width*height > 16777216:
        raise ValueError('Native Canvas export extent exceeds its admitted capacity')
    # Trusted host captures its existing display endpoint, not an SDK field.
    # The withdrawn widget supplies Tk font/photo services; no screen pixels
    # or mapped widget dimensions determine the materialized document.
    root = tkinter.Tk(screenName=manifest['display'])
    root.withdraw()
    root.tk.wantobjects(False)
    if 'tk_scaling' in manifest:
        root.tk.call('tk','scaling',manifest['tk_scaling'])
    for declared, actual in tdict(manifest.get('fonts','')).items():
        if declared in root.tk.splitlist(root.tk.call('font','names')):
            root.tk.call('font','configure',declared,*root.tk.splitlist(actual))
        else:
            # Preserve custom named aliases and inert list specifications with
            # their actual captured font properties, never a silent fallback.
            root.tk.call('font','create',declared,*root.tk.splitlist(actual))
    scene = facade = presenter = None
    photos = []
    started = time.monotonic_ns()
    try:
        root.tk.call('load', str(framework/'core/native2d/bin/gx2dtcl.so'), 'Gx2dtcl')
        core = '::GX::Native2D::core'
        scene = root.tk.call(core, 'scene')
        facade = root.tk.call(core, 'canvas_create', scene)
        root.tk.call(facade, 'command', 'configure', tvalue(dict(extent=[width,height], background=snapshot['background'], canvas_id=snapshot['canvas_id'])))
        layers = {}
        for raw in root.tk.splitlist(snapshot['layers']):
            layer = tdict(raw)
            result = tdict(root.tk.call(facade, 'command', 'layer_create', tvalue(dict(name=layer['name'], logical_id=layer['logical_id'], properties=layer['properties'], blend=layer['blend']))))
            native = result['layer']
            layers[layer['logical_id']] = native
            for key, value in tdict(layer['attributes']).items():
                root.tk.call(core, 'identity_attribute', scene, native, key, value)
        objects = {}
        aliases = tdict(manifest['aliases'])
        image_photos = {}
        source_records = []
        for raw in root.tk.splitlist(snapshot['objects']):
            item = tdict(raw)
            reference = tdict(item['resource'])
            metadata = tdict(reference['metadata'])
            logical = item['logical_id']
            leaf_aliases=tdict(aliases[logical])
            raw_bytes = context.inputs[leaf_aliases['geometry']]
            if hashlib.sha256(raw_bytes).hexdigest() != reference['sha256']:
                raise ValueError('Frozen Canvas geometry resource SHA mismatch')
            if 'reference_image' in metadata:
                image = tdict(metadata['image_resource'])
                alias = leaf_aliases['image']
                pixels = context.inputs[alias]
                if hashlib.sha256(pixels).hexdigest() != image['sha256']:
                    raise ValueError('Frozen Canvas original image SHA mismatch')
                native = root.tk.call(core, 'image_create', scene, metadata['reference_image'])
                photo = root.tk.call('image', 'create', 'photo', '-data', pixels, '-format', 'png')
                photos.append(photo)
                image_photos[logical] = dict(photo=photo, identity=image['sha256'])
                from gxtxt_native2d_raster import png_info
                source_info=png_info(pixels)
                source_records.append(dict(logical_id=logical, source_sha256=image['sha256'], original_bytes=len(pixels),original_bit_depth=source_info[2],original_color_type=source_info[3]))
            elif 'sketch_definition' in metadata:
                native = root.tk.call(core, 'sketch_create', scene, metadata['sketch_definition'], int(metadata['point_count']))
            else:
                kind = metadata.get('native_kind', 'curve')
                operation = {'curve':'append_binary_xy','point_set':'append_binary_pointset','point':'append_binary_point'}.get(kind)
                if operation is None:
                    raise ValueError('Unsupported frozen native leaf; output cannot omit it')
                native = root.tk.call(core, operation, scene, 0, raw_bytes)
            objects[logical] = native
            attributes=tdict(metadata.get('sketch_attributes',''))
            if 'gx.raster.layer' in attributes:
                policy=tdict(attributes['gx.raster.layer'])
                if policy.get('mask_uuid') or policy.get('roi_id') or policy.get('mask_only','0') not in ('0','false','no','off'):
                    raise ValueError('Mixed Canvas output cannot silently omit an image mask; materialize it with the existing raster owner first')
            if 'gap_resource' in tdict(metadata.get('geometry_metadata','')):
                raise ValueError('Frozen point-backed gap resource requires an explicit native gap binding; output cannot silently connect it')
            for key, value in attributes.items():
                root.tk.call(core, 'identity_attribute', scene, native, key, value)
            if 'native_direction' in metadata:
                root.tk.call(core, 'direction_marker', scene, native, metadata['native_direction'])
            style = dict(tdict(item['style']), layer=layers[item['layer_logical_id']])
            root.tk.call(core, 'object_style', scene, native, tvalue(style))
            # Empty display names are admitted Canvas state. Native identity
            # names are optional and its setter requires a nonempty value.
            if item['name']:
                root.tk.call(core, 'identity_name', scene, native, item['name'])
            root.tk.call(facade, 'command', 'object_adopt', tvalue(dict(object=native, logical_id=logical, layer=layers[item['layer_logical_id']])))
        for raw in root.tk.splitlist(snapshot['groups']):
            group = tdict(raw)
            members = [objects[logical] for logical in root.tk.splitlist(group['members'])]
            native = root.tk.call(core, 'group', scene, tuple(members))
            objects[group['logical_id']] = native
            for key, value in tdict(group['attributes']).items():
                root.tk.call(core, 'identity_attribute', scene, native, key, value)
            style = dict(tdict(group['style']), layer=layers[group['layer_logical_id']])
            root.tk.call(core, 'object_style', scene, native, tvalue(style))
            if group['name']:
                root.tk.call(core, 'identity_name', scene, native, group['name'])
        root.tk.call(core, 'view', scene, (width,height,0,0,0,0,(0,0,width,height)))
        canvas = tkinter.Canvas(root, width=1, height=1, borderwidth=0, highlightthickness=0)
        presenter = root.tk.call('::gx::native2d::sprite_scene', canvas._w)
        presentation = root.tk.call(facade, 'presentation')
        # The native facade owns actual mixed stacking and exact metadata.
        # Rows are enriched only with already verified internal image handles.
        rows = []
        for raw in root.tk.splitlist(presentation):
            row = tdict(raw)
            if row['id'] in image_photos:
                row['image'] = image_photos[row['id']]
            rows.append(row)
        root.tk.call(presenter, 'begin')
        root.tk.call(core, 'sprite_sync', scene, presenter, tvalue(rows), 'composition canvas budget 65536')
        root.tk.call(presenter, 'end')
        output = context.scratch/'canvas-native.png'
        receipt = tdict(root.tk.call(presenter, 'export_png', str(output)))
        if int(receipt['width']) != width or int(receipt['height']) != height or receipt.get('depth') != '8':
            raise ValueError('Native materializer returned an incompatible document extent/depth')
        return output, dict(renderer=receipt, sources=source_records, native_materialize_ns=time.monotonic_ns()-started,
                            geometry_policy='exact native definitions; native bounded retained presentation sampling; all admitted mixed rows included',
                            image_sampling='existing native Cairo bilinear image projection; antialiased native vector presentation',
                            fonts=tdict(manifest.get('fonts','')),
                            displayed_screen_pixels_used=False, mapped_widget_required=False)
    finally:
        if presenter:
            try: root.tk.call(presenter, 'destroy')
            except tkinter.TclError: pass
        if facade:
            try: root.tk.call(facade, 'dispose')
            except tkinter.TclError: pass
        if scene:
            try: root.tk.call('::GX::Native2D::core', 'destroy', scene)
            except tkinter.TclError: pass
        for photo in photos:
            try: root.tk.call('image', 'delete', photo)
            except tkinter.TclError: pass
        root.destroy()
