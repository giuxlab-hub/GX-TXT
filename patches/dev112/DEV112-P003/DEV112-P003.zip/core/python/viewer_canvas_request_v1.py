# SPDX-License-Identifier: GPL-3.0-or-later
"""Finite typed Canvas admission. No widget, path, pixel or Resource authority."""
import json
import math
import re

OPERATIONS = ('new', 'bind_source', 'tool_set', 'selection_set', 'object_create',
              'object_update', 'object_delete', 'object_affine', 'object_duplicate',
              'object_group', 'object_ungroup', 'copy', 'cut', 'paste', 'layer_create',
              'layer_update', 'layer_delete', 'layer_assign', 'layer_select',
              'layer_reorder', 'merge', 'flatten', 'filter', 'undo', 'redo', 'fit',
              'zoom', 'pan', 'save', 'open', 'cancel', 'dispose', 'inspect', 'publish')
TOOLS = ('select', 'line', 'rectangle', 'ellipse', 'arrow', 'text', 'spline',
         'translate', 'resize', 'rotate', 'pivot', 'pan')
BLENDS = ('Over', 'Multiply', 'Screen', 'Overlay', 'SoftLight')


def decode_client_request(raw, error):
    """Shared existing client transport, with strict duplicate/kind/size limits."""
    def reject(message):
        raise error(message, 'RUNTIME_VALUE')
    if not isinstance(raw, str) or len(raw.encode('utf-8')) > 49152:
        reject('Typed client request exceeds 48 KiB')
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('Duplicate typed client field')
            result[key] = value
        return result
    try:
        envelope = json.loads(raw, object_pairs_hook=unique)
    except (ValueError, TypeError, RecursionError):
        reject('Typed client request must be strict JSON')
    nodes = [0]
    def decode(item, depth=0):
        nodes[0] += 1
        if depth > 64 or nodes[0] > 8192 or not isinstance(item, dict) or set(item) != {'kind', 'value'}:
            reject('Invalid bounded typed client value')
        kind, value = item['kind'], item['value']
        if kind == 'null':
            valid = value is None
        elif kind == 'text':
            valid = isinstance(value, str) and '\0' not in value
        elif kind == 'bool':
            valid = type(value) is bool
        elif kind == 'int':
            valid = type(value) is int and -(2**63) <= value < 2**63
        elif kind == 'real':
            valid = type(value) in (int, float) and math.isfinite(value)
        elif kind == 'array':
            if not isinstance(value, list):
                reject('Typed client array mismatch')
            return [decode(child, depth+1) for child in value]
        elif kind == 'object':
            if not isinstance(value, dict) or any(not isinstance(key, str) or '\0' in key for key in value):
                reject('Typed client object mismatch')
            return {key: decode(child, depth+1) for key, child in value.items()}
        else:
            valid = False
        if not valid:
            reject('Typed client value does not match its kind')
        return value
    decoded = decode(envelope)
    if not isinstance(decoded, dict) or set(decoded) != {'operation', 'request'} or not isinstance(decoded['operation'], str) or not isinstance(decoded['request'], dict):
        reject('Typed client requires operation/request object')
    return decoded


def validate_canvas_request(operation, request, error):
    """Validate inert stable identities and finite public operation schemas."""
    def reject(message='Unknown or invalid finite Canvas field'):
        raise error(message, 'RUNTIME_VALUE')
    def fields(value, required=(), optional=()):
        if not isinstance(value, dict) or set(value)-set(required)-set(optional) or not set(required).issubset(value):
            reject('Unknown or missing finite Canvas request fields')
    def number(value, minimum=-1e12, maximum=1e12):
        if type(value) not in (int, float) or not math.isfinite(value) or not minimum <= value <= maximum:
            reject('Canvas number must be finite and within its declared bounds')
    def integer(value, minimum=0, maximum=2**63-1):
        if type(value) is not int or not minimum <= value <= maximum:
            reject('Canvas integer must be within its declared bounds')
    def text(value, maximum=256, empty=False):
        if not isinstance(value, str) or '\0' in value or len(value.encode('utf-8')) > maximum or (not empty and not value):
            reject('Canvas text must be bounded inert UTF-8')
    def identity(value):
        text(value, 128)
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_.:#-]{0,127}', value):
            reject('Canvas target requires a stable logical identity, never a path or native number')
    def identities(value):
        if not isinstance(value, list) or not value or len(value) > 65536:
            reject('Canvas targets require 1..65536 logical identities')
        for item in value:
            identity(item)
        if len(set(value)) != len(value):
            reject('Canvas target identities must be distinct')
    def coordinates(value, count):
        if not isinstance(value, list) or len(value) != count:
            reject('Canvas coordinate tuple has the wrong size')
        for item in value:
            number(item)
    def color(value):
        coordinates(value, 4)
        for item in value:
            number(item, 0, 1)
    def properties(value, layer=False):
        allowed = ('visible', 'selectable', 'locked', 'order', 'opacity') if layer else ('visible', 'selectable', 'selected', 'locked', 'order', 'color', 'line_width', 'line_style', 'marker')
        fields(value, (), allowed)
        for key, item in value.items():
            if key in ('visible', 'selectable', 'selected', 'locked'):
                if type(item) is not bool:
                    reject('Canvas visibility/lock flags must be Booleans')
            elif key == 'order':
                integer(item, -(2**31), 2**31-1)
            elif key == 'opacity':
                number(item, 0, 1)
            elif key == 'color':
                color(item)
            elif key == 'line_width':
                number(item, 0, 256)
            elif key == 'line_style':
                integer(item, 0, 2)
            elif key == 'marker':
                integer(item, 0, 3)
    def definition(value, nested=False):
        fields(value, ('family',), ('controls', 'matrix', 'radius_x', 'radius_y', 'rotation', 'angle_start', 'angle_sweep', 'tangents', 'segments', 'closed', 'parts', 'nodes', 'tolerance'))
        family = value['family']
        if family not in ('point', 'line', 'construction_line', 'polyline', 'rectangle', 'circle', 'arc', 'ellipse', 'quadratic_bezier', 'cubic_bezier', 'spline', 'path', 'composite_path', 'compound'):
            reject('Unsupported existing native sketch family')
        if family in ('composite_path', 'compound'):
            parts = value.get('parts')
            if nested or not isinstance(parts, list) or not 1 <= len(parts) <= 256:
                reject('Native composition needs 1..256 flat exact leaves')
            for part in parts:
                fields(part, ('definition',), ('reversed',))
                definition(part['definition'], True)
                if 'reversed' in part and type(part['reversed']) is not bool:
                    reject()
        else:
            controls = value.get('controls')
            if not isinstance(controls, list) or not 1 <= len(controls) <= 65536:
                reject('Typed native sketch needs 1..65536 defining controls')
            for point in controls:
                coordinates(point, 2)
        for key, item in value.items():
            if key == 'matrix':
                coordinates(item, 6)
            elif key in ('radius_x', 'radius_y', 'rotation', 'angle_start', 'angle_sweep', 'tolerance'):
                number(item)
            elif key == 'closed' and type(item) is not bool:
                reject()
            elif key == 'tangents':
                if not isinstance(item, list) or len(item) != len(value.get('controls', ())):
                    reject()
                for tangent in item:
                    if not isinstance(tangent, list) or len(tangent) != 3:
                        reject()
                    integer(tangent[0], 0, 3)
                    coordinates(tangent[1], 2)
                    coordinates(tangent[2], 2)
            elif key == 'segments':
                if not isinstance(item, list) or len(item) > 65536:
                    reject()
                for segment in item:
                    fields(segment, ('family', 'first', 'last'))
                    if segment['family'] != 'line':
                        reject()
                    integer(segment['first'], 0, 65535)
                    integer(segment['last'], 0, 65535)
            elif key == 'nodes':
                if not isinstance(item, list) or len(item) > 65536:
                    reject()
                for node in item:
                    integer(node, 0, 65535)
    schemas = {
        'new': (('width', 'height'), ('background',)),
        'bind_source': ((), ('source_selector', 'dataset_id', 'layer')),
        'tool_set': (('tool',), ()), 'selection_set': (('objects',), ('mode',)),
        'object_create': (('definition',), ('style', 'layer', 'kind', 'text', 'fill')),
        'object_update': (('object',), ('definition', 'style', 'text', 'fill')),
        'object_delete': ((), ('objects',)), 'copy': ((), ('objects',)), 'cut': ((), ('objects',)),
        'object_affine': (('objects', 'matrix'), ()),
        'object_duplicate': (('objects',), ('layer', 'matrix')),
        'object_group': (('objects',), ('layer',)), 'object_ungroup': (('object',), ()),
        'paste': ((), ('layer',)), 'layer_create': ((), ('name', 'properties', 'blend')),
        'layer_update': (('layer',), ('properties', 'name', 'blend')),
        'layer_delete': (('layer',), ('delete_objects',)),
        'layer_assign': (('layer', 'objects'), ()), 'layer_select': (('layer',), ()),
        'layer_reorder': (('layer', 'order'), ()), 'merge': (('layers',), ('target',)),
        'flatten': ((), ('layers', 'precision')), 'filter': (('name',), ('object', 'parameters')),
        'zoom': (('factor',), ('center',)), 'pan': (('dx', 'dy'), ()),
        'open': (('document_id',), ()), 'publish': (('dataset_id',), ('name', 'format', 'precision')),
    }
    if operation not in OPERATIONS:
        reject('Unknown finite Canvas operation')
    required, optional = schemas.get(operation, ((), ()))
    fields(request, required, (*optional, 'expected_revision'))
    for key, value in request.items():
        if key == 'expected_revision':
            integer(value)
        elif key in ('object', 'layer', 'target', 'document_id', 'dataset_id'):
            identity(value)
        elif key in ('objects', 'layers'):
            if key == 'objects' and operation == 'selection_set' and value == []:
                continue
            identities(value)
        elif key in ('width', 'height'):
            number(value, 1, 16384)
        elif key in ('background', 'fill'):
            color(value)
        elif key == 'source_selector':
            integer(value, 1, 512)
        elif key == 'tool':
            if value not in TOOLS:
                reject('Unknown finite native Canvas tool')
        elif key == 'mode':
            if value not in ('replace', 'add', 'subtract'):
                reject()
        elif key == 'definition':
            definition(value)
        elif key == 'style':
            properties(value)
        elif key == 'properties':
            properties(value, True)
        elif key == 'matrix':
            coordinates(value, 6)
        elif key == 'center':
            coordinates(value, 2)
        elif key == 'factor':
            number(value, 0.000001, 1000000)
        elif key in ('dx', 'dy'):
            number(value)
        elif key == 'order':
            integer(value, -(2**31), 2**31-1)
        elif key == 'blend':
            if value not in BLENDS:
                reject('Unsupported exact Canvas blend')
        elif key == 'delete_objects':
            if type(value) is not bool:
                reject()
        elif key == 'kind':
            if value not in ('shape', 'arrow', 'text', 'spline', 'path'):
                reject()
        elif key == 'name':
            text(value, 128)
        elif key == 'text':
            fields(value, ('value',), ('font', 'font_size', 'anchor'))
            text(value['value'], 4096, True)
            if 'font' in value:
                text(value['font'], 128)
            if 'font_size' in value:
                number(value['font_size'], 1, 512)
            if 'anchor' in value and value['anchor'] not in ('n', 'ne', 'e', 'se', 's', 'sw', 'w', 'nw', 'center'):
                reject()
        elif key == 'precision' and value != 'rgba8':
            reject('Canvas display raster output supports explicit rgba8 only')
        elif key == 'format' and value != 'png':
            reject('Canvas output supports explicit PNG only')
    if operation == 'bind_source' and (('source_selector' in request) + ('dataset_id' in request) != 1):
        reject('Bind exactly one canonical Dataset or declared raster selector')
    if operation == 'new' and request['width']*request['height'] > 16777216:
        reject('Canvas extent exceeds existing raster pixel capacity')
    if operation == 'filter':
        name = request['name']
        if name not in ('grayscale', 'invert', 'brightness_contrast', 'blur', 'sharpen'):
            reject('Unsupported finite Canvas filter')
        params = request.get('parameters', {})
        allowed = ('brightness', 'contrast') if name == 'brightness_contrast' else ('radius',) if name in ('blur', 'sharpen') else ()
        fields(params, (), allowed)
        for key, value in params.items():
            number(value, -100 if key in ('brightness', 'contrast') else 0, 100 if key in ('brightness', 'contrast') else 16)
    return request
