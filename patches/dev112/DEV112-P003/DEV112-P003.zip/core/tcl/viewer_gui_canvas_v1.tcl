# SPDX-License-Identifier: GPL-3.0-or-later
# Existing declarative Native2D component, opt-in reusable Canvas mode.
proc ::GX::_viewerGuiCanvasDefinition {window component} {
    if {![viewerGuiDesignGuard $window]} {error {Session changed; reopen the Canvas Viewer}}
    set definition [viewerGuiDesignComponent $window $component]
    if {[dict get $definition type] ne {native2d} || [datasetPublicationV2DictDefault [dict get $definition properties] source_kind {}] ne {canvas}} {error {Declare a Native2D source_kind canvas component in Interface Builder}}
    return $definition
}
proc ::GX::_viewerGuiCanvasInitialize {window {payload {}}} {
    set instance [dict get $::GX::ViewerGui::instances $window]
    foreach component [dict get $instance design components] {
        set properties [dict get $component properties]
        if {[dict get $component type] ne {native2d} || [datasetPublicationV2DictDefault $properties source_kind {}] ne {canvas}} continue
        set id [dict get $component id];set widget [dict get $instance widgets $id]
        if {[dict exists $::GX::ViewerGui::instances $window canvas_slots $id]} continue
        if {[dict get $instance mode] eq {demo} || [catch {interactiveDocumentSessionToken}]} {
            foreach child [winfo children $widget] {destroy $child}
            set notice [expr {[dict get $instance mode] eq {demo} ? {Canvas layout preview — use Builder Runtime Test to draw and edit.} : {Canvas — open a Session, then reopen this Viewer to draw and edit.}}]
            ttk::label $widget.empty -text $notice -wraplength 360
            pack $widget.empty -fill both -expand 1
            continue
        }
        set options [dict create width [datasetPublicationV2DictDefault $properties canvas_width 1024] height [datasetPublicationV2DictDefault $properties canvas_height 768] background [datasetPublicationV2DictDefault $properties canvas_background {1 1 1 1}]]
        if {[dict exists $payload domain_state native2d_canvas $id document_id]} {dict set options document_id [dict get $payload domain_state native2d_canvas $id document_id]}
        set handle [native2DCanvasCreate [dict get $instance module] [dict get $instance provider] $options]
        try {
            foreach child [winfo children $widget] {destroy $child}
            native2DCanvasMount $handle $widget [dict create controls [datasetPublicationV2DictDefault $properties canvas_controls 1] callback [list ::GX::_viewerCanvasEvent $window $id]]
            dict set ::GX::ViewerGui::instances $window canvas_slots $id $handle
        } on error {message errorOptions} {native2DCanvasDispose $handle;return -options $errorOptions $message}
    }
}
proc ::GX::_viewerCanvasHandle {window component} {
    _viewerGuiCanvasDefinition $window $component
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots $component]} {error {Open a Session and Preview or reopen this Canvas component}}
    return [dict get $::GX::ViewerGui::instances $window canvas_slots $component]
}
proc ::GX::viewerGuiDesignCanvasDescribe {window component} {return [native2DCanvasDescribe [_viewerCanvasHandle $window $component]]}
proc ::GX::viewerGuiDesignCanvasCommand {window component operation {request {}}} {
    _viewerGuiSemanticDispatchCheck $window $component
    set handle [_viewerCanvasHandle $window $component]
    _nativeCanvasRequest $operation $request
    if {$operation eq {bind_source} && [dict exists $request source_selector]} {
        if {[dict exists $request dataset_id]} {error {Choose one declared source selector or canonical Dataset identity}}
        set selector [dict get $request source_selector]
        set definition [viewerGuiDesignComponent $window $selector]
        if {[dict get $definition type] ne {dataset_selector} || [datasetPublicationV2DictDefault [dict get $definition properties] content_kind {}] ne {raster}} {error {Canvas source selector must be a declared canonical raster Dataset selector}}
        dict set request dataset_id $::GX::ViewerGui::values($window,$selector)
        dict unset request source_selector
    }
    set result [native2DCanvasCommand $handle $operation $request]
    if {$operation eq {dispose}} {dict unset ::GX::ViewerGui::instances $window canvas_slots $component}
    _viewerCanvasCapture $window
    viewerGuiTraceEmit $window $component canvas_command [dict create status completed operation $operation]
    return $result
}
proc ::GX::_viewerCanvasEvent {window component event} {
    if {![dict exists $::GX::ViewerGui::instances $window]} return
    if {[dict get $::GX::ViewerGui::instances $window restoring]} return
    if {$event in {committed history_navigated document_changed}} {
        _viewerCanvasHistoryFlush $window
    } else {_viewerCanvasCapture $window}
    viewerGuiTraceEmit $window $component canvas_event [dict create status ready event $event]
}
proc ::GX::_viewerCanvasHistoryProjection {bindings} {
    set result {}
    foreach component [lsort [dict keys $bindings]] {
        # Receipts remain complete in persisted captures. Their operational
        # revision changes during restore without changing the scientific state.
        dict set result $component [dict remove [dict get $bindings $component] document_receipt]
    }
    return $result
}
proc ::GX::_viewerCanvasHistoryFlush {window} {
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots] || ![dict exists $::GX::ScientificHistory::viewers $window]} return
    if {[dict get $::GX::ViewerGui::instances $window restoring] || ![scientificHistoryViewerEditable $window]} return
    set record [dict get $::GX::ScientificHistory::viewers $window record]
    # Returning to an older state must keep its redo branch until the ordinary
    # existing PrepareEdit review explicitly accepts a branch.
    if {[dict get $record cursor]!=[llength [dict get $record steps]]} return
    _viewerCanvasCapture $window
    set current [viewerGuiDesignContextGet $window]
    set accepted [datasetPublicationV2DictDefault [scientificHistoryViewerState $window] domain_state {}]
    set current [datasetPublicationV2DictDefault $current native2d_canvas {}]
    set accepted [datasetPublicationV2DictDefault $accepted native2d_canvas {}]
    if {[_viewerCanvasHistoryProjection $current] ne [_viewerCanvasHistoryProjection $accepted]} {
        scientificHistoryViewerRecordOperation $window {Update Canvas}
    }
}
proc ::GX::_viewerCanvasCapture {window} {
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots]} return
    set states {}
    dict for {component handle} [dict get $::GX::ViewerGui::instances $window canvas_slots] {
        set row [_nativeCanvasRequire $handle]
        set history [dict get $row history]
        if {[dict exists $row gesture_history] && [dict get [[dict get $row native] state scalar] gesture]} {set history [dict get $row gesture_history]}
        dict set states $component [dict create document_id [dict get $row document] document_receipt [dict get $row receipt] snapshot [native2DCanvasCapture $handle] history $history]
    }
    set domain [viewerGuiDesignContextGet $window]
    dict set domain native2d_canvas $states
    viewerGuiDesignContextSet $window $domain
}
proc ::GX::_viewerCanvasRestoreCheck {window domain} {
    dict for {component binding} [datasetPublicationV2DictDefault $domain native2d_canvas {}] {
        _viewerGuiCanvasDefinition $window $component
        _nativeCanvasFields $binding {document_id document_receipt snapshot history} {document_id document_receipt snapshot history}
        set current [interactiveDocumentMetadata [dict get $binding document_id]]
        set instance [dict get $::GX::ViewerGui::instances $window]
        if {[dict get $current module_id] ne [dict get $instance module] || [dict get $current provider_id] ne [dict get $instance provider] || [dict get $current format] ne {gxtxt.native2d.canvas_scene.v1}} {error {Saved Canvas has a foreign author or document format}}
        if {[dict get $current generation] ne [dict get $binding document_receipt generation]} {error {Saved Canvas owner was replaced}}
        if {$current ne [dict get $binding document_receipt]} {
            if {![dict exists $instance canvas_slots $component] || [dict get [_nativeCanvasRequire [dict get $instance canvas_slots $component]] receipt] ne $current} {error {Saved Canvas changed in another instance; reopen its current state}}
        }
        native2DCanvasSnapshotValidate [dict get $binding snapshot]
        scientificHistoryValidate framework.native2d.canvas [dict get $binding history]
    }
}
proc ::GX::_viewerCanvasRestore {window domain} {
    _viewerCanvasRestoreCheck $window $domain
    dict for {component binding} [datasetPublicationV2DictDefault $domain native2d_canvas {}] {
        set handle [_viewerCanvasHandle $window $component]
        set row [_nativeCanvasRequire $handle]
        if {[dict get $row document] ne [dict get $binding document_id]} {_nativeCanvasOpen $handle [dict get $binding document_id];set row [_nativeCanvasRequire $handle]}
        if {[dict get $row snapshot] ne [dict get $binding snapshot]} {native2DCanvasRestore $handle [dict get $binding snapshot]}
        if {[dict get $row snapshot] ne [dict get $binding snapshot] || [dict get $row history] ne [dict get $binding history]} {_nativeCanvasStore $handle [dict get $binding snapshot] [dict get $binding history]}
    }
    _viewerCanvasCapture $window
}
proc ::GX::_viewerCanvasDispose {window} {
    if {![dict exists $::GX::ViewerGui::instances $window canvas_slots]} return
    dict for {component handle} [dict get $::GX::ViewerGui::instances $window canvas_slots] {native2DCanvasDispose $handle}
    dict unset ::GX::ViewerGui::instances $window canvas_slots
}
proc ::GX::_nativeCanvasHistoryEncode {record} {
    scientificHistoryValidate framework.native2d.canvas $record
    return [nativeWorkspaceHistoryEncode $record [list ::GX::nativeWorkspaceEncode {named canvas_snapshot}]]
}
proc ::GX::_viewerCanvasEncode {value} {
    return [nativeWorkspaceEncode {map {record {document_id text document_receipt {named document_receipt} snapshot {named canvas_snapshot} history {codec ::GX::_nativeCanvasHistoryEncode}}}} $value]
}
proc ::GX::_viewerCanvasPublicState {handle} {
    set description [native2DCanvasDescribe $handle]
    set result [dict remove $description api_id canvas_version display_precision rendering scheduling]
    dict set result layer_count [llength [dict get $description layers]]
    dict set result object_count [llength [dict get $description objects]]
    # Diagnostics are a bounded metadata page, never a second object authority.
    dict set result layers [lrange [dict get $description layers] 0 63]
    dict set result objects [lrange [dict get $description objects] 0 127]
    dict set result selection [lrange [dict get $description selection] 0 127]
    dict set result diagnostics_complete [expr {[dict get $result layer_count]<=64 && [dict get $result object_count]<=128 && [llength [dict get $description selection]]<=128}]
    return $result
}
proc ::GX::_viewerCanvasClientSnapshot {window {component {}}} {
    set values {}
    if {$component ne {} && [dict exists $::GX::ViewerGui::instances $window canvas_slots $component]} {
        set handle [dict get $::GX::ViewerGui::instances $window canvas_slots $component]
        if {[catch {set row [_viewerCanvasPublicState $handle]} message]} {
            dict set values $component [list object [dict create status [list text unavailable] diagnostic [list text [string range $message 0 2047]]]]
        } else {
            while {1} {
                dict set values $component [nativeWorkspaceEncode {named canvas_public_state} $row]
                set result [nativeWorkspaceJsonEncode [list object [dict create instances [list object $values]]]]
                if {[string bytelength $result]<=49152} {return $result}
                set largest {};set count 0
                foreach field {layers objects selection} {
                    set length [llength [dict get $row $field]]
                    if {$length>$count} {set count $length;set largest $field}
                }
                if {$count==0} {
                    dict set values $component [list object [dict create status [list text unavailable] diagnostic [list text {Canvas scalar diagnostics exceed the client receipt bound}]]]
                    break
                }
                dict set row $largest [lrange [dict get $row $largest] 0 [expr {$count/2-1}]]
                dict set row diagnostics_complete 0
            }
        }
    }
    set result [nativeWorkspaceJsonEncode [list object [dict create instances [list object $values]]]]
    return $result
}
::GX::nativeWorkspaceShapeRegister canvas_public_state {record {
    document_id text canvas_id text generation text revision int tool text active_layer text selection {array text} extent {array int} background {array real}
    layers {array {record {logical_id text name text properties {record {visible bool selectable bool locked bool order int opacity real}} blend text}}}
    objects {array {record {logical_id text kind text layer text}}}
    history_cursor int history_steps int pending bool layer_count int object_count int diagnostics_complete bool
}}
::GX::viewerWorkspaceCodecRegister domains native2d_canvas ::GX::_viewerCanvasEncode
