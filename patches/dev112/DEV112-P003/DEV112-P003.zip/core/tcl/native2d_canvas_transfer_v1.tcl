# SPDX-License-Identifier: GPL-3.0-or-later
# Finite native object transfer; existing Resource owner retains all bytes.
proc ::GX::_nativeCanvasClipboardCopy {handle request} {
    set row [_nativeCanvasRequire $handle]
    set snapshot [native2DCanvasCapture $handle]
    set selected [datasetPublicationV2DictDefault $request objects [dict get $snapshot selection]]
    if {![llength $selected] || [llength [lsort -unique $selected]]!=[llength $selected]} {error {Copy requires unique selected Canvas objects}}
    set state [[dict get $row native] state]
    foreach logical $selected {_nativeCanvasLogical $state objects $logical}
    set leaves {};set groups {};set wanted $selected
    foreach group [dict get $snapshot groups] {if {[dict get $group logical_id] in $selected} {set wanted [concat $wanted [dict get $group members]];lappend groups $group}}
    foreach object [dict get $snapshot objects] {if {[dict get $object logical_id] in $wanted} {lappend leaves $object}}
    if {![llength $leaves]} {error {Copy contains no admitted native objects}}
    # Source-bound alpha mask dependencies must be transferred together.
    set uuids {};set required {}
    foreach object $leaves {
        set attrs [dict get $object resource metadata sketch_attributes]
        if {[dict exists $attrs gx.raster.uuid]} {lappend uuids [dict get $attrs gx.raster.uuid]}
        if {[dict exists $attrs gx.raster.layer mask_uuid] && [dict get $attrs gx.raster.layer mask_uuid] ne {}} {lappend required [dict get $attrs gx.raster.layer mask_uuid]}
    }
    foreach uuid $required {if {$uuid ni $uuids} {error {Copy the linked raster mask together with its image}}}
    dict set snapshot objects $leaves;dict set snapshot groups $groups
    dict set snapshot selection $selected
    native2DCanvasSnapshotValidate $snapshot
    set ::GX::NativeCanvas::clipboard $snapshot
    return [dict create status copied objects [llength $selected] canvas_id [dict get $snapshot canvas_id]]
}
proc ::GX::_nativeCanvasCloneResource {reference document cacheName} {
    upvar 1 $cacheName cache
    interactiveDocumentResourceInfo $reference
    set key [list [dict get $reference document_id] [dict get $reference owner_generation] [dict get $reference sha256] [dict get $reference size_bytes] [dict get $reference metadata]]
    if {[dict exists $cache $key]} {return [dict get $cache $key]}
    if {[dict get $reference document_id] eq $document} {dict set cache $key $reference;return $reference}
    set typed [nativeWorkspaceEncode {resource {named resource_metadata}} $reference]
    set copy [nativeWorkspaceDecode [managedResourceCopyTree $document $typed]]
    if {[dict get $copy sha256] ne [dict get $reference sha256] || [dict get $copy size_bytes]!=[dict get $reference size_bytes]} {error {Canvas resource transfer changed immutable bytes}}
    dict set cache $key $copy
    return $copy
}
proc ::GX::_nativeCanvasClipboardPaste {handle request} {
    set row [_nativeCanvasRequire $handle]
    if {$::GX::NativeCanvas::clipboard eq {}} {error {Canvas clipboard is empty}}
    set snapshot [native2DCanvasSnapshotValidate $::GX::NativeCanvas::clipboard]
    set context [dict get $row native];set state [$context state];set scene [dict get $state scene]
    set layer [datasetPublicationV2DictDefault $request layer [_nativeCanvasLogicalFromId $state layers [dict get $state active_layer]]]
    set layerId [_nativeCanvasLogical $state layers $layer]
    foreach item [dict get $state layers] {if {[dict get $item id]==$layerId && ([dict get $item properties locked] || ![dict get $item properties selectable] || ![dict get $item properties visible])} {error {Paste target layer is locked, hidden or not selectable}}}
    set copies {};set cache {};set uuidMap {};set pasted {};set images {}
    foreach item [dict get $snapshot objects] {
        set reference [_nativeCanvasCloneResource [dict get $item resource] [dict get $row document] cache]
        set restored [native2DGeometryCall [dict get $row geometry] restore_resource [dict create resource $reference]]
        set token [dict get $restored object_token]
        set id [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects $token native]
        # Restore the managed image owner before raster UUID admission asks
        # the existing geometry wrapper for that image's resource receipt.
        if {[dict exists $reference metadata image_resource]} {
            dict set ::GX::Native2DGeometry::scenes [dict get $row geometry] objects $token metadata image_resource [dict get $reference metadata image_resource]
            if {[dict exists $item source]} {dict set ::GX::Native2DGeometry::scenes [dict get $row geometry] objects $token metadata raster_dataset [dict get $item source]}
        }
        set attrs [::GX::Native2D::core identity_attributes $scene $id]
        if {[dict exists $attrs gx.canvas]} {
            set metadata [dict get $attrs gx.canvas]
            dict unset metadata logical_id
            ::GX::Native2D::core identity_attribute $scene $id gx.canvas $metadata
        }
        if {[dict exists $attrs gx.raster.uuid]} {
            set old [dict get $attrs gx.raster.uuid]
            ::GX::Native2D::core identity_attribute_remove $scene $id gx.raster.uuid
            set new [_native2DRasterUUID [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry]] $token]
            dict set uuidMap $old $new;lappend images $id
        }
        set style [dict get $item style];dict set style layer $layerId
        dict set style locked 0
        ::GX::Native2D::core object_style $scene $id $style
        $context command object_adopt [dict create object $id layer $layerId]
        dict set copies [dict get $item logical_id] $id;lappend pasted $id
    }
    foreach id $images {
        set attrs [::GX::Native2D::core identity_attributes $scene $id]
        if {[dict exists $attrs gx.raster.layer mask_uuid] && [dict get $attrs gx.raster.layer mask_uuid] ne {}} {
            set properties [dict get $attrs gx.raster.layer]
            dict set properties mask_uuid [dict get $uuidMap [dict get $properties mask_uuid]]
            ::GX::Native2D::core identity_attribute $scene $id gx.raster.layer $properties
        }
    }
    foreach group [dict get $snapshot groups] {
        set existing [lmap item [dict get [$context state] groups] {dict get $item id}]
        $context command object_group [dict create objects [lmap logical [dict get $group members] {dict get $copies $logical}] layer $layerId]
        foreach item [dict get [$context state] groups] {
            set id [dict get $item id]
            if {$id in $existing} continue
            set logical [dict get $item logical_id]
            dict for {key value} [dict get $group attributes] {
                if {$key eq {gx.canvas}} {dict set value logical_id $logical}
                ::GX::Native2D::core identity_attribute $scene $id $key $value
            }
            set style [dict get $group style];dict set style layer $layerId
            ::GX::Native2D::core object_style $scene $id $style
            if {[dict get $group name] ne {}} {::GX::Native2D::core identity_name $scene $id [dict get $group name]}
        }
    }
    foreach item [dict get $snapshot objects] {
        if {![dict get $item style locked]} continue
        set style [dict get $item style];dict set style layer $layerId
        ::GX::Native2D::core object_style $scene [dict get $copies [dict get $item logical_id]] $style
    }
    $context command selection_set [dict create objects $pasted mode replace]
    return [dict create status pasted objects [llength $pasted]]
}
proc ::GX::_nativeCanvasMerge {handle request} {
    set row [_nativeCanvasRequire $handle];set context [dict get $row native];set state [$context state]
    set layers [dict get $request layers]
    if {[llength $layers]<2 || [llength [lsort -unique $layers]]!=[llength $layers]} {error {Merge requires two or more distinct compatible layers}}
    set target [datasetPublicationV2DictDefault $request target [lindex $layers 0]]
    if {$target ni $layers} {error {Merge target must be one of the reviewed layers}}
    set ids {};set targetId [_nativeCanvasLogical $state layers $target]
    foreach logical $layers {
        set id [_nativeCanvasLogical $state layers $logical];lappend ids $id
        foreach item [dict get $state layers] {
            if {[dict get $item id]!=$id} continue
            set properties [dict get $item properties]
            if {![dict get $properties visible] || [dict get $properties locked] || ![dict get $properties selectable]} {error {Cannot merge hidden, locked or unselectable layers}}
            if {[dict get $properties opacity]!=1 || [dict get $item blend] ne {Over}} {error {Editable merge requires Over layers at full layer opacity; use explicit flatten for composited layers}}
        }
    }
    set ordered {};foreach descriptor [$context presentation] {
        if {![dict exists $descriptor object]} continue
        set id [dict get $descriptor object]
        foreach object [dict get $state objects] {if {[dict get $object id]==$id && [dict get $object layer] in $ids} {lappend ordered $id;break}}
    }
    set groups {};foreach group [dict get $state groups] {if {[dict get $group layer] in $ids} {lappend groups [dict get $group id]}}
    $context command layer_assign [dict create layer $targetId objects [lsort -unique [concat $ordered $groups]]]
    set order 0
    foreach id $ordered {$context command object_update [dict create object $id style [dict create order [incr order]]]}
    foreach group [dict get $state groups] {
        if {[dict get $group id] ni $groups} continue
        set first [llength $ordered]
        foreach member [dict get $group members] {set ordinal [lsearch -exact $ordered $member];if {$ordinal>=0} {set first [expr {min($first,$ordinal)}]}}
        $context command object_update [dict create object [dict get $group id] style [dict create order [expr {$first+1}]]]
    }
    foreach id $ids {if {$id!=$targetId} {$context command layer_delete [dict create layer $id]}}
    return [dict create status merged layer $target]
}
proc ::GX::_nativeCanvasSwapDocument {handle replacement} {
    set old [_nativeCanvasRequire $handle];set new [_nativeCanvasRequire $replacement]
    foreach key {canvas scheduler frame callback controls controls_signature} {if {[dict exists $old $key]} {dict set new $key [dict get $old $key]}}
    dict set new photos {}
    set canvas [dict get $old canvas]
    if {$canvas ne {} && [winfo exists $canvas]} {
        if {[winfo width $canvas]>1 && [winfo height $canvas]>1} {[dict get $new native] event resize [dict create width [winfo width $canvas] height [winfo height $canvas]]}
        set new [_nativeCanvasStagePresentation $handle $new]
    }
    _nativeCanvasCancelPending $handle
    set canceled [_nativeCanvasRequire $handle 0]
    dict set new sequence [dict get $canceled sequence]
    if {[dict get $old pending] ne {} && [dict exists $canceled raster_status]} {dict set new raster_status [dict get $canceled raster_status]}
    if {[dict get $old subscription] ne {}} {interactiveDocumentLifecycleUnsubscribe [dict get $old subscription]}
    if {$canvas ne {} && [winfo exists $canvas]} {
        native2DSpriteSceneDetach $canvas
        native2DSpriteSceneAttach $canvas [dict get [[dict get $new native] state] scene]
        [dict get $new native] command configure [dict create presenter [native2DSpriteSceneCreate $canvas]]
        native2DViewportHostScene $canvas [dict get [[dict get $new native] state] scene]
        dict set new subscription [interactiveDocumentLifecycleSubscribe [list ::GX::_nativeCanvasLifecycle $handle] $canvas [dict get $new document]]
    }
    dict set ::GX::NativeCanvas::instances $handle $new
    dict unset ::GX::NativeCanvas::instances $replacement
    if {$canvas ne {} && [winfo exists $canvas]} {
        guiUpdateSchedulerRequest [dict get $new scheduler]
        guiUpdateSchedulerFinish [dict get $new scheduler]
    }
    catch {[dict get $old native] dispose}
    catch {native2DGeometryClose [dict get $old geometry]}
    set kept [dict values [dict get $::GX::NativeCanvas::instances $handle photos]]
    dict for {key photo} [dict get $old photos] {if {$photo ni $kept} {catch {image delete $photo}}}
    _nativeCanvasNotify $handle document_changed
    return [native2DCanvasDescribe $handle]
}
proc ::GX::_nativeCanvasNew {handle request} {
    set row [_nativeCanvasRequire $handle]
    set replacement [native2DCanvasCreate [dict get $row module] [dict get $row provider] $request]
    try {return [_nativeCanvasSwapDocument $handle $replacement]} on error {message options} {catch {native2DCanvasDispose $replacement};return -options $options $message}
}
proc ::GX::_nativeCanvasOpen {handle document} {
    set row [_nativeCanvasRequire $handle]
    set replacement [native2DCanvasCreate [dict get $row module] [dict get $row provider] [dict create document_id $document]]
    try {return [_nativeCanvasSwapDocument $handle $replacement]} on error {message options} {catch {native2DCanvasDispose $replacement};return -options $options $message}
}
