# SPDX-License-Identifier: GPL-3.0-or-later
# Canvas bindings to existing Native2D, Document/Resource, History and Workspace.
# Scientific geometry and interaction remain in the native C/C++ owners.
namespace eval ::GX::NativeCanvas {
    variable instances {}
    variable serial 0
    variable clipboard {}
}
proc ::GX::native2DCanvasCommands {} {
    return {new bind_source tool_set selection_set object_create object_update object_delete object_affine object_duplicate object_group object_ungroup copy cut paste layer_create layer_update layer_delete layer_assign layer_select layer_reorder merge flatten filter undo redo fit zoom pan save open cancel dispose inspect publish}
}
proc ::GX::native2DCanvasApiInfo {} {
    return [dict create api_id NATIVE2D_API_v1 api_version 1 host_only 1 canvas_version 1 \
        canvas_format gxtxt.native2d.canvas_scene.v1 commands [native2DCanvasCommands] \
        host_commands {native2DCanvasCreate native2DCanvasMount native2DCanvasCommand native2DCanvasDescribe native2DCanvasCapture native2DCanvasRestore native2DCanvasDispose} \
        authority Native2D.C_CPP persistence INTERACTIVE_DOCUMENT_API_v1 history SCIENTIFIC_RECIPE_API_v1 \
        multiple_instances 1 display_precision rgba8_sRGB raw_pointers 0]
}
proc ::GX::_nativeCanvasFields {value allowed {required {}}} {
    if {[catch {dict size $value}]} {error {Canvas request must be a dictionary}}
    foreach key [dict keys $value] {if {$key ni $allowed} {error "Unknown Canvas field: $key"}}
    foreach key $required {if {![dict exists $value $key]} {error "Missing Canvas field: $key"}}
}
proc ::GX::_nativeCanvasRequire {handle {guard 1}} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} {error {Canvas is unknown or disposed}}
    set row [dict get $::GX::NativeCanvas::instances $handle]
    if {!$guard} {return $row}
    if {[dict get $row session] ne [interactiveDocumentSessionToken]} {error {Canvas belongs to another Session lifetime}}
    set owner [interactiveDocumentMetadata [dict get $row document]]
    set held [dict get $row receipt]
    foreach key {generation revision sha256} {
        if {[dict get $owner $key] ne [dict get $held $key]} {error {Canvas document changed outside this instance; reopen its current state}}
    }
    if {![dict get [[dict get $row native] state scalar] alive]} {error {Canvas native source has closed}}
    return $row
}
proc ::GX::_nativeCanvasNumber {value minimum maximum label} {
    return [uiFieldNormalize [dict create type number min $minimum max $maximum] $value]
}
proc ::GX::_nativeCanvasExtent {width height} {
    foreach value [list $width $height] {
        if {![string is double -strict $value] || [catch {expr {abs($value)<Inf && $value==floor($value) && $value>=1 && $value<=16384}} valid] || !$valid} {error {Canvas dimensions must be integers from1 to16384}}
    }
    if {$width*$height>16777216} {error {Canvas exceeds the existing16777216-pixel composition limit}}
    return [list [expr {wide($width)}] [expr {wide($height)}]]
}
proc ::GX::_nativeCanvasLogical {state kind value} {
    if {$value eq {} || [string is entier -strict $value]} {error {Canvas targets must be stable logical identities}}
    if {[dict exists $state _logical_index $kind]} {
        if {[dict exists $state _logical_index $kind $value]} {return [dict get $state _logical_index $kind $value]}
        error "Foreign or stale Canvas identity: $value"
    }
    foreach item [dict get $state $kind] {
        if {[dict get $item logical_id] eq $value} {return [dict get $item id]}
    }
    error "Foreign or stale Canvas identity: $value"
}
proc ::GX::_nativeCanvasLogicalFromId {state kind id} {
    if {!$id} {return {}}
    if {[dict exists $state _native_index $kind]} {
        if {[dict exists $state _native_index $kind $id]} {return [dict get $state _native_index $kind $id]}
        error {Native Canvas reference is outside its scene}
    }
    foreach item [dict get $state $kind] {if {[dict get $item id]==$id} {return [dict get $item logical_id]}}
    error {Native Canvas reference is outside its scene}
}
proc ::GX::_nativeCanvasIndexedState {state} {
    # Per-call serialization indexes over the authoritative native state.
    # These are never persisted or used as a competing identity registry.
    foreach kind {objects layers} {
        dict set state _logical_index $kind {}
        dict set state _native_index $kind {}
        foreach item [dict get $state $kind] {
            dict set state _logical_index $kind [dict get $item logical_id] [dict get $item id]
            dict set state _native_index $kind [dict get $item id] [dict get $item logical_id]
        }
    }
    return $state
}
proc ::GX::_nativeCanvasHistoryValidate {record} {
    native2DCanvasSnapshotValidate [dict get $record base] 0
    return 1
}
proc ::GX::native2DCanvasSnapshotValidate {snapshot {resources 1}} {
    _nativeCanvasFields $snapshot {schema document_id generation canvas_id extent background layers objects groups view_state selection active_layer tool retained_outputs} \
        {schema document_id generation canvas_id extent background layers objects groups view_state selection active_layer tool retained_outputs}
    if {[dict get $snapshot schema] ne {gxtxt.native2d.canvas_scene.v1} || [string bytelength $snapshot]>8388608} {error {Unsupported or oversized Canvas snapshot}}
    lassign [dict get $snapshot extent] width height
    if {[llength [dict get $snapshot extent]]!=2} {error {Canvas extent requires width and height}}
    _nativeCanvasExtent $width $height
    if {[llength [dict get $snapshot background]]!=4} {error {Canvas background requires normalized RGBA}}
    foreach n [dict get $snapshot background] {_nativeCanvasNumber $n 0 1 background}
    set ids {};set layerIds {};set objectIds {}
    if {[llength [dict get $snapshot layers]]+[llength [dict get $snapshot objects]]+[llength [dict get $snapshot groups]]>4000} {error {Canvas snapshot exceeds native identity capacity}}
    foreach layer [dict get $snapshot layers] {
        _nativeCanvasFields $layer {logical_id name attributes properties blend} {logical_id name attributes properties blend}
        set id [dict get $layer logical_id]
        if {$id eq {} || $id in $ids || [string is entier -strict $id]} {error {Duplicate or invalid Canvas layer identity}}
        lappend ids $id;lappend layerIds $id
        _nativeCanvasFields [dict get $layer properties] {visible selectable locked order opacity} {visible selectable locked order opacity}
        foreach key {visible selectable locked} {uiFieldNormalize {type boolean} [dict get $layer properties $key]}
        _nativeCanvasNumber [dict get $layer properties opacity] 0 1 opacity
        if {[dict get $layer blend] ni {Over Multiply Screen Overlay SoftLight}} {error {Unsupported Canvas layer blend}}
    }
    foreach object [dict get $snapshot objects] {
        _nativeCanvasFields $object {logical_id name resource style layer_logical_id source} {logical_id name resource style layer_logical_id}
        set id [dict get $object logical_id]
        if {$id eq {} || $id in $ids || [string is entier -strict $id]} {error {Duplicate or invalid Canvas object identity}}
        lappend ids $id;lappend objectIds $id
        if {[dict get $object layer_logical_id] ni $layerIds} {error {Canvas object refers to a missing layer}}
        if {[dict exists $object style layer]} {error {Canvas snapshot must not persist native layer numbers}}
        if {$resources} {
            set ref [dict get $object resource]
            if {[dict get $ref document_id] ne [dict get $snapshot document_id] || [dict get $ref owner_generation] ne [dict get $snapshot generation]} {error {Canvas leaf resource has a foreign owner}}
            interactiveDocumentResourceInfo $ref
            if {[dict exists $object source]} {_viewerGuiRasterSourceCheck [dict get $object source]}
        }
    }
    foreach group [dict get $snapshot groups] {
        _nativeCanvasFields $group {logical_id name members attributes style layer_logical_id} {logical_id name members attributes style layer_logical_id}
        set id [dict get $group logical_id]
        if {$id eq {} || $id in $ids || [string is entier -strict $id]} {error {Duplicate or invalid Canvas group identity}}
        lappend ids $id
        set members [dict get $group members]
        if {![llength $members] || [llength [lsort -unique $members]]!=[llength $members]} {error {Native Canvas groups require unique nongroup members}}
        foreach member $members {if {$member ni $objectIds} {error {Missing or nested Canvas group member}}}
        if {[dict get $group layer_logical_id] ni $layerIds} {error {Canvas group refers to a missing layer}}
    }
    foreach id [dict get $snapshot selection] {if {$id ni $ids || $id in $layerIds} {error {Canvas selection refers to a missing object}}}
    if {[dict get $snapshot active_layer] ne {} && [dict get $snapshot active_layer] ni $layerIds} {error {Canvas active layer is missing}}
    nativeWorkspaceEncode {named canvas_snapshot} $snapshot
    return $snapshot
}
proc ::GX::_nativeCanvasAdmitSources {row} {
    set token [dict get $row geometry]
    set scene [dict get $::GX::Native2DGeometry::scenes $token]
    dict for {object entry} [dict get $scene objects] {
        if {[dict exists $entry metadata image_resource]} {_native2DRasterImage $scene $object}
    }
}
proc ::GX::_nativeCanvasReconcile {handle} {
    set row [_nativeCanvasRequire $handle]
    set context [dict get $row native];set token [dict get $row geometry]
    set state [$context state];set native [dict get $state scene]
    set live {};foreach id [::GX::Native2D::core ids $native] {dict set live $id 1}
    set registered {};set images {}
    set scene [dict get $::GX::Native2DGeometry::scenes $token]
    dict for {object entry} [dict get $scene objects] {
        if {![dict exists $live [dict get $entry native]]} {
            if {[dict exists $scene raster_resource_readers $object]} {catch {interactiveDocumentResourceCloseReader [dict get $scene raster_resource_readers $object]};dict unset ::GX::Native2DGeometry::scenes $token raster_resource_readers $object}
            dict unset ::GX::Native2DGeometry::scenes $token objects $object
        } else {
            dict set registered [dict get $entry native] 1
            if {[dict exists $entry metadata image_resource] && ![dict exists $images [dict get $entry metadata image_resource sha256]]} {dict set images [dict get $entry metadata image_resource sha256] [dict get $entry metadata]}
        }
    }
    foreach item [dict get $state objects] {
        set id [dict get $item id]
        if {[dict get $item logical_id] eq {}} {$context command object_adopt [dict create object $id]}
        if {[dict exists $registered $id]} continue
        set metadata {}
        set image [::GX::Native2D::core image_get $native $id]
        if {$image ne {}} {
            set reference {}
            if {[dict exists $images [dict get $image resource_id]]} {set metadata [dict get $images [dict get $image resource_id]];set reference [dict get $metadata image_resource]}
            if {$reference eq {} && [dict exists $::GX::Native2DRaster::resources $native $id]} {set reference [dict get $::GX::Native2DRaster::resources $native $id];dict set metadata image_resource $reference}
            if {$reference eq {}} {error {Native Canvas image lacks its managed resource}}
            native2DReferenceImageBind $native $id $reference
        }
        _native2DGeometryAdopt $token $id $metadata
        dict set registered $id 1
    }
    return [$context state]
}
proc ::GX::native2DCanvasCreate {module provider {options {}}} {
    _nativeCanvasFields $options {width height background document_id} {}
    set extent [_nativeCanvasExtent [datasetPublicationV2DictDefault $options width 1024] [datasetPublicationV2DictDefault $options height 768]]
    set background [datasetPublicationV2DictDefault $options background {1 1 1 1}]
    if {[llength $background]!=4} {error {Canvas background requires RGBA}}
    foreach value $background {_nativeCanvasNumber $value 0 1 background}
    set created [expr {![dict exists $options document_id]}]
    if {$created} {
        set owner [interactiveDocumentCreate $module $provider gxtxt.native2d.canvas_scene.v1 1 {}]
    } else {
        set owner [interactiveDocumentRead [dict get $options document_id]]
        if {[dict get $owner format] ne {gxtxt.native2d.canvas_scene.v1} || [dict get $owner module_id] ne $module || [dict get $owner provider_id] ne $provider} {error {Canvas document format or author context differs}}
    }
    set geometry {};set context {};set handle {}
    try {
        set geometry [native2DGeometryOpen [dict get $owner id]]
        set scene [dict get $::GX::Native2DGeometry::scenes $geometry native]
        set context [::GX::Native2D::core canvas_create $scene]
        set handle "native2d-canvas#[pid]-[incr ::GX::NativeCanvas::serial]"
        dict set ::GX::NativeCanvas::instances $handle [dict create native $context geometry $geometry document [dict get $owner id] receipt [dict remove $owner payload] session [interactiveDocumentSessionToken] module $module provider $provider canvas {} scheduler {} subscription {} photos {} resources {} history {} snapshot {} pending {} sequence 0 accepting 0]
        if {$created} {
            $context command configure [dict create extent $extent background $background]
            $context command layer_create {name Background properties {visible 1 selectable 1 locked 0 order 0 opacity 1} blend Over}
            lassign $extent width height
            ::GX::Native2D::core fit_bounds $scene [list 0 0 $width $height]
            set snapshot [native2DCanvasCapture $handle]
            set history [scientificHistoryCreate framework.native2d.canvas $snapshot]
            _nativeCanvasStore $handle $snapshot $history
        } else {
            set payload [dict get $owner payload]
            _nativeCanvasFields $payload {schema snapshot history} {schema snapshot history}
            if {[dict get $payload schema] ne {gxtxt.native2d.canvas_document.v1}} {error {Unsupported Canvas document payload}}
            native2DCanvasRestore $handle [dict get $payload snapshot]
            scientificHistoryValidate framework.native2d.canvas [dict get $payload history]
            dict set ::GX::NativeCanvas::instances $handle history [dict get $payload history]
            dict set ::GX::NativeCanvas::instances $handle snapshot [dict get $payload snapshot]
        }
        return $handle
    } on error {message errorOptions} {
        if {$handle ne {}} {catch {native2DCanvasDispose $handle}} else {
            if {$context ne {}} {catch {$context dispose}}
            if {$geometry ne {}} {catch {native2DGeometryClose $geometry}}
        }
        if {$created} {catch {interactiveDocumentDelete [dict get $owner id]}}
        return -options $errorOptions $message
    }
}
proc ::GX::native2DCanvasCapture {handle} {
    set held [_nativeCanvasRequire $handle 0]
    if {[dict exists $held gesture_before]} {
        _nativeCanvasRequire $handle
        if {[dict get [[dict get $held native] state scalar] gesture]} {return [dict get $held gesture_before]}
    }
    set state [_nativeCanvasIndexedState [_nativeCanvasReconcile $handle]];set row [_nativeCanvasRequire $handle]
    set scene [dict get $state scene];set document [dict get $row document]
    set layers {};set objects {};set groups {};set cache [dict get $row resources];set captureOrigin {}
    set sources {}
    dict for {token entry} [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects] {
        if {[dict exists $entry metadata raster_dataset]} {dict set sources [dict get $entry native] [dict get $entry metadata raster_dataset]}
    }
    foreach layer [dict get $state layers] {
        lappend layers [dict create logical_id [dict get $layer logical_id] name [dict get $layer name] attributes [dict get $layer attributes] properties [dict remove [dict get $layer properties] id] blend [dict get $layer blend]]
    }
    foreach object [dict get $state objects] {
        set id [dict get $object id];set logical [dict get $object logical_id]
        set style [dict remove [dict get $object style] layer selected]
        set layer [_nativeCanvasLogicalFromId $state layers [dict get $object layer]]
        set name [::GX::Native2D::core identity_name $scene $id]
        if {[dict get $object kind] eq {group}} {
            set members [lmap native [dict get $object members] {_nativeCanvasLogicalFromId $state objects $native}]
            lappend groups [dict create logical_id $logical name $name members $members attributes [dict get $object attributes] style $style layer_logical_id $layer]
            continue
        }
        set definition [::GX::Native2D::core sketch_definition $scene $id]
        set image [::GX::Native2D::core image_get $scene $id]
        set signature [list $definition $image [dict get $object attributes] [::GX::Native2D::core direction_marker $scene $id]]
        if {($definition ne {} || $image ne {}) && [dict exists $cache $logical] && [dict get $cache $logical signature] eq $signature} {
            set resource [dict get $cache $logical reference]
        } else {
            if {$captureOrigin eq {}} {set captureOrigin [_scientificResourceOrigin $document managed_resource]}
            set resource [interactiveDocumentNative2DStore $document $scene $id [dict create origin $captureOrigin]]
            dict set cache $logical [dict create signature $signature reference $resource]
        }
        set item [dict create logical_id $logical name $name resource $resource style $style layer_logical_id $layer]
        if {[dict exists $sources $id]} {dict set item source [dict get $sources $id]}
        lappend objects $item
    }
    set selected [lmap id [dict get $state selected_objects] {_nativeCanvasLogicalFromId $state objects $id}]
    set snapshot [dict create schema gxtxt.native2d.canvas_scene.v1 document_id $document generation [dict get $row receipt generation] \
        canvas_id [dict get $state canvas_id] extent [_nativeCanvasExtent {*}[dict get $state extent]] background [dict get $state background] \
        layers $layers objects $objects groups $groups view_state [::GX::Native2D::core view_state $scene] selection $selected \
        active_layer [_nativeCanvasLogicalFromId $state layers [dict get $state active_layer]] tool [dict get $state tool] retained_outputs [datasetPublicationV2DictDefault $row retained_outputs {}]]
    native2DCanvasSnapshotValidate $snapshot 0
    dict set ::GX::NativeCanvas::instances $handle resources $cache
    return $snapshot
}
proc ::GX::_nativeCanvasStore {handle snapshot history} {
    set row [_nativeCanvasRequire $handle]
    set payload [dict create schema gxtxt.native2d.canvas_document.v1 snapshot $snapshot history $history]
    set receipt [native2DGeometryCheckpoint [dict get $row geometry] $payload]
    dict set ::GX::NativeCanvas::instances $handle receipt $receipt
    dict set ::GX::NativeCanvas::instances $handle snapshot $snapshot
    dict set ::GX::NativeCanvas::instances $handle history $history
    return $receipt
}
proc ::GX::_nativeCanvasAccepted {handle description} {
    set row [_nativeCanvasRequire $handle]
    set snapshot [native2DCanvasCapture $handle];set history [dict get $row history]
    if {[dict get $history cursor]!=[llength [dict get $history steps]]} {error {Confirm an explicit Canvas History branch before editing}}
    set history [scientificHistoryAppend framework.native2d.canvas $history $snapshot $description]
    _nativeCanvasStore $handle $snapshot $history
    _nativeCanvasNotify $handle committed
    return [native2DCanvasDescribe $handle]
}
proc ::GX::native2DCanvasRestore {handle snapshot} {
    set row [_nativeCanvasRequire $handle]
    if {[dict get $snapshot document_id] ne [dict get $row document] || [dict get $snapshot generation] ne [dict get $row receipt generation]} {error {Canvas snapshot belongs to another Document generation}}
    native2DCanvasSnapshotValidate $snapshot
    set geometry {};set context {};set swapped 0
    try {
        set geometry [native2DGeometryOpen [dict get $row document]]
        set scene [dict get $::GX::Native2DGeometry::scenes $geometry native]
        set context [::GX::Native2D::core canvas_create $scene]
        $context command configure [dict create extent [dict get $snapshot extent] background [dict get $snapshot background] canvas_id [dict get $snapshot canvas_id]]
        set layerIds {};set objectIds {};set cache {}
        foreach layer [dict get $snapshot layers] {
            set properties [dict replace [dict get $layer properties] locked 0]
            set result [$context command layer_create [dict create name [dict get $layer name] properties $properties blend [dict get $layer blend] logical_id [dict get $layer logical_id]]]
            set state [$context state]
            set id [_nativeCanvasLogical $state layers [dict get $layer logical_id]]
            dict set layerIds [dict get $layer logical_id] $id
            dict for {key value} [dict get $layer attributes] {::GX::Native2D::core identity_attribute $scene $id $key $value}
        }
        foreach object [dict get $snapshot objects] {
            set logical [dict get $object logical_id]
            set reference [dict get $object resource]
            set restored [native2DGeometryCall $geometry restore_resource [dict create resource $reference]]
            set token [dict get $restored object_token]
            set id [dict get $::GX::Native2DGeometry::scenes $geometry objects $token native]
            set style [dict get $object style];dict set style layer [dict get $layerIds [dict get $object layer_logical_id]]
            dict set style locked 0
            ::GX::Native2D::core object_style $scene $id $style
            if {[dict get $object name] ne {}} {::GX::Native2D::core identity_name $scene $id [dict get $object name]}
            $context command object_adopt [dict create object $id logical_id $logical layer [dict get $style layer]]
            if {[dict exists $reference metadata image_resource]} {
                dict set ::GX::Native2DGeometry::scenes $geometry objects $token metadata image_resource [dict get $reference metadata image_resource]
                if {[dict exists $object source]} {dict set ::GX::Native2DGeometry::scenes $geometry objects $token metadata raster_dataset [dict get $object source]}
            }
            dict set objectIds $logical $id
            # Restore the accepted immutable receipt into the existing cache.
            # Re-exporting identical bytes would mint a new provenance origin
            # at a different Document revision and falsely change saved science.
            set signature [list [::GX::Native2D::core sketch_definition $scene $id] [::GX::Native2D::core image_get $scene $id] [::GX::Native2D::core identity_attributes $scene $id] [::GX::Native2D::core direction_marker $scene $id]]
            dict set cache $logical [dict create signature $signature reference $reference]
        }
        foreach group [dict get $snapshot groups] {
            set members [lmap logical [dict get $group members] {dict get $objectIds $logical}]
            $context command object_group [dict create objects $members layer [dict get $layerIds [dict get $group layer_logical_id]]]
            set newest 0
            foreach candidate [dict get [$context state] groups] {if {[dict get $candidate id]>$newest} {set newest [dict get $candidate id]}}
            if {!$newest} {error {Native Canvas group restoration produced no group}}
            dict for {key value} [dict get $group attributes] {::GX::Native2D::core identity_attribute $scene $newest $key $value}
            if {[dict get $group name] ne {}} {::GX::Native2D::core identity_name $scene $newest [dict get $group name]}
            ::GX::Native2D::core object_style $scene $newest [dict get $group style]
            dict set objectIds [dict get $group logical_id] $newest
        }
        # Rebuild membership before restoring locks. These objects are still
        # private; public edit guards remain in force for accepted scenes.
        foreach object [dict get $snapshot objects] {
            if {![dict get $object style locked]} continue
            set style [dict get $object style];dict set style layer [dict get $layerIds [dict get $object layer_logical_id]]
            ::GX::Native2D::core object_style $scene [dict get $objectIds [dict get $object logical_id]] $style
        }
        foreach layer [dict get $snapshot layers] {
            if {![dict get $layer properties locked]} continue
            $context command layer_update [dict create layer [dict get $layerIds [dict get $layer logical_id]] properties [dict get $layer properties]]
        }
        ::GX::Native2D::core view_state $scene [dict get $snapshot view_state]
        if {[dict get $snapshot active_layer] ne {}} {$context command layer_select [dict create layer [dict get $layerIds [dict get $snapshot active_layer]] ]}
        $context command selection_set [dict create objects [lmap id [dict get $snapshot selection] {dict get $objectIds $id}] mode replace]
        $context command tool_set [dict create tool [dict get $snapshot tool]]
        set canvas [dict get $row canvas]
        if {$canvas ne {} && [winfo exists $canvas] && [winfo width $canvas]>1 && [winfo height $canvas]>1} {
            $context event resize [dict create width [winfo width $canvas] height [winfo height $canvas]]
        }
        set provisional [dict replace $row native $context geometry $geometry resources $cache photos [dict get $row photos] snapshot $snapshot retained_outputs [dict get $snapshot retained_outputs]]
        set provisional [dict remove $provisional gesture_before gesture_history]
        _nativeCanvasAdmitSources $provisional
        # Assets and native presentation are admitted on a private staging
        # surface before replacing a mounted valid scene.
        if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
            set provisional [_nativeCanvasStagePresentation $handle $provisional]
        }
        _nativeCanvasCancelPending $handle
        set canceled [_nativeCanvasRequire $handle 0]
        foreach key {sequence pending raster_status} {if {[dict exists $canceled $key]} {dict set provisional $key [dict get $canceled $key]}}
        dict set ::GX::NativeCanvas::instances $handle $provisional
        set swapped 1
        if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
            native2DSpriteSceneDetach [dict get $row canvas]
            native2DSpriteSceneAttach [dict get $row canvas] $scene
            $context command configure [dict create presenter [native2DSpriteSceneCreate [dict get $row canvas]]]
            native2DViewportHostScene [dict get $row canvas] $scene
            guiUpdateSchedulerRequest [dict get $row scheduler]
            guiUpdateSchedulerFinish [dict get $row scheduler]
        }
        catch {[dict get $row native] dispose}
        catch {native2DGeometryClose [dict get $row geometry]}
        set kept [dict values [dict get $::GX::NativeCanvas::instances $handle photos]]
        dict for {key photo} [dict get $row photos] {if {$photo ni $kept} {catch {image delete $photo}}}
        _nativeCanvasNotify $handle restored
        return [dict create status restored document_id [dict get $row document] canvas_id [dict get $snapshot canvas_id]]
    } on error {message errorOptions} {
        if {!$swapped} {
            if {$context ne {}} {catch {$context dispose}}
            if {$geometry ne {}} {catch {native2DGeometryClose $geometry}}
        }
        return -options $errorOptions $message
    }
}
proc ::GX::_nativeCanvasWorkspacePrepareEdit {handle} {
    set row [_nativeCanvasRequire $handle];set canvas [dict get $row canvas]
    if {$canvas ne {} && [winfo exists $canvas]} {
        set window [winfo toplevel $canvas]
        if {[dict exists $::GX::ScientificHistory::viewers $window]} {
            set accepted [scientificHistoryViewerPrepareEdit $window]
            set current [_nativeCanvasRequire $handle]
            foreach key {native document receipt session sequence} {
                if {[dict get $row $key] ne [dict get $current $key]} {error {Canvas changed during Workspace History review; retry the operation}}
            }
            return $accepted
        }
    }
    return 1
}
proc ::GX::_nativeCanvasPrepareEdit {handle} {
    if {![_nativeCanvasWorkspacePrepareEdit $handle]} {return 0}
    set row [_nativeCanvasRequire $handle];set history [dict get $row history]
    if {[dict get $history cursor]==[llength [dict get $history steps]]} {return 1}
    set canvas [dict get $row canvas]
    if {$canvas eq {} || ![winfo exists $canvas]} {error {Explicit History branching requires the owning Canvas review}}
    set accepted [tk_messageBox -parent [winfo toplevel $canvas] -type yesno -icon question -title {Canvas History} -message {Edit this earlier Canvas state and discard its redo branch?}]
    if {$accepted ne {yes}} {return 0}
    set current [_nativeCanvasRequire $handle]
    foreach key {native document receipt session sequence} {
        if {[dict get $row $key] ne [dict get $current $key]} {error {Canvas changed during History review; retry the operation}}
    }
    dict set ::GX::NativeCanvas::instances $handle history [scientificHistoryBranch framework.native2d.canvas $history [dict get $history cursor]]
    return 1
}
proc ::GX::_nativeCanvasCancelPending {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    dict set ::GX::NativeCanvas::instances $handle sequence [expr {[dict get $row sequence]+1}]
    if {[dict get $row pending] ne {}} {
        foreach {kind id} [dict get $row pending] {
            switch $kind {
                preparation {catch {scientificExecutionDiscard $id}}
                job {if {[catch {scientificExecutionCancel $id}]} {catch {scriptJobCancel $id}}}
                waiter {catch {scriptJobRequestCancel $id canceled}}
            }
        }
        if {[dict exists $row raster_status]} {dict set ::GX::NativeCanvas::instances $handle raster_status [dict replace [dict get $row raster_status] status canceled]}
    }
    dict set ::GX::NativeCanvas::instances $handle pending {}
}
proc ::GX::native2DCanvasDispose {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} {return 0}
    set row [_nativeCanvasRequire $handle 0]
    _nativeCanvasCancelPending $handle
    # Release registry ownership before Destroy callbacks can reenter cleanup.
    dict unset ::GX::NativeCanvas::instances $handle
    if {[dict get $row scheduler] ne {}} {catch {guiUpdateSchedulerDispose [dict get $row scheduler]}}
    if {[dict get $row subscription] ne {}} {catch {interactiveDocumentLifecycleUnsubscribe [dict get $row subscription]}}
    catch {[dict get $row native] command cancel {}}
    set canvas [dict get $row canvas]
    if {$canvas ne {} && [winfo exists $canvas]} {
        catch {native2DSpriteSceneDispose $canvas}
        catch {native2DViewportDispose $canvas $canvas}
        if {[dict exists $row frame] && [winfo exists [dict get $row frame]]} {destroy [dict get $row frame]}
    }
    catch {[dict get $row native] dispose}
    catch {native2DGeometryClose [dict get $row geometry]}
    dict for {key photo} [dict get $row photos] {catch {image delete $photo}}
    foreach key [array names ::GX::NativeCanvas::ui "$handle,*"] {unset ::GX::NativeCanvas::ui($key)}
    return 1
}
proc ::GX::_nativeCanvasRequest {operation request} {
    set contracts [dict create \
        new {width height background} bind_source {source_selector dataset_id layer} tool_set {tool} selection_set {objects mode} \
        object_create {definition style layer kind text fill} object_update {object definition style text fill} object_delete {objects} \
        object_affine {objects matrix} object_duplicate {objects layer matrix} object_group {objects layer} object_ungroup {object} \
        copy {objects} cut {objects} paste {layer} layer_create {name properties blend} layer_update {layer properties name blend} \
        layer_delete {layer delete_objects} layer_assign {layer objects} layer_select {layer} layer_reorder {layer order} \
        merge {layers target} flatten {layers precision} filter {object name parameters} undo {} redo {} fit {} zoom {factor center} \
        pan {dx dy} save {} open {document_id} cancel {} dispose {} inspect {} publish {dataset_id name format precision}]
    if {![dict exists $contracts $operation]} {error {Unknown finite Canvas operation}}
    _nativeCanvasFields $request [concat [dict get $contracts $operation] expected_revision]
    if {[string bytelength $request]>49152} {error {Canvas request exceeds48KiB}}
    set required [dict create new {width height} tool_set tool selection_set objects object_create definition object_update object \
        object_affine {objects matrix} object_duplicate objects object_group objects object_ungroup object layer_update layer \
        layer_delete layer layer_assign {layer objects} layer_select layer layer_reorder {layer order} merge layers filter name \
        zoom factor pan {dx dy} open document_id publish dataset_id]
    foreach key [datasetPublicationV2DictDefault $required $operation {}] {if {![dict exists $request $key]} {error "Missing Canvas field: $key"}}
    if {$operation eq {bind_source} && ([dict exists $request dataset_id]+[dict exists $request source_selector])!=1} {error {Choose exactly one canonical source identity or declared selector}}
}
proc ::GX::native2DCanvasCommand {handle operation {request {}}} {
    _nativeCanvasRequest $operation $request
    set row [_nativeCanvasRequire $handle]
    if {[dict exists $request expected_revision]} {
        if {![string is entier -strict [dict get $request expected_revision]] || [dict get $request expected_revision]!=[dict get $row receipt revision]} {error {Stale Canvas revision}}
        dict unset request expected_revision
    }
    if {$operation eq {dispose}} {return [native2DCanvasDispose $handle]}
    if {$operation in {cancel save tool_set fit zoom pan undo redo open new}} {
        _nativeCanvasCancelGesture $handle
        set row [_nativeCanvasRequire $handle]
    } elseif {$operation ne {inspect} && [dict get [[dict get $row native] state scalar] gesture]} {
        error {Finish or cancel the provisional Canvas gesture before editing}
    }
    if {$operation ni {new open cancel inspect tool_set selection_set layer_select fit zoom pan}} {_nativeCanvasAdmitSources $row}
    if {$operation in {tool_set selection_set layer_select fit zoom pan undo redo open new}} {
        if {![_nativeCanvasWorkspacePrepareEdit $handle]} {return {status canceled}}
        set row [_nativeCanvasRequire $handle]
    }
    set context [dict get $row native]
    if {$operation in {inspect cancel save tool_set fit zoom pan undo redo open new copy filter flatten publish}} {
        set state [$context state scalar]
    } else {set state [_nativeCanvasIndexedState [$context state]]}
    set scene [dict get $state scene]
    switch -- $operation {
        inspect {return [native2DCanvasDescribe $handle]}
        cancel {_nativeCanvasCancelPending $handle;$context command cancel {};_nativeCanvasNotify $handle canceled;return {status canceled}}
        save {
            $context command cancel {}
            return [_nativeCanvasStore $handle [native2DCanvasCapture $handle] [dict get $row history]]
        }
        tool_set {$context command tool_set $request;_nativeCanvasNotify $handle tool_changed;return [native2DCanvasDescribe $handle]}
        layer_select {
            dict set request layer [_nativeCanvasLogical $state layers [dict get $request layer]]
            $context command layer_select $request;_nativeCanvasNotify $handle layer_selected;return [native2DCanvasDescribe $handle]
        }
        selection_set {
            dict set request objects [lmap id [dict get $request objects] {_nativeCanvasLogical $state objects $id}]
            $context command selection_set $request;_nativeCanvasNotify $handle selected;return [native2DCanvasDescribe $handle]
        }
        fit - zoom - pan {
            $context command cancel {}
            switch $operation {
                fit {lassign [dict get $state extent] width height;::GX::Native2D::core fit_bounds $scene [list 0 0 $width $height]}
                zoom {
                    set factor [_nativeCanvasNumber [dict get $request factor] 0.01 100 factor]
                    set point [datasetPublicationV2DictDefault $request center {0 0}]
                    ::GX::Native2D::core zoom $scene $factor $point
                }
                pan {::GX::Native2D::core pan $scene [_nativeCanvasNumber [dict get $request dx] -1e9 1e9 dx] [_nativeCanvasNumber [dict get $request dy] -1e9 1e9 dy]}
            }
            _nativeCanvasNotify $handle view_changed;return [native2DCanvasDescribe $handle]
        }
        undo - redo {
            $context command cancel {};_nativeCanvasCancelPending $handle
            set history [dict get $row history]
            set index [expr {[dict get $history cursor]+($operation eq {undo}?-1:1)}]
            set history [scientificHistoryNavigate framework.native2d.canvas $history $index]
            set snapshot [scientificHistoryState $history]
            native2DCanvasRestore $handle $snapshot
            _nativeCanvasStore $handle $snapshot $history
            _nativeCanvasNotify $handle history_navigated
            return [native2DCanvasDescribe $handle]
        }
        copy {return [_nativeCanvasClipboardCopy $handle $request]}
        open {return [_nativeCanvasOpen $handle [dict get $request document_id]]}
        new {return [_nativeCanvasNew $handle $request]}
        filter - flatten - publish {return [_nativeCanvasRasterCommand $handle $operation $request]}
    }
    if {[dict get $row pending] ne {}} {error {Cancel the pending Canvas operation before editing}}
    if {![_nativeCanvasPrepareEdit $handle]} {return {status canceled}}
    set before [native2DCanvasCapture $handle]
    set committed 0
    try {
        switch -- $operation {
            bind_source {
                if {[dict exists $request source_selector] || ![dict exists $request dataset_id]} {error {Resolve a declared Dataset selector through the Viewer Canvas host}}
                _nativeCanvasAdmitSources $row
                set result [native2DGeometryRasterDatasetBind [dict get $row geometry] [dict get $request dataset_id]]
                set object [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects [dict get $result object_token] native]
                set adopt [dict create object $object kind image layer [dict get $state active_layer]]
                if {[dict exists $request layer]} {dict set adopt layer [_nativeCanvasLogical $state layers [dict get $request layer]]}
                $context command object_adopt $adopt
            }
            cut {_nativeCanvasClipboardCopy $handle $request;set ids [datasetPublicationV2DictDefault $request objects [dict get [native2DCanvasDescribe $handle] selection]];$context command object_delete [dict create objects [lmap id $ids {_nativeCanvasLogical $state objects $id}]]}
            paste {_nativeCanvasClipboardPaste $handle $request}
            layer_reorder {$context command layer_update [dict create layer [_nativeCanvasLogical $state layers [dict get $request layer]] properties [dict create order [dict get $request order]]]}
            merge {_nativeCanvasMerge $handle $request}
            default {
                if {$operation eq {object_delete} && ![dict exists $request objects]} {dict set request objects [dict get [native2DCanvasDescribe $handle] selection]}
                foreach key {object layer} kind {objects layers} {if {[dict exists $request $key]} {dict set request $key [_nativeCanvasLogical $state $kind [dict get $request $key]]}}
                if {[dict exists $request objects]} {dict set request objects [lmap id [dict get $request objects] {_nativeCanvasLogical $state objects $id}]}
                set receipt [$context command $operation $request]
                if {$operation eq {object_duplicate}} {
                    # Native affine already returns the exact source/copy map.
                    # Equal image bytes do not imply the same Dataset lineage.
                    set metadataById {}
                    dict for {token entry} [dict get $::GX::Native2DGeometry::scenes [dict get $row geometry] objects] {dict set metadataById [dict get $entry native] [dict get $entry metadata]}
                    if {[llength [dict get $receipt source_ids]]!=[llength [dict get $receipt object_ids]]} {error {Native duplicate returned an incomplete source map}}
                    foreach original [dict get $receipt source_ids] copy [dict get $receipt object_ids] {
                        set metadata [dict get $metadataById $original]
                        if {[dict exists $metadata image_resource]} {native2DReferenceImageBind $scene $copy [dict get $metadata image_resource]}
                        _native2DGeometryAdopt [dict get $row geometry] $copy $metadata
                    }
                }
            }
        }
        set result [_nativeCanvasAccepted $handle [string map {_ { }} $operation]]
        set committed 1
        return $result
    } on error {message errorOptions} {
        if {!$committed && ![catch {_nativeCanvasRequire $handle}]} {
            if {[$context state] ne [dict remove $state _native_index _logical_index] && [catch {native2DCanvasRestore $handle $before} recovery]} {dict set ::GX::NativeCanvas::instances $handle recovery_failure $recovery;append message "; Canvas recovery failed: $recovery"}
            dict set ::GX::NativeCanvas::instances $handle history [dict get $row history]
        }
        return -options $errorOptions $message
    }
}
proc ::GX::native2DCanvasDescribe {handle} {
    set row [_nativeCanvasRequire $handle];set state [_nativeCanvasIndexedState [[dict get $row native] state]]
    set layers {};foreach item [dict get $state layers] {lappend layers [dict remove $item id attributes canvas_metadata]}
    set objects {};foreach item [dict get $state objects] {
        lappend objects [dict create logical_id [dict get $item logical_id] kind [dict get $item kind] layer [_nativeCanvasLogicalFromId $state layers [dict get $item layer]]]
    }
    set selected [lmap id [dict get $state selected_objects] {_nativeCanvasLogicalFromId $state objects $id}]
    set result [dict create api_id NATIVE2D_API_v1 canvas_version 1 document_id [dict get $row document] canvas_id [dict get $state canvas_id] \
        generation [dict get $row receipt generation] revision [dict get $row receipt revision] tool [dict get $state tool] \
        active_layer [_nativeCanvasLogicalFromId $state layers [dict get $state active_layer]] selection $selected extent [_nativeCanvasExtent {*}[dict get $state extent]] background [dict get $state background] \
        layers $layers objects $objects history_cursor [dict get $row history cursor] history_steps [llength [dict get $row history steps]] pending [expr {[dict get $row pending] ne {}}] display_precision rgba8_sRGB]
    if {[dict get $row canvas] ne {} && [winfo exists [dict get $row canvas]]} {
        dict set result rendering [dict remove [native2DSpriteSceneDescribe [dict get $row canvas]] item]
        dict set result scheduling [dict remove [guiUpdateSchedulerDescribe [dict get $row scheduler]] owner config]
    }
    return $result
}
proc ::GX::_nativeCanvasNotify {handle event} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    if {[dict get $row scheduler] ne {}} {catch {guiUpdateSchedulerRequest [dict get $row scheduler]}}
    if {[dict exists $row callback] && [dict get $row callback] ne {}} {
        if {[catch {uplevel #0 [list {*}[dict get $row callback] $event]} message] && [dict exists $::GX::NativeCanvas::instances $handle]} {dict set ::GX::NativeCanvas::instances $handle notification_error $message}
    }
}

# Exact native Workspace types. Scientific arrays remain managed resources.
::GX::nativeWorkspaceShapeRegister canvas_layer {record {logical_id text name text attributes {map text} properties {record {visible bool selectable bool locked bool order int opacity real}} blend text}}
::GX::nativeWorkspaceShapeRegister canvas_leaf {record {logical_id text name text resource {resource {named resource_metadata}} style {named native_style} layer_logical_id text source {named raster_source}}}
::GX::nativeWorkspaceShapeRegister canvas_group {record {logical_id text name text members {array text} attributes {map text} style {named native_style} layer_logical_id text}}
::GX::nativeWorkspaceShapeRegister canvas_snapshot {record {
    schema text document_id text generation text canvas_id text extent {array int} background {array real}
    layers {array {named canvas_layer}} objects {array {named canvas_leaf}} groups {array {named canvas_group}}
    view_state {named view2d} selection {array text} active_layer text tool text retained_outputs {array {resource {named resource_metadata}}}
}}
::GX::scientificRecipeHostRegister framework.native2d.canvas [dict create capture ::GX::native2DCanvasApiInfo validate ::GX::_nativeCanvasHistoryValidate replay ::GX::scientificHistoryState]
