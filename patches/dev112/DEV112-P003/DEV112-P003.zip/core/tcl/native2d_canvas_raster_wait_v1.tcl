# SPDX-License-Identifier: GPL-3.0-or-later
# Existing Script Job waiter, isolated from the GUI event loop. No new queue.
lassign $argv nativeCanvasWaitFramework nativeCanvasWaitRoot nativeCanvasWaitJob
set argv0 __native_canvas_managed_wait__
# Bootstrap contains top-level catalog loops using generic global names such
# as id. Keep the admitted Job/root arguments in this helper's own names.
source [file join $nativeCanvasWaitFramework gxtxt_pipeline.tcl]
::GX::defaults
set ::env(GXTXT_JOB_ROOT) $nativeCanvasWaitRoot
try {
    set result [::GX::scriptJobWait $nativeCanvasWaitJob 180]
    puts [dict create ok 1 result [dict create id $nativeCanvasWaitJob state [dict get $result state]]]
    exit 0
} on error {message options} {
    puts [dict create ok 0 error $message]
    exit 1
}
