# Native2D multilayer Canvas — DEV112-P003

SPDX-License-Identifier: GPL-3.0-or-later

This additive capability belongs to `NATIVE2D_API_v1@1` and
`VIEWER_GUI_HOST_API_v1@1`. Existing Native2D/CAD/raster contracts remain valid.
The C++ controller reuses the native scene, sketch, affine, CAD interaction and
retained SpriteScene owners. Interactive Document, managed Resource, Scientific
History, native Workspace and Scientific Execution retain their existing roles.
Canvas has no optional Viewer runtime dependency.

Each mounted Canvas uses the existing global adaptive GUI scheduler, including
the configured Low/Medium/Fast intensive cadence and immediate terminal Finish.
Diagnostics distinguish scheduled delay from actual preparation/paint cost.

## Builder and C++ admission

Insert the existing **native2d** component and set `source_kind canvas`.
`canvas_width`, `canvas_height`, `canvas_background` (RGBA) and `canvas_controls`
configure it. Ordinary native2d declarations retain their previous behavior.
Duplicate and reparent through standard Builder controls. Each component owns
independent document/view/selection/tool/History/scheduler/lifetime state.
Use ordinary panel/section/splitter/tab containers; tabs contain tab pages.
The ordinary Builder component/resource bounds remain authoritative.

CORE controls use the existing overflow menu on narrow toolbars. The inspector
scrolls horizontally when its natural font width exceeds its allocation, and
keyboard focus reveals the selected field. The status remains one line; focus
or F1 exposes the complete diagnostic. These controls use the framework's actual
theme, font and Tk scaling configuration.

Builder Design Preview retains its existing inert layout-preview contract.
Native editing in Builder uses its existing **Runtime Test** workflow: install
the matching compiled package into a private test framework, select the marked
private GUI fixture/current Session, then connect that exact installed design.
This keeps ordinary design preview from creating scientific documents or running
custom handlers. The normal installed Viewer mounts native Canvases in an active
Session; a Viewer opened without a Session displays a diagnostic.

Declare GUI Host operation `canvas_command` in the C++ project. The additive
`Host::canvas_command(unsigned component, const char* operation,
const WorkspaceValue& request)` uses the existing typed client transport.
Component indices are one-based declaration indices. `canvas_result()` returns
a borrowed immutable next-event receipt for the last successful explicit Canvas
command target, valid only for that event. Use `inspect` to request a particular
component. Before the first command, or after its target is disposed, the receipt
has an empty `instances` map. The existing map contains at most that one target;
it is not a global feed of all Canvas instances. Diagnostic layer/object/selection
lists may be shortened to fit48KiB, with `diagnostics_complete=false` and exact
layer/object totals retained. Complete trusted Describe/Capture remain available.
Command-only clients receive no unused diagnostic context. The SDK
changes neither Host/State/Event layout nor existing opcodes.

```cpp
host.canvas_command(canvas_index, "bind_source", gx::workspace_object({
    {"source_selector", gx::workspace_integer(selector_index)}
}));
host.canvas_command(canvas_index, "tool_set", gx::workspace_object({
    {"tool", gx::workspace_text("spline")}
}));
```

Source selectors must declare `content_kind raster`. Extra existing grants:
bind_source needs GUI Host raster_bind; filter/flatten need Scientific Execution
submit; undo/redo need Scientific Recipe scientificHistoryViewerNavigate;
publish needs Dataset File Publication datasetFilePublicationPublish.

Requests are bounded to48KiB/8192nodes/depth64, with strict finite schemas.
Unknown/duplicate fields, nonfinite values, raw resources, pixel arrays, widget
names, filesystem paths and Tcl dispatch are refused. Target objects/layers use
returned stable logical IDs: an ASCII letter followed by letters, digits,
underscore, period, colon, hash or hyphen, at most128characters. Native IDs are
not public target authority. Optional expected_revision rejects stale edits.

## Trusted host lifecycle

* `native2DCanvasCreate module provider ?options?`: current Session and admitted
  document owner required. Options: width, height, background, saved document_id.
* `native2DCanvasMount handle parent ?{controls boolean callback command}?`:
  mount once in a chosen parent, including `.`.
* `native2DCanvasCommand handle operation ?request?`: finite admitted operation.
* `native2DCanvasDescribe handle`: state and bounded diagnostics.
* `native2DCanvasCapture handle`: complete declared scene snapshot.
* `native2DCanvasRestore handle snapshot`: validate/rebuild provisionally, adopt
  only after native resources and presentation pass admission.
* `native2DCanvasDispose handle`: release its own runtime and cancel requests;
  other instances and persisted documents retain their existing owners.

Dimensions are integral1–16384, at most16777216pixels. RGBA channels and opacity
are finite0–1. Mutations recheck Session/document/source generation, revision
and SHA. Changed/missing sources refuse edits and stale result adoption.
Recovery, navigation, inspection and cancellation remain available.

## Operations and properties

The strict executable request schemas are
`core/python/viewer_canvas_request_v1.py` and the trusted host binding
`core/tcl/native2d_canvas_api_v1.tcl`. Finite operations:

* new, bind_source, tool_set, selection_set;
* object_create/update/delete/affine/duplicate/group/ungroup;
* copy, cut, paste;
* layer_create/update/delete/assign/select/reorder;
* merge, flatten, filter, undo, redo, fit, zoom, pan;
* save, open, cancel, dispose, inspect, publish.

Tools: select, line, rectangle, ellipse, arrow, text, spline, translate, resize,
rotate, pivot, pan. Drag gestures commit one edit on release. For a native
spline, click its knots (three noncollinear knots produce a curved spline),
move to preview, and press Enter to commit one edit. Escape or a tool transition
cancels the whole provisional construction. Ctrl-drag edits defining native
controls. SDK edits during a provisional gesture must first finish or cancel it;
explicit tool/navigation/save/history transitions cancel it safely. Splines retain native
controls/tangents/affine precision. Selection remains distinct from scientific ROI.

Geometry and affine translations use native world coordinates. `pan` dx/dy and
`zoom` center use device pixels in the current viewport; zoom factor below1
zooms in (for example1/1.2), above1 zooms out. A fresh document fits its declared
extent before its initial checkpoint. Mounting an existing document preserves
its saved requested-world camera; window resizing can change device dimensions.

Capture and Viewer Workspace/History use the accepted pre-gesture snapshot and
History record while a native edit is provisional. Another Canvas's completion
cannot publish a held preview or discard its redo branch. Native commit releases
that guard before one accepted edit is captured.

Layers expose stable identity/name/order, visible/selectable/locked flags,
opacity and blend. Blends are exactly Over, Multiply, Screen, Overlay, SoftLight.
Object opacity is the alpha channel of style.color, not a style.opacity field.
Other flags/order/line width/style/marker retain existing Native2D contracts.
Text uses an exact native rectangle and declared text/font/font_size/anchor
metadata, rendered by the existing shaped-text owner; font_size is1–512world
units. Groups are disjoint flat contiguous members of one layer. Group alpha
and visibility/lock/selectability preserve leaf local properties; unsupported
nested/partial groups refuse.

## Composition, sources and materialization

Vectors, raster images, text and native splines share one retained native painter
in actual layer/object order. Layer/group alpha apply after member composition.
Style/order/camera changes reuse admitted raster photos and retained identities.
An unchanged Cartesian pan at identical scale/frame can reuse the existing
prepared native geometry through its presenter transform. Offsets derive from
its fixed prepared reference, preserving round trips. Source, descriptor, group,
style and budget checks remain. Construction-line clipping, zoom/resize, frame
changes and nonidentity previews take the existing native build path. This
reuses geometry; it does not shift screen pixels into scientific output.
Grouping retains editable native geometry. A compatible merge retains exact
native objects/IDs and requires visible/selectable/unlocked Over layers with
opacity1; other composition policies explicitly refuse. Flatten captures the
full admitted composition using that same native painter and makes one new
managed raster/History edit. Partial layer subsets and hidden/locked targets
refuse rather than silently dropping content. Undo restores native editability.
Preview never implicitly replaces scientific geometry or source bytes.

Fixed filters: grayscale, invert, brightness_contrast, blur, sharpen. Existing
managed raster Jobs process immutable full source resources. RGB processing
preserves alpha. Derived/filter/flatten output is explicitly RGBA8 sRGB, not
scientific16-bit/float preservation. Original source bytes/checksums remain
unchanged. Unsupported source encodings, unreproducible legacy masks, blend or
output policies refuse. Publish creates a new canonical image.raster PNG without
replacing editable objects. Adoption checks the captured Canvas/Session/document/
source receipts and request sequence; cancellation never adopts a late success.
Raster display depends on the installed Tk image decoder. In particular, the
tested float32 TIFF fixture is source-admissible but its display decoder and
RGBA8 publication path refuse that encoding. This is an explicit unsupported
render/output case, not a floating-point scientific conversion guarantee.

## Persistence and compatibility

Complete snapshots use gxtxt.native2d.canvas_scene.v1; existing Interactive
Document payloads use gxtxt.native2d.canvas_document.v1. They retain stable IDs,
exact native resources, groups, source lineage, camera, selection, active layer,
tool and retained outputs. No runtime widget/native pointers or scheduler handles
persist. Ordinary/cold reopen validates all resources before adopting a scene.
The existing typed Viewer Workspace includes a native2d_canvas domain for every
component binding. Per-Canvas Undo is independent from global Viewer History.
Completed edits and the existing transition flush keep the enclosing Viewer
History coherent before Save, Close and navigation. Canvas edits use its existing
read-only and explicit branch review. Receipt revisions created by restoration
do not themselves create semantic History edits. Persisted receipts remain exact.
Mounted restoration uses the current widget dimensions and binds the existing
presenter before synchronously finishing its first frame. Locked members are
reconstructed provisionally, grouped, and then restored to their exact saved
locks before adoption. Runtime request sequences and gesture state are not
restored from persisted snapshots. Retired display-photo values are released
when a document or accepted presentation replaces them; History resources remain
with their existing owner.

Layer duplication composes the existing operations: copy the layer's complete
groups and ungrouped leaves, create a layer, paste into its returned logical ID,
and restore the requested layer properties. These are separate ordinary edits.
`layer_create` does not implicitly select the new layer. The executable layer
recipe in the validation evidence checks exact locked member/group/layer styles,
fresh identities, native definitions, Undo/Redo and cold reopen.

Complete snapshots are bounded to8MiB and4000 combined layer/leaf/group identities.
The48KiB client request bound may refuse a large bulk list before that scene
capacity; split such work into admitted requests. No partial request is applied.

The existing managedResourceCopyTree(document,typed_graph) additionally admits
an active Interactive Document destination. The same explicit typed grammar,
native validation, streaming copier and generation/SHA checks remain in force;
existing native Workspace targets remain supported. Canvas clipboard uses this
owner for nested image/geometry adoption, never the retired untyped converter.

P003 is incremental against exact post-P002. Candidate implementation and test
evidence do not imply owner acceptance or release activation.
