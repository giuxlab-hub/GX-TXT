# DEV112-P007 owner handoff

This delivery is one cumulative framework patch containing the three required corrections. The exact source commit, managed inventory and checksums are recorded in `patch/ASSEMBLY.json`, `patch/FILES.json`, `patch/SOURCE_FILES.json` and the delivery checksum files. `MODIFIED_FILES.json` identifies the changes from delivered P006 r5.

The supported direct installation routes are pristine DEV112 Release 2, the exact accepted post-P005 baseline and the exact delivered P006 r5 installation. They reach one identical managed P007 framework postimage. The helper performs strict baseline and integrity checks; successful application creates an external receipt bound to the origin, archive, manifest, framework root and installation instance. Authentic receipt-based rollback restores the selected route's original managed bytes and modes.

Follow `INSTALLAZIONE.md` using the supplied helper and retain the completed receipt plus its independently retained SHA-256. Scientific data, Sessions, configuration and unrelated files are preserved. The owner's working installation was not activated or modified. The original frozen ORION/SII and unrelated unfinished work remain preserved.

Validation uses disposable scientific fixtures and isolated environments. The performance report distinguishes worker preparation, host rendering, first painted current view, warm/repeated rendering and actual Tk heartbeat gaps. Engineering budgets are explicitly identified; they are not owner-approved numerical thresholds. Independent Sol 6.1 Low validation, including its own subagent, binds the final source and artifacts to its acceptance decision.

The preinstalled Curve Digitalizer companion is updated by the framework overlay. Historical version-pinned distribution carriers remain retained; `FILES.json` is authoritative for the current P007 managed framework. No separate plugin installation is required.
