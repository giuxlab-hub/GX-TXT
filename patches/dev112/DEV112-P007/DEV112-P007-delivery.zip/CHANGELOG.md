# GX-TXT DEV112-P007 changes

Framework version: 0.9.8.10-dev-112. Patch level: 007. Cumulative source baseline: delivered P006 r5, commit `6498d8d241e3fb8e8c48db1e9d3ce3dd0c2d393e`.

## Script Library

Selection no longer rebuilds and rereads the entire Registry. Existing native SHA engines accelerate selected-source checks with the original binary-safe fallbacks retained. Project, source-note and provided-API reads use the existing managed request owner while Tk services events. The read scope remains bound to the original Library, Session and stack; module ownership is suspended during unrelated callbacks and restored before continuation. Existing identity, namespace, source-integrity and draft guards remain in force.

## Script Jobs

Closing a window after an unrestricted Treeview column drag could fail its existing 3000-pixel preference validator. Captured widths now use the established persistence bounds. Workspace, History, menu organization, preferences, active/completed Jobs, logs, results, cancellation and recovery retain their owners and interfaces.

## Dataset Preview

Repeated metadata decoding and contributor verification use bounded exact-current-value caches. Scientific preparation retains the existing asynchronous Job route and visible Preview progress. Presentation validation brackets each admitted update; rendering uses guarded event-loop phases. Same-key rendering retains a complete, source-verified companion composition. Curve Digitalizer companion model preparation and Plot mounting use separate original source-checked deliveries, with cancellation ownership maintained throughout.

Accepted saved-view state is committed through the existing fixed worker and Dataset authority, guarded by source/key, Session-instance and configuration CAS checks. The queue preserves newer accepted views and foreign changes, and completes accepted work safely after normal window closure. Compiled editor acknowledgement retains its existing path. Scientific algorithms, calibration, grouping, source identity and Plot semantics remain unchanged.

See the performance report, modified-file inventory and independent validation records for measured results and exact scope. P001–P006 functionality remains cumulative. ORION and SII remain frozen.
