# DEV112-P007 measured performance

Independent validator: Sol 6.1, Low, with its own independent subagent. Final source `a10f5a99fdab93e251efe9c415d5ad76d14c5259`. Actual Tk GUI tests use isolated disposable Sessions on Debian/Xvfb. Cold means the managed Preview cache is empty; shared OS filesystem caches were not flushed. Results describe this environment, not universal timing guarantees.

## Script Library

| Selection | P006 r5 median | P007 median |
|---|---:|---:|
| Python | 1741.2 ms | 426.2 ms |
| Octave | 1703.2 ms | 375.7 ms |
| Python multifile | 2067.7 ms | 919.2 ms |

All nine repeated selections completed. Maximum measured Tk timer gap improved from2037.2ms to196.6ms. The actual Octave multiple-file project and source roster were also verified. Engineering targets: Python/Octave selection600ms, multiple-file selection1200ms, heartbeat250ms. These are engineering targets, not owner-approved thresholds.

## Dataset Preview — 50,000 points per Dataset

Fixtures contain one curve or five curves totaling50,000 points, calibrated physical/raster coordinates, grouping, a linked source PNG and the original digitizer Quality diagnostics. Preparation is original managed supervisor start-to-finish time. Render is traced host adoption duration. Total is action-to-current-painted readiness. The measured intervals overlap and must not be summed.

| Existing Preview route | Dataset | Preparation (s) | Render (s) | Usable total (s) | Max Tk gap (ms) |
|---|---|---:|---:|---:|---:|
| Standard cold | single curve | 8.525 | 1.455 | 13.482 | 322 |
| Standard warm | single curve | 9.098 | 1.638 | 14.628 | 412 |
| Standard repeat | single curve | 0.000 | 0.000 | 0.459 | 328 |
| Standard cold | five curves | 9.415 | 1.718 | 14.836 | 394 |
| Standard warm | five curves | 9.544 | 1.928 | 15.055 | 389 |
| Standard repeat | five curves | 0.000 | 0.000 | 0.526 | 333 |
| Companion warm | single curve | 0.000 | 0.000 | 0.579 | 396 |
| Companion repeat | single curve | 0.000 | 0.000 | 0.719 | 406 |
| Companion warm | five curves | 0.000 | 0.000 | 0.597 | 409 |
| Companion repeat | five curves | 0.000 | 0.000 | 0.723 | 403 |
| reopen | single curve | 0.000 | 2.249 | 2.551 | 420 |
| Companion cold restoration | single curve | 10.304 | 3.265 | 15.701 | 402 |
| Companion cold restoration | five curves | 9.834 | 3.568 | 15.381 | 407 |

The first Standard explicit Render changes the renderer/options key and prepares a new Job, even though its raw scenario name is warm. Only unchanged-key repeat and companion warm rows are cache-hit results. The raw Standard multiple-curve cold report sampled ready=false after a subsequent25ms heartbeat drain scheduled another redraw; the bounded readiness loop had already observed current successful paint at14.836s. Raw evidence and this qualification are retained.

Actual visible companion Load took2.402s (single) and2.507s (multiple), with maximum Tk gaps410/432ms. Both final corrected cold companion restoration rows replace the failed intermediate final03 cold rows; unaffected standard/cache/companion evidence is explicitly bound by the independent source comparison. Cold companion P006 r5 totals were42.896/43.532s with Tk gaps25.288/24.765s. P007 corrected cold totals are15.701/15.381s with402/407ms gaps.

Engineering targets: preparation30s; first current usable view35s; unchanged-key cache reuse5s; phased host rendering5s; maximum20ms-sampled Tk timer gap500ms during preparation and completion. These are engineering targets, not owner-approved thresholds. Tested final scenarios meet them. Cancellation with a live PREPARING Job and after an old view is restored, queued callback cancellation/retry, Dataset switching, closure and reopening pass. All100,000 fixture rows, point order, calibration, grouping and original CSV/PNG identity remain unchanged.

## Script Jobs

An actual3500-pixel pointer drag reproduced the baseline closure error. Corrected normal Close took6.65ms;19 independent lifecycle checks passed with no background errors. Existing Workspace/History menus, presentation preferences, active/completed Jobs, logs, cancellation and recovery were preserved.

Full numerical records, original raw evidence, source bindings and retained intermediate failures are in `INDEPENDENT_BENCHMARKS.json`, `INDEPENDENT_RUNTIME_ACCEPTANCE.txt` and the hash-pinned independent evidence archive. Actual cumulative ZIP installation and receipt rollback qualification are separate artifact evidence.
