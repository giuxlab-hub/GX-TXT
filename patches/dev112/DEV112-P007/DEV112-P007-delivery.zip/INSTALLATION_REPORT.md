# DEV112-P007 cumulative installation qualification

The independent validator's own subagent tested the actual final patch ZIP and helper, using fresh private trees reconstructed from hash-pinned original archives. These are installation tests, with no framework activation or real Session use.

| Direct baseline | Original managed files | Replaced/added files | Final managed files | Installation and authentic rollback |
|---|---:|---:|---:|---|
| Pristine DEV112 Release2 | 5435 | 1516 | 6381 | PASS |
| Exact accepted post-P005 | 5520 | 1407 | 6381 | PASS |
| Exact delivered P006r5 | 6362 | 43 | 6381 | PASS |

All three routes produced identical managed bytes, sizes and modes with canonical inventory SHA-256 `514e9dd7778b8eb2fc34d60ea0ec4cb544786f430d9e308d0620171e8cac90ed`. Each authentic receipt rollback restored that route's exact original managed inventory and removed patch-added managed files. Session, configuration and unrelated-file sentinels remained byte/mode-identical throughout.

Each route additionally verified read-only default/check behavior and prewrite refusal of modified managed bytes, changed modes and undeclared CORE source files. Rollback refused a wrong origin, a changed retained receipt and an incomplete forged receipt without changing the target.

Exact source `a10f5a99fdab93e251efe9c415d5ad76d14c5259`; patch SHA-256 `db4b7457edebc3a01bae244e1bc01db7a785d7348b9d808fb000b7a2d20131b3`; manifest SHA-256 `439b6635cb62c68ff453a98094b07a43db91042bf85846e9ad17581ec6d97dca`; helper SHA-256 `7caf5a50d80f9aa9d5dad2e2f663ef46e5bbe65af2b7ca5ff1c898344c5c3946`.

The earlier300-second author/independent harness attempts exhausted the shared RAID durability-I/O budget; their trees/receipts remain preserved and are not classified as passes. The successful independent full matrix used fresh baselines and a1200-second test-only budget. Neither the final installer nor Preview/Job timeouts were changed. No mixed-tree continuation was attempted. Per-file atomicity and interrupted-install recovery limitations remain documented in `INSTALLAZIONE.md`.

`INDEPENDENT_INSTALLATION_RESULT.json` contains the independent verdict and three retained test-receipt hashes. Those disposable test receipts are evidence only; an owner's installation must create and retain its own receipt.
