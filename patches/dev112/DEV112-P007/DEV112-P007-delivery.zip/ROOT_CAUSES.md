# DEV112-P007 root causes and corrections

Source: `a10f5a99fdab93e251efe9c415d5ad76d14c5259`, based on delivered P006 r5 `6498d8d241e3fb8e8c48db1e9d3ce3dd0c2d393e`. The modified-file inventory is `MODIFIED_FILES.json`.

## Script Library selection

A read-only selection performed a complete Registry refresh in addition to selected-script verification. This doubled common Registry reads and repeated source hashes. Selected source, project and provided-API reads also launched synchronous external processing on the Tk stack. The independent baseline recorded a full Registry list/refresh on every selection and a 2.037-second maximum heartbeat gap.

Selection now preserves the current registered-reference list and updates its highlight. Existing trusted native digest operations accelerate the selected-file checks; binary-safe legacy fallbacks and escaped-path compatibility remain intact. Read-only preparation runs through the existing managed Job infrastructure while Tk services events. The original Library/Session/request binding is checked again before adoption. The implementation suspends the current module actor context during event servicing and restores it before continuation, preventing unrelated callbacks from inheriting another module's authority. Closing the Library or switching Session cancels only its owned reads; a changed source refuses stale adoption. Existing synchronous public callers keep their contract.

## Script Jobs closure

An actual Treeview header drag could create a width above the preference validator's existing 3000-pixel maximum. Closing the window attempted to persist that width and raised `Invalid Runner column width`. Captured widths now obey the established 30–3000 preference bounds. The menus and their organization remain unchanged. Independent lifecycle checks cover active/completed Jobs, repeated closure, saved Workspace reopening, History hide/restore, cancellation, recovery and retained logs.

## Dataset Preview

Scientific work already had a managed asynchronous route, but substantial preparation and delivery work still ran synchronously on Tk: repeated metadata decoding/contributor checks, repeated companion composition and model/Plot mounting, and durable saved-view receipt transactions. Theme-driven destruction could also invalidate widgets while Tk traversed them. The independent P006 baseline measured Tk gaps up to 25.288 seconds and companion cold generation around 43 seconds.

Bounded metadata caches use exact bytes/current public values and protected origins, so same-size or same-mtime source changes cannot bypass freshness checks. Scientific computation remains in its existing Job. Host adoption uses private guarded event phases, and companion model preparation and Plot mounting use two original source-checked deliveries. A valid unchanged-key composition is retained. Periodic observation skips unfinished phased rendering and reuses only a fully validated current companion; it no longer reconstructs the same old-frame companion repeatedly. The live new Job key is retained when restoring an older frame, preserving progress and cancellation.

Accepted saved-view receipts run in the existing fixed worker under the original Dataset authority transaction, with source/key, authenticated cache, saved-map CAS and physical Session-instance checks. Only CORE reserved last-render state is written. Coalescing rebases only an earlier verified write from the same queue; it never adopts foreign preference edits. Normal closure destroys the UI promptly and safely drains already accepted receipts afterward. Compiled editor acknowledgement keeps its existing synchronous semantics. Queued companion callbacks retain cancellation ownership until delivery starts.

No scientific algorithm, calibration, grouping, point order, original CSV/PNG, public API or Plot scientific behavior was changed. Preparation, phased rendering, total painted readiness and Tk responsiveness are reported separately in the independent performance evidence. Engineering limits are test targets, not owner-approved numerical thresholds.
