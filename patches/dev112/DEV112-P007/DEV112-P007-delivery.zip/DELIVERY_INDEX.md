# GX-TXT DEV112-P007 delivery index

Cumulative framework version `0.9.8.10-dev-112`, patch `007`.

- Exact source commit: `a10f5a99fdab93e251efe9c415d5ad76d14c5259`.
- Installable patch SHA-256: `db4b7457edebc3a01bae244e1bc01db7a785d7348b9d808fb000b7a2d20131b3`.
- Final managed inventory:6381 files; canonical SHA-256 `514e9dd7778b8eb2fc34d60ea0ec4cb544786f430d9e308d0620171e8cac90ed` (bytes, sizes and modes).

Start with `INSTALLAZIONE.md`. The installer is `patch/apply.py`; cumulative patch `patch/DEV112-P007.zip`. The exact supported direct routes are pristine DEV112 Release2, accepted post-P005 and delivered P006r5; installing previous patches in sequence is unnecessary. Retain the completed external receipt and its independently retained SHA for rollback.

Read `ROOT_CAUSES.md` and `CHANGELOG.md` for the three corrections; `MODIFIED_FILES.json` for changes relative to P006r5; `PERFORMANCE_REPORT.md` and `INDEPENDENT_BENCHMARKS.json` for separately measured preparation, rendering, total readiness and Tk responsiveness. `API_CONTRACTS.md`, `CORE_REUSE_AND_GAP_AUDIT.md` and `INDEPENDENT_FINAL_SOURCE_BINDING.json` describe compatibility and source integrity. The framework TODO removes obsolete completed descriptions while retaining genuinely unfinished scientific/platform work. ORION and SII remain frozen.

`INDEPENDENT_RUNTIME_ACCEPTANCE.txt/.json` provide Sol6.1 Low runtime acceptance with its own subagent. Named evidence under `evidence/` contains raw selected GUI/scientific results, representative screenshots, reproducible independent test scripts and actual cumulative installer/rollback results. Intermediate failed runs and the storage-budget interruptions are identified explicitly, without treating them as final passes. `reproduce/delivery_tools/` contains the version-scoped packaging and installation-check tooling with its catalog.

The delivery ZIP includes internal `SHA256SUMS`. Its external checksum file authenticates that ZIP. Detached `FINAL_ACCEPTANCE.json` in the release directory binds the exact source, installable patch and complete delivery ZIP hashes; it is detached to avoid a self-referential archive hash. `PUBLICATION_READBACK.json` verifies the deposited archives and expanded mirrors. No working installation or real Session was activated or modified.

## Using only the standalone patch ZIP

The standalone ZIP also carries its helper and instructions under `patch_notes/DEV112-P007/`. Extract those notes to a separate directory outside the framework and retain the original ZIP. Invoke that extracted `apply.py` with the original ZIP and target framework as its arguments; use the same check/apply/receipt/rollback flags documented in `INSTALLAZIONE.md`. The complete delivery layout already supplies the helper as `patch/apply.py` and avoids this extra extraction step.
