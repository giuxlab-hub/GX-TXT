# DEV112-P007 CORE reuse and scope

The patch reuses existing Script Registry, Script Jobs, Dataset publication, Preview preparation/cache, native rendering and curve-digitizer companion owners. It does not replace scientific algorithms or introduce another execution infrastructure.

ORION, SII and unrelated Viewers remain outside this patch. Unfinished unrelated work stays in GX-TXT_REMAINING_WORK_TODO.md.

The owner withdrew A02 on 2026-11-12. Functional API compatibility, source integrity and independent validation remain required; no retrospective inventory is presented as satisfaction of the withdrawn temporal requirement.

The companion is preinstalled and managed by the framework. Its P007 API source and SHA inventory travel in the cumulative framework payload. The original DEV111-P032 module carrier is retained as a pinned historical artifact. Current P007 archive/expanded parity applies to the complete P007 framework package; no new standalone external-plugin release or activation is introduced.
