# DEV112-P007 API and compatibility

P007 retains the existing public APIs, framework version, interfaces and cumulative P001–P006 capabilities. Changes are confined to Script Library selection, Script Jobs window lifecycle, Dataset Preview responsiveness/performance and their necessary technical dependencies.

Workspace and History management, existing menu organization and presentation preferences remain required. Existing Job execution, logs, results, cancellation and recovery ownership remain authoritative. Preview progress stays in the existing Preview interface. Existing scientific owners retain calibration, grouping, source identity and Plot behavior.

The exact managed file manifest and checksums define installation compatibility. The three supported baselines are strict byte/mode identities. Existing scientific data or user configuration are outside the patch payload.
