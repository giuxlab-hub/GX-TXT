# DEV112-P007 cumulative delivery tools

Version scope: GX-TXT 0.9.8.10-dev-112, patch007, based on P006r5 commit6498d8d241e3fb8e8c48db1e9d3ce3dd0c2d393e.

- `python3 -I -B assemble.py FRAMEWORK NEW_STAGE --source-commit FULL_SHA --documents DOCUMENTS`: reads clean frozen Git source and pinned r2/P005/P006r5 archives, writes fresh private cumulative ZIP, manifest, exact preimages, helper and checksums. No installation or activation.
- `python3 -I -B check_install.py STAGE NEW_OUTPUT`: reconstructs three exact private baseline trees, calls check/apply/receipt rollback, verifies full byte/mode postimages and restoration plus unrelated Session/config sentinels. No product launch or user data.
- `apply_p007_template.py`: installer template only, not a runnable current release helper until manifest pin substitution by assembly. Default check reads only; explicit apply requires stopped/authorized acknowledgements and creates external receipt; rollback requires retained SHA and authentic receipt.
- `baselines.py`: pinned archive/member verification and private in-memory baseline reconstruction, no writes.

All outputs must be fresh. Historical P006 tooling is adapted for three P007 routes before use.

- `python3 -I -B package_bundle.py STAGE DOCUMENTS EVIDENCE_INPUTS_JSON NEW_OUTPUT`: copies exact patch artifacts, English documents, named hash-pinned evidence and delivery tool source into a fresh private delivery tree/ZIP; validates member bytes and writes complete checksums. No frozen external package manipulation or activation. Final independent acceptance of the actual bundle is required before deposit.

- `python3 -I -B publish.py PREPARED_BUNDLE FINAL_REVIEW EXPECTED_REVIEW_SHA256`: requires independent ACCEPT_FOR_DELIVERY with exact source/patch/bundle hashes and zero blockers. Creates fresh workspace delivery, dev112 patch deposit and GXTXT/framework archives+expanded mirrors; verifies all extracted member bytes/modes, writes publication readback and checksums. Refuses existing destinations. No owner working-install changes, activation, user data or external messages. external_plugins/session_generators unchanged because no package in those sections is modified.

Final shared API catalog refresh: invoke `python3 -I -B FRAMEWORK/core/python/gxtxt_api_catalog.py build FRAMEWORK NEW_CATALOG_OUTPUT` with all XDG/cache/temp/installation/Job/Resource roots under a new private task directory, HOME unchanged. Uses original trusted discovery/builder; writes only private generated catalog then MAIN copies exact generated pair to candidate. Run after integrated fixes/marker007; compare public operation and argument tables with P006r5 and preserve exact frozen packages. No product launch or scientific execution.

Installer validation budget: check_install.py allows up to1200seconds per durable installer command because the shared RAID fsync throughput can exceed300seconds for1516 cumulative replacements. This is a test-harness budget only; the final installer and all Preview/Job timeouts are unchanged. Preserve interrupted earlier private attempts; always reconstruct a new target, never resume a mixed tree.
