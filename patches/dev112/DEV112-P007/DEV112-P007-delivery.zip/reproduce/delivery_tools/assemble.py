#!/usr/bin/env python3
"""Assemble an unqualified P007 cumulative archive from an explicit frozen commit.

This is author tooling. An assembled archive is not an independently qualified
release, owner acceptance or permission to activate an installation.
"""
import argparse
from datetime import datetime, timezone
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
TASK = HERE.parents[1]
sys.path.insert(0, str(HERE))
from baselines import admitted_baselines, canonical, digest, file_sha, identity, require, P005_SHA

TEMPLATE = HERE/'apply_p007_template.py'
DOCS = {'INSTALLAZIONE.md','README.md','CHANGELOG.md','OWNER_HANDOFF.md','VALIDATION.json',
        'CORE_REUSE_AND_GAP_AUDIT.md','API_CONTRACTS.md'}

def git(root, *arguments):
    return subprocess.check_output(['git','-C',str(root),*arguments])

def regular(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1,
            'Nonregular/symlink/hardlinked input: '+str(path))
    return info

def plain_root(raw):
    root = Path(os.path.abspath(raw))
    for p in [*reversed(root.parents), root]:
        require(stat.S_ISDIR(p.lstat().st_mode), 'Linked/non-directory ancestor: '+str(p))
    return root

def load_template():
    spec = importlib.util.spec_from_file_location('p007_guard_template',TEMPLATE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def source_snapshot(root, commit):
    require(re.fullmatch('[0-9a-f]{40}',commit), 'Use a complete exact source commit SHA')
    require(git(root,'rev-parse','HEAD').decode().strip() == commit, 'Frozen source commit differs')
    require(git(root,'rev-parse','--show-object-format').decode().strip()=='sha1', 'Unsupported Git object format')
    require(not git(root,'status','--porcelain','--untracked-files=all'), 'Candidate source is not clean')
    inventory = {}; source = {}; blobs = {}
    guard = load_template()
    for entry in git(root,'ls-files','--stage','-z').split(b'\0'):
        if not entry: continue
        head, raw_name = entry.split(b'\t',1)
        git_mode, blob, stage = head.decode('ascii').split()
        name = raw_name.decode('utf-8')
        guard.safe_relative(name)
        require(git_mode in ('100644','100755') and stage == '0', 'Unsupported Git mode/stage: '+name)
        path = guard.member(root,name)
        info = regular(path)
        require(info.st_size <= guard.MAX_MEMBER,'Candidate file exceeds bound: '+name)
        data = path.read_bytes()
        row = identity(data, stat.S_IMODE(info.st_mode))
        guard.expected_identity(row, name)
        require(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,
                'Candidate bytes differ from tracked Git blob: '+name)
        inventory[name] = row; blobs[name] = data
        source[name] = dict(**row,git_blob=blob,git_mode=git_mode)
    guard.guard_source_inventory(root,inventory)
    return inventory, source, blobs

def note_blobs(directory):
    directory=plain_root(directory)
    notes={}
    for name in sorted(DOCS):
        p=directory/name; info=regular(p)
        require(info.st_size <= 8*1024*1024,'Oversized P007 document: '+name)
        notes[name]=p.read_bytes()
        if name.endswith('.json'): json.loads(notes[name])
        else: notes[name].decode('utf-8')
    return notes

def zipped_member(archive,name,data,mode):
    info=zipfile.ZipInfo(name,(2026,11,12,0,0,0))
    info.create_system=3; info.external_attr=(stat.S_IFREG|mode)<<16
    info.compress_type=zipfile.ZIP_DEFLATED
    archive.writestr(info,data,compresslevel=6)

def assemble(candidate, output, commit, documents):
    candidate=plain_root(candidate)
    output=Path(os.path.abspath(output))
    require(output.is_relative_to(TASK),'Assembly output must remain in isolated P007 task root')
    require(not output.is_relative_to(candidate),'Assembly output must be outside candidate source')
    plain_root(output.parent)
    require(not os.path.lexists(output),'Assembly output already exists; preserve prior attempts')
    routes,before_blobs,inputs=admitted_baselines()
    post,source,blobs=source_snapshot(candidate,commit)
    require(blobs['PATCH_LEVEL.txt']==b'007\n','Candidate marker must already be exact007 newline')
    require(all(row['VERSION.txt']==post['VERSION.txt'] for row in routes.values()),'VERSION.txt policy changed')
    require(all(set(row)<=set(post) for row in routes.values()),'Published file deletions are not supported')
    payload=sorted(p for p in post if any(post[p]!=row.get(p) for row in routes.values()))
    manifest=dict(schema='gxtxt.dev112.cumulative.v1',patch='DEV112-P007',inputs=inputs,
                  routes=routes,postimage=post,payload=payload)
    raw_manifest=json.dumps(manifest,indent=2,sort_keys=True).encode()+b'\n'
    manifest_sha=digest(raw_manifest)
    installer=TEMPLATE.read_text().replace("MANIFEST_SHA256 = '"+'0'*64+"'", "MANIFEST_SHA256 = '"+manifest_sha+"'")
    guard=load_template(); guard.MANIFEST_SHA256=manifest_sha
    guard.validate_manifest(manifest)
    notes=note_blobs(documents)
    notes['FILES.json']=raw_manifest; notes['apply.py']=installer.encode()
    output.mkdir()
    archive_path=output/'DEV112-P007.zip'
    with zipfile.ZipFile(archive_path,'x') as archive:
        for name in payload:
            zipped_member(archive,name,blobs[name],post[name]['mode'])
        for route,before in sorted(routes.items()):
            for name in payload:
                if name in before and before[name]!=post[name]:
                    zipped_member(archive,'patch_notes/DEV112-P007/preimages/'+route+'/'+name,
                                  before_blobs[route][name],before[name]['mode'])
        for name,data in sorted(notes.items()):
            zipped_member(archive,'patch_notes/DEV112-P007/'+name,data,0o755 if name=='apply.py' else 0o644)
    for name,data in notes.items():
        p=output/name; p.write_bytes(data); p.chmod(0o755 if name=='apply.py' else 0o644)
    archive_sha=file_sha(archive_path)
    (output/'DEV112-P007.zip.sha256').write_text(archive_sha+'  DEV112-P007.zip\n')
    guard.archive_read(archive_path)
    # Recheck the complete frozen source after assembling, including modes.
    post_after,source_after,_=source_snapshot(candidate,commit)
    require(post_after==post and source_after==source,'Frozen source changed during packaging')
    (output/'SOURCE_FILES.json').write_text(json.dumps(source,indent=2,sort_keys=True)+'\n')
    (output/'P007_POSTIMAGE.json').write_text(json.dumps(post,indent=2,sort_keys=True)+'\n')
    changes={route:[dict(path=p,before=row.get(p),after=post[p]) for p in payload if row.get(p)!=post[p]]
             for route,row in routes.items()}
    (output/'CHANGE_MANIFEST.json').write_text(json.dumps(changes,indent=2,sort_keys=True)+'\n')
    receipt=dict(schema='gxtxt.dev112.p007.author_assembly.v1',utc=datetime.now(timezone.utc).isoformat(),
        status='AUTHOR_ASSEMBLED_NOT_INDEPENDENTLY_QUALIFIED',patch='DEV112-P007',activation='NONE',
        source_commit=commit,source_root=str(candidate),archive_sha256=archive_sha,
        manifest_sha256=manifest_sha,canonical_postimage_sha256=digest(canonical(post)),
        files=len(post),payload_files=len(payload),routes={k:dict(original_files=len(v),
        original_inventory_sha256=digest(canonical(v)),changes=len(changes[k])) for k,v in routes.items()},
        installer_template_sha256=file_sha(TEMPLATE),installer_sha256=file_sha(output/'apply.py'),
        limitations=['No product functionality or independent gate PASS is implied by assembly.',
                     'Per-file atomicity only; interrupted mixed trees require explicit owner restoration.',
                     'Exact stopped target, authorization, retained receipt and receipt SHA required for writes/rollback.'])
    (output/'ASSEMBLY.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    all_files=sorted(p for p in output.iterdir() if p.is_file())
    (output/'SHA256SUMS').write_text(''.join(file_sha(p)+'  '+p.name+'\n' for p in all_files))
    return receipt

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('candidate',type=Path);p.add_argument('new_stage',type=Path)
    p.add_argument('--source-commit',required=True)
    p.add_argument('--documents',type=Path,required=True,help='Actual owner-review documents, including VALIDATION.json')
    args=p.parse_args()
    try: result=assemble(args.candidate,args.new_stage,args.source_commit,args.documents)
    except (OSError,ValueError,subprocess.CalledProcessError) as error:
        raise SystemExit('ASSEMBLY REFUSED: '+str(error))
    print(json.dumps(result,sort_keys=True))

if __name__=='__main__': main()
