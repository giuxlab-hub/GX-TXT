"""Immutable DEV112.r2 and P005 archive admission and delivered P006r5 for P007 packaging."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import zipfile

DEPOSIT = Path('/srv/gxtxt/releases/dev112/patches/0005-cumulative-quantitative-raster')
R2 = Path('/srv/gxtxt/releases/dev112/0.9.8.10-dev-112-r2/public/gxtxt_pipeline_dev112_public.tar.gz')
R2_SHA = '8fda1fd6e485d9d917adfb08d64991c2403f8faf19ed10f4770565d8afcdbaa0'
P005_SHA = '55358070dc710ae4b1d7384edeef03f4a47627e4f790484d102a5a360e2e38b9'
P005_MANIFEST_SHA = '2b5919cc47f1bdd4fa9d4960bee02dbda4505c2b5f034497b8e992def3c309b7'
P005_INVENTORY_SHA = 'c4f988dee0f95b14b773fd67064fa09a80073a07a1a34e25d381273387b63a80'
R2_INVENTORY_SHA = 'd385ab67405dedbe0747d6de6bc97c9ff267313041391c355d7020da8a195c3d'

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(blob):
    return hashlib.sha256(blob).hexdigest()

def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()

def identity(blob, mode):
    return dict(sha256=digest(blob), size=len(blob), mode=mode)

def prior_baselines():
    require(file_sha(R2) == R2_SHA, 'Pristine r2 archive SHA differs')
    require(file_sha(DEPOSIT/'DEV112-P005.zip') == P005_SHA, 'Deposited P005 archive SHA differs')
    with zipfile.ZipFile(DEPOSIT/'DEV112-P005.zip') as archive:
        raw = archive.read('patch_notes/DEV112-P005/FILES.json')
        require(digest(raw) == P005_MANIFEST_SHA, 'Embedded P005 manifest SHA differs')
        prior = json.loads(raw)
        r2 = prior['routes']['r2']
        p005 = prior['postimage']
        require(len(r2) == 5435 and digest(canonical(r2)) == R2_INVENTORY_SHA, 'r2 inventory differs')
        require(len(p005) == 5520 and digest(canonical(p005)) == P005_INVENTORY_SHA, 'P005 inventory differs')
        overlay = {p: archive.read(p) for p in prior['payload']}
        for path, blob in overlay.items():
            info = archive.getinfo(path)
            require(identity(blob, (info.external_attr >> 16) & 0o7777) == p005[path], 'P005 payload identity differs: '+path)
    contents = {}
    with tarfile.open(R2, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == 5435, 'Pristine r2 member count differs')
        for member in members:
            parts = PurePosixPath(member.name).parts
            require(len(parts) > 1 and parts[0] == 'gxtxt_pipeline_v09810dev_112' and
                    all(p not in ('', '.', '..') for p in parts) and member.isfile() and
                    '\\' not in member.name and ':' not in member.name,
                    'Invalid pristine r2 archive member: '+member.name)
            path = '/'.join(parts[1:])
            require(path in r2 and path not in contents, 'Unknown/duplicate r2 member: '+path)
            with archive.extractfile(member) as stream:
                blob = stream.read()
            require(identity(blob, member.mode) == r2[path], 'Pristine r2 member identity differs: '+path)
            contents[path] = blob
    require(set(contents) == set(r2), 'Pristine r2 membership differs')
    p005_contents = dict(contents)
    p005_contents.update(overlay)
    require(set(p005_contents) == set(p005), 'P005 membership differs after overlay')
    require(all(identity(p005_contents[p], p005[p]['mode']) == row for p, row in p005.items()),
            'P005 reconstructed postimage bytes differ')
    return dict(r2=r2, **{'post-p005':p005}), dict(r2=contents, **{'post-p005':p005_contents}), prior['inputs'] | {'P005':P005_SHA}


P006 = Path('/srv/gxtxt/main/work-agent/TK_GIUXLAB/deliveries/DEV112-P006-20261112-r5/patch/DEV112-P006.zip')
P006_SHA = 'd62ff22bd824e1dcdfaece27243ae958a5d20d1ec624d0b33d45be79fc2a7ed6'
P006_MANIFEST_SHA = 'd0a4d9f7bf32469aa3c10bedc7411f113f96c17d52795abf7bb550686f247556'
P006_INVENTORY_SHA = '1471c154455c18c18c7f71a1dd751c1d946e1235ceecc25e23008bfb7360c11c'

def admitted_baselines():
    routes, contents, inputs = prior_baselines()
    require(file_sha(P006) == P006_SHA, 'Delivered P006r5 archive SHA differs')
    with zipfile.ZipFile(P006) as archive:
        raw = archive.read('patch_notes/DEV112-P006/FILES.json')
        require(digest(raw) == P006_MANIFEST_SHA, 'Delivered P006r5 manifest SHA differs')
        prior = json.loads(raw)
        require(prior['routes'] == routes and prior['inputs'] == inputs, 'P006 prior baseline identity differs')
        post = prior['postimage']
        require(len(post) == 6362 and digest(canonical(post)) == P006_INVENTORY_SHA, 'P006 inventory differs')
        result = dict(contents['r2'])
        for name in prior['payload']:
            blob = archive.read(name)
            info = archive.getinfo(name)
            require(identity(blob, (info.external_attr >> 16) & 0o7777) == post[name], 'P006 member identity differs: '+name)
            result[name] = blob
        require(set(result) == set(post), 'P006 member set differs')
        require(all(identity(result[p], row['mode']) == row for p,row in post.items()), 'P006 postimage differs')
    routes['post-p006-r5'] = post
    contents['post-p006-r5'] = result
    return routes, contents, inputs | {'P006-r5': P006_SHA}
