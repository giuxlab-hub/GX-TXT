"""Package a reviewed P007 patch, English documents and named evidence."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import stat
import zipfile

TASK = Path(__file__).resolve().parents[2]


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def copy(source, target):
    assert source.is_file() and not source.is_symlink(), source
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    target.chmod(stat.S_IMODE(source.stat().st_mode))
    assert sha(source) == sha(target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', type=Path)
    parser.add_argument('documents', type=Path)
    parser.add_argument('evidence_inputs', type=Path)
    parser.add_argument('new_output', type=Path)
    args = parser.parse_args()
    output = args.new_output.absolute()
    assert output.is_relative_to(TASK) and not output.exists()
    output.mkdir(mode=0o700)
    tree = output / 'delivery'
    tree.mkdir()
    assembly = json.loads((args.stage / 'ASSEMBLY.json').read_text())
    assert assembly['patch'] == 'DEV112-P007'
    for name, key in [('DEV112-P007.zip', 'archive_sha256'), ('apply.py', 'installer_sha256'), ('FILES.json', 'manifest_sha256')]:
        assert sha(args.stage / name) == assembly[key], name
    for source in sorted(args.stage.iterdir()):
        if source.is_file():
            copy(source, tree / 'patch' / source.name)
    for source in sorted(args.documents.iterdir()):
        if source.is_file():
            copy(source, tree / source.name)
    evidence = json.loads(args.evidence_inputs.read_text())
    for name, record in evidence.items():
        assert Path(name).name == name and name not in {'.', '..'}, name
        source = Path(record['path'])
        assert sha(source) == record['sha256'], name
        copy(source, tree / 'evidence' / name)
    copy(args.evidence_inputs, tree / 'evidence/INPUTS.json')
    for source in sorted(Path(__file__).parent.iterdir()):
        if source.is_file() and source.suffix in {'.py', '.md'}:
            copy(source, tree / 'reproduce/delivery_tools' / source.name)
    files = sorted(path for path in tree.rglob('*') if path.is_file())
    (tree / 'SHA256SUMS').write_text(''.join(sha(path) + '  ' + path.relative_to(tree).as_posix() + '\n' for path in files))
    archive = output / 'DEV112-P007-delivery.zip'
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for path in sorted(path for path in tree.rglob('*') if path.is_file()):
            assert not path.is_symlink()
            info = zipfile.ZipInfo(path.relative_to(tree).as_posix(), (2026, 11, 12, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | stat.S_IMODE(path.stat().st_mode)) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            zipped.writestr(info, path.read_bytes(), compresslevel=6)
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        assert set(zipped.namelist()) == {p.relative_to(tree).as_posix() for p in tree.rglob('*') if p.is_file()}
        for name in zipped.namelist():
            assert hashlib.sha256(zipped.read(name)).hexdigest() == sha(tree / name)
    digest = sha(archive)
    (output / (archive.name + '.sha256')).write_text(digest + '  ' + archive.name + '\n')
    receipt = {'status': 'PREPARED_FOR_FINAL_INDEPENDENT_REVIEW', 'source_commit': assembly['source_commit'],
        'patch_sha256': assembly['archive_sha256'], 'bundle_sha256': digest,
        'delivery_tree': str(tree), 'bundle': str(archive), 'production_activation': False}
    (output / 'BUNDLE.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
