"""Deposit only independently accepted P007 bytes in new release directories."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import stat
import zipfile

TASK = Path(__file__).resolve().parents[2]
WORKSPACE = Path('/srv/gxtxt/main/work-agent/TK_GIUXLAB/deliveries/DEV112-P007-20261112')
RELEASE = Path('/srv/gxtxt/releases/dev112/patches/0007-cumulative-usability')
ARCHIVES = Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV112-P007-20261112')
EXPANDED = Path('/srv/gxtxt/releases/GXTXT/framework/expanded/patches/DEV112-P007-20261112')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def copy(source, target):
    assert source.is_file() and not source.is_symlink(), source
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open('rb') as incoming, target.open('xb') as outgoing:
        shutil.copyfileobj(incoming, outgoing)
    target.chmod(stat.S_IMODE(source.stat().st_mode))
    assert sha(source) == sha(target)


def copy_tree(source, target):
    target.mkdir()
    for path in sorted(source.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            copy(path, target / path.relative_to(source))
        elif path.is_dir():
            (target / path.relative_to(source)).mkdir(exist_ok=True)
        else:
            raise ValueError('Nonregular delivery artifact: '+str(path))


def expand(archive, target):
    target.mkdir()
    with zipfile.ZipFile(archive) as zipped:
        names = zipped.namelist()
        assert len(names) == len(set(names))
        for info in zipped.infolist():
            parts = info.filename.split('/')
            assert all(p not in {'', '.', '..'} for p in parts)
            assert not info.filename.startswith('/') and '\\' not in info.filename and ':' not in info.filename
            mode = info.external_attr >> 16
            assert stat.S_ISREG(mode)
            path = target.joinpath(*parts)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(zipped.read(info))
            path.chmod(stat.S_IMODE(mode))
        assert {p.relative_to(target).as_posix() for p in target.rglob('*') if p.is_file()} == set(names)
        for info in zipped.infolist():
            path = target / info.filename
            assert hashlib.sha256(zipped.read(info)).hexdigest() == sha(path)
            assert stat.S_IMODE(path.stat().st_mode) == stat.S_IMODE(info.external_attr >> 16)
    return {'archive': str(archive), 'sha256': sha(archive), 'expanded': str(target),
            'members': len(names), 'complete_sha256_mode_parity': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('prepared_bundle', type=Path)
    parser.add_argument('final_review', type=Path)
    parser.add_argument('expected_review_sha256')
    args = parser.parse_args()
    bundle = args.prepared_bundle.absolute()
    assert bundle.is_relative_to(TASK)
    assert sha(args.final_review) == args.expected_review_sha256
    review = json.loads(args.final_review.read_text())
    prepared = json.loads((bundle / 'BUNDLE.json').read_text())
    assert review['status'] == 'ACCEPT_FOR_DELIVERY' and not review['blockers']
    for key in ['source_commit', 'patch_sha256', 'bundle_sha256']:
        assert review[key] == prepared[key], key
    tree = bundle / 'delivery'
    assert sha(tree / 'patch/DEV112-P007.zip') == prepared['patch_sha256']
    assert sha(bundle / 'DEV112-P007-delivery.zip') == prepared['bundle_sha256']
    for target in [WORKSPACE, RELEASE, ARCHIVES, EXPANDED]:
        assert not target.exists() and target.parent.is_dir(), target
    for target in [WORKSPACE, RELEASE]:
        copy_tree(tree, target)
        for source in [bundle / 'DEV112-P007-delivery.zip', bundle / 'DEV112-P007-delivery.zip.sha256', bundle / 'BUNDLE.json']:
            copy(source, target / source.name)
        copy(tree / 'patch/DEV112-P007.zip', target / 'DEV112-P007.zip')
        copy(tree / 'patch/DEV112-P007.zip.sha256', target / 'DEV112-P007.zip.sha256')
        copy(args.final_review, target / 'FINAL_ACCEPTANCE.json')
    ARCHIVES.mkdir()
    for source in [tree / 'patch/DEV112-P007.zip', tree / 'patch/DEV112-P007.zip.sha256',
                   bundle / 'DEV112-P007-delivery.zip', bundle / 'DEV112-P007-delivery.zip.sha256']:
        copy(source, ARCHIVES / source.name)
    copy(tree / 'patch/apply.py', ARCHIVES / 'DEV112-P007-apply.py')
    copy(args.final_review, ARCHIVES / 'FINAL_ACCEPTANCE.json')
    EXPANDED.mkdir()
    parity = [expand(ARCHIVES / 'DEV112-P007.zip', EXPANDED / 'DEV112-P007'),
              expand(ARCHIVES / 'DEV112-P007-delivery.zip', EXPANDED / 'DEV112-P007-delivery')]
    record = {'status': 'DEV112-P007_DELIVERED', **{k: prepared[k] for k in ['source_commit', 'patch_sha256', 'bundle_sha256']},
        'independent_review_sha256': args.expected_review_sha256,
        'destinations': [str(p) for p in [WORKSPACE, RELEASE, ARCHIVES, EXPANDED]],
        'archive_expanded_parity': parity, 'production_activation': False,
        'external_plugins': 'UNCHANGED', 'session_generators': 'UNCHANGED'}
    for target in [WORKSPACE, RELEASE, ARCHIVES, EXPANDED]:
        (target / 'PUBLICATION_READBACK.json').write_text(json.dumps(record, indent=2) + '\n')
        files = sorted(p for p in target.rglob('*') if p.is_file())
        (target / 'DELIVERY_SHA256SUMS').write_text(''.join(sha(p)+'  '+p.relative_to(target).as_posix()+'\n' for p in files))
    (TASK / 'PUBLICATION_READBACK.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
