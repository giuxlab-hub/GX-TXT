# GX-TXT DEV112-P007

Cumulative framework bug-fix patch for GX-TXT 0.9.8.10-dev-112, patch level 007. Development starts from delivered P006r5 source 6498d8d241e3fb8e8c48db1e9d3ce3dd0c2d393e. P001–P006 functionality is retained.

The installer accepts pristine DEV112 Release 2, the exact accepted post-P005 baseline, or the exact delivered P006r5 installation directly. Previous patches do not need to be installed in sequence. Each route has the same complete P007 managed framework postimage.

Read INSTALLAZIONE.md for installation and authentic receipt-based rollback. FILES.json records all admitted baselines and the final managed inventory; ASSEMBLY.json records the exact source commit and hashes. The delivery includes the modified-file inventory, measured GUI results and independent Sol 6.1 Low decision.

Existing scientific data, Sessions, configuration and unrelated files are preserved. Release deposit does not activate the owner's working installation. ORION and SII remain frozen.
