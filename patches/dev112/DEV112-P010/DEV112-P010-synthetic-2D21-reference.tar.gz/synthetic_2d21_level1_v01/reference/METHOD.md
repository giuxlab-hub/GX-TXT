# Synthetic 2D21 Level-1 v0.1 reference

Source: Giux-Lab, Compact grid-current model of the 2D21 from the GE datasheet.
Article: https://giux-lab.it/2026/09/16/2d21-modello-compatto-corrente-griglia-datasheet-ge/

These are newly generated theoretical curves, not GE observations, digitizations or fitted data. No noise, uncertainty, current interpolation law or derivative continuity is invented. The historical Session is never accessed.

The complete published five-family table is in published_family_parameters.csv. K=0.551; lambda=(0.060,0.240,0.960). Negative Y=-QA+sum(Aj*exp(lambda_j*(Vg-V0)/Sminus)); positive Y=0.005*expm1(K*(Vg-V0)/Splus)/expm1(K). A1..A3 solve Y(0)=0, Y(-1)=-0.010, Y(-U20)=-0.020 in negative normalized coordinates through original Numeric linear algebra. Ig=Ia*Y with explicitly recorded Ia in mA.

For each family, the negative grid is 401 uniform samples on the closed interval V0-U20*Sminus to V0. The positive grid declares301 uniform samples on V0 to V0+3*Splus and excludes its lower endpoint, yielding300 actual samples. Common outer bounds are -3V to0.1V. Every function/branch is published separately with its actual row grid; normalized Y and physical Ig use separate original Plotv4 panels. All five native Workspaces contain full explicit family tables, relations, systems and domains. Their scientific title is family-neutral so changing the selected family cannot leave an obsolete current asserted in the graph title. No raw measurements are present.

Reproduce using this package's generate.tcl with the exact delivered framework and a fresh output root; original public Mathematics/Numeric/Unit Registry/Workspace/Publication/Plotv4 owners perform all scientific work. Dynamic runtime IDs/timestamps may differ; equations, declared inputs and sampled numerical values are deterministic.
