# SPDX-License-Identifier: GPL-3.0-or-later
# Both Dataset Browser menus use this single discovery and invocation projection.
proc ::GX::datasetExportMenuAppend {menu datasetId {requireActive 0}} {
    set actions [datasetExportProviderList $datasetId]
    if {![llength $actions]} return
    set submenu $menu.datasetExports
    if {[winfo exists $submenu]} {destroy $submenu}
    menu $submenu -tearoff 0
    foreach definition $actions {
        $submenu add command -label [dict get $definition label] -command [list ::GX::datasetPageAction datasetExportGuiOpen [dict get $definition module_id] [dict get $definition action_id] $datasetId [dict get $definition source] $requireActive]
    }
    $menu add cascade -label {Export as…} -menu $submenu
}
proc ::GX::_datasetExportGuiCheck {module action datasetId expected requireActive} {
    if {$requireActive && $::GX::variableDatasetChoice ne [datasetInspectionImportedChoice $datasetId]} {error {Active Dataset changed; reopen Dataset Actions}}
    set check [datasetExportProviderCheck $module $action $datasetId]
    if {![dict get $check compatible] || [dict get $check source] ne $expected} {error {Dataset or Session changed; reopen the export action}}
}
proc ::GX::datasetExportGuiOpen {module action datasetId expected requireActive} {
    _datasetExportGuiCheck $module $action $datasetId $expected $requireActive
    set definition [datasetExportProviderDescribe $module $action]
    if {[dict size [dict get $definition fields]]} {
        uiFieldFormCreate .datasetExportOptions "[dict get $definition label] — $datasetId" [dict get $definition fields] {} [list ::GX::datasetExportGuiSave $module $action $datasetId $expected $requireActive] .top
    } else {datasetExportGuiSave $module $action $datasetId $expected $requireActive {}}
}
proc ::GX::datasetExportGuiSave {module action datasetId expected requireActive parameters} {
    _datasetExportGuiCheck $module $action $datasetId $expected $requireActive
    set definition [datasetExportProviderDescribe $module $action]
    set extension [dict get $definition extension]
    set path [workspaceSaveFile export_dir -title "Export Dataset $datasetId — [dict get $definition label]" -initialfile "[sanitize $datasetId]$extension" -defaultextension $extension -filetypes [list [list [string toupper [dict get $definition format]] [list *$extension]]]]
    if {$path eq {}} return
    _datasetExportGuiCheck $module $action $datasetId $expected $requireActive
    set receipt [datasetExportProviderInvoke $module $action $datasetId $path $parameters $expected]
    setStatus "Exported Dataset $datasetId: $path" 100
    return $receipt
}
