# SPDX-License-Identifier: GPL-3.0-or-later
# Host-side presentation drafts reuse the existing graph configuration owners.
# These commands are deliberately not registered as Script Bridge writers.
proc ::GX::_plotProfileFields {section} {
    modulePublicApiActivate plot.dataset PLOT_DATASET_API_v4
    set types [::GX::PlotDatasetAPIv4::renderSettingsFieldTypes $section]
    if {$section eq {graphics}} {
        foreach field {colorbar_label color_unit color_min color_max} {dict unset types $field}
    }
    if {$section eq {legend}} {dict unset types source_override_enabled}
    return $types
}
proc ::GX::_plotProfileValidateValue {section field value} {
    set types [_plotProfileFields $section]
    if {![dict exists $types $field]} {error "Unsupported portable $section field '$field'"}
    if {[string length $value]>256 || [regexp {[\r\n\t]} $value]} {error {Portable values must be bounded single-line data}}
    ::GX::PlotDatasetAPIv4::_renderSettingsValue [dict get $types $field] $value
    if {$value in {{} auto inherit} && [dict get $types $field] in {number boolean}} {return $value}
    if {$section eq {graphics}} {plotVariantGraphicsValidateValue $field $value}
    set enumerations [dict create font_unit {px pt} legend_font_unit {inherit px pt} grid_mode {inherit both vertical horizontal none major minor} \
        legend_placement {inside above below left right manual none} placement {inside above below left right manual none} \
        legend_inside_preset {northeast northwest southeast southwest north south east west center best} inside_preset {northeast northwest southeast southwest north south east west center best} \
        legend_layout {auto row stacked wrapped horizontal vertical grid} layout {auto row stacked wrapped horizontal vertical grid} \
        legend_alignment {start center end left right top bottom} alignment {start center end left right top bottom} projection {orthographic perspective} \
        aspect_mode {auto xy_equal data_equal manual}]
    if {[dict exists $enumerations $field] && $value ni [dict get $enumerations $field]} {error "Invalid $field choice"}
    if {$field in {background legend_background grid_color border_color legend_border_color} && $value ni {{} none transparent auto inherit} && ![regexp {^#[0-9A-Fa-f]{6}$} $value]} {error "Invalid $field color"}
    if {$field eq {colormap} && ![regexp {^[A-Za-z][A-Za-z0-9_]{0,63}$} $value]} {error {Invalid portable colormap name}}
    if {$field in {width_px height_px} && ($value<1 || $value>32768 || int($value)!=$value)} {error {Portable canvas dimensions must be integers in 1..32768}}
    if {$field eq {dpi} && ($value<72 || $value>1200 || int($value)!=$value)} {error {Portable DPI must be an integer in 72..1200}}
    if {$field in {columns legend_columns} && ($value<1 || $value>64 || int($value)!=$value)} {error {Legend columns must be an integer in 1..64}}
    if {$field in {manual_x manual_y} && ($value<0 || $value>1)} {error {Manual legend coordinates must be in 0..1}}
    if {[string match layout_margin_* $field] && ($value<0 || $value>30)} {error {Layout margins must be in 0..30 percent}}
    return $value
}
proc ::GX::plotPresentationProfileValidate {profile} {
    foreach key [dict keys $profile] {if {$key ni {schema version dimension settings series}} {error "Unknown portable profile field '$key'"}}
    if {[dict get $profile schema] ne {PLOT_PRESENTATION_PROFILE_v1} || [dict get $profile version] ne {1} || [dict get $profile dimension] ni {2 3}} {error {Unsupported presentation profile}}
    dict for {section values} [dict get $profile settings] {
        if {$section ni {graphics legend layout}} {error "Unsupported portable section '$section'"}
        dict for {field value} $values {_plotProfileValidateValue $section $field $value}
    }
    set graphics [datasetPublicationV2DictDefault [dict get $profile settings] graphics {}]
    if {[dict exists $graphics aspect_mode]} {plot3dAspectValidate [dict get $graphics aspect_mode] [datasetPublicationV2DictDefault $graphics aspect_ratio {}] 0}
    set series [datasetPublicationV2DictDefault $profile series {}]
    if {[llength $series]>256} {error {Presentation profile supports at most256 series styles}}
    set positions {}
    foreach record $series {
        foreach field [dict keys $record] {if {$field ni {panel_index series_index panel_count series_count kind axis style}} {error {Unknown series-style metadata}}}
        foreach field {panel_index series_index panel_count series_count} {set n [dict get $record $field];if {![string is integer -strict $n] || $n<0 || $n>512} {error {Series-style positions/counts must be bounded integers}}}
        if {[dict get $record panel_count]<1 || [dict get $record series_count]<1 || [dict get $record panel_index]>=[dict get $record panel_count] || [dict get $record series_index]>=[dict get $record series_count]} {error {Series-style position is outside declared topology}}
        set position [list [dict get $record panel_index] [dict get $record series_index]]
        if {$position in $positions} {error {Duplicate series-style position}};lappend positions $position
        if {[dict get $record axis] ni {left right} || ![regexp {^[a-z][a-z0-9_]{0,40}$} [dict get $record kind]]} {error {Invalid series-style kind/axis}}
        dict for {field value} [dict get $record style] {_plotProfileValidateValue style $field $value}
        modulePublicApiActivate plot.dataset PLOT_DATASET_API_v2
        ::GX::PlotDatasetAPIv2::_validateStyle [dict get $record style] {Portable series}
    }
    # One effective legend owner appears in a draft. Older profiles containing
    # duplicate graphics legend defaults normalize to their explicit legend.
    dict for {graphicsField legendField} [_plotProfileLegendMap] {
        if {[dict exists $profile settings legend $legendField] && [dict exists $profile settings graphics $graphicsField]} {dict unset profile settings graphics $graphicsField}
    }
    return $profile
}
proc ::GX::_plotProfileLegendMap {} {return {legend_placement placement legend_inside_preset inside_preset legend_layout layout legend_alignment alignment legend_columns columns legend_font_unit font_unit legend_font_size font_size legend_background background legend_border border legend_border_color border_color legend_margin_px margin_px}}
proc ::GX::plotPresentationProfileEncode {profile} {
    set profile [plotPresentationProfileValidate $profile]
    set sections {}
    dict for {section values} [dict get $profile settings] {
        set types [_plotProfileFields $section];set fields {}
        dict for {field value} $values {dict set fields $field [::GX::PlotDatasetAPIv4::_renderSettingsValue [dict get $types $field] $value]}
        dict set sections $section [list object $fields]
    }
    set result [dict create schema {text PLOT_PRESENTATION_PROFILE_v1} version {int 1} dimension [list int [dict get $profile dimension]] settings [list object $sections]]
    if {[dict exists $profile series]} {
        set records {}
        foreach record [dict get $profile series] {
            set fields {};foreach field {panel_index series_index panel_count series_count} {dict set fields $field [list int [dict get $record $field]]}
            foreach field {kind axis} {dict set fields $field [list text [dict get $record $field]]}
            set style {};dict for {field value} [dict get $record style] {dict set style $field [::GX::PlotDatasetAPIv4::_renderSettingsValue [dict get [_plotProfileFields style] $field] $value]}
            dict set fields style [list object $style];lappend records [list object $fields]
        }
        dict set result series [list array $records]
    }
    return [list object $result]
}
proc ::GX::plotPresentationProfileFromSnapshot {reference} {
    set result [plotRenderSettingsRead $reference]
    if {[dict get $result status] ne {available}} {error "Last rendered settings are [dict get $result status]; a complete transferable profile is unavailable"}
    set presentation [dict get $result snapshot presentation];set sections {};set omitted {}
    foreach section {graphics legend layout} {
        set values [datasetPublicationV2DictDefault [dict get $presentation settings] $section {}];set accepted {}
        dict for {field value} $values {
            if {![dict exists [_plotProfileFields $section] $field]} {lappend omitted $section.$field;continue}
            if {$section eq {graphics} && [dict get $presentation dimension]==2 && $field in {view_azimuth view_elevation projection aspect_mode aspect_ratio colormap colorbar_visible}} continue
            # Automatic empty physical text sizes remain a documented inherit
            # policy; never substitute another renderer's guessed fallback.
            if {$value eq {auto} && $field in {axis_label_font_size title_font_size}} {set value {}}
            _plotProfileValidateValue $section $field $value
            dict set accepted $field $value
        }
        dict set sections $section $accepted
    }
    set profile [dict create schema PLOT_PRESENTATION_PROFILE_v1 version 1 dimension [dict get $presentation dimension] settings $sections]
    set styles [datasetPublicationV2DictDefault [dict get $presentation settings] series_presentations {}]
    if {[dict exists $presentation settings panels] && [dict get $presentation dimension]==2} {
        set panels [dict get $presentation settings panels];set pi 0
        foreach panel $panels {
            set traces [dict get $panel series];set si 0
            foreach trace $traces {lappend styles [dict create panel_index $pi series_index $si panel_count [llength $panels] series_count [llength $traces] kind [dict get $trace kind] axis [dict get $trace axis] style [dict get $trace style]];incr si}
            incr pi
        }
    }
    set admitted {}
    foreach record $styles {
        set style {};dict for {field value} [dict get $record style] {
            modulePublicApiActivate plot.dataset PLOT_DATASET_API_v2
            if {$field ni $::GX::PlotDatasetAPIv2::styleFields} {lappend omitted series.[dict get $record panel_index].[dict get $record series_index].$field;continue}
            dict set style $field $value
        }
        dict set record style $style;lappend admitted $record
    }
    if {[llength $admitted]} {dict set profile series $admitted} else {lappend omitted {series styles: no exact logical producer receipt}}
    lappend omitted {numeric axes: use the original compatible-unit Axes editor}
    return [dict create profile [plotPresentationProfileValidate $profile] omitted $omitted \
        scope {presentation_only; target Dataset, series, formulas, title, semantic labels and numeric axes remain owned by their original editors}]
}
proc ::GX::plotPresentationProfileReadFile {path} {
    if {![file isfile $path] || [file size $path]>65536} {error {Presentation profile must be a regular JSON file of at most 64 KiB}}
    set stream [open $path r]
    try {fconfigure $stream -encoding utf-8;set typed [nativeWorkspaceJsonDecode [read $stream 65537]]} finally {close $stream}
    return [plotPresentationProfileDecode $typed]
}
proc ::GX::plotPresentationProfileDecode {typed} {
    if {[lindex $typed 0] ne {object}} {error {Presentation profile must be a typed object}}
    set nodes [lindex $typed 1]
    foreach {key type} {schema text version int dimension int settings object} {if {[lindex [dict get $nodes $key] 0] ne $type} {error "Invalid profile $key type"}}
    dict for {section node} [lindex [dict get $nodes settings] 1] {
        if {[lindex $node 0] ne {object}} {error {Profile sections must be typed objects}}
        set types [_plotProfileFields $section]
        dict for {field value} [lindex $node 1] {
            if {![dict exists $types $field]} {error "Unsupported profile property '$field'"}
            set allowed [dict get [dict create text {text} number {real int text} boolean {bool text}] [dict get $types $field]]
            if {[lindex $value 0] ni $allowed} {error "Invalid profile property type '$field'"}
        }
    }
    if {[dict exists $nodes series]} {
        set series [dict get $nodes series];if {[lindex $series 0] ne {array}} {error {Profile series must be a typed array}}
        foreach node [lindex $series 1] {
            if {[lindex $node 0] ne {object}} {error {Profile series records must be objects}}
            set fields [lindex $node 1]
            foreach {field type} {panel_index int series_index int panel_count int series_count int kind text axis text style object} {if {[lindex [dict get $fields $field] 0] ne $type} {error "Invalid series-style $field type"}}
            dict for {field value} [lindex [dict get $fields style] 1] {
                set types [_plotProfileFields style]
                if {![dict exists $types $field]} {error {Unknown series style field}}
                set allowed [dict get [dict create text {text} number {real int text}] [dict get $types $field]]
                if {[lindex $value 0] ni $allowed} {error {Invalid series-style value type}}
            }
        }
    }
    return [plotPresentationProfileValidate [nativeWorkspaceDecode $typed]]
}
proc ::GX::plotPresentationProfileExport {profile path} {
    set json [nativeWorkspaceJsonEncode [plotPresentationProfileEncode $profile]]
    if {[string bytelength $json]>65536} {error {Presentation profile exceeds 64 KiB}}
    return [filePublicationPublishBundle [list [dict create id profile destination $path writer [list ::GX::_plotRenderSettingsWrite $json]]]]
}
proc ::GX::_plotPresetPath {} {return [file join [sessionInspectionCurrentSession] metadata plot_presentation_presets.json]}
proc ::GX::plotPresentationPresets {} {
    set path [_plotPresetPath]
    if {![file isfile $path]} {return {}}
    if {[file size $path]>1048576} {error {Session preset collection exceeds 1 MiB}}
    set stream [open $path r]
    try {fconfigure $stream -encoding utf-8;set typed [nativeWorkspaceJsonDecode [read $stream 1048577]]} finally {close $stream}
    if {[lindex $typed 0] ne {object}} {error {Invalid Session presets}}
    set fields [lindex $typed 1];set result {}
    if {[dict size $fields]>64} {error {At most 64 named Session presets are supported}}
    dict for {name profile} $fields {
        if {[string trim $name] eq {} || [string length $name]>72 || ![string is print -strict $name]} {error {Invalid stored Session preset name}}
        dict set result $name [plotPresentationProfileDecode $profile]
    }
    return $result
}
proc ::GX::plotPresentationPresetSave {name profile} {
    if {[string trim $name] eq {} || [string length $name]>72 || ![string is print -strict $name]} {error {Preset name must contain 1..72 printable characters}}
    plotPresentationProfileValidate $profile
    set profiles [plotPresentationPresets];dict set profiles $name $profile
    if {[dict size $profiles]>64} {error {At most 64 named Session presets are supported}}
    return [_plotPresentationPresetsWrite $profiles]
}
proc ::GX::plotPresentationPresetDelete {name} {
    set profiles [plotPresentationPresets];dict unset profiles $name
    return [_plotPresentationPresetsWrite $profiles]
}
proc ::GX::_plotPresentationPresetsWrite {profiles} {
    set fields {};dict for {name profile} $profiles {dict set fields $name [plotPresentationProfileEncode $profile]}
    set json [nativeWorkspaceJsonEncode [list object $fields]]
    if {[string bytelength $json]>1048576} {error {Session preset collection exceeds 1 MiB}}
    return [filePublicationPublishBundle [list [dict create id presets destination [_plotPresetPath] writer [list ::GX::_plotRenderSettingsWrite $json]]] replace]
}

proc ::GX::plotPresentationApplyPlan {reference profile} {
    set reference [graphResourceRef $reference];set profile [plotPresentationProfileValidate $profile]
    set skipped {};set sections [dict get $profile settings]
    if {[dict get $reference kind] eq {clone}} {
        set path [_plotRenderSettingsArtifact $reference];set clone [::GX::PlotClone::infoForPath $path]
        if {[dict get $clone clone.capture_mode] ne {scientific}} {error {Rendered-only Clone presentation cannot be edited}}
        set values {}
        foreach section {graphics layout} {
            dict for {field value} [datasetPublicationV2DictDefault $sections $section {}] {
                if {$field in {width_px height_px line_width marker_size layout_auto layout_margin_left layout_margin_right layout_margin_top layout_margin_bottom layout_gap layout_ylabel_dist}} {dict set values $field $value} else {lappend skipped $section.$field}
            }
        }
        if {[dict exists $sections legend placement]} {dict set values legend_placement [dict get $sections legend placement]}
        dict for {field value} [datasetPublicationV2DictDefault $sections legend {}] {if {$field ne {placement}} {lappend skipped legend.$field}}
        if {[llength [datasetPublicationV2DictDefault $profile series {}]]} {lappend skipped {series styles: original Clone editor supports common strokes only}}
        return [dict create reference $reference clone_values $values skipped $skipped profile $profile]
    }
    if {[dict get $reference module_id] ne {plot.dataset}} {error {Presentation profiles require a scientific Plot Dataset graph}}
    set dimension [expr {[dict get $reference graph_id] eq {plot.dataset.xyz}?3:2}]
    if {$dimension==2} {
        foreach field {view_azimuth view_elevation projection aspect_mode aspect_ratio colormap colorbar_visible} {
            if {[dict exists $sections graphics $field]} {dict unset sections graphics $field;lappend skipped graphics.$field}
        }
    }
    # Only presentation fields reach configuration owners. Numeric axes require
    # a separate explicit compatible-unit editor; this contract never guesses
    # axes units from captions or changes target scientific identities.
    set seriesPlan [_plotProfileSeriesPlan $reference [datasetPublicationV2DictDefault $profile series {}]]
    set skipped [concat $skipped [dict get $seriesPlan skipped]]
    return [dict create reference $reference sections $sections skipped $skipped profile $profile series_plan $seriesPlan]
}
proc ::GX::plotPresentationApply {reference profile} {
    set plan [plotPresentationApplyPlan $reference $profile];set reference [dict get $plan reference]
    if {[dict get $reference kind] eq {clone}} {
        ::GX::PlotClone::setPresentation [_plotRenderSettingsArtifact $reference] [dict get $plan clone_values]
        return $plan
    }
    set key [graphAxisAddress [dict get $reference module_id] [dict get $reference graph_id] [dict get $reference variant_id]]
    axisOverrideEnsure $key {};legendOverrideEnsure $key
    set axisBefore [array get ::GX::axisOverride "$key,*"];set legendBefore [array get ::GX::legendOverride "$key,*"]
    set seriesPlan [dict get $plan series_plan];set specChanged 0
    try {
        if {[dict get $seriesPlan changed]} {_plotProfileSaveSpec $reference [dict get $seriesPlan after];set specChanged 1}
        set axisFields {};foreach {field default} [plot3dAxisFieldDefaults] {lappend axisFields $field}
        dict for {section values} [dict get $plan sections] {
            dict for {field value} $values {
                switch -- $section {
                    graphics {
                        set ::GX::axisOverride($key,graphics_$field) $value
                        # These original per-axis settings are the same scope.
                        # Keep their existing editor and finalizer consistent.
                        if {$field in $axisFields} {set ::GX::axisOverride($key,$field) $value}
                    }
                    layout {set ::GX::axisOverride($key,$field) $value}
                    legend {
                        set name $field
                        switch -- $field {inside_preset {set name location} margin_px {set name external_margin_px}}
                        set ::GX::legendOverride($key,$name) $value
                        set ::GX::legendOverride($key,enabled) 1
                    }
                }
            }
        }
        writeAxisOverrideFile;sessionPersistenceCommit
    } on error {message options} {
        if {$specChanged} {catch {_plotProfileSaveSpec $reference [dict get $seriesPlan before]}}
        array unset ::GX::axisOverride "$key,*";array set ::GX::axisOverride $axisBefore
        array unset ::GX::legendOverride "$key,*";array set ::GX::legendOverride $legendBefore
        return -options $options $message
    }
    return $plan
}

# Extend the existing per-plot Axes presentation owner; no independent PlotSpec
# or global defaults store is created. Original Session manifest owns persistence.
rename ::GX::manifestStringV2 ::GX::manifestStringV2_before_plot_presentation
proc ::GX::manifestStringV2 {} {
    set text [manifestStringV2_before_plot_presentation];set index 0
    set keys {};foreach item [array names ::GX::axisOverride *,graphics_*] {lappend keys [string range $item 0 [expr {[string last , $item]-1}]]}
    foreach key [lsort -unique $keys] {
        append text "\n\[plot.presentation.[incr index]\]\n";appendKV text graph_key $key
        foreach item [lsort [array names ::GX::axisOverride "$key,graphics_*"]] {appendKV text [string range $item [string length "$key,graphics_"] end] $::GX::axisOverride($item)}
    }
    return $text
}
rename ::GX::loadManifestV2 ::GX::loadManifestV2_before_plot_presentation
proc ::GX::loadManifestV2 {path} {
    loadManifestV2_before_plot_presentation $path
    set data [parseIni $path]
    foreach field [dict keys $data plot.presentation.*.graph_key] {
        set key [dict get $data $field]
        if {![regexp {^plot[.]dataset[.](xy|xy_region|xyz)([.]p[0-9]+)?$} $key]} continue
        set prefix [string range $field 0 end-9]
        foreach property [dict keys $data $prefix*] {
            set name [string range $property [string length $prefix] end]
            if {$name eq {graph_key}} continue
            if {[catch {_plotProfileValidateValue graphics $name [dict get $data $property]}]} continue
            set ::GX::axisOverride($key,graphics_$name) [dict get $data $property]
        }
    }
}

proc ::GX::_plotProfileSaveSpec {reference spec} {
    if {[::GX::PlotDatasetAPIv4::isOwned $reference]} {return [::GX::PlotDatasetAPIv4::saveSpec $reference $spec]}
    modulePublicApiActivate plot.dataset PLOT_DATASET_API_v3
    return [::GX::PlotDatasetAPIv3::saveSpec $reference $spec]
}
proc ::GX::_plotProfileSeriesPlan {reference records} {
    set result [dict create changed 0 skipped {} mapping {}]
    if {![llength $records]} {return $result}
    if {[dict get $reference graph_id] ne {plot.dataset.xy}} {dict set result skipped [list {series styles: this target graph has no compatible ordinary 2D topology}];return $result}
    set spec [::GX::PlotDatasetAPIv4::loadSpec $reference];set before $spec
    set panels [dict get $spec panels]
    foreach record $records {
        set pi [dict get $record panel_index];set si [dict get $record series_index]
        if {[llength $panels]!=[dict get $record panel_count] || $pi>=[llength $panels]} {dict lappend result skipped "series $pi/$si: panel count mismatch";continue}
        set panel [lindex $panels $pi];set series [dict get $panel series]
        if {[llength $series]!=[dict get $record series_count] || $si>=[llength $series]} {dict lappend result skipped "series $pi/$si: series count mismatch";continue}
        set trace [lindex $series $si];set kind [datasetPublicationV2DictDefault $trace kind auto]
        if {$kind eq {auto}} {set kind [::GX::PlotDatasetAPIv1::getConfig $reference plot_style];if {$kind in {auto inherit {}}} {set kind line};if {$kind eq {line_markers}} {set kind line_marker}}
        if {$kind ne [dict get $record kind] || [dict get $trace axis] ne [dict get $record axis] || [dict exists $trace family_variable_id]} {dict lappend result skipped "series $pi/$si: kind/axis/family topology incompatible";continue}
        set style [datasetPublicationV2DictDefault $trace style {}]
        dict for {field value} [dict get $record style] {dict set style $field $value}
        dict set trace style $style;lset series $si $trace;dict set panel series $series;lset panels $pi $panel
        dict lappend result mapping "panel [expr {$pi+1}], series [expr {$si+1}] -> [dict get $trace id] ($kind/[dict get $trace axis])"
        dict set result changed 1
    }
    dict set spec panels $panels
    ::GX::PlotDatasetAPIv4::validateSpec $spec
    dict set result before $before;dict set result after $spec
    return $result
}
