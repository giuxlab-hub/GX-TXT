# SPDX-License-Identifier: GPL-3.0-or-later
# Evidence of completed renders, distinct from mutable scientific PlotSpecs.
proc ::GX::plotRenderSettingsApiInfo {} {
    return [dict create api_id PLOT_RENDER_SETTINGS_API_v1 api_version 1 operations {info status read} schemas {PLOT_RENDER_SETTINGS_SNAPSHOT_v1 PLOT_CLONE_RENDER_SETTINGS_v1} statuses {available absent_legacy partial unsupported stale/output_mismatch} authority last_successful_render script_bridge read_only]
}
proc ::GX::plotRenderSettingsInfoJson {} {
    return [nativeWorkspaceJsonEncode [nativeWorkspaceEncode {record {api_id text api_version int operations {array text} schemas {array text} statuses {array text} authority text script_bridge text}} [plotRenderSettingsApiInfo]]]
}
proc ::GX::_plotRenderSettingsArtifact {reference} {
    set reference [graphResourceRef $reference]
    if {$::GX::currentSession eq {} || ![file isdirectory $::GX::currentSession]} {error {Open a Session before reading plot settings}}
    if {[dict get $reference kind] eq {clone}} {return [file join [::GX::PlotClone::root] [dict get $reference clone_id] graph.png]}
    return [graphAxisArtifactPath [dict get $reference module_id] [dict get $reference graph_id] [dict get $reference variant_id]]
}
proc ::GX::_plotRenderSettingsReadTyped {reference} {
    set reference [graphResourceRef $reference];set output [_plotRenderSettingsArtifact $reference]
    set result [dict create api_id PLOT_RENDER_SETTINGS_API_v1 reference $reference status absent_legacy snapshot {null {}}]
    if {[dict get $reference kind] eq {provider} && [dict get $reference module_id] ne {plot.dataset}} {dict set result status unsupported;return $result}
    set path $output.render-settings.json
    if {![file isfile $path]} {return $result}
    if {[file size $path]>2097152} {dict set result status partial;dict set result reason oversized_manifest;return $result}
    if {[catch {
        set stream [open $path r]
        try {fconfigure $stream -encoding utf-8;set json [read $stream 2097153]} finally {close $stream}
        set typed [nativeWorkspaceJsonDecode $json]
        if {[lindex $typed 0] ne {object}} {error {Manifest must be an object}}
        set nodes [lindex $typed 1]
        set snapshot [nativeWorkspaceDecode $typed]
        set schema [expr {[dict get $reference kind] eq {clone}?{PLOT_CLONE_RENDER_SETTINGS_v1}:{PLOT_RENDER_SETTINGS_SNAPSHOT_v1}}]
        foreach key {schema version} {if {![dict exists $snapshot $key]} {error "Missing manifest field $key"}}
        if {[lindex [dict get $nodes schema] 0] ne {text} || [lindex [dict get $nodes version] 0] ne {int}} {error {Invalid schema field types}}
        set supported [expr {[dict get $snapshot schema] eq $schema && [dict get $snapshot version]==1}]
        if {$supported} {
            foreach key {reference renderer_api backend rendered_at revision render_status output presentation completeness verification} {if {![dict exists $snapshot $key]} {error "Missing manifest field $key"}}
            foreach key {reference output presentation verification} {if {[lindex [dict get $nodes $key] 0] ne {object}} {error "Manifest $key must be a typed object"}}
            foreach key {renderer_api backend rendered_at revision render_status completeness} {if {[lindex [dict get $nodes $key] 0] ne {text}} {error "Manifest $key must be typed text"}}
            foreach key {filename sha256} {if {[lindex [dict get [lindex [dict get $nodes output] 1] $key] 0] ne {text}} {error {Invalid output identity field types}}}
            if {[lindex [dict get [lindex [dict get $nodes output] 1] byte_count] 0] ne {int}} {error {Invalid output byte count type}}
            if {[dict exists $nodes renderer_extensions] && [lindex [dict get $nodes renderer_extensions] 0] ne {object}} {error {Renderer extensions must be a typed object}}
            if {[graphResourceRef [dict get $snapshot reference]] ne $reference} {error {Manifest graph identity mismatch}}
            if {[dict get $snapshot output filename] ne [file tail $output] || ![regexp {^[0-9a-f]{64}$} [dict get $snapshot output sha256]]} {error {Invalid render output identity}}
            if {![dict exists $snapshot output byte_count] || ![string is entier -strict [dict get $snapshot output byte_count]] || [dict get $snapshot output byte_count]<1} {error {Invalid render output byte count}}
            if {[dict get $snapshot render_status] ne {success}} {error {Snapshot is not a successful render}}
            if {[dict get $snapshot completeness] ni {available partial unsupported}} {error {Invalid snapshot completeness}}
        }
    } failure]} {dict set result status partial;dict set result reason invalid_manifest;return $result}
    if {!$supported} {dict set result status unsupported;return $result}
    if {![file isfile $output] || [file size $output]!=[dict get $snapshot output byte_count] || [sha256File $output] ne [dict get $snapshot output sha256]} {
        dict set result status stale/output_mismatch;dict set result reason output_identity_changed
    } else {dict set result status [dict get $snapshot completeness]}
    dict set result snapshot $typed
    return $result
}
proc ::GX::plotRenderSettingsStatus {reference} {
    return [dict remove [_plotRenderSettingsReadTyped $reference] snapshot]
}
proc ::GX::plotRenderSettingsRead {reference} {
    set result [_plotRenderSettingsReadTyped $reference]
    dict set result snapshot [nativeWorkspaceDecode [dict get $result snapshot]]
    return $result
}
proc ::GX::_plotRenderSettingsResultJson {reference includeSnapshot} {
    set result [_plotRenderSettingsReadTyped $reference];set fields {}
    foreach key {api_id status reason} {if {[dict exists $result $key]} {dict set fields $key [list text [dict get $result $key]]}}
    dict set fields reference [nativeWorkspaceEncode {map text} [dict get $result reference]]
    if {$includeSnapshot} {dict set fields snapshot [dict get $result snapshot]}
    return [nativeWorkspaceJsonEncode [list object $fields]]
}
proc ::GX::plotRenderSettingsStatusJson {reference} {return [_plotRenderSettingsResultJson $reference 0]}
proc ::GX::plotRenderSettingsReadJson {reference} {return [_plotRenderSettingsResultJson $reference 1]}
proc ::GX::plotRenderSettingsBuild {reference renderer backend presentation png {completeness available} {extensions {object {}}}} {
    set reference [graphResourceRef $reference]
    return [_plotRenderSettingsBuildForOutput $reference [_plotRenderSettingsArtifact $reference] $renderer $backend $presentation $png $completeness $extensions]
}
# Trusted renderer workers already carry their original output/reference. This
# internal path avoids opening or rewriting a Session in a helper interpreter.
proc ::GX::_plotRenderSettingsBuildForOutput {reference output renderer backend presentation png completeness extensions} {
    if {![file isfile $png] || [file size $png]<1} {error {Completed render artifact is unavailable}}
    if {$completeness ni {available partial unsupported} || [lindex $presentation 0] ne {object} || [lindex $extensions 0] ne {object}} {error {Invalid typed render presentation}}
    # Validate the complete inert typed tree through the existing JSON owner.
    set serialized [nativeWorkspaceJsonEncode $presentation]
    if {[string bytelength $serialized]>1048576} {error {Render presentation exceeds 1 MiB}}
    set schema [expr {[dict get $reference kind] eq {clone} ?
        {PLOT_CLONE_RENDER_SETTINGS_v1} : {PLOT_RENDER_SETTINGS_SNAPSHOT_v1}}]
    set outputIdentity [dict create filename [file tail $output] sha256 [sha256File $png] byte_count [file size $png]]
    set verification {settings renderer_submitted_or_receipted pixels not_independently_verified}
    set fields [dict create \
        schema [list text $schema] version {int 1} \
        reference [nativeWorkspaceEncode {map text} $reference] \
        renderer_api [list text $renderer] backend [list text $backend] \
        rendered_at [list text [clock format [clock seconds] -gmt 1 -format {%Y-%m-%dT%H:%M:%SZ}]] \
        revision [list text "render-[pid]-[clock clicks]"] render_status {text success} \
        output [nativeWorkspaceEncode {record {filename text sha256 text byte_count int}} $outputIdentity] \
        presentation $presentation renderer_extensions $extensions \
        completeness [list text $completeness] \
        verification [nativeWorkspaceEncode {record {settings text pixels text}} $verification]]
    set result [list object $fields]
    if {[string bytelength [nativeWorkspaceJsonEncode $result]]>2097152} {error {Render settings snapshot exceeds 2 MiB}}
    return $result
}
proc ::GX::plotRenderSettingsPublish {reference png presentation renderer backend {extraArtifacts {}} {extensions {object {}}} {completeness available}} {
    set output [_plotRenderSettingsArtifact $reference]
    set manifest [plotRenderSettingsBuild $reference $renderer $backend $presentation $png $completeness $extensions]
    set json [nativeWorkspaceJsonEncode $manifest]
    set artifacts [list [dict create id png destination $output writer [list ::GX::_filePublicationCopyWriter $png [sha256File $png]]] [dict create id render_settings destination $output.render-settings.json writer [list ::GX::_plotRenderSettingsWrite $json]]]
    foreach artifact $extraArtifacts {lappend artifacts $artifact}
    return [filePublicationPublishBundle $artifacts replace {create_parents 1}]
}
proc ::GX::_plotRenderSettingsWrite {json channel context} {puts -nonewline $channel [encoding convertto utf-8 $json]}

# Clone capture consumes either its own exact producer receipt, or a verified
# source record for byte-identical rendered fallback. Missing legacy evidence
# remains missing; scientific caches are never reverse engineered here.
proc ::GX::_plotRenderSettingsCloneBuild {id output png mode producer {source {}}} {
    if {![regexp {^c[0-9]{6}$} $id] || $mode ni {scientific rendered}} {error {Invalid Clone render identity}}
    set presentation {};set provenance {};set completeness partial
    if {[file isfile $producer]} {
        if {[file size $producer]>2097152} {error {Clone producer receipt exceeds 2 MiB}}
        set stream [open $producer r]
        try {fconfigure $stream -encoding utf-8;set typed [nativeWorkspaceJsonDecode [read $stream 2097153]]} finally {close $stream}
        set receipt [nativeWorkspaceDecode $typed]
        if {[dict get $receipt schema] ne {PLOT_RENDER_PRODUCER_RECEIPT_v1} || [dict get $receipt version]!=1 || [dict get $receipt png_sha256] ne [sha256File $png]} {error {Clone producer receipt does not match completed PNG}}
        set presentation [dict get [lindex $typed 1] presentation]
        set renderer [dict get $receipt renderer_api];set backend [dict get $receipt backend]
        set completeness [expr {[dict exists $receipt completeness]?[dict get $receipt completeness]:{available}}]
        dict set provenance settings_origin {text clone_owned_producer_receipt}
    } elseif {$source ne {} && ![catch {
        set reference [graphResourceRefForPath $source]
        set result [_plotRenderSettingsReadTyped $reference]
        set snapshot [dict get $result snapshot];set values [nativeWorkspaceDecode $snapshot]
        if {[dict get $result status] ni {available partial} || [dict get $values output sha256] ne [sha256File $png]} {error {No byte-identical verified source render}}
        set presentation [dict get [lindex $snapshot 1] presentation]
        set renderer [dict get $values renderer_api];set backend [dict get $values backend]
        dict set provenance source_reference [nativeWorkspaceEncode {map text} $reference]
        dict set provenance source_revision [list text [dict get $values revision]]
        dict set provenance settings_origin {text verified_byte_identical_source_render}
    }]} {
        # Rendered fallback preserves verified evidence, with explicit limited
        # editability. It does not become a scientific PlotSpec by copying JSON.
        set completeness partial
    }
    if {$presentation eq {}} {return {}}
    dict set provenance capture_mode [list text $mode]
    dict set provenance scientific_editable [list bool [expr {$mode eq {scientific}}]]
    dict set provenance source_png_sha256 [list text [sha256File $png]]
    return [_plotRenderSettingsBuildForOutput [dict create kind clone clone_id $id] $output $renderer $backend $presentation $png $completeness [list object [dict create clone [list object $provenance]]]]
}
