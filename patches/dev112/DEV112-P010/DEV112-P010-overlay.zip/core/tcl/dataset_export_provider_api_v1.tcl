# SPDX-License-Identifier: GPL-3.0-or-later
# Metadata-only discovery over the existing Module and Canonical Dataset owners.
proc ::GX::datasetExportProviderApiInfo {} {
    return [dict create api_id DATASET_EXPORT_PROVIDER_API_v1 api_version 1 operations {list describe check invoke} discovery metadata_only output_policy create_only script_bridge 0 declaration dataset_exports]
}
proc ::GX::_datasetExportIdentifier {value} {
    expr {[string length $value]<=128 && [regexp {^[A-Za-z][A-Za-z0-9_.-]*$} $value]}
}
proc ::GX::_datasetExportDeclarations {} {
    variable moduleOrder
    set result {}
    foreach module $moduleOrder {
        if {![moduleIsEnabled $module]} continue
        set path [moduleField $module descriptor {}]
        if {$path eq {} || ![file isfile $path]} continue
        set data [parseIni $path]
        set actions [splitList [descriptorValue $data dataset_exports ids {}]]
        if {$actions eq {}} continue
        if {[descriptorValue $data dataset_exports api_version {}] ne {1} || [llength $actions]>32} continue
        foreach action $actions {
            # A malformed/unavailable provider cannot break ordinary browsing.
            if {[catch {
                if {![_datasetExportIdentifier $action]} {error {Invalid export action}}
                set section dataset_export.$action
                set record [dict create module_id $module action_id $action provider_version [moduleField $module version {}]]
                foreach key {label format extension public_api command} {
                    set value [descriptorValue $data $section $key {}]
                    if {$value eq {} || [string length $value]>256} {error {Missing export declaration}}
                    dict set record $key $value
                }
                if {![_datasetExportIdentifier [dict get $record format]] || ![regexp {^\.[A-Za-z0-9]{1,16}$} [dict get $record extension]] || ![regexp {^::[A-Za-z_][A-Za-z0-9_:]*$} [dict get $record command]]} {error {Invalid export contract}}
                set api [dict get $record public_api]
                if {$api ni [splitList [descriptorValue $data public_apis ids {}]]} {error {Undeclared exporter API}}
                set root [file normalize [file dirname $path]]
                set entry [file normalize [file join $root [descriptorValue $data public_api.$api entrypoint {}]]]
                if {[string first $root/ $entry] != 0 || ![file isfile $entry]} {error {Exporter unavailable}}
                set contracts {}
                foreach contract [splitList [descriptorValue $data $section contracts {}]] {
                    if {![_datasetExportIdentifier $contract]} {error {Invalid contract identity}}
                    set spec {}
                    foreach key {versions formats legacy_format_versions requirements} {
                        dict set spec $key [descriptorValue $data $section.contract.$contract $key {}]
                    }
                    dict set spec versions [splitList [dict get $spec versions]]
                    dict set spec formats [splitList [dict get $spec formats]]
                    if {![llength [dict get $spec versions]] || [catch {dict size [dict get $spec legacy_format_versions]}] || [catch {dict size [dict get $spec requirements]}]} {error {Invalid contract compatibility}}
                    dict for {field accepted} [dict get $spec requirements] {
                        if {![_datasetExportIdentifier $field] || [llength $accepted]<1 || [llength $accepted]>128} {error {Invalid bounded capability value list}}
                    }
                    dict for {format version} [dict get $spec legacy_format_versions] {
                        if {![_datasetExportIdentifier $format] || $version ni [dict get $spec versions]} {error {Invalid legacy format schema declaration}}
                    }
                    dict set contracts $contract $spec
                }
                if {![dict size $contracts]} {error {No compatible contracts}}
                dict set record contracts $contracts
                set fields {}
                foreach key [splitList [descriptorValue $data $section parameters {}]] {
                    if {![_datasetExportIdentifier $key] || [dict size $fields]>=32} {error {Invalid bounded export parameter}}
                    set field {}
                    foreach {name default} {type string label {} default {} required 0 min {} max {} values {}} {
                        set value [descriptorValue $data $section.parameter.$key $name $default]
                        if {$name eq {values}} {set value [splitList $value]}
                        if {$value ne {}} {dict set field $name $value}
                    }
                    if {[dict get $field type] ni {string integer double number boolean choice}} {error {Unsupported export parameter type}}
                    dict set fields $key $field
                }
                dict set record fields $fields
            }]} continue
            lappend result $record
        }
    }
    return $result
}
proc ::GX::datasetExportProviderDescribe {module action} {
    foreach record [_datasetExportDeclarations] {
        if {[dict get $record module_id] eq $module && [dict get $record action_id] eq $action} {return $record}
    }
    error {Dataset exporter is disabled, unavailable or unsupported}
}
proc ::GX::_datasetExportSource {datasetId} {
    variable currentSession
    if {$currentSession eq {}} {error {Open a Session before exporting a Dataset}}
    set token [interactiveDocumentSessionToken]
    loadDatasetRegistry $currentSession
    if {$datasetId ni [datasetRegistryIds]} {error {Canonical Dataset is unavailable}}
    set result [dict create session_token $token dataset_id $datasetId]
    foreach key {contract format contract_schema_version canonical_sha256 sha256 source_module updated_at} {
        dict set result $key [datasetField $datasetId $key {}]
    }
    return $result
}
proc ::GX::_datasetExportCompatibility {definition source} {
    set contract [dict get $source contract]
    if {![dict exists $definition contracts $contract]} {return [dict create compatible 0 reason contract]}
    set spec [dict get $definition contracts $contract];set format [dict get $source format]
    if {[dict get $spec formats] ne {} && $format ni [dict get $spec formats]} {return [dict create compatible 0 reason format]}
    set version [dict get $source contract_schema_version]
    # Legacy mappings are explicit provider declarations for a public format
    # whose contract already fixes its schema. Never inspect/guess file content.
    if {$version eq {} && [dict exists $spec legacy_format_versions $format]} {set version [dict get $spec legacy_format_versions $format]}
    if {$version ni [dict get $spec versions]} {return [dict create compatible 0 reason schema_version]}
    dict for {key accepted} [dict get $spec requirements] {
        if {[datasetField [dict get $source dataset_id] $key {}] ni $accepted} {return [dict create compatible 0 reason capability field $key]}
    }
    return [dict create compatible 1 reason compatible schema_version $version]
}
proc ::GX::datasetExportProviderCheck {module action datasetId} {
    set source [_datasetExportSource $datasetId]
    return [dict merge [_datasetExportCompatibility [datasetExportProviderDescribe $module $action] $source] [dict create source $source]]
}
proc ::GX::datasetExportProviderList {{datasetId {}}} {
    set result {};set source {}
    if {$datasetId ne {}} {set source [_datasetExportSource $datasetId]}
    foreach record [_datasetExportDeclarations] {
        if {$datasetId ne {}} {
            set compatibility [_datasetExportCompatibility $record $source]
            if {![dict get $compatibility compatible]} continue
            dict set record source $source
            dict set record compatibility $compatibility
        }
        lappend result $record
    }
    return $result
}
proc ::GX::datasetExportProviderInvoke {module action datasetId destination {parameters {}} {expected {}}} {
    variable currentSession
    set definition [datasetExportProviderDescribe $module $action]
    set check [datasetExportProviderCheck $module $action $datasetId]
    if {![dict get $check compatible]} {error "Dataset export is incompatible: [dict get $check reason]"}
    set source [dict get $check source]
    if {$expected ne {} && $source ne $expected} {error {Dataset or Session changed; reopen the export action}}
    if {[string bytelength $parameters]>65536 || [catch {dict size $parameters}]} {error {Export parameters must be a bounded dictionary}}
    set normalized {}
    dict for {key value} $parameters {if {![dict exists $definition fields $key]} {error "Unknown export parameter '$key'"}}
    dict for {key field} [dict get $definition fields] {
        set value [datasetPublicationV2DictDefault $parameters $key [datasetPublicationV2DictDefault $field default {}]]
        if {[string length $value]>4096} {error {Export parameter exceeds its bound}}
        dict set normalized $key [uiFieldNormalize $field $value]
    }
    set destination [file normalize $destination];set session [file normalize $currentSession]
    if {$destination eq $session || [string first $session/ $destination]==0} {error {Choose an external destination outside the scientific Session}}
    modulePublicApiActivate $module [dict get $definition public_api]
    set command [dict get $definition command]
    if {![llength [info commands $command]]} {error {Exporter callback unavailable}}
    set request [dict create api_id DATASET_EXPORT_PROVIDER_API_v1 version 1 dataset_id $datasetId session_token [dict get $source session_token] source $source parameters $normalized]
    set result [uplevel #0 [list $command $request]]
    if {![dict exists $result status] || [dict get $result status] ne {ok} || ![dict exists $result bytes] || [dict get $result format] ne [dict get $definition format] || [string bytelength [dict get $result bytes]]>64000000} {error {Exporter returned an invalid bounded output receipt}}
    if {[_datasetExportSource $datasetId] ne $source || ![moduleIsEnabled $module]} {error {Dataset, Session or exporter changed during conversion}}
    set publication [filePublicationPublishBundle [list [dict create id export destination $destination writer [list ::GX::_datasetExportWrite [dict get $result bytes]]]]]
    return [dict merge [dict remove $result bytes] [dict create api_id DATASET_EXPORT_PROVIDER_API_v1 module_id $module action_id $action source $source parameters $normalized publication $publication]]
}
proc ::GX::_datasetExportWrite {bytes channel context} {puts -nonewline $channel $bytes}
