% SPDX-License-Identifier: GPL-3.0-or-later
% Existing per-graph Axes owner projects only validated public graphics fields.
% Reuse the original configuration resolver and physical font conversion.
function config=gxtxt_plot_config_for_graph(cfg,graph)
  prefix=regexprep(['axis.' graph '.graphics_env.'],'[^A-Za-z0-9_]','_');
  names=fieldnames(cfg);saved=struct();
  unwind_protect
    for k=1:numel(names)
      if(!strncmp(names{k},prefix,numel(prefix))),continue;endif
      name=names{k}(numel(prefix)+1:end);
      if(isempty(regexp(name,'^GXTXT_(PLOT(_|3D_).+|PNG_DPI)$','once'))||strcmp(name,'GXTXT_PLOT_GRAPH_MAP_FILE')),error('GXTXT:PlotGraphics','Unsupported per-graph environment projection');endif
      saved.(name)=getenv(name);setenv(name,cfg.(names{k}));
    endfor
    config=gxtxt_plot_config();
  unwind_protect_cleanup
    names=fieldnames(saved);for k=1:numel(names),setenv(names{k},saved.(names{k}));endfor
  end_unwind_protect
endfunction
