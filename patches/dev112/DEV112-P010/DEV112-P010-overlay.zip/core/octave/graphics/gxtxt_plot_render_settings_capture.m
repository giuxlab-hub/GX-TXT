% SPDX-License-Identifier: GPL-3.0-or-later
% Renderer-owned bounded presentation evidence. Never serialize scientific data.
function presentation=gxtxt_plot_render_settings_capture(fig,context,dpi,device,png)
  graphics=context.graphics;
  % Configuration NaNs mean automatic policy, not a JSON numeric value.
  names=fieldnames(graphics);
  for k=1:numel(names)
    value=graphics.(names{k});
    if(isnumeric(value)&&isscalar(value)&&!isfinite(value)),graphics.(names{k})='auto';endif
  endfor
  common=graphics;
  renames={'font_size_input','font_size';'axis_label_font_size_input','axis_label_font_size'; ...
    'title_font_size_input','title_font_size';'legend_font_size_input','legend_font_size'; ...
    'legend_mode','legend_placement';'legend_location','legend_inside_preset';'legend_external_margin_px','legend_margin_px'};
  for k=1:rows(renames)
    if(isfield(graphics,renames{k,1})),common.(renames{k,2})=graphics.(renames{k,1});endif
  endfor
  % Retain the exact runtime struct separately; common fields use original
  % user font units rather than the renderer's converted physical points.
  allowed={'width_px','height_px','dpi','font_unit','font_size','axis_label_font_size','title_font_size', ...
    'line_width','grid_mode','grid_color','background','legend_placement','legend_inside_preset','legend_layout', ...
    'legend_alignment','legend_columns','legend_font_unit','legend_font_size','legend_background','legend_border', ...
    'legend_border_color','legend_margin_px','view_azimuth','view_elevation','projection','aspect_mode','aspect_ratio', ...
    'colormap','colorbar_visible','colorbar_label','color_unit','color_min','color_max'};
  common=rmfield(common,setdiff(fieldnames(common),allowed));
  presentation=struct('schema','PLOT_RENDERER_PRESENTATION_v1','version',1,'dimension',context.dimension, ...
    'settings',struct('graphics',common,'runtime_config',graphics),'renderer_extensions',struct());
  actual=struct('owner','PlotDataset.Octave.v3','toolkit',graphics_toolkit(fig),'raster_device',device,'dpi',dpi);
  image=imfinfo(png);actual.width_px=image.Width;actual.height_px=image.Height;
  actual.background=get(fig,'color');
  axes_receipts={};legend_receipts={};series_receipts={};
  handles=findall(fig,'type','axes');
  for k=1:numel(handles)
    ax=handles(k);tag=get(ax,'tag');
    item=struct('tag',tag,'visible',get(ax,'visible'),'position',get(ax,'position'),'position_unit',get(ax,'units'));
    if(!isempty(strfind(lower(tag),'legend')))
      item=properties(ax,item,{'fontsize','fontunits','fontname','color','edgecolor','linewidth','box','location','orientation','string'});
      item.kind='legend_container';item.text_objects={};
      for property={'placement','layout','columns'}
        key=['gxtxt_plot_legend_effective_' property{1}];
        if(isappdata(ax,key)),item.(['effective_' property{1}])=getappdata(ax,key);endif
      endfor
      text_handles=findall(ax,'type','text');
      for j=1:numel(text_handles)
        text_item=properties(text_handles(j),struct(),{'string','fontsize','fontunits','fontname','color','position','units','rotation','horizontalalignment','verticalalignment','visible'});
        item.text_objects{end+1}=text_item;
      endfor
      legend_receipts{end+1}=item;continue;
    endif
    if(!isempty(strfind(lower(tag),'colorbar')))
      item.kind='colorbar';
    else
      item.kind='data_axis';
    endif
    item=properties(ax,item,{'xlim','ylim','zlim','xscale','yscale','zscale','xdir','ydir','zdir','xtick','ytick','ztick', ...
      'xticklabel','yticklabel','zticklabel','xgrid','ygrid','zgrid','xminorgrid','yminorgrid','zminorgrid', ...
      'fontsize','fontunits','fontname','linewidth','color','gridcolor','gridalpha','clim','view','projection', ...
      'dataaspectratio','plotboxaspectratio','cameraposition','cameratarget','cameraupvector','cameraviewangle'});
    item.colormap=colormap(ax);
    for label={'xlabel','ylabel','zlabel','title'}
      h=get(ax,label{1});item.(label{1})=struct('text',get(h,'string'),'font_size',get(h,'fontsize'),'font_unit',get(h,'fontunits'));
    endfor
    axes_receipts{end+1}=item;
    if(strcmp(item.kind,'data_axis'))
      children=findall(ax,'type','line');
      for j=1:numel(children)
        line=properties(children(j),struct('axis_tag',tag),{'displayname','color','linestyle','linewidth','marker','markersize','markerfacecolor','markeredgecolor','visible'});
        series_receipts{end+1}=line;
      endfor
    endif
  endfor
  actual.text_objects={};
  text_handles=findall(fig,'type','text');
  for j=1:numel(text_handles)
    item=properties(text_handles(j),struct(),{'string','fontsize','fontunits','fontname','color','position','units','rotation','visible'});
    actual.text_objects{end+1}=item;
  endfor
  actual.axes=axes_receipts;actual.legends=legend_receipts;actual.series_styles=series_receipts;
  actual.figure_default_colormap=get(fig,'colormap');
  presentation.settings.renderer_receipt=actual;
  if(isappdata(fig,'gxtxt_render_settings_series')),presentation.settings.series_presentations=getappdata(fig,'gxtxt_render_settings_series');endif
endfunction

function out=properties(handle,out,names)
  for k=1:numel(names)
    if(isprop(handle,names{k})),out.(names{k})=get(handle,names{k});endif
  endfor
endfunction
