"""Existing Mathematics/Numeric/Workspace owners with immutable result publication."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray
import math
import uuid
from numbers import Real

# New inert owner facets are appended below; existing operation descriptors and
# executable paths retain their original definitions.

_OPERATIONS = ('initialState', 'presets')
REGISTRATION = {
    'api_id': 'MATHEMATICS_EXPLORER_API_v1', 'api_version': 1,
    'provider_kind': 'module', 'provider_id': 'viewer.mathematics_explorer',
    'documentation_ref': 'plugins/modules/viewer.mathematics_explorer/docs/USER_GUIDE.md',
    'operations': {name: {'name': name, 'summary': 'Read existing provider metadata: '+name,
        'arguments': [], 'argument_convention': 'no arguments',
        'result_contract': 'Typed inert public owner metadata; no GUI/scientific operation'}
        for name in _OPERATIONS},
}


def _metadata(host, operation, args):
    if operation not in _OPERATIONS:
        raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown provider metadata operation')
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Provider metadata takes no arguments')
    host.call('::GX::modulePublicApiActivate', 'viewer.mathematics_explorer', 'MATHEMATICS_EXPLORER_API_v1')
    raw = host.call('::GX::MathematicsExplorer::'+operation)
    if operation == 'presets':
        return {str(key): str(value) for key, value in host.as_dict(raw).items()}
    source = host.as_dict(raw)
    result = {key: str(source[key]) for key in ('title', 'output_unit')}
    result.update(schema=int(source['schema']), xmin=float(source['xmin']), xmax=float(source['xmax']),
                  samples=int(source['samples']), derivative=bool(int(source['derivative'])))
    result['symbol_units'] = {str(key): str(value) for key, value in host.as_dict(source['symbol_units']).items()}
    result['parameters'] = {str(key): float(value) for key, value in host.as_dict(source['parameters']).items()}
    result['view_axes'] = {str(key): host.normalize(value) for key, value in host.as_dict(source['view_axes']).items()}
    result['functions'] = []
    for item in host.as_list(source['functions']):
        fields = host.as_dict(item)
        result['functions'].append({**{key: str(fields[key]) for key in ('id', 'label', 'preset', 'expression')},
                                    'enabled': bool(int(fields['enabled']))})
    return result


_OWNER='::GX::MathematicsExplorer::'
_FIELDS={
 'validateState':[('state',True)],
 'evaluateExpression':[('expression',True),('x',True),('parameters',True),('units',True),('outputUnit',True)],
 'analyzeFirst':[('state',True),('mode',True)],'calculate':[('state',True)],
 'integralOfFirst':[('computed_id',True)],'sessionToken':[],
 'saveDocument':[('state',True),('currentId',True),('sessionToken',True),('expected_receipt_id',False)],
 'readDocument':[('id',True),('sessionToken',True)],'listDocuments':[],
 'saveWorkspace':[('state',True),('expected_receipt_id',True),('sessionToken',True),('name',False)],
 'publishComputed':[('state',True),('computed_id',True),('document_receipt_id',True),('sessionToken',True),('outputId',True)],
 'publishGraph':[('state',True),('computed_id',True),('document_receipt_id',True),('sessionToken',True),('datasetId',True)],
}
REGISTRATION['operations'].update({name:{'name':name,'summary':'Shared Mathematics Explorer owner: '+name,
 'host_command':_OWNER+name,'arguments':[{'name':field,'kind':'closed mathematical state, execution-owned result/receipt, or explicit scalar','required':required}for field,required in fields],
 'argument_convention':', '.join(field for field,_ in fields)or'no arguments',
 'result_contract':'Actual shared Numeric values/units or canonical Workspace/Plot identities. calculate returns immutable execution-owned computed_id; read/saveWorkspace returns opaque receipt_id. Updates/publication require that held receipt, exact Session and unchanged canonical model/revision. No caller-computed publication arrays, Tcl variable/callback or host path.'}
 for name,fields in _FIELDS.items()})


def _invalid(message):raise BridgeError('GXTXT:ScriptBridge:InvalidArguments',message)
def _text(host,value):return str(host.tcl.call('format','%s',value))
def _session(host):return _text(host,host.call(_OWNER+'sessionToken'))

def _handles(host):
 session=_session(host);state=host.handles.setdefault('mathematics_explorer',{'session':session,'computed':{},'documents':{}})
 if state['session']!=session:
  state={'session':session,'computed':{},'documents':{}};host.handles['mathematics_explorer']=state
 return state

def _put(host,kind,record):
 records=_handles(host)[kind]
 if len(records)>=128:records.pop(next(iter(records)))
 token='mathematics-'+kind+'-'+uuid.uuid4().hex;records[token]=record
 return token

def _require(host,kind,token):
 if not isinstance(token,str)or token not in _handles(host)[kind]:_invalid('Unknown/foreign execution-owned Mathematics '+kind+' token')
 return _handles(host)[kind][token]

def _graph(host,state):
 return host.call(_OWNER+'workspaceEncode',state)

def _equivalent(host,left,right):
 return bool(host.tcl.getboolean(host.call('::GX::workspaceNative','typed_equivalent',left,right)))

def _state(host,state):
 if not isinstance(state,dict):_invalid('Mathematics state must be a closed struct')
 raw=host.call(_OWNER+'validateState',state)
 # The actual provider shape, rather than an adapter schema or parser, owns
 # all nested state fields and their scalar/array annotations.
 _graph(host,raw)
 return raw

def _node(node):
 kind,value=node['kind'],node['value']
 if kind=='object':return {key:_node(v)for key,v in value.items()}
 if kind=='array':return [_node(v)for v in value]
 if kind=='int':return int(value)
 if kind=='real':return float(value)
 if kind=='bool':return bool(int(value))
 if kind=='null':return None
 return value

def _visible_state(host,raw):
 return _node(host.modules['NATIVE_WORKSPACE_API_v1'].from_tcl(host,_graph(host,raw)))

def _stamp(host,record):
 row=host.as_dict(record)
 return {key:_text(host,row[key])for key in('id','generation','revision','sha256','module_id','provider_id','format','format_version')}

def _read(host,document,session):
 variable='__gxtxt_mathematics_receipt_'+uuid.uuid4().hex
 try:
  state=host.call(_OWNER+'readDocument',document,session,variable)
  record=host.tcl.getvar(variable)
  return state,record
 finally:host.tcl.call('unset','-nocomplain',variable)

def _guard_document(host,record):
 current=host.call('::GX::interactiveDocumentRead',record['stamp']['id'])
 if record['session']!=_session(host)or _stamp(host,current)!=record['stamp']:
  raise BridgeError('GXTXT:ScriptBridge:Ownership','Mathematical Document changed; read current source and calculate again')
 return current

def _document(host,state,raw):
 record={'raw':raw,'state':state,'stamp':_stamp(host,raw),'session':_session(host)}
 token=_put(host,'documents',record);row=host.as_dict(raw)
 result={key:_text(host,row[key])for key in('id','generation','sha256','module_id','provider_id','format','format_version')}
 result.update(revision=int(row['revision']),receipt_id=token,session_token=record['session'])
 return result

def _vector(host,value):
 values=[float(v)for v in host.as_list(value)];return NumericArray(values,[len(values),1])

def _computed(host,raw,token):
 row=host.as_dict(raw)
 return {'computed_id':token,'x':_vector(host,row['x']),
 'outputs':{key:_vector(host,value)for key,value in host.as_dict(row['outputs']).items()},
 'output_units':{key:_text(host,value)for key,value in host.as_dict(row['output_units']).items()},
 'series':[{'id':_text(host,host.as_dict(value)['id']),'label':_text(host,host.as_dict(value)['label']),
            'unit':_text(host,host.as_dict(value)['unit']),'values':_vector(host,host.as_dict(value)['values'])}for value in host.as_list(row['series'])]}

class _TypedHost:
 # Numeric's existing typed adapter builds temporary Python dictionaries for
 # cell nodes. Accept those transport containers without Tcl string inference.
 def __init__(self,host):self.host=host
 def __getattr__(self,name):return getattr(self.host,name)
 def as_dict(self,value):return value if isinstance(value,dict)else self.host.as_dict(value)

def _numeric(host,raw):
 return host.modules['NUMERIC_API_v1']._adapt(_TypedHost(host),raw,host.as_dict(host.call('::GX::NumericAPIv1::resultTypes')))

def invoke(host,operation,args):
 if operation in _OPERATIONS:return _metadata(host,operation,args)
 if operation not in _FIELDS:raise BridgeError('GXTXT:ScriptBridge:UnknownOperation',operation)
 fields=_FIELDS[operation]
 if not sum(required for _,required in fields)<=len(args)<=len(fields):_invalid('Invalid Mathematics argument count')
 host.call('::GX::modulePublicApiActivate','viewer.mathematics_explorer','MATHEMATICS_EXPLORER_API_v1')
 if operation=='sessionToken':return _session(host)
 if operation=='listDocuments':
  result=[]
  for raw in host.as_list(host.call(_OWNER+operation)):
   row=host.as_dict(raw);item={key:_text(host,row[key])for key in('id','name','generation','module_id','provider_id','format','format_version','sha256')if key in row}
   for key in('revision','durable_revision','size_bytes'):
    if key in row:item[key]=int(row[key])
   result.append(item)
  return result
 if operation=='evaluateExpression':
  if not isinstance(args[0],str)or not all(isinstance(v,dict)for v in args[2:4])or not isinstance(args[4],str):_invalid('Expression requires text, numeric x and explicit parameter/unit maps')
  values=args[1].values if isinstance(args[1],NumericArray)else args[1]
  if not isinstance(values,(list,tuple))and not isinstance(args[1],NumericArray):_invalid('Expression x must be a numerical vector')
  if any(isinstance(v,bool)or not isinstance(v,Real)or not math.isfinite(v)for v in values):_invalid('Expression x values must be finite real numbers')
  host.call(_OWNER+'activateNumerics');raw=host.call(_OWNER+operation,args[0],args[1],*args[2:])
  return _numeric(host,raw)
 if operation in('validateState','calculate','analyzeFirst'):
  state=_state(host,args[0])
  if operation=='validateState':return _visible_state(host,state)
  if operation=='analyzeFirst':
   if not isinstance(args[1],str):_invalid('Mathematical analysis mode must be text')
   raw=host.call(_OWNER+operation,state,args[1])
   return _numeric(host,raw)
  session=_session(host);raw=host.call(_OWNER+operation,state)
  if _session(host)!=session:raise BridgeError('GXTXT:ScriptBridge:Ownership','Session changed during mathematical calculation')
  token=_put(host,'computed',{'raw':raw,'state_graph':_graph(host,state),'session':session})
  return _computed(host,raw,token)
 if operation=='integralOfFirst':
  record=_require(host,'computed',args[0]);value=float(host.call(_OWNER+operation,record['raw']))
  if record['session']!=_session(host):raise BridgeError('GXTXT:ScriptBridge:Ownership','Session changed during mathematical integration')
  return value
 if operation=='readDocument':
  if any(not isinstance(v,str)for v in args):_invalid('Canonical Document ID and Session token must be text')
  state,raw=_read(host,*args);result=_document(host,state,raw);result['state']=_visible_state(host,state);return result
 if operation in('saveDocument','saveWorkspace'):
  state=_state(host,args[0])
  if any(not isinstance(v,str)for v in args[1:]):_invalid('Save uses text identities and an execution-owned expected receipt')
  if operation=='saveDocument':
   expected=args[3]if len(args)>3 else''
   held=_require(host,'documents',expected)if expected else None
   if held:_guard_document(host,held)
   document=_text(host,host.call(_OWNER+operation,state,args[1],args[2],held['raw']if held else''))
   # Re-read through the same owner to establish actual durable/source identity.
   _read(host,document,args[2]);return document
  held=_require(host,'documents',args[1])if args[1]else None
  if held:_guard_document(host,held)
  saved=host.as_dict(host.call(_OWNER+operation,state,held['raw']if held else'',args[2],*args[3:]))
  actual_state,raw=_read(host,_text(host,saved['id']),args[2]);return _document(host,actual_state,raw)
 # Publication accepts retained shared-owner calculation and a held canonical
 # Document receipt. Caller arrays/derived outputs never become authority.
 state=_state(host,args[0]);computed=_require(host,'computed',args[1]);held=_require(host,'documents',args[2])
 if any(not isinstance(v,str)for v in args[3:]):_invalid('Publication Session and output identity must be text')
 actual=_guard_document(host,held);payload=host.as_dict(actual)['payload']
 if args[3]!=computed['session']or args[3]!=held['session']or not _equivalent(host,_graph(host,state),computed['state_graph'])or not _equivalent(host,_graph(host,payload),computed['state_graph']):
  raise BridgeError('GXTXT:ScriptBridge:Ownership','Calculated model, saved canonical Document and Session must agree exactly')
 # Native Workspace reads add owner metadata. Pass that actual source payload
 # to its unchanged equality guard; no caller metadata can supply authority.
 raw=host.call(_OWNER+operation,payload,computed['raw'],held['stamp']['id'],args[3],args[4])
 _guard_document(host,held)
 if operation=='publishGraph':
  host.persist_manifest('mathematics_publish_graph')
  return {'dataset_id':args[4],'graph_ref':{key:_text(host,value)for key,value in host.as_dict(raw).items()}}
 row=host.as_dict(raw)
 result={key:_text(host,row[key])for key in('dataset_id','sha256','storage_provider')}
 return host.record_publications(result)

def cleanup(host):host.handles.pop('mathematics_explorer',None)


# Value-only facets of the same descriptor-admitted module. The original Tcl
# lexer/parser/finite validator remain the sole owners of accepted input and
# errors. These operations neither evaluate a formula nor acquire a GUI owner.
_INERT_FIELDS = {'finiteNumber': ('value', 'label'),
                 'tokenize': ('expression',), 'parseExpression': ('source',)}
REGISTRATION['operations'].update({name: {
    'name': name, 'summary': 'Call the original inert Mathematics owner: ' + name,
    'host_command': _OWNER + name,
    'arguments': [{'name': field, 'kind': 'string', 'required': True} for field in fields],
    'argument_convention': ', '.join(fields),
    'result_contract': ('finite double or original labelled owner error' if name == 'finiteNumber' else
                        'ordered two-text token cells, including the original end/empty token' if name == 'tokenize' else
                        'inert tagged AST cells; constant payloads are doubles, other scalar payloads text'),
} for name, fields in _INERT_FIELDS.items()})


def _inert_ast(host, raw, depth=0):
    """Transport the owner's tagged list; no parsing or mathematical evaluation."""
    if depth > 64:
        raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original AST exceeds transport depth')
    parts = host.as_list(raw)
    if not parts:
        raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original AST node is empty')
    tag = _text(host, parts[0])
    arities = {'constant': 2, 'symbol': 2, 'function': 3, 'unary': 3, 'binary': 4}
    if tag not in arities or len(parts) != arities[tag]:
        raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original AST tag/arity changed')
    if tag == 'constant':
        return [tag, float(parts[1])]
    if tag == 'symbol':
        return [tag, _text(host, parts[1])]
    return [tag, _text(host, parts[1]), *[_inert_ast(host, part, depth + 1) for part in parts[2:]]]


_established_invoke = invoke


def invoke(host, operation, args):
    if operation not in _INERT_FIELDS:
        return _established_invoke(host, operation, args)
    if len(args) != len(_INERT_FIELDS[operation]) or any(not isinstance(value, str) for value in args):
        _invalid('Inert Mathematics operation requires its exact text arguments')
    if any(len(value.encode('utf-8')) > 1048576 for value in args):
        _invalid('Inert Mathematics text exceeds the 1 MiB transport bound')
    host.call('::GX::modulePublicApiActivate', 'viewer.mathematics_explorer', 'MATHEMATICS_EXPLORER_API_v1')
    raw = host.call(_OWNER + operation, *args)
    if operation == 'finiteNumber':
        return float(raw)
    if operation == 'parseExpression':
        return _inert_ast(host, raw)
    result = []
    for token in host.as_list(raw):
        parts = host.as_list(token)
        if len(parts) != 2:
            raise BridgeError('GXTXT:ScriptBridge:RemoteError', 'Original token pair shape changed')
        result.append([_text(host, value) for value in parts])
    return result


from gxtxt_script_values_v1 import descriptor as _value_descriptor, invoke as _whole_value
REGISTRATION['operations']['nativeModel'] = _value_descriptor(
    'nativeModel', ['state', 'computed'], 'Complete original model as opaque whole TclValue, including nonfinite sentinels; no rendering/publication')
REGISTRATION['operations']['nativeModel']['host_command'] = _OWNER + 'nativeModel'
_previous_model_invoke = invoke

def invoke(host, operation, args):
    if operation == 'nativeModel':
        host.call('::GX::modulePublicApiActivate', 'viewer.mathematics_explorer', 'MATHEMATICS_EXPLORER_API_v1')
        return _whole_value(host, 'MATHEMATICS_EXPLORER_API_v1', operation, args)
    return _previous_model_invoke(host, operation, args)
