# Retained P009 Mathematics source evidence

These files preserve exact immutable P009 policy bytes. Their source hashes,
contracts and historical qualifications are retained evidence, not current P010
registration or runtime proof. Current policies remain beside their P010 owners;
independent executed coverage belongs to the delivery matrix.
