# Plot Render Settings API v1

SPDX-License-Identifier: GPL-3.0-or-later

Read-only evidence of a graph's last successful rendering, separate from its
mutable PlotSpec, Graph Metadata, configuration and scientific Dataset authority.
No image analysis, guessed defaults or automatic migration reconstructs legacy
settings. Ordinary browsing/open/save/reopen/Clone operations do not require a
manifest and do not force a rerender.

## Operations and typed statuses

- `::GX::plotRenderSettingsApiInfo`: API version, schemas, status vocabulary.
- `::GX::plotRenderSettingsStatus graph_ref`: `api_id`, normalized `reference`,
  `status` and optional bounded reason.
- `::GX::plotRenderSettingsRead graph_ref`: the same result plus `snapshot`,
  a nested presentation object when available, otherwise an empty value.

Graph references use the existing owner: `{kind provider module_id plot.dataset
graph_id plot.dataset.xy variant_id ...}` or `{kind clone clone_id c000001}`.
An omitted Variant ID means the base identity. Each Variant owns a separate
output/manifest. Other providers normally return `unsupported`. A malformed
reference or missing current Session raises an ordinary owner validation error;
legacy absence is not an error.

| Status | Meaning |
| --- | --- |
| `available` | Complete supported snapshot, exact current output identity |
| `absent_legacy` | No stored manifest; expected for historical graphs |
| `partial` | Incomplete/unreadable/bounded-invalid settings evidence |
| `unsupported` | Unknown schema or renderer/capture capability |
| `stale/output_mismatch` | Output missing, changed byte count or SHA-256 |

Partial/stale snapshots are diagnostic evidence, not a complete transferable
profile. Their presence must not prevent ordinary image display. The reader
hashes the managed PNG to check binding; callers need no private filesystem
access. Manifest files are inert UTF-8 JSON, bounded to 2 MiB and decoded through
the existing native Workspace typed JSON owner; they are never sourced/evaluated.

## Snapshot contracts

`PLOT_RENDER_SETTINGS_SNAPSHOT_v1` is for persistent provider graphs.
`PLOT_CLONE_RENDER_SETTINGS_v1` is the distinct Clone contract. Common fields:

- `schema`, integer `version=1`, normalized graph `reference`.
- `renderer_api`, `backend`, UTC `rendered_at`, independent render `revision` and `render_status=success`.
- `output`: owned relative filename, PNG SHA-256 and exact integer byte count.
- `presentation`: a typed extensible object supplied by the producing renderer.
- Optional `renderer_extensions`: renderer-specific typed fields with explicit
  version/compatibility rules; no Dataset samples, executable commands or
  arbitrary system paths.
- `completeness`: `available`, `partial` or `unsupported`.
- `verification`: settings are renderer-submitted/receipted; pixels are not
  described as independently visually verified by an automatic capture.

The renderer owns property definitions and serialization, including numeric,
boolean, text and collection types. The normalized reader does not recognize
every Plot option independently. New transferable properties require explicit
public validation/compatibility rules. Interactive orbit/pan/wheel movements are
transient and do not update this last-successful-render record.

Trusted internal producers use `plotRenderSettingsBuild` to construct typed
evidence and `plotRenderSettingsPublish` to publish the PNG, manifest and supplied
managed sidecars through the existing File Publication replace transaction. All
writers finish before any visible file changes; failures retain/restore the old
pair or propagate the original explicit rollback-recovery error. These helpers
are host implementation surfaces, not Script Bridge configuration writers.

## Python and Octave Script Bridge

Both languages register exactly `info()`, `status(graph_ref)` and
`read(graph_ref)` under `PLOT_RENDER_SETTINGS_API_v1`. Typed JSON projection keeps
nested objects, arrays, booleans and numeric values instead of flattening them
to Tcl strings. Absent snapshots become null in the typed Bridge result.
Normal Script Registry/Session admission still applies; existing authorized MCP
Bridge calls can invoke these registered operations without new transport.

```python
from gxtxt import gxtxt_api_call as call
ref = {"kind": "provider", "module_id": "plot.dataset",
       "graph_id": "plot.dataset.xy", "variant_id": ""}
result = call("PLOT_RENDER_SETTINGS_API_v1", "read", [ref])
```

No `write`, `apply`, `save`, rerender or configuration mutation is added to this
Bridge API. Existing permitted Plot Dataset v3/v4 operations remain their own
scientific/configuration owners.

## Producing renderers and Clones

Original persistent v3 captures actual process configuration and finalized
figure/axes/text presentation before cleanup, including each axes palette and
external legend child text. Figure-default palette and legend container fonts
are identified separately from the actual painted objects. Native v4 uses its
prepared model and Native2D receipt, or its Native3D descriptor plus available
accepted camera receipt before temporary geometry deletion. Titles and panel
titles are evidence even though portable profiles preserve target titles.

Original calibration, shared-X metadata and requested vector outputs share the
PNG/manifest publication transaction. Failed work cannot replace calibration
for the retained prior image. Missing legacy records are never backfilled.

Scientific Clone capture binds its own producer receipt and PNG to its own
Clone identity. A verified available v3 source record supplies actual graphics
when freezing a Variant; a saved parent runtime file alone is not actual
Variant environment evidence. Detached rerender creates a new Clone revision.
Rendered fallback may retain only byte-identical verified source presentation,
marked partial and noneditable; absent trustworthy information stays absent.

## Presentation drafts and portable profiles

Trusted GUI helpers use `PLOT_PRESENTATION_PROFILE_v1`, version1, dimension2/3,
and bounded `settings` objects for graphics, legend and layout. Optional `series`
records contain only zero-based panel/series positions, their expected counts,
kind, side and validated style. They contain no Dataset/variable binding, samples,
formula, path or executable. Original renderer field catalogs and original PlotSpec
style validation own admitted values. JSON profiles are at most64KiB; Session
collections at most64 named profiles/1MiB. Read/load changes a draft; Apply commits
through the original target owners and rerender is explicit.

Original v3 ordinary2D rendering records its resolved logical series styles before
cleanup. RGB colors project to the existing public eight-bit hex color contract.
Native2D uses its exact prepared logical panels/series/styles. Profiles map styles
only at matching panel/series positions with matching counts, kind and axis; the
confirmation names target series identities. Incompatible, family-expanded or
unrecorded style capabilities are skipped explicitly. No visual or label matching
is inferred. Older snapshots without exact logical style receipts stay usable for
their common supported settings; missing style data is not guessed. Scientific
Clone editors retain their original supported common strokes; unsupported detailed
styles are listed. Target Dataset/series/variable IDs, formulas, titles and semantic
labels are preserved. Numeric axes transfer is not part of this portable contract;
use the original Axes editor with its explicit compatible-unit admission.

Explicit legend properties have one draft owner. Historical profiles containing
duplicate graphics legend defaults normalize to the explicit legend section so
an edited value cannot be silently shadowed. Source-specific unsupported fields
remain visible as omissions; an available render snapshot does not imply that
every renderer property has a cross-renderer portable equivalent.
