# Mathematics Explorer model v2

SPDX-License-Identifier: GPL-3.0-or-later

Schema2 is inert mathematical data. Use `initialState2` for a complete template.
Top-level fields: schema2, title, xmin/xmax, samples, x_unit, ordered parameters,
definitions, systems, families/family_id, functions, selected_function,
selected_branch (empty means all its branches), derivative and saved view_axes.
Declarations remain separate from transient computed buffers.

Parameters contain stable case-sensitive id, label, description, group, unit,
exact value and slider `{mode,min,max}`. Modes are none/linear/logarithmic;
logarithmic ranges require positive endpoints. Shared inputs belong to the model;
function-local parameters belong to that function and explicitly shadow
same-named shared inputs. Distinct functions retain independent local values.
The selected family supplies recorded shared overrides. No interpolation or
predictive family law is inferred.

A definition contains id, expression and declared unit. Its name denotes a
reusable scalar or X-dependent relation, for example `X=(x-V0)/Sminus` with unit1.
Needed dependency closures are evaluated; cycles/unresolved symbols fail.
No arbitrary Tcl/Python/Octave/shell source executes. Text is bounded to8192
characters. Original Numeric owns exact tokens, precedence, pointwise functions
(including expm1/log1p), dimensional rules and the64-symbol bound. The original
three-slot parser is not reused for schema2.

A system contains id, ordered unknown `{id,unit}` declarations and an equally
sized equation list. Each equation contains coefficient expressions for every
unknown, a right-hand-side expression and equation unit. Coefficients may depend
on available inputs/relations/earlier systems, not unknowns being solved. Original
Numeric solves only square1..16 systems with full rank, condition≤1e12 and
normalized relative residual≤1e-10. Strict expression units normalize each
unknown-unit basis into its equation-unit row. Receipts retain these bases/row
units; condition numbers are not claimed physically unit-invariant. No nonlinear
fitter or computer algebra system is added.

Each function contains id, label, enabled flag, default output_unit, local
parameters/definitions and ordered branches. Each branch contains id, label,
expression, lower/upper expressions (empty uses global bounds), inclusive flags,
samples (0 inherits global), sampling uniform/explicit, explicit_x and exclusions.
Optional branch output_unit overrides its function default. Literal bounds are
coordinates in x_unit; other expressions resolve to compatible scalar quantities.

Exclusions contain lower/upper expressions and inclusive flags. Ordered branches
must not overlap, including ambiguous shared endpoints. Connected admitted
intervals are determined before original Numeric comparisons/masks/select choose
samples. Invalid alternatives never execute outside declared domains. Undeclared
real-domain errors remain failures. No zero fill, epsilon repair, smoothing or
connector across a gap is invented. C0 continuity does not impose C1 continuity.

Global/per-branch uniform counts are2..20000; explicit vectors strictly increase
and contain at most20000 finite coordinates. Limits:32 functions,32 branches per
function,64 exclusions per branch,64 parameters/definitions per scope,64 named
families,8 systems,200000 declared sample points and512 connected components.
These engineering bounds are not scientific accuracy guarantees.

`calculate` returns segments with function/branch/component/family identity,
actual X/response vectors, units, declared intervals and actual sampled limits.
Selected differentiation runs separately per connected component. Integration
returns per-component trapezoidal values/units and actual limits, never an
integral over gaps. Analysis uses closed subintervals of admitted samples and
original bounded solvers. Independent local symbols remain separate for
intersections. An excluded/open endpoint is never silently included.

The native model reuses the existing Plot v4 widget and its data panels for
incompatible units or derivative quantities. Publication creates one canonical
Dataset row grid per component with x/response variables, units and complete
formula/parameter/domain/family/synthetic provenance. Graph publication reuses
those Datasets and explicit display units. Component IDs use the requested
create-only output prefix; all IDs are preflighted. Later component/Graph failure
reports and preserves committed receipts.

Schema1 Workspaces retain original field types and version1. Schema2 uses
distinct provider mathematics_explorer_v2 and format version2 through the same
original native Workspace authority. Existing Script Bridge operations retain
source receipts, revision/lifetime checks and execution-held calculation handles.
Changed mathematical declarations or Unit Registry context require recomputation.

```python
from gxtxt import gxtxt_api_call as call
api = "MATHEMATICS_EXPLORER_API_v1"
state = call(api, "initialState2", [])
state["samples"] = 51
state["functions"][0]["branches"][0]["expression"] = "amplitude*expm1(x)"
result = call(api, "calculate", [state])
integrals = call(api, "integralOfSelected", [result["computed_id"]])
```

Run expensive script work through existing managed Jobs. Finite numerical
sampling is not symbolic completeness, measurement uncertainty or independent
scientific validation. This backend increment does not claim the separately
approved dynamic GUI is complete.
