# Dataset Export Provider API v1

SPDX-License-Identifier: GPL-3.0-or-later

Trusted host API over the existing Module and Canonical Dataset registries.
Discovery is metadata only: it does not activate a provider, read geometry,
convert scientific values, create an output or require a Viewer. There are no
new Script Bridge operations or writer grants.

## Host operations

- `datasetExportProviderApiInfo` describes version and policy.
- `datasetExportProviderList ?datasetId?` returns enabled, installed providers;
  a supplied canonical identity filters by declared compatibility.
- `datasetExportProviderDescribe module action` returns the current declaration
  or fails if disabled, missing or unsupported.
- `datasetExportProviderCheck module action datasetId` returns `compatible`,
  `reason` (`compatible`, `contract`, `format`, `schema_version`, `capability`),
  optional incompatible field, effective schema version and `source` identity.
- `datasetExportProviderInvoke module action datasetId destination ?parameters?
  ?expectedSource?` validates again, calls the declared public adapter and uses
  File Publication create-only atomic output. Return: adapter receipt without
  bytes, API/module/action IDs, exact source, normalized parameters and complete
  File Publication receipt (destination/SHA-256/byte count). Errors propagate;
  conversion/publication failure creates no partial destination. Existing files
  are never replaced by this API.

Source identity contains the current process-local Session token, Dataset ID,
exact canonical contract and format, declared schema version when available,
canonical/file SHA-256, producer and update identity. Menus retain this source
record; invoking after a Session/Dataset change fails. Active-Dataset actions
also verify that activation has not changed while options/chooser are open.
The context menu always binds its clicked canonical Dataset independently of
the active Dataset. Both menus call `datasetExportMenuAppend`; future exporters
require no Browser edits. Namespaces, pending inputs and Groups are excluded.
Normal ZIP exports remain independent.

## Module declaration

Declare `[dataset_exports] api_version=1` and `ids=action;...` (maximum 32).
Each `[dataset_export.action]` declares `label`, `format`, `.extension`,
`public_api`, a literal qualified `command`, `contracts=exact.contract;...` and
optional `parameters=name;...` (maximum 32). The API must occur in the module's
existing `[public_apis]` list with a present module-local entrypoint.

Each `[dataset_export.action.contract.exact.contract]` declares:

- `versions`: exact supported schema versions, required.
- `formats`: optional exact canonical formats.
- `legacy_format_versions`: optional inert Tcl dictionary mapping an exact
  public format to its already specified schema version, for legacy registry
  records without `contract_schema_version`. This is an explicit provider
  contract claim, never a filename/label/default inference. Invocation must
  validate the actual public schema through its owner.
- `requirements`: optional inert dictionary of canonical metadata fields and
  accepted exact values, e.g. `dimensionality {2}`. Missing required metadata
  is incompatible, not guessed.

Optional `[dataset_export.action.parameter.name]` has shared UI Field `type`
(`string`, `integer`, `double`, `number`, `boolean`, `choice`), `label`, `default`,
`required`, `min`, `max`, `values`. Parameters are bounded (64 KiB request, 4096
characters per value), unknown keys rejected, and normalized by UI Field.
Malformed/unavailable declarations are omitted from discovery so ordinary
Dataset browsing remains available. `describe`/invocation fail explicitly.

The adapter receives one inert request: `api_id`, `version`, `dataset_id`,
`session_token`, exact `source`, normalized `parameters`. It must read and
validate the published Dataset through the relevant public owner, preserve all
source scientific state, and return `status ok`, matching `format`, complete
binary `bytes` (maximum 64 MB), plus bounded descriptive provenance/warnings
as appropriate. Do not return executable callbacks or implicit Dataset outputs.
The host rechecks source/provider state before publication. The destination
must be external to the scientific Session. Version1 publishes one file;
future sidecar policies require an explicit contract extension.
