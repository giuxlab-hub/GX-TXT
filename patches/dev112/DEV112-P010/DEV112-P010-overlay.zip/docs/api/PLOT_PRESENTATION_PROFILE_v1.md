# Plot presentation profiles v1

SPDX-License-Identifier: GPL-3.0-or-later

This bounded JSON contract contains `schema=PLOT_PRESENTATION_PROFILE_v1`,
integer `version=1`, integer `dimension=2|3`, and a `settings` object with
renderer-declared `graphics`, `legend` and `layout` sections. It contains no
Dataset, PlotSpec, scientific series identity, executable command, worker scene
or arbitrary filesystem locator. Files are at most 64 KiB. Unknown fields,
invalid types, nonfinite numbers and unsupported choices are refused through
the renderer-owned property catalog and original graphics validation.

The existing Plots row context menu can read a complete last-render manifest
into a separate editable draft. Reading, editing a draft, loading a named
preset and importing a file do not mutate any graph. A separate explicit Apply
reviews the chosen target and unavailable fields, commits only compatible
presentation through its original configuration owners, then invokes the
existing rerender handler. The last-render record continues to describe the
old successful output until that rerender publishes a new coherent bundle.

The original per-plot Axes presentation owner retains new `graphics_<field>`
properties. Its original Session manifest persists them in indexed
`plot.presentation.*` sections. Original CORE environment names project these
values to the existing Octave configuration resolver; native v4 consumes the
same per-plot owner. Global defaults, module defaults and sibling Variants are
unchanged. Existing Axes view/color fields are kept consistent with the same
explicit per-plot edit. The original Legend and layout owners retain their
own fields. Scientific titles, semantic labels, formulas, Dataset and variable
identities, numeric limits and units remain unchanged by this contract.

Two-dimensional targets explicitly report unavailable 3D view/colorbar fields.
Scientific Clones use their existing bounded presentation editor; unavailable
properties are reported before applying. Rendered-only Clones refuse editing.
No settings are fabricated for absent, stale, partial or unsupported snapshots;
the GUI explains their normal status and ordinary image display remains valid.

The Session stores up to 64 distinct named presets, each with a printable name
of 1..72 characters, in owned `metadata/plot_presentation_presets.json` (1 MiB
collection bound). Names are dictionary keys, never filesystem path components.
Import conf / Export conf use the existing Plots Import / Export primary group.
Export publishes through File Publication create-only; preset changes use its
replace transaction. Existing files are not silently overwritten on export.

Host functions include `plotPresentationProfileFromSnapshot`,
`plotPresentationProfileValidate`, `plotPresentationApplyPlan`,
`plotPresentationApply`, `plotPresentationProfileReadFile`,
`plotPresentationProfileExport`, `plotPresentationPresets`,
`plotPresentationPresetSave` and `plotPresentationPresetDelete`. Apply does not
invoke a private renderer. These GUI safety helpers add no Script Bridge write
operation: the public manifest Bridge retains only info/status/read.

The optional `series` array retains renderer-owned logical style records: integer
`panel_index`, `series_index`, `panel_count`, `series_count`, text `kind`/`axis`
and a typed `style` object. At most256 unique positions are accepted. Only the
original public PlotSpec style fields are transferable; original renderer field
types and style validation remain authoritative. These positional presentation
records contain no scientific bindings or samples. Portable and Session decoders
validate nested types; scalar strings cannot impersonate counts or collections.

Ordinary2D v3 producing renderers record resolved logical styles before cleanup;
Native2D uses exact prepared panels/series. Styles map only matching panel/series
positions and counts, kind and axis. Confirmation names the target series for
review; no label/PNG matching or invented family correspondence occurs. Original
PlotSpec owners save only styles, preserving target scientific identities,
formulas, titles, semantic labels, units and numeric axes. Unsupported topology,
family-expanded styles,3D layer styles or Clone detailed styles are explicitly
reported as skipped. Existing snapshots without logical receipts do not acquire
guessed style data. Source RGB uses the existing public eight-bit hex contract.

Explicit legend sections normalize duplicate historical graphics legend defaults
to one editable owner so a draft row cannot be silently shadowed. Numeric axes
transfer is outside this portable profile contract; the original compatible-unit
Axes editor remains available. It is an optional separate capability, not an
uncompleted required profile field or a new Script Bridge writer.
