# Synthetic 2D21 reference

This standalone example generates a **new** reproducible Session using the
published Giux-Lab 2D21 Level-1 v0.1 equations and five tabulated families
(25, 50, 100, 150, 200 mA). It never opens the historical 2D21 Session.
All values are theoretical model outputs, not experimental observations.

Run with the delivered P010 framework, Tcl, Octave and the original native plot
dependencies. On a headless server:

```sh
umask 077
xvfb-run -a tclsh generate.tcl /path/to/framework /path/to/NEW-output-root
```

The output root must not exist. All profiles, caches, temporary data, Resources,
Jobs and the new Session remain inside it. `SESSION_PATH.txt` identifies the
Session to open in GX-TXT. `reference/METHOD.md` records the article URL, equations,
units, table, domains and grids. Five native mathematical Workspaces, twenty
independent canonical component Datasets and five original Plotv4 graphs are
produced through existing public owners. Numerical receipts are retained for
independent validation. No fitting, invented raw observations, noise, uncertainty,
family interpolation or imposed derivative continuity is involved.

The generic Mathematics Explorer has no valve-specific mode or preset. This
example is data and a reproducible public-owner script. Runtime identifiers and
timestamps can vary; the mathematical declarations and numerical values are
deterministic. Existing files are never overwritten by rerunning the generator.
