# SPDX-License-Identifier: GPL-3.0-or-later
# Reproducible synthetic scientific example. The generic Mathematics API owns
# all expressions, coefficients, domains, physical units and publication.
if {[llength $argv]!=2} {error {Usage: tclsh generate.tcl FRAMEWORK NEW_OUTPUT_ROOT}}
lassign $argv framework output
set framework [file normalize $framework];set output [file normalize $output]
if {[file exists $output]} {error {Output root already exists; choose a new directory}}
file mkdir $output;file attributes $output -permissions 0700
set argv0 __gxtxt_synthetic_2d21_generator__
foreach {name relative} {XDG_CONFIG_HOME configuration XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state TMPDIR temporary GXTXT_JOB_ROOT jobs GXTXT_RESOURCE_ROOT resources GXTXT_RESOURCE_STORAGE resource_storage} {
    set ::env($name) [file join $output operation $relative];file mkdir $::env($name);file attributes $::env($name) -permissions 0700
}
source [file join $framework gxtxt_pipeline.tcl]
set fields {}
foreach {field relative} {storage.cache_dir cache storage.temp_dir temporary storage.session_root sessions storage.export_dir exports scripts.user_root scripts diagnostics.stderr_log_directory diagnostics} {
    set path [file join $output operation $relative];file mkdir $path
    ::GX::configurationRegister $field [dict create group {Synthetic reference generation} label $field type path default $path scope user]
    ::GX::configurationSet $field $path;lappend fields $field
}
::GX::configurationRegister preview.cache_enabled [dict create group Preview label {Automatic preview} type boolean default 0 scope user]
::GX::configurationSet preview.cache_enabled 0;lappend fields preview.cache_enabled
::GX::configurationSave $fields 0;::GX::defaults;::GX::configurationSave $fields 1;::GX::loadModuleCatalog
set roots [dict create configuration [::GX::configurationPath] cache [::GX::configurationCacheDirectory] temporary [::GX::configurationTempDirectory] resource_registry [::GX::resourceManagementRoot] resource_storage $::env(GXTXT_RESOURCE_STORAGE) jobs [::GX::scriptJobRoot]]
dict for {name path} $roots {if {[string first "$output/" [file normalize $path]]!=0} {error "Effective $name escaped the new output allocation"}}
set f [open [file join $output EFFECTIVE_ROOTS.tcldict] w];puts $f $roots;close $f
set ::GX::cfg(output_root) [file join $output sessions]
::GX::createNewSession synthetic_2d21_level1_v01
::GX::modulePublicApiActivate viewer.mathematics_explorer MATHEMATICS_EXPLORER_API_v1
set session [::GX::sessionInspectionCurrentSession]
file mkdir [file join $session reference]
set article https://giux-lab.it/2026/09/16/2d21-modello-compatto-corrente-griglia-datasheet-ge/
set table {
    {25 -0.28418 0.14187 0.03058 0.03136 4.995}
    {50 -0.36110 0.23812 0.04413 0.02802 3.746}
    {100 -0.43804 0.25758 0.06747 0.02819 4.984}
    {150 -0.45898 0.32066 0.05269 0.02884 4.072}
    {200 -0.50980 0.21483 0.05017 0.03254 4.592}
}
proc declaration {id value unit} {return [dict create id $id label $id description {Published Level-1 v0.1 reference value} group Reference unit $unit value $value slider {mode none min 0.000001 max 1000}]}
set state [::GX::MathematicsExplorer::initialState2]
dict set state x_unit V;dict set state xmin -3;dict set state xmax 0.1;dict set state samples 401
set parameters {}
foreach {id value unit} {Ia 25 mA V0 -0.28418 V Sminus 0.14187 V Splus 0.03058 V QA 0.03136 1 U20 4.995 1 K 0.551 1 lambda1 0.060 1 lambda2 0.240 1 lambda3 0.960 1} {lappend parameters [declaration $id $value $unit]}
dict set state parameters $parameters
set families {}
foreach row $table {lassign $row current v0 sm sp qa u20;lappend families [dict create id I$current label "Ia = $current mA (published family)" values [dict create Ia $current V0 $v0 Sminus $sm Splus $sp QA $qa U20 $u20]]}
dict set state families $families
dict set state definitions [list \
    {id Xm expression (x-V0)/Sminus unit 1} \
    {id Xp expression (x-V0)/Splus unit 1} \
    {id NegY expression -QA+A1*exp(lambda1*Xm)+A2*exp(lambda2*Xm)+A3*exp(lambda3*Xm) unit 1} \
    {id PosY expression 0.005*expm1(K*Xp)/expm1(K) unit 1}]
dict set state systems [list [dict create id negativeCoefficients unknowns {{id A1 unit 1} {id A2 unit 1} {id A3 unit 1}} equations [list \
    [dict create coefficients {A1 1 A2 1 A3 1} rhs QA unit 1] \
    [dict create coefficients {A1 exp(-lambda1) A2 exp(-lambda2) A3 exp(-lambda3)} rhs QA-0.010 unit 1] \
    [dict create coefficients {A1 exp(-lambda1*U20) A2 exp(-lambda2*U20) A3 exp(-lambda3*U20)} rhs QA-0.020 unit 1]]]]
set template [lindex [dict get $state functions] 0]
set negative [dict replace [lindex [dict get $template branches] 0] id negative label {Negative: Vg <= V0} expression NegY lower V0-U20*Sminus upper V0 lower_closed 1 upper_closed 1 samples 401]
set positive [dict replace $negative id positive label {Positive: Vg > V0} expression PosY lower V0 upper V0+3*Splus lower_closed 0 upper_closed 1 samples 301]
set normalized [dict replace $template id normalized label {Synthetic Y = Ig / Ia} output_unit 1 branches [list $negative $positive]]
dict set negative expression Ia*NegY;dict set positive expression Ia*PosY
set current [dict replace $template id gridCurrent label {Synthetic Ig} output_unit mA branches [list $negative $positive]]
dict set state functions [list $normalized $current];dict set state selected_function normalized
set f [open [file join $session reference published_family_parameters.csv] w]
puts $f {Ia_mA,V0_V,Sminus_V,Splus_V,QA,U20};foreach row $table {puts $f [join $row ,]};close $f
set f [open [file join $session reference METHOD.md] w]
puts $f "# Synthetic 2D21 Level-1 v0.1 reference\n\nSource: Giux-Lab, Compact grid-current model of the 2D21 from the GE datasheet.\nArticle: $article\n\nThese are newly generated theoretical curves, not GE observations, digitizations or fitted data. No noise, uncertainty, current interpolation law or derivative continuity is invented. The historical Session is never accessed.\n\nThe complete published five-family table is in published_family_parameters.csv. K=0.551; lambda=(0.060,0.240,0.960). Negative Y=-QA+sum(Aj*exp(lambda_j*(Vg-V0)/Sminus)); positive Y=0.005*expm1(K*(Vg-V0)/Splus)/expm1(K). A1..A3 solve Y(0)=0, Y(-1)=-0.010, Y(-U20)=-0.020 in negative normalized coordinates through original Numeric linear algebra. Ig=Ia*Y with explicitly recorded Ia in mA.\n\nFor each family, the negative grid is 401 uniform samples on the closed interval V0-U20*Sminus to V0. The positive grid declares301 uniform samples on V0 to V0+3*Splus and excludes its lower endpoint, yielding300 actual samples. Common outer bounds are -3V to0.1V. Every function/branch is published separately with its actual row grid; normalized Y and physical Ig use separate original Plotv4 panels. All five native Workspaces contain full explicit family tables, relations, systems and domains. Their scientific title is family-neutral so changing the selected family cannot leave an obsolete current asserted in the graph title. No raw measurements are present.\n\nReproduce using this package's generate.tcl with the exact delivered framework and a fresh output root; original public Mathematics/Numeric/Unit Registry/Workspace/Publication/Plotv4 owners perform all scientific work. Dynamic runtime IDs/timestamps may differ; equations, declared inputs and sampled numerical values are deterministic."
close $f
set f [open [file join $session notes experiment objective.md] w];puts $f "Synthetic theoretical 2D21 Level-1 v0.1 reference from $article. No experimental observations or uncertainty. Five explicitly recorded families only; no interpolation law.";close $f
set publications {}
foreach row $table {
    set current [lindex $row 0]
    dict set state title {SYNTHETIC 2D21 Level-1 v0.1: selected recorded family}
    dict set state family_id I$current
    set state [::GX::MathematicsExplorer::validateState $state]
    set saved [::GX::MathematicsExplorer::saveWorkspace $state {} [::GX::MathematicsExplorer::sessionToken] "Synthetic 2D21 $current mA"]
    puts "Calculating explicit published family $current mA";flush stdout
    set result [::GX::MathematicsExplorer::calculate $state]
    set f [open [file join $session reference family_${current}_computed.json] w]
    puts $f [::GX::nativeWorkspaceJsonEncode [::GX::MathematicsExplorer::computedEncode2 $result]];close $f
    set publication [::GX::MathematicsExplorer::publishGraph $state $result [dict get $saved id] [::GX::MathematicsExplorer::sessionToken] synthetic.2d21.I$current]
    lappend publications [dict create family I$current workspace [dict get $saved id] publication $publication]
}
set f [open [file join $session reference PUBLICATION_RECEIPTS.tcldict] w];puts $f $publications;close $f
::GX::sessionPersistenceCommit
set f [open [file join $output SESSION_PATH.txt] w];puts $f $session;close $f
if {[llength [info commands ::GX::apiCatalogClose]]} {::GX::apiCatalogClose}
puts "Generated new synthetic Session: $session"
