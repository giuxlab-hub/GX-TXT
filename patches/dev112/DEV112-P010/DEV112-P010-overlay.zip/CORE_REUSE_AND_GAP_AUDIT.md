# P010 reuse and limits

| Work | Existing authority retained |
| --- | --- |
| Dataset export | Original enabled Module metadata, canonical Dataset/schema/source identity, public Sketch, Unit Registry and File Publication. Both Browser menus share one discovery owner. |
| Plots | Original Plotv3 Octave and Plotv4 native renderers, PlotSpec/Graph Series/Variants, original Axes/Legend/layout/graphics and Session/Clone owners. |
| Render evidence/profiles | Actual producer inputs/receipts before cleanup; typed native JSON, original coherent File Publication, managed graph storage and original target configuration editors. |
| Mathematics | Existing Numeric expression/grid/masks/matrix/calculus, public Unit Registry, native Workspace/Session CAS, canonical Publicationv2, Plotv4 widget/picking/rendering and original Python/Octave Bridge. |
| Responsiveness | Original ScriptJob auxiliary process group/cancel/timeout and Resource descendant lease. Private frozen worker units/profiles/runtime Session, terminal guarded retirement retries. |

No separate renderer, camera system, numerical parser/evaluator, nonlinear fitter,
family predictor, Dataset registry or scripting transport is added. The owner's
P009 disappearing-zoom result is retained; no new zoom campaign was opened.
Curve Workbench GUI, ORION, SII, historical Sessions and canonical sources remain
outside the production delta.

Missing render manifests are normal `absent_legacy`; partial, unsupported and
stale/output_mismatch remain distinct. No PNG/default guessing, forced bulk
migration or false rendered-only Clone editability is supplied. An available
snapshot does not guarantee every renderer property is portable. Per-series
transfer requires matching ordinary2D topology; unsupported family/3D/Clone style
capabilities are listed. Numeric axes remain with the original compatible-unit
editor. Native3D/vector limitations inherited from P009 remain unchanged.

Mathematics bounds and sampled-calculus limits are documented in the model/API
manuals. No invented common grid joins disjoint domains; no C1 smoothing or
measurement uncertainty is inferred. The existing Numeric parser can refuse
registered semantic/nonlinear/custom aliases even when their Unit Registry
definition transports exactly; tests distinguish transport from numerical
admission. Intrinsic supported linear units retain their public semantics.
Original Native Fit can amplify machine-roundoff-sized variation in nearly
constant derivative traces (about1e-18 in the independent case). Actual samples
and units stay unchanged; this inherited presentation limit is not a new
precision or uncertainty claim.

Early development isolation declarations were qualified after application
storage.cache_dir/temp_dir were found to retain HOME defaults in several author
and validator harnesses. No unidentified/shared cache or scientific data was
deleted. Later tests read actual Configuration/Resource/Job roots and pin them to
allocated scratch. One earlier TECH orphan supervisor was retired only after
exact identity/no-descendant proof; retained evidence and original guard refusals
remain. Final acceptance must retain these qualifications, not rewrite earlier
runs as fully isolated. GUI accessibility evidence covers actual X11/Tk keyboard,
focus, labels, contrast/layout/scaling; screen-reader coverage is not inferred.

Final source/package/whole-release qualification is independent of this design
summary and is recorded in the delivery matrix. No production activation occurs.
