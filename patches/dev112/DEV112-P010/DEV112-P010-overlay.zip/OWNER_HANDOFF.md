# P010 owner handoff

P010 is developed exclusively in independent server scratch allocations from
immutable deposited P009. MAIN owns production integration and delivery. GUI
validation continues on verified Terra6.1 Medium; Technical remains Sol6.1 Low,
Scientific Sol6.1 High and MAIN Sol6.1 High. The original Sol GUI runtime remains
idle with its history/evidence preserved; in-place model reassignment was not
supported, so the Terra continuation reused the same role workspace/checkpoint.
No GUI descendant uses a silent Sol fallback.

The delivered scope is generic Dataset export/exact Sketch DXF, corrected Plot
colorbar precedence and actual render settings/Clone evidence, trusted GUI
presentation drafts/presets and a general domain-aware Mathematics model with
the separately approved bounded controls. The new reference Session contains
only synthetic2D21 Level-1 v0.1 theory from five explicitly published families.
It does not open/migrate the historical Session or invent measurements, uncertainty
or a current-family interpolation law. Generic Mathematics contains no valve mode.

Read INSTALLAZIONE.md before explicit installation/rollback, API_CONTRACTS.md for
public contracts and CORE_REUSE_AND_GAP_AUDIT.md for actual limits. The delivery
matrix identifies exact accepted candidate/package identities, independent tests,
closed findings, retained evidence and unexecuted scope. This document does not
replace those records or assert readiness before required final checks complete.
The remaining-work register contains only genuinely unfinished assignments.

All owner Sessions/scientific sources and deposited P009 remain preserved.
Curve Workbench GUI, ORION and SII are unchanged. Production launchers, services,
mounts and active installation are not switched. Delivering a package is separate
from activation. Preserve the external successful apply receipt and its separately
retained SHA for rollback; do not treat a failed/modified receipt as authority.
