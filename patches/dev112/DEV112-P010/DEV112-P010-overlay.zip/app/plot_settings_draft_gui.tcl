# SPDX-License-Identifier: GPL-3.0-or-later
# Commands attach only to the existing Plots list and original action handlers.
namespace eval ::GX::PlotSettingsGUI {variable draft {};variable token {};variable value {};variable colorbar 0}
proc ::GX::plotSettingsGuiCatch {command} {
    if {[catch {uplevel #0 $command} message]} {
        set parent .;set focused [focus]
        if {$focused ne {} && [winfo exists $focused]} {set parent [winfo toplevel $focused]}
        tk_messageBox -parent $parent -title {Plot settings} -icon error -message $message
    }
}
proc ::GX::_plotSettingsCurrentRef {} {
    set path [currentGraphPath]
    if {$path eq {}} {error {Select a plot first}}
    return [graphResourceRefForPath $path]
}
proc ::GX::_plotSettingsHold {profile} {
    set ::GX::PlotSettingsGUI::draft [plotPresentationProfileValidate $profile]
    set ::GX::PlotSettingsGUI::token [interactiveDocumentSessionToken]
}
proc ::GX::_plotSettingsDraft {} {
    if {$::GX::PlotSettingsGUI::draft eq {}} {error {Read a plot, load a Session preset, or import a presentation profile first}}
    if {$::GX::PlotSettingsGUI::token ne [interactiveDocumentSessionToken]} {error {Session changed; read or load the profile again before applying}}
    return $::GX::PlotSettingsGUI::draft
}
proc ::GX::plotSettingsReadCurrent {} {
    set reference [_plotSettingsCurrentRef];set status [dict get [plotRenderSettingsStatus $reference] status]
    if {$status ne {available}} {
        tk_messageBox -parent . -title {Last rendered plot settings} -icon info -message "Settings status: $status. A complete presentation draft is unavailable. Existing plots remain valid; no configuration is guessed or generated. A normal successful rerender creates new evidence."
        return
    }
    set result [plotPresentationProfileFromSnapshot $reference]
    _plotSettingsHold [dict get $result profile]
    plotSettingsDraftDialog "Last successful render: $reference\n[dict get $result scope]\nExcluded fields: [join [dict get $result omitted] {, }]"
}
proc ::GX::plotSettingsDraftDialog {{notice {Presentation draft; changes here take effect only after Apply}}} {
    set profile [_plotSettingsDraft];catch {destroy .plotSettingsDraft}
    toplevel .plotSettingsDraft;wm title .plotSettingsDraft {Plot presentation draft}
    ttk::label .plotSettingsDraft.note -text $notice -wraplength 620 -justify left
    grid .plotSettingsDraft.note -row 0 -column 0 -columnspan 2 -sticky ew -padx 10 -pady 8
    ttk::treeview .plotSettingsDraft.fields -columns {property value} -show headings -selectmode browse -height 16
    .plotSettingsDraft.fields heading property -text {Presentation property};.plotSettingsDraft.fields heading value -text {Draft value}
    .plotSettingsDraft.fields column property -width 280;.plotSettingsDraft.fields column value -width 200
    ttk::scrollbar .plotSettingsDraft.scroll -orient vertical -command {.plotSettingsDraft.fields yview}
    .plotSettingsDraft.fields configure -yscrollcommand {.plotSettingsDraft.scroll set}
    dict for {section values} [dict get $profile settings] {dict for {field value} $values {
        set label "[string totitle $section] / [string map {_ { }} $field]"
        set display $value
        if {[string is double -strict $value] && [expr {abs(double($value))<Inf}]} {set display [format %.12g $value]}
        .plotSettingsDraft.fields insert {} end -id $section.$field -values [list $label $display]
    }}
    set styleIndex 0
    foreach record [datasetPublicationV2DictDefault $profile series {}] {
        dict for {field value} [dict get $record style] {
            set label "Panel [expr {[dict get $record panel_index]+1}] / Series [expr {[dict get $record series_index]+1}] / [string map {_ { }} $field]"
            .plotSettingsDraft.fields insert {} end -id series:$styleIndex.$field -values [list $label $value]
        }
        incr styleIndex
    }
    grid .plotSettingsDraft.fields -row 1 -column 0 -sticky nsew -padx {10 0};grid .plotSettingsDraft.scroll -row 1 -column 1 -sticky ns -padx {0 10}
    ttk::frame .plotSettingsDraft.buttons
    foreach {name label command} {edit {Edit value...} ::GX::plotSettingsDraftEdit apply {Apply to selected plot...} ::GX::plotSettingsApplyCurrent save {Save as preset...} ::GX::plotSettingsSavePreset close Close {destroy .plotSettingsDraft}} {
        ttk::button .plotSettingsDraft.buttons.$name -text $label -command [list ::GX::plotSettingsGuiCatch $command]
        pack .plotSettingsDraft.buttons.$name -side left -padx 4
    }
    grid .plotSettingsDraft.buttons -row 2 -column 0 -columnspan 2 -sticky ew -padx 6 -pady 10
    grid columnconfigure .plotSettingsDraft 0 -weight 1;grid rowconfigure .plotSettingsDraft 1 -weight 1
    bind .plotSettingsDraft.fields <Return> {::GX::plotSettingsGuiCatch ::GX::plotSettingsDraftEdit}
    bind .plotSettingsDraft.fields <Double-1> {::GX::plotSettingsGuiCatch ::GX::plotSettingsDraftEdit}
    bind .plotSettingsDraft <Escape> {destroy .plotSettingsDraft}
    bind .plotSettingsDraft <Destroy> [list ::GX::plotSettingsDraftDestroyed %W]
    wm geometry .plotSettingsDraft 660x560;focus .plotSettingsDraft.fields
}
proc ::GX::plotSettingsDraftEdit {} {
    set row [.plotSettingsDraft.fields selection];if {[llength $row]!=1} {error {Select one presentation property}}
    lassign [split [lindex $row 0] .] section field
    set profile [_plotSettingsDraft]
    if {[regexp {^series:([0-9]+)$} $section unused index]} {set ::GX::PlotSettingsGUI::value [dict get [lindex [dict get $profile series] $index] style $field]
    } else {set ::GX::PlotSettingsGUI::value [dict get $profile settings $section $field]}
    catch {destroy .plotSettingsValue};toplevel .plotSettingsValue;wm title .plotSettingsValue {Edit presentation value}
    wm transient .plotSettingsValue .plotSettingsDraft
    ttk::label .plotSettingsValue.label -text [lindex [.plotSettingsDraft.fields item [lindex $row 0] -values] 0]
    ttk::entry .plotSettingsValue.value -textvariable ::GX::PlotSettingsGUI::value -width 36
    ttk::button .plotSettingsValue.ok -text {Use in draft} -command [list ::GX::plotSettingsGuiCatch [list ::GX::plotSettingsDraftValueSave $section $field]]
    ttk::button .plotSettingsValue.cancel -text Cancel -command ::GX::plotSettingsValueClose
    grid .plotSettingsValue.label -row 0 -column 0 -columnspan 2 -sticky w -padx 10 -pady 6
    grid .plotSettingsValue.value -row 1 -column 0 -columnspan 2 -sticky ew -padx 10 -pady 6
    grid .plotSettingsValue.ok -row 2 -column 0 -padx 10 -pady 10;grid .plotSettingsValue.cancel -row 2 -column 1 -padx 10 -pady 10
    grid columnconfigure .plotSettingsValue 0 -weight 1
    bind .plotSettingsValue <Return> [list ::GX::plotSettingsGuiCatch [list ::GX::plotSettingsDraftValueSave $section $field]]
    bind .plotSettingsValue <Escape> ::GX::plotSettingsValueClose
    bind .plotSettingsValue <ButtonPress> [list ::GX::plotSettingsValueOutsideClick %X %Y]
    wm protocol .plotSettingsValue WM_DELETE_WINDOW ::GX::plotSettingsValueClose
    update idletasks;grab set .plotSettingsValue
    focus .plotSettingsValue.value;.plotSettingsValue.value selection range 0 end
}
proc ::GX::plotSettingsDraftDestroyed {actual} {
    if {$actual eq {.plotSettingsDraft}} {plotSettingsValueClose}
}
proc ::GX::plotSettingsValueOutsideClick {x y} {
    if {![winfo exists .plotSettingsValue]} return
    set w .plotSettingsValue
    if {$x<[winfo rootx $w] || $y<[winfo rooty $w] || $x>=[winfo rootx $w]+[winfo width $w] || $y>=[winfo rooty $w]+[winfo height $w]} {
        after idle ::GX::plotSettingsValueRefocus
    }
}
proc ::GX::plotSettingsValueRefocus {} {
    if {[winfo exists .plotSettingsValue.value] && [grab current .] eq {.plotSettingsValue}} {focus -force .plotSettingsValue.value}
}
proc ::GX::plotSettingsValueClose {} {
    catch {grab release .plotSettingsValue};catch {destroy .plotSettingsValue}
    if {[winfo exists .plotSettingsDraft.fields]} {focus .plotSettingsDraft.fields}
}
proc ::GX::plotSettingsDraftValueSave {section field} {
    set profile [_plotSettingsDraft]
    if {[regexp {^series:([0-9]+)$} $section unused index]} {
        set records [dict get $profile series];set record [lindex $records $index]
        dict set record style $field $::GX::PlotSettingsGUI::value;lset records $index $record;dict set profile series $records
    } else {dict set profile settings $section $field $::GX::PlotSettingsGUI::value}
    plotPresentationProfileValidate $profile;_plotSettingsHold $profile
    plotSettingsValueClose;plotSettingsDraftDialog
}
proc ::GX::plotSettingsApplyCurrent {} {
    set reference [_plotSettingsCurrentRef];set profile [_plotSettingsDraft]
    set plan [plotPresentationApplyPlan $reference $profile]
    set mapping {}
    if {[dict exists $plan series_plan mapping]} {set mapping [join [dict get $plan series_plan mapping] {; }]}
    set message "Apply this presentation draft to $reference and rerender?\n\nTarget scientific data, series identities, formulas, title, labels and numeric axes are preserved.\n\nStyle mapping (matching panel/series positions, kinds and axes): $mapping\n\nFields unavailable for this target: [join [dict get $plan skipped] {, }]"
    if {[tk_messageBox -parent . -title {Apply plot presentation} -type okcancel -icon question -message $message] ne {ok}} return
    set path [_plotRenderSettingsArtifact $reference]
    # Confirmation can process events. Recheck identity/Session before commit.
    _plotSettingsDraft
    if {[_plotSettingsCurrentRef] ne $reference} {error {Selected plot changed; review the new target before applying}}
    plotPresentationApply $reference $profile
    startRerenderPaths [list $path]
}
proc ::GX::plotSettingsSavePreset {} {
    _plotSettingsDraft
    catch {destroy .plotPresetName};toplevel .plotPresetName;wm title .plotPresetName {Save Session presentation preset}
    set ::GX::PlotSettingsGUI::name {}
    ttk::label .plotPresetName.label -text {Preset name}
    ttk::entry .plotPresetName.name -textvariable ::GX::PlotSettingsGUI::name -width 36
    ttk::button .plotPresetName.save -text Save -command {::GX::plotSettingsGuiCatch ::GX::plotSettingsPresetStore}
    ttk::button .plotPresetName.cancel -text Cancel -command {destroy .plotPresetName}
    grid .plotPresetName.label .plotPresetName.name -padx 8 -pady 8
    grid .plotPresetName.save .plotPresetName.cancel -padx 8 -pady 8
    bind .plotPresetName <Return> {::GX::plotSettingsGuiCatch ::GX::plotSettingsPresetStore}
    bind .plotPresetName <Escape> {destroy .plotPresetName};focus .plotPresetName.name
}
proc ::GX::plotSettingsPresetStore {} {
    set name $::GX::PlotSettingsGUI::name
    if {[dict exists [plotPresentationPresets] $name] && [tk_messageBox -parent .plotPresetName -type okcancel -icon question -message "Replace Session preset '$name'?"] ne {ok}} return
    plotPresentationPresetSave $name [_plotSettingsDraft];destroy .plotPresetName
}
proc ::GX::plotSettingsPresetChooser {} {
    set profiles [plotPresentationPresets];catch {destroy .plotPresets};toplevel .plotPresets;wm title .plotPresets {Session presentation presets}
    ttk::label .plotPresets.note -text {Load creates a draft. Apply is a separate action on the selected plot.} -wraplength 440
    listbox .plotPresets.names -height 12 -exportselection 0
    foreach name [lsort -dictionary [dict keys $profiles]] {.plotPresets.names insert end $name}
    ttk::scrollbar .plotPresets.scroll -orient vertical -command {.plotPresets.names yview};.plotPresets.names configure -yscrollcommand {.plotPresets.scroll set}
    ttk::button .plotPresets.load -text {Load draft} -command {::GX::plotSettingsGuiCatch {::GX::plotSettingsPresetChoose load}}
    ttk::button .plotPresets.delete -text Delete -command {::GX::plotSettingsGuiCatch {::GX::plotSettingsPresetChoose delete}}
    ttk::button .plotPresets.close -text Close -command {destroy .plotPresets}
    grid .plotPresets.note -row 0 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 8
    grid .plotPresets.names -row 1 -column 0 -columnspan 2 -sticky nsew -padx {8 0};grid .plotPresets.scroll -row 1 -column 2 -sticky ns
    grid .plotPresets.load .plotPresets.delete .plotPresets.close -row 2 -padx 8 -pady 8
    grid columnconfigure .plotPresets 0 -weight 1;grid rowconfigure .plotPresets 1 -weight 1
    bind .plotPresets <Escape> {destroy .plotPresets};bind .plotPresets.names <Return> {::GX::plotSettingsGuiCatch {::GX::plotSettingsPresetChoose load}}
    focus .plotPresets.names
}
proc ::GX::plotSettingsPresetChoose {action} {
    set selected [.plotPresets.names curselection];if {[llength $selected]!=1} {error {Select one named preset}}
    set name [.plotPresets.names get [lindex $selected 0]]
    if {$action eq {delete}} {plotPresentationPresetDelete $name;plotSettingsPresetChooser;return}
    _plotSettingsHold [dict get [plotPresentationPresets] $name];destroy .plotPresets;plotSettingsDraftDialog "Session preset: $name"
}
proc ::GX::plotSettingsImportConf {} {
    set path [tk_getOpenFile -parent . -title {Import presentation profile} -filetypes {{{Presentation JSON} {.json}} {{All files} *}}]
    if {$path eq {}} return
    _plotSettingsHold [plotPresentationProfileReadFile $path];plotSettingsDraftDialog {Imported presentation profile; nothing has been applied}
}
proc ::GX::plotSettingsExportConf {} {
    set profile [_plotSettingsDraft]
    set path [tk_getSaveFile -parent . -title {Export presentation profile} -defaultextension .json -initialfile plot-presentation.json]
    if {$path eq {}} return
    plotPresentationProfileExport $profile $path
}
proc ::GX::plotSettingsColorbarCurrent {} {
    set reference [_plotSettingsCurrentRef]
    if {[dict get $reference kind] ne {provider} || [dict get $reference module_id] ne {plot.dataset} || [dict get $reference graph_id] ne {plot.dataset.xyz}} {error {Selected plot has no supported scalar colorbar}}
    set profile [dict create schema PLOT_PRESENTATION_PROFILE_v1 version 1 dimension 3 settings [dict create graphics [dict create colorbar_visible $::GX::PlotSettingsGUI::colorbar]]]
    plotPresentationApply $reference $profile;startRerenderPaths [list [_plotRenderSettingsArtifact $reference]]
}
proc ::GX::plotSettingsContext {tree x y screenX screenY {keyboard 0}} {
    if {$keyboard} {set row [$tree focus]} else {set row [$tree identify row $x $y]}
    if {$row eq {}} return
    $tree selection set $row;$tree focus $row;previewGraph
    set menu .plotRowContext;catch {destroy $menu};menu $menu -tearoff 0
    foreach {label widget} {Open openfull Rerender one {Axes / grid...} axes {Legend...} legend {Graph information...} info} {
        set action .top.nb.graphs.actions.$widget
        $menu add command -label $label -state [expr {[$action instate disabled]?{disabled}:{normal}}] -command [list $action invoke]
    }
    if {![catch {set ref [_plotSettingsCurrentRef]}] && [dict get $ref kind] eq {provider} && [dict get $ref module_id] eq {plot.dataset} && [dict get $ref graph_id] eq {plot.dataset.xyz}} {
        modulePublicApiActivate plot.dataset PLOT_DATASET_API_v4
        set spec [::GX::PlotDatasetAPIv4::loadSpec $ref]
        set config [datasetPublicationV2DictDefault $spec config {}];set type [datasetPublicationV2DictDefault $config plot_type line3]
        if {$type in {surface mesh contour3 trisurf heatmap} || ($type eq {scatter3} && [dict exists $spec color_variable_id])} {
            set effective [graphRendererEffectiveSpec $ref $spec]
            set ::GX::PlotSettingsGUI::colorbar [datasetPublicationV2DictDefault [dict get $effective native_presentation graphics] colorbar_visible 0]
            $menu add checkbutton -label {Colorbar visible} -variable ::GX::PlotSettingsGUI::colorbar -command {::GX::plotSettingsGuiCatch ::GX::plotSettingsColorbarCurrent}
        }
    }
    $menu add separator
    foreach {label command} {{Read plot settings} ::GX::plotSettingsReadCurrent {Apply current settings...} ::GX::plotSettingsApplyCurrent {Apply preset...} ::GX::plotSettingsPresetChooser {Save settings as preset...} ::GX::plotSettingsSavePreset} {$menu add command -label $label -command [list ::GX::plotSettingsGuiCatch $command]}
    tk_popup $menu $screenX $screenY
}
proc ::GX::plotSettingsGuiInstall {} {
    set tree .top.nb.graphs.tree
    bind $tree <Button-3> {::GX::plotSettingsGuiCatch {::GX::plotSettingsContext %W %x %y %X %Y};break}
    bind $tree <Menu> {::GX::plotSettingsGuiCatch {::GX::plotSettingsContext %W 0 0 [winfo rootx %W] [winfo rooty %W] 1};break}
    bind $tree <Shift-F10> [bind $tree <Menu>]
    set menu .top.nb.graphs.buttons.transport.menu
    $menu add separator
    $menu add command -label {Import conf...} -command {::GX::plotSettingsGuiCatch ::GX::plotSettingsImportConf}
    $menu add command -label {Export conf...} -command {::GX::plotSettingsGuiCatch ::GX::plotSettingsExportConf}
}
