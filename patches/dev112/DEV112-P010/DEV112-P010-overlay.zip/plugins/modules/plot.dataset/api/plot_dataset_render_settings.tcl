# SPDX-License-Identifier: GPL-3.0-or-later
# The producing Plot renderer owns presentation field types. The normalized
# reader never reverse engineers a PlotSpec or duplicates this property catalog.
proc ::GX::PlotDatasetAPIv4::renderSettingsFieldTypes {section {graph plot.dataset.xy}} {
    set types {}
    switch -- $section {
        graphics {
            foreach field [::GX::moduleGraphicsFields] {dict set types $field text}
            foreach field {width_px height_px dpi font_size axis_label_font_size title_font_size line_width legend_columns legend_font_size legend_margin_px view_azimuth view_elevation color_min color_max} {dict set types $field number}
            foreach field {colorbar_visible legend_border} {dict set types $field boolean}
        }
        legend {
            foreach field {placement inside_preset layout alignment font_unit background border_color} {dict set types $field text}
            foreach field {columns font_size margin_px external_margin_px manual_x manual_y} {dict set types $field number}
            foreach field {border source_override_enabled} {dict set types $field boolean}
        }
        axes {
            foreach {field default} [::GX::plot3dAxisFieldDefaults] {dict set types $field text}
            foreach field {enabled align_ylabels} {dict set types $field boolean}
            foreach field {x_unit y_unit y2_unit z_unit time_unit ylabel_x ygrid_source grid_color} {dict set types $field text}
            foreach prefix {x y y2 z} {foreach field {min max step} {dict set types ${prefix}_$field number}}
            foreach field {view_azimuth view_elevation color_min color_max ylabel_x} {dict set types $field number}
            dict set types colorbar_visible boolean
            foreach field {x_level_scale y_level_scale y2_level_scale z_level_scale} {dict set types $field dictionary}
        }
        layout {
            foreach field {layout_auto align_ylabels layout_ylabel_allow_negative} {dict set types $field boolean}
            foreach field {layout_margin_left layout_margin_right layout_margin_top layout_margin_bottom layout_gap layout_ylabel_dist layout_ylabel_x layout_legend_dist layout_title_dist} {dict set types $field number}
        }
        style {
            foreach field {color line_style marker marker_edge_color marker_face_color marker_fill fill_color edge_color hatch} {dict set types $field text}
            foreach field {line_width marker_size opacity fill_opacity edge_width} {dict set types $field number}
        }
        plot_config {
            set graphFields [::GX::moduleGraphConfigKeys plot.dataset $graph]
            foreach field [lsort -unique [concat [::GX::moduleConfigKeys plot.dataset] $graphFields]] {
                if {$field in $graphFields} {set declared [::GX::moduleGraphConfigField plot.dataset $graph $field type string]} else {set declared [::GX::moduleConfigField plot.dataset $field type string]}
                dict set types $field [expr {$declared in {number double integer}?{number}:$declared eq {boolean}?{boolean}:{text}}]
            }
        }
        model_axis {
            foreach field {label display_unit scale direction format grid major_grid minor_grid grid_source tick_label_mode tick_format} {dict set types $field text}
            foreach field {min max major_step label_position_x} {dict set types $field number}
            foreach field {tick_positions} {dict set types $field vector}
            foreach field {tick_labels} {dict set types $field text_vector}
        }
        default {error {Unknown renderer presentation section}}
    }
    return $types
}
proc ::GX::PlotDatasetAPIv4::_renderSettingsValue {type value} {
    switch -- $type {
        text {return [list text $value]}
        number {
            if {$value in {{} auto inherit source}} {return [list text $value]}
            if {![string is double -strict $value] || ![expr {abs(double($value))<Inf}]} {error {Renderer presentation number is not finite}}
            return [list real $value]
        }
        boolean {
            if {$value in {{} auto inherit}} {return [list text $value]}
            if {![string is boolean -strict $value]} {error {Renderer presentation flag is not boolean}}
            return [list bool [expr {!!$value}]]
        }
        vector {
            set values [lsearch -all -inline -not -exact [split [string map {; { }} $value]] {}]
            return [::GX::nativeWorkspaceEncode {array real} $values]
        }
        text_vector {return [::GX::nativeWorkspaceEncode {array text} $value]}
        dictionary {return [::GX::nativeWorkspaceEncode {map text} $value]}
        default {error {Unsupported renderer presentation field type}}
    }
}
proc ::GX::PlotDatasetAPIv4::_renderSettingsMap {section values {graph plot.dataset.xy}} {
    set types [renderSettingsFieldTypes $section $graph];set fields {};set extensions {}
    dict for {key value} $values {
        if {$key in {prepared_source}} continue
        if {[dict exists $types $key]} {dict set fields $key [_renderSettingsValue [dict get $types $key] $value]} else {
            # Unknown fields stay explicitly renderer-specific and are not
            # automatically made transferable presentation properties.
            dict set extensions $key {text unsupported_unregistered_field}
        }
    }
    return [dict create fields [list object $fields] extensions [list object $extensions]]
}
proc ::GX::PlotDatasetAPIv4::_renderSettingsPresentation {model {receipt {}} {descriptor {}} {renderReceipt {}} {resolvedMetadata {}}} {
    set graph [_get $model graph_id plot.dataset.xy];set np [_get $model native_presentation {}]
    set graphics [_get $np graphics {}];set sections [dict create title [list text [_get $model title {}]]];set extensions {}
    foreach section {graphics legend axes layout plot_config} {
        set encoded [_renderSettingsMap $section [_get $np $section {}] $graph]
        dict set sections $section [dict get $encoded fields]
        dict set extensions $section [dict get $encoded extensions]
    }
    set panelOverrides {}
    dict for {id values} [_get $np panels {}] {
        set encoded [_renderSettingsMap axes $values $graph]
        dict set panelOverrides $id [dict get $encoded fields]
        dict set extensions panel_$id [dict get $encoded extensions]
    }
    dict set sections panel_overrides [list object $panelOverrides]
    set defaults [_renderSettingsMap style [_get [_get $model defaults {}] style {}] $graph]
    dict set sections default_style [dict get $defaults fields]
    dict set extensions default_style [dict get $defaults extensions]
    set width [_get $receipt width [_get $graphics width_px 1000]]
    set height [_get $receipt height [_get $graphics height_px 720]]
    dict set sections canvas [::GX::nativeWorkspaceEncode {record {width_px int height_px int dpi real background text}} \
        [dict create width_px $width height_px $height dpi [_get $graphics dpi 100] background [_get $graphics background #FFFFFF]]]
    set panels {};set effectiveAxes {}
    foreach panel [_get $model panels {}] {
        set axes {};dict for {axis values} [_get $panel axes {}] {
            set encoded [_renderSettingsMap model_axis $values $graph]
            dict set axes $axis [dict get $encoded fields]
            dict set effectiveAxes [dict get $panel id].$axis [dict get $encoded extensions]
        }
        set series {}
        foreach trace [_get $panel series {}] {
            set encoded [_renderSettingsMap style [_get $trace style {}] $graph]
            dict set extensions style_[dict get $trace id] [dict get $encoded extensions]
            lappend series [list object [dict create id [list text [dict get $trace id]] label [list text [_get $trace label {}]] \
                kind [list text [_get $trace kind line]] axis [list text [_get $trace axis left]] style [dict get $encoded fields]]]
        }
        lappend panels [list object [dict create id [list text [dict get $panel id]] title [list text [_get $panel title {}]] axes [list object $axes] series [list array $series]]]
    }
    dict set sections panels [list array $panels]
    dict set extensions model_axes [list object $effectiveAxes]
    if {$receipt ne {}} {
        set axes {}
        foreach axis [_get $receipt axes {}] {
            lappend axes [::GX::nativeWorkspaceEncode {record {panel_id text axis text limits {array real} plot_rect {array real} scale text direction text aspect text ticks {array {record {value real display_value real label text device real}}}}} $axis]
        }
        set legends [::GX::nativeWorkspaceEncode {array {record {panel_id text placement text alignment text box {array real} metrics_owner text clamped bool requested_center {array real} items {array {record {series_id text label text text_box {array real}}}}}}} [_get $receipt legends {}]]
        dict set sections renderer_receipt [list object [dict create owner [list text [_get $receipt owner Native2D]] \
            width_px [list int $width] height_px [list int $height] axes [list array $axes] legends $legends]]
    }
    if {$descriptor ne {}} {
        set view {};set viewTypes [dict create projection text camera_position vector camera_target vector camera_up vector near_clip number far_clip number orthographic_height number vertical_fov_degrees number clip_box vector background_rgb vector background_bottom_rgb vector]
        dict for {key value} [dict get $descriptor view] {if {[dict exists $viewTypes $key]} {dict set view $key [_renderSettingsValue [dict get $viewTypes $key] $value]}}
        set figure [dict get $descriptor scientific_figure];set figureFields {}
        foreach key {x_label y_label z_label title legend scalar_label} {if {[dict exists $figure $key]} {dict set figureFields $key [list text [dict get $figure $key]]}}
        foreach key {colorbar_visible axes_grid_visible} {if {[dict exists $figure $key]} {dict set figureFields $key [list bool [dict get $figure $key]]}}
        foreach key {scalar_min scalar_max} {if {[dict exists $figure $key]} {dict set figureFields $key [list real [dict get $figure $key]]}}
        foreach key {axis_min axis_max bounds_min bounds_max} {if {[dict exists $figure $key]} {dict set figureFields $key [_renderSettingsValue vector [dict get $figure $key]]}}
        if {[dict exists $figure physical_axis_ranges]} {dict set figureFields physical_axis_ranges [::GX::nativeWorkspaceEncode {array {array real}} [dict get $figure physical_axis_ranges]]}
        if {[dict exists $figure tick_labels]} {dict set figureFields tick_labels [::GX::nativeWorkspaceEncode {array {array text}} [dict get $figure tick_labels]]}
        if {[dict exists $figure palette]} {
            set palette {};foreach rgb [dict get $figure palette] {lappend palette [_renderSettingsValue vector $rgb]}
            dict set figureFields palette [list array $palette]
        }
        if {[dict exists $figure native_style]} {dict set figureFields native_style [::GX::nativeWorkspaceEncode {map text} [dict get $figure native_style]]}
        if {[dict exists $figure aspect_policy]} {dict set figureFields aspect_policy [::GX::nativeWorkspaceEncode {map text} [dict get $figure aspect_policy]]}
        set layerStyles {}
        dict for {id layer} [dict get $descriptor layers] {
            set fields {}
            foreach key {kind representation colormap} {if {[dict exists $layer $key]} {dict set fields $key [list text [dict get $layer $key]]}}
            foreach key {opacity line_width point_size} {if {[dict exists $layer $key]} {dict set fields $key [list real [dict get $layer $key]]}}
            foreach key {visible sphere_glyphs} {if {[dict exists $layer $key]} {dict set fields $key [_renderSettingsValue boolean [dict get $layer $key]]}}
            dict set layerStyles $id [list object $fields]
        }
        set accepted {}
        foreach key {camera_position camera_target camera_up} {if {[dict exists $renderReceipt $key]} {dict set accepted $key [::GX::nativeWorkspaceEncode {array real} [dict get $renderReceipt $key]]}}
        foreach key {near_clip far_clip vertical_fov_degrees} {if {[dict exists $renderReceipt $key]} {dict set accepted $key [list real [dict get $renderReceipt $key]]}}
        if {[dict exists $renderReceipt projection]} {dict set accepted projection [list text [dict get $renderReceipt projection]]}
        dict set sections native_3d [list object [dict create submitted_view [list object $view] submitted_figure [list object $figureFields] submitted_layers [list object $layerStyles] accepted_camera [list object $accepted] axis_units [::GX::nativeWorkspaceEncode {map text} [_get $resolvedMetadata axis_units {}]] \
            verification {text descriptor_before_cleanup_and_available_render_receipt}]]
    }
    return [list object [dict create schema {text PLOT_RENDERER_PRESENTATION_v1} version {int 1} \
        dimension [list int [expr {$descriptor eq {}?2:3}]] settings [list object $sections] renderer_extensions [list object $extensions]]]
}
proc ::GX::PlotDatasetAPIv4::_renderSettingsCompleteness {presentation} {
    set extensions [dict get [lindex $presentation 1] renderer_extensions]
    if {[_renderSettingsHasUnsupported $extensions]} {return partial}
    return available
}
proc ::GX::PlotDatasetAPIv4::_renderSettingsFileArtifact {id source destination} {
    return [dict create id $id destination $destination writer [list ::GX::_filePublicationCopyWriter $source [::GX::sha256File $source]]]
}

proc ::GX::PlotDatasetAPIv4::_renderSettingsHasUnsupported {node} {
    if {[lindex $node 0] eq {text}} {return [expr {[lindex $node 1] eq {unsupported_unregistered_field}}]}
    if {[lindex $node 0] eq {object}} {
        dict for {key child} [lindex $node 1] {if {[_renderSettingsHasUnsupported $child]} {return 1}}
    }
    return 0
}
