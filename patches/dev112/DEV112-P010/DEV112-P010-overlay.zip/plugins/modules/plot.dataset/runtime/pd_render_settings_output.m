% SPDX-License-Identifier: GPL-3.0-or-later
% Extra outputs share the producing renderer's owned staging transaction.
function target=pd_render_settings_output(fig,target)
  if(isappdata(fig,'gxtxt_render_settings_pending'))
    pending=getappdata(fig,'gxtxt_render_settings_pending');target=pending.png;
  endif
endfunction
