% SPDX-License-Identifier: GPL-3.0-or-later
% The original producing renderer records its resolved style and exact logical
% panel/series position. No samples, Dataset bindings or inferred PNG data.
function pd_render_settings_series(fig,S,kind,style,panel_index,series_index,panel_count,series_count)
  records={};key='gxtxt_render_settings_series';
  if(isappdata(fig,key)),records=getappdata(fig,key);endif
  style.color=sprintf('#%02X%02X%02X',round(255*min(1,max(0,style.color))));
  record=struct('panel_index',panel_index,'series_index',series_index,'panel_count',panel_count, ...
    'series_count',series_count,'kind',kind,'axis',S.axis,'style',style);
  records{end+1}=record;setappdata(fig,key,records);
endfunction
