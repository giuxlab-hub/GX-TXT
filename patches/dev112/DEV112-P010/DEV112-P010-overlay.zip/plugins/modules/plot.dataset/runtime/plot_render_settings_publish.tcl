# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted producer worker; no Bridge operation or caller-supplied callback.
if {[llength $argv]!=3} {error {Usage: plot_render_settings_publish.tcl target staged_png producer_receipt}}
lassign $argv target png receipt
set framework [file dirname [file dirname [file dirname [file dirname [file dirname [file normalize [info script]]]]]]]
set argv0 __gxtxt_plot_render_settings_publisher__
source [file join $framework gxtxt_pipeline.tcl]
::GX::defaults;::GX::loadModuleCatalog
if {![file isfile $receipt] || [file size $receipt]>1048576} {error {Invalid bounded producer receipt}}
set stream [open $receipt r]
try {fconfigure $stream -encoding utf-8;set typed [::GX::nativeWorkspaceJsonDecode [read $stream 1048577]]} finally {close $stream}
set request [::GX::nativeWorkspaceDecode $typed]
if {[dict get $request schema] ne {PLOT_RENDER_PRODUCER_RECEIPT_v1} || [dict get $request version]!=1} {error {Unsupported producer receipt}}
set graph [dict get $request graph_id];set variant [dict get $request variant_id]
if {$graph ni {plot.dataset.xy plot.dataset.xy_region plot.dataset.xyz} || ![regexp {^([A-Za-z][A-Za-z0-9_-]{0,63})?$} $variant]} {error {Invalid producing graph identity}}
set presentation [dict get [lindex $typed 1] presentation]
if {[lindex $presentation 0] ne {object}} {error {Presentation must be a typed object}}
set target [file normalize $target];set png [file normalize $png]
if {[file dirname [file dirname $png]] ne [file dirname $target] || ![string match {.gxtxt-render-*} [file tail [file dirname $png]]] || [file tail $png] ne [file tail $target] || [file extension $target] ne {.png} || ![file isfile $png]} {error {Producer PNG staging is invalid}}
set session [file normalize [dict get $request session]]
set persistent [expr {[string first "$session/analysis/" $target]==0}]
set cloneDescriptor [file join [file dirname $target] clone.ini]
if {[file isfile $cloneDescriptor]} {
    set clone [::GX::parseIni $cloneDescriptor]
    if {[dict get $clone clone.capture_mode] ne {scientific} || ![regexp {^c[0-9]{6}$} [dict get $clone clone.id]]} {error {Unsupported Clone output identity}}
    set reference [dict create kind clone clone_id [dict get $clone clone.id]]
    set extensions [list object [dict create clone [list object [dict create capture_mode {text scientific} scientific_editable {bool 1} settings_origin {text clone_owned_producer_receipt}]]]]
    set manifest [::GX::_plotRenderSettingsBuildForOutput $reference $target PLOT_DATASET_API_v3 Octave $presentation $png available $extensions]
    set destination $target.render-settings.json
} elseif {$persistent} {
    set reference [dict create kind provider module_id plot.dataset graph_id $graph variant_id $variant]
    set manifest [::GX::_plotRenderSettingsBuildForOutput $reference $target PLOT_DATASET_API_v3 Octave $presentation $png available {object {}}]
    set destination $target.render-settings.json
} else {
    # Detached snapshot workers own a separate lifecycle. Their parent binds
    # this exact producer receipt to a new Clone identity after admission.
    set manifest [list object [dict create schema {text PLOT_RENDER_PRODUCER_RECEIPT_v1} version {int 1} presentation $presentation \
        renderer_api {text PLOT_DATASET_API_v3} backend {text Octave} png_sha256 [list text [::GX::sha256File $png]]]]
    set destination $target.presentation.json
}
set json [::GX::nativeWorkspaceJsonEncode $manifest]
set artifacts [list [dict create id png destination $target writer [list ::GX::_filePublicationCopyWriter $png [::GX::sha256File $png]]] \
    [dict create id render_settings destination $destination writer [list ::GX::_plotRenderSettingsWrite $json]]]
set base [file rootname [file tail $target]]
foreach relative [list [file join .gxtxt_plotmeta $base.ini] [file join .gxtxt_plotmeta $base.xrange.ini] $base.svg $base.pdf] {
    set source [file join [file dirname $png] $relative]
    if {[file isfile $source]} {lappend artifacts [dict create id sidecar_[llength $artifacts] destination [file join [file dirname $target] $relative] writer [list ::GX::_filePublicationCopyWriter $source [::GX::sha256File $source]]]}
}
::GX::filePublicationPublishBundle $artifacts replace {create_parents 1}
