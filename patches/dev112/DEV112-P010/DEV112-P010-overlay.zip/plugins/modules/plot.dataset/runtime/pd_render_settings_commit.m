% SPDX-License-Identifier: GPL-3.0-or-later
function pd_render_settings_commit(fig)
  if(!isappdata(fig,'gxtxt_render_settings_pending')),return;endif
  pending=getappdata(fig,'gxtxt_render_settings_pending');context=getappdata(fig,'gxtxt_render_settings_context');
  request=struct('schema','PLOT_RENDER_PRODUCER_RECEIPT_v1','version',1,'graph_id',context.graph,'variant_id',context.variant, ...
    'session',context.session,'presentation',pending.presentation);
  path=[pending.png '.presentation.json'];
  unwind_protect
    text=jsonencode(request);if(numel(text)>1048576),error('GXTXT:RenderSettings','Producer receipt exceeds 1 MiB');endif
    fid=fopen(path,'w');if(fid<0),error('GXTXT:RenderSettings','Cannot stage producer receipt');endif
    unwind_protect,fputs(fid,text);unwind_protect_cleanup,fclose(fid);end_unwind_protect
    helper=fullfile(fileparts(mfilename('fullpath')),'plot_render_settings_publish.tcl');
    command=sprintf('tclsh %s %s %s %s',shell_quote(helper),shell_quote(pending.target),shell_quote(pending.png),shell_quote(path));
    [status,output]=system(command);
    if(status!=0),error('GXTXT:RenderSettings','Paired render publication failed: %s',output);endif
    rmappdata(fig,'gxtxt_render_settings_pending');
    stage=getappdata(fig,'gxtxt_render_settings_stage');
    if(exist(stage,'dir')==7),rmdir(stage,'s');endif
    rmappdata(fig,'gxtxt_render_settings_stage');
  unwind_protect_cleanup
    if(exist(path,'file')==2),unlink(path);endif
  end_unwind_protect
endfunction

function q=shell_quote(value)
  q=['''' strrep(value,'''','''\''''') ''''];
endfunction
