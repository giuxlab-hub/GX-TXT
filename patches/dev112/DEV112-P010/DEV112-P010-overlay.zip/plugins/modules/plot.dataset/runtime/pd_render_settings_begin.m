% SPDX-License-Identifier: GPL-3.0-or-later
function lifetime=pd_render_settings_begin(fig,cfg,graph,pcfg,dimension)
  context=struct('graphics',pcfg,'dimension',dimension,'graph',graph, ...
    'variant',gxtxt_ini_get(cfg,'plot_variant.variant_id',''),'session',gxtxt_ini_get(cfg,'runtime.session',''));
  % Transient curves have no persistent evidence obligation. Detached snapshot
  % renders with a private Session emit a producer receipt for their owner.
  if(isempty(context.session)),lifetime=[];return;endif
  setappdata(fig,'gxtxt_render_settings_context',context);
  lifetime=onCleanup(@() cleanup_pending(fig));
endfunction

function cleanup_pending(fig)
  if(!ishandle(fig)),return;endif
  if(isappdata(fig,'gxtxt_render_settings_stage'))
    stage=getappdata(fig,'gxtxt_render_settings_stage');
    if(exist(stage,'dir')==7),rmdir(stage,'s');endif
    rmappdata(fig,'gxtxt_render_settings_stage');
  endif
endfunction
