# Sketch Dataset CAD DXF export

Export a published canonical `geometry.sketch` v1 Dataset from the main Dataset
Browser: right-click its row → **Export as… → CAD DXF…**, or activate it and use
**Dataset Actions → Export as… → CAD DXF…**. Choose a declared output length unit
(mm, cm, m or in), optionally include finite reference/construction geometry,
then choose a new external
`.dxf` file. Existing destinations are refused. Cancel creates no output.

The exporter is independent of Curve Workbench: its existing **Publish / Export
as Sketch Dataset…** already provides the canonical source. No open Viewer is
required and any producer satisfying the same contract is eligible. Disable or
uninstall `export.sketch_dxf` through the existing Module/Plugin controls and its
action disappears from both Dataset Browser menus. Standard ZIP export remains.

The ASCII DXF uses AC1015 (AutoCAD 2000) model space and `$INSUNITS`, with LINE,
LWPOLYLINE, CIRCLE, ARC, ELLIPSE and nonrational degree2/3 SPLINE entities. Retained
Bezier curves map directly to clamped splines. Native2D extracts each exact cubic
Spline span, including explicit tangent arms. Compound/ordered Path leaves retain
original affine transforms, orientation and independent contours; no connectors,
axis decoration, display LOD or pixels are exported. Physical X/Y Unit Registry
conversions precede CAD serialization. Nonuniform circle transforms produce exact
ellipses, including elliptical arcs; reflected/signed sweeps retain their locus.
Calculations and 17-digit text use binary64 precision, not a tolerance-based
polyline approximation. Singular or unrepresentable geometry fails explicitly.

X/Y must declare coherent proportional physical length units. Unitless, incompatible
or affine-offset coordinate units are refused; the selected output unit does not
assign missing source units. Infinite construction lines are omitted explicitly;
reference points and objects explicitly marked `gx.geometry_role=reference` or
`construction` are omitted unless requested. Finite opted-in objects retain their
exact geometry, and the receipt retains their source role; DXF solver/construction
constraints are not synthesized. The public `in` choice uses the existing CORE
Unit Registry's scale-registration mechanism (exactly 0.0254 metres per inch),
with DXF INSUNITS1. The structured receipt reports
omissions and object-to-entity mapping, units, source hashes and topology. Only
geometric entities are transferred: GX-TXT parametric/solver constraints and
provenance are not turned into executable CAD constraints. Source data remain
unchanged. No DXF importer, CAD kernel or new Viewer is included. Import the DXF
into external CAD as a 2D sketch; use existing `acq.geometry_3d` for supported
STEP/STL reimports created externally.

Format references: [Autodesk SPLINE](https://help.autodesk.com/cloudhelp/2024/ENU/AutoCAD-DXF/files/GUID-E1F884F8-AA90-4864-A215-3182D47A9C74.htm),
[LWPOLYLINE](https://help.autodesk.com/cloudhelp/2026/ENU/AutoCAD-DXF/files/GUID-748FC305-F3F2-4F74-825A-61F04D757A50.htm),
and [INSUNITS](https://help.autodesk.com/cloudhelp/2025/ENU/AutoCAD-Core/files/GUID-A58A87BB-482B-4042-A00A-EEF55A2B4FD8.htm).

Public host adapter `::GX::SketchDXF::export request` accepts the versioned
Dataset Export request and returns the bounded byte/geometry/provenance receipt
specified by `DATASET_EXPORT_PROVIDER_API_v1`. CORE owns destination selection,
source-state revalidation and File Publication. No new Script Bridge writer.
