# Sketch Dataset CAD DXF

Independently installable export module for the matching DEV112-P010 CORE Dataset
Export Provider API. Both original Dataset Browsers discover it through the same
enabled-provider metadata owner. No Curve Workbench GUI dependency is introduced.

Exports exact canonical published geometry.sketch v1 primitives in explicit
physical model-space units. Unsupported geometry/units fail before create-only
File Publication. Scientific source data and Sessions are never rewritten.
Read [the manual](MANUAL.md) for entities, transforms, supported units and bounds.

SPDX-License-Identifier: GPL-3.0-or-later.
