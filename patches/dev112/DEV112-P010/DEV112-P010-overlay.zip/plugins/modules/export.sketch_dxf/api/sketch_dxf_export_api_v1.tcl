# SPDX-License-Identifier: GPL-3.0-or-later
# Retained scientific geometry to DXF; never consume display samples or pixels.
namespace eval ::GX::SketchDXF {}
proc ::GX::SketchDXF::_number {value} {
    if {![string is double -strict $value] || ![expr {abs(double($value))<Inf}]} {error {DXF coordinates must be finite}}
    return [format %.17g $value]
}
proc ::GX::SketchDXF::_pair {code value} {return "$code\r\n$value\r\n"}
proc ::GX::SketchDXF::_xyz {code point} {
    lassign $point x y
    return "[_pair $code [_number $x]][_pair [expr {$code+10}] [_number $y]][_pair [expr {$code+20}] 0]"
}
proc ::GX::SketchDXF::_world {definition point scales {vector 0}} {
    lassign [::GX::datasetPublicationV2DictDefault $definition matrix {1 0 0 1 0 0}] a b c d tx ty
    lassign $point x y;lassign $scales sx sy
    if {$vector} {set tx 0;set ty 0}
    return [list [expr {$sx*($a*$x+$b*$y+$tx)}] [expr {$sy*($c*$x+$d*$y+$ty)}]]
}
proc ::GX::SketchDXF::_header {unit} {
    set code [dict get {in 1 mm 4 cm 5 m 6} $unit]
    set result "0\r\nSECTION\r\n2\r\nHEADER\r\n9\r\n\$ACADVER\r\n1\r\nAC1015\r\n9\r\n\$INSUNITS\r\n70\r\n$code\r\n9\r\n\$MEASUREMENT\r\n70\r\n[expr {$unit eq {in}?0:1}]\r\n0\r\nENDSEC\r\n"
    append result "0\r\nSECTION\r\n2\r\nTABLES\r\n0\r\nTABLE\r\n2\r\nLTYPE\r\n5\r\n2\r\n100\r\nAcDbSymbolTable\r\n70\r\n1\r\n0\r\nLTYPE\r\n5\r\n3\r\n330\r\n2\r\n100\r\nAcDbSymbolTableRecord\r\n100\r\nAcDbLinetypeTableRecord\r\n2\r\nCONTINUOUS\r\n70\r\n0\r\n3\r\nSolid line\r\n72\r\n65\r\n73\r\n0\r\n40\r\n0\r\n0\r\nENDTAB\r\n"
    append result "0\r\nTABLE\r\n2\r\nLAYER\r\n5\r\n4\r\n100\r\nAcDbSymbolTable\r\n70\r\n1\r\n0\r\nLAYER\r\n5\r\n5\r\n330\r\n4\r\n100\r\nAcDbSymbolTableRecord\r\n100\r\nAcDbLayerTableRecord\r\n2\r\n0\r\n70\r\n0\r\n62\r\n7\r\n6\r\nCONTINUOUS\r\n0\r\nENDTAB\r\n"
    append result "0\r\nTABLE\r\n2\r\nBLOCK_RECORD\r\n5\r\n6\r\n100\r\nAcDbSymbolTable\r\n70\r\n2\r\n"
    foreach {handle name} {7 *Model_Space 8 *Paper_Space} {
        append result "0\r\nBLOCK_RECORD\r\n5\r\n$handle\r\n330\r\n6\r\n100\r\nAcDbSymbolTableRecord\r\n100\r\nAcDbBlockTableRecord\r\n2\r\n$name\r\n70\r\n0\r\n"
    }
    append result "0\r\nENDTAB\r\n0\r\nENDSEC\r\n0\r\nSECTION\r\n2\r\nBLOCKS\r\n"
    foreach {owner start finish name} {7 9 A *Model_Space 8 B C *Paper_Space} {
        append result "0\r\nBLOCK\r\n5\r\n$start\r\n330\r\n$owner\r\n100\r\nAcDbEntity\r\n8\r\n0\r\n100\r\nAcDbBlockBegin\r\n2\r\n$name\r\n70\r\n0\r\n10\r\n0\r\n20\r\n0\r\n30\r\n0\r\n3\r\n$name\r\n1\r\n\r\n0\r\nENDBLK\r\n5\r\n$finish\r\n330\r\n$owner\r\n100\r\nAcDbEntity\r\n8\r\n0\r\n100\r\nAcDbBlockEnd\r\n"
    }
    append result "0\r\nENDSEC\r\n0\r\nSECTION\r\n2\r\nENTITIES\r\n"
    return $result
}
proc ::GX::SketchDXF::_entity {type subclass handle body} {
    return "0\r\n$type\r\n5\r\n[format %X $handle]\r\n330\r\n7\r\n100\r\nAcDbEntity\r\n8\r\n0\r\n100\r\n$subclass\r\n$body"
}
proc ::GX::SketchDXF::_spline {controls handle {closed 0}} {
    set degree [expr {[llength $controls]-1}]
    set body "[_pair 70 [expr {8|$closed}]][_pair 71 $degree][_pair 72 [expr {2*($degree+1)}]][_pair 73 [llength $controls]][_pair 74 0]"
    foreach value {0 1} {for {set i 0} {$i<=$degree} {incr i} {append body [_pair 40 $value]}}
    foreach point $controls {append body [_xyz 10 $point]}
    append body "210\r\n0\r\n220\r\n0\r\n230\r\n1\r\n"
    return [_entity SPLINE AcDbSpline $handle $body]
}
proc ::GX::SketchDXF::_conic {definition scales handle reverse} {
    set family [dict get $definition family];set controls [dict get $definition controls]
    set center [_world $definition [lindex $controls 0] $scales]
    set rx [dict get $definition radius_x]
    set ry [expr {$family eq {ellipse}?[dict get $definition radius_y]:$rx}]
    set rotation [::GX::datasetPublicationV2DictDefault $definition rotation 0]
    set u [_world $definition [list [expr {$rx*cos($rotation)}] [expr {$rx*sin($rotation)}]] $scales 1]
    set v [_world $definition [list [expr {-$ry*sin($rotation)}] [expr {$ry*cos($rotation)}]] $scales 1]
    lassign $u ux uy;lassign $v vx vy
    set det [expr {$ux*$vy-$uy*$vx}]
    set xx [expr {$ux*$ux+$vx*$vx}];set yy [expr {$uy*$uy+$vy*$vy}];set xy [expr {$ux*$uy+$vx*$vy}]
    set disc [expr {hypot($xx-$yy,2*$xy)}]
    set major2 [expr {($xx+$yy+$disc)/2.0}]
    if {$major2<=0 || $det==0} {error {DXF cannot export a singular conic transform}}
    set major [expr {sqrt($major2)}];set minor [expr {abs($det)/$major}]
    set angle [expr {atan2(2*$xy,$xx-$yy)/2.0}]
    set ex [expr {cos($angle)}];set ey [expr {sin($angle)}]
    set tau [expr {2*acos(-1)}]
    set start [expr {$family eq {arc}?[dict get $definition angle_start]:0.0}]
    set sweep [expr {$family eq {arc}?[dict get $definition angle_sweep]:$tau}]
    if {$reverse} {set start [expr {$start+$sweep}];set sweep [expr {-$sweep}]}
    set normal [expr {$det*$sweep<0?-1:1}]
    set qx [expr {$ux*cos($start)+$vx*sin($start)}];set qy [expr {$uy*cos($start)+$vy*sin($start)}]
    set full [expr {$family ne {arc} || abs($sweep)==$tau}]
    # A similarity maps circles to circles; affine anisotropy remains an ellipse.
    set circular [expr {abs($major-$minor)<=32*2.220446049250313e-16*$major}]
    if {$circular} {
        lassign $center cx cy
        set body "[_xyz 10 [list [expr {$normal*$cx}] $cy]][_pair 40 [_number $major]]210\r\n0\r\n220\r\n0\r\n230\r\n$normal\r\n"
        if {$full} {return [dict create type CIRCLE bytes [_entity CIRCLE AcDbCircle $handle $body]]}
        set phi [expr {atan2($qy,$normal*$qx)*180/acos(-1)}]
        set end [expr {$phi+abs($sweep)*180/acos(-1)}]
        append body "100\r\nAcDbArc\r\n[_pair 50 [_number $phi]][_pair 51 [_number $end]]"
        return [dict create type ARC bytes [_entity ARC AcDbCircle $handle $body]]
    }
    set phi [expr {atan2($normal*(-$ey*$qx+$ex*$qy)/$minor,($ex*$qx+$ey*$qy)/$major)}]
    if {$full} {set phi 0;set end $tau} else {set end [expr {$phi+abs($sweep)}]}
    set body "[_xyz 10 $center][_xyz 11 [list [expr {$major*$ex}] [expr {$major*$ey}]]][_pair 40 [_number [expr {$minor/$major}]]][_pair 41 [_number $phi]][_pair 42 [_number $end]]210\r\n0\r\n220\r\n0\r\n230\r\n$normal\r\n"
    return [dict create type ELLIPSE bytes [_entity ELLIPSE AcDbEllipse $handle $body]]
}
proc ::GX::SketchDXF::_primitive {scene definition scales reverse handleName mapName logical} {
    upvar 1 $handleName handle $mapName mapping
    set family [dict get $definition family];set bytes {};set types {}
    if {$family in {circle arc ellipse}} {
        set conic [_conic $definition $scales [incr handle] $reverse]
        dict lappend mapping $logical [dict create handle [format %X $handle] type [dict get $conic type]]
        return [dict get $conic bytes]
    }
    set controls [dict get $definition controls]
    set points {};foreach p $controls {lappend points [_world $definition $p $scales]}
    switch -- $family {
        point {
            set type POINT;set bytes [_entity POINT AcDbPoint [incr handle] [_xyz 10 [lindex $points 0]]]
        }
        line {
            if {$reverse} {set points [lreverse $points]}
            set type LINE;set bytes [_entity LINE AcDbLine [incr handle] "[_xyz 10 [lindex $points 0]][_xyz 11 [lindex $points 1]]"]
        }
        rectangle - polyline - path {
            if {$family eq {rectangle}} {
                set object [::GX::Native2D::core sketch_create $scene $definition 2];set points {}
                for {set i 0} {$i<4} {incr i} {
                    lassign [dict get [::GX::Native2D::core sketch_evaluate $scene $object [expr {$i/4.0}]] point] x y
                    lappend points [list [expr {$x*[lindex $scales 0]}] [expr {$y*[lindex $scales 1]}]]
                }
                ::GX::Native2D::core delete $scene $object;set closed 1
            } else {set closed [expr {$family eq {path} && [::GX::datasetPublicationV2DictDefault $definition closed 0]}]}
            if {$reverse} {set points [lreverse $points]}
            set body "[_pair 90 [llength $points]][_pair 70 $closed]"
            foreach p $points {lassign $p x y;append body "[_pair 10 [_number $x]][_pair 20 [_number $y]]"}
            set type LWPOLYLINE;set bytes [_entity $type AcDbPolyline [incr handle] $body]
        }
        quadratic_bezier - cubic_bezier {
            if {$reverse} {set points [lreverse $points]}
            set type SPLINE;set bytes [_spline $points [incr handle]]
        }
        spline {
            # Original Native2D extracts exact cubic arms for each span; do not
            # duplicate its Catmull-Rom or explicit-tangent construction rules.
            set object [::GX::Native2D::core sketch_create $scene $definition 2]
            try {
                set spans [expr {[llength $controls]-1}]
                for {set i 0} {$i<$spans} {incr i} {
                    set ordinal [expr {$reverse?$spans-1-$i:$i}]
                    set part [::GX::Native2D::core selection_definition $scene $object [expr {2000000000+$ordinal}]]
                    lassign [dict get $part controls] p0 p3
                    lassign [lindex [dict get $part tangents] 0] flags incoming outgoing
                    lassign $p0 x y;lassign $outgoing dx dy;set p1 [list [expr {$x+$dx}] [expr {$y+$dy}]]
                    lassign [lindex [dict get $part tangents] 1] flags incoming outgoing
                    lassign $p3 x y;lassign $incoming dx dy;set p2 [list [expr {$x+$dx}] [expr {$y+$dy}]]
                    set curve {};foreach p [list $p0 $p1 $p2 $p3] {lappend curve [_world $part $p $scales]}
                    if {$reverse} {set curve [lreverse $curve]}
                    append bytes [_spline $curve [incr handle]]
                    dict lappend mapping $logical [dict create handle [format %X $handle] type SPLINE span $ordinal]
                }
            } finally {::GX::Native2D::core delete $scene $object}
            return $bytes
        }
        default {error "Unsupported exact DXF geometry: $family"}
    }
    dict lappend mapping $logical [dict create handle [format %X $handle] type $type]
    return $bytes
}
proc ::GX::SketchDXF::export {request} {
    if {[dict get $request api_id] ne {DATASET_EXPORT_PROVIDER_API_v1} || [dict get $request version]!=1 || [dict get $request session_token] ne [::GX::interactiveDocumentSessionToken]} {error {Invalid Dataset Export request}}
    set datasetId [dict get $request dataset_id];set parameters [dict get $request parameters]
    set unit [dict get $parameters length_unit];set reference [dict get $parameters include_reference]
    if {$unit ni {mm cm m in} || ![string is boolean -strict $reference]} {error {Invalid DXF parameters}}
    set sketch [::GX::sketchDatasetRead $::GX::currentSession $datasetId]
    set scene [::GX::Native2D::core scene];set handle 255;set mapping {};set omitted {};set topology {};set count 0
    set bytes [_header $unit]
    try {
        dict for {id record} [dict get $sketch objects] {
            set definition [dict get $record definition];set family [dict get $definition family]
            set metadata [::GX::datasetPublicationV2DictDefault $record metadata {}]
            set role [::GX::datasetPublicationV2DictDefault $metadata gx.geometry_role regular]
            if {$family eq {construction_line}} {
                lappend omitted [dict create object_id $id reason unsupported_infinite_construction];continue
            }
            if {!$reference && ($family eq {point} || $role in {reference construction})} {
                lappend omitted [dict create object_id $id reason reference_geometry role $role];continue
            }
            set units [dict get $record units]
            if {[llength $units]!=2 || [lindex $units 0] eq {} || [lindex $units 1] eq {}} {error "Object $id needs declared X/Y physical length units"}
            set scales {}
            foreach source $units {
                set plan [::GX::unitRegistryHomogeneousCoordinatePlan $source $unit]
                if {![dict get $plan physical_length]} {error "Object $id is not physical length geometry"}
                lappend scales [dict get $plan scale]
            }
            dict set topology $id [dict create family $family geometry_role $role closed [::GX::datasetPublicationV2DictDefault $definition closed [expr {$family in {circle ellipse rectangle}}]]]
            if {$family in {compound composite_path}} {
                set object [::GX::Native2D::core sketch_create $scene $definition 2]
                try {
                    for {set i 0} {$i<[llength [dict get $definition parts]]} {incr i} {
                        set part [::GX::Native2D::core composition_part $scene $object $i]
                        append bytes [_primitive $scene [dict get $part definition] $scales [dict get $part reversed] handle mapping $id]
                    }
                } finally {::GX::Native2D::core delete $scene $object}
            } else {append bytes [_primitive $scene $definition $scales 0 handle mapping $id]}
            if {[string bytelength $bytes]>63000000} {error {DXF output exceeds 63 MB conversion budget}}
            incr count
        }
    } finally {::GX::Native2D::core destroy $scene}
    if {!$count} {error {Sketch has no exportable finite geometry}}
    append bytes "0\r\nENDSEC\r\n0\r\nEOF\r\n"
    set warnings {}
    if {$omitted ne {}} {lappend warnings {Reference points/infinite construction geometry omitted; see omitted_objects}}
    return [dict create status ok format dxf bytes [encoding convertto ascii $bytes] dxf_version AC1015 length_unit $unit working_plane XY conversion exact_binary64 approximation none source_dataset_id $datasetId entities $mapping topology $topology omitted_objects $omitted warnings $warnings provenance [dict create schema gxtxt.sketch_dxf.export.v1 source [dict get $request source] source_provenance [dict get $sketch provenance] constraints_policy {Geometry only; no CAD solver constraint transfer}]]
}
