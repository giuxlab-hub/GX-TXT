# Mathematics Explorer

A generic bounded real1D mathematical model with named shared/local parameters,
reusable relations, physical units, small explicit linear systems, recorded
families, multiple functions and explicit branches/gaps. Existing schema1 models
retain their original expressions, controls and native Workspace format.

The separately owner-approved bounded controls reuse the original toolbar,
splitter and interactive Plotv4 widget. Managed Numeric workers retain the last
valid graph during pending/error states and support owned cancellation. Original
Numeric/Unit Registry, Workspace/Session, Publication and Plot owners remain the
only scientific/persistence authorities. No valve preset, private evaluator,
renderer or fitting engine is added.

Read the [user guide](docs/USER_GUIDE.md), [architecture](docs/ARCHITECTURE.md),
[model2 contract](../../../docs/api/MATHEMATICS_EXPLORER_MODEL_v2.md) and
[public API](../../../docs/api/MATHEMATICS_EXPLORER_API_v1.md).
The standalone synthetic2D21 reference is example material, not experimental data.
Original-source provenance is retained separately in integration documentation.

SPDX-License-Identifier: GPL-3.0-or-later.
