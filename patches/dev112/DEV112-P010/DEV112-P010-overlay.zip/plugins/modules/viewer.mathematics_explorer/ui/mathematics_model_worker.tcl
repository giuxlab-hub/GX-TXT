# SPDX-License-Identifier: GPL-3.0-or-later
# Fixed trusted UI worker. Inert declarations enter through an owned directory;
# original Numeric, Unit Registry and managed process groups own computation.
lassign $argv framework directory
set argv0 __gxtxt_mathematics_worker__
set ::env(PYTHONDONTWRITEBYTECODE) 1
if {[llength $argv]!=2 || ![file isdirectory $directory] || [file type $directory] ne {directory}} {error {Expected the parent-owned mathematical operation directory}}
set directory [file normalize $directory]
set requestPath [file join $directory request.tcldict]
if {![file isfile $requestPath] || [file size $requestPath]>4194304} {error {Missing or oversized mathematical request}}
set stream [open $requestPath r];try {fconfigure $stream -encoding utf-8;set request [read $stream 4194305]} finally {close $stream}
set private [file join $directory private]
file mkdir $private
foreach {key relative} {XDG_CONFIG_HOME config XDG_DATA_HOME data XDG_CACHE_HOME cache XDG_STATE_HOME state TMPDIR tmp GXTXT_JOB_ROOT jobs GXTXT_RESOURCE_STORAGE resources} {
    set ::env($key) [file join $private $relative];file mkdir $::env($key)
}
try {
    source [file join $framework gxtxt_pipeline.tcl]
    set fields {}
    foreach {field relative} {storage.cache_dir cache storage.temp_dir tmp storage.session_root sessions scripts.user_root scripts diagnostics.stderr_log_directory diagnostics} {
        set path [file join $private $relative];file mkdir $path
        ::GX::configurationRegister $field [dict create group {Mathematics worker} label $field type path default $path scope user]
        ::GX::configurationSet $field $path;lappend fields $field
    }
    ::GX::configurationRegister preview.cache_enabled [dict create group Preview label {Prepare Dataset previews} type boolean default 0 scope user]
    ::GX::configurationSet preview.cache_enabled 0;lappend fields preview.cache_enabled
    ::GX::configurationSave $fields 0;::GX::defaults;::GX::configurationSave $fields 1;::GX::loadModuleCatalog
    # This private Session supplies the existing Numeric runtime unit file only.
    set ::GX::cfg(output_root) [file join $private sessions]
    ::GX::createNewSession mathematics_numeric_worker
    ::GX::modulePublicApiActivate viewer.mathematics_explorer MATHEMATICS_EXPLORER_API_v1
    set context [dict get $request unit_context]
    if {[dict size $context]>4096} {error {Oversized frozen unit context}}
    dict for {symbol definition} $context {
        # The captured active definition is authoritative in this disposable
        # interpreter. No plug-in enablement or operator configuration changes.
        ::GX::unitRegistryRegister $symbol [dict replace $definition owner_plugin {}]
    }
    set ::env(GXTXT_UNIT_REGISTRY_FILE) [::GX::unitRegistryWriteRuntimeFile]
    set state [::GX::MathematicsExplorer::validateState [dict get $request state]]
    switch [dict get $request operation] {
        calculate {
            set result [::GX::MathematicsExplorer::calculate $state]
            if {[dict get $state schema]==2} {dict set result unit_context $context}
        }
        integral {
            set computed [::GX::MathematicsExplorer::calculate $state]
            if {[dict get $state schema]==2} {
                set result [::GX::MathematicsExplorer::integralOfSelected $computed]
            } else {
                set plan [::GX::unitRegistryArithmeticPlan * [dict get $state symbol_units x] [dict get $state output_unit]]
                set value [expr {[::GX::MathematicsExplorer::integralOfFirst $computed]*[dict get $plan left_scale]*[dict get $plan right_scale]}]
                set result [list [dict create segment_id f1 status available value $value unit [dict get $plan output_unit] interval [list [dict get $state xmin] [dict get $state xmax]] method trapezoidal]]
            }
        }
        analyze {
            if {[dict get $state schema]==2} {
                set result [::GX::MathematicsExplorer::analyzeSelected $state [dict get $request mode] [dict get $request partner] [dict get $request minimum] [dict get $request maximum]]
            } else {set result [::GX::MathematicsExplorer::analyzeFirst $state [dict get $request mode]]}
        }
        default {error {Unknown fixed mathematical operation}}
    }
    set response [dict create ok 1 result $result]
} on error {message options} {
    set response [dict create ok 0 error $message]
} finally {
    if {[llength [info commands ::GX::apiCatalogClose]]} {::GX::apiCatalogClose}
    if {[info exists ::GX::scriptJobRequests]} {
        foreach job [dict keys $::GX::scriptJobRequests] {::GX::scriptJobRequestCancel $job closed}
        set deadline [expr {[clock milliseconds]+4000}]
        while {[dict size $::GX::scriptJobRequests] && [clock milliseconds]<$deadline} {after 10 {set ::mathShutdownTick 1};vwait ::mathShutdownTick}
        if {[dict size $::GX::scriptJobRequests]} {set response [dict create ok 0 error {Mathematics worker descendants did not retire; allocation remains protected}]}
    }
}
puts $response
