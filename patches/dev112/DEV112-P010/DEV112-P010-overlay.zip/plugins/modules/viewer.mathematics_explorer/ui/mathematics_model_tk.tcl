# SPDX-License-Identifier: GPL-3.0-or-later
# Approved bounded Mathematics controls. Original Workspace/Numeric/Plot owners
# retain persistence, computation and rendering. No expression executes in Tk.
namespace eval ::GX::MathematicsExplorer {variable modelUiSerial 0}
foreach name {_uiReadState _uiSetState _uiChanged _uiNew _uiIntegral _uiAnalyze _uiCancelAnalysis _uiPick _uiPublishDialog _uiDispose _uiDestroyed} {
    if {[llength [info commands ::GX::MathematicsExplorer::${name}Legacy]]} {rename ::GX::MathematicsExplorer::${name}Legacy {}}
    rename ::GX::MathematicsExplorer::$name ::GX::MathematicsExplorer::${name}Legacy
}
unset name
proc ::GX::MathematicsExplorer::_mUiIs2 {w} {variable ui;return [expr {[info exists ui($w,model)] && [dict get $ui($w,model) schema]==2}]}
proc ::GX::MathematicsExplorer::_mUiKey {w} {
    variable ui
    set state $ui($w,model);set result [list [dict get $state x_unit] [dict get $state derivative] [dict get $state selected_function] [dict get $state selected_branch]]
    foreach fn [dict get $state functions] {
        lappend result [list [dict get $fn id] [dict get $fn enabled] [dict get $fn output_unit]]
        foreach branch [dict get $fn branches] {lappend result [list [dict get $branch id] [::GX::datasetPublicationV2DictDefault $branch output_unit {}]]}
    }
    return $result
}
proc ::GX::MathematicsExplorer::_uiReadState {w} {
    variable ui
    if {![_mUiIs2 $w]} {return [_uiReadStateLegacy $w]}
    set state $ui($w,model)
    foreach key {title xmin xmax samples derivative x_unit} {dict set state $key $ui($w,$key)}
    dict set state view_axes {}
    if {[info exists ui($w,view_key)] && $ui($w,view_key) eq [_mUiKey $w] && [winfo exists $w.right.plot.native]} {
        set receipt [::GX::PlotDatasetAPIv4::widgetReceipt $w.right.plot.native]
        if {[dict exists $receipt axes]} {dict set state view_axes [dict get $receipt axes]}
    } elseif {[info exists ui($w,restored_axes)]} {dict set state view_axes $ui($w,restored_axes)}
    return [validateState2 $state]
}
proc ::GX::MathematicsExplorer::_uiSetState {w state} {
    variable ui
    set state [validateState $state]
    _mUiCancel $w
    foreach child [winfo children $w.left] {destroy $child}
    if {[dict get $state schema]==1} {
        unset -nocomplain ui($w,model)
        _uiBuildLegacyControls $w
        $w.top.integral configure -text {Integrate F1}
        _uiSetStateLegacy $w $state
        return
    }
    set ui($w,model) $state
    foreach key {title xmin xmax samples derivative x_unit} {set ui($w,$key) [dict get $state $key]}
    set ui($w,restored_axes) [dict get $state view_axes]
    unset -nocomplain ui($w,view_key)
    set ui($w,computed) {};set ui($w,computed_state) {};set ui($w,integral) {Integration not calculated}
    set ui($w,analysis_mode) roots;set ui($w,changed) 0
    _mUiBuild $w
    $w.top.integral configure -text {Integrate selected}
    $w.top.cancel configure -text {Cancel calculation}
    _status $w {Model loaded. Plot to evaluate; any previous frame belongs to the previous model.}
}
proc ::GX::MathematicsExplorer::_mUiTree {parent name columns headings height} {
    ttk::frame $parent.$name
    set tree $parent.$name.tree
    ttk::treeview $tree -columns $columns -show headings -height $height -selectmode browse
    foreach column $columns heading $headings {$tree heading $column -text $heading;$tree column $column -width 95 -minwidth 45 -stretch 1}
    ttk::scrollbar $parent.$name.scroll -orient vertical -command [list $tree yview]
    $tree configure -yscrollcommand [list $parent.$name.scroll set]
    pack $parent.$name.scroll -side right -fill y;pack $tree -fill both -expand 1
    pack $parent.$name -fill both -expand 1
    return $tree
}
proc ::GX::MathematicsExplorer::_mUiField {parent key caption {width 15}} {
    variable ui
    set w [winfo toplevel $parent]
    ttk::frame $parent.$key
    ttk::label $parent.$key.label -text $caption -width 18 -anchor w
    ttk::entry $parent.$key.value -width $width -textvariable ::GX::MathematicsExplorer::ui($w,$key)
    pack $parent.$key.label -side left;pack $parent.$key.value -side left -fill x -expand 1
    pack $parent.$key -fill x -pady 2
    bind $parent.$key.value <Return> [list ::GX::MathematicsExplorer::_uiChanged $w]
    bind $parent.$key.value <FocusOut> [list ::GX::MathematicsExplorer::_uiChanged $w]
}
proc ::GX::MathematicsExplorer::_mUiBuild {w} {
    variable ui
    canvas $w.left.scroll -highlightthickness 0 -borderwidth 0 -width 430 -yscrollcommand [list $w.left.bar set]
    ttk::scrollbar $w.left.bar -orient vertical -command [list $w.left.scroll yview]
    pack $w.left.bar -side right -fill y;pack $w.left.scroll -fill both -expand 1
    set body $w.left.scroll.body
    ttk::frame $body -padding 3
    $w.left.scroll create window 0 0 -window $body -anchor nw -tags body
    bind $body <Configure> [list ::GX::MathematicsExplorer::_mUiScrollRegion $w]
    bind $w.left.scroll <Configure> [list ::GX::MathematicsExplorer::_mUiScrollWidth $w %w]
    ttk::labelframe $body.functions -text {Functions and branches} -padding 6
    pack $body.functions -fill x -pady 4
    set functions [_mUiTree $body.functions list {visible name unit} {Visible Function Unit} 4]
    set ui($w,functions_tree) $functions
    bind $functions <<TreeviewSelect>> [list ::GX::MathematicsExplorer::_mUiSelectFunction $w]
    set branches [_mUiTree $body.functions branches {name expression} {Branch Expression} 3]
    set ui($w,branches_tree) $branches
    bind $branches <<TreeviewSelect>> [list ::GX::MathematicsExplorer::_mUiSelectBranch $w]
    ttk::label $body.functions.hint -text {Right-click or Shift+F10 for function and branch commands. Double-click to edit.} -wraplength 400
    pack $body.functions.hint -fill x -pady 3
    foreach {tree type} [list $functions function $branches branch] {
        bind $tree <Button-3> [list ::GX::MathematicsExplorer::_mUiContext $w $type $tree %x %y %X %Y]
        bind $tree <Shift-F10> [list ::GX::MathematicsExplorer::_mUiContext $w $type $tree {} {} {} {}]
        bind $tree <Menu> [list ::GX::MathematicsExplorer::_mUiContext $w $type $tree {} {} {} {}]
        bind $tree <Double-1> [list ::GX::MathematicsExplorer::_mUiEdit $w $type edit]
        bind $tree <Return> [list ::GX::MathematicsExplorer::_mUiEdit $w $type edit]
    }
    ttk::labelframe $body.parameters -text {Named parameters and families} -padding 6
    pack $body.parameters -fill x -pady 4
    ttk::label $body.parameters.familylabel -text {Parameter family:}
    ttk::combobox $body.parameters.family -state readonly -textvariable ::GX::MathematicsExplorer::ui($w,family_choice)
    pack $body.parameters.familylabel $body.parameters.family -fill x
    set ui($w,family_widget) $body.parameters.family
    bind $body.parameters.family <<ComboboxSelected>> [list ::GX::MathematicsExplorer::_mUiFamily $w]
    set params [_mUiTree $body.parameters list {name value unit scope} {Name {Exact value} Unit Scope} 5]
    set ui($w,parameters_tree) $params
    bind $params <<TreeviewSelect>> [list ::GX::MathematicsExplorer::_mUiParameterSelected $w]
    bind $params <Button-3> [list ::GX::MathematicsExplorer::_mUiContext $w parameter $params %x %y %X %Y]
    foreach event {<Shift-F10> <Menu>} {bind $params $event [list ::GX::MathematicsExplorer::_mUiContext $w parameter $params {} {} {} {}]}
    bind $params <Return> [list ::GX::MathematicsExplorer::_mUiEdit $w parameter edit]
    bind $params <Double-1> [list ::GX::MathematicsExplorer::_mUiEdit $w parameter edit]
    ttk::label $body.parameters.exactlabel -text {Selected input — exact value:}
    ttk::entry $body.parameters.exact -textvariable ::GX::MathematicsExplorer::ui($w,parameter_value)
    pack $body.parameters.exactlabel $body.parameters.exact -fill x
    bind $body.parameters.exact <Return> [list ::GX::MathematicsExplorer::_mUiExact $w]
    bind $body.parameters.exact <FocusOut> [list ::GX::MathematicsExplorer::_mUiExact $w]
    ttk::scale $body.parameters.slider -from 0 -to 1 -command [list ::GX::MathematicsExplorer::_mUiSlider $w]
    pack $body.parameters.slider -fill x -pady 3
    set ui($w,exact_widget) $body.parameters.exact;set ui($w,slider_widget) $body.parameters.slider
    ttk::label $body.parameters.range -textvariable ::GX::MathematicsExplorer::ui($w,parameter_hint) -wraplength 400
    pack $body.parameters.range -fill x
    ttk::labelframe $body.domain -text {Domain and numerical sampling} -padding 6
    pack $body.domain -fill x -pady 4
    foreach {key caption} {xmin {Global X minimum} xmax {Global X maximum} samples {Default sample count}} {_mUiField $body.domain $key $caption}
    ttk::label $body.domain.selected -textvariable ::GX::MathematicsExplorer::ui($w,branch_hint) -wraplength 400
    pack $body.domain.selected -fill x -pady 3
    ttk::labelframe $body.units -text {Explicit units (1 = dimensionless)} -padding 6
    pack $body.units -fill x -pady 4
    _mUiField $body.units x_unit {Common X unit}
    ttk::label $body.units.output -text {Function/branch output units: edit the selected declaration.} -wraplength 400
    pack $body.units.output -fill x
    ttk::checkbutton $body.derivative -text {Show derivative of selected function / branch} -variable ::GX::MathematicsExplorer::ui($w,derivative) -command [list ::GX::MathematicsExplorer::_uiChanged $w]
    pack $body.derivative -anchor w -pady 5
    ttk::label $body.analysislabel -text {Analyze selected function / branch:}
    ttk::combobox $body.mode -state readonly -values {roots intersections extrema} -textvariable ::GX::MathematicsExplorer::ui($w,analysis_mode)
    pack $body.analysislabel $body.mode -fill x
    ttk::label $body.scope -text {Separate branches keep their stated boundaries and gaps. Numerical calculus uses admitted samples; it does not prove completeness or uncertainty.} -wraplength 400
    ttk::label $body.integral -textvariable ::GX::MathematicsExplorer::ui($w,integral) -wraplength 400
    pack $body.scope $body.integral -fill x -pady 5
    set ui($w,body) $body
    bind $w <FocusIn> [list ::GX::MathematicsExplorer::_mUiRevealFocus $w %W]
    foreach event {<Button-4> <Button-5> <MouseWheel>} {
        bind $w $event [list ::GX::MathematicsExplorer::_mUiWheel $w %W $event %D]
    }
    _mUiRefresh $w
}
proc ::GX::MathematicsExplorer::_mUiScrollRegion {w} {if {[winfo exists $w.left.scroll]} {$w.left.scroll configure -scrollregion [$w.left.scroll bbox all]}}
proc ::GX::MathematicsExplorer::_mUiScrollWidth {w width} {
    if {![winfo exists $w.left.scroll]} return
    $w.left.scroll itemconfigure body -width $width
    foreach widget [list $w.left.scroll.body.functions.hint $w.left.scroll.body.parameters.range $w.left.scroll.body.domain.selected $w.left.scroll.body.units.output $w.left.scroll.body.scope $w.left.scroll.body.integral] {if {[winfo exists $widget]} {$widget configure -wraplength [expr {max(100,$width-30)}]}}
}
proc ::GX::MathematicsExplorer::_mUiFnIndex {w} {
    variable ui;set index 0
    foreach fn [dict get $ui($w,model) functions] {if {[dict get $fn id] eq [dict get $ui($w,model) selected_function]} {return $index};incr index}
    error {Select a function}
}
proc ::GX::MathematicsExplorer::_mUiBranchIndex {w} {
    variable ui;set fn [lindex [dict get $ui($w,model) functions] [_mUiFnIndex $w]];set index 0
    foreach branch [dict get $fn branches] {if {[dict get $branch id] eq [dict get $ui($w,model) selected_branch]} {return $index};incr index}
    return 0
}
proc ::GX::MathematicsExplorer::_mUiRefresh {w} {
    variable ui
    if {![_mUiIs2 $w]} return
    set ui($w,updating) 1
    set ft $ui($w,functions_tree);$ft delete [$ft children {}]
    foreach fn [dict get $ui($w,model) functions] {$ft insert {} end -id [dict get $fn id] -values [list [expr {[dict get $fn enabled]?{Yes}:{No}}] [dict get $fn label] [dict get $fn output_unit]]}
    $ft selection set [dict get $ui($w,model) selected_function];$ft see [dict get $ui($w,model) selected_function]
    set fn [lindex [dict get $ui($w,model) functions] [_mUiFnIndex $w]]
    set bt $ui($w,branches_tree);$bt delete [$bt children {}]
    foreach branch [dict get $fn branches] {$bt insert {} end -id [dict get $branch id] -values [list [dict get $branch label] [dict get $branch expression]]}
    if {[dict get $ui($w,model) selected_branch] ne {}} {$bt selection set [dict get $ui($w,model) selected_branch];$bt see [dict get $ui($w,model) selected_branch]}
    set ui($w,branch_hint) {Selected scope: all branches. Edit a branch for its bounds, exclusions and grid.}
    if {[dict get $ui($w,model) selected_branch] ne {}} {
        set b [lindex [dict get $fn branches] [_mUiBranchIndex $w]]
        set lower [dict get $b lower];if {$lower eq {}} {set lower {global minimum}}
        set upper [dict get $b upper];if {$upper eq {}} {set upper {global maximum}}
        set ui($w,branch_hint) "[dict get $b label]: $lower to $upper; lower [expr {[dict get $b lower_closed]?{included}:{excluded}}], upper [expr {[dict get $b upper_closed]?{included}:{excluded}}]; [dict get $b sampling] grid; [llength [dict get $b exclusions]] exclusion(s)."
    }
    set familyLabels [list {Manual inputs}];set ui($w,family_ids) [list {}]
    set ui($w,family_choice) {Manual inputs}
    foreach family [dict get $ui($w,model) families] {
        set label "[dict get $family label] ([dict get $family id])";lappend familyLabels $label;lappend ui($w,family_ids) [dict get $family id]
        if {[dict get $family id] eq [dict get $ui($w,model) family_id]} {set ui($w,family_choice) $label}
    }
    $ui($w,family_widget) configure -values $familyLabels
    set pt $ui($w,parameters_tree);set old [$pt selection]
    if {[info exists ui($w,parameter_select)]} {set old [list $ui($w,parameter_select)];unset ui($w,parameter_select)}
    $pt delete [$pt children {}]
    set ui($w,parameter_rows) {}
    foreach {scope parameters} [list shared [dict get $ui($w,model) parameters] local [dict get $fn parameters]] {
        foreach p $parameters {
            set id [dict get $p id];set value [dict get $p value]
            if {$scope eq {shared}} {foreach family [dict get $ui($w,model) families] {if {[dict get $family id] eq [dict get $ui($w,model) family_id] && [dict exists $family values $id]} {set value [dict get $family values $id]}}}
            set row ${scope}:$id;dict set ui($w,parameter_rows) $row [dict create scope $scope id $id parameter $p value $value]
            $pt insert {} end -id $row -values [list $id $value [dict get $p unit] $scope]
        }
    }
    foreach {scope definitions} [list shared [dict get $ui($w,model) definitions] local [dict get $fn definitions]] {
        foreach definition $definitions {set id [dict get $definition id];$pt insert {} end -id definition:$scope:$id -values [list $id [dict get $definition expression] [dict get $definition unit] {Derived — read-only}]}
    }
    foreach system [dict get $ui($w,model) systems] {
        foreach unknown [dict get $system unknowns] {
            set id [dict get $unknown id];set value {Not evaluated}
            if {$ui($w,computed) ne {} && [dict exists $ui($w,computed) resolved_shared_values $id] && [dict remove $ui($w,computed_state) view_axes] eq [dict remove [_uiReadState $w] view_axes]} {set value [dict get $ui($w,computed) resolved_shared_values $id]}
            $pt insert {} end -id system:$id -values [list $id $value [dict get $unknown unit] {Solved — read-only}]
        }
    }
    if {[llength $old] && [$pt exists [lindex $old 0]]} {$pt selection set $old;$pt see [lindex $old 0]}
    set ui($w,updating) 0
    _mUiParameterSelected $w
}
proc ::GX::MathematicsExplorer::_mUiSelectFunction {w} {
    variable ui;if {![_mUiIs2 $w] || $ui($w,updating)} return
    set selection [$ui($w,functions_tree) selection];if {![llength $selection]} return
    set id [lindex $selection 0];if {$id eq [dict get $ui($w,model) selected_function]} return
    dict set ui($w,model) selected_function $id;dict set ui($w,model) selected_branch {}
    _mUiRefresh $w;_uiChanged $w
}
proc ::GX::MathematicsExplorer::_mUiSelectBranch {w} {
    variable ui;if {![_mUiIs2 $w] || $ui($w,updating)} return
    set selection [$ui($w,branches_tree) selection];if {![llength $selection]} return
    set id [lindex $selection 0];if {$id eq [dict get $ui($w,model) selected_branch]} return
    dict set ui($w,model) selected_branch $id;_mUiRefresh $w;_uiChanged $w
}
proc ::GX::MathematicsExplorer::_mUiFamily {w} {
    variable ui;set index [lsearch -exact [$ui($w,family_widget) cget -values] $ui($w,family_choice)]
    if {$index<0} return
    dict set ui($w,model) family_id [lindex $ui($w,family_ids) $index]
    _mUiRefresh $w;_uiChanged $w
}
proc ::GX::MathematicsExplorer::_mUiParameterSelected {w} {
    variable ui;if {![_mUiIs2 $w] || $ui($w,updating)} return
    set selection [$ui($w,parameters_tree) selection];set row [lindex $selection 0]
    set ui($w,parameter_hint) {Select an input for exact entry or a configured slider. Derived values are read-only.}
    set ui($w,parameter_value) {}
    $ui($w,exact_widget) configure -state readonly;$ui($w,slider_widget) configure -state disabled
    if {![dict exists $ui($w,parameter_rows) $row]} return
    set record [dict get $ui($w,parameter_rows) $row];set p [dict get $record parameter]
    set ui($w,parameter_value) [dict get $record value]
    $ui($w,exact_widget) configure -state normal
    set slider [dict get $p slider];set mode [dict get $slider mode]
    set ui($w,parameter_hint) "[dict get $p label] ([dict get $p unit]); $mode slider [dict get $slider min] to [dict get $slider max]. [dict get $p description]"
    if {$mode ne {none}} {
        set lo [dict get $slider min];set hi [dict get $slider max];set value [dict get $record value]
        if {$mode eq {logarithmic}} {set lo [expr {log($lo)}];set hi [expr {log($hi)}];set value [expr {$value>0?log($value):$lo}]}
        set ui($w,updating) 1
        $ui($w,slider_widget) configure -from $lo -to $hi -state normal
        $ui($w,slider_widget) set $value
        set ui($w,updating) 0
    }
}
proc ::GX::MathematicsExplorer::_mUiExact {w} {
    variable ui
    if {![_mUiIs2 $w] || $ui($w,updating)} return
    set row [lindex [$ui($w,parameters_tree) selection] 0]
    if {![dict exists $ui($w,parameter_rows) $row]} return
    set code [catch {
        set value $ui($w,parameter_value);finiteNumber $value {Parameter value}
        set record [dict get $ui($w,parameter_rows) $row]
        if {$value eq [dict get $record value]} return
        set state [_uiReadState $w];set scope [dict get $record scope];set id [dict get $record id]
        # Editing a family member becomes an explicit manual set, preserving
        # the named family table and all its other effective values.
        if {$scope eq {shared} && [dict get $state family_id] ne {}} {
            foreach family [dict get $state families] {if {[dict get $family id] eq [dict get $state family_id]} {set overrides [dict get $family values]}}
            set parameters {};foreach p [dict get $state parameters] {if {[dict exists $overrides [dict get $p id]]} {dict set p value [dict get $overrides [dict get $p id]]};lappend parameters $p};dict set state parameters $parameters;dict set state family_id {}
        }
        if {$scope eq {shared}} {set parameters [dict get $state parameters]} else {set fi [_mUiFnIndex $w];set fn [lindex [dict get $state functions] $fi];set parameters [dict get $fn parameters]}
        set updated {};foreach p $parameters {if {[dict get $p id] eq $id} {dict set p value $value};lappend updated $p}
        if {$scope eq {shared}} {dict set state parameters $updated} else {dict set fn parameters $updated;set functions [dict get $state functions];lset functions $fi $fn;dict set state functions $functions}
        _mUiCommit $w $state
    } message options]
    if {$code==2} {return -options $options $message}
    if {$code} {_status $w "Parameter not changed: $message"}
}
proc ::GX::MathematicsExplorer::_mUiSlider {w value} {
    variable ui;if {![_mUiIs2 $w] || $ui($w,updating)} return
    set row [lindex [$ui($w,parameters_tree) selection] 0];if {![dict exists $ui($w,parameter_rows) $row]} return
    set p [dict get $ui($w,parameter_rows) $row parameter]
    if {[dict get $p slider mode] eq {logarithmic}} {set value [expr {exp($value)}]}
    set ui($w,parameter_value) [format %.17g $value];_mUiExact $w
}
proc ::GX::MathematicsExplorer::_mUiCommit {w state} {
    variable ui
    set state [validateState2 $state]
    set ui($w,model) $state
    foreach key {title xmin xmax samples derivative x_unit} {set ui($w,$key) [dict get $state $key]}
    set ui($w,restored_axes) {}
    _mUiRefresh $w;_uiChanged $w
}
proc ::GX::MathematicsExplorer::_uiChanged {w} {
    variable ui
    if {![winfo exists $w] || ([info exists ui($w,updating)] && $ui($w,updating))} return
    if {[_mUiIs2 $w]} {
        foreach key {title xmin xmax samples derivative x_unit} {dict set ui($w,model) $key $ui($w,$key)}
        set ui($w,restored_axes) {}
    }
    set ui($w,changed) 1
    _status $w {Model changed; the last valid graph is retained until calculation succeeds.}
    _uiSchedule $w
}
# Every declaration editor is an owned modal. Submitted text remains inert;
# the complete model validator admits the change before the dialog closes.
proc ::GX::MathematicsExplorer::_mUiForm {w title fields initial callback} {
    variable ui;variable modelUiSerial
    set parent $w;set focused [focus]
    if {$focused ne {} && [winfo exists $focused]} {set candidate [winfo toplevel $focused];if {[string match $w* $candidate]} {set parent $candidate}}
    set d $w.edit[incr modelUiSerial]
    toplevel $d;wm title $d $title;wm transient $d $parent
    set ui($d,parent) $parent;set ui($d,return_focus) $focused;set ui($d,callback) $callback;set ui($d,fields) $fields
    set ui($d,prior_grab) [grab current $w]
    # Keep actions outside bounded scrollable declarations on compact/scaled
    # displays. The form can grow without placing Apply/Cancel offscreen.
    ttk::frame $d.viewport;pack $d.viewport -fill both -expand 1 -padx 8 -pady 8
    canvas $d.viewport.canvas -highlightthickness 0 -borderwidth 0 -width 600 -height 400 -yscrollcommand [list $d.viewport.bar set]
    ttk::scrollbar $d.viewport.bar -orient vertical -command [list $d.viewport.canvas yview]
    pack $d.viewport.bar -side right -fill y;pack $d.viewport.canvas -fill both -expand 1
    set body $d.viewport.canvas.body;ttk::frame $body -padding 4
    $d.viewport.canvas create window 0 0 -window $body -anchor nw -tags body
    bind $body <Configure> [list ::GX::MathematicsExplorer::_mUiFormRegion $d]
    bind $d.viewport.canvas <Configure> [list ::GX::MathematicsExplorer::_mUiFormWidth $d %w]
    bind $d <FocusIn> [list ::GX::MathematicsExplorer::_mUiFormReveal $d %W]
    foreach event {<Button-4> <Button-5> <MouseWheel>} {bind $d $event [list ::GX::MathematicsExplorer::_mUiFormWheel $d %W $event %D]}
    set i 0;set first {}
    foreach field $fields {
        lassign $field key label kind choices
        set row $body.r[incr i];ttk::frame $row;pack $row -fill x -pady 3
        ttk::label $row.label -text $label -width 24 -wraplength 210 -anchor w;pack $row.label -side left -padx {0 6}
        set ui($d,$key) [::GX::datasetPublicationV2DictDefault $initial $key {}]
        if {$kind eq {choice}} {ttk::combobox $row.value -state readonly -values $choices -textvariable ::GX::MathematicsExplorer::ui($d,$key) -width 38
        } elseif {$kind eq {bool}} {ttk::checkbutton $row.value -text Included -variable ::GX::MathematicsExplorer::ui($d,$key)
        } elseif {$kind eq {text}} {
            text $row.value -width 45 -height 5 -wrap word -undo 1;$row.value insert 1.0 $ui($d,$key)
            set ui($d,text,$key) $row.value
        } else {ttk::entry $row.value -width 45 -textvariable ::GX::MathematicsExplorer::ui($d,$key)}
        pack $row.value -side left -fill x -expand 1
        if {$first eq {}} {set first $row.value}
    }
    ttk::label $d.error -textvariable ::GX::MathematicsExplorer::ui($d,error) -wraplength 560;set ui($d,error) {};pack $d.error -fill x -padx 10
    ttk::frame $d.buttons -padding 8;pack $d.buttons -fill x
    ttk::button $d.buttons.cancel -text Cancel -command [list ::GX::MathematicsExplorer::_mUiFormClose $d]
    ttk::button $d.buttons.ok -text Apply -command [list ::GX::MathematicsExplorer::_mUiFormApply $d]
    pack $d.buttons.cancel $d.buttons.ok -side right -padx 4
    # Pack fixed actions first: a shorter form must not let the canvas consume
    # their allocation before Tk reaches the action/error widgets.
    pack forget $d.viewport $d.error $d.buttons
    pack $d.buttons -side bottom -fill x
    pack $d.error -side bottom -fill x -padx 10
    pack $d.viewport -side top -fill both -expand 1 -padx 8 -pady 8
    wm protocol $d WM_DELETE_WINDOW [list ::GX::MathematicsExplorer::_mUiFormClose $d]
    bind $d <Escape> [list ::GX::MathematicsExplorer::_mUiFormClose $d]
    bind $d <ButtonPress> [list ::GX::MathematicsExplorer::_mUiModalOutside $d %X %Y]
    bind $parent <Destroy> +[list ::GX::MathematicsExplorer::_mUiModalParentDestroyed $d $parent %W]
    update idletasks
    set maxHeight [expr {max(300,[winfo screenheight $d]-130)}]
    set maxWidth [expr {max(450,[winfo screenwidth $d]-70)}]
    set height [expr {min($maxHeight,[winfo reqheight $body]+[winfo reqheight $d.buttons]+70)}]
    set width [expr {min($maxWidth,max(530,[winfo reqwidth $body]+40))}]
    wm geometry $d ${width}x${height};wm minsize $d 420 260
    grab set $d;focus $first
    return $d
}
proc ::GX::MathematicsExplorer::_mUiFormApply {d} {
    variable ui
    if {![winfo exists $d]} return
    if {[catch {
        set values {}
        foreach field $ui($d,fields) {set key [lindex $field 0];set value $ui($d,$key);if {[info exists ui($d,text,$key)]} {set value [$ui($d,text,$key) get 1.0 end-1c]};dict set values $key $value}
        {*}$ui($d,callback) $values
    } message]} {set ui($d,error) $message;bell;return}
    _mUiFormClose $d
}
proc ::GX::MathematicsExplorer::_mUiFormClose {d} {
    variable ui
    if {![winfo exists $d]} return
    set parent $ui($d,parent);set prior $ui($d,prior_grab)
    set returnFocus [expr {[info exists ui($d,return_focus)]?$ui($d,return_focus):{}}]
    catch {grab release $d};destroy $d;array unset ui $d,*
    if {$prior ne {} && [winfo exists $prior]} {grab set $prior}
    if {$returnFocus ne {} && [winfo exists $returnFocus]} {focus $returnFocus} elseif {[winfo exists $parent]} {focus $parent}
}
proc ::GX::MathematicsExplorer::_mUiContext {w type tree x y X Y} {
    variable ui
    if {$x ne {}} {set row [$tree identify row $x $y];if {$row ne {}} {$tree selection set $row;focus $tree;update idletasks}}
    if {$X eq {}} {set X [expr {[winfo rootx $tree]+15}];set Y [expr {[winfo rooty $tree]+20}]}
    set m $w.modelmenu;catch {destroy $m};menu $m -tearoff 0
    foreach {action label} {add {Add declaration...} edit {Edit selected...} duplicate {Duplicate selected...} delete {Delete selected}} {$m add command -label $label -command [list ::GX::MathematicsExplorer::_mUiEdit $w $type $action]}
    if {$type eq {function}} {
        $m add separator;$m add command -label {Toggle selected visibility} -command [list ::GX::MathematicsExplorer::_mUiToggle $w]
        $m add command -label {Select all branches for calculus} -command [list ::GX::MathematicsExplorer::_mUiAllBranches $w]
    }
    if {$type eq {parameter}} {
        $m add separator
        foreach {kind label} {definition {Reusable definitions...} system {Linear systems...} family {Parameter families...}} {$m add command -label $label -command [list ::GX::MathematicsExplorer::_mUiManage $w $kind]}
    }
    tk_popup $m $X $Y
}
proc ::GX::MathematicsExplorer::_mUiToggle {w} {variable ui;set state [_uiReadState $w];set fs [dict get $state functions];set i [_mUiFnIndex $w];set fn [lindex $fs $i];dict set fn enabled [expr {![dict get $fn enabled]}];lset fs $i $fn;dict set state functions $fs;if {[catch {_mUiCommit $w $state} message]} {_notify $w $message}}
proc ::GX::MathematicsExplorer::_mUiAllBranches {w} {variable ui;dict set ui($w,model) selected_branch {};_mUiRefresh $w;_uiChanged $w}
proc ::GX::MathematicsExplorer::_mUiUnique {records prefix} {set used {};foreach record $records {lappend used [dict get $record id]};set n 1;set candidate $prefix$n;while {$candidate in $used} {incr n;set candidate $prefix$n};return $candidate}
proc ::GX::MathematicsExplorer::_mUiEdit {w type action} {
    variable ui
    set code [catch {
        set state [_uiReadState $w];set fi [_mUiFnIndex $w];set fn [lindex [dict get $state functions] $fi]
        set scope shared
        switch $type {
            function {set records [dict get $state functions];set index $fi;set initial [lindex $records $index];set fields {{id Identity entry} {label Name entry} {enabled Visible bool} {output_unit {Output unit} entry}};set fresh [dict replace [lindex [dict get [initialState2] functions] 0] id [_mUiUnique $records f] label {New function}]}
            branch {set records [dict get $fn branches];set index [_mUiBranchIndex $w];set initial [lindex $records $index];set fields {{id Identity entry} {label Name entry} {expression Expression entry} {output_unit {Output unit (empty inherits)} entry} {lower {Lower bound (empty = global)} entry} {upper {Upper bound (empty = global)} entry} {lower_closed {Include lower bound} bool} {upper_closed {Include upper bound} bool} {samples {Samples (0 inherits)} entry} {sampling Sampling choice {uniform explicit}} {explicit_x {Explicit X (space-separated)} text} {excluded {Exclusions: lower ; upper ; inclusive lower ; inclusive upper, one per line} text}};set fresh [dict replace [lindex [dict get [lindex [dict get [initialState2] functions] 0] branches] 0] id [_mUiUnique $records branch] label {New branch}]}
            parameter {
                set row [lindex [$ui($w,parameters_tree) selection] 0]
                if {$action ne {add} && ![dict exists $ui($w,parameter_rows) $row]} {error {Select an input; use the declaration managers for read-only derived values}}
                if {[dict exists $ui($w,parameter_rows) $row]} {set scope [dict get $ui($w,parameter_rows) $row scope]}
                set records [expr {$scope eq {shared}?[dict get $state parameters]:[dict get $fn parameters]}];set index -1
                if {$action ne {add}} {set id [dict get $ui($w,parameter_rows) $row id];set i 0;foreach p $records {if {[dict get $p id] eq $id} {set index $i};incr i}}
                set initial [lindex $records $index]
                set fields {{id Identity entry} {label Name entry} {scope Scope choice {shared local}} {description Description entry} {group Group entry} {unit Unit entry} {value {Exact value} entry} {slider_mode {Slider mode} choice {none linear logarithmic}} {slider_min {Slider minimum} entry} {slider_max {Slider maximum} entry}}
                set fresh [dict replace [lindex [dict get [initialState2] parameters] 0] id [_mUiUnique [concat [dict get $state parameters] [dict get $fn parameters]] parameter] label {New parameter}]
            }
            default {error {Unknown declaration kind}}
        }
        if {$action eq {delete}} {_mUiRecordSave $w $type $scope $index $state {} delete;return}
        if {$action eq {add}} {set initial $fresh;set index -1}
        if {$action eq {duplicate}} {dict set initial id [_mUiUnique $records copy];dict set initial label "[dict get $initial label] copy";set index -1}
        if {$type eq {parameter}} {dict set initial scope $scope;foreach field {mode min max} {dict set initial slider_$field [dict get $initial slider $field]}}
        if {$type eq {branch}} {set lines {};foreach exclusion [dict get $initial exclusions] {lappend lines [join [list [dict get $exclusion lower] [dict get $exclusion upper] [dict get $exclusion lower_closed] [dict get $exclusion upper_closed]] { ; }]};dict set initial excluded [join $lines \n]}
        _mUiForm $w "[string totitle $type] declaration" $fields $initial [list ::GX::MathematicsExplorer::_mUiRecordSave $w $type $scope $index $state $initial save]
    } message options]
    if {$code==2} {return -options $options $message}
    if {$code} {_notify $w $message}
}
proc ::GX::MathematicsExplorer::_mUiRecordSave {w type oldScope index state initial action {values {}}} {
    variable ui
    # A modal belongs to the declarations it opened; external Session changes
    # cannot silently redirect it to another scientific owner.
    if {$ui($w,session_token) ne [sessionToken]} {error {Session changed; reopen Mathematics Explorer}}
    set fi [_mUiFnIndex $w];set functions [dict get $state functions];set fn [lindex $functions $fi]
    switch $type {
        function {set records $functions}
        branch {set records [dict get $fn branches]}
        parameter {set records [expr {$oldScope eq {shared}?[dict get $state parameters]:[dict get $fn parameters]}]}
    }
    if {$action eq {delete}} {set records [lreplace $records $index $index]} else {
        set record [dict merge $initial $values]
        if {$type eq {parameter}} {
            set newScope [dict get $record scope];dict unset record scope
            dict set record slider [dict create mode [dict get $record slider_mode] min [dict get $record slider_min] max [dict get $record slider_max]]
            foreach field {slider_mode slider_min slider_max} {dict unset record $field}
            if {$newScope ne $oldScope} {
                if {$index>=0} {set records [lreplace $records $index $index]}
                if {$oldScope eq {shared}} {dict set state parameters $records} else {dict set fn parameters $records}
                set oldScope $newScope;set records [expr {$newScope eq {shared}?[dict get $state parameters]:[dict get $fn parameters]}];set index -1
            }
        }
        if {$type eq {branch}} {
            set exclusions {}
            foreach line [split [dict get $record excluded] \n] {
                if {[string trim $line] eq {}} continue
                set parts [split $line {;}];if {[llength $parts]!=4} {error {Each exclusion needs four semicolon-separated fields: lower; upper; include lower (0/1); include upper (0/1)}}
                lassign [lmap part $parts {string trim $part}] lower upper lc uc
                lappend exclusions [dict create lower $lower upper $upper lower_closed $lc upper_closed $uc]
            }
            dict set record exclusions $exclusions;dict unset record excluded
        }
        if {$index<0} {lappend records $record} else {lset records $index $record}
    }
    switch $type {
        function {
            dict set state functions $records
            if {$action ne {delete}} {dict set state selected_function [dict get $record id]} else {if {![llength $records]} {error {Keep at least one function}};dict set state selected_function [dict get [lindex $records 0] id]}
            dict set state selected_branch {}
        }
        branch {
            if {![llength $records]} {error {Keep at least one branch}}
            dict set fn branches $records;lset functions $fi $fn;dict set state functions $functions
            dict set state selected_branch [expr {$action eq {delete}?{}:[dict get $record id]}]
        }
        parameter {
            if {$oldScope eq {shared}} {dict set state parameters $records} else {dict set fn parameters $records;lset functions $fi $fn;dict set state functions $functions}
            # A local-to-shared move also commits removal from the local scope.
            if {$oldScope eq {shared}} {lset functions $fi $fn;dict set state functions $functions}
        }
    }
    if {$type eq {parameter} && $action ne {delete}} {set ui($w,parameter_select) $oldScope:[dict get $record id]}
    _mUiCommit $w $state
}
proc ::GX::MathematicsExplorer::_mUiManage {w type} {
    variable ui;variable modelUiSerial
    if {[catch {set state [_uiReadState $w]} message]} {_notify $w $message;return}
    set d $w.manage[incr modelUiSerial];toplevel $d;wm transient $d $w;wm title $d "[string totitle $type] declarations"
    set ui($d,parent) $w;set ui($d,prior_grab) [grab current $w]
    set ui($d,type) $type;set ui($d,owner) $w
    ttk::label $d.hint -text {Declare explicit mathematical inputs and relations. Changes remain in the model until Save model.} -wraplength 500 -padding 8
    pack $d.hint -fill x
    listbox $d.list -height 8 -width 60 -exportselection 0
    pack $d.list -fill both -expand 1 -padx 8
    ttk::frame $d.buttons -padding 8;pack $d.buttons -fill x
    foreach {action label} {add Add... edit Edit... delete Delete} {
        ttk::button $d.buttons.$action -text $label -command [list ::GX::MathematicsExplorer::_mUiManageEdit $d $action]
        pack $d.buttons.$action -side left -padx 3
    }
    ttk::button $d.buttons.close -text Close -command [list ::GX::MathematicsExplorer::_mUiFormClose $d]
    pack $d.buttons.close -side right
    bind $d.list <Return> [list ::GX::MathematicsExplorer::_mUiManageEdit $d edit]
    bind $d.list <Double-1> [list ::GX::MathematicsExplorer::_mUiManageEdit $d edit]
    bind $d <Escape> [list ::GX::MathematicsExplorer::_mUiFormClose $d]
    wm protocol $d WM_DELETE_WINDOW [list ::GX::MathematicsExplorer::_mUiFormClose $d]
    _mUiManageRefresh $d;update idletasks;grab set $d;focus $d.list
}
proc ::GX::MathematicsExplorer::_mUiManageRecords {w type} {
    variable ui;set state [_uiReadState $w];set result {}
    switch $type {
        definition {
            foreach definition [dict get $state definitions] {lappend result [dict create scope shared record $definition]}
            set fn [lindex [dict get $state functions] [_mUiFnIndex $w]]
            foreach definition [dict get $fn definitions] {lappend result [dict create scope local record $definition]}
        }
        system {foreach record [dict get $state systems] {lappend result [dict create scope shared record $record]}}
        family {foreach record [dict get $state families] {lappend result [dict create scope shared record $record]}}
    }
    return $result
}
proc ::GX::MathematicsExplorer::_mUiManageRefresh {d} {
    variable ui
    if {![winfo exists $d]} return
    set ui($d,records) [_mUiManageRecords $ui($d,owner) $ui($d,type)]
    $d.list delete 0 end
    foreach item $ui($d,records) {$d.list insert end "[dict get $item record id] — [dict get $item scope]"}
}
proc ::GX::MathematicsExplorer::_mUiManageEdit {d action} {
    variable ui
    set code [catch {
        set w $ui($d,owner);set type $ui($d,type);set records $ui($d,records)
        set index [lindex [$d.list curselection] 0]
        if {$action ne {add} && $index eq {}} {error {Select a declaration}}
        set original {};set scope shared
        if {$action ne {add}} {set original [dict get [lindex $records $index] record];set scope [dict get [lindex $records $index] scope]}
        if {$action eq {delete}} {_mUiManageSave $w $d $type $original $scope delete {};return}
        set plain {};foreach item $records {lappend plain [dict get $item record]}
        set initial $original
        switch $type {
            definition {
                if {$action eq {add}} {set initial [dict create id [_mUiUnique $plain relation] expression x unit 1]}
                dict set initial scope $scope
                set fields {{id Identity entry} {scope Scope choice {shared local}} {expression {Expression (bare named relations)} entry} {unit {Declared result unit} entry}}
            }
            family {
                if {$action eq {add}} {set initial [dict create id [_mUiUnique $plain family] label {New family} values {}]}
                set lines {};dict for {id value} [dict get $initial values] {lappend lines "$id = $value"};dict set initial assignments [join $lines \n]
                set fields {{id Identity entry} {label Name entry} {assignments {Shared overrides: name = value, one per line} text}}
            }
            system {
                if {$action eq {add}} {set initial [dict create id [_mUiUnique $plain system] unknowns [list [dict create id coefficient unit 1]] equations [list [dict create coefficients {coefficient 1} rhs 1 unit 1]]]}
                set names {};set lines {};foreach unknown [dict get $initial unknowns] {lappend names [dict get $unknown id];lappend lines "[dict get $unknown id] ; [dict get $unknown unit]"};dict set initial unknown_lines [join $lines \n]
                set lines {};foreach equation [dict get $initial equations] {set coefficients {};foreach id $names {lappend coefficients [dict get $equation coefficients $id]};lappend lines "[join $coefficients { ; }] ; [dict get $equation rhs] ; [dict get $equation unit]"};dict set initial equation_lines [join $lines \n]
                set fields {{id Identity entry} {unknown_lines {Unknowns: name ; unit, one per line (1..16)} text} {equation_lines {Rows: coefficients in unknown order ; right side ; row unit} text}}
            }
        }
        _mUiForm $w "[string totitle $type] declaration" $fields $initial [list ::GX::MathematicsExplorer::_mUiManageSave $w $d $type $original $scope save]
    } message options]
    if {$code==2} {return -options $options $message}
    if {$code} {tk_messageBox -parent $d -title {Mathematical declaration} -icon error -message $message}
}
proc ::GX::MathematicsExplorer::_mUiManageSave {w manager type original oldScope action values} {
    variable ui
    if {$ui($w,session_token) ne [sessionToken]} {error {Session changed; reopen Mathematics Explorer}}
    set state [_uiReadState $w];set fi [_mUiFnIndex $w];set functions [dict get $state functions];set fn [lindex $functions $fi]
    set scope shared
    if {$type eq {definition}} {set field definitions;if {$action eq {save}} {set scope [dict get $values scope];set record [dict remove $values scope]}
    } elseif {$type eq {family}} {
        set field families
        if {$action eq {save}} {
            set overrides {}
            foreach line [split [dict get $values assignments] \n] {if {[string trim $line] eq {}} continue;if {![regexp {^\s*([A-Za-z][A-Za-z0-9_]*)\s*=\s*(.+?)\s*$} $line unused id value]} {error {Use name = finite numeric value on each family line}};if {[dict exists $overrides $id]} {error {Duplicate family override}};finiteNumber $value {Family value};dict set overrides $id $value}
            set record [dict create id [dict get $values id] label [dict get $values label] values $overrides]
        }
    } else {
        set field systems
        if {$action eq {save}} {
            set unknowns {};set names {}
            foreach line [split [dict get $values unknown_lines] \n] {if {[string trim $line] eq {}} continue;set parts [lmap part [split $line {;}] {string trim $part}];if {[llength $parts]!=2} {error {Unknown rows need name ; unit}};lassign $parts id unit;lappend names $id;lappend unknowns [dict create id $id unit $unit]}
            set equations {}
            foreach line [split [dict get $values equation_lines] \n] {
                if {[string trim $line] eq {}} continue
                set parts [lmap part [split $line {;}] {string trim $part}]
                if {[llength $parts]!=[llength $names]+2} {error {Each equation needs one explicit coefficient per unknown, then right side and row unit}}
                set coefficients {};foreach id $names value [lrange $parts 0 end-2] {dict set coefficients $id $value}
                lappend equations [dict create coefficients $coefficients rhs [lindex $parts end-1] unit [lindex $parts end]]
            }
            set record [dict create id [dict get $values id] unknowns $unknowns equations $equations]
        }
    }
    # Remove the exact old declaration from its owning scope, then insert the
    # edited declaration; validation rejects collisions rather than renaming.
    foreach targetScope {shared local} {
        if {$targetScope eq {local} && $type ne {definition}} continue
        set items [expr {$targetScope eq {shared}?[dict get $state $field]:[dict get $fn $field]}]
        set kept {};foreach item $items {if {$original ne {} && $oldScope eq $targetScope && [dict get $item id] eq [dict get $original id]} continue;lappend kept $item}
        if {$action eq {save} && $scope eq $targetScope} {lappend kept $record}
        if {$targetScope eq {shared}} {dict set state $field $kept} else {dict set fn $field $kept}
    }
    lset functions $fi $fn;dict set state functions $functions
    if {$type eq {family} && $original ne {} && [dict get $state family_id] eq [dict get $original id]} {dict set state family_id [expr {$action eq {delete}?{}:[dict get $record id]}]}
    _mUiCommit $w $state;_mUiManageRefresh $manager
}
proc ::GX::MathematicsExplorer::_mUiRetirementRecord {id record} {
    variable retirements
    if {![info exists retirements]} {set retirements {}}
    dict set retirements $id $record
    while {[dict size $retirements]>64} {dict unset retirements [lindex [dict keys $retirements] 0]}
}
proc ::GX::MathematicsExplorer::_mUiRelease {allocation {attempt 0}} {
    # Terminal pipe EOF can precede a descendant's final process retirement.
    # Retry only the original lease authority; live/uncertain owners remain
    # protected. No forced release or deletion bypass is ever attempted.
    set id [dict get $allocation id];set reason {}
    if {[catch {::GX::resourceManagementRelease $id verified_orphan 0} reason]} {
        set phase waiting
    } elseif {[catch {::GX::resourceManagementCleanup [list $id]} reason]} {
        set phase waiting
    } elseif {[catch {set inspected [::GX::resourceManagementInspect $id]} reason]} {
        set phase waiting
    } elseif {[dict get $inspected removed]} {
        _mUiRetirementRecord $id [dict create phase removed attempts [expr {$attempt+1}]]
        return
    } else {set phase waiting;set reason [dict get $inspected reason]}
    if {$attempt<20} {
        _mUiRetirementRecord $id [dict create phase $phase attempts [expr {$attempt+1}] diagnostic $reason]
        after 500 [list ::GX::MathematicsExplorer::_mUiRelease $allocation [expr {$attempt+1}]]
    } else {
        # Inspectable bounded host diagnostic; the durable original Resource
        # record remains authoritative for later recovery/reconciliation.
        _mUiRetirementRecord $id [dict create phase protected attempts [expr {$attempt+1}] diagnostic $reason]
    }
}

proc ::GX::MathematicsExplorer::_mUiCancel {w} {
    variable ui
    if {[info exists ui($w,request)] && $ui($w,request) ne {}} {catch {::GX::scriptJobRequestCancel $ui($w,request) cancelled};set ui($w,request) {}}
    if {[info exists ui($w,serial)]} {incr ui($w,serial)}
    if {[winfo exists $w.top.cancel]} {$w.top.cancel configure -state disabled}
}
proc ::GX::MathematicsExplorer::_mUiStart {w operation {extra {}}} {
    variable ui;variable modelUiSerial
    set state [_uiReadState $w]
    if {$ui($w,session_token) ne [sessionToken]} {error {Session changed; close and reopen Mathematics Explorer}}
    _mUiCancel $w
    set allocation [::GX::resourceManagementAllocate mathematics_calculation [dict create category temporary kind directory lifetime operation retention_seconds 0 descendant_lease 1 session [::GX::sessionInspectionCurrentSession]]]
    set directory [dict get $allocation path]
    set context [_m2UnitContext]
    set request [dict merge [dict create operation $operation state $state unit_context $context] $extra]
    if {[string bytelength $request]>4194304} {_mUiRelease $allocation;error {Mathematical request exceeds 4 MiB}}
    set stream [::open [file join $directory request.tcldict] w]
    try {fconfigure $stream -encoding utf-8;puts $stream $request} finally {close $stream}
    set serial [incr modelUiSerial];set ui($w,serial) $serial
    set saved {};foreach name {GXTXT_RESOURCE_ROOT GXTXT_RESOURCE_LEASE} {dict set saved $name [list [info exists ::env($name)] [expr {[info exists ::env($name)]?$::env($name):{}}]]}
    try {
        set ::env(GXTXT_RESOURCE_ROOT) [::GX::resourceManagementRoot];set ::env(GXTXT_RESOURCE_LEASE) [dict get $allocation id]
        set command [list /usr/bin/setsid /usr/bin/tclsh [file join $::GX::scriptDir plugins modules viewer.mathematics_explorer ui mathematics_model_worker.tcl] $::GX::scriptDir $directory]
        set ui($w,request) [::GX::scriptJobAsync $command {} [list ::GX::MathematicsExplorer::_mUiDone $w $serial $allocation $operation $state $context $ui($w,session_token)] {timeout_ms 300000 max_bytes 33554432 process_group 1 ui_lifetime 1 separate_stderr 1 label {Mathematics calculation}}]
    } on error {message options} {_mUiRelease $allocation;return -options $options $message
    } finally {dict for {name previous} $saved {if {[lindex $previous 0]} {set ::env($name) [lindex $previous 1]} else {unset -nocomplain ::env($name)}}}
    $w.top.cancel configure -state normal
    _status $w "Running $operation through managed Numeric worker; the last valid graph is retained."
    return $ui($w,request)
}
proc ::GX::MathematicsExplorer::_uiPlot {w} {
    variable ui
    if {![winfo exists $w]} return
    if {[info exists ui($w,pending)] && $ui($w,pending) ne {}} {after cancel $ui($w,pending);set ui($w,pending) {}}
    if {[catch {_mUiStart $w calculate} message]} {_status $w "Not evaluated: $message. Last valid graph retained."}
}
proc ::GX::MathematicsExplorer::_mUiDone {w serial allocation operation state context token output} {
    variable ui
    try {
        if {![winfo exists $w] || ![info exists ui($w,serial)] || $ui($w,serial)!=$serial} return
        set ui($w,request) {};$w.top.cancel configure -state disabled
        if {$token ne [sessionToken] || [dict remove [_uiReadState $w] view_axes] ne [dict remove $state view_axes]} {error {Model or Session changed; stale calculation discarded}}
        _m2CheckUnitContext $context
        if {![dict get $output ok]} {error [dict get $output error]}
        set result [dict get $output result]
        if {$operation eq {calculate}} {
            ::GX::modulePublicApiActivate plot.dataset PLOT_DATASET_API_v4
            set model [nativeModel $state $result]
            if {[winfo exists $w.right.plot.native]} {::GX::PlotDatasetAPIv4::widgetConfigure $w.right.plot.native $model {prepared_model 1}
            } else {::GX::PlotDatasetAPIv4::widgetCreate $w.right.plot.native $model {prepared_model 1};pack $w.right.plot.native -fill both -expand 1;bind $w.right.plot.native <Button-1> [list ::GX::MathematicsExplorer::_uiPick $w %x %y]}
            if {[dict get $state view_axes] ne {}} {::GX::PlotDatasetAPIv4::widgetView $w.right.plot.native restore [dict get $state view_axes]} else {::GX::PlotDatasetAPIv4::widgetView $w.right.plot.native fit}
            set ui($w,computed) $result;set ui($w,computed_state) $state
            if {[dict get $state schema]==2} {set ui($w,view_key) [_mUiKey $w];set ui($w,restored_axes) {};_mUiRefresh $w;set count [llength [dict get $result segments]]
            } else {set ui($w,view_units) [list [dict get $state symbol_units] [dict get $state output_unit]];set count [llength [dict get $result series]]}
            _status $w "$count admitted trace(s); explicit units, independent domains and original Numeric/native graph."
        } elseif {$operation eq {integral}} {
            set lines {}
            foreach item $result {
                if {[dict get $item status] ne {available}} {lappend lines "[dict get $item segment_id]: [dict get $item status]";continue}
                lappend lines "[dict get $item segment_id]: [format %.12g [dict get $item value]] [dict get $item unit], actual interval [dict get $item interval]"
            }
            _status $w {Integration completed; results report actual connected sampled intervals.}
            set ui($w,integral) [join $lines \n];_mUiResult $w {Selected sampled integrals} "[join $lines \n]\nTrapezoidal values on each connected sampled interval; gaps are not integrated."
        } else {
            set ui($w,last_analysis) [dict create state COMPLETED result $result]
            _status $w {Selected analysis completed; finite sampling does not prove all solutions.}
            _mUiResult $w {Selected mathematical analysis} [_mUiAnalysisText $state $result]
        }
    } on error {message options} {_status $w "Calculation not adopted: $message. Last valid graph retained."
    } finally {_mUiRelease $allocation}
}
proc ::GX::MathematicsExplorer::_mUiResult {w title text} {
    set d $w.result;catch {destroy $d};toplevel $d;wm title $d $title;wm transient $d $w
    text $d.value -width 75 -height 18 -wrap word
    ttk::scrollbar $d.scroll -orient vertical -command [list $d.value yview];$d.value configure -yscrollcommand [list $d.scroll set]
    pack $d.scroll -side right -fill y;pack $d.value -fill both -expand 1
    $d.value insert end $text;$d.value configure -state disabled
    ttk::button $d.close -text Close -command [list destroy $d];pack $d.close -side bottom -pady 5
    bind $d <Escape> [list destroy $d];focus $d.close
}
proc ::GX::MathematicsExplorer::_uiIntegral {w} {if {[catch {_mUiStart $w integral} message]} {_notify $w $message}}
proc ::GX::MathematicsExplorer::_uiAnalyze {w} {
    variable ui
    if {[catch {
        set state [_uiReadState $w];set mode $ui($w,analysis_mode)
        if {$mode ni {roots intersections extrema}} {error {Select roots, intersections or extrema}}
        if {[dict get $state schema]==2} {
            set fields {{minimum {Study X minimum (empty = selected domain)} entry} {maximum {Study X maximum (empty = selected domain)} entry}}
            set initial [dict create minimum {} maximum {} partner {}]
            if {$mode eq {intersections}} {
                set choices {};foreach fn [dict get $state functions] {if {[dict get $fn id] ne [dict get $state selected_function]} {lappend choices [dict get $fn id]}}
                if {![llength $choices]} {error {Declare another function for intersections}}
                lappend fields [list partner {Other function identity} choice $choices];dict set initial partner [lindex $choices 0]
            }
            _mUiForm $w {Selected mathematical study} $fields $initial [list ::GX::MathematicsExplorer::_mUiAnalyzeRequest $w $mode]
        } else {_mUiStart $w analyze [dict create mode $mode partner {} minimum {} maximum {}]}
    } message]} {_notify $w $message}
}
proc ::GX::MathematicsExplorer::_mUiAnalyzeRequest {w mode values} {
    set partner [::GX::datasetPublicationV2DictDefault $values partner {}]
    _mUiStart $w analyze [dict create mode $mode partner $partner minimum [dict get $values minimum] maximum [dict get $values maximum]]
}
proc ::GX::MathematicsExplorer::_uiCancelAnalysis {w} {_mUiCancel $w;_status $w {Calculation cancelled; last valid graph retained.}}
proc ::GX::MathematicsExplorer::_uiNew {w} {
    variable ui
    if {![_uiConfirmDiscard $w]} return
    set ui($w,doc_id) {};set ui($w,doc_receipt) {};set ui($w,workspace_name) {}
    _uiSetState $w [initialState2];set ui($w,saved_state) [_uiReadState $w]
    _mUiWorkspaceMenu $w;_uiSchedule $w
}
proc ::GX::MathematicsExplorer::_uiPick {w x y} {
    variable ui
    if {$ui($w,computed) ne {} && [dict remove $ui($w,computed_state) view_axes] ne [dict remove [_uiReadState $w] view_axes]} {_status $w {This retained graph belongs to earlier declarations; finish the current calculation before picking.};return}
    unset -nocomplain ui($w,last_pick)
    _uiPickLegacy $w $x $y
    if {![_mUiIs2 $w] || ![info exists ui($w,last_pick)] || $ui($w,computed) eq {}} return
    set hit $ui($w,last_pick)
    if {![dict exists $hit series_id]} return
    foreach segment [dict get $ui($w,computed) segments] {
        if {[dict get $segment id] ne [dict get $hit series_id]} continue
        dict set ui($w,model) selected_function [dict get $segment function_id];dict set ui($w,model) selected_branch [dict get $segment branch_id]
        _mUiRefresh $w;_uiChanged $w;break
    }
}
proc ::GX::MathematicsExplorer::_uiPublishDialog {w} {
    _uiPublishDialogLegacy $w
    if {[_mUiIs2 $w] && [winfo exists $w.publish.hint]} {$w.publish.hint configure -text {One independent Dataset per admitted connected component, with exact units and synthetic model provenance. The ID is a create-only prefix.}}
}
proc ::GX::MathematicsExplorer::_mUiWorkspaceMenu {w} {
    if {![winfo exists $w.top.workspace.menu]} return
    set menu $w.top.workspace.menu;$menu delete 0 end;catch {destroy $menu.ownerActions}
    set provider [expr {[_mUiIs2 $w]?{mathematics_explorer_v2}:{mathematics_explorer}}]
    ::GX::sessionWorkspaceViewerMenu $menu $provider [_workspaceCallbacks $w] $w
}
proc ::GX::MathematicsExplorer::_uiDispose {w} {_mUiCancel $w;_uiDisposeLegacy $w}
proc ::GX::MathematicsExplorer::_uiDestroyed {w actual} {if {$w eq $actual} {_mUiCancel $w};_uiDestroyedLegacy $w $actual}

proc ::GX::MathematicsExplorer::_mUiModalParentDestroyed {d parent actual} {
    if {$actual eq $parent && [winfo exists $d]} {_mUiFormClose $d}
}
proc ::GX::MathematicsExplorer::_mUiModalOutside {d x y} {
    if {![winfo exists $d]} return
    if {$x<[winfo rootx $d] || $y<[winfo rooty $d] || $x>=[winfo rootx $d]+[winfo width $d] || $y>=[winfo rooty $d]+[winfo height $d]} {after idle [list ::GX::MathematicsExplorer::_mUiModalRefocus $d]}
}
proc ::GX::MathematicsExplorer::_mUiModalRefocus {d} {
    if {[winfo exists $d] && [grab current $d] eq $d} {focus -force $d.buttons.ok}
}
proc ::GX::MathematicsExplorer::_mUiRevealFocus {w widget} {
    if {![winfo exists $w.left.scroll] || ![string match $w.left.scroll.body.* $widget]} return
    set canvas $w.left.scroll
    set y [expr {[winfo rooty $widget]-[winfo rooty $canvas]}]
    if {$y<0 || $y+[winfo height $widget]>[winfo height $canvas]} {
        set box [$canvas bbox all];set total [expr {max(1,[lindex $box 3])}]
        set top [expr {[$canvas canvasy 0]+$y-12}]
        $canvas yview moveto [expr {max(0,min(1,double($top)/$total))}]
    }
}
proc ::GX::MathematicsExplorer::_mUiWheel {w widget event delta} {
    if {![winfo exists $w.left.scroll] || ![string match $w.left.scroll* $widget] || [winfo class $widget] in {Treeview Text}} return
    set direction [expr {$event eq {<Button-4>} || ($event eq {<MouseWheel>} && $delta>0)?-1:1}]
    $w.left.scroll yview scroll [expr {3*$direction}] units
}
proc ::GX::MathematicsExplorer::_mUiToolbar {w} {
    variable ui
    if {![winfo exists $w.top]} return
    set available [expr {max(400,[winfo width $w.top]-20)}]
    set widgets {};set widths {}
    foreach widget [winfo children $w.top] {
        if {[regexp {^[.]gx_mathematics_explorer[.]top[.]wrap[0-9]+$} $widget]} continue
        lappend widgets $widget;lappend widths [expr {[winfo reqwidth $widget]+6}]
    }
    set key [list $available [tk scaling] $widths]
    if {[info exists ui($w,toolbar_key)] && $ui($w,toolbar_key) eq $key} return
    set ui($w,toolbar_key) $key
    foreach widget $widgets {pack forget $widget;grid forget $widget}
    foreach row [winfo children $w.top] {if {[regexp {^[.]gx_mathematics_explorer[.]top[.]wrap[0-9]+$} $row]} {destroy $row}}
    # Independent row frames prevent shared grid-column maxima from making a
    # visually shorter row wider than the sum used by the wrapping decision.
    set rowIndex -1;set used $available
    foreach widget $widgets width $widths {
        if {$used+$width>$available} {
            set row $w.top.wrap[incr rowIndex];ttk::frame $row
            pack $row -side top -anchor w -fill x
            # Command widgets retain their original logical parent/identity.
            # Lower the sibling layout frame so it cannot paint over them.
            lower $row
            set used 0
        }
        pack $widget -in $row -side left -padx 3 -pady 2
        incr used $width
    }
}

proc ::GX::MathematicsExplorer::_mUiFormRegion {d} {if {[winfo exists $d.viewport.canvas]} {$d.viewport.canvas configure -scrollregion [$d.viewport.canvas bbox all]}}
proc ::GX::MathematicsExplorer::_mUiFormWidth {d width} {if {[winfo exists $d.viewport.canvas]} {$d.viewport.canvas itemconfigure body -width $width}}
proc ::GX::MathematicsExplorer::_mUiFormReveal {d widget} {
    if {![winfo exists $d.viewport.canvas] || ![string match $d.viewport.canvas.body.* $widget]} return
    set canvas $d.viewport.canvas;set y [expr {[winfo rooty $widget]-[winfo rooty $canvas]}]
    if {$y<0 || $y+[winfo height $widget]>[winfo height $canvas]} {set total [expr {max(1,[lindex [$canvas bbox all] 3])}];$canvas yview moveto [expr {max(0,min(1,double([$canvas canvasy 0]+$y-10)/$total))}]}
}
proc ::GX::MathematicsExplorer::_mUiFormWheel {d widget event delta} {
    if {![winfo exists $d.viewport.canvas] || ![string match $d.viewport.canvas.body* $widget] || [winfo class $widget] eq {Text}} return
    set direction [expr {$event eq {<Button-4>} || ($event eq {<MouseWheel>} && $delta>0)?-1:1}]
    $d.viewport.canvas yview scroll [expr {3*$direction}] units
}

proc ::GX::MathematicsExplorer::_mUiAnalysisText {state results} {
    if {[dict get $state schema]==1} {set results [list [dict create function_id f1 branch_id main partner_function {} result $results]]}
    set lines {}
    foreach component $results {
        set result [dict get $component result]
        set xunit [dict get $result variable_unit];set yunit [dict get $result response_unit]
        lappend lines "Function [dict get $component function_id], branch [dict get $component branch_id]"
        set partner [::GX::datasetPublicationV2DictDefault $component partner_function {}]
        if {$partner ne {}} {lappend lines "Intersection partner: $partner"}
        lappend lines "Study interval: [dict get $result interval] $xunit"
        lappend lines "Outcome: [string map {_ { }} [dict get $result status]]"
        foreach x [dict get $result roots] residual [dict get $result root_residuals] kind [dict get $result root_kinds] {
            lappend lines "  x = [format %.12g $x] $xunit; residual [format %.6g $residual] $yunit ([string map {_ { }} $kind])"
        }
        foreach x [dict get $result extrema_x] y [dict get $result extrema_y] kind [dict get $result extrema_kinds] {
            lappend lines "  [string totitle [string map {_ { }} $kind]]: x = [format %.12g $x] $xunit; response = [format %.12g $y] $yunit"
        }
        lappend lines "Samples: [dict get $result sample_count]; function evaluations: [dict get $result function_evaluations]"
        if {[llength [dict get $result failures]]} {lappend lines "Candidate failures: [dict get $result failures]"}
        lappend lines {}
    }
    if {![llength $results]} {lappend lines {No admitted components in the requested study interval.}}
    lappend lines {Numerical candidates are not a completeness proof or an uncertainty estimate.}
    return [join $lines \n]
}
