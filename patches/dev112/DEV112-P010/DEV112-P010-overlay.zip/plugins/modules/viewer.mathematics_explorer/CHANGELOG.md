# 0.2.0 — DEV112-P010

Add general named model2 through existing Numeric/Unit/Workspace/Publication/Plot
owners; preserve schema1. Add approved bounded declaration controls, managed worker
lifetime/cancel/stale guards, selected calculus, explicit connected publication and
units. Extend the original Python/Octave binding without a parallel scripting
engine. Exact independent qualification belongs to the P010 delivery matrix.

## 0.1.2 — 2026-10-17

Declare distinct native-resolution scientific catalog artwork, short title and semantic group through the existing Viewer Provider descriptor.

# Mathematics Explorer change history

##0.1.1 — framework integration adapter

Preserve the independent prototype's bounded workflows. Adopt public shared
Numeric expression evaluation/analysis and Unit Registry; use the accepted
native v4 graph widget with persisted numerical viewport and explicit retained
Graph publication. Add current functional guidance and original-source receipts.

##0.1.0 — independently supplied source prototype

Original artifact and exact SHA remain recorded in integration provenance.
