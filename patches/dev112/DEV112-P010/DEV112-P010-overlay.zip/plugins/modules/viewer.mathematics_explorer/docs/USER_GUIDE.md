# Mathematics Explorer — P010 model2

New work opens a generic named model. Existing version1 Workspaces open their
original three-function controls and keep their original expressions and units.
Save model uses the original versioned Session Workspace owner. The old model
is never implicitly replaced with a model2 record.

The existing toolbar and splitter remain. At smaller widths, the same commands
wrap inside their top region. The left declaration area scrolls; keyboard focus
reveals offscreen fields. The right area retains the original interactive native
graph, zoom, pan, Fit and picking. Read the status before using a retained frame:
a changed or failed model keeps the last valid graph until a new result succeeds.
Calculation and numerical studies run through managed, cancellable workers.

The bounded function list shows visibility, name and output unit. Select a
function, then a branch. Right-click or Shift+F10 opens Add, Edit, Duplicate and
Delete; Enter/double-click edits. The function menu also toggles visibility and
selects all its branches for calculus. At least one function must stay enabled.

Branch editors retain the expression, explicit inclusive/open bounds, independent
sample count (0 inherits), uniform/explicit grid and excluded intervals. An empty
bound uses the common outer domain. Explicit X values are space-separated real
coordinates. Each exclusion line is `lower ; upper ; include lower ; include upper`,
where inclusion flags are0/1. Numeric expressions and named parameters may define
bounds. Branch order and boundary ownership are explicit; overlapping branches
are refused. Gaps stay disconnected. No smooth derivative is invented at a corner.

The named parameter list shows exact values, physical units and scope. Select an
input to enter an exact value or use its configured linear/logarithmic slider.
Enter or leaving the exact field commits it. Text and slider values are not rounded to four
significant figures, including the retained schema1 slider handler. Edit a declaration to set its unit, shared/local scope,
description and slider range. Local inputs explicitly shadow shared inputs only
inside that function. Derived and solved values are visibly read-only.

The parameter context menu opens reusable definitions, small linear systems and
named family managers. Definitions use bare named relations such as
`VoltageDrop=Resistance*Current` (enter the identity and expression separately).
Original Numeric owns expression grammar, functions and dimensional arithmetic.
For a system, enter one `unknown ; unit` per line, then one equation per line:
coefficients in that same unknown order, right side, and row unit, separated by
semicolons. Declare every coefficient explicitly, including zero. Only bounded
square, full-rank systems are supported. Family rows use `name = value` for shared
numeric overrides. Selecting a family does not infer an interpolation law.
Editing an effective shared value switches to manual inputs while preserving the
other effective values and the original recorded family.

Global domain/default sampling and common X unit stay in their original left
regions. Function and optional branch output units belong to their declarations.
Different output quantities use existing native data panels. Derivative,
Integrate selected and Analyze use the selected function/branch. Analyze opens an
owned modal for an optional study subinterval and an explicit other-function
choice for intersections. Results remain sampled, bounded numerical evidence;
they do not prove all roots/extrema or measurement uncertainty. Integrals report
actual sampled limits separately for each connected component.

Save the exact current model before Publish Dataset/Graph. Each admitted connected
component becomes its own canonical Dataset with its own X grid, units and full
synthetic/formula/domain/family provenance. No false common grid is fabricated.
Create-only output IDs never overwrite scientific data. Later publication failure
reports already committed components rather than deleting them. Original Plotv4
owns graph publication. Bridge/API details are in the model2 and API manuals.

The standalone `examples/mathematics_2d21` reference is synthetic model-generated
theory. The generic viewer has no 2D21 mode, fitting engine or family predictor.

---

## Original schema1 controls and historical workflow

The following retained guide describes loaded version1 Workspaces only.

# Mathematics Explorer

## P006 source-only inert value adapter proposal

The existing Script registration adds `finiteNumber(value, label)`,
`tokenize(expression)` and `parseExpression(source)` through normal module
activation and the original Tcl owners. Arguments are text; results are a
finite double, ordered text token pairs and tagged AST cells with double
constants. The adapter implements no formula evaluator. New runtime checks
and independent acceptance remain pending. See framework reference
`docs/api/NONFROZEN_VALUE_FACETS_P006.md` for exact bounds and held tasks.

Mathematics Explorer evaluates real functions through the public Numeric service
and presents them in the shared native interactive graph. It requires an open
Session. The optional module is separate from numerical Analysis selection.

## Functions, parameters and units

Enable up to three functions. Each row provides a label, preset and editable
formula. The accepted bounded formula grammar contains `x`, `a`, `b`, `c`, `pi`,
parentheses, `+ - * / ^` and `sin`, `cos`, `tan`, `exp`, `log`, `log10`, `sqrt`,
`abs`. Powers associate right to left; `-x^2` means `-(x^2)`. Expressions are data,
not Tcl, Python, Octave or shell commands.

Set parameters using their numeric fields or sliders. Sliders cover −10 to10;
the fields accept other finite values. Set the increasing X interval and32–1201
samples. **Plot / Refresh** evaluates the model. Changes schedule an update after
900ms; the bounded public worker call is synchronous.

Declare the units of X, each parameter and Y. Use `1` for dimensionless values.
Compatible scales are converted by the shared Unit Registry. For example,
`a*x+b`, with X in V, a in1 and b in V, can display Y in mV. A dimensioned sine,
incompatible sum, unknown unit, absolute affine arithmetic, nonfinite result or
invalid real domain produces an explicit error. Trigonometric arguments are
normalized dimensionless quantities; the radians convention applies. A failed
edit retains the previous valid graph with an explicit error status.

## Numerical analysis

Save the current model, choose **roots**, **intersections** or **extrema**, then **Analyze**. Roots and
extrema use Function1; intersections require Functions1 and2 enabled. The
analysis uses the displayed interval, explicit parameter/unit declarations and
public Numeric root/minimization methods. Results show status, residuals,
physical units, evaluation count and limitations.

The service samples a bounded grid to locate candidate intervals. It verifies
crossing roots and may identify non-crossing residual candidates. Neither finite
sampling nor a small residual proves all roots, continuity or exact
multiplicity. An identically near-zero sampled function remains indeterminate.
Local extrema are interior candidates; endpoint values are reported separately.
No measurement uncertainty or confidence interval is estimated. Analysis runs through the existing durable Script Jobs; **Cancel analysis** cancels only its owned process tree. The GUI remains responsive. Edited, replaced or foreign-Session models cannot adopt stale results. Closing the Viewer leaves the owned Job and its actual log available in Jobs.

**Show sampled derivative of F1** adds a separate native panel with its actual
unit. **Integrate F1** returns a composite trapezoidal integral and product unit.
Both depend on the selected sample grid. Compare suitable grids independently
when numerical accuracy matters.

## Native graph interaction and persistence

Wheel input zooms; middle-button drag pans; double-click fits the complete
sampled scientific extent, including negative coordinates. Clicking uses native
point identities. Resize changes presentation only. **Save model** persists
formulas, parameters, units and current numerical viewport through the Session's
Interactive Document authority. **Open…** restores a saved model and its view.
A Session switch cannot transfer an old window's work into another Session.

**Publish Dataset…** requires a saved current model and a new Dataset ID. It
creates canonical `x`, enabled `f1`/`f2`/`f3`, and optional `f1_derivative`
Variables with actual units, formula and Document provenance. **Publish Graph…**
also creates a retained native Graph Variant in Plots. Publication freezes
sampled values; later model edits do not change the published Dataset or Graph.
If a later Graph phase fails, its already committed Dataset remains available
and is identified in the error. Existing scientific data are never replaced.

The GUI does not overlay experimental Datasets or edit arbitrary multivariable
models. Scripts may use the public [Numeric expression operations](../../../../docs/api/NUMERIC_EXPRESSION_OPERATIONS.md)
for bounded canonical Dataset inputs, richer registered pointwise functions and
managed Script Job cancellation. The GUI's expression and sampling bounds remain
explicit. This is a numerical explorer, not a symbolic algebra system.

## Supplied-value Script Bridge operations

The existing provider now exposes its supplied-value model/predicate operations through normal Python/Octave admission. Complete representation, defaults, weak predicate semantics and resource limits: `docs/api/P006_SUPPLIED_VALUE_BINDINGS.md`. No GUI, renderer, scientific producer or publication authority is added.
