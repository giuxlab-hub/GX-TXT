# SPDX-License-Identifier: GPL-3.0-or-later
# Independent model declarations; discovery does not open a plot or run Numeric.
namespace eval ::GX::MathematicsExplorer {}
if {![llength [info commands ::GX::MathematicsExplorer::validateState]]} {
    source [file join [file dirname [info script]] .. lib expression.tcl]
    source [file join [file dirname [info script]] .. lib science.tcl]
}
::GX::nativeWorkspaceShapeRegister mathematics_explorer_schema1 {record {
    schema int title text xmin real xmax real samples int symbol_units {map text} output_unit text parameters {map real}
    derivative bool functions {array {record {id text label text preset text enabled bool expression text}}}
    view_axes {array {record {panel_id text axis text limits {array real} plot_rect {array real} scale text direction text aspect text
        ticks {array {record {value real display_value real label text device real}}}}}}
}}
::GX::nativeWorkspaceShapeRegister mathematics_explorer {codec ::GX::MathematicsExplorer::workspaceEncode}
proc ::GX::MathematicsExplorer::workspaceEncode {payload} {
    set payload [dict remove $payload workspace_metadata]
    if {[dict get $payload schema]==2} {return [stateEncode2 $payload]}
    return [::GX::nativeWorkspaceEncode {named mathematics_explorer_schema1} $payload]
}
proc ::GX::MathematicsExplorer::workspaceOpen {id} {
    ::GX::modulePublicApiActivate viewer.mathematics_explorer MATHEMATICS_EXPLORER_API_v1
    return [open [dict create document_id $id]]
}
