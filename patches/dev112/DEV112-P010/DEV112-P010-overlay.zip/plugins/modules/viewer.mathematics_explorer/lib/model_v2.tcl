# SPDX-License-Identifier: GPL-3.0-or-later
# A bounded inert scientific model. Numeric and Unit Registry remain the only
# expression, dimensional arithmetic and linear-solve authorities.
namespace eval ::GX::MathematicsExplorer {}
proc ::GX::MathematicsExplorer::initialState2 {} {
    return [dict create schema 2 title {Mathematics Explorer} xmin -6 xmax 6 samples 301 x_unit 1 parameters [list \
        [dict create id amplitude label Amplitude description {} group Shared unit 1 value 1 slider {mode linear min -10 max 10}]] \
        definitions {} systems {} families {} family_id {} functions [list [dict create id f1 label Sine enabled 1 output_unit 1 \
        parameters {} definitions {} branches [list [dict create id main label Main expression {amplitude*sin(x)} lower {} upper {} \
        lower_closed 1 upper_closed 1 samples 0 sampling uniform explicit_x {} exclusions {}]]]] \
        selected_function f1 selected_branch {} derivative 0 view_axes {}]
}
proc ::GX::MathematicsExplorer::_m2Closed {value allowed label} {
    if {[catch {dict size $value}]} {error "$label must be a dictionary"}
    foreach field [dict keys $value] {if {$field ni $allowed} {error "Unknown $label field '$field'"}}
}
proc ::GX::MathematicsExplorer::_m2Id {id} {
    if {![regexp {^[A-Za-z][A-Za-z0-9_]{0,47}$} $id] || $id in {x pi e}} {error "Invalid or reserved mathematical identity '$id'"}
    return $id
}
proc ::GX::MathematicsExplorer::_m2Text {text limit label} {
    if {[string length $text]>$limit || [regexp {[\r\n\t]} $text]} {error "Invalid bounded $label"}
}
proc ::GX::MathematicsExplorer::_m2Expression {text} {
    if {[string length $text]>8192} {error {Expression length exceeds 8192 characters}}
    if {[string trim $text] eq {} || [regexp {[^A-Za-z0-9_.,+*/^()[:space:]-]} $text]} {error {Expression must use the public Numeric data-only grammar}}
    # The public Numeric parser owns its exact token/program bounds, grammar,
    # precedence, pointwise function catalog and dimensional rules.
}
proc ::GX::MathematicsExplorer::_m2Unit {unit} {::GX::unitRegistryArithmeticPlan + $unit $unit;return $unit}
proc ::GX::MathematicsExplorer::_m2UnitContext {} {
    set context {}
    foreach unit [lsort [::GX::unitRegistryList]] {dict set context $unit [dict remove [::GX::unitRegistryDefinition $unit] symbol]}
    if {[dict size $context]>4096} {error {Unit declaration context exceeds 4096 registered symbols}}
    return $context
}
proc ::GX::MathematicsExplorer::_m2CheckUnitContext {context} {
    set original [::GX::nativeWorkspaceEncode {map {map text}} $context]
    set current [::GX::nativeWorkspaceEncode {map {map text}} [_m2UnitContext]]
    ::GX::_nativeWorkspaceLibraryRequire
    if {![::GX::workspaceNative typed_equivalent $original $current]} {error {Unit definitions changed; recompute before adopting or publishing values}}
}
proc ::GX::MathematicsExplorer::_m2Parameters {parameters} {
    if {[llength $parameters]>64} {error {At most 64 parameter declarations per scope}}
    set used {}
    foreach p $parameters {
        _m2Closed $p {id label description group unit value slider} parameter
        foreach key {id label description group unit value slider} {dict get $p $key}
        set id [_m2Id [dict get $p id]];if {$id in $used} {error "Duplicate parameter '$id'"};lappend used $id
        foreach key {label group} {_m2Text [dict get $p $key] 100 $key};_m2Text [dict get $p description] 512 description
        _m2Unit [dict get $p unit];finiteNumber [dict get $p value] "Parameter $id"
        set slider [dict get $p slider];_m2Closed $slider {mode min max} slider
        if {[dict get $slider mode] ni {none linear logarithmic}} {error {Slider mode must be none, linear or logarithmic}}
        set lo [finiteNumber [dict get $slider min] {Slider minimum}];set hi [finiteNumber [dict get $slider max] {Slider maximum}]
        if {$lo>=$hi || ([dict get $slider mode] eq {logarithmic} && $lo<=0)} {error {Invalid slider range}}
    }
    return $used
}
proc ::GX::MathematicsExplorer::_m2Definitions {definitions ids} {
    if {[llength $definitions]>64} {error {At most 64 reusable definitions per scope}}
    foreach item $definitions {
        _m2Closed $item {id expression unit} definition
        set id [_m2Id [dict get $item id]];if {$id in $ids} {error "Duplicate mathematical symbol '$id'"};lappend ids $id
        _m2Expression [dict get $item expression];_m2Unit [dict get $item unit]
    }
    return $ids
}
proc ::GX::MathematicsExplorer::validateState2 {state} {
    set state [dict remove $state workspace_metadata]
    _m2Closed $state {schema title xmin xmax samples x_unit parameters definitions systems families family_id functions selected_function selected_branch derivative view_axes} model
    foreach key {schema title xmin xmax samples x_unit parameters definitions systems families family_id functions selected_function selected_branch derivative view_axes} {dict get $state $key}
    if {[dict get $state schema] ne {2}} {error {Unsupported mathematical model schema}}
    _m2Text [dict get $state title] 100 title
    if {[finiteNumber [dict get $state xmin] {X minimum}]>=[finiteNumber [dict get $state xmax] {X maximum}]} {error {X interval must increase}}
    set n [dict get $state samples];if {![string is integer -strict $n] || $n<2 || $n>20000} {error {Sample count must be 2..20000}}
    _m2Unit [dict get $state x_unit]
    set ids [_m2Parameters [dict get $state parameters]]
    set parameterIds $ids;set ids [_m2Definitions [dict get $state definitions] $ids]
    if {[llength [dict get $state systems]]>8} {error {At most eight explicit linear systems}}
    foreach system [dict get $state systems] {
        _m2Closed $system {id unknowns equations} system;_m2Id [dict get $system id]
        set unknowns [dict get $system unknowns];set equations [dict get $system equations]
        if {[llength $unknowns]<1 || [llength $unknowns]>16 || [llength $unknowns]!=[llength $equations]} {error {Coefficient derivation requires a square system of 1..16 unknowns}}
        set names {}
        foreach unknown $unknowns {
            _m2Closed $unknown {id unit} unknown;set id [_m2Id [dict get $unknown id]]
            if {$id in $ids} {error "Duplicate system unknown '$id'"};lappend ids $id;lappend names $id;_m2Unit [dict get $unknown unit]
        }
        foreach equation $equations {
            _m2Closed $equation {coefficients rhs unit} equation;_m2Unit [dict get $equation unit];_m2Expression [dict get $equation rhs]
            if {[lsort [dict keys [dict get $equation coefficients]]] ne [lsort $names]} {error {Each equation must declare every coefficient explicitly}}
            dict for {id expression} [dict get $equation coefficients] {_m2Expression $expression}
        }
    }
    if {[llength [dict get $state families]]>64} {error {At most 64 independent family sets}}
    set familyIds {}
    foreach family [dict get $state families] {
        _m2Closed $family {id label values} family;set id [_m2Id [dict get $family id]]
        if {$id in $familyIds} {error {Duplicate family identity}};lappend familyIds $id;_m2Text [dict get $family label] 100 {family label}
        dict for {id value} [dict get $family values] {if {$id ni $parameterIds} {error "Unknown shared family parameter '$id'"};finiteNumber $value {Family parameter}}
    }
    if {[dict get $state family_id] ne {} && [dict get $state family_id] ni $familyIds} {error {Unknown selected parameter family}}
    set functions [dict get $state functions]
    if {[llength $functions]<1 || [llength $functions]>32} {error {Declare 1..32 stable functions}}
    set functionIds {};set active 0
    foreach fn $functions {
        _m2Closed $fn {id label enabled output_unit parameters definitions branches} function
        set id [_m2Id [dict get $fn id]];if {$id in $functionIds} {error {Duplicate function identity}};lappend functionIds $id
        _m2Text [dict get $fn label] 100 {function label};_m2Unit [dict get $fn output_unit]
        if {[dict get $fn enabled] ni {0 1}} {error {Function visibility must be Boolean}};incr active [dict get $fn enabled]
        set localIds [_m2Parameters [dict get $fn parameters]]
        _m2Definitions [dict get $fn definitions] [lsort -unique [concat $ids $localIds]]
        set branchIds {};set branches [dict get $fn branches]
        if {[llength $branches]<1 || [llength $branches]>32} {error {Declare 1..32 ordered branches per function}}
        foreach branch $branches {
            _m2Closed $branch {id label expression output_unit lower upper lower_closed upper_closed samples sampling explicit_x exclusions} branch
            set bid [_m2Id [dict get $branch id]];if {$bid in $branchIds} {error {Duplicate branch identity}};lappend branchIds $bid
            _m2Text [dict get $branch label] 100 {branch label};_m2Expression [dict get $branch expression]
            if {[dict exists $branch output_unit] && [dict get $branch output_unit] ne {}} {_m2Unit [dict get $branch output_unit]}
            foreach field {lower upper} {set value [dict get $branch $field];if {$value ne {}} {_m2Expression $value}}
            foreach field {lower_closed upper_closed} {if {[dict get $branch $field] ni {0 1}} {error {Boundary ownership must be Boolean}}}
            set count [dict get $branch samples];if {![string is integer -strict $count] || ($count!=0 && $count<2) || $count>20000} {error {Per-branch sample count must be 0 (inherit) or 2..20000}}
            if {[dict get $branch sampling] ni {uniform explicit}} {error {Sampling must be uniform or explicit}}
            set xs [dict get $branch explicit_x];if {[llength $xs]>20000} {error {Explicit grid exceeds 20000 values}}
            set previous -Inf;foreach x $xs {set x [finiteNumber $x {Explicit X}];if {$x<=$previous} {error {Explicit X must strictly increase}};set previous $x}
            if {[dict get $branch sampling] eq {explicit} && [llength $xs]<2} {error {Explicit sampling requires at least two X values}}
            if {[llength [dict get $branch exclusions]]>64} {error {At most 64 declared excluded intervals}}
            foreach exclusion [dict get $branch exclusions] {
                _m2Closed $exclusion {lower upper lower_closed upper_closed} exclusion
                foreach field {lower upper} {_m2Expression [dict get $exclusion $field]}
                foreach field {lower_closed upper_closed} {if {[dict get $exclusion $field] ni {0 1}} {error {Excluded boundary ownership must be Boolean}}}
            }
        }
        if {$id eq [dict get $state selected_function] && [dict get $state selected_branch] ne {} && [dict get $state selected_branch] ni $branchIds} {error {Unknown selected branch}}
    }
    if {!$active || [dict get $state selected_function] ni $functionIds || [dict get $state derivative] ni {0 1}} {error {Invalid active/selected function or calculus flag}}
    return $state
}

# Identifier discovery only assembles dependencies. It does not accept grammar
# or execute an expression; the original Numeric parser makes that decision.
proc ::GX::MathematicsExplorer::_m2References {expression} {
    set result {}
    foreach span [regexp -all -inline -indices {[A-Za-z_][A-Za-z0-9_]*} $expression] {
        lassign $span first last;set id [string range $expression $first $last]
        set tail [string trimleft [string range $expression [expr {$last+1}] end]]
        if {[string index $tail 0] eq {(} || $id in {pi e}} continue
        # The e in a scientific numeric literal is not an independent symbol.
        if {$first>0 && [string index $expression [expr {$first-1}]] in {0 1 2 3 4 5 6 7 8 9 .} && [regexp {^[eE][0-9]*$} $id]} continue
        if {$id ni $result} {lappend result $id}
    }
    return $result
}
proc ::GX::MathematicsExplorer::_m2Evaluate {expression values units definitions outputUnit {stack {}}} {
    set symbols {};set symbolUnits {}
    foreach id [_m2References $expression] {
        if {$id in $stack} {error "Cyclic mathematical dependency: [join [concat $stack $id] { -> }]"}
        if {[dict exists $values $id]} {set data [dict get $values $id]} elseif {[dict exists $definitions $id]} {
            set definition [dict get $definitions $id]
            set response [_m2Evaluate [dict get $definition expression] $values $units $definitions [dict get $definition unit] [concat $stack $id]]
            set data [dict get $response values]
        } else {error "Unresolved mathematical symbol '$id'"}
        if {![dict exists $units $id]} {error "Explicit unit missing for '$id'"}
        dict set symbols $id [::GX::ScientificTransportv1::array [list [llength $data] 1] $data]
        dict set symbolUnits $id [::GX::ScientificTransportv1::text [dict get $units $id]]
    }
    if {[dict size $symbols]>64} {error {An expression dependency closure exceeds Numeric's 64-symbol budget}}
    return [::GX::NumericAPIv1::callOperation expression_evaluate [list [::GX::ScientificTransportv1::text $expression] \
        [::GX::ScientificTransportv1::struct $symbols] [::GX::ScientificTransportv1::struct $symbolUnits]] \
        [::GX::ScientificTransportv1::struct [dict create output_unit [::GX::ScientificTransportv1::text $outputUnit]]]]
}
proc ::GX::MathematicsExplorer::_m2Scalar {expression values units definitions outputUnit} {
    set result [_m2Evaluate $expression $values $units $definitions $outputUnit]
    set value [dict get $result values];if {[llength $value]!=1} {error {A scalar mathematical value was required}}
    return [finiteNumber [lindex $value 0] {Derived scalar}]
}
proc ::GX::MathematicsExplorer::_m2Context {state {fn {}} {shared {}}} {
    if {$shared eq {}} {
    set values {};set units [dict create x [dict get $state x_unit]];set definitions {};set receipts {}
    foreach p [dict get $state parameters] {dict set values [dict get $p id] [list [dict get $p value]];dict set units [dict get $p id] [dict get $p unit]}
    foreach family [dict get $state families] {if {[dict get $family id] eq [dict get $state family_id]} {dict for {id value} [dict get $family values] {dict set values $id [list $value]}}}
    foreach definition [dict get $state definitions] {dict set definitions [dict get $definition id] $definition;dict set units [dict get $definition id] [dict get $definition unit]}
    foreach system [dict get $state systems] {
        set unknowns [dict get $system unknowns];set matrix {};set rhs {};set rowUnits {}
        foreach unknown $unknowns {dict set units [dict get $unknown id] [dict get $unknown unit]}
        foreach equation [dict get $system equations] {
            set row {};set equationUnit [dict get $equation unit];lappend rowUnits $equationUnit
            foreach unknown $unknowns {
                set id [dict get $unknown id];set coefficient [dict get $equation coefficients $id]
                set basis GxUnitBasis;set serial 0
                while {[dict exists $units $basis] || $basis in [_m2References $coefficient]} {set basis GxUnitBasis[incr serial]}
                set basisValues [dict merge $values [dict create $basis {1}]];set basisUnits [dict merge $units [dict create $basis [dict get $unknown unit]]]
                lappend row [_m2Scalar "($coefficient)*$basis" $basisValues $basisUnits $definitions $equationUnit]
            }
            lappend matrix $row;lappend rhs [list [_m2Scalar [dict get $equation rhs] $values $units $definitions $equationUnit]]
        }
        set result [::GX::NumericAPIv1::linearMatrix solve [dict create real $matrix] [dict create real $rhs] {rank_policy error condition_limit 1e12}]
        set n [llength $unknowns]
        if {[dict get $result rank]!=$n || [dict get $result condition_number]>1e12 || [dict get $result relative_residual]>1e-10} {error {Declared coefficient system lacks a unique sufficiently conditioned exact solution}}
        foreach unknown $unknowns value [dict get $result value_real] {dict set values [dict get $unknown id] [list [finiteNumber $value {Solved coefficient}]]}
        lappend receipts [dict create id [dict get $system id] result $result equation_units $rowUnits unknowns $unknowns normalization {explicit equation-unit rows and unknown-unit bases}]
    }
    } else {
        foreach field {values units definitions} {set $field [dict get $shared $field]}
        set receipts [dict get $shared systems]
    }
    if {$fn ne {}} {
        foreach p [dict get $fn parameters] {dict set values [dict get $p id] [list [dict get $p value]];dict set units [dict get $p id] [dict get $p unit]}
        foreach definition [dict get $fn definitions] {dict set definitions [dict get $definition id] $definition;dict set units [dict get $definition id] [dict get $definition unit]}
    }
    return [dict create values $values units $units definitions $definitions systems $receipts]
}
proc ::GX::MathematicsExplorer::_m2Bound {expression fallback context xUnit} {
    if {$expression eq {}} {return $fallback}
    if {[string is double -strict $expression]} {return [finiteNumber $expression {Domain coordinate}]}
    return [_m2Scalar $expression [dict get $context values] [dict get $context units] [dict get $context definitions] $xUnit]
}
proc ::GX::MathematicsExplorer::_m2Components {branch lower upper context xUnit} {
    set components [list [list $lower $upper [dict get $branch lower_closed] [dict get $branch upper_closed]]]
    foreach exclusion [dict get $branch exclusions] {
        set lo [_m2Bound [dict get $exclusion lower] {} $context $xUnit]
        set hi [_m2Bound [dict get $exclusion upper] {} $context $xUnit]
        if {$lo>$hi} {error {Excluded interval must not decrease}}
        if {$lo==$hi && !([dict get $exclusion lower_closed] && [dict get $exclusion upper_closed])} continue
        set remaining {}
        foreach component $components {
            lassign $component a b ac bc
            if {$hi<$a || $lo>$b} {lappend remaining $component;continue}
            if {$lo>$a || ($lo==$a && ![dict get $exclusion lower_closed] && $ac)} {
                lappend remaining [list $a [expr {min($b,$lo)}] $ac [expr {![dict get $exclusion lower_closed] && ($lo<$b || $bc)}]]
            }
            if {$hi<$b || ($hi==$b && ![dict get $exclusion upper_closed] && $bc)} {
                lappend remaining [list [expr {max($a,$hi)}] $b [expr {![dict get $exclusion upper_closed] && ($hi>$a || $ac)}] $bc]
            }
        }
        set components $remaining
    }
    return $components
}
proc ::GX::MathematicsExplorer::_m2Select {xs lo hi lowerClosed upperClosed} {
    set values [_operand $xs]
    set left [::GX::NumericAPIv1::arrayCompare [expr {$lowerClosed?{greater_equal}:{greater_than}}] $values [_operand [list $lo]]]
    set right [::GX::NumericAPIv1::arrayCompare [expr {$upperClosed?{less_equal}:{less_than}}] $values [_operand [list $hi]]]
    set mask [::GX::NumericAPIv1::arrayMask logical_and [_operand [dict get $left values]] [_operand [dict get $right values]]]
    return [dict get [::GX::NumericAPIv1::arraySelect $values [_operand [dict get $mask values]]] values]
}
proc ::GX::MathematicsExplorer::calculate2 {state} {
    set state [validateState2 $state];activateNumerics
    set budget 0
    foreach fn [dict get $state functions] {
        if {![dict get $fn enabled]} continue
        foreach branch [dict get $fn branches] {
            if {[dict get $branch sampling] eq {explicit}} {incr budget [llength [dict get $branch explicit_x]]} else {
                set count [dict get $branch samples];incr budget [expr {$count?$count:[dict get $state samples]}]
            }
        }
    }
    if {$budget>200000} {error {Declared sampling exceeds the 200000-point model budget}}
    set segments {};set empty {};set ordinal 0;set systems {}
    set shared [_m2Context $state]
    foreach fn [dict get $state functions] {
        if {![dict get $fn enabled]} continue
        set context [_m2Context $state $fn $shared];set systems [dict get $context systems]
        set previousUpper -Inf;set previousClosed 0
        foreach branch [dict get $fn branches] {
            set lower [_m2Bound [dict get $branch lower] [dict get $state xmin] $context [dict get $state x_unit]]
            set upper [_m2Bound [dict get $branch upper] [dict get $state xmax] $context [dict get $state x_unit]]
            if {$lower>$upper || $lower<$previousUpper || ($lower==$previousUpper && $previousClosed && [dict get $branch lower_closed])} {error {Declared branches must increase without overlapping boundary ownership}}
            set previousUpper $upper;set previousClosed [dict get $branch upper_closed]
            set lo [expr {max($lower,[dict get $state xmin])}];set hi [expr {min($upper,[dict get $state xmax])}]
            if {$lo>$hi} {lappend empty [dict create function_id [dict get $fn id] branch_id [dict get $branch id] status outside_view_domain];continue}
            if {[dict get $branch sampling] eq {explicit}} {set xs [dict get $branch explicit_x]} elseif {$lo==$hi} {set xs [list $lo]} else {
                set count [dict get $branch samples];if {$count==0} {set count [dict get $state samples]}
                set xs [dict get [::GX::NumericAPIv1::uniformGrid $lo $hi $count {mode count}] x]
            }
            set count 0
            set cropped $branch
            if {$lo>$lower} {dict set cropped lower_closed 1}
            if {$hi<$upper} {dict set cropped upper_closed 1}
            foreach component [_m2Components $cropped $lo $hi $context [dict get $state x_unit]] {
                lassign $component a b ac bc
                set selected [_m2Select $xs $a $b $ac $bc]
                if {![llength $selected]} continue
                set values [dict merge [dict get $context values] [dict create x $selected]]
                set outputUnit [::GX::datasetPublicationV2DictDefault $branch output_unit {}]
                if {$outputUnit eq {}} {set outputUnit [dict get $fn output_unit]}
                set response [_m2Evaluate [dict get $branch expression] $values [dict get $context units] [dict get $context definitions] $outputUnit]
                set ys [dict get $response values]
                if {[llength $ys]==1} {set ys [lrepeat [llength $selected] [lindex $ys 0]]}
                if {[llength $ys]!=[llength $selected]} {error {Numeric expression shape does not match admitted branch coordinates}}
                foreach value $ys {finiteNumber $value {Function output}}
                incr count
                if {$ordinal>=512} {error {Connected-component budget exceeds 512}}
                set id [format s%04d [incr ordinal]]
                lappend segments [dict create id $id function_id [dict get $fn id] branch_id [dict get $branch id] component $count family_id [dict get $state family_id] \
                    label "[dict get $fn label] / [dict get $branch label]" x $selected values $ys x_unit [dict get $state x_unit] unit [dict get $response unit] \
                    declared_interval $component sampled_interval [list [lindex $selected 0] [lindex $selected end]] expression [dict get $branch expression] calculus function]
            }
            if {!$count} {lappend empty [dict create function_id [dict get $fn id] branch_id [dict get $branch id] status no_admitted_samples]}
        }
    }
    if {[dict get $state derivative]} {
        set derivatives {}
        foreach segment $segments {
            if {[dict get $segment function_id] ne [dict get $state selected_function] || ([dict get $state selected_branch] ne {} && [dict get $segment branch_id] ne [dict get $state selected_branch])} continue
            if {[llength [dict get $segment x]]<2} {lappend empty [dict create function_id [dict get $segment function_id] branch_id [dict get $segment branch_id] status derivative_requires_two_samples];continue}
            set derivative [::GX::NumericAPIv1::differentiate [dict get $segment x] [dict get $segment values]]
            set plan [::GX::unitRegistryArithmeticPlan / [dict get $segment unit] [dict get $segment x_unit]]
            set scale [expr {[dict get $plan left_scale]/[dict get $plan right_scale]}]
            set values {};foreach value [dict get $derivative dy_dx] {lappend values [finiteNumber [expr {$value*$scale}] Derivative]}
            lappend derivatives [dict replace $segment id [dict get $segment id]_derivative label "d([dict get $segment label])/dx" values $values unit [dict get $plan output_unit] calculus derivative]
        }
        lappend segments {*}$derivatives
    }
    return [dict create schema 2 model_state $state unit_context [_m2UnitContext] segments $segments empty_domains $empty systems $systems resolved_shared_values [dict get $shared values] resolved_shared_units [dict get $shared units] selected_function [dict get $state selected_function] selected_branch [dict get $state selected_branch] \
        sampling_policy {explicit connected admitted branches; public Numeric finite_real_or_error; no smoothing or invented gap values}]
}
proc ::GX::MathematicsExplorer::_m2Expand {expression definitions {stack {}}} {
    set spans [regexp -all -inline -indices {[A-Za-z_][A-Za-z0-9_]*} $expression]
    foreach span [lreverse $spans] {
        lassign $span first last;set id [string range $expression $first $last]
        if {![dict exists $definitions $id]} continue
        if {$id in $stack} {error {Cyclic reusable expression}}
        set after [string trimleft [string range $expression [expr {$last+1}] end]]
        if {[string index $after 0] eq {(}} continue
        set replacement [_m2Expand [dict get $definitions $id expression] $definitions [concat $stack $id]]
        set expression [string replace $expression $first $last "($replacement)"]
        if {[string length $expression]>8192} {error {Expanded expression exceeds Numeric's 8192-character bound}}
    }
    return $expression
}
proc ::GX::MathematicsExplorer::_m2AnalysisExpression {expression context prefix} {
    set expression [_m2Expand $expression [dict get $context definitions]]
    set symbols {};set units [dict create x [::GX::ScientificTransportv1::text [dict get $context units x]]]
    foreach span [lreverse [regexp -all -inline -indices {[A-Za-z_][A-Za-z0-9_]*} $expression]] {
        lassign $span first last;set id [string range $expression $first $last]
        set after [string trimleft [string range $expression [expr {$last+1}] end]]
        if {$id eq {x} || [string index $after 0] eq {(} || ![dict exists $context values $id]} continue
        set data [dict get $context values $id]
        if {[llength $data]!=1} {error {Expression analysis parameters must be scalar}}
        set name ${prefix}_$id
        set expression [string replace $expression $first $last $name]
        dict set symbols $name [::GX::ScientificTransportv1::array {1 1} $data]
        dict set units $name [::GX::ScientificTransportv1::text [dict get $context units $id]]
    }
    return [dict create expression $expression symbols $symbols units $units]
}
proc ::GX::MathematicsExplorer::analyzeSelected {state mode {otherFunction {}} {minimum {}} {maximum {}}} {
    set state [validateState2 $state];activateNumerics
    if {$mode ni {roots intersections extrema}} {error {Analysis must be roots, intersections or extrema}}
    set selected [dict get $state selected_function];set declarations {};set functions {}
    foreach fn [dict get $state functions] {
        if {[dict get $fn id] in [list $selected $otherFunction]} {dict set fn enabled 1;lappend functions $fn;dict set declarations [dict get $fn id] $fn}
    }
    if {$mode eq {intersections} && ($otherFunction eq $selected || ![dict exists $declarations $otherFunction])} {error {Choose a distinct existing intersection function}}
    dict set state functions $functions;dict set state derivative 0
    set sampled [calculate2 $state];set results {};set shared [_m2Context $state]
    foreach segment [dict get $sampled segments] {
        if {[dict get $segment function_id] ne $selected || ([dict get $state selected_branch] ne {} && [dict get $segment branch_id] ne [dict get $state selected_branch]) || [llength [dict get $segment x]]<2} continue
        set fn [dict get $declarations $selected];set context [_m2Context $state $fn $shared]
        set left [_m2AnalysisExpression [dict get $segment expression] $context Left]
        if {$mode eq {intersections}} {set partners [dict get $sampled segments]} else {set partners [list $segment]}
        foreach partner $partners {
            if {$mode eq {intersections} && [dict get $partner function_id] ne $otherFunction} continue
            lassign [dict get $segment sampled_interval] lo hi
            if {$mode eq {intersections}} {
                lassign [dict get $partner sampled_interval] a b;set lo [expr {max($lo,$a)}];set hi [expr {min($hi,$b)}]
            }
            if {$minimum ne {}} {set lo [expr {max($lo,[finiteNumber $minimum {Analysis minimum}])}]}
            if {$maximum ne {}} {set hi [expr {min($hi,[finiteNumber $maximum {Analysis maximum}])}]}
            if {$hi<=$lo} continue
            set symbols [dict get $left symbols];set units [dict get $left units]
            set fields [dict create expression [::GX::ScientificTransportv1::text [dict get $left expression]] variable [::GX::ScientificTransportv1::text x] \
                interval [::GX::ScientificTransportv1::array {2 1} [list $lo $hi]] mode [::GX::ScientificTransportv1::text $mode]]
            if {$mode eq {intersections}} {
                set rightContext [_m2Context $state [dict get $declarations $otherFunction] $shared]
                set right [_m2AnalysisExpression [dict get $partner expression] $rightContext Right]
                set symbols [dict merge $symbols [dict get $right symbols]];set units [dict merge $units [dict get $right units]]
                dict set fields expression2 [::GX::ScientificTransportv1::text [dict get $right expression]]
            }
            dict set fields symbols [::GX::ScientificTransportv1::struct $symbols];dict set fields symbol_units [::GX::ScientificTransportv1::struct $units]
            set result [::GX::NumericAPIv1::callOperation expression_analyze [list [::GX::ScientificTransportv1::struct $fields]] \
                [::GX::ScientificTransportv1::struct [dict create output_unit [::GX::ScientificTransportv1::text [dict get $segment unit]]]]]
            lappend results [dict create function_id $selected branch_id [dict get $segment branch_id] partner_function $otherFunction interval [list $lo $hi] \
                domain_policy {closed subinterval of actual admitted samples; no excluded/open endpoint repaired or crossed} result $result \
                result_types [::GX::NumericAPIv1::resultTypes] result_array_shapes [::GX::NumericAPIv1::_resultArrayShapes] result_cell_shapes [::GX::NumericAPIv1::_resultCellShapes]]
        }
    }
    if {![llength $results]} {error {No admitted connected interval with at least two samples for the selected analysis}}
    return $results
}
proc ::GX::MathematicsExplorer::integralOfSelected {computed} {
    activateNumerics;set results {}
    foreach segment [dict get $computed segments] {
        if {[dict get $segment calculus] ne {function} || [dict get $segment function_id] ne [dict get $computed selected_function] || ([dict get $computed selected_branch] ne {} && [dict get $segment branch_id] ne [dict get $computed selected_branch])} continue
        if {[llength [dict get $segment x]]<2} {lappend results [dict create segment_id [dict get $segment id] status insufficient_samples];continue}
        set response [::GX::NumericAPIv1::integrate [dict get $segment x] [dict get $segment values]]
        set plan [::GX::unitRegistryArithmeticPlan * [dict get $segment unit] [dict get $segment x_unit]]
        set value [expr {[dict get $response value]*[dict get $plan left_scale]*[dict get $plan right_scale]}]
        lappend results [dict create segment_id [dict get $segment id] status available value [finiteNumber $value Integral] unit [dict get $plan output_unit] \
            interval [dict get $segment sampled_interval] method [dict get $response method] domain_policy {integral over these actual admitted samples only}]
    }
    return $results
}
proc ::GX::MathematicsExplorer::nativeModel2 {state computed} {
    set groups {};set order {}
    foreach segment [dict get $computed segments] {
        set unit [dict get $segment unit];set kind [dict get $segment calculus];set group [list $unit $kind]
        if {![dict exists $groups $group]} {lappend order $group}
        set points {};set rows {};set row 0
        foreach x [dict get $segment x] y [dict get $segment values] {lappend points [list $x $y];lappend rows $row;incr row}
        dict lappend groups $group [dict create id [dict get $segment id] label [dict get $segment label] kind line axis left points $points source_rows $rows breaks {} style {line_width 1.5}]
    }
    set panels {};set count 0
    foreach group $order {
        lassign $group unit kind
        lappend panels [dict create id panel[incr count] axes [dict create x [dict create label "x ([dict get $state x_unit])"] left [dict create label "$kind ($unit)"]] series [dict get $groups $group] annotations {}]
    }
    if {![llength $panels]} {error {No admitted real samples; retain the last good view}}
    return [dict create title [dict get $state title] panels $panels native_presentation [dict create schema GXTXT_NATIVE_GRAPH_PRESENTATION_v1 graphics {} layout {layout_auto 1} legend {placement inside}]]
}
proc ::GX::MathematicsExplorer::stateEncode2 {state} {
    set state [validateState2 $state]
    set parameter {record {id text label text description text group text unit text value real slider {record {mode text min real max real}}}}
    set definition {record {id text expression text unit text}}
    set branch {record {id text label text expression text output_unit text lower text upper text lower_closed bool upper_closed bool samples int sampling text explicit_x {array real} exclusions {array {record {lower text upper text lower_closed bool upper_closed bool}}}}}
    set function [list record [dict create id text label text enabled bool output_unit text parameters [list array $parameter] definitions [list array $definition] branches [list array $branch]]]
    set shape [list record [dict create schema int title text xmin real xmax real samples int x_unit text parameters [list array $parameter] definitions [list array $definition] \
        systems {array {record {id text unknowns {array {record {id text unit text}}} equations {array {record {coefficients {map text} rhs text unit text}}}}}} \
        families {array {record {id text label text values {map real}}}} family_id text functions [list array $function] selected_function text selected_branch text derivative bool \
        view_axes {array {record {panel_id text axis text limits {array real} plot_rect {array real} scale text direction text aspect text ticks {array {record {value real display_value real label text device real}}}}}}]]
    return [::GX::nativeWorkspaceEncode $shape $state]
}
proc ::GX::MathematicsExplorer::computedEncode2 {computed} {
    set segment {record {id text function_id text branch_id text component int family_id text label text x {array real} values {array real} x_unit text unit text \
        declared_interval {tuple {real real bool bool}} sampled_interval {array real} expression text calculus text}}
    set linear {record {rows int cols int rank int rank_tolerance real condition_number real value_real {array real} value_imaginary {array real} residual_real {array real} residual_imaginary {array real} residual_norm real relative_residual real solution_kind text rhs_columns int}}
    set systems [list array [list record [dict create id text result $linear equation_units {array text} unknowns {array {record {id text unit text}}} normalization text]]]
    return [::GX::nativeWorkspaceEncode [list record [dict create schema int unit_context {map {map text}} segments [list array $segment] systems $systems \
        resolved_shared_values {map {array real}} resolved_shared_units {map text} \
        empty_domains {array {record {function_id text branch_id text status text}}} selected_function text selected_branch text sampling_policy text]] [dict remove $computed model_state]]
}
proc ::GX::MathematicsExplorer::integralEncode2 {computed} {
    return [::GX::nativeWorkspaceEncode {array {record {segment_id text status text value real unit text interval {array real} method text domain_policy text}}} [integralOfSelected $computed]]
}

proc ::GX::MathematicsExplorer::_m2PublicationGuard {state computed documentId token} {
    set state [validateState2 $state]
    _m2CheckUnitContext [dict get $computed unit_context]
    if {$token ne [sessionToken]} {error {Session changed; mathematical publication refused}}
    if {$documentId eq {}} {error {Save the model before publishing}}
    set doc [::GX::interactiveDocumentRead $documentId]
    if {[dict get $doc module_id] ne {viewer.mathematics_explorer} || [dict get $doc provider_id] ne {mathematics_explorer_v2} || [dict get $doc format] ne {gxtxt.mathematics_explorer.state} || [dict get $doc format_version]!=2} {error {Mathematical publication requires its own saved native Workspace}}
    set expected [stateEncode2 [dict replace $state view_axes {}]]
    foreach original [list [dict get $doc payload] [dict get $computed model_state]] {
        if {![::GX::workspaceNative typed_equivalent $expected [stateEncode2 [dict replace $original view_axes {}]]]} {error {Computed, current and saved mathematical declarations differ}}
    }
    return $state
}
proc ::GX::MathematicsExplorer::publishComputed2 {state computed documentId token outputId} {
    set state [_m2PublicationGuard $state $computed $documentId $token]
    set outputId [::GX::datasetPublicationV2ValidateId dataset $outputId]
    set segments [dict get $computed segments]
    if {![llength $segments] || [llength $segments]>512} {error {Publish between one and 512 actual connected components}}
    set modelJson [::GX::nativeWorkspaceJsonEncode [stateEncode2 $state]]
    if {[string bytelength $modelJson]>1048576} {error {Mathematical declaration provenance exceeds 1 MiB}}
    set plans {};set receipts {};set session [::GX::sessionInspectionCurrentSession]
    # Every component is an independent canonical row grid. Preflight all IDs
    # through the original Publication owner before creating any writer.
    foreach segment $segments {
        set id [::GX::datasetPublicationV2ValidateId dataset "$outputId.[dict get $segment id]"]
        set provenance "Synthetic model-generated theoretical values, not experimental observations. Native Workspace $documentId; function=[dict get $segment function_id]; branch=[dict get $segment branch_id]; component=[dict get $segment component]; family=[dict get $segment family_id]; calculus=[dict get $segment calculus]; actual_sampled_interval=[dict get $segment sampled_interval]; declarations=$modelJson"
        set definition [dict create dataset_id $id contract table.generic storage csv expected_rows [llength [dict get $segment x]] \
            source {Mathematics Explorer schema2} producer_version [::GX::moduleField viewer.mathematics_explorer version {}] provenance $provenance \
            notes {Independent admitted connected samples; no invented common grid, gap values, smoothing or C1 continuity. Numerical calculus is grid-dependent.}]
        lappend plans [::GX::datasetPublicationV2Prepare $session viewer.mathematics_explorer $definition]
    }
    foreach segment $segments plan $plans {
        set writer {}
        try {
            set writer [::GX::datasetPublicationV2OpenWriter $plan]
            ::GX::datasetPublicationV2DeclareDimension $writer row 0 {extendible 1}
            ::GX::datasetPublicationV2DeclareVariable $writer x [dict create dtype float64 rank 1 dimension_ids row unit [dict get $segment x_unit] display_label x coordinate_role coordinate axis_kind explicit]
            ::GX::datasetPublicationV2DeclareVariable $writer response [dict create dtype float64 rank 1 dimension_ids row unit [dict get $segment unit] display_label [dict get $segment label]]
            ::GX::datasetPublicationV2Append $writer row [dict create x [dict get $segment x] response [dict get $segment values]]
            set receipt [::GX::datasetPublicationV2Finalize $writer];set writer {}
            lappend receipts [dict merge [dict remove $segment x values expression] [dict create dataset_id [dict get $receipt dataset_id] sha256 [dict get $receipt sha256] storage_provider [dict get $receipt storage_provider]]]
        } on error {message options} {
            if {$writer ne {}} {catch {::GX::datasetPublicationV2Abort $writer}}
            return -options $options "Mathematical publication failed; committed component receipts remain preserved: $receipts; $message"
        }
    }
    return [dict create schema 2 datasets $receipts document_id $documentId]
}
proc ::GX::MathematicsExplorer::publishGraph2 {state computed documentId token outputId} {
    set publication [publishComputed2 $state $computed $documentId $token $outputId]
    set groups {};set order {}
    foreach source [dict get $publication datasets] {
        set group [list [dict get $source unit] [dict get $source calculus]]
        if {![dict exists $groups $group]} {lappend order $group}
        dict lappend groups $group [dict create id [dict get $source id] dataset_id [dict get $source dataset_id] x_variable_id x y_variable_id response \
            kind line label [dict get $source label] axis left style {}]
    }
    set panels {};set index 0
    foreach group $order {
        lassign $group unit kind
        lappend panels [dict create id panel[incr index] axes [dict create x [dict create label "x ([dict get $state x_unit])" display_unit [dict get $state x_unit]] y_left [dict create label "$kind ($unit)" display_unit $unit]] \
            series [dict get $groups $group] annotations {}]
    }
    set spec [dict create schema PLOT_DATASET_PLOTSPEC_v2 graph_type cartesian_2d graph_id plot.dataset.xy title [dict get $state title] defaults {style {}} panels $panels output {}]
    ::GX::modulePublicApiActivate plot.dataset PLOT_DATASET_API_v4
    try {
        set reference [::GX::PlotDatasetAPIv4::createPlotFromSpec $spec variant]
        ::GX::PlotDatasetAPIv4::render $reference
        ::GX::graphMetadataUpdate [dict merge {kind provider module_id plot.dataset} $reference] [dict create mathematics.document_id $documentId mathematics.model_schema 2 mathematics.synthetic 1]
        ::GX::sessionPersistenceCommit
        dict set publication graph_ref $reference
        return $publication
    } on error {message options} {return -options $options "Mathematical component Datasets were committed and preserved; Graph phase failed: $message"}
}
proc ::GX::MathematicsExplorer::publicationEncode2 {publication} {
    set row {record {id text function_id text branch_id text component int family_id text label text x_unit text unit text declared_interval {tuple {real real bool bool}} sampled_interval {array real} calculus text dataset_id text sha256 text storage_provider text}}
    return [::GX::nativeWorkspaceEncode [list record [dict create schema int datasets [list array $row] document_id text graph_ref {map text}]] $publication]
}

# Existing operation names remain facades for saved schema1 and new schema2.
# Sources are reloaded through existing activation, so recapture the original
# legacy bodies immediately after science.tcl defines them each time.
foreach _gx_math_v2_facade {validateState calculate nativeModel integralOfFirst renderPreview publishComputed publishGraph analyzeFirst saveWorkspace readDocument listDocuments} {
    if {[llength [info commands ::GX::MathematicsExplorer::${_gx_math_v2_facade}Schema1]]} {rename ::GX::MathematicsExplorer::${_gx_math_v2_facade}Schema1 {}}
    rename ::GX::MathematicsExplorer::$_gx_math_v2_facade ::GX::MathematicsExplorer::${_gx_math_v2_facade}Schema1
}
proc ::GX::MathematicsExplorer::validateState {state} {
    if {[dict exists $state schema] && [dict get $state schema]==2} {return [validateState2 $state]}
    return [validateStateSchema1 $state]
}
proc ::GX::MathematicsExplorer::calculate {state} {
    if {[dict get $state schema]==2} {return [calculate2 $state]}
    return [calculateSchema1 $state]
}
proc ::GX::MathematicsExplorer::nativeModel {state computed} {
    if {[dict get $state schema]==2} {return [nativeModel2 $state $computed]}
    return [nativeModelSchema1 $state $computed]
}
proc ::GX::MathematicsExplorer::integralOfFirst {computed} {
    if {[dict exists $computed schema] && [dict get $computed schema]==2} {return [integralOfSelected $computed]}
    return [integralOfFirstSchema1 $computed]
}
proc ::GX::MathematicsExplorer::renderPreview {state computed directory} {
    if {[dict get $state schema]!=2} {return [renderPreviewSchema1 $state $computed $directory]}
    ::GX::modulePublicApiActivate plot.dataset PLOT_DATASET_API_v4
    file mkdir $directory;set artifact [file join $directory graph.png]
    ::GX::PlotDatasetAPIv4::renderModel [nativeModel2 $state $computed] $artifact
    return $artifact
}
proc ::GX::MathematicsExplorer::publishComputed {state computed documentId token outputId} {
    if {[dict get $state schema]==2} {return [publishComputed2 $state $computed $documentId $token $outputId]}
    return [publishComputedSchema1 $state $computed $documentId $token $outputId]
}
proc ::GX::MathematicsExplorer::publishGraph {state computed documentId token outputId} {
    if {[dict get $state schema]==2} {return [publishGraph2 $state $computed $documentId $token $outputId]}
    return [publishGraphSchema1 $state $computed $documentId $token $outputId]
}
proc ::GX::MathematicsExplorer::analyzeFirst {state mode} {
    if {[dict get $state schema]==2} {return [analyzeSelected $state $mode]}
    return [analyzeFirstSchema1 $state $mode]
}
proc ::GX::MathematicsExplorer::saveWorkspace {state expected token {name {}}} {
    set state [validateState $state]
    if {[dict get $state schema]!=2} {return [saveWorkspaceSchema1 $state $expected $token $name]}
    if {$token ne [sessionToken]} {error {Session changed; mathematical Workspace not saved}}
    if {$expected ne {}} {
        set current [::GX::nativeWorkspaceMetadata [dict get $expected id]]
        if {[dict get $current module_id] ne {viewer.mathematics_explorer} || [dict get $current provider_id] ni {mathematics_explorer mathematics_explorer_v2}} {error {Foreign Workspace cannot own a mathematical model}}
        if {[dict get $current provider_id] eq {mathematics_explorer}} {
            # Structural upgrade is a new versioned Workspace; the historical
            # schema1 source and its original identities are preserved intact.
            set expected {}
        }
    }
    if {$expected eq {}} {
        if {$name eq {}} {set name [::GX::sessionWorkspaceAvailableName [dict get $state title]]}
        return [::GX::sessionWorkspaceCreate mathematics_explorer_v2 $name $state]
    }
    return [::GX::sessionWorkspaceUpdate [dict get $expected id] $state $expected]
}
proc ::GX::MathematicsExplorer::readDocument {id token {receiptName {}}} {
    if {$token ne [sessionToken]} {error {Session changed; choose a Workspace from the current Session}}
    set current [::GX::interactiveDocumentRead $id]
    if {[dict get $current provider_id] eq {mathematics_explorer_v2}} {
        if {[dict get $current module_id] ne {viewer.mathematics_explorer} || [dict get $current format] ne {gxtxt.mathematics_explorer.state} || [dict get $current format_version]!=2} {error {Incompatible mathematical Workspace}}
        set value [validateState2 [dict get $current payload]];set receipt $current
    } else {set value [readDocumentSchema1 $id $token receipt]}
    if {$receiptName ne {}} {upvar 1 $receiptName callerReceipt;set callerReceipt $receipt}
    return $value
}
proc ::GX::MathematicsExplorer::listDocuments {} {
    return [concat [listDocumentsSchema1] [::GX::nativeWorkspaceQuery mathematics_explorer_v2]]
}
unset _gx_math_v2_facade
