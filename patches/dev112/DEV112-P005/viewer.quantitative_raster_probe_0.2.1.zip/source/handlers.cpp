enum Component : unsigned {
    Canvas = 1,
    Source = 2,
    Bind = 3,
    Inspect = 4,
    Discover = 5,
    Operation = 7,
    X = 8,
    Y = 9,
    Width = 10,
    Height = 11,
    Channels = 12,
    Roi = 13,
    HistogramMode = 14,
    Bins = 15,
    DomainLow = 16,
    DomainHigh = 17,
    Offset = 18,
    Submit = 20,
    Status = 21,
    Cancel = 22,
    Result = 23,
    Page = 24,
    MapRoi = 25,
    Receipt = 26,
    Output = 27,
    JobInput = 28,
    Reconnect = 29,
    CanvasDocument = 30,
    SaveCanvas = 31,
    OpenCanvas = 32,
};
const char CanvasName[] = "native2d_1";
// SPDX-License-Identifier: GPL-3.0-or-later
// The component enum above comes from the actual Builder declaration order.
#include <cstdio>
#include <stdexcept>
#include <string>

namespace {
using Value = gx::WorkspaceValue;
std::string object_id, source_id, source_sha, source_revision, job_id, token, generation;
Value last_received, last_canvas;

const Value& field(const Value& value, const std::string& key) {
    static const Value absent;
    if (value.kind != Value::Kind::object) return absent;
    const auto found = value.fields.find(key);
    return found == value.fields.end() ? absent : found->second;
}
std::string text(const Value& value, const std::string& key) {
    const auto& item = field(value, key);
    return item.kind == Value::Kind::text ? item.text : std::string();
}
void clear_source() {
    source_id.clear(); source_sha.clear(); source_revision.clear();
    job_id.clear(); token.clear(); generation.clear();
}
void render(const Value& value, std::string& out, unsigned depth = 0) {
    if (out.size() > 20000 || depth > 32) return;
    if (value.kind == Value::Kind::text) {out += value.text; return;}
    if (value.kind == Value::Kind::integer) {out += std::to_string(value.integer); return;}
    if (value.kind == Value::Kind::real) {
        char buffer[64]; std::snprintf(buffer, sizeof(buffer), "%.17g", value.real);
        out += buffer; return;
    }
    if (value.kind == Value::Kind::boolean) {out += value.integer ? "true" : "false"; return;}
    if (value.kind == Value::Kind::null) {out += "null"; return;}
    if (value.kind == Value::Kind::array) {
        out += "[\n";
        for (const auto& item : value.elements) {
            out += std::string(depth + 1, ' '); render(item, out, depth + 1); out += "\n";
            if (out.size() > 20000) break;
        }
        out += std::string(depth, ' ') + "]"; return;
    }
    out += "{\n";
    for (const auto& item : value.fields) {
        out += std::string(depth + 1, ' ') + item.first + ": ";
        render(item.second, out, depth + 1); out += "\n";
        if (out.size() > 20000) break;
    }
    out += std::string(depth, ' ') + "}";
}
void display_text(gx::Host& host, const std::string& value) {
    std::string escaped;
    const char digits[] = "0123456789abcdef";
    for (const unsigned char ch : value) {
        if (ch == '"' || ch == '\\') {escaped += '\\'; escaped += ch;}
        else if (ch < 32) {
            escaped += "\\u00"; escaped += digits[ch >> 4]; escaped += digits[ch & 15];
        } else escaped += ch;
    }
    const std::string runs = "{\"replace\":true,\"runs\":[{\"text\":\"" + escaped +
        "\",\"style\":\"normal\"}],\"autoscroll\":true}";
    host.text_runs(Output, runs.c_str());
}
void show(gx::Host& host, const std::string& heading) {
    std::string out = heading + "\nLast explicit Canvas receipt (Document ID is reusable by Open):\n";
    render(last_canvas, out);
    out += "\nLast typed quantitative CORE receipt; source identities remain explicit:\n";
    render(last_received, out);
    if (out.size() > 20000) {
        out.resize(20000);
        out += "\nDisplay truncated. The typed API receipt remains the authoritative result.\n";
    }
    display_text(host, out);
}
void receive(gx::Host& host) {
    const auto* canvas = host.canvas_result();
    if (canvas) {
        last_canvas = *canvas;
        const auto& instance = field(field(*canvas, "instances"), CanvasName);
        const auto& selected = field(instance, "selection");
        const auto& objects = field(instance, "objects");
        std::string candidate;
        if (selected.kind == Value::Kind::array && selected.elements.size() == 1 &&
            selected.elements.front().kind == Value::Kind::text) {
            const auto wanted = selected.elements.front().text;
            for (const auto& item : objects.elements) {
                if (text(item, "logical_id") == wanted && text(item, "kind") == "image") candidate = wanted;
            }
        }
        if (candidate != object_id) {object_id = candidate; clear_source();}
    }
    const auto* receipt = host.quantitative_raster_result();
    if (!receipt || receipt->kind != Value::Kind::object) return;
    last_received = *receipt;
    // A previous source's discovery cannot authorize the current selector.
    const auto discovered = text(*receipt, "dataset_id");
    if (!discovered.empty() && discovered == host.input(Source)) {
        source_id = discovered; source_sha = text(*receipt, "source_sha256");
        source_revision = text(*receipt, "source_revision");
    }
    const auto received_job = text(*receipt, "job_id");
    const std::string explicit_job = host.input(JobInput);
    if (!source_id.empty() || (!received_job.empty() && received_job == explicit_job)) {
        const auto returned_job = received_job;
        if (!returned_job.empty()) job_id = returned_job;
        const auto& output = field(*receipt, "histogram_output");
        if (output.kind == Value::Kind::object) {
            token = text(output, "token"); generation = text(output, "source_generation");
        }
    }
}
std::int64_t integer_input(gx::Host& host, unsigned component) {
    const std::string value = host.input(component);
    std::size_t end = 0;
    const auto result = std::stoll(value, &end);
    if (end != value.size()) throw std::runtime_error("Enter an exact integer source coordinate or count.");
    return result;
}
double real_input(gx::Host& host, unsigned component) {
    const std::string value = host.input(component);
    std::size_t end = 0;
    const auto result = std::stod(value, &end);
    if (end != value.size()) throw std::runtime_error("Enter an explicit finite histogram edge.");
    return result;
}
void require_object() {
    if (object_id.empty()) throw std::runtime_error("Bind and select one canonical source image in the Canvas first.");
}
Value job_request(gx::Host& host) {
    const std::string selected = job_id.empty() ? std::string(host.input(JobInput)) : job_id;
    if (selected.empty()) throw std::runtime_error("Submit a measurement or enter its durable Job ID first.");
    return gx::workspace_object({{"job_id", gx::workspace_text(selected)}});
}
}

void on_event(gx::Host& host, gx::State& state, const gx::Event& event) {
    if (event.kind == gx::EventKind::open) {
        object_id.clear(); clear_source(); last_received = Value(); last_canvas = Value();
        display_text(host, "Select a canonical raster, then Bind source and Discover source.");
        return;
    }
    if (event.kind != gx::EventKind::invoke) return;
    ++state.counter;
    try {
        receive(host);
        if (event.component == Bind) {
            object_id.clear(); clear_source(); last_received = Value();
            host.canvas_command(Canvas, "bind_source", gx::workspace_object({
                {"source_selector", gx::workspace_integer(Source)}
            }));
            show(host, "Canonical source bind requested. Discover source reads the next CORE receipt.");
        } else if (event.component == Inspect) {
            host.canvas_command(Canvas, "inspect", gx::workspace_object());
            show(host, "Canvas inspection requested. Show received data reads the next receipt.");
        } else if (event.component == SaveCanvas) {
            host.canvas_command(Canvas, "save", gx::workspace_object());
            show(host, "Canvas Save requested. Show received data exposes its exact Document ID.");
        } else if (event.component == OpenCanvas) {
            const std::string document = host.input(CanvasDocument);
            if (document.empty()) throw std::runtime_error("Enter the existing Canvas Document ID first.");
            object_id.clear(); clear_source(); last_received = Value(); last_canvas = Value();
            host.canvas_command(Canvas, "open", gx::workspace_object({
                {"document_id", gx::workspace_text(document)}
            }));
            show(host, "Canvas Open requested. Inspect Canvas and Show received data expose its retained identity.");
        } else if (event.component == Discover) {
            require_object();
            host.quantitative_raster_command(Canvas, "discover", gx::workspace_object({
                {"object", gx::workspace_text(object_id)}
            }));
            show(host, "Source discovery requested.");
        } else if (event.component == Submit) {
            require_object();
            if (source_sha.empty() || source_revision.empty() || source_id != host.input(Source))
                throw std::runtime_error("Discover the current canonical source before submitting.");
            const std::string operation = host.input(Operation);
            auto request = gx::workspace_object({
                {"object", gx::workspace_text(object_id)},
                {"operation", gx::workspace_text(operation)},
                {"expected_sha256", gx::workspace_text(source_sha)},
                {"expected_revision", gx::workspace_text(source_revision)},
                {"channels", gx::workspace_text(host.input(Channels))},
                {"frame", gx::workspace_integer(0)}
            });
            if (operation != "describe") {
                const std::string roi = host.input(Roi);
                if (!roi.empty()) request.fields["roi_id"] = gx::workspace_text(roi);
                else {
                    request.fields["x"] = gx::workspace_integer(integer_input(host, X));
                    request.fields["y"] = gx::workspace_integer(integer_input(host, Y));
                    if (operation != "pixel") {
                        request.fields["width"] = gx::workspace_integer(integer_input(host, Width));
                        request.fields["height"] = gx::workspace_integer(integer_input(host, Height));
                    }
                }
            }
            if (operation == "histogram") {
                const std::string mode = host.input(HistogramMode);
                request.fields["histogram_mode"] = gx::workspace_text(mode);
                if (mode == "bounded") {
                    request.fields["bins"] = gx::workspace_integer(integer_input(host, Bins));
                    request.fields["domain_low"] = gx::workspace_number(real_input(host, DomainLow));
                    request.fields["domain_high"] = gx::workspace_number(real_input(host, DomainHigh));
                }
            }
            host.quantitative_raster_command(Canvas, "submit", request);
            show(host, "Measurement submission requested through the managed CORE lifecycle.");
        } else if (event.component == Status || event.component == Cancel || event.component == Result) {
            const char* operation = event.component == Status ? "status" : event.component == Cancel ? "cancel" : "result";
            host.quantitative_raster_command(Canvas, operation, job_request(host));
            show(host, std::string("Requested ") + operation + ". Show received data reads the next receipt.");
        } else if (event.component == Page) {
            auto request = job_request(host);
            if (token.empty() || generation.empty()) throw std::runtime_error("Get a completed histogram result before requesting its count page.");
            request.fields["token"] = gx::workspace_text(token);
            request.fields["generation"] = gx::workspace_text(generation);
            request.fields["offset"] = gx::workspace_integer(integer_input(host, Offset));
            request.fields["count"] = gx::workspace_integer(256);
            host.quantitative_raster_command(Canvas, "histogram_page", request);
            show(host, "Requested at most 256 original-domain histogram counts.");
        } else if (event.component == MapRoi) {
            require_object();
            const std::string roi = host.input(Roi);
            if (roi.empty()) throw std::runtime_error("Enter an existing retained source ROI ID to map.");
            host.quantitative_raster_command(Canvas, "map_roi", gx::workspace_object({
                {"object", gx::workspace_text(object_id)}, {"roi_id", gx::workspace_text(roi)}
            }));
            show(host, "Retained source ROI mapping requested.");
        } else if (event.component == Reconnect) {
            const std::string requested = host.input(JobInput);
            if (requested.empty()) throw std::runtime_error("Enter the durable Job ID to reconnect.");
            host.quantitative_raster_command(Canvas, "reconnect", gx::workspace_object({
                {"job_id", gx::workspace_text(requested)}
            }));
            show(host, "Reconnection requested. CORE verifies the matching saved Canvas and closed earlier view owner.");
        } else if (event.component == Receipt) {
            show(host, "Received typed CORE data; no additional measurement or polling was requested.");
        }
    } catch (const std::exception& error) {
        display_text(host, error.what());
    }
}
