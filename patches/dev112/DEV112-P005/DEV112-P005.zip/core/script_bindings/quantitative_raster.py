"""Original scientific sample measurements through the canonical CORE owners."""
# SPDX-License-Identifier: GPL-3.0-or-later
import json
from gxtxt_script_bridge_server import BridgeError

COMMANDS = {
    'source_info': ('::GX::quantitativeRasterSourceInfo', ['dataset_id']),
    'submit': ('::GX::quantitativeRasterSubmit', ['document_id', 'dataset_id', 'expected_sha256',
               'expected_revision', 'source_resource', 'parameters']),
    'status': ('::GX::quantitativeRasterStatus', ['job_id']),
    'cancel': ('::GX::quantitativeRasterCancel', ['job_id']),
    'result': ('::GX::quantitativeRasterResult', ['job_id']),
    'histogram_page': ('::GX::quantitativeRasterHistogramPage',
                       ['job_id', 'output_token', 'generation', 'offset', 'count']),
}
REGISTRATION = {
    'api_id': 'QUANTITATIVE_RASTER_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'quantitative_raster',
    'documentation_ref': 'docs/api/QUANTITATIVE_RASTER_API_v1.md',
    'operations': {name: {'name': name, 'summary': 'Original-source quantitative raster '+name,
        'arguments': [{'name': arg, 'kind': 'public value', 'required': True} for arg in args],
        'argument_convention': ', '.join(args),
        'result_contract': 'Canonical source identity, managed Job receipt or finite typed measurement'}
        for name, (_, args) in COMMANDS.items()},
}


def invoke(host, operation, args):
    if operation not in COMMANDS or len(args) != len(COMMANDS[operation][1]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid finite quantitative arguments')
    raw = host.call(COMMANDS[operation][0], *args)
    if operation in {'result', 'histogram_page'}:
        return json.loads(str(host.call('::GX::nativeWorkspaceJsonEncode', raw)))
    if operation in {'status', 'cancel'}:
        fields = host.as_dict(raw)
        result = {key: str(fields[key]) for key in
                  ('job_id', 'provider_id', 'state', 'error', 'diagnostic', 'progress_stage') if key in fields}
        if 'progress_percent' in fields:
            result['progress_percent'] = float(fields['progress_percent'])
        if 'policy' in fields:
            result['policy'] = {str(k): int(v) for k, v in host.as_dict(fields['policy']).items()}
        if 'source_current' in fields:
            result['source_current'] = bool(int(fields['source_current']))
        return host.normalize(result)
    return host.normalize(host.as_dict(raw))
