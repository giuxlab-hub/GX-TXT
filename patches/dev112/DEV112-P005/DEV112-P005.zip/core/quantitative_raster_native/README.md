# Original scientific raster extraction

This trusted C++17 helper decodes original sample bytes and copies a source-pixel ROI into per-channel buffers. It performs no statistics, reductions, histograms, mathematical summaries, nonfinite classification, display conversion or publication. Public NUMERIC_API_v1 owns computations. MAIN's fixed RuntimeTool and existing ScientificExecution Job own authorization, source materialization, execution and scratch lifetime; the CLI is not a public caller-path capability or security sandbox.

The prebuilt Linux x86-64 executable is `gxtxt_quantitative_extract`. Runtime compilation is unnecessary. CMake source and BUILD_PROVENANCE.json identify the tested compiler, installed dependencies, source hashes and exact bundled binary. Other platforms require an explicitly qualified build; no Windows ABI claim is made.

```text
gxtxt_quantitative_extract SOURCE EXPECTED_SHA OUTPUT_DIR OP X Y WIDTH HEIGHT CHANNELS FRAME
gxtxt_quantitative_extract --version
```

Exactly ten fixed arguments follow the executable. OP is describe/pixel/statistics/histogram; these are extraction labels only. Describe reports the full source extent and writes no buffers. Pixel forces 1x1 at explicit X/Y. Other ROIs are strictly contained half-open integer rectangles in original top-left stored pixel coordinates. Incoming W/H must still be positive bounded integers. FRAME is exactly 0. CHANNELS is all or a comma-separated unique subset of Gray/R/G/B/A in requested output order. Histogram extraction requires one channel but computes no bins/counts. Unknown operations, channels, modes or frames refuse.

SOURCE must be a bounded nonempty regular single-link file opened read-only/O_NOFOLLOW. Full SHA256 must equal the exact 64-character lowercase expected hash before and after extraction, with stable descriptor/path identity. Encoded bytes<=64MiB, pixels<=16,777,216, each dimension<=16384, decoded declared raster<=128MiB and row<=1MiB. Sources are never modified. Output directory must already exist, be absolute, real (no symlink ancestors), owned by this account and private 0700. No output directory is created by the helper.

Supported native encodings:

- PNG Gray/RGB/RGBA unsigned 8/16, noninterlaced. Full chunk bounds/order/CRC, IHDR/data/IEND structure and decoder row shape are checked. Palette, sub-8-bit, gray-alpha, transparency-key, EXIF, ICC, animation, unknown critical chunks and interlace refuse. Raw codes are read with full libpng scanline API without gamma, normalization, alpha or significant-bit transforms. Source gAMA/sRGB declarations do not transform samples. Unneeded text chunks are discarded after source CRC checking, avoiding compressed-text inflation. No simplified linear/premultiplied image API is used.
- Classic single-frame, strip-contiguous, stored top-left TIFF Gray/RGB/RGBA with uint8/uint16/int16/IEEEfloat32. Compression 1/5/8 only, with installed-codec admission. Tiled, planar-separate, multiple frames, BigTIFF, other photometric/sample/compression/orientation layouts refuse. WhiteIsZero returns stored codes without inversion. RGBA requires exactly one explicit associated/unassociated alpha declaration; associated component codes remain associated, without unpremultiplication. Native TIFF OpenOptions cap single allocations 32MiB and cumulative allocations 128MiB. Rows before a cropped compressed ROI are decoded sequentially, retaining one row.

For each selected channel, `samples-INDEX.bin` is created exclusively/O_NOFOLLOW at mode 0600 and contains contiguous row-major little-endian original dtype samples. Integer values and float32 bits (including nonfinite payloads and signed zero) are not converted to binary64 or classified. Existing files are never overwritten. Caught errors/cancellation remove only this invocation's own created files; pre-existing output content remains. SIGTERM/SIGINT request cooperative cancellation. An abrupt SIGKILL or blocked native call can bypass cleanup/cooperative 120s checks; existing Job guardian and Resource ownership retain final disposal authority.

Successful extraction prints one finite JSON object<=32KiB, with no success stderr:

```text
{
 schema: "gxtxt.quantitative_raster.extract.v1",
 metadata: {format,width,height,dtype,sample_depth,channels,frame,frame_count,
            photometric,alpha_association,orientation,orientation_tag,
            decoder,decoder_version,[compression/profile_conversion],
            intensity_unit:"raw_sample",spatial_unit:"source_pixel",origin:"top_left",
            bounds:"half_open_strict_containment",color_conversion:false,
            luminance_conversion:false,normalization:"none",alpha_weighting:false,
            physical_calibration_inferred:false,native_precision_preserved:true},
 roi: {x,y,width,height},
 buffers: [{channel,dtype,elements,size_bytes,file}],
 timings_ms: {decoder_initialization,native_scanline_decode,extraction}
}
```

PNG decoder is truthfully `libpng_native_scanline`; TIFF remains `libtiff_native_scanline`. Dtypes are uint8/uint16/int16/float32. Buffers carry filenames only; no numeric values or classifications appear in JSON. Describe has an empty buffer array. Decoder initialization includes header admission; native scanline timing counts decoder calls; extraction includes streamed copying/output validation and overlapping native decode time. These are not additive independent phases or end-to-end Job/GUI timings. Source SHA guards and caller orchestration are outside these phase timings. TIFF describe admits its full directory but does not decode pixel payload; PNG describe validates full scanlines/end structure while producing no buffers.

Caught failures print one bounded `GXTXT:QuantitativeRaster:CODE: message` stderr line, no success JSON, and exit nonzero. Ordinary --version returns one short tool/runtime-library version line for fixed RuntimeTool discovery.

Decoder capability is distinct from installed Viewer/Canvas admission: a source supported here can still be refused by an existing display or source-dimension owner. No scientific precision, actual C++ reachability, resource cancellation, latency or release acceptance beyond the separately pinned integration/independent evidence is implied by this component alone.
