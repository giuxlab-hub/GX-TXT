# SPDX-License-Identifier: GPL-3.0-or-later
# Typed document-extraction form for the existing C++ Viewer GUI Host.
# Existing OCR/Table services and Dataset/Workspace owners
# retain processing and persistence authority. Author code receives no paths.
namespace eval ::GX::ViewerDocuments {variable forms {};variable serial 0}
proc ::GX::viewerGuiDocumentsCommands {} {
    return {refresh_sources open_source render previous next zoom_in zoom_out fit fit_width apply_zoom roi pan clear_roi select_page ocr table publish_text publish_image publish_page publish_table searchable_pdf copy_text cancel}
}
proc ::GX::_viewerDocumentsDefinitions {design} {
    set result {};set definitions {};set menuCommands {}
    foreach c [dict get $design components] {
        dict set definitions [dict get $c id] $c
        if {[dict get $c type] in {menu context_menu}} {lappend menuCommands {*}[datasetPublicationV2DictDefault [dict get $c properties] actions {}]}
    }
    foreach c [dict get $design components] {
        set p [dict get $c properties]
        if {![dict exists $p documents_owner]} continue
        if {[dict get $c type] ne {section} || [dict get $p documents_owner] ne {extraction}} {error {Document extraction requires a declared extraction section}}
        foreach {api version} {OCR_LAYOUT_API_v1 1 TABLE_EXTRACTOR_API_v1 1 DATASET_FILE_PUBLICATION_API_v1 1 DATASET_PUBLICATION_API_v2 2} {
            if {[datasetPublicationV2DictDefault [dict get $design requirements] $api {}] ne $version} {error "Document extraction requires $api@$version"}
        }
        set roles [dict get $p documents_components]
        foreach role {dataset page dpi zoom languages psm scope method ocr_engine table_engine expected_columns header table_index output_text output_image output_table output_pdf status source_info preview text table} {
            if {![dict exists $roles $role] || ![dict exists $definitions [dict get $roles $role]]} {error "Missing document form role: $role"}
            set type [dict get $definitions [dict get $roles $role] type]
            set wanted [expr {$role in {preview text table}?{section}:$role in {status source_info}?{status label log}:$role eq {dataset}?{dataset_selector}:{field entry choice combobox checkbutton toggle}}]
            if {$type ni $wanted} {error "Invalid document control type: $role"}
        }
        dict for {role id} $roles {
            if {$role in {text_provenance table_provenance}} {
                if {![dict exists $definitions $id] || [dict get $definitions $id type] ni {status label log}} {error "Invalid document provenance label: $role"}
            } elseif {[string match action_* $role]} {
                if {[string range $role 7 end] ni [viewerGuiDocumentsCommands]} {error "Invalid document action role: $role"}
                if {[dict exists $definitions $id]} {
                    if {[dict get $definitions $id type] ne {action}} {error "Invalid document action role: $role"}
                } elseif {![dict exists $design handlers $id] || $id ni $menuCommands} {error "Invalid document action role: $role"}
            }
        }
        dict set result [dict get $c id] $roles
    }
    return $result
}
proc ::GX::_viewerDocumentsKey {w form} {return [list $w $form]}
proc ::GX::_viewerDocumentsWidget {w form role} {
    set roles [dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form]
    return [dict get $::GX::ViewerGui::instances $w widgets [dict get $roles $role]]
}
proc ::GX::_viewerDocumentsGet {w form role} {
    set roles [dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form]
    return $::GX::ViewerGui::values($w,[dict get $roles $role])
}
proc ::GX::_viewerDocumentsSet {w form role value} {
    set roles [dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form]
    viewerGuiDesignValueSet $w [dict get $roles $role] $value
}
proc ::GX::_viewerDocumentsStatus {w form message} {
    if {![winfo exists $w]} return
    set roles [dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form]
    viewerGuiDesignTextSet $w [dict get $roles status] $message
}
proc ::GX::_viewerDocumentsSource {id {expected {}}} {
    set session [sessionInspectionCurrentSession]
    set ds [sessionInspectionDataset $id $session]
    set contract [datasetPublicationV2DictDefault $ds contract [datasetPublicationV2DictDefault $ds kind {}]]
    if {$contract ni {document.pdf image.raster}} {error {Select a canonical PDF or image Dataset}}
    set payload [sessionInspectionDatasetPayload $id $session]
    if {$expected ne {} && [dict get $payload sha256] ne $expected} {error {The canonical source changed; open its current version explicitly}}
    return [dict create dataset_id $id contract $contract format [datasetPublicationV2DictDefault $ds format {}] path [dict get $payload path] sha256 [dict get $payload sha256]]
}
proc ::GX::_viewerDocumentsEmpty {} {
    return [dict create dataset_id {} sha256 {} page 1 dpi 300 zoom 0 roi {} text {} rows {} width 0 height 0 page_count 0 text_context {} table_context {}]
}
# Optional role bindings join the existing command catalog. Older designs keep
# their original actions; no module callback or scientific Canvas is replaced.
proc ::GX::_viewerDocumentsCommandBindings {design} {
    set definitions {};set result {}
    foreach c [dict get $design components] {dict set definitions [dict get $c id] $c}
    dict for {form roles} [_viewerDocumentsDefinitions $design] {
        dict for {role id} $roles {
            if {[string match action_* $role]} {
                set action [expr {[dict exists $definitions $id]?[dict get $definitions $id properties action]:$id}]
                dict set result $action [list $form [string range $role 7 end]]
            }
        }
    }
    return $result
}
proc ::GX::_viewerDocumentsCommandChecked {w form operation} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form]
    return [expr {[dict exists $forms $key] && [dict get $forms $key mode] eq $operation}]
}
proc ::GX::_viewerDocumentsCommandEnabled {w form operation action} {
    variable ::GX::ViewerDocuments::forms
    if {![viewerGuiDesignActionEnabled $w $action]} {return 0}
    set key [_viewerDocumentsKey $w $form]
    if {![dict exists $forms $key]} {return 0}
    set row [dict get $forms $key]
    if {$operation eq {cancel}} {return [expr {[dict get $row pending] ne {}}]}
    if {[dict get $row pending] ne {}} {return 0}
    if {$operation in {refresh_sources open_source render copy_text}} {return 1}
    if {[dict get $row state dataset_id] eq {}} {return 0}
    if {$operation eq {previous}} {return [expr {[dict get $row state page]>1}]}
    if {$operation eq {next}} {return [expr {[dict get $row state page]<[dict get $row state page_count]}]}
    return 1
}
proc ::GX::_viewerDocumentsReviewMatches {w form context} {
    variable ::GX::ViewerDocuments::forms
    set state [dict get $forms [_viewerDocumentsKey $w $form] state]
    if {$context eq {}} {return 0}
    foreach field {dataset_id sha256 page dpi} {
        if {[dict get $context $field] ne [dict get $state $field]} {return 0}
    }
    if {[_viewerDocumentsGet $w $form dataset] ne [dict get $context dataset_id]} {return 0}
    foreach field {page dpi} {if {[_viewerDocumentsGet $w $form $field] ne [dict get $context $field]} {return 0}}
    return [expr {![catch {_viewerDocumentsSource [dict get $context dataset_id] [dict get $context sha256]}]}]
}
proc ::GX::_viewerDocumentsProvenance {w form} {
    variable ::GX::ViewerDocuments::forms
    set roles [dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form]
    set state [dict get $forms [_viewerDocumentsKey $w $form] state]
    foreach kind {text table} {
        if {![dict exists $roles ${kind}_provenance]} continue
        set context [dict get $state ${kind}_context]
        set message {No reviewed result. Run extraction on the opened source.}
        if {$context ne {}} {
            set match [_viewerDocumentsReviewMatches $w $form $context]
            set prefix [expr {$match?{Review}:{Retained draft — publication blocked}}]
            set message "$prefix: [dict get $context dataset_id] · page [dict get $context page] · [dict get $context dpi] DPI · SHA256 [dict get $context sha256]"
        }
        viewerGuiDesignTextSet $w [dict get $roles ${kind}_provenance] $message
    }
}
proc ::GX::_viewerDocumentsEscape {w form} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form]
    if {![dict exists $forms $key]} return
    if {[dict exists $forms $key drag]} {
        dict set forms $key state roi [dict get $forms $key drag old]
        dict unset forms $key drag
        _viewerDocumentsDrawRoi $w $form
        _viewerDocumentsStatus $w $form {Region gesture cancelled; previous selection restored.}
    } elseif {[dict get $forms $key pending] ne {}} {viewerGuiDesignDocumentsCommand $w $form cancel}
}
proc ::GX::_viewerDocumentsMinimumSize {w} {
    if {![winfo exists $w] || ![dict exists $::GX::ViewerGui::instances $w] ||
        [winfo toplevel $w] ne $w} return
    set definitions [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]]
    if {![dict size $definitions]} return
    set line 17
    foreach name {TkDefaultFont TkTextFont TkHeadingFont} {
        set line [expr {max($line,[font metrics $name -linespace])}]
    }
    if {![dict exists $::GX::ViewerGui::instances $w documents_minimum_base]} {
        dict set ::GX::ViewerGui::instances $w documents_minimum_base [wm minsize $w]
    }
    lassign [dict get $::GX::ViewerGui::instances $w documents_minimum_base] baseWidth baseHeight
    set width [expr {max($baseWidth,int(ceil(680*$line/17.0)))}]
    set height [expr {max($baseHeight,int(ceil(520*$line/17.0)))}]
    if {[winfo ismapped $w]} {
        dict for {form roles} $definitions {
            foreach role {preview text table} {
                set section [_viewerDocumentsWidget $w $form $role]
                if {[winfo manager $section] ne {grid}} continue
                set body [dict get [grid info $section] -in]
                if {![winfo ismapped $body] || [winfo width $body]<2 || [winfo height $body]<2} continue
                set review $section.[dict get {preview canvas text editor table tree} $role]
                if {![winfo exists $review]} continue
                # Tk owns the layout. Reserve a few review rows in addition to
                # its current fixed controls, including expanded options.
                set fixed [expr {max(0,[winfo reqheight $body]-[winfo reqheight $section])}]
                set chrome [expr {max(0,[winfo height $w]-[winfo height $body])}]
                set frame [expr {max(0,[winfo reqheight $section]-[winfo reqheight $review])}]
                set height [expr {max($height,$chrome+$fixed+$frame+max(100,4*$line))}]
            }
        }
    }
    set request [list $width $height [winfo screenwidth $w] [winfo screenheight $w]]
    if {[datasetPublicationV2DictDefault [dict get $::GX::ViewerGui::instances $w] documents_minimum_request {}] eq $request} return
    dict set ::GX::ViewerGui::instances $w documents_minimum_request $request
    wm minsize $w $width $height
    uiFieldWindowFit $w
}
proc ::GX::_viewerDocumentsInitialize {w} {
    variable ::GX::ViewerDocuments::forms
    set instance [dict get $::GX::ViewerGui::instances $w]
    set definitions [_viewerDocumentsDefinitions [dict get $instance design]]
    if {[dict size $definitions] && [winfo toplevel $w] eq $w} {
        _viewerDocumentsMinimumSize $w
    }
    dict for {form roles} $definitions {
        set key [_viewerDocumentsKey $w $form]
        if {[dict exists $forms $key]} continue
        dict set forms $key [dict create state [_viewerDocumentsEmpty] token [datasetPublicationV2DictDefault $instance token {}] pending {} mode roi photo {} render_allocation {} disposed 0 serial 0]
        set view [_viewerDocumentsWidget $w $form preview]
        canvas $view.canvas -background #eef2f5 -highlightthickness 0 -width 760 -height 470
        ttk::scrollbar $view.sy -orient vertical -command [list $view.canvas yview]
        ttk::scrollbar $view.sx -orient horizontal -command [list $view.canvas xview]
        $view.canvas configure -yscrollcommand [list $view.sy set] -xscrollcommand [list $view.sx set]
        grid $view.canvas -row 0 -column 0 -sticky nsew;grid $view.sy -row 0 -column 1 -sticky ns;grid $view.sx -row 1 -column 0 -sticky ew
        grid rowconfigure $view 0 -weight 1;grid columnconfigure $view 0 -weight 1
        bind $view.canvas <ButtonPress-1> [list ::GX::_viewerDocumentsPointer $w $form press %x %y]
        bind $view.canvas <B1-Motion> [list ::GX::_viewerDocumentsPointer $w $form move %x %y]
        bind $view.canvas <ButtonRelease-1> [list ::GX::_viewerDocumentsPointer $w $form release %x %y]
        bind $view.canvas <ButtonPress-2> [list $view.canvas scan mark %x %y]
        bind $view.canvas <B2-Motion> [list $view.canvas scan dragto %x %y 1]
        bind $view.canvas <Button-4> [list $view.canvas yview scroll -3 units]
        bind $view.canvas <Button-5> [list $view.canvas yview scroll 3 units]
        $view.canvas configure -takefocus 1
        bind $view.canvas <Escape> [list ::GX::_viewerDocumentsEscape $w $form]
        set text [_viewerDocumentsWidget $w $form text]
        text $text.editor -wrap word -undo 1 -height 20 -width 70
        ttk::scrollbar $text.sy -command [list $text.editor yview];$text.editor configure -yscrollcommand [list $text.sy set]
        pack $text.sy -side right -fill y;pack $text.editor -fill both -expand 1
        bind $text.editor <<Modified>> [list ::GX::_viewerDocumentsTextChanged $w $form]
        bind $text.editor <FocusOut> [list ::GX::_viewerDocumentsCheckpoint $w $form]
        set table [_viewerDocumentsWidget $w $form table]
        ttk::treeview $table.tree -show headings -height 18
        # Reuse the same font-row owner as Dataset Preview, Workspace and
        # Plugin Manager; this style is scoped to document review tables.
        _uiFieldTreeFontRows $table.tree GXDocumentReview.Treeview
        foreach event {<Map> <Configure> <<ThemeChanged>>} {bind $table.tree $event +[list ::GX::_uiFieldTreeFontRows $table.tree GXDocumentReview.Treeview]}
        ttk::scrollbar $table.sy -command [list $table.tree yview]
        ttk::scrollbar $table.sx -orient horizontal -command [list $table.tree xview]
        $table.tree configure -yscrollcommand [list $table.sy set] -xscrollcommand [list $table.sx set]
        grid $table.tree -row 0 -column 0 -sticky nsew;grid $table.sy -row 0 -column 1 -sticky ns;grid $table.sx -row 1 -column 0 -sticky ew
        grid rowconfigure $table 0 -weight 1;grid columnconfigure $table 0 -weight 1
        bind $table.tree <Double-1> [list ::GX::_viewerDocumentsEdit $w $form %x %y]
        foreach event {<F2> <Return>} {bind $table.tree $event [list ::GX::_viewerDocumentsEditFocused $w $form]}
        foreach section [list $view $text $table] {
            foreach event {<Map> <Unmap> <Configure>} {bind $section $event +[list ::GX::_viewerGuiGeometrySchedule $w $w]}
        }
        _viewerDocumentsStatus $w $form {Select a PDF or image Dataset, then Open source. No source is opened automatically.}
        _viewerDocumentsProvenance $w $form
    }
    viewerGuiActionsRefresh $w
}
proc ::GX::_viewerDocumentsSync {w form} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form]
    if {![dict exists $forms $key] || ![dict exists $::GX::ViewerGui::instances $w]} return
    set text [_viewerDocumentsWidget $w $form text].editor
    set reviewState [dict get $forms $key state]
    if {[winfo exists $text]} {
        set review [$text get 1.0 end-1c]
        if {[string length [encoding convertto utf-8 $review]]>4194304} {
            set message {Text exceeds the 4 MiB UTF-8 review limit. Correct the editor before Save or Publish; the previous accepted review is preserved.}
            _viewerDocumentsStatus $w $form $message
            return -code error $message
        }
        dict set reviewState text $review
    }
    set context [viewerGuiDesignContextGet $w]
    dict set context document_extraction $form $reviewState
    if {[catch {viewerGuiDesignContextSet $w $context} message options]} {
        _viewerDocumentsStatus $w $form "Review cannot be committed: $message. The previous accepted review is preserved."
        return -options $options $message
    }
    dict set forms $key state $reviewState
}
proc ::GX::_viewerDocumentsCapture {w} {
    variable ::GX::ViewerDocuments::forms
    dict for {key row} $forms {if {[lindex $key 0] eq $w && ![dict get $row disposed]} {_viewerDocumentsSync $w [lindex $key 1]}}
}
proc ::GX::_viewerDocumentsCheckpoint {w form} {
    if {![winfo exists $w]} return
    if {[catch {_viewerDocumentsSync $w $form}]} {return 0}
    if {[dict exists $::GX::ScientificHistory::viewers $w] && ![dict get $::GX::ViewerGui::instances $w restoring]} {
        set latest [scientificHistoryViewerState $w]
        set current [viewerGuiDesignContextGet $w]
        if {[datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $latest domain_state {}] document_extraction {}] ne [datasetPublicationV2DictDefault $current document_extraction {}]} {
            scientificHistoryViewerRecordOperation $w {Update document review}
        }
    }
    return 1
}
proc ::GX::_viewerDocumentsHistoryFlush {w} {
    variable ::GX::ViewerDocuments::forms
    if {![dict exists $::GX::ViewerGui::instances $w] || [dict get $::GX::ViewerGui::instances $w restoring]} return
    dict for {key row} $forms {
        if {[lindex $key 0] eq $w && ![dict get $row disposed] && [dict get $row pending] eq {}} {
            if {![_viewerDocumentsCheckpoint $w [lindex $key 1]]} {error {Correct the oversized text review before changing History}}
        }
    }
}
proc ::GX::_viewerGuiHistoryBeforeTransition {w} {
    _viewerGuiScriptLibraryHistoryFlush $w
    _viewerDocumentsHistoryFlush $w
    _viewerCanvasHistoryFlush $w
}
proc ::GX::_viewerDocumentsTextChanged {w form} {
    set text [_viewerDocumentsWidget $w $form text].editor
    if {![winfo exists $text] || ![$text edit modified]} return
    $text edit modified 0
    catch {_viewerDocumentsSync $w $form}
}
proc ::GX::_viewerDocumentsDrawRoi {w form} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form];set row [dict get $forms $key]
    set canvas [_viewerDocumentsWidget $w $form preview].canvas
    $canvas delete roi
    set roi [dict get $row state roi]
    if {$roi eq {} || ![dict exists $row display_width]} return
    lassign $roi x1 y1 x2 y2;set width [dict get $row display_width];set height [dict get $row display_height]
    set left [expr {$x1*$width}];set top [expr {$y1*$height}];set right [expr {$x2*$width}];set bottom [expr {$y2*$height}]
    $canvas create rectangle $left $top $right $bottom -outline #087ea4 -width 2 -tags roi
    foreach {x y} [list $left $top [expr {($left+$right)/2}] $top $right $top $right [expr {($top+$bottom)/2}] $right $bottom [expr {($left+$right)/2}] $bottom $left $bottom $left [expr {($top+$bottom)/2}]] {
        $canvas create rectangle [expr {$x-4}] [expr {$y-4}] [expr {$x+4}] [expr {$y+4}] -fill white -outline #087ea4 -tags roi
    }
}
proc ::GX::_viewerDocumentsPointer {w form phase x y} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form]
    if {![viewerGuiDesignGuard $w] || ![dict exists $forms $key display_width] || [dict get $forms $key pending] ne {}} return
    set c [_viewerDocumentsWidget $w $form preview].canvas
    if {[dict get $forms $key mode] eq {pan}} {
        if {$phase eq {press}} {$c scan mark $x $y} elseif {$phase eq {move}} {$c scan dragto $x $y 1}
        return
    }
    set width [dict get $forms $key display_width];set height [dict get $forms $key display_height]
    set nx [expr {max(0.0,min(1.0,double([$c canvasx $x])/$width))}]
    set ny [expr {max(0.0,min(1.0,double([$c canvasy $y])/$height))}]
    if {$phase eq {press}} {
        focus $c
        if {[dict exists $::GX::ScientificHistory::viewers $w] && ![scientificHistoryViewerPrepareEdit $w]} return
        set old [dict get $forms $key state roi];set mode new;set handle {}
        if {$old ne {}} {
            lassign $old a b d e
            foreach {name hx hy} [list nw $a $b n [expr {($a+$d)/2}] $b ne $d $b e $d [expr {($b+$e)/2}] se $d $e s [expr {($a+$d)/2}] $e sw $a $e w $a [expr {($b+$e)/2}]] {
                if {abs(($hx-$nx)*$width)<=7 && abs(($hy-$ny)*$height)<=7} {set mode resize;set handle $name;break}
            }
            if {$mode eq {new} && $nx>=$a && $nx<=$d && $ny>=$b && $ny<=$e} {set mode move}
        }
        dict set forms $key drag [dict create x $nx y $ny old $old mode $mode handle $handle]
    }
    if {![dict exists $forms $key drag]} return
    set drag [dict get $forms $key drag];set dx [expr {$nx-[dict get $drag x]}];set dy [expr {$ny-[dict get $drag y]}]
    set mode [dict get $drag mode]
    if {$mode eq {new}} {set roi [list [dict get $drag x] [dict get $drag y] $nx $ny]
    } else {
        lassign [dict get $drag old] a b d e
        if {$mode eq {move}} {
            set dx [expr {max(-$a,min(1-$d,$dx))}];set dy [expr {max(-$b,min(1-$e,$dy))}]
            set roi [list [expr {$a+$dx}] [expr {$b+$dy}] [expr {$d+$dx}] [expr {$e+$dy}]]
        } else {
            set h [dict get $drag handle]
            if {[string match *w* $h]} {set a $nx};if {[string match *e* $h]} {set d $nx}
            if {[string match *n* $h]} {set b $ny};if {[string match *s* $h]} {set e $ny}
            set roi [list $a $b $d $e]
        }
    }
    lassign $roi a b d e;set roi [list [expr {min($a,$d)}] [expr {min($b,$e)}] [expr {max($a,$d)}] [expr {max($b,$e)}]]
    dict set forms $key state roi $roi
    _viewerDocumentsDrawRoi $w $form
    if {$phase eq {release}} {
        dict unset forms $key drag
        lassign $roi a b d e
        if {($d-$a)*$width<2 || ($e-$b)*$height<2} {dict set forms $key state roi {};_viewerDocumentsDrawRoi $w $form}
        _viewerDocumentsCheckpoint $w $form
    }
}
proc ::GX::_viewerDocumentsTableDraw {w form} {
    variable ::GX::ViewerDocuments::forms
    set tree [_viewerDocumentsWidget $w $form table].tree
    set rows [dict get $forms [_viewerDocumentsKey $w $form] state rows]
    set selection [$tree selection];set focused [$tree focus]
    $tree delete [$tree children {}]
    set count 0;foreach row $rows {set count [expr {max($count,[llength $row])}]}
    set columns {};for {set i 0} {$i<$count} {incr i} {lappend columns c$i}
    $tree configure -columns $columns
    for {set i 0} {$i<$count} {incr i} {$tree heading c$i -text "Column [expr {$i+1}]";$tree column c$i -width 150 -minwidth 70}
    set i 0;foreach row $rows {$tree insert {} end -id r$i -values $row;incr i}
    set retained {};foreach id $selection {if {[$tree exists $id]} {lappend retained $id}}
    if {[llength $retained]} {$tree selection set $retained}
    if {$focused ne {} && [$tree exists $focused]} {$tree focus $focused}
}
proc ::GX::_viewerDocumentsEdit {w form x y} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form];set tree [_viewerDocumentsWidget $w $form table].tree
    if {[dict get $forms $key pending] ne {} || [$tree identify region $x $y] ne {cell}} return
    set item [$tree identify row $x $y];set column [$tree identify column $x $y]
    if {$item eq {} || $column eq {}} return
    set ri [string range $item 1 end];set ci [expr {[string range $column 1 end]-1}]
    _viewerDocumentsEditCell $w $form $ri $ci
}
proc ::GX::_viewerDocumentsEditFocused {w form} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form];set tree [_viewerDocumentsWidget $w $form table].tree
    set item [$tree focus]
    if {$item eq {}} {set item [lindex [$tree selection] 0]}
    if {$item eq {}} {set item [lindex [$tree children {}] 0]}
    if {$item ne {}} {_viewerDocumentsEditCell $w $form [string range $item 1 end] [datasetPublicationV2DictDefault [dict get $forms $key] cell_column 0]}
    return -code break
}
proc ::GX::_viewerDocumentsEditCell {w form ri ci} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form];set tree [_viewerDocumentsWidget $w $form table].tree
    if {![viewerGuiDesignGuard $w] || [dict get $forms $key pending] ne {} || ![$tree exists r$ri]} return
    set columns [$tree cget -columns];if {![llength $columns]} return
    set ci [expr {max(0,min([llength $columns]-1,$ci))}]
    if {[dict exists $::GX::ScientificHistory::viewers $w] && ![scientificHistoryViewerPrepareEdit $w]} return
    $tree selection set r$ri;$tree focus r$ri;$tree see r$ri
    # Reveal the native cell before placing its existing entry editor. Only
    # the Treeview scroll position changes; scientific table values do not.
    set total 0;set left 0;set width 0;set index 0
    foreach column $columns {
        set current [$tree column $column -width]
        if {$index<$ci} {incr left $current}
        if {$index==$ci} {set width $current}
        incr total $current;incr index
    }
    set visible [expr {[lindex [$tree xview] 0]*$total}];set room [expr {max(1,[winfo width $tree]-4)}]
    if {$left<$visible || $left+$width>$visible+$room} {
        set origin [expr {$width>$room || $left<$visible?$left:$left+$width-$room}]
        $tree xview moveto [expr {$origin/double(max(1,$total))}]
    }
    set bounds [$tree bbox r$ri [lindex $columns $ci]]
    if {[llength $bounds]!=4} return
    lassign $bounds bx by bw bh
    set bw [expr {max(1,min($bw,[winfo width $tree]-$bx-2))}]
    catch {destroy $tree.edit}
    ttk::entry $tree.edit -font TkDefaultFont;$tree.edit insert 0 [lindex [dict get $forms $key state rows] $ri $ci]
    place $tree.edit -x $bx -y $by -width $bw -height $bh
    dict set forms $key cell_column $ci
    $tree.edit selection range 0 end;focus $tree.edit
    bind $tree.edit <Return> [list ::GX::_viewerDocumentsEditCommit $w $form $ri $ci]
    bind $tree.edit <FocusOut> [list ::GX::_viewerDocumentsEditCommit $w $form $ri $ci 0]
    bind $tree.edit <Escape> [list ::GX::_viewerDocumentsEditCancel $w $form]
    bind $tree.edit <Tab> [list ::GX::_viewerDocumentsEditStep $w $form $ri $ci 1]
    foreach event {<Shift-Tab> <ISO_Left_Tab>} {bind $tree.edit $event [list ::GX::_viewerDocumentsEditStep $w $form $ri $ci -1]}
}
proc ::GX::_viewerDocumentsEditCancel {w form} {
    set tree [_viewerDocumentsWidget $w $form table].tree
    if {[winfo exists $tree.edit]} {bind $tree.edit <FocusOut> {};destroy $tree.edit}
    focus $tree
    return -code break
}
proc ::GX::_viewerDocumentsEditStep {w form ri ci direction} {
    variable ::GX::ViewerDocuments::forms
    set tree [_viewerDocumentsWidget $w $form table].tree;set count [llength [$tree cget -columns]]
    _viewerDocumentsEditCommit $w $form $ri $ci
    set next [expr {$ri*$count+$ci+$direction}]
    set rows [dict get $forms [_viewerDocumentsKey $w $form] state rows]
    if {$next>=0 && $next<[llength $rows]*$count} {
        _viewerDocumentsEditCell $w $form [expr {$next/$count}] [expr {$next%$count}]
    } else {focus [expr {$direction>0?[tk_focusNext $tree]:[tk_focusPrev $tree]}]}
    return -code break
}
proc ::GX::_viewerDocumentsEditCommit {w form ri ci {returnFocus 1}} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form];set edit [_viewerDocumentsWidget $w $form table].tree.edit
    if {![winfo exists $edit]} return
    set rows [dict get $forms $key state rows];set row [lindex $rows $ri]
    while {[llength $row]<=$ci} {lappend row {}}
    lset row $ci [$edit get];lset rows $ri $row
    bind $edit <FocusOut> {};destroy $edit
    dict set forms $key state rows $rows
    _viewerDocumentsTableDraw $w $form;_viewerDocumentsCheckpoint $w $form
    if {$returnFocus} {focus [_viewerDocumentsWidget $w $form table].tree}
}
proc ::GX::_viewerDocumentsContext {request} {
    set result {}
    foreach key {dataset_id sha256 contract page dpi roi scope languages psm method ocr_engine table_engine expected_columns header table_index} {if {[dict exists $request $key]} {dict set result $key [dict get $request $key]}}
    return $result
}
proc ::GX::_viewerDocumentsRelease {allocation} {
    if {$allocation eq {}} return
    catch {resourceManagementRelease [dict get $allocation id] verified_orphan 0}
    catch {resourceManagementCleanup [list [dict get $allocation id]]}
}
proc ::GX::_viewerDocumentsStart {w form operation {extra {}}} {
    variable ::GX::ViewerDocuments::forms
    variable ::GX::ViewerDocuments::serial
    set key [_viewerDocumentsKey $w $form]
    if {[dict get $forms $key pending] ne {}} {error {A document operation is pending; wait or cancel it}}
    if {![viewerGuiDesignGuard $w]} {error {Session changed; reopen Unified Documents}}
    _viewerDocumentsSync $w $form
    if {[dict get $::GX::ViewerGui::instances $w token] eq {}} {dict set ::GX::ViewerGui::instances $w token [interactiveDocumentSessionToken]}
    set state [dict get $forms $key state]
    set id [expr {$operation eq {render}?[_viewerDocumentsGet $w $form dataset]:[dict get $state dataset_id]}]
    if {$id eq {}} {error {Select a canonical PDF or image Dataset and open it}}
    set source [_viewerDocumentsSource $id [expr {$operation eq {render}?{}:[dict get $state sha256]}]]
    set request $source
    foreach role {page dpi zoom languages psm scope method ocr_engine table_engine expected_columns header table_index} {dict set request $role [_viewerDocumentsGet $w $form $role]}
    dict set request method [string tolower [dict get $request method]]
    foreach {field minimum maximum} {page 1 100000 dpi 72 600 psm 0 13 expected_columns 0 100 table_index 1 1000} {
        set value [dict get $request $field]
        if {![string is integer -strict $value] || $value<$minimum || $value>$maximum} {error "Invalid $field: enter an integer in $minimum..$maximum"}
    }
    if {$operation ni {render schema} && ([dict get $request page] != [dict get $state page] || [dict get $request dpi] != [dict get $state dpi])} {error {Press Render page to apply changed page or DPI settings before processing}}
    set request [dict merge $request $extra]
    if {$operation eq {table}} {dict set request scope Region}
    dict set request operation $operation
    dict set request page_count [dict get $state page_count]
    dict set request roi [dict get $state roi]
    if {[dict get $request scope] ne {Region} || $operation eq {searchable_pdf}} {dict set request roi {}}
    if {$operation in {render zoom}} {dict set request roi [dict get $state roi]}
    if {[dict exists $forms $key image_path]} {dict set request image_path [dict get $forms $key image_path]}
    if {$operation ni {render} && ![dict exists $request image_path]} {error {Open and render the source first}}
    if {$operation eq {crop} && [dict exists $extra whole_page]} {dict set request roi {}}
    if {[dict exists $extra context]} {set request [dict merge $request [dict get $extra context]];dict unset request context}
    set canvas [_viewerDocumentsWidget $w $form preview].canvas
    dict set request view_width [expr {max(1,[winfo width $canvas]-10)}]
    dict set request view_height [expr {max(1,[winfo height $canvas]-10)}]
    set allocation [resourceManagementAllocate document_extraction [dict create category temporary lifetime viewer session [sessionInspectionCurrentSession]]]
    set directory [dict get $allocation path];dict set request directory $directory
    set requestPath [file join $directory request.tcldict]
    set f [open $requestPath w];fconfigure $f -encoding utf-8;puts $f $request;close $f
    set generation [incr serial];dict set forms $key serial $generation
    dict set forms $key allocation $allocation
    set command [list /usr/bin/setsid /usr/bin/tclsh [file join $::GX::scriptDir core tcl document_extraction_worker.tcl] $::GX::scriptDir $requestPath]
    if {[dict exists $forms $key last_error]} {dict unset forms $key last_error}
    try {
        set token [scriptJobAsync $command {} [list ::GX::_viewerDocumentsDone $w $form $generation $allocation $request] [dict create timeout_ms 3700000 max_bytes 8388608 process_group 1 ui_lifetime 1 separate_stderr 1 label "Document $operation"]]
    } on error {message options} {_viewerDocumentsRelease $allocation;return -options $options $message}
    dict set forms $key pending $token
    viewerGuiActionsRefresh $w
    _viewerDocumentsStatus $w $form "Running $operation… The Viewer remains responsive; Cancel stops the owned request."
    return [dict create status pending operation $operation request_id $token]
}
proc ::GX::_viewerDocumentsDone {w form generation allocation request output} {
    variable ::GX::ViewerDocuments::forms
    set key [_viewerDocumentsKey $w $form];set retain 0
    try {
        if {![dict exists $forms $key] || [dict get $forms $key disposed] || ![winfo exists $w]} return
        if {[dict get $forms $key serial]!=$generation} return
        dict set forms $key pending {}
        viewerGuiActionsRefresh $w
        if {![viewerGuiDesignGuard $w]} {error {Session changed; document result was discarded}}
        if {[_viewerDocumentsGet $w $form dataset] ne [dict get $request dataset_id] || [_viewerDocumentsGet $w $form page] ne [dict get $request page] || [_viewerDocumentsGet $w $form dpi] ne [dict get $request dpi]} {error {Source or page settings changed; document result was discarded}}
        _viewerDocumentsSource [dict get $request dataset_id] [dict get $request sha256]
        if {[catch {dict get $output ok} ok] || !$ok} {
            if {![catch {dict get $output error} message]} {error $message}
            error "Document operation failed or was cancelled: [string range $output 0 1500]"
        }
        set result [dict get $output result];set operation [dict get $request operation]
        set context [_viewerDocumentsContext $request]
        switch $operation {
            render - zoom {
                set old [dict get $forms $key render_allocation]
                dict set forms $key render_allocation $allocation;set retain 1
                foreach field {image_path display_width display_height} {dict set forms $key $field [dict get $result $field]}
                foreach field {dataset_id sha256 dpi} {dict set forms $key state $field [dict get $request $field]}
                foreach field {width height zoom} {dict set forms $key state $field [dict get $result $field]}
                if {$operation eq {render}} {
                    dict set forms $key state page [dict get $result page]
                    dict set forms $key state page_count [dict get $result page_count]
                    _viewerDocumentsSet $w $form page [dict get $result page]
                    if {![datasetPublicationV2DictDefault $request restore 0]} {dict set forms $key state roi {}}
                }
                _viewerDocumentsSet $w $form zoom [format %.2f [dict get $result zoom]]
                set canvas [_viewerDocumentsWidget $w $form preview].canvas
                set photo [image create photo -file [dict get $result display_path]]
                set oldPhoto [dict get $forms $key photo]
                dict set forms $key photo $photo
                if {[$canvas find withtag source] eq {}} {$canvas create image 0 0 -anchor nw -image $photo -tags source} else {$canvas itemconfigure source -image $photo}
                if {$oldPhoto ne {}} {image delete $oldPhoto}
                $canvas configure -scrollregion [list 0 0 [dict get $result display_width] [dict get $result display_height]]
                if {$operation eq {render}} {$canvas xview moveto 0;$canvas yview moveto 0}
                _viewerDocumentsDrawRoi $w $form
                set roles [dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form]
                set state [dict get $forms $key state]
                if {[dict exists $result languages]} {dict set forms $key languages [dict get $result languages]}
                viewerGuiDesignTextSet $w [dict get $roles source_info] "Opened: [dict get $state dataset_id] · page [dict get $state page]/[dict get $state page_count] · [dict get $state width]×[dict get $state height] px · SHA256 [string range [dict get $state sha256] 0 11]…"
                if {$old ne {}} {_viewerDocumentsRelease $old}
                _viewerDocumentsStatus $w $form {Source ready.}
            }
            ocr {
                set text [dict get $result text]
                if {[string length [encoding convertto utf-8 $text]]>4194304} {error {Recognized text exceeds the 4 MiB UTF-8 review limit}}
                dict set forms $key state text $text
                dict set forms $key state text_context $context
                set widget [_viewerDocumentsWidget $w $form text].editor
                $widget delete 1.0 end;$widget insert 1.0 $text;$widget edit reset;$widget edit modified 0
                _viewerDocumentsStatus $w $form "OCR completed: [string length $text] characters. Review and correct the text before publishing."
            }
            table {
                dict set forms $key state rows [dict get $result rows]
                foreach field {method word_count table_count} {if {[dict exists $result $field]} {dict set context $field [dict get $result $field]}}
                dict set forms $key state table_context $context
                _viewerDocumentsTableDraw $w $form
                _viewerDocumentsStatus $w $form "Table ready: [llength [dict get $result rows]] rows; [datasetPublicationV2DictDefault $result table_count 1] table(s). Double-click cells to correct them before publication."
            }
            crop {_viewerDocumentsPublishFile $w $form image $request [dict get $result output_path] $result}
            searchable_pdf {_viewerDocumentsPublishFile $w $form pdf $request [dict get $result output_path] $result}
            schema {_viewerDocumentsPublishTable $w $form $request $result}
        }
        _viewerDocumentsProvenance $w $form
        viewerGuiActionsRefresh $w
        if {![datasetPublicationV2DictDefault $request restore 0]} {_viewerDocumentsCheckpoint $w $form}
    } on error {message options} {
        if {[winfo exists $w]} {_viewerDocumentsStatus $w $form "Error: $message"}
        if {[dict exists $forms $key]} {dict set forms $key last_error $message}
    } finally {
        if {!$retain} {_viewerDocumentsRelease $allocation}
        if {[dict exists $forms $key] && [dict get $forms $key disposed]} {
            _viewerDocumentsRelease [dict get $forms $key render_allocation]
            dict unset forms $key
        }
    }
}
proc ::GX::_viewerDocumentsPublishFile {w form kind context path {result {}}} {
    _viewerDocumentsSource [dict get $context dataset_id] [dict get $context sha256]
    set module [dict get $::GX::ViewerGui::instances $w actor_module]
    set role [dict get {text output_text image output_image pdf output_pdf} $kind]
    set id [string trim [_viewerDocumentsGet $w $form $role]]
    datasetPublicationV2ValidateId dataset $id
    set contract [dict get {text document.text image image.raster pdf document.pdf} $kind]
    set format [dict get {text txt image png pdf pdf} $kind]
    set media [dict get {text text/plain image image/png pdf application/pdf} $kind]
    set md [dict create document.source_dataset_id [dict get $context dataset_id] document.source_sha256 [dict get $context sha256] document.source_page [dict get $context page] document.render_dpi [dict get $context dpi] document.source_roi_norm [dict get $context roi] extraction.viewer $module]
    foreach field {languages psm scope method ocr_engine} {dict set md ocr.$field [dict get $context $field]}
    if {$kind eq {text}} {dict set md text.encoding UTF-8;dict set md ocr.source_dataset_id [dict get $context dataset_id]}
    if {$kind eq {image}} {foreach field {width height} {dict set md image.${field}_px [dict get $result $field]};dict set md image.source_pdf_dataset_id [dict get $context dataset_id];dict set md image.source_page [dict get $context page];dict set md image.render_dpi [dict get $context dpi]}
    if {$kind eq {pdf}} {dict set md document.page_count [dict get $result page_count];dict set md pdf.ocr true;dict set md ocr.engine OCRmyPDF/Tesseract}
    set req [dict create dataset_id $id contract $contract format $format source_file $path storage_kind [expr {$kind eq {text}?{text}:{binary}}] media_type $media producer_version [moduleField $module version] source_dataset_ids [list [dict get $context dataset_id]] source {Unified Documents} provenance "[dict get $context ocr_engine] / [dict get $context scope] extraction from Dataset [dict get $context dataset_id]; SHA256 [dict get $context sha256]; page [dict get $context page]; ROI [dict get $context roi]" structured_metadata $md replace_owned 1]
    set receipt [datasetFilePublicationPublish [sessionInspectionCurrentSession] $module $req]
    _viewerDocumentsStatus $w $form "Published $contract Dataset: [dict get $receipt dataset_id]"
    return $receipt
}
proc ::GX::_viewerDocumentsPublishTable {w form context result} {
    _viewerDocumentsSource [dict get $context dataset_id] [dict get $context sha256]
    set module [dict get $::GX::ViewerGui::instances $w actor_module]
    set columns [dict get $result columns];set rows [dict get $result rows]
    if {![llength $columns] || ![llength $rows]} {error {The corrected table has no publishable data rows}}
    set id [string trim [_viewerDocumentsGet $w $form output_table]]
    set md [dict create table.source_dataset_id [dict get $context dataset_id] table.source_sha256 [dict get $context sha256] table.source_page [dict get $context page] table.source_roi_norm [dict get $context roi] table.method [dict get $context method] table.first_row_header [dict get $context header] table.extraction.api [dict get $context table_engine] table.languages [dict get $context languages] table.psm [dict get $context psm] table.render_dpi [dict get $context dpi]]
    if {[dict exists $result title] && [dict get $result title] ne {}} {dict set md table.title [dict get $result title]}
    set definition [dict create dataset_id $id contract table.generic storage csv replace_owned 1 producer_version [moduleField $module version] structured_metadata $md source_dataset_ids [list [dict get $context dataset_id]] source {Unified Documents} provenance "[dict get $context table_engine]; source Dataset [dict get $context dataset_id]; SHA256 [dict get $context sha256]; method [dict get $context method]; page [dict get $context page]; ROI [dict get $context roi]"]
    set plan [datasetPublicationV2Prepare [sessionInspectionCurrentSession] $module $definition]
    set writer [datasetPublicationV2OpenWriter $plan]
    try {
        datasetPublicationV2DeclareDimension $writer row 0 [dict create extendible 1]
        set chunk {};set index 0
        foreach col $columns {
            set name [dict get $col id];set label [datasetPublicationV2DictDefault $col label [datasetPublicationV2DictDefault $col name $name]]
            datasetPublicationV2DeclareVariable $writer $name [dict create name $name display_label $label semantic_source plugin unit {} semantic_role {} dtype [dict get $col dtype] rank 1 dimension_ids row coordinate_role data axis_kind explicit]
            set values {};foreach row $rows {lappend values [lindex $row $index]};dict set chunk $name $values
            incr index
        }
        datasetPublicationV2Append $writer row $chunk
        set receipt [datasetPublicationV2Finalize $writer]
    } on error {message options} {catch {datasetPublicationV2Abort $writer};return -options $options $message}
    _viewerDocumentsStatus $w $form "Published table.generic Dataset: $id ([llength $rows] rows × [llength $columns] columns)"
    return $receipt
}
proc ::GX::viewerGuiDesignDocumentsCommand {w form operation} {
    variable ::GX::ViewerDocuments::forms
    if {$operation ni [viewerGuiDocumentsCommands]} {error {Unsupported document extraction command}}
    if {![viewerGuiDesignGuard $w]} {error {The document Viewer belongs to another Session}}
    set key [_viewerDocumentsKey $w $form]
    if {![dict exists $forms $key]} {_viewerDocumentsInitialize $w}
    if {![dict exists $forms $key]} {error {Declare the complete document extraction form in Interface Builder}}
    if {$operation eq {cancel}} {
        set pending [dict get $forms $key pending]
        if {$pending ne {}} {scriptJobRequestCancel $pending cancelled;_viewerDocumentsStatus $w $form {Cancelling the owned document operation…}}
        return [dict create status cancelling]
    }
    if {$operation eq {refresh_sources}} {datasetSelectorRefresh [_viewerDocumentsWidget $w $form dataset].entry;return [dict create status refreshed]}
    if {[dict get $forms $key pending] ne {}} {error {Wait for the current document operation or cancel it}}
    set state [dict get $forms $key state]
    switch $operation {
        open_source - render {return [_viewerDocumentsStart $w $form render]}
        previous - next {
            set page [expr {max(1,min([dict get $state page_count],[dict get $state page]+($operation eq {next}?1:-1)))}]
            if {$page==[dict get $state page]} {return [dict create status ready page $page unchanged 1]}
            _viewerDocumentsSet $w $form page $page
            return [_viewerDocumentsStart $w $form render]
        }
        fit - fit_width - zoom_in - zoom_out - apply_zoom {
            if {$operation eq {fit}} {set zoom 0} elseif {$operation eq {fit_width}} {set zoom -1} elseif {$operation eq {apply_zoom}} {set zoom [_viewerDocumentsGet $w $form zoom]} else {set zoom [expr {[dict get $state zoom]*($operation eq {zoom_in}?1.25:0.8)}]}
            _viewerDocumentsSet $w $form zoom $zoom
            return [_viewerDocumentsStart $w $form zoom]
        }
        pan - roi {dict set forms $key mode $operation;viewerGuiActionsRefresh $w;_viewerDocumentsStatus $w $form "Pointer mode: $operation"}
        clear_roi - select_page {
            dict set forms $key state roi [expr {$operation eq {clear_roi}?{}:{0 0 1 1}}]
            _viewerDocumentsDrawRoi $w $form;_viewerDocumentsCheckpoint $w $form
        }
        ocr {return [_viewerDocumentsStart $w $form ocr]}
        table {return [_viewerDocumentsStart $w $form table]}
        publish_image - publish_page {
            if {$operation eq {publish_image} && [dict get $state roi] eq {}} {error {Select a region first, or use Publish page image}}
            set extra [dict create scope Region]
            if {$operation eq {publish_page}} {dict set extra whole_page 1}
            return [_viewerDocumentsStart $w $form crop $extra]
        }
        searchable_pdf {return [_viewerDocumentsStart $w $form searchable_pdf]}
        copy_text {
            set text [[_viewerDocumentsWidget $w $form text].editor get 1.0 end-1c]
            clipboard clear -displayof $w;clipboard append -displayof $w $text
            _viewerDocumentsStatus $w $form {Recognized text copied to the clipboard}
        }
        publish_text {
            _viewerDocumentsSync $w $form;set state [dict get $forms $key state]
            set text [dict get $state text];if {[string trim $text] eq {}} {error {Recognize or enter text before publishing}}
            set context [dict get $state text_context]
            if {$context eq {}} {error {Run OCR on the source before publishing corrected text}}
            if {![_viewerDocumentsReviewMatches $w $form $context]} {_viewerDocumentsProvenance $w $form;error {This retained text belongs to another source/page/revision. Reopen its original source and settings, or run OCR explicitly on the current source.}}
            set f [file tempfile path];fconfigure $f -encoding utf-8 -translation lf;puts -nonewline $f $text;close $f
            try {return [_viewerDocumentsPublishFile $w $form text $context $path]} finally {file delete -force $path}
        }
        publish_table {
            set context [dict get $state table_context]
            if {$context eq {} || ![llength [dict get $state rows]]} {error {Extract and review a table before publishing}}
            if {![_viewerDocumentsReviewMatches $w $form $context]} {_viewerDocumentsProvenance $w $form;error {This retained table belongs to another source/page/revision. Reopen its original source and settings, or extract explicitly on the current source.}}
            dict set context header [_viewerDocumentsGet $w $form header]
            return [_viewerDocumentsStart $w $form schema [dict create rows [dict get $state rows] context $context]]
        }
    }
    return [dict create status ready]
}
proc ::GX::_viewerDocumentsRestoreCheck {w domains} {
    if {![dict exists $domains document_extraction]} return
    dict for {form state} [dict get $domains document_extraction] {
        dict get [_viewerDocumentsDefinitions [dict get $::GX::ViewerGui::instances $w design]] $form
        if {[dict get $state dataset_id] ne {}} {_viewerDocumentsSource [dict get $state dataset_id] [dict get $state sha256]}
    }
}
proc ::GX::_viewerDocumentsRestore {w domains} {
    variable ::GX::ViewerDocuments::forms
    if {![dict exists $domains document_extraction]} return
    _viewerDocumentsRestoreCheck $w $domains
    dict for {form state} [dict get $domains document_extraction] {
        set key [_viewerDocumentsKey $w $form]
        if {[dict get $forms $key pending] ne {}} {scriptJobRequestCancel [dict get $forms $key pending] cancelled;dict set forms $key pending {};dict set forms $key serial [expr {[dict get $forms $key serial]+1}]}
        dict set forms $key state $state
        set text [_viewerDocumentsWidget $w $form text].editor
        $text delete 1.0 end;$text insert 1.0 [dict get $state text];$text edit modified 0
        _viewerDocumentsTableDraw $w $form
        _viewerDocumentsProvenance $w $form
        if {[dict get $state dataset_id] ne {}} {
            foreach field {page dpi zoom} {_viewerDocumentsSet $w $form $field [dict get $state $field]}
            _viewerDocumentsSet $w $form dataset [dict get $state dataset_id]
            after idle [list ::GX::_viewerDocumentsRestoreRender $w $form]
        }
    }
}
proc ::GX::_viewerDocumentsRestoreRender {w form} {
    if {[winfo exists $w]} {catch {_viewerDocumentsStart $w $form render {restore 1}} message}
}
proc ::GX::_viewerDocumentsDispose {w} {
    variable ::GX::ViewerDocuments::forms
    dict for {key row} $forms {
        if {[lindex $key 0] ne $w} continue
        if {[dict get $row photo] ne {}} {catch {image delete [dict get $row photo]}}
        if {[dict get $row pending] ne {}} {
            dict set forms $key disposed 1
            scriptJobRequestCancel [dict get $row pending] closed
        } else {_viewerDocumentsRelease [dict get $row render_allocation];dict unset forms $key}
    }
}
# Source/review state joins the existing typed Workspace/History domain registry.
::GX::nativeWorkspaceShapeRegister document_extraction_state {record {
    dataset_id text sha256 text page int dpi int zoom real roi {array real} text text rows {array {array text}}
    width int height int page_count int text_context {map text} table_context {map text}
}}
::GX::viewerWorkspaceCodecRegister domains document_extraction [list ::GX::_viewerWorkspaceShapeEncode {map {named document_extraction_state}}]
