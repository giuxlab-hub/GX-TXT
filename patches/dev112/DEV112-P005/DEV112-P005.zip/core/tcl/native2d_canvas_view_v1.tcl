# SPDX-License-Identifier: GPL-3.0-or-later
# Trusted native Canvas chrome and existing scheduler/viewport bindings.
proc ::GX::_nativeCanvasGuard {handle} {return [expr {![catch {_nativeCanvasRequire $handle}]}]}
proc ::GX::_nativeCanvasStatus {handle message} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    dict set ::GX::NativeCanvas::instances $handle status $message
    if {[dict exists $row frame] && [winfo exists [dict get $row frame].status]} {
        set status [dict get $row frame].status
        $status configure -text [string map [list "\r" { } "\n" { }] $message]
        native2DViewportTooltip $status $message
    }
}
proc ::GX::_nativeCanvasSafe {handle operation {request {}}} {
    if {[catch {
        _nativeCanvasCancelGesture $handle
        native2DCanvasCommand $handle $operation $request
    } result options]} {
        _nativeCanvasStatus $handle $result
        return [dict create status error message $result]
    }
    _nativeCanvasStatus $handle [string map {_ { }} $operation]
    return $result
}
proc ::GX::_nativeCanvasGestureFinish {handle canceled} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    if {$canceled && [dict exists $::GX::NativeCanvas::instances $handle gesture_history]} {
        dict set ::GX::NativeCanvas::instances $handle history [dict get $::GX::NativeCanvas::instances $handle gesture_history]
    }
    foreach key {gesture_before gesture_history} {catch {dict unset ::GX::NativeCanvas::instances $handle $key}}
}
proc ::GX::_nativeCanvasCancelGesture {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle gesture_before]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    set active [dict get [[dict get $row native] state scalar] gesture]
    [dict get $row native] command cancel {}
    _nativeCanvasGestureFinish $handle $active
}
proc ::GX::_nativeCanvasLifecycle {handle event} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    _nativeCanvasCancelPending $handle
    if {[dict get $row scheduler] ne {}} {guiUpdateSchedulerCancel [dict get $row scheduler]}
    catch {[dict get $row native] command cancel {}}
    _nativeCanvasGestureFinish $handle 1
    _nativeCanvasStatus $handle {Canvas source or Session changed. Reopen the current document.}
}
proc ::GX::_nativeCanvasError {handle args} {_nativeCanvasStatus $handle [lindex $args [expr {[llength $args]>=2?1:0}]]}
proc ::GX::_nativeCanvasDisplayReply {variable response} {set $variable $response}
proc ::GX::_nativeCanvasDisplayInstances {row frameId} {
    # A staged replacement can temporarily share the mounted target's frame.
    # Each prior instance retains its own identity and cancellation sequence.
    set admitted {}
    dict for {handle current} $::GX::NativeCanvas::instances {
        if {[dict get $current native] eq [dict get $row native] || ($frameId ne {} && [dict exists $current frame] && [dict get $current frame] eq [dict get $row frame])} {
            set stamp {}
            foreach key {native document receipt session sequence} {dict set stamp $key [dict get $current $key]}
            dict set stamp frame [datasetPublicationV2DictDefault $current frame {}]
            dict set admitted $handle $stamp
        }
    }
    return $admitted
}
proc ::GX::_nativeCanvasDisplayCurrent {row scene object reference image nativeState view frameId admitted} {
    if {[dict get $row session] ne [interactiveDocumentSessionToken]} {error {Canvas Session changed during display decoding}}
    set owner [interactiveDocumentMetadata [dict get $row document]]
    foreach key {generation revision sha256} {
        if {[dict get $owner $key] ne [dict get $row receipt $key]} {error {Canvas Document changed during display decoding}}
    }
    if {[[dict get $row native] state scalar] ne $nativeState || [::GX::Native2D::core view_state $scene] ne $view || [::GX::Native2D::core image_get $scene $object] ne $image} {error {Canvas presentation changed during display decoding}}
    if {![dict exists $::GX::Native2DRaster::resources $scene $object] || [dict get $::GX::Native2DRaster::resources $scene $object] ne $reference} {error {Canvas original image Resource changed during display decoding}}
    if {$frameId ne {}} {
        set frame [dict get $row frame]
        if {![winfo exists $frame] || [winfo id $frame] ne $frameId} {error {Canvas window closed during display decoding}}
    }
    dict for {handle stamp} $admitted {
        if {![dict exists $::GX::NativeCanvas::instances $handle]} {error {Canvas display admission was cancelled}}
        set current [dict get $::GX::NativeCanvas::instances $handle]
        foreach key {native document receipt session sequence} {
            if {[dict get $current $key] ne [dict get $stamp $key]} {error {Canvas display admission was cancelled}}
        }
        if {[datasetPublicationV2DictDefault $current frame {}] ne [dict get $stamp frame]} {error {Canvas display admission was cancelled}}
    }
    interactiveDocumentResourceInfo $reference
    _nativeCanvasAdmitSources $row
}
proc ::GX::_nativeCanvasDisplayPhoto {row scene object reference path image} {
    # One existing managed auxiliary request and temporary envelope. Only the
    # existing source-keyed Tk photo survives; this file is never scientific.
    set width [expr {wide([dict get $image width])}];set height [expr {wide([dict get $image height])}]
    set pixels [expr {$width*$height}]
    if {$width<1 || $height<1 || $width>16384 || $height>16384 || $pixels>16777216 || [dict get $reference size_bytes]>67108864} {error {Canvas display conversion exceeds its source bounds}}
    set maximum [expr {5*$pixels+65536}]
    set nativeState [[dict get $row native] state scalar]
    set view [::GX::Native2D::core view_state $scene]
    set frameId {}
    if {[dict exists $row frame] && [winfo exists [dict get $row frame]]} {set frameId [winfo id [dict get $row frame]]}
    set admitted [_nativeCanvasDisplayInstances $row $frameId]
    set allocation {};set request {};set photo {}
    set variable ::GX::NativeCanvas::display_reply_[incr ::GX::NativeCanvas::serial]
    set $variable pending
    try {
        set allocation [resourceManagementAllocate native2d_display [dict create category temporary lifetime request retention_seconds 0 session [_interactiveDocumentRequireSession] expected_bytes $maximum]]
        if {![dict get $allocation managed] || [dict get $allocation kind] ne {directory} || [dict get $allocation subsystem] ne {native2d_display} || [dict get $allocation owner_pid] != [pid] || [dict get $allocation path] ne [dict get $allocation envelope]} {error {Invalid Canvas display allocation}}
        set output [file join [dict get $allocation path] display.png]
        set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python native2d_scene_renderer_v1.py] display_png $path $output --width $width --height $height --sha256 [dict get $reference sha256] --allocation-id [dict get $allocation id]]
        set request [scriptJobAsync $command {} [list ::GX::_nativeCanvasDisplayReply $variable] {timeout_ms 30000 max_bytes 65536 process_group 1 ui_lifetime 0 separate_stderr 1 label {Canvas display decoding}}]
        vwait $variable
        set response [set $variable]
        if {![dict get $response ok]} {error [dict get $response error]}
        set result [dict get $response result]
        if {[dict get $result width] != $width || [dict get $result height] != $height || [dict get $result source_sha256] ne [dict get $reference sha256] || [dict get $result representation] ne {display_RGBA8}} {error {Canvas display decoder identity differs}}
        _nativeCanvasDisplayCurrent $row $scene $object $reference $image $nativeState $view $frameId $admitted
        file lstat $output outputInfo
        if {$outputInfo(type) ne {file} || $outputInfo(nlink)!=1 || $outputInfo(size)>$maximum || $outputInfo(size)<33 || $outputInfo(size)!=[dict get $result output_bytes]} {error {Canvas display output exceeds its allocated file bounds}}
        set photo [image create photo -file $output -format png]
        if {[image width $photo]!=$width || [image height $photo]!=$height} {error {Canvas display PNG dimensions differ from source}}
    } on error {message options} {
        if {$photo ne {}} {catch {image delete $photo};set photo {}}
        return -options $options $message
    } finally {
        # Never release an envelope while its helper can still write into it.
        if {$request ne {} && [dict exists $::GX::scriptJobRequests $request]} {
            scriptJobRequestCancel $request cancelled
            vwait $variable
        }
        unset -nocomplain $variable
        if {$allocation ne {}} {
            if {[catch {
                resourceManagementRelease [dict get $allocation id] verified_orphan 0
                resourceManagementCleanup [list [dict get $allocation id]]
            } message options]} {
                if {$photo ne {}} {catch {image delete $photo}}
                return -options $options $message
            }
        }
    }
    return $photo
}
proc ::GX::_nativeCanvasRows {row} {
    set native [dict get $row native]
    set state [$native state scalar];set scene [dict get $state scene]
    set available [dict get $row photos];set photos {};set descriptors {};set created {};set pixels 0
    try {
      _nativeCanvasAdmitSources $row
      foreach descriptor [$native presentation] {
        if {[dict exists $descriptor object]} {
            set object [dict get $descriptor object]
            set image [::GX::Native2D::core image_get $scene $object]
            if {$image ne {}} {
                if {![dict exists $::GX::Native2DRaster::resources $scene $object]} {error {Canvas image has no admitted Resource binding}}
                set reference [dict get $::GX::Native2DRaster::resources $scene $object]
                set key [list [dict get $reference document_id] [dict get $reference owner_generation] [dict get $reference sha256]]
                if {![dict exists $photos $key]} {
                    set cached [expr {[dict exists $available $key] && ![catch {image type [dict get $available $key]}]}]
                    if {!$cached} {
                        set style [::GX::Native2D::core object_style $scene $object]
                        set visible [dict get $style visible]
                        if {$visible && [dict get $style layer]} {set visible [dict get [::GX::Native2D::core layer_info $scene [dict get $style layer]] visible]}
                        if {$visible && [dict exists $descriptor group]} {set visible [dict get [::GX::Native2D::core object_style $scene [dict get $descriptor group]] visible]}
                        if {!$visible} {lappend descriptors $descriptor;continue}
                    }
                    set count [expr {wide([dict get $image width])*wide([dict get $image height])}]
                    if {$count>16777216 || $count>33554432-$pixels} {error {Canvas decoded display photos exceed the native128MiB asset budget}}
                    incr pixels $count
                    if {$cached} {set photo [dict get $available $key]} else {
                        interactiveDocumentResourceInfo $reference
                        set path [_native2DImagePath $scene $object]
                        if {[catch {image create photo -file $path} photo]} {
                            set photo [_nativeCanvasDisplayPhoto $row $scene $object $reference $path $image]
                        }
                        lappend created $photo
                        if {[image width $photo]*[image height $photo]>16777216 || [image width $photo]!=[dict get $image width] || [image height $photo]!=[dict get $image height]} {error {Canvas display raster dimensions exceed admission or differ from source}}
                    }
                    dict set photos $key $photo
                }
                dict set descriptor image [dict create photo [dict get $photos $key] identity [dict get $reference sha256]]
            }
        }
        lappend descriptors $descriptor
      }
      dict set row photos $photos
      return [dict create row $row descriptors $descriptors]
    } on error {message options} {
        foreach photo $created {catch {image delete $photo}}
        return -options $options $message
    }
}
proc ::GX::_nativeCanvasStagePresentation {handle row} {
    set original [_nativeCanvasRequire $handle]
    set frame [dict get $original frame]
    set stage $frame.admission[incr ::GX::NativeCanvas::serial]
    canvas $stage -width 64 -height 64 -highlightthickness 0
    set prepared {}
    try {
        set prepared [_nativeCanvasRows $row]
        native2DSpriteSceneAttach $stage [dict get [[dict get $row native] state scalar] scene]
        native2DSpriteSceneBegin $stage
        native2DSpriteSceneSync $stage [dict get [[dict get $row native] state scalar] scene] [dict get $prepared descriptors] {composition canvas budget 4096}
        native2DSpriteSceneEnd $stage
        return [dict get $prepared row]
    } on error {message options} {
        if {$prepared ne {}} {
            dict for {key photo} [dict get $prepared row photos] {if {![dict exists $original photos $key] || [dict get $original photos $key] ne $photo} {catch {image delete $photo}}}
        }
        return -options $options $message
    } finally {catch {native2DSpriteSceneDispose $stage};destroy $stage}
}
proc ::GX::_nativeCanvasPresent {handle} {
    set row [_nativeCanvasRequire $handle]
    set canvas [dict get $row canvas]
    if {$canvas eq {} || ![winfo exists $canvas]} return
    set prepared [_nativeCanvasRows $row]
    set scene [dict get [[dict get $row native] state scalar] scene]
    try {
        native2DSpriteSceneBegin $canvas [list 0 0 [winfo width $canvas] [winfo height $canvas]]
        native2DSpriteSceneSync $canvas $scene [dict get $prepared descriptors] {composition canvas budget 4096}
        native2DSpriteSceneEnd $canvas
    } on error {message options} {
        dict for {key photo} [dict get $prepared row photos] {if {![dict exists $row photos $key] || [dict get $row photos $key] ne $photo} {catch {image delete $photo}}}
        return -options $options $message
    }
    dict set ::GX::NativeCanvas::instances $handle photos [dict get $prepared row photos]
    set kept [dict values [dict get $prepared row photos]]
    dict for {key photo} [dict get $row photos] {if {$photo ni $kept} {catch {image delete $photo}}}
    _nativeCanvasControlsRefresh $handle
    return {}
}
proc ::GX::_nativeCanvasInput {handle kind data} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    # Idle pointer motion has no scientific work. During multipoint construction
    # the original capture/history spans every click until Return or cancellation.
    if {$kind eq {move} && ![dict exists $::GX::NativeCanvas::instances $handle gesture_before]} return
    if {[catch {
        set row [_nativeCanvasRequire $handle]
        set native [dict get $row native];set canvas [dict get $row canvas]
        if {$kind eq {wheel} && ![_nativeCanvasWorkspacePrepareEdit $handle]} return
        if {$kind in {down move up}} {_nativeCanvasAdmitSources $row}
        if {$kind eq {down} && ![dict exists $row gesture_before]} {
            if {[dict get $row pending] ne {}} {error {Cancel the pending Canvas operation before editing}}
            if {![_nativeCanvasPrepareEdit $handle]} return
            dict set ::GX::NativeCanvas::instances $handle gesture_before [native2DCanvasCapture $handle]
            dict set ::GX::NativeCanvas::instances $handle gesture_history [dict get $row history]
        }
        if {$kind eq {down}} {focus $canvas}
        set receipt [$native event $kind $data]
        if {[datasetPublicationV2DictDefault $receipt committed 0]} {
            _nativeCanvasAccepted $handle {Canvas gesture}
        }
        set committed [datasetPublicationV2DictDefault $receipt committed 0]
        set canceled [datasetPublicationV2DictDefault $receipt canceled 0]
        set provisional [datasetPublicationV2DictDefault $receipt provisional 0]
        if {$committed || $canceled || ($kind in {up key} && !$provisional)} {
            _nativeCanvasGestureFinish $handle [expr {!$committed}]
            guiUpdateSchedulerFinish [dict get $row scheduler]
        } elseif {$provisional} {
            guiUpdateSchedulerRequest [dict get $row scheduler] intensive
        } else {guiUpdateSchedulerRequest [dict get $row scheduler] normal}
        if {[datasetPublicationV2DictDefault $receipt selection_changed 0]} {_nativeCanvasControlsRefresh $handle}
    } message options]} {
        if {[dict exists $::GX::NativeCanvas::instances $handle]} {
            set row [dict get $::GX::NativeCanvas::instances $handle]
            catch {[dict get $row native] command cancel {}}
            if {[dict exists $row gesture_before] && ![catch {_nativeCanvasRequire $handle}]} {
                if {![catch {native2DCanvasRestore $handle [dict get $row gesture_before]}] && [dict exists $row gesture_history] && [dict exists $::GX::NativeCanvas::instances $handle]} {
                    set current [dict get $::GX::NativeCanvas::instances $handle]
                    if {[dict get $current document] eq [dict get $row document] && [dict get $current session] eq [dict get $row session]} {
                        dict set ::GX::NativeCanvas::instances $handle history [dict get $row gesture_history]
                    }
                }
            }
            _nativeCanvasGestureFinish $handle 1
            _nativeCanvasStatus $handle $message
            dict set ::GX::NativeCanvas::instances $handle last_input_error $message
        }
    }
}
proc ::GX::_nativeCanvasResize {handle width height} {
    if {$width<2 || $height<2} return
    _nativeCanvasInput $handle resize [dict create width $width height $height]
}
proc ::GX::_nativeCanvasViewportChanged {handle} {
    if {![dict exists $::GX::NativeCanvas::instances $handle]} return
    set row [dict get $::GX::NativeCanvas::instances $handle]
    if {[dict get $row scheduler] ne {}} {guiUpdateSchedulerRequest [dict get $row scheduler]}
}
proc ::GX::_nativeCanvasDestroyed {handle owner actual} {
    if {$owner eq $actual} {native2DCanvasDispose $handle}
}
proc ::GX::native2DCanvasMount {handle parent {options {}}} {
    package require Tk
    _nativeCanvasFields $options {controls callback} {}
    set row [_nativeCanvasRequire $handle]
    if {![winfo exists $parent]} {error {Canvas parent has closed}}
    if {[dict get $row canvas] ne {}} {error {Canvas is already mounted; create an independent instance}}
    set frame [expr {$parent eq {.}?{.}:"$parent."}]canvas[incr ::GX::NativeCanvas::serial]
    ttk::frame $frame
    set canvas $frame.viewport
    canvas $canvas -width 420 -height 330 -background white -highlightthickness 1 -highlightcolor #087ea4 -takefocus 1
    grid $canvas -row 1 -column 0 -sticky nsew
    grid rowconfigure $frame 1 -weight 1;grid columnconfigure $frame 0 -weight 1
    set instructions {Spline: click knots, Return finishes. Ctrl+drag edits controls; Escape cancels}
    ttk::label $frame.status -text $instructions -width 1 -anchor w -wraplength 0 -takefocus 1
    grid $frame.status -row 2 -column 0 -columnspan 2 -sticky ew
    bind $frame.status <FocusIn> [list ::GX::_native2DViewportTooltipEnter $frame.status]
    bind $frame.status <F1> [list ::GX::_native2DViewportTooltipEnter $frame.status]
    bind $frame.status <FocusOut> [list ::GX::native2DViewportTooltipHide $frame.status]
    set scene [dict get [[dict get $row native] state scalar] scene]
    native2DViewportHostCreate $frame $canvas $scene [list ::GX::_nativeCanvasViewportChanged $handle]
    native2DSpriteSceneAttach $canvas $scene
    [dict get $row native] command configure [dict create presenter [native2DSpriteSceneCreate $canvas]]
    set scheduler [guiUpdateSchedulerCreate $canvas [list ::GX::_nativeCanvasPresent $handle] [dict create profile global policy adaptive guard [list ::GX::_nativeCanvasGuard $handle] error_callback [list ::GX::_nativeCanvasError $handle]]]
    dict set ::GX::NativeCanvas::instances $handle frame $frame
    _nativeCanvasStatus $handle $instructions
    dict set ::GX::NativeCanvas::instances $handle canvas $canvas
    dict set ::GX::NativeCanvas::instances $handle scheduler $scheduler
    dict set ::GX::NativeCanvas::instances $handle callback [datasetPublicationV2DictDefault $options callback {}]
    dict set ::GX::NativeCanvas::instances $handle subscription [interactiveDocumentLifecycleSubscribe [list ::GX::_nativeCanvasLifecycle $handle] $canvas [dict get $row document]]
    foreach {event kind} {<ButtonPress-1> down <Motion> move <B1-Motion> move <ButtonRelease-1> up} {
        bind $canvas $event [list ::GX::_nativeCanvasInput $handle $kind [list position [list %x %y] modifiers %s]]
    }
    bind $canvas <Escape> [list ::GX::_nativeCanvasInput $handle key {key Escape}]
    bind $canvas <Return> [list ::GX::_nativeCanvasInput $handle key {key Return}]
    bind $canvas <Delete> [list ::GX::_nativeCanvasSafe $handle object_delete]
    bind $canvas <Control-z> [list ::GX::_nativeCanvasSafe $handle undo]
    bind $canvas <Control-y> [list ::GX::_nativeCanvasSafe $handle redo]
    bind $canvas <Control-c> [list ::GX::_nativeCanvasSafe $handle copy]
    bind $canvas <Control-x> [list ::GX::_nativeCanvasSafe $handle cut]
    bind $canvas <Control-v> [list ::GX::_nativeCanvasSafe $handle paste]
    bind $canvas <Control-d> [list ::GX::_nativeCanvasSelectedAction $handle object_duplicate]
    bind $canvas <Button-4> [list ::GX::_nativeCanvasInput $handle wheel [list position [list %x %y] delta 120]]
    bind $canvas <Button-5> [list ::GX::_nativeCanvasInput $handle wheel [list position [list %x %y] delta -120]]
    bind $canvas <Configure> +[list ::GX::_nativeCanvasResize $handle %w %h]
    bind $frame <Destroy> +[list ::GX::_nativeCanvasDestroyed $handle $frame %W]
    if {[datasetPublicationV2DictDefault $options controls 1]} {_nativeCanvasControlsCreate $handle $frame}
    pack $frame -fill both -expand 1
    guiUpdateSchedulerRequest $scheduler
    return $handle
}
proc ::GX::_nativeCanvasSelectedAction {handle operation} {
    if {[catch {set description [native2DCanvasDescribe $handle]}]} return
    set objects [dict get $description selection]
    if {![llength $objects]} {_nativeCanvasStatus $handle {Select a visible editable object first};return}
    if {$operation eq {object_ungroup}} {_nativeCanvasSafe $handle $operation [dict create object [lindex $objects 0]]} else {_nativeCanvasSafe $handle $operation [dict create objects $objects]}
}
proc ::GX::_nativeCanvasToolSelected {handle combo} {_nativeCanvasSafe $handle tool_set [dict create tool [$combo get]]}
proc ::GX::_nativeCanvasLayerSelected {handle tree} {
    if {[dict exists $::GX::NativeCanvas::instances $handle updating_controls]} return
    if {![winfo exists $tree]} return
    set selected [$tree selection]
    if {[llength $selected]!=1} return
    if {[catch {
        set row [_nativeCanvasRequire $handle]
        set state [[dict get $row native] state scalar]
        set attributes [::GX::Native2D::core identity_attributes [dict get $state scene] [dict get $state active_layer]]
        set active [dict get $attributes gx.canvas logical_id]
    }]} return
    if {[lindex $selected 0] eq $active} return
    _nativeCanvasSafe $handle layer_select [dict create layer [lindex $selected 0]]
}
proc ::GX::_nativeCanvasLayerProperty {handle property widget} {
    if {[dict exists $::GX::NativeCanvas::instances $handle updating_controls]} return
    if {[catch {set description [native2DCanvasDescribe $handle]}]} return
    set layer [dict get $description active_layer]
    if {$layer eq {}} return
    if {$property eq {blend}} {set request [dict create layer $layer blend [$widget get]]} else {set request [dict create layer $layer properties [dict create $property [$widget get]]]}
    _nativeCanvasSafe $handle layer_update $request
}
proc ::GX::_nativeCanvasLayerOrder {handle step} {
    set description [native2DCanvasDescribe $handle];set active [dict get $description active_layer]
    foreach layer [dict get $description layers] {
        if {[dict get $layer logical_id] eq $active} {_nativeCanvasSafe $handle layer_reorder [dict create layer $active order [expr {[dict get $layer properties order]+$step}]];return}
    }
}
proc ::GX::_nativeCanvasLayerFlag {handle property} {
    if {[dict exists $::GX::NativeCanvas::instances $handle updating_controls]} return
    set description [native2DCanvasDescribe $handle]
    _nativeCanvasSafe $handle layer_update [dict create layer [dict get $description active_layer] properties [dict create $property $::GX::NativeCanvas::ui($handle,$property)]]
}
proc ::GX::_nativeCanvasMergeSelected {handle} {
    set description [native2DCanvasDescribe $handle]
    set layers [lmap layer [dict get $description layers] {dict get $layer logical_id}]
    _nativeCanvasSafe $handle merge [dict create layers $layers target [dict get $description active_layer]]
}
proc ::GX::_nativeCanvasObjectProperty {handle} {
    set row [_nativeCanvasRequire $handle];set frame [dict get $row frame];set pane [dict get $row controls]
    set description [native2DCanvasDescribe $handle]
    set selected [$pane.object_tree selection]
    if {![llength $selected]} {set selected [dict get $description selection]}
    if {[llength $selected]!=1} {_nativeCanvasStatus $handle {Select one native object to edit its properties};return}
    if {[catch {set color [uiFieldColorToRGBA [$pane.object_color get]]} message]} {_nativeCanvasStatus $handle $message;return}
    if {[catch {set alpha [_nativeCanvasNumber [$pane.object_opacity get] 0 1 opacity]} message]} {_nativeCanvasStatus $handle $message;return}
    set color [lreplace $color 3 3 $alpha]
    set request [dict create object [lindex $selected 0] style [dict create color $color]]
    set value [$pane.object_text get]
    if {$value ne {}} {dict set request text [dict create value $value font TkDefaultFont font_size 12 anchor nw]}
    _nativeCanvasSafe $handle object_update $request
}
proc ::GX::_nativeCanvasObjectSelected {handle tree} {
    if {[dict exists $::GX::NativeCanvas::instances $handle updating_controls]} return
    set objects [$tree selection]
    if {[catch {set description [native2DCanvasDescribe $handle]}]} return
    if {[lsort $objects] eq [lsort [dict get $description selection]]} return
    _nativeCanvasSafe $handle selection_set [dict create objects $objects mode replace]
}
proc ::GX::_nativeCanvasObjectFlag {handle property} {
    if {[dict exists $::GX::NativeCanvas::instances $handle updating_controls]} return
    set row [_nativeCanvasRequire $handle];set tree [dict get $row controls].object_tree
    set selected [$tree selection]
    if {[llength $selected]!=1} {_nativeCanvasStatus $handle {Select one object in the object list};return}
    _nativeCanvasSafe $handle object_update [dict create object [lindex $selected 0] style [dict create $property $::GX::NativeCanvas::ui($handle,object_$property)]]
}
proc ::GX::_nativeCanvasControlsCreate {handle frame} {
    ttk::frame $frame.tools
    grid $frame.tools -row 0 -column 0 -columnspan 2 -sticky ew
    ttk::combobox $frame.tools.tool -state readonly -width 9 -values {select line rectangle ellipse arrow text spline translate resize rotate pivot pan}
    $frame.tools.tool set select
    native2DViewportTooltip $frame.tools.tool {Spline: click knots, Enter commits, Escape cancels. Ctrl+drag edits native controls.}
    bind $frame.tools.tool <<ComboboxSelected>> [list ::GX::_nativeCanvasToolSelected $handle $frame.tools.tool]
    grid $frame.tools.tool -row 0 -column 0 -sticky nw
    ttk::frame $frame.tools.actions
    grid $frame.tools.actions -row 0 -column 1 -sticky nsew
    grid columnconfigure $frame.tools 1 -weight 1
    set column 1
    foreach {id label operation} {undo Undo undo redo Redo redo fit Fit fit copy Copy copy paste Paste paste} {
        ttk::button $frame.tools.actions.$id -text $label -width 5 -command [list ::GX::_nativeCanvasSafe $handle $operation]
        grid $frame.tools.actions.$id -row 0 -column [expr {$column-1}] -padx 1;incr column
        native2DViewportTooltip $frame.tools.actions.$id $label
    }
    _uiFieldToolbarAttach $frame.tools.actions 1
    set pane [uiFieldScrollableCreate $frame.inspector 128]
    dict set ::GX::NativeCanvas::instances $handle controls $pane
    grid $frame.inspector -row 1 -column 1 -sticky nsew -padx 3
    ttk::label $pane.title -text Layers
    pack $pane.title -anchor w
    ttk::treeview $pane.tree -show tree -height 5 -selectmode browse
    uiFieldInspectionColumnsFit $pane.tree
    $pane.tree column #0 -width 105 -minwidth 70 -stretch 1
    pack $pane.tree -fill both -expand 1
    bind $pane.tree <<TreeviewSelect>> [list ::GX::_nativeCanvasLayerSelected $handle $pane.tree]
    foreach {property label} {visible Visible locked Locked} {
        set ::GX::NativeCanvas::ui($handle,$property) [expr {$property eq {visible}}]
        ttk::checkbutton $pane.$property -text $label -variable ::GX::NativeCanvas::ui($handle,$property) -command [list ::GX::_nativeCanvasLayerFlag $handle $property]
        pack $pane.$property -anchor w
    }
    ttk::frame $pane.actions
    pack $pane.actions -fill x
    foreach {id label command} [list add + [list ::GX::_nativeCanvasSafe $handle layer_create {name Layer}] up ↑ [list ::GX::_nativeCanvasLayerOrder $handle 1] down ↓ [list ::GX::_nativeCanvasLayerOrder $handle -1]] {
        ttk::button $pane.actions.$id -text $label -width 2 -command $command
        pack $pane.actions.$id -side left
    }
    ttk::label $pane.opacity_label -text {Layer opacity}
    ttk::spinbox $pane.opacity -from 0 -to 1 -increment 0.1 -width 7 -command [list ::GX::_nativeCanvasLayerProperty $handle opacity $pane.opacity]
    bind $pane.opacity <Return> [list ::GX::_nativeCanvasLayerProperty $handle opacity $pane.opacity]
    bind $pane.opacity <FocusOut> [list ::GX::_nativeCanvasLayerProperty $handle opacity $pane.opacity]
    ttk::label $pane.blend_label -text Blend
    ttk::combobox $pane.blend -state readonly -values {Over Multiply Screen Overlay SoftLight} -width 10
    bind $pane.blend <<ComboboxSelected>> [list ::GX::_nativeCanvasLayerProperty $handle blend $pane.blend]
    foreach widget {opacity_label opacity blend_label blend} {pack $pane.$widget -fill x}
    ttk::frame $pane.objects
    pack $pane.objects -fill x -pady 3
    foreach {id label operation} {duplicate Duplicate object_duplicate group Group object_group ungroup Ungroup object_ungroup} {
        ttk::button $pane.objects.$id -text $label -command [list ::GX::_nativeCanvasSelectedAction $handle $operation]
        pack $pane.objects.$id -fill x
    }
    ttk::button $pane.flatten -text Flatten -command [list ::GX::_nativeCanvasSafe $handle flatten]
    pack $pane.flatten -fill x
    ttk::button $pane.merge -text {Merge layers} -command [list ::GX::_nativeCanvasMergeSelected $handle]
    pack $pane.merge -fill x
    ttk::label $pane.object_label -text {Selected object}
    ttk::treeview $pane.object_tree -show tree -height 4 -selectmode extended
    uiFieldInspectionColumnsFit $pane.object_tree
    $pane.object_tree column #0 -width 105 -minwidth 70 -stretch 1
    bind $pane.object_tree <<TreeviewSelect>> [list ::GX::_nativeCanvasObjectSelected $handle $pane.object_tree]
    foreach {property label} {visible {Object visible} locked {Object locked}} {
        set ::GX::NativeCanvas::ui($handle,object_$property) [expr {$property eq {visible}}]
        ttk::checkbutton $pane.object_$property -text $label -variable ::GX::NativeCanvas::ui($handle,object_$property) -command [list ::GX::_nativeCanvasObjectFlag $handle $property]
    }
    ttk::label $pane.object_color_label -text {Stroke RGB}
    ttk::entry $pane.object_color -width 10
    $pane.object_color insert 0 #1565c0
    ttk::spinbox $pane.object_opacity -from 0 -to 1 -increment 0.1 -width 7
    ttk::label $pane.object_opacity_label -text {Object opacity}
    $pane.object_opacity set 1
    ttk::entry $pane.object_text -width 10
    ttk::label $pane.object_text_label -text {Text annotation}
    ttk::button $pane.object_apply -text {Apply properties} -command [list ::GX::_nativeCanvasObjectProperty $handle]
    foreach item {object_label object_tree object_visible object_locked object_color_label object_color object_opacity_label object_opacity object_text_label object_text object_apply} {pack $pane.$item -fill x}
    foreach tree [list $pane.tree $pane.object_tree] {
        foreach event {<Map> <Configure> <<ThemeChanged>>} {bind $tree $event +[list ::GX::_uiFieldComponentTableFontLayout $tree]}
        bind $tree <Destroy> +[list ::GX::_uiFieldComponentTableFontDispose $tree %W]
    }
    # Preserve full-font controls in UI Field's scrollable content, while
    # sharing a compact frame with the scientific viewport.
    bind $pane <Configure> +[list ::GX::_nativeCanvasInspectorWidth $frame.inspector $pane]
    bind $frame <Configure> +[list ::GX::_nativeCanvasInspectorWidth $frame.inspector $pane]
    _nativeCanvasInspectorWidth $frame.inspector $pane
    native2DViewportTooltip $pane.object_color {Object stroke RGB color; opacity is edited separately}
    native2DViewportTooltip $pane.object_text {Text value for a native text annotation; leave empty for geometric objects}
}
proc ::GX::_nativeCanvasInspectorWidth {frame pane} {
    if {![winfo exists $frame.scroll]} return
    set width 128
    foreach child [winfo children $pane] {
        if {[winfo class $child] ne {Treeview}} {set width [expr {max($width,[winfo reqwidth $child])}]}
    }
    set room [winfo width [winfo parent $frame]]
    set allocated [expr {min($width,max(1,int($room/2)-[winfo reqwidth $frame.bar]-6))}]
    if {[$frame.scroll cget -width]!=$allocated} {$frame.scroll configure -width $allocated}
    _uiFieldScrollableHorizontalAttach $frame $width
}
proc ::GX::_nativeCanvasControlsRefresh {handle} {
    set row [_nativeCanvasRequire $handle]
    if {![dict exists $row controls] || ![winfo exists [dict get $row controls].tree]} return
    set frame [dict get $row frame];set pane [dict get $row controls];set tree $pane.tree
    set state [[dict get $row native] state];set active [dict get $state active_layer]
    set signature [list [dict get $row native] [dict get $row receipt revision] [dict get $state tool] [dict get $state layers] $active [dict get $state revision] [dict get $state selected_objects]]
    if {[datasetPublicationV2DictDefault $row controls_signature {}] eq $signature} return
    dict set ::GX::NativeCanvas::instances $handle updating_controls 1
    try {
        $frame.tools.tool set [dict get $state tool]
        set retained {}
        foreach layer [dict get $state layers] {
            set logical [dict get $layer logical_id];lappend retained $logical
            set text [dict get $layer name]
            if {![dict get $layer properties visible]} {append text { (hidden)}}
            if {[dict get $layer properties locked]} {append text { (locked)}}
            if {[$tree exists $logical]} {$tree item $logical -text $text} else {$tree insert {} end -id $logical -text $text}
            $tree move $logical {} end
            if {[dict get $layer id]==$active} {
                $tree selection set $logical
                $pane.opacity set [dict get $layer properties opacity]
                $pane.blend set [dict get $layer blend]
                foreach property {visible locked} {set ::GX::NativeCanvas::ui($handle,$property) [dict get $layer properties $property]}
            }
        }
        foreach item [$tree children {}] {if {$item ni $retained} {$tree delete $item}}
        set retained {};set selected {}
        if {[llength [dict get $state selected_objects]]!=1} {
            $pane.object_color delete 0 end
            $pane.object_opacity set {}
            $pane.object_text delete 0 end
        }
        foreach object [dict get $state objects] {
            set logical [dict get $object logical_id]
            if {$logical eq {}} continue
            lappend retained $logical
            set text [dict get $object kind]
            if {[dict exists $object canvas_metadata name] && [dict get $object canvas_metadata name] ne {}} {set text [dict get $object canvas_metadata name]}
            if {![dict get $object style visible]} {append text { (hidden)}}
            if {[dict get $object style locked]} {append text { (locked)}}
            if {[$pane.object_tree exists $logical]} {$pane.object_tree item $logical -text $text} else {$pane.object_tree insert {} end -id $logical -text $text}
            if {[dict get $object id] in [dict get $state selected_objects]} {lappend selected $logical}
            if {[llength [dict get $state selected_objects]]==1 && [dict get $object id] in [dict get $state selected_objects]} {
                set color [uiFieldColorFromRGBA [dict get $object style color]]
                $pane.object_color delete 0 end;$pane.object_color insert 0 [dict get $color rgb]
                $pane.object_opacity set [dict get $color alpha]
                $pane.object_text delete 0 end
                if {[dict get $object kind] eq {text} && [dict exists $object canvas_metadata text]} {$pane.object_text insert 0 [dict get $object canvas_metadata text]}
                foreach property {visible locked} {set ::GX::NativeCanvas::ui($handle,object_$property) [dict get $object style $property]}
            }
        }
        foreach item [$pane.object_tree children {}] {if {$item ni $retained} {$pane.object_tree delete $item}}
        $pane.object_tree selection set $selected
        dict set ::GX::NativeCanvas::instances $handle controls_signature $signature
    } finally {dict unset ::GX::NativeCanvas::instances $handle updating_controls}
    return {}
}
