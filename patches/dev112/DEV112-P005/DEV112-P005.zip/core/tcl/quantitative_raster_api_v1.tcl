# SPDX-License-Identifier: GPL-3.0-or-later
# Original samples reuse canonical Dataset, Document Resource and Script Job owners.
proc ::GX::quantitativeRasterApiInfo {} {
    return [dict create api_id QUANTITATIVE_RASTER_API_v1 api_version 1 operations {command source_info submit status cancel result histogram_page} canvas_operations {discover submit status cancel result histogram_page map_roi reconnect} provider core.quantitative.raster source_precision original_native_samples spatial_unit source_pixel intensity_unit raw_sample histogram_page_limit 256 encoded_bytes_max 67108864 pixels_max 16777216 metadata_bytes_max 32768 timeout {120 seconds cooperative worker elapsed; blocking calls and memory use existing Script Job guardian policy} unsupported {polygon/source-rotated ROI; nonidentity stored orientation; unqualified formats}]
}
proc ::GX::_quantitativeError {code message} {return -code error -errorcode [list GXTXT QUANTITATIVE $code] $message}
proc ::GX::_quantitativeRecord {shape value} {
    # Public receipts project only declared fields. The shared encoder remains
    # strict about unknown members of existing owner status/output records.
    set projected {}
    foreach key [dict keys [lindex $shape 1]] {dict set projected $key [dict get $value $key]}
    return [nativeWorkspaceEncode $shape $projected]
}
proc ::GX::_quantitativeDatasetStamp {dataset} {
    if {![llength [info commands ::GX::apiCatalogNative]]} {load [file join $::GX::scriptDir core api_catalog libgxtxt_api_catalog[info sharedlibextension]] Gxtxt_api_catalog}
    set location [sessionInspectionDatasetLocation $dataset]
    return [apiCatalogNative digest [list gxtxt.quantitative.source_stamp.v1 [datasetViewerStamp $dataset [dict get $location path]]]]
}
proc ::GX::quantitativeRasterSourceInfo {dataset} {
    if {[datasetField $dataset contract [datasetField $dataset kind {}]] ne {image.raster}} {_quantitativeError SOURCE {A canonical image.raster Dataset is required}}
    set payload [sessionInspectionDatasetPayload $dataset]
    if {[dict get $payload path] eq {}} {_quantitativeError SOURCE {A local canonical original payload is required}}
    if {[file size [dict get $payload path]]>67108864} {_quantitativeError LIMIT {Encoded source exceeds 64 MiB}}
    # Existing native SHA-256 hashes the canonical owner's complete revision;
    # compiled clients receive an opaque identity, never a storage pathname.
    if {![llength [info commands ::GX::apiCatalogNative]]} {load [file join $::GX::scriptDir core api_catalog libgxtxt_api_catalog[info sharedlibextension]] Gxtxt_api_catalog}
    set revision [apiCatalogNative digest [list gxtxt.quantitative.source_revision.v1 [datasetRevisionToken $dataset [_interactiveDocumentRequireSession]]]]
    return [dict create dataset_id $dataset source_sha256 [dict get $payload sha256] source_revision $revision source_stamp [_quantitativeDatasetStamp $dataset]]
}
proc ::GX::_quantitativeProvider {} {
    if {{core.quantitative.raster} in [scientificExecutionDiscover]} return
    set parameters {
        operation {type choice required 1 values {describe pixel statistics histogram}}
        source_resource {type string required 1} source_dataset_id {type string required 1}
        expected_sha256 {type string required 1} request_guard {type string default {}}
        x {type integer default 0 min 0 max 16383} y {type integer default 0 min 0 max 16383}
        width {type integer default 1 min 1 max 16384} height {type integer default 1 min 1 max 16384}
        channels {type string default all} frame {type integer default 0 min 0 max 0}
        histogram_mode {type choice default native values {native bounded}}
        bins {type integer default 256 min 1 max 65536}
        domain_low {type number default 0} domain_high {type number default 256}
    }
    modulePublicApiActivate math.numeric NUMERIC_API_v1
    foreach operation {statistics_summary histogram_summary} {
        if {$operation ni [::GX::NumericAPIv1::listOperations]} {_quantitativeError BACKEND {Public Numeric summary contract is unavailable}}
    }
    # Existing Scientific Execution pins the exact computational dependencies
    # at preparation and verifies them again at admission and worker startup.
    set runtimeFiles {
        core/quantitative_raster_native/gxtxt_quantitative_extract
        plugins/modules/math.numeric/module.ini
        plugins/modules/math.numeric/api/script_bridge_binding.py
        plugins/modules/math.numeric/api/numeric_api_v1.tcl
        plugins/modules/math.numeric/api/operations_v1.tsv
        plugins/modules/math.numeric/api/octave/gxtxt_numeric_v1.m
        plugins/modules/math.numeric/api/octave/gxtxt_numeric_summary_v1.m
        plugins/modules/math.numeric/api/octave/gxtxt_numeric_faithful_native.oct
        core/python/gxtxt/__init__.py
        core/python/gxtxt_script_bridge_server.py
        core/python/gxtxt_scientific_binary_v1.py
        core/python/gxtxt_resource_manager.py
        core/tcl/native_workspace_api_v1.tcl
        core/workspace/libgxtxt_workspace.so
        core/octave/gxtxt_scientific_binary_worker_v1.m
        core/octave/gxtxt_scientific_binary_worker_main_v1.m
        core/octave/util/gxtxt_binary_resource_v1.m
    }
    scientificExecutionRegister core.quantitative.raster [dict create module_id core.quantitative version 1.1.0 worker core/python/gxtxt_quantitative_raster.py tools {quantitative_raster_native} runtime_files $runtimeFiles parameters $parameters]
}
proc ::GX::quantitativeRasterSubmit {document dataset expectedSha expectedRevision reference parameters {guard {}}} {
    set source [quantitativeRasterSourceInfo $dataset]
    if {$expectedSha ne [dict get $source source_sha256] || $expectedRevision ne [dict get $source source_revision]} {_quantitativeError STALE_SOURCE {Canonical source SHA, metadata or schema changed}}
    set owner [interactiveDocumentRead $document]
    interactiveDocumentResourceInfo $reference
    if {[dict get $reference document_id] ne $document || [dict get $reference sha256] ne $expectedSha} {_quantitativeError OWNER {Original source Resource must belong to the declared Document and match canonical SHA}}
    _nativeCanvasFields $parameters {operation x y width height channels frame histogram_mode bins domain_low domain_high} operation
    if {[dict get $parameters operation] ne {describe}} {
        foreach key {x y} {if {![dict exists $parameters $key]} {_quantitativeError ROI {Explicit source-pixel coordinates are required}}}
        if {[dict get $parameters operation] ne {pixel}} {foreach key {width height} {if {![dict exists $parameters $key]} {_quantitativeError ROI {Explicit half-open source rectangle is required}}}}
    }
    if {[datasetPublicationV2DictDefault $parameters histogram_mode native] eq {bounded}} {
        foreach key {bins domain_low domain_high} {if {![dict exists $parameters $key]} {_quantitativeError DOMAIN {Bounded histogram requires explicit bins and domain edges}}}
    }
    _quantitativeProvider
    dict set guard source_stamp [dict get $source source_stamp]
    set parameters [dict merge $parameters [dict create source_resource $reference source_dataset_id $dataset expected_sha256 $expectedSha request_guard $guard]]
    set preparation [scientificExecutionPrepare core.quantitative.raster $parameters {} [dict create node_id local document_id $document expected_revision [dict get $owner revision] dataset_sources [list $dataset]]]
    try {return [scientificExecutionSubmit $preparation]} on error {message options} {catch {scientificExecutionDiscard $preparation};return -options $options $message}
}
proc ::GX::_quantitativeSourcesCurrent {row} {
    _scientificExecutionSourcesCurrent [dict get $row scientific_request source_identities]
    set parameters [dict get $row scientific_request parameters]
    if {[dict get $parameters request_guard source_stamp] ne [_quantitativeDatasetStamp [dict get $parameters source_dataset_id]]} {_quantitativeError STALE_SOURCE {Original canonical file identity changed}}
}
proc ::GX::_quantitativeJob {job {current 1}} {
    set row [_scientificExecutionJob $job]
    if {[dict get $row scientific_request provider_id] ne {core.quantitative.raster}} {_quantitativeError OWNER {Job is not an original-source quantitative operation}}
    if {$current} {
        _quantitativeSourcesCurrent $row
        # File-stat timestamps are only a cheap invalidation hint. Scientific
        # adoption verifies the original payload SHA, including same-second
        # same-size rewrites which leave the persisted descriptor unchanged.
        set parameters [dict get $row scientific_request parameters]
        set payload [sessionInspectionDatasetPayload [dict get $parameters source_dataset_id]]
        if {[dict get $payload sha256] ne [dict get $parameters expected_sha256]} {_quantitativeError STALE_SOURCE {Original canonical payload SHA changed}}
    }
    return $row
}
proc ::GX::quantitativeRasterStatus {job} {
    set row [_quantitativeJob $job 0];set status [scientificExecutionStatus $job]
    set stale [catch {_quantitativeSourcesCurrent $row} diagnostic]
    dict set status source_current [expr {!$stale}]
    dict set status diagnostic [expr {$stale?$diagnostic:{}}]
    set progress [datasetPublicationV2DictDefault $row progress {}]
    set stage [datasetPublicationV2DictDefault $progress stage waiting]
    if {$stage ni {materialize decoder_initialization measurement complete waiting}} {set stage waiting}
    set percent [datasetPublicationV2DictDefault $progress percent 0]
    if {![string is double -strict $percent] || [catch {expr {$percent>=0 && $percent<=100}} valid] || !$valid} {set percent 0}
    dict set status progress_stage $stage
    dict set status progress_percent $percent
    return $status
}
proc ::GX::quantitativeRasterCancel {job} {_quantitativeJob $job 0;scientificExecutionCancel $job;return [quantitativeRasterStatus $job]}
proc ::GX::_quantitativeOutput {job role} {
    set row [_quantitativeJob $job 0]
    if {[dict get $row state] ne {COMPLETED}} {_quantitativeError NOT_COMPLETED {Only COMPLETED quantitative jobs expose measurements}}
    set found {};set outputs [scientificExecutionOutputs $job]
    if {[dict get $outputs validation] ne {validated_structure}} {_quantitativeError OUTPUT {Quantitative output structure was not validated}}
    foreach output [dict get $outputs outputs] {if {[dict get $output role] eq $role} {if {$found ne {}} {_quantitativeError OUTPUT {Duplicate quantitative output role}};set found $output}}
    if {$found eq {}} {_quantitativeError OUTPUT {Required quantitative output is absent}}
    return $found
}
proc ::GX::quantitativeRasterResult {job} {
    set output [_quantitativeOutput $job measurement]
    if {[dict get $output size_bytes]>32768 || [dict get $output format] ne {json}} {_quantitativeError OUTPUT {Measurement exceeds its JSON metadata contract}}
    set page [scientificExecutionReadOutput $job [dict get $output token] 0 32768 [dict get $output source_generation]]
    set typed [nativeWorkspaceJsonDecode [encoding convertfrom utf-8 [binary decode base64 [dict get $page bytes_base64]]]]
    if {[lindex $typed 0] ne {object}} {_quantitativeError OUTPUT {Measurement must be a typed object}}
    set values [lindex $typed 1];set request [dict get [_quantitativeJob $job 0] scientific_request parameters]
    foreach {key parameter} {schema {} source_dataset_id source_dataset_id source_sha256 expected_sha256 operation operation request_guard request_guard} {
        set expected [expr {$key eq {schema}?{gxtxt.quantitative_raster.v1}:[dict get $request $parameter]}]
        if {![dict exists $values $key] || [dict get $values $key] ne [list text $expected]} {_quantitativeError OUTPUT "Measurement identity mismatch: $key"}
    }
    dict set values job_id [list text $job]
    dict set values output_generation [list text [dict get $output source_generation]]
    if {[dict get $request operation] eq {histogram}} {
        set histogram [_quantitativeOutput $job histogram]
        dict set values histogram_output [_quantitativeRecord {record {token text source_generation text size_bytes int}} $histogram]
    }
    _quantitativeJob $job
    return [list object $values]
}
proc ::GX::quantitativeRasterHistogramPage {job token generation offset count} {
    foreach value [list $offset $count] {if {![string is entier -strict $value]} {_quantitativeError PAGE {Histogram offsets/counts must be exact integers}}}
    if {$offset<0 || $count<1 || $count>256} {_quantitativeError PAGE {Histogram pages contain 1..256 ordered counts}}
    set result [quantitativeRasterResult $job];set output [_quantitativeOutput $job histogram]
    if {$token ne [dict get $output token] || $generation ne [dict get $output source_generation] || [dict get $output format] ne {uint64_le}} {_quantitativeError STALE_OUTPUT {Histogram token or output generation changed}}
    set size [dict get $output size_bytes]
    if {$size%8 || $size>524288 || $offset>=$size/8} {_quantitativeError PAGE {Histogram page is outside the fixed count array}}
    set count [expr {min($count,$size/8-$offset)}]
    set page [scientificExecutionReadOutput $job $token [expr {$offset*8}] [expr {$count*8}] $generation]
    set bytes [binary decode base64 [dict get $page bytes_base64]]
    if {[string length $bytes]!=$count*8} {_quantitativeError OUTPUT {Incomplete histogram page}}
    binary scan $bytes cu* octets;set counts {}
    for {set i 0} {$i<[llength $octets]} {incr i 8} {
        set value 0
        for {set b 7} {$b>=0} {incr b -1} {set value [expr {($value<<8)|[lindex $octets [expr {$i+$b}]]}]}
        if {$value>16777216} {_quantitativeError OUTPUT {Histogram count exceeds admitted source pixels}}
        lappend counts [list int $value]
    }
    set fields [lindex $result 1]
    dict set fields histogram_page [list object [dict create token [list text $token] generation [list text $generation] offset [list int $offset] next_offset [list int [expr {$offset+$count}]] total_bins [list int [expr {$size/8}]] counts [list array $counts]]]
    _quantitativeJob $job
    return [list object $fields]
}
proc ::GX::_quantitativeCanvasImage {handle logical} {
    set row [_nativeCanvasRequire $handle];set snapshot [native2DCanvasCapture $handle]
    set item [_nativeCanvasRasterLeaf $snapshot $logical]
    if {![dict exists $item source dataset_id]} {_quantitativeError SOURCE {Quantitation requires a canonical source image, not a display-derived raster}}
    set geometry [dict get $row geometry];set scene [_native2DGeometryRequire $geometry]
    set state [_nativeCanvasIndexedState [_nativeCanvasReconcile $handle]]
    set id [_nativeCanvasLogical $state objects $logical];set token {}
    dict for {candidate entry} [dict get $scene objects] {if {[dict get $entry native]==$id} {set token $candidate;break}}
    if {$token eq {}} {_quantitativeError OWNER {Image is outside this Canvas geometry owner}}
    set image [_native2DRasterImage $scene $token]
    # Keep canonical payload hashing/revision I/O in the managed adapter. The
    # live view checks its existing Dataset stamp and native image binding here;
    # the adapter verifies the complete canonical identity before adoption.
    set dataset [dict get $item source dataset_id]
    set source [dict create dataset_id $dataset source_stamp [_quantitativeDatasetStamp $dataset]]
    return [dict create row $row canvas_id [dict get $snapshot canvas_id] geometry $geometry object_token $token image $image source $source]
}
proc ::GX::_quantitativeCanvasGuard {context logical roi} {
    set row [dict get $context row]
    return [dict create document_id [dict get $row document] canvas_id [dict get $context canvas_id] document_receipt [dict get $row receipt] object $logical image_state [dict get $context image state] roi $roi source_stamp [dict get $context source source_stamp]]
}
proc ::GX::_quantitativeCanvasRoi {context request} {
    if {![dict exists $request roi_id]} {return {}}
    foreach key {x y width height} {if {[dict exists $request $key]} {_quantitativeError ROI {Choose a retained source ROI or an explicit pixel rectangle}}}
    set geometry [native2DGeometryCall [dict get $context geometry] raster_roi_geometry [dict create object_token [dict get $context object_token] roi_id [dict get $request roi_id]]]
    if {![dict get $geometry valid] || [dict get $geometry definition kind] ne {rectangle}} {_quantitativeError UNSUPPORTED_ROI {Only a valid axis-aligned source rectangle is admitted}}
    set points [dict get $geometry canonical_points]
    lassign [lindex $points 0] x0 y0;lassign [lindex $points 1] x1 y1;lassign [lindex $points 2] x2 y2;lassign [lindex $points 3] x3 y3
    if {$y0!=$y1 || $x1!=$x2 || $y2!=$y3 || $x3!=$x0} {_quantitativeError UNSUPPORTED_ROI {A source-rotated ROI cannot be replaced by its bounding box}}
    set state [dict get $context image state]
    # Include every pixel cell intersecting the ROI, clipped to original bounds.
    set x [expr {max(0,wide(floor(min($x0,$x2))))}];set y [expr {max(0,wide(floor(min($y0,$y2))))}]
    set right [expr {min(wide([dict get $state width]),wide(ceil(max($x0,$x2))))}]
    set bottom [expr {min(wide([dict get $state height]),wide(ceil(max($y0,$y2))))}]
    if {$right<=$x || $bottom<=$y} {_quantitativeError ROI {Source ROI has no intersecting pixels}}
    # Presentation-only camera projection must not stale source-pixel results.
    set canonical [dict remove $geometry device_points handles]
    return [dict create geometry $canonical x $x y $y width [expr {wide($right-$x)}] height [expr {wide($bottom-$y)}] roi_id [dict get $request roi_id]]
}
proc ::GX::_quantitativeManagedReply {variable response} {set $variable $response}
proc ::GX::_quantitativeOwnerJson {owner} {
    if {$owner eq {}} {return null}
    return [nativeWorkspaceJsonEncode [_quantitativeRecord {record {pid int process text instance text}} $owner]]
}
proc ::GX::_quantitativeProposedOwner {context} {
    set ownerPid [dict get $context owner_pid]
    set identity [scriptJobCall process_identity $ownerPid]
    if {$identity eq {}} {_quantitativeError OWNER {Quantitative view process has ended}}
    return [dict create pid $ownerPid process $identity instance [dict get $context canvas_instance]]
}
proc ::GX::_quantitativeManagedContext {handle row} {
    set session [_interactiveDocumentRequireSession]
    return [dict create session $session origin [sessionOriginRead $session] document_id [dict get $row document] canvas_id [dict get [[dict get $row native] state scalar] canvas_id] canvas_instance $handle owner_pid [pid]]
}
proc ::GX::_quantitativeAwait {command envelope options} {
    # Existing nonblocking pipes service Tk while the fixed owner performs I/O.
    # This temporary completion variable is not a scheduler or Job registry.
    set variable ::GX::ScientificExecution::quantitative_reply_[incr ::GX::ScientificExecution::serial]
    set $variable pending
    if {[string bytelength $envelope]>65536} {unset $variable;_quantitativeError LIMIT {Managed quantitative request exceeds its finite envelope}}
    try {
        scriptJobAsync $command $envelope [list ::GX::_quantitativeManagedReply $variable] $options
        vwait $variable
        set response [set $variable]
        if {![dict get $response ok]} {
            set code [datasetPublicationV2DictDefault $response code {GXTXT QUANTITATIVE REQUEST}]
            return -code error -errorcode $code [dict get $response error]
        }
        return [dict get $response result]
    } finally {unset -nocomplain $variable}
}
proc ::GX::_quantitativeManagedCall {context operation arguments} {
    set envelope [dict merge $context [dict create operation $operation arguments $arguments]]
    set interpreter [auto_execok tclsh];set group [auto_execok setsid]
    if {$interpreter eq {} || $group eq {}} {_quantitativeError BACKEND {Managed quantitative process-group execution is unavailable}}
    # The owned auxiliary PID is now its actual process-group leader.
    set command [list {*}$group {*}$interpreter [file join $::GX::scriptDir core tcl quantitative_raster_request.tcl] $::GX::scriptDir]
    return [_quantitativeAwait $command $envelope {timeout_ms 120000 max_bytes 262144 process_group 1 ui_lifetime 0 separate_stderr 1 label {Quantitative managed I/O}}]
}
proc ::GX::_quantitativeCancelAdmitted {job} {
    # The caller obtained this exact identity from its trusted submit reply.
    # Use the existing supervisor directly so stale admission cleanup does not
    # wait through another framework bootstrap while the Job starts running.
    return [_quantitativeAwait [scriptJobCommand cancel $job] {} {timeout_ms 30000 max_bytes 262144 process_group 0 ui_lifetime 0 separate_stderr 1 label {Cancel unadopted quantitative Job}}]
}
proc ::GX::_quantitativeCanvasGuardCurrent {handle guard} {
    set context [_quantitativeCanvasImage $handle [dict get $guard object]]
    set roi [dict get $guard roi]
    if {$roi ne {}} {set roi [_quantitativeCanvasRoi $context [dict create roi_id [dict get $roi roi_id]]]}
    if {[dict remove $guard admission_id canvas_instance owner_pid owner_process] ne [_quantitativeCanvasGuard $context [dict get $guard object] $roi]} {_quantitativeError STALE_ROI {Canvas image, Document or source ROI changed}}
}
proc ::GX::quantitativeRasterCanvasCommand {handle operation request} {
    switch -- $operation {
        discover {_nativeCanvasFields $request {object} object}
        map_roi {_nativeCanvasFields $request {object roi_id} {object roi_id}}
        submit {_nativeCanvasFields $request {object roi_id operation expected_sha256 expected_revision x y width height channels frame histogram_mode bins domain_low domain_high} {object operation expected_sha256 expected_revision}}
        status - cancel - result - reconnect {_nativeCanvasFields $request {job_id} job_id}
        histogram_page {_nativeCanvasFields $request {job_id token generation offset count} {job_id token generation offset count}}
        default {_quantitativeError OPERATION {Unknown finite quantitative operation}}
    }
    if {$operation in {status cancel result histogram_page reconnect}} {
        # Lifecycle remains available when a measurement has become stale.
        # Only matching terminal ownership retires the existing pending slot.
        set row [_nativeCanvasRequire $handle 0]
        if {[dict get $row session] ne [interactiveDocumentSessionToken]} {_quantitativeError OWNER {Canvas belongs to another Session lifetime}}
        set job [dict get $request job_id]
        set managedContext [_quantitativeManagedContext $handle $row]
        set reply [_quantitativeManagedCall $managedContext $operation $request]
        set row [_nativeCanvasRequire $handle 0]
        if {[dict get $row session] ne [interactiveDocumentSessionToken]} {_quantitativeError OWNER {Canvas Session changed while reading its Job}}
        set guard [dict get $reply guard];set value [dict get $reply value]
        if {$operation eq {reconnect}} {
            _quantitativeCanvasGuardCurrent $handle $guard
            set owner [dict get $reply owner]
            if {[dict get $reply owner_alive] && ([dict get $owner pid] != [pid] || ([dict get $owner instance] ne $handle && [dict exists $::GX::NativeCanvas::instances [dict get $owner instance]]))} {_quantitativeError OWNER {The previous quantitative Canvas view is still open}}
            set claim [_quantitativeManagedCall $managedContext claim_owner [dict create job_id $job expected_owner [dict get $reply expected_owner]]]
            _quantitativeCanvasGuardCurrent $handle $guard
            return [dict get $claim value]
        }
        if {[dict get $reply state] in {COMPLETED FAILED CANCELLED INTERRUPTED} && [dict get $row pending] ne {} && [dict exists [dict get $row pending] job] && [dict get [dict get $row pending] job] eq $job} {dict set ::GX::NativeCanvas::instances $handle pending {}}
        if {$operation eq {cancel}} {return $value}
        if {$operation eq {status}} {
            if {[dict get [lindex $value 1] source_current] eq {bool 1} && [catch {_quantitativeCanvasGuardCurrent $handle $guard} diagnostic]} {
                set fields [lindex $value 1];dict set fields source_current {bool 0};dict set fields diagnostic [list text $diagnostic];set value [list object $fields]
            }
            return $value
        }
        _quantitativeCanvasGuardCurrent $handle $guard
        return $value
    }
    set row [_nativeCanvasRequire $handle]
    set logical [dict get $request object];set context [_quantitativeCanvasImage $handle $logical]
    set roi [_quantitativeCanvasRoi $context $request]
    if {$operation eq {map_roi}} {return [_quantitativeRecord {record {x int y int width int height int roi_id text}} $roi]}
    if {$operation eq {discover}} {
        set guard [_quantitativeCanvasGuard $context $logical $roi]
        set reply [_quantitativeManagedCall [_quantitativeManagedContext $handle $row] source_info [dict create dataset_id [dict get $context source dataset_id] resource [dict get $context image resource]]]
        _quantitativeCanvasGuardCurrent $handle $guard
        return [_quantitativeRecord {record {dataset_id text source_sha256 text source_revision text}} $reply]
    }
    if {[dict get $row pending] ne {} || [dict get [[dict get $row native] state scalar] gesture]} {_quantitativeError BUSY {Finish or cancel the existing Canvas operation first}}
    set parameters [dict remove $request object roi_id expected_sha256 expected_revision]
    if {$roi ne {}} {foreach key {x y width height} {dict set parameters $key [dict get $roi $key]}}
    set guard [_quantitativeCanvasGuard $context $logical $roi]
    set managedContext [_quantitativeManagedContext $handle $row]
    set sequence [expr {[dict get $row sequence]+1}]
    # Admission identities prevent the supervisor's correct active-request
    # deduplication from aliasing a cancelled request with its replacement.
    dict set guard admission_id [list [pid] [clock clicks] $sequence [incr ::GX::ScientificExecution::serial]]
    set pending [list quantitative_request [list [pid] [clock clicks]]]
    dict set ::GX::NativeCanvas::instances $handle sequence $sequence
    dict set ::GX::NativeCanvas::instances $handle pending $pending
    try {
        set reply [_quantitativeManagedCall $managedContext submit [list [dict get $context source dataset_id] [dict get $request expected_sha256] [dict get $request expected_revision] [dict get $context image resource] $parameters $guard [dict get $row receipt]]]
        set job [dict get $reply job_id]
        if {[catch {
            set current [_nativeCanvasRequire $handle]
            if {[dict get $current sequence]!=$sequence || [dict get $current pending] ne $pending} {_quantitativeError CANCELLED {Quantitative admission was cancelled}}
            _quantitativeCanvasGuardCurrent $handle $guard
        } message options]} {
            catch {_quantitativeCancelAdmitted $job}
            return -options $options $message
        }
        dict set ::GX::NativeCanvas::instances $handle pending [list job $job]
        return [dict get $reply value]
    } on error {message options} {
        if {![info exists reply]} {
            # A managed timeout/transport failure is reported only after its
            # process group is reaped. Recover any committed admission through
            # the existing active Job journal and its unique request guard.
            if {[catch {_quantitativeManagedCall $managedContext cancel_admission [dict create admission_id [dict get $guard admission_id]]} cleanupError]} {append message "\nAdmission cleanup could not be verified: $cleanupError"}
        }
        if {[dict exists $::GX::NativeCanvas::instances $handle] && [dict get $::GX::NativeCanvas::instances $handle pending] eq $pending} {dict set ::GX::NativeCanvas::instances $handle pending {}}
        return -options $options $message
    }
}
proc ::GX::_viewerDevelopmentQuantitativeCommand {window component intent} {
    set row [dict get $::GX::ViewerDevelopment::windows $window]
    if {{command} ni [datasetPublicationV2DictDefault [datasetPublicationV2DictDefault $row quantitative_grants {}] QUANTITATIVE_RASTER_API_v1 {}]} {_quantitativeError CAPABILITY {Quantitative Host capability was not granted}}
    _nativeCanvasFields $intent {operation request} {operation request}
    _viewerGuiSemanticDispatchCheck $window $component
    set lifetime [dict get $row lifetime];set incarnation [winfo id $window]
    set result [quantitativeRasterCanvasCommand [_viewerCanvasHandle $window $component] [dict get $intent operation] [dict get $intent request]]
    if {![winfo exists $window] || [winfo id $window] ne $incarnation || ![dict exists $::GX::ViewerDevelopment::windows $window lifetime] || [dict get $::GX::ViewerDevelopment::windows $window lifetime] ne $lifetime || ![viewerGuiDesignGuard $window]} {_quantitativeError OWNER {Viewer lifetime changed while awaiting quantitative I/O}}
    dict set ::GX::ViewerDevelopment::windows $window quantitative_result $result
}
