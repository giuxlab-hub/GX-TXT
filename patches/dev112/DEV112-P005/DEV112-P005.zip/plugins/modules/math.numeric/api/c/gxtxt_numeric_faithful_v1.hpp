// Public NUMERIC_API_v1 C++17 precision extension, contract version 1.
// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef GXTXT_NUMERIC_FAITHFUL_V1_HPP
#define GXTXT_NUMERIC_FAITHFUL_V1_HPP
#include "gxtxt_numeric_reductions_v1.h"
#include <array>
#include <cstdint>
#include <cmath>
#include <limits>
#include <type_traits>
#include <utility>

namespace gxtxt_numeric_v1 {
constexpr std::size_t summary_max_samples = 16777216;

// Error-free binary64 partials survive sample/block boundaries. No heap or
// caller-owned pointers are retained. Requires round-to-nearest, no fast math.
class faithful_sum {
  std::array<double,64> partials_{};
  std::size_t size_=0;
public:
  gx_numeric_status_v1 push(double value) {
    if(!std::isfinite(value))return GX_NUMERIC_INVALID_V1;
    std::size_t next=0;
    for(std::size_t i=0;i<size_;++i){
      double other=partials_[i];
      if(std::abs(value)<std::abs(other))std::swap(value,other);
      const double high=value+other;
      if(!std::isfinite(high))return GX_NUMERIC_RANGE_V1;
      const double low=other-(high-value);
      if(low)partials_[next++]=low;
      value=high;
    }
    if(next==partials_.size())return GX_NUMERIC_RANGE_V1;
    partials_[next]=value;size_=next+1;return GX_NUMERIC_OK_V1;
  }
  double finish() const {
    if(!size_)return 0;
    std::size_t remaining=size_-1;
    double high=partials_[remaining],low=0;
    while(remaining){
      const double other=partials_[--remaining],previous=high;
      high=previous+other;low=other-(high-previous);
      if(low)break;
    }
    // Preserve half-even rounding when the remaining tail lies on the same
    // side of an exact halfway result. The expansion is ordered by magnitude.
    if(remaining && ((low<0 && partials_[remaining-1]<0) ||
                     (low>0 && partials_[remaining-1]>0))){
      const double twice=low*2,rounded=high+twice;
      if(rounded-high==twice)high=rounded;
    }
    return high;
  }
};

struct float_moments_result {
  std::uint64_t finite_count=0;
  double mean=std::numeric_limits<double>::quiet_NaN();
  double population_stddev=std::numeric_limits<double>::quiet_NaN();
};

// Public native precision primitive. Only sum/mean are new mathematics; SD is
// the existing public residual RMS after centering at the faithful mean.
// Nonfinite samples are omitted; classification belongs to existing Numeric
// masks. Binary64 controls are accepted within the binary32 magnitude domain.
template<class Real>
gx_numeric_status_v1 float_moments(const Real* values,std::size_t count,
                                 float_moments_result* output) {
  static_assert(std::is_floating_point<Real>::value,"floating-point source required");
  if(!output || (count && !values))return GX_NUMERIC_INVALID_V1;
  if(count>summary_max_samples)return GX_NUMERIC_RANGE_V1;
  faithful_sum sum;float_moments_result result;
  for(std::size_t i=0;i<count;++i){
    const double value=static_cast<double>(values[i]);
    if(!std::isfinite(value))continue;
    if(std::abs(value)>std::numeric_limits<float>::max())return GX_NUMERIC_RANGE_V1;
    const auto status=sum.push(value);if(status!=GX_NUMERIC_OK_V1)return status;
    ++result.finite_count;
  }
  if(!result.finite_count){*output=result;return GX_NUMERIC_EMPTY_V1;}
  result.mean=sum.finish()/static_cast<double>(result.finite_count);
  gx_numeric_residual_accumulator_v1 residuals;gx_numeric_residual_init_v1(&residuals);
  for(std::size_t i=0;i<count;++i){
    const double value=static_cast<double>(values[i]);
    if(!std::isfinite(value))continue;
    const auto status=gx_numeric_residual_push_v1(&residuals,value-result.mean);
    if(status!=GX_NUMERIC_OK_V1)return status;
  }
  gx_numeric_residual_result_v1 residual_result;
  const auto status=gx_numeric_residual_finish_v1(&residuals,&residual_result);
  if(status!=GX_NUMERIC_OK_V1)return status;
  result.population_stddev=residual_result.rmse;*output=result;
  return GX_NUMERIC_OK_V1;
}
}
#endif
