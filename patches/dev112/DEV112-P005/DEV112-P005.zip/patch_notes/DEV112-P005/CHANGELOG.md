# DEV112-P005 cumulative changes

The net payload includes the original P001 Viewer catalog/icons, corrected P002 Unified Documents, P003 multilayer Canvas and all delivered P004 layout/functional/version fixes. It applies once to exact DEV112.r2 or upgrades exact delivered P004, with the same final inventory and marker 005. Original releases remain unchanged.

P005 refines the actual Builder source/settings strip and module version to 1.2.0, preserving original scientific handlers and editors. It adds the generic quantitative CORE API, finite restricted C++ Host/SDK admission, managed asynchronous I/O and durable view ownership/reconnect. C++17 original decoding delegates mathematical facts to the existing public Numeric family, extended additively as module 1.65.0. Original sample precision, nonfinite accounting and exact uint64 native-depth histogram pages are explicit.

All historical unaccepted TODO entries remain byte-identical. New owner acceptance remains outstanding. No ORION project, disabled action, user Session, prior release, mandate or live installation is changed. No framework activation or authoritative integration occurs.

Saved-Workspace compatibility uses the existing native Store's additive read-only admission and scoped scientific-child propagation, with no second database, authority, migration or writer unlock. Staged TIFF display admission now validates each prior instance's own sequence while preserving cancellation/disposal/source guards.

The final focused corrections anchor the existing numeric/icon group to the far-right strip edge without changing preview, source bounds, fonts or native minima. The integer summary keeps the existing public mean and delegates population deviation to the existing public residual RMS through a typed C++17 binding. This closes the independently reproduced16M uint16 precision failure at unchanged tolerance. Original failure evidence and earlier frozen artifacts remain preserved.
