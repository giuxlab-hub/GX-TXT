#!/usr/bin/env python3
"""Use the same guarded DEV112-P001 procedure for rollback."""
import subprocess,sys
from pathlib import Path
args=sys.argv[1:]
if '--rollback' not in args and '--check' not in args:args.append('--check')
raise SystemExit(subprocess.call([sys.executable,'-I','-B',str(Path(__file__).with_name('apply.py')),*args]))
