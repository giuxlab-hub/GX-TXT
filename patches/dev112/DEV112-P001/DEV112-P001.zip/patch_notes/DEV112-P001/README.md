# DEV112-P001 — Viewer catalog categories and icons

This patch contains ONLY the completed33-file Viewer presentation delta: nine module.ini descriptors, ten associated existing checksum lists, seven SVG sources and seven PNG runtime assets. All33 postimages are byte-identical to the previously validated original delivery. No module packages, installer transactions, registry changes, CORE/application/scientific code, global version/patch-marker changes or Workspace/API changes are included. DEV112-P001 is identified by its patch_notes metadata; PATCH_LEVEL.txt stays000.

Exact baseline: accepted DEV112.r2 `/srv/gxtxt/releases/dev112/0.9.8.10-dev-112-r2/`, public framework TAR SHA2568fda1fd6e485d9d917adfb08d64991c2403f8faf19ed10f4770565d8afcdbaa0, framework source8e637adff46306b5005297679166c09a1e9d36b8, version0.9.8.10-dev-112/patch000. DEV111 is not a baseline or destination.

Changes: IR and IC reuse spectra / Spectroscopy & Signals; Markdown and Unified Documents reuse images / Imaging & Documents; UML uses Modeling & Diagrams; Crystal and Molecule use Chemistry & Structures. Script Library stays scripts/Scripts; STDERR keeps its category/order. Seven original icons use the existing PNG loader. Existing useful icons are retained. See CHANGE_MANIFEST.md and CHANGED_FILES.txt for exact before/after and all paths.

Keep the ZIP and adjacent SHA256 sidecar. Extract only patch_notes for review; stop the target application/workers before changes. The existing guarded overlay procedure is reused, with conservative full factory-module inventory and registration checks. Independently changed/upgraded/reinstalled target modules, unknown extra module files or newly managed factory targets refuse. Only the33 declared files can be changed. The registry is read for ownership checks and is never written. --stopped is operator acknowledgement, not process detection.

```sh
unzip DEV112-P001.zip 'patch_notes/DEV112-P001/*' -d review
python3 review/patch_notes/DEV112-P001/apply.py FRAMEWORK DEV112-P001.zip --check
python3 review/patch_notes/DEV112-P001/apply.py FRAMEWORK DEV112-P001.zip --apply --stopped
python3 review/patch_notes/DEV112-P001/rollback.py FRAMEWORK DEV112-P001.zip --rollback --stopped
```

Application checks all preimages before writing; rollback restores exact19 original files and removes only14 new assets. Unknown edits/modes/links/collisions refuse. Replacement is atomic per file, not across the whole tree; known before/after states allow interrupted operations to be retried. Reverse later overlapping patches first. Empty added directories may remain. Restart GX-TXT after application or rollback.

Existing actual GUI screenshots, icon scaling and nine activation checks are reused under evidence/. Conversion validation proves all33 implementation files unchanged, isolated application/idempotence/rollback exact, registry byte-identical, and all unrelated framework files unchanged. No GUI/science campaign is repeated.

Known limits: this deliberately refuses independently customized target modules; those require separate owner handling. Script Library keeps its scripts/Scripts metadata, while the pre-existing shared GUI heading remains Scientific Scripting. Four unrelated fallback icons and further catalog proposals remain owner decisions in ADDITIONAL_IMPROVEMENTS.md. Accepted release inventories and original bundled module packages are preserved; future integration refreshes are outside this patch.
