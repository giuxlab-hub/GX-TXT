# Complete Viewer catalog audit (before edits)

Accepted DEV112.r2 public release; 149 module descriptors parsed, 56 Viewer providers. Original requested installation is unavailable; this audit covers every installed Viewer in the accepted public release. Module order drives catalog traversal; viewer sections have no separate supported order field.

| Module / Viewer ID | Display name | Group / title | Order | Icon (module relative) / exists | Proposal |
|---|---|---|---|---|---|
| analysis.octave_script / octave_script_editor | Octave Script Workspace | scripts / Scientific Scripting | 795 | icons/octave_script_editor.png / yes | Preserve |
| analysis.python_script / python_script_editor | Python Script Workspace | scripts / Scientific Scripting | 796 | icons/python_script_editor.png / yes | Preserve |
| viewer.3d_workbench / workbench_3d | 3D Workbench | geometry / 3D & Geometry | 862 | icons/workbench_3d.png / yes | Preserve |
| viewer.circuit_workbench / circuit_workbench | Circuit Workbench | simulation / Simulation & Modeling | 900 | resources/icons/catalog_circuit.png / yes | Preserve |
| viewer.code_dataset / code_dataset | Code Dataset Viewer | documents / Documents | 900 | resources/icons/code_document.png / yes | Preserve |
| viewer.comparison_example / comparison_example | Non-IR Comparison Example | development / Interface Tools | 900 | (fallback) / no | Preserve; see additional findings |
| viewer.crystal_structure / crystal_structure | Crystal Chemistry Viewer | geometry / 3D & Geometry | 859 | icons/crystal_structure.png / yes | semantic_group → chemistry; group_title → Chemistry & Structures |
| viewer.curve_digitizer / curve_digitizer | Curve Digitalizer | images / Imaging & Documents | 840 | icons/curve_digitizer.png / yes | Preserve |
| viewer.curve_viewer / curve_viewer | Curve Viewer | curves / Curves & Digitization | 860 | icons/curve_viewer.png / yes | Preserve |
| viewer.curve_workbench / curve_workbench | Curve Workbench | curves / Curves & Digitization | 861 | icons/curve_workbench.png / yes | Preserve |
| viewer.dataset_curve_fit / dataset_surface_fit | Physical Surface Fit | data / Scientific Data & Mathematics | 862 | icons/dataset_surface_fit.png / yes | Preserve |
| viewer.dataset_curve_fit / dataset_curve_fit | Dataset Curve Fit | data / Scientific Data & Mathematics | 862 | icons/dataset_curve_fit.png / yes | Preserve |
| viewer.dataset_table_next / dataset_table | Dataset Table | documents / Documents | 900 | resources/icons/dataset_table.png / yes | Preserve |
| viewer.dev107_restricted_native3d / development_example | Restricted C++ · real public Native3D | development / Designed Viewers | 900 | resources/icons/catalog_cpp_native3d.png / yes | Preserve |
| viewer.dev107_scientific_xy / scientific_xy | Public scientific XY regression | development / Designed Viewers | 900 | resources/icons/catalog_scientific_xy.png / yes | Preserve |
| viewer.development_workspace / development_workspace | Viewer Development Workspace | development / Interface Tools | 871 | resources/icons/catalog_development_workspace.png / yes | Preserve |
| viewer.document_extractors / generic_ocr | Generic OCR | images / Imaging & Documents | 852 | icons/generic_ocr.png / yes | Preserve |
| viewer.document_extractors / table_extractor | Table Extractor | images / Imaging & Documents | 852 | icons/table_extractor.png / yes | Preserve |
| viewer.electromagnetics / electromagnetics | Electromagnetics Studio | simulation / Simulation & Modeling | 870 | icons/electromagnetics.png / yes | Preserve |
| viewer.electromagnetics_studio / electromagnetics_studio | Electromagnetics Studio | simulation / Simulation & Modeling | 900 | resources/icons/electromagnetics.png / yes | Preserve |
| viewer.engine_3d / engine_3d | Native 3D Engine Viewer | geometry / 3D & Geometry | 854 | icons/engine_3d.png / yes | Preserve |
| viewer.html / html | HTML Dataset Viewer | documents / Documents | 900 | resources/icons/html_document.png / yes | Preserve |
| viewer.ic_chromatograms / ic_chromatograms | IC chromatograms — canonical consultation | scientific / Scientific Data | 900 | (fallback) / no | semantic_group → spectra; group_title → Spectroscopy & Signals; order → 860; icon → resources/icons/catalog_ic_chromatograms.png |
| viewer.interactive_curve_builder / interactive_curve_builder | Interactive Curve Builder | curves / Curves & Digitization | 860 | icons/interactive_curve_builder.png / yes | Preserve |
| viewer.interface_builder / interface_builder | Viewer Interface Builder | development / Interface Tools | 870 | resources/icons/catalog_interface_builder.png / yes | Preserve |
| viewer.ir_spectroscopy / ir_spectroscopy | IR Spectroscopy — Reference Evidence | spectroscopy / Spectroscopy | 900 | resources/icons/xy_plot.png / yes | semantic_group → spectra; group_title → Spectroscopy & Signals; order → 856; icon → resources/icons/catalog_ir_spectroscopy.png |
| viewer.markdown_documents / markdown_documents | Markdown Documents | documents / Documents | 900 | (fallback) / no | semantic_group → images; group_title → Imaging & Documents; order → 853; icon → resources/icons/catalog_markdown_documents.png |
| viewer.mathematics_explorer / mathematics_explorer | Mathematics Explorer | data / Scientific Data & Mathematics | 870 | icons/mathematics_explorer.png / yes | Preserve |
| viewer.molecule_3d / molecule_3d | Molecule Viewer | geometry / 3D & Geometry | 859 | icons/molecule_3d.png / yes | semantic_group → chemistry; group_title → Chemistry & Structures |
| viewer.native_3d / native_3d | Legacy 3D Viewer (Deprecated) | geometry / 3D & Geometry | 855 | icons/native_3d.png / yes | Preserve |
| viewer.nmr_multidimensional / nmr_multidimensional | Multidimensional NMR Viewer | spectra / Spectroscopy & Signals | 859 | icons/nmr_multidimensional.png / yes | Preserve |
| viewer.nmr_reference / nmr_reference | NMR Reference Spectrum Viewer | spectra / Spectroscopy & Signals | 857 | icons/nmr_reference.png / yes | Preserve |
| viewer.nmr_spectrum / nmr_spectrum | NMR Spectrum Viewer | spectra / Spectroscopy & Signals | 858 | icons/nmr_spectrum.png / yes | Preserve |
| viewer.pcb_source_snapshot_inspector / pcb_source_snapshot_inspector | PCB source snapshot inspector | development / Interface Tools | 900 | (fallback) / no | Preserve; see additional findings |
| viewer.pdf_ocr / pdf_ocr | PDF OCR Viewer | images / Imaging & Documents | 845 | icons/pdf_ocr.png / yes | Preserve |
| viewer.pdf_reader / pdf_reader | PDF Reader | documents / Documents | 900 | resources/icons/pdf_document.png / yes | Preserve |
| viewer.reference_library / reference_library | Scientific Reference Library | data / Scientific Data & Mathematics | 852 | icons/reference_library.png / yes | Preserve |
| viewer.replicate_curve_analysis / replicate_consensus | Replicate / Consensus Curves | curves / Curves & Digitization | 866 | icons/replicate_consensus.png / yes | Preserve |
| viewer.scientific_3d_workbench / scientific_3d_workbench | 3D CAD Workbench | geometry / 3D & Geometry | 900 | resources/icons/cad_workbench.png / yes | Preserve |
| viewer.scientific_image_inspector / scientific_image_inspector | Scientific Image Inspector | images / Imaging & Documents | 848 | icons/scientific_image_inspector.png / yes | Preserve |
| viewer.scientific_latex / scientific_latex | Scientific LaTeX Article Workspace | documents / Documents | 900 | resources/icons/latex_article.png / yes | Preserve |
| viewer.scientific_library_manager / scientific_library_manager | Scientific Library Manager | data / Scientific Data & Mathematics | 853 | icons/scientific_library_manager.png / yes | Preserve |
| viewer.scientific_library_workspace / scientific_library_workspace | Scientific Libraries | data / Scientific Data & Mathematics | 900 | resources/icons/scientific_library.png / yes | Preserve |
| viewer.scientific_worksheet / scientific_worksheet | Scientific Worksheet | data / Scientific Data & Mathematics | 865 | icons/scientific_worksheet.png / yes | Preserve |
| viewer.script_library / script_library | Script Library | scripts / Scripts | 900 | (fallback) / no | icon → resources/icons/catalog_script_library.png |
| viewer.section_profile / section_profile | 3D Section / Profile Viewer | geometry / 3D & Geometry | 858 | icons/section_profile.png / yes | Preserve |
| viewer.signal_analysis / signal_analysis | Signal Analysis Viewer | scientific / Scientific Analysis | 860 | icon.png / yes | Preserve |
| viewer.spectral_library / spectral_library | Scientific Spectral Library Viewer | spectra / Spectroscopy & Signals | 850 | icons/spectral_library.png / yes | Preserve |
| viewer.statistical_analysis / statistical_analysis | Statistical Analysis Viewer | scientific / Scientific Analysis | 861 | icon.png / yes | Preserve |
| viewer.stderr_diagnostics / stderr_diagnostics | STDERR Diagnostics Viewer | development / Interface Tools | 900 | (fallback) / no | icon → resources/icons/catalog_stderr_diagnostics.png |
| viewer.table_extractor / table_extractor | Table Extractor | images / Imaging & Documents | 850 | icons/table_extractor.png / yes | Preserve |
| viewer.test_cad_1 / test_cad_1 | TEST CAD 1 — Viewer controls | development / TEST Viewers | 900 | (fallback) / no | Preserve; see additional findings |
| viewer.test_cad_2 / test_cad_2 | TEST CAD 2 — Canvas controls | development / TEST Viewers | 900 | (fallback) / no | Preserve; see additional findings |
| viewer.uml_editor / uml_editor | UML Editor | documents / Documents | 900 | (fallback) / no | semantic_group → modeling; group_title → Modeling & Diagrams; icon → resources/icons/catalog_uml_editor.png |
| viewer.unified_document_extraction / unified_document_extraction | Unified document extraction — preview | documents / Documents | 900 | (fallback) / no | semantic_group → images; group_title → Imaging & Documents; order → 854; icon → resources/icons/catalog_unified_document_extraction.png |
| viewer.xas_spectra / xas_spectra | XAS spectra viewer | spectra / Spectroscopy & Signals | 855 | icons/xas_spectra.png / yes | Preserve |

Empty module icon fields resolve through the existing framework fallback `app/icons/viewer_fallback.png`, which exists. All nonempty module icon references resolve to existing images. Additional grouping/duplicate-title/legacy findings: ADDITIONAL_IMPROVEMENTS.md.
