# Approved changes

| Viewer | Field | Before | After |
|---|---|---|---|
| viewer.ir_spectroscopy | semantic_group | spectroscopy | spectra |
| viewer.ir_spectroscopy | group_title | Spectroscopy | Spectroscopy & Signals |
| viewer.ir_spectroscopy | order | 900 | 856 |
| viewer.ir_spectroscopy | icon | resources/icons/xy_plot.png | resources/icons/catalog_ir_spectroscopy.png |
| viewer.ic_chromatograms | semantic_group | scientific | spectra |
| viewer.ic_chromatograms | group_title | Scientific Data | Spectroscopy & Signals |
| viewer.ic_chromatograms | order | 900 | 860 |
| viewer.ic_chromatograms | icon | (fallback) | resources/icons/catalog_ic_chromatograms.png |
| viewer.markdown_documents | semantic_group | documents | images |
| viewer.markdown_documents | group_title | Documents | Imaging & Documents |
| viewer.markdown_documents | order | 900 | 853 |
| viewer.markdown_documents | icon | (fallback) | resources/icons/catalog_markdown_documents.png |
| viewer.unified_document_extraction | semantic_group | documents | images |
| viewer.unified_document_extraction | group_title | Documents | Imaging & Documents |
| viewer.unified_document_extraction | order | 900 | 854 |
| viewer.unified_document_extraction | icon | (fallback) | resources/icons/catalog_unified_document_extraction.png |
| viewer.uml_editor | semantic_group | documents | modeling |
| viewer.uml_editor | group_title | Documents | Modeling & Diagrams |
| viewer.uml_editor | icon | (fallback) | resources/icons/catalog_uml_editor.png |
| viewer.crystal_structure | semantic_group | geometry | chemistry |
| viewer.crystal_structure | group_title | 3D & Geometry | Chemistry & Structures |
| viewer.molecule_3d | semantic_group | geometry | chemistry |
| viewer.molecule_3d | group_title | 3D & Geometry | Chemistry & Structures |
| viewer.script_library | icon | (fallback) | resources/icons/catalog_script_library.png |
| viewer.stderr_diagnostics | icon | (fallback) | resources/icons/catalog_stderr_diagnostics.png |

Ordering uses existing module `meta.order`: IR (856) sits after XAS (855) and before NMR (857–859), IC (860) after NMR. Markdown (853) and extraction (854) follow imaging/OCR/table tools (840–852). Other orders remain unchanged, including STDERR (900) and Script Library (900). Existing molecular/crystal icons are retained.

The old IR XY icon is retained on disk because packaged designs may use it; only the catalog icon reference changes. No algorithms, design files, public APIs, IDs or Workspace contracts change.
