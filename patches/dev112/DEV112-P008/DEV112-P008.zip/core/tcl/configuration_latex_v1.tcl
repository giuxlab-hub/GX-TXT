# SPDX-License-Identifier: GPL-3.0-or-later
# Read-only TeX environment presentation under existing Configuration authority.
namespace eval ::GX::LatexEnvironment {variable generation 0;variable request {};variable inventory {};variable search {};variable lookupQuery {};variable subscription {};variable status {Refresh to inspect installed TeX tools and resources.}}
proc ::GX::latexEnvironmentPanelBuild {parent row} {
    set p $parent.latex
    ttk::labelframe $p -text {Local LaTeX environment — read-only} -padding 8
    grid $p -row $row -column 0 -columnspan 4 -sticky nsew -padx 8 -pady 8
    ttk::button $p.refresh -text {Refresh LaTeX environment} -command ::GX::latexEnvironmentRefresh
    ttk::button $p.cancel -text Cancel -command ::GX::latexEnvironmentCancel
    ttk::entry $p.search -textvariable ::GX::LatexEnvironment::search
    ttk::button $p.locate -text {Locate filename (kpsewhich)} -command ::GX::latexEnvironmentLookup
    ttk::label $p.status -textvariable ::GX::LatexEnvironment::status -wraplength 900
    ttk::treeview $p.items -columns {kind version location status} -show {tree headings} -height 12
    $p.items heading #0 -text {Tool / package / class / font}
    foreach {id title} {kind Kind version Version location Location status Status} {$p.items heading $id -text $title;$p.items column $id -width 170 -stretch 1}
    ttk::scrollbar $p.vertical -command [list $p.items yview]
    ttk::scrollbar $p.horizontal -orient horizontal -command [list $p.items xview]
    $p.items configure -yscrollcommand [list $p.vertical set] -xscrollcommand [list $p.horizontal set]
    grid $p.refresh -row 0 -column 0 -sticky w;grid $p.cancel -row 0 -column 1 -sticky w
    grid $p.search -row 0 -column 2 -sticky ew;grid $p.locate -row 0 -column 3 -sticky e
    grid $p.status -row 1 -column 0 -columnspan 4 -sticky ew
    grid $p.items -row 2 -column 0 -columnspan 3 -sticky nsew;grid $p.vertical -row 2 -column 3 -sticky ns
    grid $p.horizontal -row 3 -column 0 -columnspan 3 -sticky ew
    grid columnconfigure $p 2 -weight 1;grid rowconfigure $p 2 -weight 1
    trace add variable ::GX::LatexEnvironment::search write ::GX::_latexEnvironmentSearch
    set ::GX::LatexEnvironment::subscription [configurationSubscribe ::GX::_latexEnvironmentConfigurationChanged]
    bind $p <Destroy> [list ::GX::_latexEnvironmentDestroyed $p %W]
}
proc ::GX::_latexEnvironmentDestroyed {parent actual} {
    if {$parent ne $actual} return
    latexEnvironmentCancel
    trace remove variable ::GX::LatexEnvironment::search write ::GX::_latexEnvironmentSearch
    if {$::GX::LatexEnvironment::subscription ne {}} {configurationUnsubscribe $::GX::LatexEnvironment::subscription;set ::GX::LatexEnvironment::subscription {}}
}
proc ::GX::latexEnvironmentCancel {} {
    incr ::GX::LatexEnvironment::generation
    set ::GX::LatexEnvironment::lookupQuery {}
    if {$::GX::LatexEnvironment::request ne {}} {catch {scriptJobRequestCancel $::GX::LatexEnvironment::request};set ::GX::LatexEnvironment::request {};set ::GX::LatexEnvironment::status {TeX diagnostic cancelled. Previous inventory observations retained.}}
}
proc ::GX::latexEnvironmentLookup {} {
    latexEnvironmentCancel
    set query [string trim $::GX::LatexEnvironment::search]
    if {[string length $query]>200 || ![regexp -nocase {^[A-Za-z0-9][A-Za-z0-9_.+-]*\.(sty|cls|bst|bib|tfm|otf|ttf|tex|def|cfg|fd|map|enc)$} $query]} {
        set ::GX::LatexEnvironment::status {Enter one exact resource filename in Search, for example amsmath.sty or article.cls. No paths, options or wildcards.}
        return
    }
    try {
        set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_latex_environment.py] --query $query]
        set ::GX::LatexEnvironment::lookupQuery $query
        set ::GX::LatexEnvironment::status "Locating $query through kpsewhich (bounded read-only query)…"
        set ::GX::LatexEnvironment::request [scriptJobAsync $command {} [list ::GX::_latexEnvironmentLocated $::GX::LatexEnvironment::generation $query] {timeout_ms 10000 max_bytes 1048576 process_group 1 ui_lifetime 1 label {Targeted TeX resource lookup}}]
    } on error {message options} {
        set ::GX::LatexEnvironment::lookupQuery {}
        set ::GX::LatexEnvironment::request {}
        set ::GX::LatexEnvironment::status "Targeted TeX lookup unavailable: $message"
    }
}
proc ::GX::_latexEnvironmentLocated {generation query response} {
    if {$generation!=$::GX::LatexEnvironment::generation || $query ne [string trim $::GX::LatexEnvironment::search]} return
    set ::GX::LatexEnvironment::request {};set ::GX::LatexEnvironment::lookupQuery {}
    if {![dict get $response ok]} {set ::GX::LatexEnvironment::status [dict get $response error];return}
    set result [dict get $response result]
    _latexEnvironmentSearch
    set tree .top.nb.configuration.sections.scripts.latex.items
    if {![winfo exists $tree]} return
    $tree insert {} 0 -id targeted -text $query -values [list {targeted kpsewhich} {} [dict get $result location] [dict get $result status]]
    append ::GX::LatexEnvironment::status " Targeted lookup: $query — [dict get $result status]. [dict get $result message]."
}
proc ::GX::latexEnvironmentRefresh {} {
    latexEnvironmentCancel
    # Machine Configuration inventory has no Session or Document dependency.
    # Report missing runtimes/launch failures in the existing panel as well.
    try {
        set executable [runtimeToolResolve latex]
        set command [list [runtimeToolRequired python] -B [file join $::GX::scriptDir core python gxtxt_latex_environment.py] --configured $executable]
        set ::GX::LatexEnvironment::status {Inspecting native TeX versions/search roots and installed resources…}
        set generation $::GX::LatexEnvironment::generation
        set ::GX::LatexEnvironment::request [scriptJobAsync $command {} [list ::GX::_latexEnvironmentRefreshed $generation $executable] {timeout_ms 60000 max_bytes 8388608 process_group 1 ui_lifetime 1 label {Read-only LaTeX environment}}]
    } on error {message options} {
        set ::GX::LatexEnvironment::request {}
        set ::GX::LatexEnvironment::status "LaTeX environment unavailable: $message"
    }
}
proc ::GX::_latexEnvironmentRefreshed {generation executable response} {
    if {$generation!=$::GX::LatexEnvironment::generation} return
    set ::GX::LatexEnvironment::request {}
    if {[catch {runtimeToolResolve latex} current] || $current ne $executable} {
        set ::GX::LatexEnvironment::inventory {}
        _latexEnvironmentSearch
        set ::GX::LatexEnvironment::status {LaTeX runtime changed. Refresh its environment inventory.}
        return
    }
    if {![dict get $response ok]} {set ::GX::LatexEnvironment::status [dict get $response error];return}
    set ::GX::LatexEnvironment::inventory [dict get $response result]
    _latexEnvironmentSearch
}
proc ::GX::_latexEnvironmentConfigurationChanged {id} {
    if {$id ne {runtime.latex}} return
    latexEnvironmentCancel
    set ::GX::LatexEnvironment::inventory {}
    _latexEnvironmentSearch
    set ::GX::LatexEnvironment::status {LaTeX runtime changed. Refresh its environment inventory.}
}
proc ::GX::_latexEnvironmentSearch {args} {
    set tree .top.nb.configuration.sections.scripts.latex.items
    if {![winfo exists $tree]} return
    if {$::GX::LatexEnvironment::lookupQuery ne {} && $::GX::LatexEnvironment::lookupQuery ne [string trim $::GX::LatexEnvironment::search]} {latexEnvironmentCancel}
    $tree delete [$tree children {}]
    if {$::GX::LatexEnvironment::inventory eq {}} {set ::GX::LatexEnvironment::status {No inventory loaded. Refresh the inventory or locate one exact resource filename.};return}
    set search [string tolower $::GX::LatexEnvironment::search];set shown 0;set matched 0
    foreach item [dict get $::GX::LatexEnvironment::inventory entries] {
        if {$search ne {} && [string first $search [string tolower $item]]<0} continue
        incr matched
        if {$shown>=500} continue
        $tree insert {} end -text [dict get $item name] -values [list [dict get $item kind] [dict get $item version] [dict get $item location] [dict get $item status]]
        incr shown
    }
    set ::GX::LatexEnvironment::status "$shown of $matched matching observations in the scanned subset; [dict get $::GX::LatexEnvironment::inventory total] inventoried. [expr {[dict get $::GX::LatexEnvironment::inventory truncated] ? {Incomplete inventory (bound reached); zero matches do not establish absence. Use Locate filename for an exact resource query.} : {Use Locate filename to query an exact resource outside this inventory.}}] Resource presence is not compilation acceptance."
}
