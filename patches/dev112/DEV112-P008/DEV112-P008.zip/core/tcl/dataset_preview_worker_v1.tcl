#!/usr/bin/env tclsh
# SPDX-License-Identifier: GPL-3.0-or-later
# Fixed trusted managed-cache worker. Payload is dictionary data, never script.
namespace eval ::GXPreviewWorker {variable diagnostics {}}
rename ::puts ::GXPreviewWorker::originalPuts
proc ::puts {args} {
    set rest $args;set newline 1
    if {[lindex $rest 0] eq "-nonewline"} {set newline 0;set rest [lrange $rest 1 end]}
    if {[llength $rest]==1} {set channel stdout;set message [lindex $rest 0]
    } elseif {[llength $rest]==2} {lassign $rest channel message
    } else {tailcall ::GXPreviewWorker::originalPuts {*}$args}
    if {$channel ni {stdout stderr}} {tailcall ::GXPreviewWorker::originalPuts {*}$args}
    if {[string bytelength $message]>8192} {set message [string range $message end-1023 end]}
    append ::GXPreviewWorker::diagnostics $message
    if {$newline} {append ::GXPreviewWorker::diagnostics \n}
    if {[string bytelength $::GXPreviewWorker::diagnostics]>8192} {set ::GXPreviewWorker::diagnostics [string range $::GXPreviewWorker::diagnostics end-1023 end]}
    return
}
# Receipt persistence stays in the original Dataset transaction/metadata owner.
# The exact accepted configuration is a CAS pin, never caller write content.
proc ::GXPreviewWorker::receiptSessionCurrent {request} {
    set session [dict get $request session]
    set expected [dict get $request session_instance]
    file stat $session observed
    if {[llength $expected]!=3 || $session ne [file normalize $session] ||
        [list $session $observed(dev) $observed(ino)] ne $expected} {
        error {Preview receipt belongs to a replaced Session directory}
    }
}
proc ::GXPreviewWorker::receiptCommit {request} {
    receiptSessionCurrent $request
    set id [dict get $request dataset_id];set key [dict get $request expected_key]
    set current [::GX::datasetPreviewConfigurationRead $id]
    if {$current ne [dict get $request expected_saved]} {
        return [dict create dataset_id $id key $key persisted 0 reason configuration_changed]
    }
    ::GX::sessionInspectionDatasetPayload $id $::GX::currentSession
    if {[::GX::datasetPreviewCacheKey $id [dict get $request options]] ne $key} {error {Preview source or settings changed before receipt persistence}}
    set prepared [::GX::datasetPreviewCacheRead $id $key]
    if {$prepared eq {} || ![dict get $prepared current]} {error {Accepted Preview representation is absent, damaged or stale}}
    set persisted [::GX::_datasetPreviewLivePersistReceipt $id [::GX::interactiveDocumentSessionToken] $prepared]
    set after [::GX::datasetPreviewConfigurationRead $id]
    return [dict create dataset_id $id key $key persisted $persisted saved_before $current saved_after $after]
}
set status [catch {
    if {[llength $argv]!=1} {error {Preview worker needs its matching framework root}}
    set framework [file normalize [lindex $argv 0]]
    if {$framework ne [file normalize [file join [file dirname [info script]] .. ..]]} {error {Preview worker framework identity mismatch}}
    fconfigure stdin -encoding binary -translation binary
    set raw [read stdin 1048577]
    if {[string length $raw]>1048576 || ![eof stdin]} {error {Preview worker request exceeds1MiB}}
    set request [encoding convertfrom utf-8 $raw]
    if {[encoding convertto utf-8 $request] ne $raw} {error {Preview worker request is not canonical UTF-8}}
    if {[catch {dict size $request}]} {error {Preview worker request must be a dictionary}}
    foreach key {schema session dataset_id options expected_key} {if {![dict exists $request $key]} {error "Preview worker request needs $key"}}
    set pageMode [expr {[dict get $request schema] eq {gxtxt.preview_page_worker.v1}}]
    set receiptMode [expr {[dict get $request schema] eq {gxtxt.preview_receipt_worker.v1}}]
    foreach key [dict keys $request] {if {$key ni {schema session dataset_id options expected_key preview_activation page_options expected_saved session_instance}} {error "Unknown Preview worker request field '$key'"}}
    if {!$pageMode && !$receiptMode && [dict get $request schema] ne "gxtxt.preview_worker.v1"} {error {Unsupported Preview worker request version}}
    if {$pageMode && ![dict exists $request page_options]} {error {Preview page worker requires page_options}}
    if {!$pageMode && [dict exists $request page_options]} {error {Full Preview request cannot contain page_options}}
    if {$receiptMode} {
        foreach field {expected_saved preview_activation session_instance} {if {![dict exists $request $field]} {error "Preview receipt worker needs $field"}}
        dict size [dict get $request expected_saved]
    } elseif {[dict exists $request expected_saved] || [dict exists $request session_instance]} {error {Only receipt requests may pin saved Preview configuration or Session instance}}
    set session [dict get $request session]
    if {[file pathtype $session] ne "absolute" || ![file isdirectory $session] || ![file isfile [file join $session metadata manifest.ini]]} {error {Preview worker needs an existing canonical Session}}
    if {$receiptMode} {::GXPreviewWorker::receiptSessionCurrent $request}
    if {![regexp {^[a-f0-9]{64}$} [dict get $request expected_key]]} {error {Preview worker needs an exact cache key}}
    dict size [dict get $request options]
    set ::env(GXTXT_PREVIEW_WORKER) 1
    set argv0 __gxtxt_preview_worker__
    # This metadata-only actor needs the existing native Workspace reader,
    # while legacy Dataset metadata commits retain their Dataset authority.
    set priorWorkspaceExists [info exists ::env(GXTXT_NATIVE_WORKSPACE_ACCESS)]
    if {$priorWorkspaceExists} {set priorWorkspace $::env(GXTXT_NATIVE_WORKSPACE_ACCESS)}
    try {
        if {$receiptMode} {set ::env(GXTXT_NATIVE_WORKSPACE_ACCESS) read_only}
        source [file join $framework gxtxt_pipeline.tcl]
    } finally {
        if {$receiptMode} {
            if {$priorWorkspaceExists} {set ::env(GXTXT_NATIVE_WORKSPACE_ACCESS) $priorWorkspace
            } else {unset -nocomplain ::env(GXTXT_NATIVE_WORKSPACE_ACCESS)}
        }
    }
    if {![llength [info commands ::GX::datasetPreviewNativeEnsure]]} {
        source [file join $framework core tcl dataset_preview_provider_v1.tcl]
        source [file join $framework core tcl dataset_preview_native_v1.tcl]
    }
    ::GX::defaults;::GX::loadModuleCatalog
    set ::GX::currentSession [file normalize $session]
    ::GX::loadManifest [file join $session metadata manifest.ini]
    set ::GX::currentSession [file normalize $session]
    ::GX::loadDatasetRegistry $session
    if {[dict exists $request preview_activation]} {::GX::_datasetPreviewActivationApply [dict get $request preview_activation]}
    # TASK210's existing native adapter belongs to the fixed worker bootstrap,
    # independently of whether discovery happened to query a Preview component.
    # This loads the bridge only; providers still require normal Module/package
    # admission. Keep the existing CORE route if the optional bridge cannot load.
    if {[catch {::GX::datasetPreviewNativeEnsure} nativeError]} {
        puts stderr "Native Preview adapter unavailable; using CORE fallback: $nativeError"
    }
    set id [::GX::datasetPublicationV2ValidateId dataset [dict get $request dataset_id]]
    if {$receiptMode} {
        if {[llength [info commands ::tk]] || [llength [info commands ::winfo]]} {error {Preview receipt persistence requires the headless owner}}
        set result [::GX::datasetAuthorityTransaction $session ::GXPreviewWorker::receiptCommit $request]
    } elseif {$pageMode} {
        set prepared [::GX::datasetPreviewCachedPageGenerate $id [dict get $request page_options] [dict get $request expected_key] [dict get $request options]]
        set result [dict create key [dict get $prepared key] dataset_id $id status ready page 1]
    } else {
        set prepared [::GX::datasetPreviewCacheGenerate $id [dict get $request options] [dict get $request expected_key]]
        set result [dict create key [dict get $prepared key] dataset_id $id status ready kind [dict get $prepared kind]]
    }
} message options]
if {$status} {
    if {[string length $message]>4096} {set message "[string range $message 0 4095]…"}
    set response [dict create ok 0 error $message]
} else {set response [dict create ok 1 result $result]}
if {$::GXPreviewWorker::diagnostics ne {}} {dict set response diagnostic_tail $::GXPreviewWorker::diagnostics}
::GXPreviewWorker::originalPuts stdout $response
exit [expr {$status?1:0}]
