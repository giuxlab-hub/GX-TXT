# GX-TXT DEV112-P008 cumulative delivery

Version 0.9.8.10-dev-112, patch 008. Exact source: f691b0f6e1016cb9af3db30ba3d1c8b5ea91429c.
This delivery preserves all accepted functionality through P007 and accounts for
all 52 owner-authorized requirements:22 original,29 supplementary Y, and J008.
The single ACCEPTANCE_MATRIX.json records original IDs, accepted-P007 evidence,
necessary corrections, no-change/environment dispositions and both independent
validation domains. Historical behavior already correct in P007 is not claimed
as a P008 code fix.

Plugin Manager now owns the existing default package chooser folder preference
with Browse, explicit Save directory and coherent unsaved Close/reopen behavior.
Configuration→Modules→Viewers has interactive view-only Search viewers with
Reset, empty-result feedback, visible-selection guards and preserved controls.
The other changes are verified conditional corrections and presentation clarity
through existing authoritative owners, not new scientific or management systems.

The installable ZIP is DEV112-P008.zip. The complete DEV112-P008-delivery.zip
contains installation/rollback instructions, exact source and file inventory,
SHA256 checksums, the 52-entry matrix, MAIN/subagent summaries, independent GUI
and technical/release results, supporting evidence and reproducible scoped tools.
Use INSTALLAZIONE.md (English) for commands. Final acceptance is bound to exact
source, patch and delivery ZIP bytes by the detached FINAL_ACCEPTANCE.json.

J010, J019, J023 and J040 remain deferred. Group C / P007-GUI-016, MCP Server,
HTML Guides installation infrastructure, Scientific LaTeX public API work,
shared Python/Octave editor APIs and unrelated features remain outside P008.
The supplementary bounded TeX diagnostic is not the excluded public API project.
Normal final catalog provenance generation reuses existing release infrastructure;
it does not implement the deferred J023 investigation. ORION and SII are frozen.
The owner's working installation and real scientific data remain unchanged.

`DEV112-P008-source.bundle` preserves the exact Git delta; it requires accepted
P007 commit a10f5a99fdab93e251efe9c415d5ad76d14c5259. The cumulative installer
works independently of Git.
