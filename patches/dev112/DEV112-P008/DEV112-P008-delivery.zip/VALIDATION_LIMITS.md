# P008 validation scope and retained behavior

Final acceptance covers the 52 authorized requirements on the exact final
source and package bytes. GUI validation used real mapped GX-TXT windows,
framebuffer screenshots, native keyboard interaction, and ordinary and compact
window sizes. Technical validation separately covered state and transaction
semantics, affected regressions, public APIs, scientific/source integrity,
security refusals and four direct cumulative installation/rollback routes.
The attached reports identify concrete evidence and any retained earlier check
whose applicability was established by final byte identity.

The Linux validation does not claim a Windows desktop campaign or an actual
physical print. Print availability and refusal were tested through the existing
CUPS/document owners. Python inventory classification distinguishes platform
applicability from runtime import failure without installing optional packages.
No real owner Session, scientific data or working installation was modified.

The pre-existing blank module 3D aspect Save behavior requires an explicit
inherit choice. It was reproduced on P007 and retains its established validation
contract; P008 does not change that unrelated rule. Corrected 3D draft, reachability
and transaction requirements have their own passing evidence.

Comprehensive Plot 2D/3D GUI verification (P007-GUI-016), J010, J019, J023 and
J040 remain excluded. Normal catalog provenance checks do not implement J023.
MCP Server, HTML Guides installation infrastructure, Scientific LaTeX public API
and shared Python/Octave editor API projects remain deferred. ORION and SII
remain frozen. The bounded diagnostic/guide corrections in P008 do not expand
those projects.

The installer preserves the established per-file atomic replacement model.
It does not claim a whole-tree transaction or automatic recovery of interrupted
mixed trees. Exact target identity, filesystem protections and authenticated
receipts remain mandatory. Installation commands and recovery limits are in
INSTALLAZIONE.md. These limits are disclosed behavior, not unresolved P008
acceptance requirements.
