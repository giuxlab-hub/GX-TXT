# P008 public API and ownership contracts

Source:f691b0f6e1016cb9af3db30ba3d1c8b5ea91429c.
P008 preserves existing public function signatures, settings keys, package and
Viewer identities, scientific data formats and ownership. New GUI helpers are
presentation-local. No new package preference key, activation API, execution
service, registry or scientific data contract is introduced.

`plugins.package_chooser_directory` remains user-scoped Configuration owned.
Its saved value controls only the initial ZIP/INI folder; configured/home/current
fallback and Plugin Install/Update execution are unchanged. Viewer Manager and
tile searches alter visible records only. Neither search changes module flags,
Viewer preferences, Registry, Workspace or saved configuration.

Readiness uses the existing canonical Dataset source validator. UIField retains
its normal normalization and committed-baseline semantics. Existing parameter
refusal, document navigation, CUPS verification, resource ownership and filesystem
security remain authoritative. Genuine runtime import failures remain distinct
from static inventory uncertainty and platform/optional diagnostics.

The installer's four baseline inventories and source manifest bind exact bytes
and modes. Independent runtime and package evidence qualifies compatibility;
final API catalog generation uses the existing trusted packaging owner, with
public declarations compared against accepted P007. API development projects
outside the owner-authorized scope remain deferred.
