# P008 CORE reuse and compatibility audit

Source:f691b0f6e1016cb9af3db30ba3d1c8b5ea91429c.
Configuration remains the owner of user preferences, transactions, conflict
checks and persistence. Plugin Install retains package execution and destination
semantics; Viewer Provider retains activation/launch behavior. Searches project
existing records only. Workspace/Storage owners resolve effective paths without
migrating scientific Sessions. Existing source validation supplies readiness
feedback; no scheduler or scientific validator is introduced.

UIField supplies integer feedback and typed Print baselines. Existing Plot
validation and font/legend conversion helpers serve genuine dialog drafts;
public callback signatures and numerical rules are preserved. Existing preview
identity/signature and SourceSurface styling owners handle stale presentation.
Existing document/parameter/Print/CUPS owners retain their contracts and guards.
Resource diagnostics retain secure ownership/permissions and cleanup boundaries.
Python and TeX inventory owners provide bounded diagnostic classification/search;
optional packages are never installed automatically. The receipt/preimage/apply
and rollback infrastructure is adapted cumulatively, not replaced.

Public compatibility is checked through independent affected-owner functional
checks, source comparison and catalog declarations. Source policies are not
used as a substitute for runtime validation. No withdrawn pre-implementation API
inventory requirement is asserted. Frozen ORION/SII, scientific datasets and
unaffected scientific calculation sources retain their original identities.
