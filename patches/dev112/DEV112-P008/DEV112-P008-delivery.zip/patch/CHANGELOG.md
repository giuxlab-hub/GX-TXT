# GX-TXT DEV112-P008 changes

Accepted source:f691b0f6e1016cb9af3db30ba3d1c8b5ea91429c. Full per-issue detail and exact file changes
are in ACCEPTANCE_MATRIX.json and MODIFIED_FILES.json.

The original P008 scope corrects17 reproduced P007 defects and implements both
requested GUI improvements. Backup-policy staleness notice, empty Print content
rows and Page Setup value projection were already correct in P007 and preserved.

Supplementary changes address demonstrated layout, diagnostic, state-clarity,
search, preview and control-feedback findings through their existing owners.
They clarify persistent versus read-through connectors, saved versus draft roots,
Module state versus Viewer visibility, immediate commits and free-text Date
metadata. They preserve security refusal and scientific semantics. Inapplicable
Python imports and incomplete TeX/resource inventories receive truthful diagnostics.
Unnecessary changes are avoided for qualified environment-only or intentionally
working behavior. The matrix distinguishes code fixes, documentation/clarity
changes, existing shared corrections and no-change results individually.

Cumulative installation and authentic rollback reuse the established receipt,
preimage and integrity infrastructure with the exact P007 route added. There is
no owner installation activation, new dependency manager, scientific algorithm
rewrite, alternative registry/scheduler or excluded-project implementation.
