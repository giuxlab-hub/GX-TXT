# GX-TXT DEV112-P008 delivery contents

Start with README.md and INSTALLAZIONE.md (both in English). The installable
archive and its matching helper are in `patch/`. Do not overlay the ZIP directly
on an installation. `SHA256SUMS` covers every other file in this delivery tree.
The detached FINAL_ACCEPTANCE.json beside the delivery ZIP binds the final
archive hash without a circular self-hash.

| Artifact | Purpose |
| --- | --- |
| ACCEPTANCE_MATRIX.json | The single authoritative set of 52 final requirement dispositions, with original IDs and baseline evidence. |
| MODIFIED_FILES.json | Exact 80-file change inventory relative to accepted P007, including hashes and modes. |
| SOURCE_PROVENANCE.json and SOURCE_COMMIT.txt | Final Git source identity and exact raw commit object. |
| DEV112-P008-source.bundle | Reproducible source delta requiring accepted P007; the installer does not require Git. |
| CHANGELOG.md and MAIN_DEVELOPMENT_SUMMARY.md | Changes, integration responsibilities and conservative development decisions. |
| CORE_REUSE_AND_GAP_AUDIT.md and API_CONTRACTS.md | Existing authoritative owners and compatibility evidence. |
| VALIDATION.json and VALIDATION_LIMITS.md | Validation scope, independent roles and practical limits. |
| evidence/GUI_SOURCE_ACCEPTANCE.json | Final mapped GUI, keyboard, layout and actual patch binding acceptance. |
| evidence/TECHNICAL_SOURCE_ACCEPTANCE.json | All 52 functional dispositions, regression/API/scientific/security checks and final source binding. |
| evidence/INSTALLATION_ACCEPTANCE.json | Independent direct installation, integrity and authentic rollback for all four exact baselines. |
| evidence/INPUTS.json and evidence/EVIDENCE_PATH_INDEX.json | Hash-pinned evidence and mapping from original scratch paths to included artifact names. |
| reproduce/delivery_tools/ | Scoped existing-infrastructure assembly, packaging, checking and deposit scripts, with their catalog. |

Preserved interim findings explain the corrections and rechecks. They are not
final acceptance claims; use the final reports above. The optional duplicate
MAIN installation run was deliberately canceled to give the independent
four-route run disk capacity. Its disposition is retained, with no PASS claimed.

The original owner request and its supplementary amendment are included as
byte-identical references in `evidence/`. The source's remaining-work TODO keeps
excluded projects and genuinely unfinished work; it does not defer an authorized
P008 requirement because of estimated complexity.

`patch/ASSEMBLY.json` is the immutable assembly-time receipt. Its initial
unqualified status records that assembly alone established no acceptance; the
later independent reports and detached FINAL_ACCEPTANCE.json supply qualification.

The files under `patch/`, including the notes inside the installable ZIP, retain
their exact assembly-time bytes used by independent installer qualification.
Use the final root documents and matrix for the complete accepted dispositions.
In particular, the abbreviated patch-note phrase about preserved Page Setup
projection refers to P007-GUI-038; it does not describe P007-GUI-039, whose
committed-baseline defect was reproduced and corrected as detailed in CHANGELOG.md.
