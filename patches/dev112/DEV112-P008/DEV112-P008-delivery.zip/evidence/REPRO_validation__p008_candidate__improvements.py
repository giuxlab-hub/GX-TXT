import os,sys,json,hashlib,tkinter
from pathlib import Path
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();t.withdraw();a=t.tk;a.call('set','argv0','__p008_validator__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog');a.call('set','probeout',str(out))
rows=[]
def check(name,script):
 try: rows.append(dict(case=name,result=a.eval(script)))
 except Exception as e: rows.append(dict(case=name,error=str(e),trace=a.eval('set errorInfo')))
 (out/'RESULT.json').write_text(json.dumps(rows,indent=2)+'\n')
check('B1-draft-close-reopen',r'''file mkdir $probeout/packagesA $probeout/packagesB
::GX::configurationCommit [list [dict create id plugins.package_chooser_directory scope user value [file normalize $probeout/packagesA]]]
::GX::pluginManagerDialog
.gxPluginManager.package.directory delete 0 end;.gxPluginManager.package.directory insert 0 [file normalize $probeout/packagesB]
set saved [::GX::configurationGet plugins.package_chooser_directory]
destroy .gxPluginManager
::GX::pluginManagerDialog
list saved $saved reopened [.gxPluginManager.package.directory get]''')
check('B1-browse-cancel-save',r'''rename tk_chooseDirectory original_tk_chooseDirectory
proc tk_chooseDirectory args {set ::chooserargs $args;return $::chooserresult}
set ::chooserresult [file normalize $probeout/packagesB]
.gxPluginManager.package.browse invoke
set draft [.gxPluginManager.package.directory get]
set savedBefore [::GX::configurationGet plugins.package_chooser_directory]
set ::chooserresult {}; .gxPluginManager.package.browse invoke
set cancelDraft [.gxPluginManager.package.directory get]
.gxPluginManager.package.save invoke
set savedAfter [::GX::configurationGet plugins.package_chooser_directory]
destroy .gxPluginManager;::GX::pluginManagerDialog
list draft $draft saved_before $savedBefore after_cancel $cancelDraft saved_after $savedAfter reopened [.gxPluginManager.package.directory get] chooser_initial $::chooserargs''')
check('B1-saved-only-package-chooser',r'''rename tk_getOpenFile original_tk_getOpenFile
proc tk_getOpenFile args {set ::packageargs $args;return {}}
.gxPluginManager.package.directory delete 0 end;.gxPluginManager.package.directory insert 0 [file normalize $probeout/packagesA]
set result [::GX::pluginInstallChoosePackage test]
set fallback [::GX::pluginInstallInitialDirectory /nonexistent-p008-fixture]
list result $result arguments $::packageargs fallback $fallback home [file normalize ~]''')
check('B1-conflict',r'''rename tk_messageBox original_tk_messageBox
proc tk_messageBox args {lappend ::messages $args;return ok}
set ::messages {}
::GX::configurationCommit [list [dict create id plugins.package_chooser_directory scope user value [file normalize $probeout/packagesA]]]
.gxPluginManager.package.directory delete 0 end;.gxPluginManager.package.directory insert 0 [file normalize $probeout/packagesB]
.gxPluginManager.package.save invoke
list saved [::GX::configurationGet plugins.package_chooser_directory] draft [.gxPluginManager.package.directory get] messages $::messages''')
check('B1-invalid-draft',r'''destroy .gxPluginManager;::GX::pluginManagerDialog
set ::messages {}
set ::GX::ui(pluginManagerPackageDirectory) "bad\npath"
.gxPluginManager.package.save invoke
list saved [::GX::configurationGet plugins.package_chooser_directory] draft $::GX::ui(pluginManagerPackageDirectory) messages $::messages''')
check('B1-reload',r'''destroy .gxPluginManager
::GX::configurationLoad
list reloaded [::GX::configurationGet plugins.package_chooser_directory] path [::GX::configurationPath]''')
check('B2-filter-invariants',r'''ttk::frame .vm
::GX::viewerManagerBuild .vm
set before [list [::GX::viewerProviderCatalog] $::GX::configurationValues [array get ::GX::moduleEnabled] [array get ::GX::moduleCfg]]
set all [.vm.tree children {}]
set selection [lindex $all 0];.vm.tree selection set $selection;::GX::viewerManagerSelection .vm
set ::GX::ui(viewerManagerQuery,.vm) impossible_no_viewer_matches_008
set hidden [list rows [.vm.tree children {}] selected [.vm.tree selection] disable [.vm.tools.disable instate disabled] enable [.vm.tools.enable instate disabled] status $::GX::ui(viewerManagerStatus,.vm)]
::GX::viewerManagerSet .vm 0
::GX::viewerManagerRefresh .vm
set refreshed [list query $::GX::ui(viewerManagerQuery,.vm) rows [.vm.tree children {}]]
::GX::viewerManagerResetFilter .vm
set restored [.vm.tree children {}]
set after [list [::GX::viewerProviderCatalog] $::GX::configurationValues [array get ::GX::moduleEnabled] [array get ::GX::moduleCfg]]
list count [llength $all] hidden $hidden refresh $refreshed reset_restores [expr {$all eq $restored}] invariant [expr {$before eq $after}]''')
check('B2-search-all-fields',r'''set result {};set providers [::GX::viewerProviderCatalog]
foreach field {short_title viewer_id module_id group_title} {
 set query [dict get [lindex $providers 0] $field]
 set ::GX::ui(viewerManagerQuery,.vm) $query
 set expected {}
 foreach provider $providers {set text [list [dict get $provider short_title] [dict get $provider viewer_id] [dict get $provider module_id] [dict get $provider group_title]];if {[string first [string tolower $query] [string tolower $text]]>=0} {lappend expected [dict get $provider module_id]/[dict get $provider viewer_id]}}
 lappend result [list field $field query $query actual [.vm.tree children {}] expected $expected match [expr {[.vm.tree children {}] eq $expected}]]
}
set result''')
check('B2-visible-actions-preserve-module',r'''set chosen {}
foreach provider [::GX::viewerProviderCatalog] {if {[dict get $provider catalog_replacement] eq {} && [dict get $provider catalog_visibility] ne {compatibility} && ![regexp -nocase {orion|sii|digitaliz|curve} [dict get $provider module_id]]} {set chosen $provider;break}}
set module [dict get $chosen module_id];set viewer [dict get $chosen viewer_id]
set old [::GX::viewerProviderEnabled $module $viewer]
set moduleBefore [::GX::moduleIsEnabled $module]
set ::GX::ui(viewerManagerQuery,.vm) $viewer
.vm.tree selection set $module/$viewer;::GX::viewerManagerSelection .vm
.vm.tools.disable invoke
set disabled [::GX::viewerProviderEnabled $module $viewer]
.vm.tree selection set $module/$viewer;::GX::viewerManagerSelection .vm
.vm.tools.enable invoke
set enabled [::GX::viewerProviderEnabled $module $viewer]
if {!$old} {.vm.tree selection set $module/$viewer;::GX::viewerManagerSelection .vm;.vm.tools.disable invoke}
list module $module viewer $viewer disabled $disabled enabled $enabled module_before $moduleBefore module_after [::GX::moduleIsEnabled $module] query $::GX::ui(viewerManagerQuery,.vm) restored [::GX::viewerProviderEnabled $module $viewer]''')
check('B2-destroy-rebuild-traces',r'''destroy .vm;ttk::frame .vm;::GX::viewerManagerBuild .vm
set ::GX::ui(viewerManagerQuery,.vm) impossible_no_viewer_matches_008
list traces [trace info variable ::GX::ui(viewerManagerQuery,.vm)] rows [.vm.tree children {}]''')
t.destroy();print(json.dumps(rows))
