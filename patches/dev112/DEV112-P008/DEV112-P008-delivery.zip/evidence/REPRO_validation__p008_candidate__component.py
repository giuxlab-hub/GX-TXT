import os,sys,json,traceback
from pathlib import Path
import tkinter
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();t.withdraw();a=t.tk;a.call('set','argv0','__p008_validator__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
rows=[]
def case(id,script):
 try: rows.append(dict(id=id,result=a.eval(script)))
 except Exception as e: rows.append(dict(id=id,error=str(e),trace=a.eval('set errorInfo')))
 (out/'RESULT.json').write_text(json.dumps(rows,indent=2))
a.call('set','probeout',str(out))
case('P007-GUI-002-default-apply-clear-change',r"""file mkdir $probeout/Session/metadata $probeout/Session/channels $probeout/rootA $probeout/exportA $probeout/exportB $probeout/private $probeout/remembered
set ::GX::currentSession [file normalize $probeout/Session]
::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
::GX::configurationSet storage.session_root [file normalize $probeout/rootA]
::GX::configurationSet storage.export_dir [file normalize $probeout/exportA]
::GX::configurationApply
set values {};foreach role [::GX::workspaceProfileFields] {dict set values $role [file normalize $probeout/private]}
::GX::sessionStorageProfileSave test $values
::GX::sessionStorageProfileApply test
set private [list [::GX::workspaceInitialDir session_root] [::GX::workspaceInitialDir export_dir]]
::GX::sessionStorageProfileApply {}
set cleared [list [::GX::workspaceInitialDir session_root] [::GX::workspaceInitialDir export_dir] remembered $::GX::workspaceDir(export_dir)]
::GX::configurationSet storage.export_dir [file normalize $probeout/exportB];::GX::configurationApply
set changed [::GX::workspaceInitialDir export_dir]
::GX::sessionStorageProfileApply test;::GX::sessionStorageProfileApply {}
set changedAfterCycle [::GX::workspaceInitialDir export_dir]
::GX::configurationSet storage.export_dir {};::GX::configurationApply
::GX::sessionStorageProfileApply test;::GX::sessionStorageProfileApply {}
list private $private cleared $cleared changed $changed changed_cycle $changedAfterCycle empty_default [::GX::workspaceInitialDir export_dir] cwd [pwd]
""")
case('P007-GUI-002-remembered-named-priority',r"""set ::GX::workspaceDir(export_dir) [file normalize $probeout/remembered]
::GX::configurationSet storage.export_dir [file normalize $probeout/exportB];::GX::configurationApply
::GX::sessionStorageProfileApply test;::GX::sessionStorageProfileApply {}
set remembered [::GX::workspaceInitialDir export_dir]
set ::GX::workspaceProfileCurrent named_test
::GX::sessionStorageProfileApply test;::GX::sessionStorageProfileApply {}
list remembered $remembered named [::GX::workspaceInitialDir export_dir] global_unchanged $::GX::workspaceDir(export_dir)
""")
case('P007-GUI-028-source-validation',r"""::GX::moduleSetEnabled plot.dataset 1;::GX::moduleSetRunSelected plot.dataset 1
set missing {};foreach row [::GX::runPlanEntries] {if {[dict get $row id] eq {plot.dataset}} {set missing $row}}
set publication [::GX::datasetPublicationV2PublishSeries $::GX::currentSession acq.generic_csv {dataset_id sample contract table.generic storage csv x_values {0 1 2} y_values {3 4 5} x_variable {variable_id x dtype float64 unit s} y_variable {variable_id y dtype float64 unit V}}]
set r [::GX::analysisSourceFindRow plot.dataset primary]
set ::GX::moduleAnalysisSource(plot.dataset,$r,dataset_id) sample
set valid {};foreach row [::GX::runPlanEntries] {if {[dict get $row id] eq {plot.dataset}} {set valid $row}}
set path [file join $::GX::currentSession [dict get $publication path]]
file rename $path $path.hidden
set missingFile {};foreach row [::GX::runPlanEntries] {if {[dict get $row id] eq {plot.dataset}} {set missingFile $row}}
file rename $path.hidden $path
list missing $missing valid $valid missing_file $missingFile
""")
case('P007-GUI-032-page-bounds',r"""ttk::frame .top;ttk::notebook .top.nb;ttk::frame .top.nb.results;::GX::buildResultsPage
set ::GX::ResultsView::session $::GX::currentSession
set ::GX::ResultsView::epoch 1
set result {};foreach {total offset count} {0 0 0 500 0 500 501 0 500 501 500 1 1000 500 500} {
 set rows {};for {set i 0} {$i<$count} {incr i} {lappend rows [dict create id row$i name sample category Analysis producer test type test state saved summary {}]}
 ::GX::resultsInventoryReady 1 $::GX::currentSession [dict create ok 1 result [dict create total $total offset $offset records $rows]]
 lappend result [list total $total offset $offset previous_disabled [.top.nb.results.pages.previous instate disabled] next_disabled [.top.nb.results.pages.next instate disabled] status $::GX::ResultsView::status]
}
set ::GX::ResultsView::loading 1;set old $::GX::ResultsView::offset;::GX::resultsPageMove -500
lappend result [list loading_guard [expr {$old==$::GX::ResultsView::offset}]]
set result
""")
case('P007-GUI-050-note-save-persistence',r"""::GX::loadInstrumentCatalog
set idx [::GX::addInstrumentFromModule instrument.generic]
set ::GX::instrumentNoteSummary($idx,notes) OLD
::GX::instrumentNoteSave $idx notes {New independent note α}
set saved [::GX::parseIni [file join $::GX::currentSession metadata manifest.ini]]
set notes {};dict for {key value} $saved {if {[string match *notes* $key] && [string first {New independent note} $value]>=0} {dict set notes $key $value}}
list note $::GX::instruments($idx,field,notes) summary $::GX::instrumentNoteSummary($idx,notes) persisted $notes
""")
t.destroy();print(json.dumps(rows))
