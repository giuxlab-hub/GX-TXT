"""Prepared independent final-stage runner; never run until exact stage supplied."""
import argparse,hashlib,json,os,stat,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def verify(root,inventory,sentinels):
 actual={}
 for p in root.rglob('*'):
  info=p.lstat()
  if stat.S_ISDIR(info.st_mode):continue
  assert stat.S_ISREG(info.st_mode) and info.st_nlink==1,str(p)
  actual[p.relative_to(root).as_posix()]={'sha256':sha(p),'size':info.st_size,'mode':stat.S_IMODE(info.st_mode)}
 assert actual==inventory|sentinels,'Complete bytes/modes/file-set mismatch'
 return hashlib.sha256(canonical(actual)).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('stage',type=Path)
 for k in ['source-commit','archive-sha256','installer-sha256','manifest-sha256']:a.add_argument('--'+k,required=True)
 args=a.parse_args();stage=args.stage.resolve(strict=True)
 assert len(args.source_commit)==40 and all(c in '0123456789abcdef' for c in args.source_commit)
 archive=stage/'DEV112-P008.zip';installer=stage/'apply.py';manifest_path=stage/'FILES.json'
 assert sha(archive)==args.archive_sha256 and sha(installer)==args.installer_sha256 and sha(manifest_path)==args.manifest_sha256
 preflight=json.loads((ROOT/'evidence/final-preflight.json').read_text());assert preflight['result']=='PASS' and preflight['source_commit']==args.source_commit
 manifest=json.loads(manifest_path.read_text());assert hashlib.sha256(canonical(manifest['postimage'])).hexdigest()=='ca61f1775cb95b253ed79a1b34eddb6be2c6439aae40d2a7acd4b246cead9b3c'
 prep=json.loads((ROOT/'RELEASE_PREP_RESULTS.json').read_text());base=Path(prep['root'])
 expected=json.loads((base/'EXPECTED_ROUTES.json').read_text());assert manifest['routes']==expected
 assert manifest['patch']=='DEV112-P008' and len(expected)==4
 # Stage source pin is recorded, but independent final full source/tree/catalog
 # binding must also be delivered by parent; this runner does not infer it.
 with zipfile.ZipFile(archive) as z:
  assert z.read('patch_notes/DEV112-P008/FILES.json')==manifest_path.read_bytes()
  assert z.read('patch_notes/DEV112-P008/apply.py')==installer.read_bytes()
 for route,before in expected.items():
  sent=json.loads((base/route/'SENTINELS.json').read_text());verify(base/route/'framework',before,sent)
 output=ROOT/'stage-run01';output.mkdir(mode=0o700);records=[]
 for route,before in expected.items():
  target=base/route/'framework';sent=json.loads((base/route/'SENTINELS.json').read_text());case=output/route;case.mkdir(mode=0o700)
  receipt=case/'apply.json'
  def command(label,*arguments,negative=False):
   argv=[sys.executable,'-I','-B',str(installer),str(target),str(archive),*arguments]
   (case/(label+'-command.json')).write_text(json.dumps(argv)+'\n')
   with (case/(label+'-stdout.json')).open('xb') as out,(case/(label+'-stderr.txt')).open('xb') as err:
    result=subprocess.run(argv,stdout=out,stderr=err,timeout=1200,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
   if negative:
    assert result.returncode!=0,(label,'unexpected success');return
   assert result.returncode==0,(route,label,result.returncode)
   audit=json.loads((case/(label+'-stdout.json')).read_text());assert audit['result']=='PASS';return audit
  baseline_snapshot=verify(target,before,sent)
  command('before','--check')
  assert verify(target,before,sent)==baseline_snapshot
  other=next(x for x in expected if x!=route)
  command('wrong-route','--check','--route',other,negative=True)
  assert verify(target,before,sent)==baseline_snapshot
  marker=target/'PATCH_LEVEL.txt';raw=marker.read_bytes();mode=stat.S_IMODE(marker.stat().st_mode)
  try:
   marker.write_bytes(raw+b'tampered\n');command('modified-byte','--check',negative=True)
  finally:marker.write_bytes(raw)
  assert verify(target,before,sent)==baseline_snapshot
  try:
   marker.chmod(0o755);command('modified-mode','--check',negative=True)
  finally:marker.chmod(mode)
  assert verify(target,before,sent)==baseline_snapshot
  command('missing-receipt','--apply','--stopped','--owner-authorized',negative=True)
  assert verify(target,before,sent)==baseline_snapshot
  applied=command('apply','--apply','--stopped','--owner-authorized','--receipt',str(receipt))
  post_snapshot=verify(target,manifest['postimage'],sent)
  receipt_sha=sha(receipt);assert applied['external_receipt_sha256']==receipt_sha
  (case/'retained-receipt.sha256').write_text(receipt_sha+'\n')
  command('after','--check','--receipt',str(receipt),'--receipt-sha256',receipt_sha)
  repeat=command('apply-idempotent','--apply','--stopped','--owner-authorized','--receipt',str(receipt),'--receipt-sha256',receipt_sha)
  assert repeat['coherent_noop'] and not repeat['writes'] and sha(receipt)==receipt_sha
  assert verify(target,manifest['postimage'],sent)==post_snapshot
  command('bad-receipt-hash','--rollback','--route',route,'--stopped','--owner-authorized','--receipt',str(receipt),'--receipt-sha256','0'*64,negative=True)
  assert verify(target,manifest['postimage'],sent)==post_snapshot and sha(receipt)==receipt_sha
  command('wrong-rollback-route','--rollback','--route',other,'--stopped','--owner-authorized','--receipt',str(receipt),'--receipt-sha256',receipt_sha,negative=True)
  assert verify(target,manifest['postimage'],sent)==post_snapshot
  if route=='post-p007':
   subprocess.run([sys.executable,'-I','-B',str(ROOT/'validation/p008_release_prep/extra_negatives.py'),str(stage),str(target),str(receipt),str(output/'extra-negatives')],check=True,timeout=1200)
   assert verify(target,manifest['postimage'],sent)==post_snapshot
  command('rollback','--rollback','--route',route,'--stopped','--owner-authorized','--receipt',str(receipt),'--receipt-sha256',receipt_sha)
  assert verify(target,before,sent)==baseline_snapshot
  restored=command('rollback-idempotent','--rollback','--route',route,'--stopped','--owner-authorized','--receipt',str(receipt),'--receipt-sha256',receipt_sha)
  assert restored['coherent_noop'] and not restored['writes']
  command('restored','--check');assert verify(target,before,sent)==baseline_snapshot
  records.append({'route':route,'result':'PASS','receipt_sha256':receipt_sha,'final_inventory_sha256':applied['final_inventory_sha256'],'full_managed_identity_and_sentinels_preserved':True})
  (case/'RESULT.json').write_text(json.dumps(records[-1],indent=2)+'\n');print('PASS',route,flush=True)
 assert len({r['final_inventory_sha256'] for r in records})==1
 result={'result':'PASS_FOUR_ROUTES','source_commit_supplied':args.source_commit,'source_full_identity_gate':'Separate final source/catalog/archive binding required; not inferred from installer result','archive_sha256':args.archive_sha256,'installer_sha256':args.installer_sha256,'manifest_sha256':args.manifest_sha256,'routes':records,'activation':False}
 (output/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
if __name__=='__main__':main()
