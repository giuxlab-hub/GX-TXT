# DEV-RUNTIME final handoff

**COMPLETE. All six assigned gates have definitive author dispositions.**
Commit: **`bcbc8c3651d1ff2f3e62b8dac86d685a0ddcf4c9`**
(`Fix P008 runtime diagnostics and asynchronous source preview`).
Clean working framework. Exact parent:
`9e89001a43e3dac223b1dddce418edc7c0ad2864`; original P008 work preserved.

Final dispositions: **003 FIXED; 007 FIXED PRESENTATION; 008 FIXED PRESENTATION/
PLATFORM QUALIFICATION; 009 FIXED; 015 ENVIRONMENT_ONLY NOCHANGE;
026 FIXED PREVIEW**. No remaining DEV-RUNTIME implementation work.

Final evidence: `fixed04/results.json` all6 PASS, background_errors=[],
home_unchanged=true. Actual Tk/screenshots, real checkbox and genuine installed
Python editor, genuine Script Registry Project admission and audit overlay.
Baseline expanded audit evidence: `baseline03/results.json`; its existing static
summary remains exactly the candidate summary:
`AVAILABLE 2 MISSING 2 OPTIONAL 1 UNKNOWN 2 ERROR 0`.
`guards02/guards.json` PASS: invalid TeX path/wildcard/option queries rejected
before probing; actual native probe timeout, found/not-located/failed diagnostic
distinctions; Windows-host qualification guard, inert local shadow preservation,
static syntax/optional/conditional distinctions. TeX GUI checks include actual
not-located lookup, query-edit cancellation and query without inventory.
No discovered optional package was imported; controlled runtime imports use only
math and private authored missing/failing modules with five-second deadlines.

008 now visibly labels source rows `winreg (Windows only)`, while an unguarded
source import remains MISSING. Environment table projects INAPPLICABLE. Private
qualification does not change public status vocabulary, closed projections,
source-audit summary counts, conditional-branch uncertainty or execution.
009 remains one exact filename, original native4s probe and managed10s/1MiB
process-group request; no full scan or inventory mutation. 026 captures styling
with the existing palette before asynchronous completion; Preview OFF clears
tags while effective preference stays ON and genuine editor OFF/ON/source pass.

Retained failure: `fixed01/results.json` caught an author-check timing flaw:
source readiness was accepted before queued styling refresh completed. Checker
now waits for existing timer/request completion as well. `fixed02`, `fixed03`
and `fixed04` pass; no product guard was relaxed. No managed ImageMagick setup
failure or private runtime override was needed. Prior private evidence retained.

Changed product files: app/gui/python_import_audit.tcl;
core/python/{gxtxt_latex_environment.py,gxtxt_python_environment.py};
core/tcl/{configuration_api_v1.tcl,configuration_latex_v1.tcl,
python_environment_api_v1.tcl,scientific_library_credentials_gui_v1.tcl,
source_surface_api_v1.tcl}. Shared configuration_api_v1 change touches only
runtimeToolStatus. Also root SCRIPT_CATALOG.md's two-line runtime pointer and
five files under validation/dev112_p008_runtime/: AUTHOR_RESULTS.md,
SCRIPT_CATALOG.md, setup_baseline.py, check.py, guards.py. `git diff --check`
passed. Committed AUTHOR_RESULTS.md contains per-ID baseline/outcome detail.

Limits: no live Windows GUI; Linux plus explicit host-guard control only. TeX
truncation uses controlled iterator through the original capped owner, not an
installed-tree census. Independent technical/GUI acceptance stays with assigned
validators and MAIN. MAIN alone updates the single matrix and final catalog,
fingerprint/hash artifacts (including root SCRIPT_CATALOG.md sidecar), integrates
and releases. No substantial Y architecture expansion was needed.

The following checkpoint preserves the earlier progress/evidence trail. Its
"running"/"planned" wording is superseded by the final state above.

Model/effort: gpt-6.1-sol HIGH. Resume session
`01a1d0c0-a879-7db1-b6c6-dc0e2ead7be7` in this exclusive framework.
Inherited source: `9e89001a43e3dac223b1dddce418edc7c0ad2864` (original P008 preserved).
Exact baseline: `a10f5a99fdab93e251efe9c415d5ad76d14c5259` in own `p007-baseline`.
All 6381 accepted postimage files verified and accepted file modes restored;
see `baseline_provenance.json`. Shared Git objects read only.

Assigned IDs: 003,007,008,009,015,026. All baseline checks completed in actual Tk
and controlled fixtures; detailed records are in `baseline01/results.json` with
screenshots. A second baseline run improves sample screenshot visibility only.

003: actual NGspice44.2 returns a banner whose first line is `******`; GUI shows
only that line. Narrow existing runtime probe parser correction implemented.
007: actual Refresh profiles shows generic integrity refusal. Private owner
correctly reports unsafe_storage for own scratch ancestor0775. Only explanatory
GUI text changed, preserving private finite errors, secrets and 0700/0600 policy.
008: Linux inventory shows Windows-only stdlib names MISSING. Existing mandatory,
optional, conditional/dynamic and genuine controlled runtime failures remain
distinct. Raw/public statuses remain unchanged; existing inventory UI projects
INAPPLICABLE and an explanation for missing Windows stdlib implementations.
009: controlled existing 20000 bound gives zero article.cls subset matches while
actual bounded kpsewhich locates it. Existing diagnostic owner gains one bounded
exact-filename query; no full scan, package changes or LaTeX public API project.
015: **ENVIRONMENT_ONLY, NOCHANGE**. Ancestor0775 explains secure refusal.
Nonexistent deferred storage root validates; private Session creation works.
026: real checkbox OFF + Preview retains keyword/comment/string tags; genuine
Python editor OFF/ON already works with exact source unchanged. Styling snapshot
capture moved to the existing configure path before async completion; no lexer
change or new SourceSurface option/API.

Candidate checks running. MAIN integration note: small changes to shared
`core/tcl/configuration_api_v1.tcl` touch runtimeToolStatus only, and root
SCRIPT_CATALOG adds the runtime-check pointer. Other source files belong to the
assigned runtime/credential/TeX/SourceSurface/import diagnostic owners.
No substantial Y architecture expansion is planned. J008 will use the existing
static owner and UI, preserving public status vocabulary and runtime distinctions.
No dependency installation, security bypass, user-directory chmod, excluded
J010/J019/J023/J040, Group C016, catalog rebuild or deployment is authorized here.

Reusable scripts are cataloged before execution in
`framework/validation/dev112_p008_runtime/SCRIPT_CATALOG.md`.
