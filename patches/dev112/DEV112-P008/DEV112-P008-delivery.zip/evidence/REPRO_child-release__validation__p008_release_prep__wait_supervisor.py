import json,os,signal,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];log=ROOT/'evidence/wait-supervisor.jsonl'
def processes():
 result={}
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   raw=(p/'cmdline').read_bytes().split(b'\0');cmd=[x.decode() for x in raw if x];info=(p/'stat').read_text().split();cwd=(p/'cwd').resolve()
   result[int(p.name)]={'cmd':cmd,'ppid':int(info[3]),'state':info[2],'cwd':cwd}
  except (OSError,ValueError,UnicodeError):pass
 return result
def event(**kw):
 with log.open('a') as f:f.write(json.dumps(dict(time=time.time(),**kw))+'\n')
ps=processes();matches=[pid for pid,p in ps.items() if 'validation/p008_release_prep/stage_check.py' in p['cmd'] and p['cwd']==ROOT];assert len(matches)==1,matches
pid=matches[0];event(event='monitor_start',runner_pid=pid);seen={};stopped=ps[pid]['state']=='T'
try:
 while True:
  ps=processes()
  if pid not in ps or ps[pid]['state']=='Z':break
  children=[(c,p) for c,p in ps.items() if p['ppid']==pid and (c in seen or p['state']=='Z' or any(x.endswith('/stage01/apply.py') for x in p['cmd']))]
  for child,p in children:
   if child not in seen:seen[child]=time.monotonic();event(event='installer_child_observed',child=child,runner_pid=pid)
   age=time.monotonic()-seen[child]
   if p['state']=='Z' and stopped:
    os.kill(pid,signal.SIGCONT);stopped=False;event(event='runner_resumed_completed_child',child=child)
   elif p['state']!='Z' and 600<age<7200 and not stopped:
    os.kill(pid,signal.SIGSTOP);stopped=True;event(event='own_runner_wait_paused_installer_uninterrupted',child=child)
   elif age>=7200 and stopped:
    os.kill(pid,signal.SIGCONT);stopped=False;event(event='maximum_wait_reached',child=child)
  time.sleep(1)
finally:
 if stopped:
  try:os.kill(pid,signal.SIGCONT)
  except ProcessLookupError:pass
 event(event='monitor_end',runner_pid=pid)
