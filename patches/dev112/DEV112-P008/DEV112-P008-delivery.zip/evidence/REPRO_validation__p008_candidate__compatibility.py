from pathlib import Path
import tkinter,sys,os,json,hashlib
old,new,out=map(lambda s:Path(s).resolve(),sys.argv[1:]);out.mkdir()
def inspect(root,tag):
 scope=out/tag;scope.mkdir()
 for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
  p=scope/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
 a=tkinter.Tcl();a.call('set','argv0','__p008_compatibility__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
 spaces=['::GX'];signatures={};bodies={}
 while spaces:
  ns=spaces.pop();spaces.extend(a.splitlist(a.call('namespace','children',ns)))
  for name in a.splitlist(a.call('info','procs',ns+'::*')):
   args=[]
   for arg in a.splitlist(a.call('info','args',name)):
    has=int(a.call('info','default',name,arg,'::__probe_default'));args.append({'name':str(arg),'has_default':bool(has),'default':str(a.call('set','::__probe_default')) if has else None})
   signatures[str(name)]=args;bodies[str(name)]=str(a.call('info','body',name))
 return signatures,bodies
before,beforebody=inspect(old,'P007');after,afterbody=inspect(new,'candidate')
changed=[{'name':n,'before':before[n],'after':after[n]} for n in sorted(before.keys()&after.keys()) if before[n]!=after[n]]
removed=sorted(before.keys()-after.keys());added=sorted(after.keys()-before.keys())
validation_before=beforebody['::GX::validatePlotSettings'];validation_after=afterbody['::GX::validatePlotSettingsArray'].replace('upvar #0 $settings cfg','variable cfg')
result={'kind':'post_implementation_compatibility','before_procs':len(before),'after_procs':len(after),'retained_signatures_changed':changed,'removed':removed,'added':added,'common_plot_validation_rules_exact':validation_before==validation_after,'result':'PASS' if not changed and not removed and validation_before==validation_after else 'REVIEW_REQUIRED'}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert result['result']=='PASS'
