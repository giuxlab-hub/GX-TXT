from pathlib import Path
import os,sys,json,time,tkinter,hashlib
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();a=t.tk;a.call('set','argv0','__p008_final_session__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
errors=[];a.createcommand('bgerror',lambda message:errors.append(str(message)))
for key in ['storage.session_root','storage.cache_dir','storage.temp_dir','scripts.user_root','diagnostics.stderr_log_directory']:
 p=out/key;p.mkdir(mode=0o700);a.call('::GX::configurationSet',key,str(p))
a.call('::GX::configurationSet','runtime.magick','/usr/bin/magick-im7.q16');a.call('::GX::configurationSave')
session=Path(str(a.call('::GX::createNewSession','P008_FINAL_SESSION','',0)));note=session/'notes/private.md';note.parent.mkdir(exist_ok=True);note.write_text('# Final synthetic note\n\nFINAL_PRIVATE_SENTINEL α\n');before=hashlib.sha256(note.read_bytes()).hexdigest();a.call('::GX::writeManifest',str(session/'metadata/manifest.ini'))
def pump(seconds):
 end=time.monotonic()+seconds
 while time.monotonic()<end:t.update();time.sleep(.01)
report={'source':str(root),'session':str(session)}
try:
 a.call('::GX::launchGui');pump(.5);a.call('wm','minsize','.',1,1);a.call('wm','geometry','.','900x650+0+0');a.call('.top.nb','select','.top.nb.sessionfiles');a.call('::GX::sessionPageSelect','files');a.call('::GX::sessionFileExplorerPopulate');pump(.2)
 tree=str(a.call('set','::GX::ui(sessionFileTree)'));text=str(a.call('set','::GX::ui(sessionFileText)'));bar='.top.nb.sessionfiles.bar'
 a.call(tree,'selection','set','f:notes/private.md');a.call('::GX::sessionFileExplorerOpenSelected');pump(.15)
 expected=str(a.call(text,'get','1.0','end-1c'));command=str(a.call(bar+'.copy','cget','-command'));a.call(bar+'.copy','invoke');copied=str(a.call('clipboard','get'));assert expected and copied==expected
 names=['projectHome','session','instruments','configuration','tools','refresh','copy','editnote','jobDetails'];actions={n:{'exists':bool(int(a.call('winfo','exists',bar+'.'+n))),'manager':str(a.call('winfo','manager',bar+'.'+n))} for n in names};assert all(x['exists'] and x['manager']=='grid' for x in actions.values())
 a.call('::GX::sessionActionGuiRefresh');pump(.1);assert str(a.call(bar+'.copy','cget','-command'))==command;a.call(bar+'.copy','invoke');assert str(a.call('clipboard','get'))==expected
 a.call('::GX::sessionPageSelect','config');a.call('.top.nb.sessionfiles.config.pages','select','.top.nb.sessionfiles.config.pages.raw');a.call('::GX::sessionConfigRefresh');a.call('::GX::_sessionFileExplorerCopyState');a.call(bar+'.copy','invoke');raw=str(a.call('.top.nb.sessionfiles.config.pages.raw.text','get','1.0','end-1c'));assert raw==str(a.call('clipboard','get'));assert str(a.call('.top.nb.sessionfiles.config.pages.raw.text','cget','-state'))=='disabled'
 guide=(root/'docs/guides/GENERIC_CSV_MULTI_IMPORT.md').read_text();assert 'Channels/Variables' not in guide and 'Dataset → Variables' in guide
 assert hashlib.sha256(note.read_bytes()).hexdigest()==before;assert not errors,errors
 report.update(result='PASS',all_nine_original_actions=actions,copy_command=command,selected_note_copy_matches=True,tools_refresh_preserves_copy=True,raw_copy_matches_visible_readonly=True,original_note_unchanged=True,guide013_current=True,background_errors=errors)
finally:
 try:a.call('::GX::apiCatalogClose')
 except Exception:pass
 t.destroy()
(out/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
