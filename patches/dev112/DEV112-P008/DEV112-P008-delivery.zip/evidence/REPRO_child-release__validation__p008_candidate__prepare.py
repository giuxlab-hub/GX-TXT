import io,json,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[2];repo='/srv/gxtxt/agents/scratch/DEV112-P008-MAIN-20261112/framework';pin='87cbc12ea102b70dc4885e887d441e2d5975a2c0';dst=root/'candidate87cbc';dst.mkdir(mode=0o700)
raw=subprocess.check_output(['git','-C',repo,'archive','--format=tar',pin])
with tarfile.open(fileobj=io.BytesIO(raw)) as t:
 assert all(not m.issym() and not m.islnk() and not m.name.startswith('/') and '..' not in Path(m.name).parts for m in t.getmembers())
 t.extractall(dst,filter='data')
subprocess.run(['python3','-I','-B',str(root/'validation/p008_candidate/restore_copy_modes.py'),str(dst),str(root/'evidence/candidate-mode-restoration.json')],check=True)
subprocess.run(['python3','-I','-B',str(root/'validation/p008_candidate/identity.py'),repo,pin,str(dst),str(root/'evidence/candidate-identity-before.json')],check=True)
diff=subprocess.check_output(['git','-C',repo,'diff','a10f5a99fdab93e251efe9c415d5ad76d14c5259',pin,'--','core/python/gxtxt_python_environment.py','core/python/gxtxt_latex_environment.py','core/python/scientific_library_credentials_v1.py','core/python/scientific_library_manager.py','core/tcl/configuration_api_v1.tcl','core/tcl/configuration_latex_v1.tcl','core/tcl/python_environment_api_v1.tcl','core/tcl/scientific_library_credentials_gui_v1.tcl','core/tcl/source_surface_api_v1.tcl','core/tcl/workspace_profiles_api_v1.tcl'])
(root/'evidence/candidate-relevant.diff').write_bytes(diff)
w=json.loads((root/'WORK_STATE.json').read_text());w.update(status='running_candidate87cbc',candidate_commit=pin,candidate_root=str(dst),active_ids=['P007-GUI-'+x for x in ['003','007','008','009','015','026']],next='bounded runtime/security/publicAPI checks and post-test exact identity');(root/'WORK_STATE.json').write_text(json.dumps(w,indent=2)+'\n')
