import ast,hashlib,importlib.util,json,os,stat,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));from baselines import admitted_baselines
os.umask(0o077)
def sha(data):return hashlib.sha256(data).hexdigest()
def canonical(data):return json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
owner=load('reviewed_p008',HERE/'apply_p008_template_reviewed.py')
routes,contents,inputs=admitted_baselines()
pins={'r2':'d385ab67405dedbe0747d6de6bc97c9ff267313041391c355d7020da8a195c3d','post-p005':'c4f988dee0f95b14b773fd67064fa09a80073a07a1a34e25d381273387b63a80','post-p006-r5':'1471c154455c18c18c7f71a1dd751c1d946e1235ceecc25e23008bfb7360c11c','post-p007':'514e9dd7778b8eb2fc34d60ea0ec4cb544786f430d9e308d0620171e8cac90ed'}
archives={
'r2':('/srv/gxtxt/releases/dev112/0.9.8.10-dev-112-r2/public/gxtxt_pipeline_dev112_public.tar.gz','8fda1fd6e485d9d917adfb08d64991c2403f8faf19ed10f4770565d8afcdbaa0'),
'post-p005':('/srv/gxtxt/releases/dev112/patches/0005-cumulative-quantitative-raster/DEV112-P005.zip','55358070dc710ae4b1d7384edeef03f4a47627e4f790484d102a5a360e2e38b9'),
'post-p006-r5':('/srv/gxtxt/main/work-agent/TK_GIUXLAB/deliveries/DEV112-P006-20261112-r5/patch/DEV112-P006.zip','d62ff22bd824e1dcdfaece27243ae958a5d20d1ec624d0b33d45be79fc2a7ed6'),
'post-p007':('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV112-P007-20261112/DEV112-P007.zip','db4b7457edebc3a01bae244e1bc01db7a785d7348b9d808fb000b7a2d20131b3')}
base=ROOT/'release-baselines01';base.mkdir(mode=0o700,exist_ok=True)
(base/'EXPECTED_ROUTES.json').write_text(json.dumps(routes,indent=2)+'\n')
result={'result':'PREPARED_NO_APPLY','root':str(base),'routes':{},'inputs':inputs,'archives':{},'installer_executed':False,'apply_executed':False}
for route,(path,pin) in archives.items():
 with open(path,'rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 assert actual==pin
 result['archives'][route]={'path':path,'sha256':actual,'independently_hash_verified':True}
for route,before in routes.items():
 assert sha(canonical(before))==pins[route]==owner.ROUTE_PINS[route]
 case=base/route;case.mkdir(mode=0o700,exist_ok=True);target=case/'framework';target.mkdir(mode=0o700,exist_ok=True)
 for name,row in before.items():
  p=target/name;p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():
   with p.open('xb') as f:f.write(contents[route][name])
   p.chmod(row['mode'])
 def verify(extra):
  observed={}
  for p in target.rglob('*'):
   info=p.lstat()
   if p.is_dir():assert not p.is_symlink();continue
   assert stat.S_ISREG(info.st_mode) and info.st_nlink==1
   observed[p.relative_to(target).as_posix()]={'sha256':sha(p.read_bytes()),'size':info.st_size,'mode':stat.S_IMODE(info.st_mode)}
  assert observed==before|extra
  return observed
 prior_sent=json.loads((case/'SENTINELS.json').read_text()) if (case/'SENTINELS.json').exists() else {}
 verify(prior_sent)
 # Provisional postimage is P007 itself; exclude duplicate route so exactly-one
 # admission remains meaningful. Map its postimage label back to post-p007.
 admission_routes={k:v for k,v in routes.items() if k!='post-p007'}
 state,_=owner.admitted_state(target,admission_routes,routes['post-p007'])
 state='post-p007' if state=='postimage' else state
 assert state==route
 sentinels={'Sessions/P008_KEEP/user-data.bin':b'Private installation preservation sentinel\x00\xff\n','Configuration/p008-preserve.ini':b'[private]\nunchanged = yes\n','p008-user-notes.txt':b'Private unrelated file preservation sentinel\n'}
 sent={}
 for name,data in sentinels.items():
  p=target/name;p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():
   with p.open('xb') as f:f.write(data)
   p.chmod(0o600)
  sent[name]={'sha256':sha(data),'size':len(data),'mode':0o600}
 verify(sent);after_state=owner.admitted_state(target,admission_routes,routes['post-p007'])[0];assert after_state==('postimage' if route=='post-p007' else route)
 (case/'SENTINELS.json').write_text(json.dumps(sent,indent=2)+'\n')
 result['routes'][route]={'framework':str(target),'files':len(before),'inventory_sha256':pins[route],'full_bytes_modes_file_set_verified':True,'admitted_before_sentinels':state,'admitted_after_sentinels':route,'sentinels':sent,'root_mode':oct(stat.S_IMODE(target.stat().st_mode))}
 print('Prepared',route,len(before),pins[route],flush=True)
old=Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV112-P007-20261112/DEV112-P007-apply.py')
oldtext=old.read_text();newtext=(HERE/'apply_p008_template_reviewed.py').read_text()
def functions(text):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
a=functions(oldtext);b=functions(newtext.replace('p008','p007').replace('P008','P007').replace("b'008\\n'","b'007\\n'").replace('008 newline','007 newline'))
result['static_review']={'unchanged_functions_after_patch_label_normalization':sorted(k for k in a if a[k]==b.get(k)),'changed_functions':sorted(k for k in a if a[k]!=b.get(k)),'summary':'Fourth route and pins, P008 marker/labels/temp prefixes, expanded exact path allowlist and rollback route help. Source identity/admission/receipt/atomic-file-write algorithms retained. Template zero manifest pin is deliberately not a final runnable release helper.','limitations':['Per-file atomic/fsynced writes are not whole-installation transactions; mixed interrupted states refuse automatic continuation.','Stopped/owner-authorized flags acknowledge operator facts, do not detect processes or grant permission.','Final source/catalog/stage archive identity, manifest binding, sizes and all four apply/rollback routes remain unqualified until stage supplied.']}
result['tool_sha256']={p.name:sha(p.read_bytes()) for p in HERE.glob('*.py')}
result['next_stage_command']='python3 -I -B validation/p008_release_prep/stage_check.py EXACT_FINAL_STAGE --source-commit FINAL_FULL_SHA --archive-sha256 FINAL_PATCH_SHA256 --installer-sha256 FINAL_APPLY_SHA256 --manifest-sha256 FINAL_FILES_SHA256'
(ROOT/'RELEASE_PREP_RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
w=json.loads((ROOT/'WORK_STATE.json').read_text());w.update(status='four_baselines_prepared_no_apply_awaiting_final_stage',release_prep='RELEASE_PREP_RESULTS.json',prepared_baselines=str(base),next=result['next_stage_command']);(ROOT/'WORK_STATE.json').write_text(json.dumps(w,indent=2)+'\n')
