import os,sys,json,traceback
from pathlib import Path
import tkinter
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();t.withdraw();a=t.tk;a.call('set','argv0','__p008_validator__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
rows=[]
def case(id,script):
 try: rows.append(dict(id=id,result=a.eval(script)))
 except Exception as e: rows.append(dict(id=id,error=str(e),trace=a.eval('set errorInfo')))
 (out/'RESULT.json').write_text(json.dumps(rows,indent=2))
a.call('set','probeout',str(out))
case('setup',r"""file mkdir $probeout/Session/metadata $probeout/Session/channels
set ::GX::currentSession [file normalize $probeout/Session];::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
ttk::frame .top;ttk::notebook .top.nb
::GX::buildSessionFileExplorerGui
list files_built [winfo exists .top.nb.sessionfiles]
""")
case('P007-GUI-047-parser-and-scroll',r"""set path [file join $::GX::currentSession metadata manifest.ini]
set f [open $path a];puts $f {
[fixture]
key=first
invalid-unassigned-line
key=second};close $f
::GX::sessionConfigRefresh
set parsed [::GX::parseIni $path]
set raw .top.nb.sessionfiles.config.pages.raw
list duplicate [dict get $parsed fixture.key] invalid_omitted [expr {![dict exists $parsed fixture.invalid-unassigned-line]}] raw_readonly [$raw.text cget -state] horizontal_exists [winfo exists $raw.sx] horizontal_command [$raw.sx cget -command] xscroll [$raw.text cget -xscrollcommand] status $::GX::sessionsUi(configStatus)
""")
case('P007-GUI-048-dependency-state',r"""::GX::parameterSessionSet a {formula 2 unit V min 0 max 10 description {Fixture}}
::GX::parameterSessionSet b {formula {a+1}}
ttk::frame .parameters;::GX::parameterEditorBuild .parameters session
set before [::GX::parameterSessionDefinitions]
set ::GX::ParameterEditor::ui(.parameters,name) a
::GX::parameterEditorAction .parameters delete
list diagnostic $::GX::ParameterEditor::ui(.parameters,status) unchanged [expr {$before eq [::GX::parameterSessionDefinitions]}]
""")
case('P007-GUI-049-date-guidance-free-text',r"""ttk::frame .top.nb.exp;::GX::rebuildNativeExperimentGui
set ::GX::cfg(experiment_date) not-a-date
::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
set saved [::GX::parseIni [file join $::GX::currentSession metadata manifest.ini]]
list persisted [dict get $saved experiment.date] labels [list [.top.nb.exp.l2 cget -text] [.top.nb.exp.hint cget -text]]
""")
case('P007-GUI-054-help-index',r"""::GX::documentationBrowserRefresh
set missing {};foreach p [glob -directory [file join $::GX::scriptDir docs help] *.md] {if {![dict exists $::GX::documentationBrowserEntries core:[file rootname [file tail $p]]]} {lappend missing [file tail $p]}}
list unindexed $missing projects_read [expr {[string length [::GX::documentationBrowserRead core:projects]]>0}] storage_read [expr {[string length [::GX::documentationBrowserRead core:storage_profiles]]>0}] builder_read [expr {[string length [::GX::documentationBrowserRead core:script_module_builder]]>0}]
""")
case('P007-GUI-035-explicit-immediate-preference',r"""ttk::frame .top.nb.modules;::GX::coreUiSurfaceBuildModulesControls
set before [::GX::configurationGet features.script_workspace]
.top.nb.modules.surfaces.c0 invoke
list before $before after [::GX::configurationGet features.script_workspace] disclosure [.top.nb.modules.surfaces cget -text] saved_file [file exists [::GX::configurationPath]]
""")
case('P007-GUI-035-Variant-New-identity',r"""::GX::plotVariantManager plot.dataset plot.dataset.xy
.plotvariants.actions.new invoke
set ids [::GX::plotVariantIds plot.dataset plot.dataset.xy]
set guidance [.plotvariants.h cget -text]
.plotvariantedit.buttons.close invoke
list created $ids after_close [::GX::plotVariantIds plot.dataset plot.dataset.xy] guidance $guidance
""")
case('P007-GUI-004/014-explanation-and-no-routing-change',r"""ttk::frame .contracts
set before [list [::GX::contractRegistryDescribe document.text] [::GX::contractVisualizerPreferenceGet document.text open] [::GX::contractVisualizerPreferenceGet document.text preview]]
::GX::configurationContractsBuild .contracts
.contracts.split.list.tree selection set document.text;::GX::configurationContractsSelect .contracts
set after [list [::GX::contractRegistryDescribe document.text] [::GX::contractVisualizerPreferenceGet document.text open] [::GX::contractVisualizerPreferenceGet document.text preview]]
list explanation [.contracts.intro cget -text] authority_unchanged [expr {$before eq $after}]
""")
t.destroy();print(json.dumps(rows))
