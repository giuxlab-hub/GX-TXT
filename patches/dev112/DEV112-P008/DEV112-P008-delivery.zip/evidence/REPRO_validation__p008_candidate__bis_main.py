import os,sys,json,traceback
from pathlib import Path
import tkinter
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();t.withdraw();a=t.tk;a.call('set','argv0','__p008_validator__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
rows=[]
def case(id,script):
 try: rows.append(dict(id=id,result=a.eval(script)))
 except Exception as e: rows.append(dict(id=id,error=str(e),trace=a.eval('set errorInfo')))
 (out/'RESULT.json').write_text(json.dumps(rows,indent=2))
a.call('set','probeout',str(out))
# Use an existing configured system tool for label/controller tests; managed source integrity was separately verified.
a.call('::GX::configurationSet','runtime.magick','/usr/bin/magick-im7.q16')
case('setup-configuration',r"""ttk::frame .top;ttk::notebook .top.nb;ttk::frame .top.nb.configuration
::GX::buildConfigurationPage
list built [winfo exists .top.nb.configuration.sections.modules.kinds] registry_label [.top.nb.configuration.sections.libraries.registry cget -textvariable]
""")
case('P007-GUI-005-side-effect-disclosure',r"""ttk::frame .nodehost;::GX::scientificExecutionNodeManagerBuild .nodehost
rename ::GX::scientificExecutionNodeRegister ::GX::originalNodeRegister
proc ::GX::scientificExecutionNodeRegister args {set ::nodeSaveAttempt 1;error {TEST STOP: Save/validate boundary, no network}}
set ::nodeSaveAttempt 0;.nodehost.nodes.actions.test invoke
list button [.nodehost.nodes.actions.test cget -text] saves_first $::nodeSaveAttempt status [.nodehost.nodes.status cget -text] intro [.nodehost.nodes.intro cget -text]
""")
case('P007-GUI-006-saved-root-draft',r"""set before [::GX::configurationGet libraries.scientific_root]
set ::GX::configurationUi(libraries.scientific_root) [file normalize $probeout/DEFERRED_NOT_CREATED]
list saved $before draft $::GX::configurationUi(libraries.scientific_root) label $::GX::configurationUi(libraries.registry_path) draft_exists [file exists $::GX::configurationUi(libraries.scientific_root)] environment_root $::env(GXTXT_SCIENTIFIC_LIBRARY_ROOT)
""")
case('P007-GUI-004/014-contract-status',r"""ttk::frame .contracts;::GX::configurationContractsBuild .contracts
.contracts.split.list.tree selection set document.text;::GX::configurationContractsSelect .contracts
set d .contracts.split.detail.viewport.scroll.content
list registry [::GX::contractRegistryDescribe document.text] intro [.contracts.intro cget -text] media_help [.top.nb.configuration.sections.viewers.explain cget -text] identity [$d.identity cget -text] open [$d.openReason cget -text] preview [$d.previewReason cget -text]
""")
case('P007-GUI-012-status-terms',r"""set rows {};foreach record [::GX::configurationInstalledPlugins] {if {[dict get $record state] eq {OFF} && [dict get $record health] eq {Available}} {lappend rows [list id [dict get $record id] state [dict get $record state] health [dict get $record health] kind [::GX::moduleField [dict get $record id] kind {}] run_eligible [::GX::moduleIsRunnableAnalysis [dict get $record id]]]}};set rows
""")
case('P007-GUI-020-Mouser-persistence',r"""set found {};dict for {node record} $::GX::ConfigurationModules::libraryImporterRecords {if {[dict get $record id] eq {source.mouser}} {set found $node;set fields [dict get $record fields];break}}
set tree .top.nb.configuration.sections.modules.kinds.library_importers.browser.split.list.tree
$tree selection set $found;::GX::configurationModulesSelect library_importers
set parent .top.nb.configuration.sections.modules.kinds.library_importers.browser.split.detail.viewport.content
set labels {};foreach w [winfo children $parent] {if {[winfo class $w] eq {TLabel}} {lappend labels [$w cget -text]}}
list persistence [::GX::descriptorValue $fields library_source_connector persistence {}] details $labels
""")
case('P007-GUI-021-presentation-vs-module',r"""set rows {};foreach provider [::GX::viewerProviderCatalog] {if {[dict get $provider enabled] && ![::GX::moduleIsEnabled [dict get $provider module_id]]} {lappend rows [list module [dict get $provider module_id] viewer [dict get $provider viewer_id] presentation [dict get $provider enabled] module_on [::GX::moduleIsEnabled [dict get $provider module_id]]]}}
list enabled_but_module_off $rows note [.top.nb.configuration.sections.modules.kinds.viewers.tools.note cget -text]
""")
case('setup-private-Session',r"""file mkdir $probeout/Session/metadata $probeout/Session/channels
set ::GX::currentSession [file normalize $probeout/Session];::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
set token [::GX::interactiveDocumentSessionToken]
""")
case('P007-GUI-029-existing-typed-validator',r"""ttk::frame .legacy;::GX::standardConfigWidget .legacy plot.dataset target_points 0
.legacy.w0.entry delete 0 end;.legacy.w0.entry insert 0 7000.5
set accepted [::GX::uiFieldCommit .legacy.w0]
list typed_frame [winfo class .legacy.w0] accepted $accepted invalid [.legacy.w0.entry instate invalid] inline $::GX::UiField::errors(.legacy.w0) value $::GX::moduleCfg(plot.dataset,target_points)
""")
case('P007-GUI-051-owning-module-query',r"""ttk::frame .top.nb.viewers;canvas .top.nb.viewers.viewport;ttk::frame .top.nb.viewers.viewport.content
set ::GX::ui(viewerQuery) analysis.octave_script;::GX::viewerGuiRefresh
set groups [winfo children .top.nb.viewers.viewport.content];set titles {};foreach g $groups {foreach w [winfo children $g] {if {[winfo class $w] eq {TButton}} {lappend titles [$w cget -text]}}}
list query $::GX::ui(viewerQuery) groups [llength $groups] titles $titles module_on [::GX::moduleIsEnabled analysis.octave_script]
""")
case('P007-GUI-002-after-Storage-layout',r"""file mkdir $probeout/rootA $probeout/exportA $probeout/private
::GX::configurationSet storage.session_root [file normalize $probeout/rootA];::GX::configurationSet storage.export_dir [file normalize $probeout/exportA];::GX::configurationApply
set values {};foreach role [::GX::workspaceProfileFields] {dict set values $role [file normalize $probeout/private]}
::GX::sessionStorageProfileSave test $values;::GX::sessionStorageProfileApply test
::GX::workspaceProfilesRefreshGui
::GX::sessionStorageProfileApply {};::GX::workspaceProfilesRefreshGui
list root [::GX::workspaceInitialDir session_root] export [::GX::workspaceInitialDir export_dir] active [dict get [::GX::sessionStorageProfilesRead] active] storage_canvas [winfo exists .top.nb.configuration.sections.storage.viewport] global_body [winfo exists .top.nb.configuration.sections.storage.viewport.body]
""")
t.destroy();print(json.dumps(rows))
