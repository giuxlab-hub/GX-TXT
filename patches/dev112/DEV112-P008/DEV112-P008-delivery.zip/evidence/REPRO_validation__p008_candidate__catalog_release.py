from pathlib import Path,PurePosixPath
import hashlib,json,sqlite3,sys,os,time,tkinter
old,root,out=map(lambda p:Path(p).resolve(),sys.argv[1:]);out.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={'scope':'Normal final release provenance, not J023 feature work','tables':{}}
connections=[sqlite3.connect((r/'core/api_catalog/catalog.sqlite').as_uri()+'?mode=ro',uri=True) for r in [old,root]]
for c in connections:assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
normalizer=tkinter.Tcl()
def public_payload(value):
 value=normalizer.call('dict','remove',value,'declaration_sha256')
 try:
  row=normalizer.call('dict','get',value,'row')
  row=normalizer.call('dict','remove',row,'declaration_sha256')
  value=normalizer.call('dict','replace',value,'row',row)
 except tkinter.TclError:pass
 try:meta=normalizer.call('dict','get',value,'catalog_meta')
 except tkinter.TclError:return str(value)
 meta=normalizer.call('dict','remove',meta,'declaration_sha256')
 try:
  members=normalizer.splitlist(normalizer.call('dict','get',meta,'source_members'))
  clean=[normalizer.call('dict','remove',member,'declaration_sha256') for member in members]
  meta=normalizer.call('dict','replace',meta,'source_members',tuple(clean))
 except tkinter.TclError:pass
 return str(normalizer.call('dict','replace',value,'catalog_meta',meta))
for table in ['records','declaration_sources','operation_visibility','operation_arguments']:
 data=[c.execute('select * from '+table).fetchall() for c in connections]
 original_equal=sorted(data[0],key=str)==sorted(data[1],key=str)
 if table=='records':data=[[row[:-1]+(public_payload(row[-1]),) for row in rows] for rows in data]
 if table=='declaration_sources':data=[[row[:3]+row[4:] for row in rows] for rows in data]
 data=[sorted(rows,key=str) for rows in data]
 report['tables'][table]={'rows':len(data[1]),'exact_physical_rows':original_equal,'public_fields_equal_excluding_source_hash_provenance':data[0]==data[1]};assert data[0]==data[1],table
for c in connections:c.close()
m=json.loads((root/'core/api_catalog/source_manifest.json').read_text());assert m['database_sha256']==sha(root/'core/api_catalog/catalog.sqlite')
errors=[]
for name,entry in m['files'].items():
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
 target=root/name;actual=sha(target) if target.is_file() and not target.is_symlink() else None
 if entry['sha256']!=actual:errors.append(name)
assert not errors,errors
report['manifest']={'sha256':sha(root/'core/api_catalog/source_manifest.json'),'database_sha256':m['database_sha256'],'source_members':len(m['files']),'all_declared_source_hashes_match':True,'fingerprint':m['fingerprint']}
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
a=tkinter.Tcl();a.call('set','argv0','__p008_release_catalog__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
a.eval('proc ::p008CatalogDone {response} {set ::p008CatalogResponse $response}')
def wait_request():
 started=time.monotonic()
 while not int(a.call('info','exists','::p008CatalogResponse')):
  a.eval('update');time.sleep(.01)
  assert time.monotonic()-started<45,'Catalog callback timeout'
 response=a.call('set','::p008CatalogResponse');assert int(a.call('dict','get',response,'ok'))==1,str(response)
 status=a.call('::GX::apiCatalogStatus')
 record={k:str(a.call('dict','get',status,k)) for k in ['freshness','error','progress','request_active','source_manifest_fingerprint','loaded_packaged_database_sha256']}
 assert record['freshness']=='current' and record['error']=='' and record['progress']=='complete' and record['request_active']=='0',record
 return record
try:
 a.call('::GX::apiCatalogRequest','::p008CatalogDone');report['cold_startup']=wait_request()
 a.call('unset','::p008CatalogResponse');a.call('::GX::apiCatalogRefresh','::p008CatalogDone');report['normal_refresh']=wait_request()
 result=a.call('::GX::apiCatalogQuery',('limit',5));report['public_query_rows']=len(a.splitlist(a.call('dict','get',result,'rows')))
 assert report['public_query_rows']==5
 report['staging_directories']=[str(p.relative_to(out)) for p in out.rglob('stage.*')];assert not report['staging_directories']
 report['result']='PASS'
finally:a.call('::GX::apiCatalogClose')
(out/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
