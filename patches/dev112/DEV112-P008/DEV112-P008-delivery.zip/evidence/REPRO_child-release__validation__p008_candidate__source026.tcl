package require Tk
set root [lindex $argv 0]
set out [lindex $argv 1]
namespace eval ::GX {}
set ::GX::scriptDir $root
source [file join $root core tcl configuration_api_v1.tcl]
source [file join $root core tcl source_surface_api_v1.tcl]
# Fixture hooks only: tooltip/editing integration outside styling scope.
proc ::GX::native2DViewportTooltip {args} {}
proc ::GX::uiTextEditingAttach {args} {}
proc ::GX::scriptJobRequestCancel {id} {after cancel $id}
proc ::GX::scriptJobAsync {command input callback options} {
    return [after 160 [list ::fixtureComplete $command $input $callback]]
}
proc fixtureComplete {command input callback} {
    if {[catch {exec {*}$command << $input} response]} {set response [dict create ok 0 error $response]}
    uplevel #0 [list {*}$callback $response]
}
proc check {name value} {puts [list CHECK $name $value];if {!$value} {error "Check failed: $name"}}
proc settle {} {set ::settled 0;after 600 {set ::settled 1};vwait ::settled;update idletasks}
proc tags {p} {return [expr {[llength [$p.text tag ranges source_keyword]]>0}]}
proc bgerror {message} {puts stderr "BGERROR: $message";set ::failed 1}
after 20000 {puts stderr TIMEOUT;exit 2}
set ::failed 0
if {[catch {
    set ::GX::configurationValues {source.theme {Readable Light} source.highlight.python 1 source.highlight.octave 1}
    foreach category {background foreground selection caret gutter breakpoint current_line search comment string escape keyword definition builtin number constant bridge decorator tag attribute identifier} {dict set ::GX::configurationValues source.color.$category {}}
    dict for {key value} $::GX::configurationValues {dict set ::GX::configurationSchema $key [dict create type string default $value scope user]}
    foreach p {.top .top.nb .top.nb.configuration .top.nb.configuration.sections .top.nb.configuration.sections.appearance .top.nb.configuration.sections.appearance.canvas .top.nb.configuration.sections.appearance.canvas.content .top.nb.configuration.sections.appearance.canvas.content.source} {ttk::frame $p}
    set base .top.nb.configuration.sections.appearance.canvas.content.source
    foreach language {python octave} {
        ::GX::sourceSurfaceCreate $base.$language [dict create mode read_only language $language]
        ::GX::sourceSurfaceSet $base.$language "def sample():\n    return 42\n"
    }
    ::GX::sourceSurfaceCreate .editor {mode editable language python}
    pack .editor -fill both -expand 1
    set original "def real_editor():\n    return 7\n"
    ::GX::sourceSurfaceSet .editor $original
    settle
    check editor_initial_tags [tags .editor]
    check editor_initial_source [expr {[::GX::sourceSurfaceGet .editor] eq $original}]
    set prior $::GX::configurationValues
    set ::GX::configurationUi(source.highlight.python) 0
    set ::GX::configurationUi(source.highlight.octave) 0
    ::GX::sourceSurfaceAppearancePreview
    check sample_captured_draft_off [expr {!$::GX::SourceSurface::state($base.python,highlightEnabled)}]
    check committed_configuration_restored [expr {$::GX::configurationValues eq $prior}]
    # Delayed native completion occurs after committed global values restored.
    settle
    check sample_off_no_keyword_tags [expr {![tags $base.python]}]
    check sample_off_model_ready [::GX::sourceSurfaceReady $base.python]
    check editor_remains_highlighted [tags .editor]
    check editor_mode_preserved [expr {[.editor.text cget -state] eq {normal}}]
    check sample_readonly_preserved [expr {[$base.python.text cget -state] eq {disabled}}]
    set ::GX::configurationUi(source.highlight.python) 1
    set ::GX::configurationUi(source.highlight.octave) 1
    ::GX::sourceSurfaceAppearancePreview
    settle
    check sample_on_keyword_tags [tags $base.python]
    check sample_original_bytes [expr {[::GX::sourceSurfaceGet $base.python] eq "def sample():\n    return 42\n"}]
    .editor.text insert end {# local draft}
    check editor_editable [expr {[string first {# local draft} [::GX::sourceSurfaceGet .editor]]>=0}]
    .editor.text edit undo
    check editor_undo_preserved [expr {[::GX::sourceSurfaceGet .editor] eq $original}]
    check editor_source_unchanged [expr {[::GX::sourceSurfaceGet .editor] eq $original}]
    check no_background_errors [expr {!$::failed}]
} message options]} {
    puts stderr $message
    puts stderr [dict get $options -errorinfo]
    destroy .
    exit 1
}
puts {RESULT PASS}
destroy .
exit 0
