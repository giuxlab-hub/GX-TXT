import os,sys,json,traceback
from pathlib import Path
import tkinter
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();t.withdraw();a=t.tk;a.call('set','argv0','__p008_validator__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
rows=[]
def case(id,script):
 try: rows.append(dict(id=id,result=a.eval(script)))
 except Exception as e: rows.append(dict(id=id,error=str(e),trace=a.eval('set errorInfo')))
 (out/'RESULT.json').write_text(json.dumps(rows,indent=2))
a.call('set','probeout',str(out))
case('P007-GUI-022-absent-scan',r"""ttk::notebook .cache;::GX::cacheStoragePanelBuild .cache
::GX::resourceManagementObserve [file normalize $probeout/absent] p008_fixture {category unknown_legacy}
set inventory [::GX::resourceManagementInventory 1];::GX::cacheStoragePanelLoaded 0 $inventory
list summary $::GX::CacheStorage::ui(summary) status $::GX::CacheStorage::ui(status)
""")
case('P007-GUI-022-refused-after-good-scan',r"""file mkdir $probeout/guarded;file attributes $probeout/guarded -permissions 0700
set f [open $probeout/guarded/payload.txt w];puts -nonewline $f 123456789012345678901234567890;close $f
::GX::resourceManagementObserve [file normalize $probeout/guarded] p008_fixture {category unknown_legacy}
file attributes $probeout/guarded -permissions 0770
set inventory [::GX::resourceManagementInventory 1];::GX::cacheStoragePanelLoaded 0 $inventory
set record {};foreach row [dict get $inventory resources] {if {[dict get $row path] eq [file normalize $probeout/guarded]} {set record $row}}
set permissions [file attributes $probeout/guarded -permissions]
file attributes $probeout/guarded -permissions 0700
list scan_error [dict get $record scan_error] retained_bytes [dict get $record bytes] retained_files [dict get $record count] eligible [dict get $record eligible] permissions_before_fixture_restore $permissions summary $::GX::CacheStorage::ui(summary) status $::GX::CacheStorage::ui(status)
""")
case('P007-GUI-022-whole-inventory-failure',r"""::GX::cacheStoragePanelLoaded 1 {Synthetic bounded failed inventory}
list summary $::GX::CacheStorage::ui(summary) status $::GX::CacheStorage::ui(status)
""")
t.destroy();print(json.dumps(rows))
