import hashlib,json,os,shutil,stat,struct,subprocess,sys,zipfile
from pathlib import Path
stage,source,receipt,out=map(Path,sys.argv[1:]);out.mkdir(mode=0o700)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(root):
 return {str(p.relative_to(root)):(sha(p),p.stat().st_mode,p.stat().st_size,p.stat().st_ino,p.stat().st_mtime_ns,p.stat().st_ctime_ns) for p in root.rglob('*') if p.is_file()}
copy=out/'copied-framework';shutil.copytree(source,copy,copy_function=shutil.copy2)
records=[]
def refuse(name,root=copy,archive=None,extra=()):
 archive=archive or stage/'DEV112-P008.zip';before=snapshot(root)
 argv=[sys.executable,'-I','-B',str(stage/'apply.py'),str(root),str(archive),*extra]
 p=subprocess.run(argv,capture_output=True,timeout=1200,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 (out/(name+'-stdout.txt')).write_bytes(p.stdout);(out/(name+'-stderr.txt')).write_bytes(p.stderr)
 (out/(name+'-command.json')).write_text(json.dumps(argv)+'\n')
 assert p.returncode!=0 and before==snapshot(root),(name,p.returncode,p.stderr)
 records.append({'case':name,'result':'PASS_REFUSED_NO_WRITES','returncode':p.returncode,'diagnostic':p.stderr.decode()})
raw=json.loads(receipt.read_text());flags=['--rollback','--route','post-p007','--stopped','--owner-authorized']
refuse('copied-root',extra=[*flags,'--receipt',str(receipt),'--receipt-sha256',sha(receipt)])
# Separate synthetic receipt points at new copy but retains authentic source marker instance.
stale=out/'stale-instance-receipt.json';stale.write_text(json.dumps(dict(raw,framework_root=str(copy)))+'\n')
refuse('stale-installation-instance',extra=[*flags,'--receipt',str(stale),'--receipt-sha256',sha(stale)])
wrong=out/'wrong-archive-receipt.json';wrong.write_text(json.dumps(dict(raw,framework_root=str(copy),archive_sha256='0'*64))+'\n')
refuse('wrong-receipt-content',extra=[*flags,'--receipt',str(wrong),'--receipt-sha256',sha(wrong)])
unknown=out/'unknown-source-framework';shutil.copytree(source,unknown,copy_function=shutil.copy2)
(unknown/'app/p008_unshipped_inert.py').write_bytes(b'# Inert unknown-source guard fixture; never executed.\n')
refuse('unknown-unshipped-source',root=unknown,extra=['--check'])
archive=stage/'DEV112-P008.zip';original=archive.read_bytes()
with zipfile.ZipFile(archive) as z:
 info=z.getinfo('PATCH_LEVEL.txt');central=z.start_dir
# Locate exact central entry without relying on compressed payload byte patterns.
pos=central
while original[pos:pos+4]==b'PK\x01\x02':
 n,e,c=struct.unpack_from('<HHH',original,pos+28);name=original[pos+46:pos+46+n]
 if name==b'PATCH_LEVEL.txt':break
 pos+=46+n+e+c
assert name==b'PATCH_LEVEL.txt'
for case in ['checksum-mismatch','unsafe-path','undeclared-missing-member','symlink-mode','oversized-member']:
 dst=out/(case+'.zip');b=bytearray(original)
 if case in ['unsafe-path','undeclared-missing-member']:
  name2=(b'../'+b'x'*(len(name)-3)) if case=='unsafe-path' else b'X'+name[1:]
  b[pos+46:pos+46+len(name)]=name2
  b[info.header_offset+30:info.header_offset+30+len(name)]=name2
 elif case=='symlink-mode':struct.pack_into('<I',b,pos+38,(stat.S_IFLNK|0o755)<<16)
 elif case=='oversized-member':struct.pack_into('<I',b,pos+24,64*1024*1024+1)
 dst.write_bytes(b)
 Path(str(dst)+'.sha256').write_text(('0'*64 if case=='checksum-mismatch' else sha(dst))+'  '+dst.name+'\n')
 refuse(case,archive=dst,extra=['--check'])
(out/'RESULT.json').write_text(json.dumps({'result':'PASS','cases':records},indent=2)+'\n');print('Extra negatives PASS',len(records),flush=True)
