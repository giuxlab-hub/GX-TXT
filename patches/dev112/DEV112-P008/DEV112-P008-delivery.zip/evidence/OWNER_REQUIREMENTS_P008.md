# GX-TXT DEV112 — P008 GUI requests (Groups A and B)

**Document purpose:** Record the requested corrections and GUI-only improvements carried forward from the original P007 backlog. This is a **requirements list only**, not an implementation plan, validation plan, agent assignment, release procedure, or scheduling decision.

**Reference baseline:** The delivered cumulative **DEV112-P007** (`a10f5a99fdab93e251efe9c415d5ad76d14c5259`). Original issue identifiers are retained for traceability and do **not** indicate that the issue is still present in P007.

## A — Previously reproduced GUI defects: verify on P007 before making any correction

**Mandatory rule for every A item:** The historical finding came from an earlier GX-TXT installation, principally DEV112 with P001–P004. The agent must first determine whether the **same actual defect still exists in the delivered P007**. Correct it **only if it still exists**. If P007 already behaves correctly, if the original observation was environment-specific, or if the behavior has been intentionally superseded, do not change working code merely to reproduce an obsolete UI design. Preserve current functions, configuration, scientific data, Session ownership, menu structure, and existing manuals. Use the smallest necessary correction rather than redesigning the component.

The items below retain their historical `P007-GUI` IDs; for the P008 request they are **verification-and-conditional-correction requirements**, not assertions of present P007 defects.

### A1. Storage and system diagnostics

- **P007-GUI-002 — Storage Profile effective values (C02).** Check whether clearing a private Storage Profile can leave private Session root/export paths effective while the GUI displays the Global profile. If still reproducible, reconcile the displayed profile and actual effective paths, especially during Save, New Session, and Export. Do not migrate or modify existing Sessions or data.
- **P007-GUI-011 — Native 3D diagnostic text clipping (C12).** Check whether multiline runtime diagnostic information is clipped or unreachable in ordinary-sized windows. If still present, make the existing diagnostic readable through an appropriately sized, scrollable, or responsive presentation. Continue to distinguish *estimated* GPU memory from actual measurements.

### A2. Backup, Run, and results

- **P007-GUI-025 — Stale Backup & Restore preview (C24).** Check whether changing the inclusion policy between Include and Exclude leaves an earlier backup preview appearing current. If so, invalidate the obsolete presentation or clearly mark it as stale. Keep the existing backup-plan safeguards and do not let an obsolete preview misrepresent the current selection.
- **P007-GUI-028 — Misleading Run/Analysis readiness (M04/M11).** Check whether selected analysis modules appear `PENDING` or `ready` despite missing required canonical Dataset inputs. If still misleading, make the UI distinguish selected/configured modules from scientifically valid inputs, using the existing source validation behavior. Do not create another scheduler or scientific validation system.
- **P007-GUI-032 — Results `Next 500` pagination (M12).** Check whether `Next 500` can remain active when the displayed page already contains all results, allowing navigation to an impossible empty range such as `501–500`. If so, correct the page bounds and navigation state while retaining the existing 500-row paging model and result identities.

### A3. Graphics configuration and Cancel/Close behavior

- **P007-GUI-030 — Module Graphics Cancel does not discard a draft (M09).** Check whether changing the `Override global graphics` option and pressing Cancel can leave the change active in memory without a committed Save. If still reproducible, restore the established distinction between draft and committed settings; do not add a new configuration layer.
- **P007-GUI-034 — Plot Presentation/Graphics Close retains an unapplied change (M14).** Check whether editing a graphics setting (historical example: width `1600` to `1608`) and closing without Apply modifies the in-memory configuration. If so, correct the original Apply/Close behavior without redesigning the Plot configuration UI or altering scientific Plot data.

### A4. Print / PDF Studio

**Special caution:** The Print/PDF Studio changed substantially after the original P004 audit. Each item below must first be compared with the *actual P007 Print/PDF Studio and its intended current workflow*. Do not restore obsolete controls, callbacks, or composition rules from the earlier version merely because an old observation exists.

- **P007-GUI-036 — Hidden source remains actionable (M16).** Check whether a Dataset hidden by a content filter can remain the internal selected source and leave **Add selected content** enabled when the visible selection is empty. If so, reconcile selected identity and action availability with the visible source list, without touching the Dataset itself.
- **P007-GUI-037 — Previous Session content rows remain visible (M17–M19).** Check whether ordered content rows from an earlier Session can remain visible after switching to a composition whose effective recipe contains no items. If so, correct the stale presentation and prevent actions on the previous Session's rows.
- **P007-GUI-038 — Page Setup shows settings from a different composition (M18).** Check whether page size, orientation, or Poster layout shown in the interface differs from the effective recipe after a Session switch (historically A4/portrait/2×2 displayed while A3/landscape/1×2 was effective). If so, reconcile the controls with the authoritative active composition.
- **P007-GUI-039 — Page Setup displayed value and committed value disagree (M18).** Check whether a programmatic recipe refresh leaves the visible field and its UIField committed baseline inconsistent, so choosing a value already displayed does not apply it. If still reproducible, correct this binding within the existing composition/UIField ownership, including normal Save/History behavior.
- **P007-GUI-041 — Previous Session PDF destination remains visible (M19).** Check whether the export destination label continues to display a private Session's PDF path after returning to another Session and starting a new composition. If so, clear or rebind the stale destination, avoiding misleading cross-Session information.

### A5. Session Files and Raw INI

- **P007-GUI-043 — Stale file preview after Refresh (M20).** Check whether Refresh clears the selected file but leaves its text visible and **Copy file text** available. If so, reconcile the preview and Copy action with the actual current selection; do not modify the file contents.
- **P007-GUI-044 — Previous Session text remains in Session Files (M20).** Check whether switching Sessions can leave a Markdown note from the former private Session visible or copyable while the file tree already belongs to the new Session. If so, enforce correct GUI text identity and Session rebind; do not weaken the existing file-navigation guards.
- **P007-GUI-046 — Copy action targets the wrong text surface (M24).** Check whether **Copy file text** while Raw INI is active copies the Session Files preview (potentially empty) rather than the relevant visible content. If so, make the action's target and label consistent with the active view, preserving ordinary Ctrl+C and the read-only INI behavior.

### A6. Instrumentation, Help, and result labels

- **P007-GUI-050 — Instrumentation Notes summary does not refresh (M27).** Check whether a successful Notes Save persists the text but leaves the main instrument Notes summary displaying an old or empty value until manual Refresh. If so, notify/reconcile the original summary presentation after Save.
- **P007-GUI-052 — Generated About cannot be opened (M32).** Check whether the Help browser can read `core:about` but its **Show** action fails because the generated document has no backing Markdown file. If so, correct the existing generated-content display route without bypassing document navigation guards.
- **P007-GUI-053 — LICENSE cannot be opened (M32).** Check whether the indexed, readable `core:license` item fails to open because its plain-text content is incorrectly required to be Markdown. If so, apply the appropriate existing content-type presentation behavior.
- **P007-GUI-055 — Incorrect `plot.dataset` version in output (M33).** Check whether a generated `plot_summary.txt` identifies a historical module version that differs from the actual installed producer and Run plan. If still present, correct the *reported version/provenance label only*; the original numerical calculation was not reported as failing.
- **P007-GUI-057 — Unsupported export appears enabled in Dataset Variables Help (M39).** Check whether **Export current view as text…** is enabled on the Variables Help section even though its callback rejects that section. If so, align the available action with the actual supported content: disable a genuinely unsupported export or route it through an existing legitimate export operation. Do not change Dataset science.

## B — Explicitly requested GUI-only improvements

These two requests are **presentation and user-interaction changes**. They do not authorize changes to scientific execution, plugin installation logic, Viewer activation semantics, the Registry, or underlying public API contracts. Keep the existing menu organization and workflows wherever possible.

### B1. P007-GUI-017 — Put the package chooser directory in Plugin Manager

- Remove the **Default plugin package directory** editor from the general **Configuration → Modules** surface, where its placement is misleading.
- Present the **same preference**, clearly labeled and editable, with a **Browse** control inside the existing **Plugin Manager** dialog, alongside the package Install/Update workflow.
- Continue using the **existing** `plugins.package_chooser_directory` setting and its established user-scope persistence and validation; do not introduce a second setting or configuration owner.
- Preserve the existing chooser-folder fallback order: configured folder → home directory → current working directory.
- The setting controls **only the initial folder of ZIP/INI file selection**. It must not become a plugin installation destination, Viewer discovery directory, or search path.
- Preserve the existing Install/Update operations, package identities, registry contents, and management of already-installed plugins. Normal saved value, unsaved draft, Browse, Cancel and reopening behavior must remain coherent.

### B2. P007-GUI-018 — Search Viewers within the existing Viewer Manager

- Add a **Search viewers** input to **Configuration → Modules → Viewers**, within the existing Viewer Manager subtab.
- Filter the **existing Viewer rows** interactively using visible title, Viewer ID, owning Module ID, and category.
- Default to displaying all Viewers. Clearing or resetting the query must restore the complete list; an empty result must be represented clearly.
- The filter is **view-only**. It must never change Viewer enabled/disabled state, owning Module ON/OFF state, provider availability, Registry, saved Configuration, or Workspace data.
- Preserve the current **Enable**, **Disable**, and **Refresh** operations. These actions must operate only on a real, currently visible selection; if filtering hides the selected Viewer, clear or safely reconcile the selection before an action can be performed. Refresh must respect the current query.
- An optional **All / Enabled / Disabled** display filter may be included **only if** it reuses the same Viewer list without creating another manager or expanding the underlying behavior.
- Preserve existing keyboard operation and compact-window usability. Do not redesign Viewer activation or modify Curve Digitalizer.

## Scope boundary

This document contains **Group A (historically reproduced GUI defects requiring recheck on P007)** and **Group B (the two explicitly requested GUI-only improvements)** only. It does not assign work on Group C (`P007-GUI-016`, the separate comprehensive 2D/3D Plot-window campaign), HTML guide packaging, MCP Server, Scientific LaTeX public APIs, or the shared Python/Octave editor API. Other historical observations and unconfirmed UX candidates remain in the original backlog and are **not silently declared resolved** by this list.

**Original reference documents:**

- `GXTXT_P007_GUI_AUDIT_REMEDIATION_LEDGER.md` — original GUI observations and their historical status.
- `GXTXT_DEV112_P007_OWNER_TASKS.md` — source of the two explicit GUI improvements and the conservative boundaries.

This file records **what is requested**. Detailed implementation organization and independent validation are deliberately left for a separate decision.
