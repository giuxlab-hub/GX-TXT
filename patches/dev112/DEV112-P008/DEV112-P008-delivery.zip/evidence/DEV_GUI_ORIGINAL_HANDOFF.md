# P008 GUI component handoff to MAIN

Cherry-pick commit **a74042618d0e652e0df87c1e82fef02da23f0998** from the independent
clone `/srv/gxtxt/agents/scratch/DEV112-P008-DEV-GUI-20261112/framework`.
Branch `dev112-p008-dev-gui`; clean after commit. Base is exact delivered P007
`a10f5a99fdab93e251efe9c415d5ad76d14c5259`.

The committed `validation/dev112_p008_gui/AUTHOR_RESULTS.md` supplies every original
ID's exact baseline observation and disposition. FIXED: 036,039,041,043,044,046,
052,053,057. NOCHANGE: 037,038. No old Print controls or composition rules restored.

Product files:
- `app/print_studio_controller.tcl`: visible source identity/action reconciliation;
  existing typed UIField baseline adoption with guarded own callback and exact
  recipe representation preservation; exported path label reset on document clear.
- `core/tcl/session_file_explorer_api_v1.tcl`, `core/tcl/dataset_notes_api_v1.tcl`,
  `app/sessions_page_redesign.tcl`: retire preview/navigation on tree rebuild or
  empty/directory selection; Copy identity guard and active Raw INI route/label.
- `app/gui/documentation_browser.tcl`: render generated About without file-backed
  navigation; indexed plain text LICENSE displayed verbatim; Markdown guards stay.
- `app/dataset_page_actions.tcl`, `app/gui/dataset_browser.tcl`,
  `app/gui/dataset_preview_sync.tcl`: existing export menu follows supported content.

Evidence directories are siblings of this HANDOFF. `baseline01/results.json` is
pre-edit real Tk evidence for every ID. `baseline04` reruns pristine original P007
from a new own archive extraction with original permission modes; includes actual
7,925-byte Print Preview→PDF export and stale path label after Session switch/New.
`fixed03` contains the matching real PDF export and all corrected ID observations;
its later extended assertion failed because the fixture assumed Undo after Save
must skip directly to initial paper. Final `fixed04` exits 0 and verifies all IDs,
Save/readback, unchanged History on refresh, authoritative Undo/Redo UI bindings,
normal file Copy/Ctrl+C, directory clearing, structured/Raw INI routing, retained
Markdown navigation refusals, exact LICENSE text and supported export menu states.
Both final and baseline receipts show zero Tcl background errors.

All initial failed fixture evidence remains (baseline02 managed ImageMagick archive
mode rejection; baseline03/fixed02 Tk empty-value conversion). The local script
catalog records execution scopes, arguments, effects and finite timeouts. No owner
installation, original Session/data, protected module, requirement document or
historical source was changed. Private synthetic Sessions are disposable evidence.
The extraction under `baseline_framework` is pristine P007, not an installation.

`SOURCE_AND_EVIDENCE_SHA256.json` pins changed candidate/original sources and JSON
receipts. MAIN alone updates its acceptance matrix, integrates, accepts and deposits;
author checks do not substitute for independent GUI/technical validation.
