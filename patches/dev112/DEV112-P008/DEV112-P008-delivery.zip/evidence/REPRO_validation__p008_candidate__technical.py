import os,sys,json,traceback
from pathlib import Path
import tkinter
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
for key in ['XDG_CONFIG_HOME','XDG_CACHE_HOME','XDG_DATA_HOME','XDG_STATE_HOME','GXTXT_INSTALLATION_ROOT','GXTXT_JOB_ROOT','GXTXT_RESOURCE_ROOT','GXTXT_RESOURCE_STORAGE','TMPDIR']:
 p=out/key;p.mkdir(mode=0o700);os.environ[key]=str(p)
t=tkinter.Tk();t.withdraw();a=t.tk;a.call('set','argv0','__p008_validator__');a.call('source',str(root/'gxtxt_pipeline.tcl'));a.call('::GX::defaults');a.call('::GX::loadModuleCatalog')
rows=[]
def case(id,script):
 try: rows.append(dict(id=id,result=a.eval(script)))
 except Exception as e: rows.append(dict(id=id,error=str(e),trace=a.eval('set errorInfo')))
 (out/'RESULT.json').write_text(json.dumps(rows,indent=2))
a.call('set','probeout',str(out))
case('P007-GUI-030-draft-lifecycle',r"""rename tk_messageBox original_tk_messageBox;proc tk_messageBox args {lappend ::messages $args;return ok};set ::messages {}
::GX::moduleGraphicsEnsure plot.dataset
set before [array get ::GX::moduleGraphicsOverride]
::GX::moduleGraphicsDialog plot.dataset
proc findVar {w variable} {foreach p [winfo children $w] {foreach option {-textvariable -variable} {if {![catch {$p cget $option} actual] && $actual eq $variable} {return $p}};set result [findVar $p $variable];if {$result ne {}} {return $result}};return {}}
set button [findVar .modulegfx ::GX::moduleGraphicsDraft(plot.dataset,enabled)]
$button invoke
set during [list committed $::GX::moduleGraphicsOverride(plot.dataset,enabled) draft $::GX::moduleGraphicsDraft(plot.dataset,enabled)]
.modulegfx.b.cancel invoke
set cancel [expr {$before eq [array get ::GX::moduleGraphicsOverride]}]
::GX::moduleGraphicsDialog plot.dataset
set ::GX::moduleGraphicsDraft(plot.dataset,aspect_mode) inherit
set ::GX::moduleGraphicsDraft(plot.dataset,width_px) -1
.modulegfx.b.save invoke
set invalid [list retained [winfo exists .modulegfx] unchanged [expr {$before eq [array get ::GX::moduleGraphicsOverride]}]]
set ::GX::moduleGraphicsDraft(plot.dataset,width_px) 1700
set ::GX::moduleGraphicsDraft(plot.dataset,enabled) 1
.modulegfx.b.save invoke
list during $during canceled $cancel invalid $invalid saved_width $::GX::moduleGraphicsOverride(plot.dataset,width_px) saved_enabled $::GX::moduleGraphicsOverride(plot.dataset,enabled) draft_removed [expr {![array exists ::GX::moduleGraphicsDraft]}] messages $::messages
""")
case('P007-GUI-034-draft-lifecycle',r"""set before $::GX::cfg(plot_width_px)
::GX::globalGraphicsDialog
set width [findVar .globalgfx ::GX::globalGraphicsDraft(plot_width_px)]
$width delete 0 end;$width insert 0 1608
set during $::GX::cfg(plot_width_px)
.globalgfx.buttons.cancel invoke
set afterClose $::GX::cfg(plot_width_px)
::GX::globalGraphicsDialog
set ::GX::globalGraphicsDraft(plot_width_px) -1
.globalgfx.buttons.apply invoke
set invalid [list retained [winfo exists .globalgfx] unchanged [expr {$::GX::cfg(plot_width_px)==$before}]]
set ::GX::globalGraphicsDraft(plot_width_px) 1608
.globalgfx.buttons.apply invoke
list before $before during $during closed $afterClose invalid $invalid applied $::GX::cfg(plot_width_px) draft_removed [expr {![array exists ::GX::globalGraphicsDraft]}]
""")
case('setup-public-dataset',r"""file mkdir $probeout/SessionA/metadata $probeout/SessionA/channels $probeout/SessionB/metadata $probeout/SessionB/channels
set ::GX::currentSession [file normalize $probeout/SessionA]
::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
::GX::datasetPublicationV2PublishSeries $::GX::currentSession acq.generic_csv {dataset_id sample contract table.generic storage csv x_values {0 1 2} y_values {3 4 5} x_variable {variable_id x dtype float64 unit s} y_variable {variable_id y dtype float64 unit V}}
""")
case('P007-GUI-036-filter-selection',r"""ttk::frame .top;ttk::notebook .top.nb;ttk::frame .top.nb.print;.top.nb add .top.nb.print
::GX::buildPrintPage;::GX::printStudioCatalogRefresh
$::GX::ui(printContentTree) selection set dataset:sample;::GX::printStudioSourceSelect
set before [::GX::printStudioEnabled add]
set ::GX::PrintStudio::state(query) impossible_no_match
::GX::printStudioCatalogRefresh
set hidden [list selection [$::GX::ui(printContentTree) selection] source $::GX::PrintStudio::state(selectedSource) enabled [::GX::printStudioEnabled add]]
set ::GX::PrintStudio::state(query) {};::GX::printStudioCatalogRefresh
list before $before hidden $hidden reset_source $::GX::PrintStudio::state(selectedSource) reset_enabled [::GX::printStudioEnabled add]
""")
case('P007-GUI-039-refresh-history-save',r"""set recipe $::GX::PrintStudio::state(recipe);dict set recipe page paper A4
::GX::printStudioEdit $recipe {Independent setup fixture}
set field [winfo parent $::GX::ui(printPaper)]
set synced [list visible [$::GX::ui(printPaper) get] committed [dict get $::GX::UiField::widgets $field committed]]
set cursor [dict get $::GX::PrintStudio::state(history) cursor]
::GX::printStudioQueueRefresh
set refreshCursor [dict get $::GX::PrintStudio::state(history) cursor]
set ::GX::cfg(print_page) A3;::GX::uiFieldCommit $field
set applied [dict get $::GX::PrintStudio::state(recipe) page paper]
::GX::printStudioNavigate undo;set undo [dict get $::GX::PrintStudio::state(recipe) page paper]
::GX::printStudioNavigate redo;set redo [dict get $::GX::PrintStudio::state(recipe) page paper]
::GX::printStudioSave
list synced $synced cursor $cursor refresh_cursor $refreshCursor applied $applied undo $undo redo $redo saved_id $::GX::PrintStudio::state(id) saved_matches [expr {$::GX::PrintStudio::state(saved) eq $::GX::PrintStudio::state(recipe)}]
""")
case('P007-GUI-037/038/041-current-Session-owner',r"""set savedA $::GX::PrintStudio::state(id)
set ::GX::PrintStudio::state(outputLabel) /PRIVATE_SESSION_A/export.pdf;set ::GX::cfg(print_output_pdf) /PRIVATE_SESSION_A/export.pdf
set ::GX::currentSession [file normalize $probeout/SessionB]
::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
set refused [catch {::GX::printStudioDocumentSession} reason]
::GX::printStudioNew
list prior_composition_refused $refused reason $reason new_rows [$::GX::ui(printQueue) children {}] paper [$::GX::ui(printPaper) get] recipe_paper [dict get $::GX::PrintStudio::state(recipe) page paper] label $::GX::PrintStudio::state(outputLabel) pdf $::GX::cfg(print_output_pdf) own_token [expr {$::GX::PrintStudio::state(session_token) eq [::GX::interactiveDocumentSessionToken]}]
""")
case('P007-GUI-043/044/046-files-identity',r"""ttk::frame .top.nb.sessionfiles;ttk::frame .top.nb.sessionfiles.bar
 ttk::button .top.nb.sessionfiles.bar.copy -command ::GX::sessionFileExplorerCopy
 ttk::combobox .top.nb.sessionfiles.navigation -values {files scripts workspaces config};.top.nb.sessionfiles.navigation current 0
 ttk::treeview .files;text .filetext;set ::GX::ui(sessionFileTree) .files;set ::GX::ui(sessionFileText) .filetext
set ::GX::currentSession [file normalize $probeout/SessionA]
set f [open $probeout/SessionA/old.md w];puts $f {PRIVATE OLD SESSION NOTE};close $f
::GX::sessionFileExplorerPopulate;.files selection set f:old.md;::GX::sessionFileExplorerOpenSelected
set active [list disabled [.top.nb.sessionfiles.bar.copy instate disabled] text [.filetext get 1.0 end-1c]]
::GX::sessionFileExplorerPopulate
set refreshed [list disabled [.top.nb.sessionfiles.bar.copy instate disabled] text [.filetext get 1.0 end-1c]]
.files selection set f:old.md;::GX::sessionFileExplorerOpenSelected
set ::GX::currentSession [file normalize $probeout/SessionB];::GX::sessionFileExplorerPopulate
set switched [list disabled [.top.nb.sessionfiles.bar.copy instate disabled] text [.filetext get 1.0 end-1c]]
ttk::frame .top.nb.sessionfiles.config;ttk::notebook .top.nb.sessionfiles.config.pages
foreach part {structured raw} {ttk::frame .top.nb.sessionfiles.config.pages.$part;.top.nb.sessionfiles.config.pages add .top.nb.sessionfiles.config.pages.$part}
ttk::treeview .top.nb.sessionfiles.config.pages.structured.tree;text .top.nb.sessionfiles.config.pages.raw.text
::GX::sessionConfigRefresh
.top.nb.sessionfiles.navigation current 3;.top.nb.sessionfiles.config.pages select .top.nb.sessionfiles.config.pages.raw
::GX::sessionFileExplorerCopy
list active $active refreshed $refreshed switched $switched raw_label [.top.nb.sessionfiles.bar.copy cget -text] raw_disabled [.top.nb.sessionfiles.bar.copy instate disabled] copied_visible [expr {[clipboard get] eq [.top.nb.sessionfiles.config.pages.raw.text get 1.0 end-1c]}] raw_readonly [.top.nb.sessionfiles.config.pages.raw.text cget -state]
""")
case('P007-GUI-052/053-Help-routes-guards',r"""ttk::frame .top.nb.help;ttk::frame .top.nb.help.left;ttk::frame .top.nb.help.right;ttk::treeview .top.nb.help.left.tree;text .top.nb.help.right.text
::GX::documentationBrowserRefresh
set result {};foreach id {core:about core:license} {set code [catch {::GX::documentationBrowserShow $id} message];lappend result [list id $id code $code text_bytes [string length [.top.nb.help.right.text get 1.0 end-1c]] font [.top.nb.help.right.text cget -font]]}
lappend result [list forged_refused [catch {::GX::documentationBrowserShow ../../outside.md} error] message $error]
set result
""")
case('P007-GUI-057-menu-availability',r"""set ::GX::currentSession [file normalize $probeout/SessionA];::GX::loadDatasetRegistry $::GX::currentSession
 ttk::frame .top.nb.channels;ttk::frame .top.nb.preview;.top.nb add .top.nb.preview
::GX::buildDatasetPage;set ::GX::variableDatasetChoice {Imported: sample};::GX::refreshNativeVariablesGui
set menu .top.nb.channels.browser.tools.print.menu
set result {};foreach section {help variables metadata notes technical temporal preview} {.top.nb.channels.views select .top.nb.channels.views.$section;::GX::_datasetPageExportMenuRefresh;lappend result [list section $section text_state [$menu entrycget 1 -state]]};set result
""")
case('navigation-path-security',r"""set f [open $probeout/outside.md w];puts $f PRIVATE_OUTSIDE;close $f
list read_escape_refused [catch {::GX::sessionFileExplorerRead $probeout/outside.md} message] message $message
""")
t.destroy();print(json.dumps(rows))
