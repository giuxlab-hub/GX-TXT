import hashlib,json,sys,zipfile
from pathlib import Path
root=Path(sys.argv[1]).resolve();receipt=Path(sys.argv[2]);assert not receipt.exists()
zpath=Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV112-P007-20261112/DEV112-P007.zip')
assert hashlib.sha256(zpath.read_bytes()).hexdigest()=='db4b7457edebc3a01bae244e1bc01db7a785d7348b9d808fb000b7a2d20131b3'
with zipfile.ZipFile(zpath) as z: manifest=json.loads(z.read('patch_notes/DEV112-P007/FILES.json'))
changed=[]
for name,entry in manifest['postimage'].items():
 p=root/name
 if not p.is_file() or p.is_symlink():continue
 prior=p.stat().st_mode&0o777
 if prior!=entry['mode']:p.chmod(entry['mode']);changed.append([name,prior,entry['mode']])
for p in root.rglob('*'):
 if p.is_file() and not p.is_symlink() and str(p.relative_to(root)) not in manifest['postimage']:
  prior=p.stat().st_mode&0o777;target=0o755 if prior&0o111 else 0o644
  if prior!=target:p.chmod(target);changed.append([str(p.relative_to(root)),prior,target])
receipt.write_text(json.dumps({'root':str(root),'mode_corrections':changed,'bytes_changed':False},indent=2)+'\n');print(len(changed))
