import ast,hashlib,importlib.util,json,stat,subprocess,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];STAGE=Path('/srv/gxtxt/agents/scratch/DEV112-P008-MAIN-20261112/stage01');REPO='/srv/gxtxt/agents/scratch/DEV112-P008-MAIN-20261112/framework'
PIN='f691b0f6e1016cb9af3db30ba3d1c8b5ea91429c';POST='ca61f1775cb95b253ed79a1b34eddb6be2c6439aae40d2a7acd4b246cead9b3c'
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(d):return json.dumps(d,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
pins={'DEV112-P008.zip':'fc931c33cbc9c390b71c5ea3e68bb67de3ce0b4c1252012711d5245bdf7c35ff','FILES.json':'cb2449c05c2fd64577b994f795a177cb9221a457b7fedd9c9d129ea59a09033c','apply.py':'256870b075a75da09053dfff1339be303ef46bada7185eb2c7c0813b4290e988'}
for n,p in pins.items():assert sha((STAGE/n).read_bytes())==p
spec=importlib.util.spec_from_file_location('final_apply',STAGE/'apply.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
routes,post,payload,data,archive_sha=m.archive_read(STAGE/'DEV112-P008.zip')
assert sha(canonical(post))==POST and len(post)==6403
expected_routes=json.loads((ROOT/'release-baselines01/EXPECTED_ROUTES.json').read_text());assert routes==expected_routes
raw=(STAGE/'FILES.json').read_bytes();manifest=json.loads(raw)
with zipfile.ZipFile(STAGE/'DEV112-P008.zip') as z:
 assert z.read(m.NOTES+'/FILES.json')==raw and z.read(m.NOTES+'/apply.py')==(STAGE/'apply.py').read_bytes()
 infos=z.infolist();count=len(infos);total=sum(i.file_size for i in infos);maximum=max(i.file_size for i in infos)
 # Independent member identity verification in addition to actual owner reader.
 expected={p:post[p] for p in payload}
 for route,before in routes.items():
  for p in payload:
   if p in before and before[p]!=post[p]:expected[m.NOTES+'/preimages/'+route+'/'+p]=before[p]
 for p,e in expected.items():
  b=z.read(p);i=z.getinfo(p);assert {'sha256':sha(b),'size':len(b),'mode':stat.S_IMODE(i.external_attr>>16)}==e
 assert count==len(expected)+len(m.NOTE_FILES)
 for i in infos:
  p=Path(i.filename);assert not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename
  assert stat.S_ISREG(i.external_attr>>16) and stat.S_IMODE(i.external_attr>>16) in {0o644,0o664,0o755}
tree={}
for row in subprocess.check_output(['git','-C',REPO,'ls-tree','-rz',PIN]).split(b'\0'):
 if row:
  meta,name=row.split(b'\t');mode,typ,oid=meta.decode().split();assert typ=='blob';tree[name.decode()]=(mode,oid)
assert set(tree)==set(post),(len(tree),len(post),set(tree)^set(post))
requests=''.join(v[1]+'\n' for v in tree.values()).encode();blobs=subprocess.check_output(['git','-C',REPO,'cat-file','--batch'],input=requests);offset=0
for p,(mode,oid) in tree.items():
 end=blobs.index(b'\n',offset);header=blobs[offset:end].decode().split();size=int(header[2]);offset=end+1;b=blobs[offset:offset+size];offset+=size+1
 assert header[:2]==[oid,'blob'] and sha(b)==post[p]['sha256'] and size==post[p]['size'],p
 want=expected_routes['post-p007'].get(p,{}).get('mode',0o755 if mode=='100755' else 0o644)
 assert post[p]['mode']==want,p
 assert bool(want&0o111)==(mode=='100755'),p
reviewed=(ROOT/'validation/p008_release_prep/apply_p008_template_reviewed.py').read_bytes();actual=(STAGE/'apply.py').read_bytes()
expected_helper=reviewed.replace(b'0'*64,pins['FILES.json'].encode()).replace(b"                        'validation/dev112_p008_bis_main/SCRIPT_CATALOG.md',",b"                        'validation/dev112_p008_gui_followup/AUTHOR_RESULTS.md',\n                        'validation/dev112_p008_gui_followup/SCRIPT_CATALOG.md',\n                        'validation/dev112_p008_gui_followup/check.py',\n                        'validation/dev112_p008_bis_main/SCRIPT_CATALOG.md',")
assert actual==expected_helper,'Unexpected helper algorithm change'
record={'result':'PASS','source_commit':PIN,'pins':pins,'canonical_postimage_sha256':POST,'postimage_files':len(post),'payload_files':len(payload),'payload_plus_preimage_members':len(expected),'zip_members':count,'archive_uncompressed_bytes':total,'largest_member_bytes':maximum,'all_zip_crc_and_member_bytes_modes':'PASS','safe_paths_modes_bounds':'PASS','embedded_manifest_installer_exact':'PASS','all_final_Git_blobs_correspond':'PASS','P007_existing_and_Git_new_modes':'PASS','final_helper_reviewed_algorithms_plus_manifest_pin_and_three_exact_followup_allowlist_entries':'PASS','route_inventory_sha256':{r:sha(canonical(v)) for r,v in routes.items()},'apply_executed':False}
(ROOT/'evidence/final-preflight.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
w=json.loads((ROOT/'WORK_STATE.json').read_text());w.update(status='final_stage_preflight_pass_four_route_running',final_source=PIN,final_preflight='evidence/final-preflight.json',next='Authorized four-route actual stage tests, then distinct negative fixtures');(ROOT/'WORK_STATE.json').write_text(json.dumps(w,indent=2)+'\n')
