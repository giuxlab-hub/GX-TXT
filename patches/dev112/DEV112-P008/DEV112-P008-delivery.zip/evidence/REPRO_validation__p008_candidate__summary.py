from pathlib import Path
import subprocess,sys,json
root=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve();out.mkdir()
q=lambda p:"'"+str(p).replace("'","''")+"'"
script="addpath("+q(root/'core/octave/io')+");addpath("+q(root/'plugins/modules/plot.dataset/runtime')+");\ninfo=struct('dataset_id','sample','source_path','synthetic.csv','x','x','y','y','z','','family','','color','');\nopts=struct('reduction_mode','none','target_points',3,'auto_reduce_threshold',1000,'chunk_rows',3);M=struct('prepared_3d',false);\npd_write_summary("+q(out/'plot_summary.txt')+",info,opts,M,{},struct());\n"
(out/'case.m').write_text(script);p=subprocess.run(['octave-cli','--quiet','--no-gui',str(out/'case.m')],capture_output=True,text=True,timeout=30);(out/'octave.log').write_text(p.stdout+p.stderr);assert p.returncode==0
actual=(out/'plot_summary.txt').read_text().splitlines();before=(Path(__file__).resolve().parents[2]/'baseline_summary01/plot_summary.txt').read_text().splitlines();assert len(actual)==len(before);assert actual[1]=='Module: plot.dataset 4.4.1';assert actual[:1]+actual[2:]==before[:1]+before[2:]
result={'result':'PASS','actual_version':actual[1],'other_diagnostic_lines_identical_to_P007':True,'numerical_execution':False};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
