"""Independent, read-only P007 identity checks; never execute installer."""
import hashlib
import json
import stat
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FW = ROOT / 'framework'
ARCH = Path('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV112-P007-20261112')
HEAD = 'a10f5a99fdab93e251efe9c415d5ad76d14c5259'
NOTE = 'patch_notes/DEV112-P007/'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', '-C', str(FW), *args])
def ident(data, mode):
    return dict(sha256=sha(data), size=len(data), mode=mode)

result = {'expected_head': HEAD, 'actual_head': git('rev-parse', 'HEAD').decode().strip(),
          'git_status': git('status', '--porcelain=v1', '--untracked-files=all').decode(),
          'archive_checksums': {}, 'errors': [], 'checks': {}}
errors = result['errors']
if result['actual_head'] != HEAD or result['git_status']:
    errors.append('HEAD mismatch or dirty framework')
for line in (ARCH / 'DELIVERY_SHA256SUMS').read_text().splitlines():
    expected, name = line.split(maxsplit=1)
    name = name.lstrip('*')
    actual = sha((ARCH / name).read_bytes())
    result['archive_checksums'][name] = actual
    if expected != actual:
        errors.append('delivery checksum: ' + name)
tree = {}
for item in git('ls-tree', '-r', '-z', HEAD).split(b'\0'):
    if item:
        meta, path = item.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        tree[path.decode()] = (mode, kind, oid)
with zipfile.ZipFile(ARCH / 'DEV112-P007.zip') as z:
    manifest_raw = z.read(NOTE + 'FILES.json')
    manifest = json.loads(manifest_raw)
    result['manifest_sha256'] = sha(manifest_raw)
    result['route_inventory_counts'] = {k: len(v) for k, v in manifest['routes'].items()}
    result['postimage_count'] = len(manifest['postimage'])
    result['payload_count'] = len(manifest['payload'])
    installer = (ARCH / 'DEV112-P007-apply.py').read_bytes()
    result['installer_sha256'] = sha(installer)
    if installer != z.read(NOTE + 'apply.py'):
        errors.append('external/embedded installer mismatch')
    if ("MANIFEST_SHA256 = '" + sha(manifest_raw) + "'").encode() not in installer:
        errors.append('installer manifest binding mismatch')
    expected_members = {}
    for path in manifest['payload']:
        expected_members[path] = manifest['postimage'][path]
    for route, before in manifest['routes'].items():
        for path in manifest['payload']:
            if path in before and before[path] != manifest['postimage'][path]:
                expected_members[NOTE + 'preimages/' + route + '/' + path] = before[path]
    for path, expected in expected_members.items():
        info = z.getinfo(path)
        if ident(z.read(path), stat.S_IMODE(info.external_attr >> 16)) != expected:
            errors.append('archive member: ' + path)
    result['checks']['payload_and_preimages_verified'] = len(expected_members)
    if len(z.namelist()) != len(set(z.namelist())):
        errors.append('duplicate archive names')
    post = manifest['postimage']
    requests = []
    for path, expected in post.items():
        disk = FW / path
        info = disk.lstat()
        if not stat.S_ISREG(info.st_mode) or ident(disk.read_bytes(), stat.S_IMODE(info.st_mode)) != expected:
            errors.append('disk postimage: ' + path)
        if path not in tree:
            errors.append('missing Git path: ' + path)
            continue
        mode, kind, oid = tree[path]
        if kind != 'blob' or (mode == '100755') != bool(expected['mode'] & 0o111):
            errors.append('Git type/executable mode: ' + path)
        requests.append((path, expected, oid))
    proc = subprocess.run(['git', '-C', str(FW), 'cat-file', '--batch'],
                          input=''.join(oid + '\n' for _, _, oid in requests).encode(),
                          stdout=subprocess.PIPE, check=True)
    offset = 0
    for path, expected, oid in requests:
        end = proc.stdout.index(b'\n', offset)
        header = proc.stdout[offset:end].decode().split()
        size = int(header[2]); offset = end + 1
        data = proc.stdout[offset:offset + size]; offset += size + 1
        if header[:2] != [oid, 'blob'] or sha(data) != expected['sha256'] or size != expected['size']:
            errors.append('Git blob postimage: ' + path)
    result['checks']['disk_exact_bytes_and_posix_modes'] = len(post)
    result['checks']['git_exact_blob_bytes_and_executable_modes'] = len(requests)
    result['git_mode_limit'] = 'Git stores executable/nonexecutable, not full 0644 versus 0664; full POSIX modes checked on disk and archive.'
result['git_status_after'] = git('status', '--porcelain=v1', '--untracked-files=all').decode()
if result['git_status_after']:
    errors.append('framework dirty after checks')
result['result'] = 'PASS' if not errors else 'FAIL'
(ROOT / 'evidence/identity.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
raise SystemExit(bool(errors))
