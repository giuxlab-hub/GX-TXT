# GX-TXT DEV112-P008 — Omitted GUI requirements: Y (simple) and J (potentially complex)

**Document type:** Supplementary owner-requested requirements inventory and preliminary engineering-effort classification. This file does not replace the existing P008-request.md, and it does not define an agent assignment, validation plan, or release procedure.

**Original authoritative backlog:** /srv/gxtxt/agents/scratch/DEV112-P007-OWNER-BACKLOG-20261103/GXTXT_P007_GUI_AUDIT_REMEDIATION_LEDGER.md

**Existing P008 requirements (unchanged):** /srv/gxtxt/agents/scratch/DEV112-P008-OWNER-REQUEST/P008-request.md

**Mandatory verification baseline:** accepted cumulative GX-TXT DEV112-P007, source commit a10f5a99fdab93e251efe9c415d5ad76d14c5259.

## Rules applying to every omitted requirement

1. **Verify first against the actual accepted P007.** A historical P004 audit observation does not establish that a defect survives in P007. Correct it only if a genuine current defect is confirmed. If the code already behaves correctly, preserve it and record an evidence-based no-change disposition.
2. **Y and J are provisional effort categories, not severity or permission to drop work.** Y means a likely small/local correction or no code change. J means a possible cross-component or substantial correction only if the current P007 evidence supports it. Actual cause and effort may differ; report any reclassification explicitly.
3. Preserve existing source/data identities, scientific computations, public APIs, Session/Workspace ownership, menus, GUI conventions and existing manuals. Do not create duplicate registries, renderers, scanners or installers.
4. Keep every requirement traceable even when the evidence supports ALREADY_RESOLVED_IN_P007, CORRECT_BEHAVIOR, ENVIRONMENT_ONLY, DOCUMENTATION_ONLY or NOT_APPLICABLE. Do not silently delete an ID.
5. **Print/PDF caution:** compare each historical finding with the substantially revised current P007 Print/PDF Studio. Do not restore obsolete P004 designs or weaken printer and document guards.
6. This supplement contains **exactly 34 omitted IDs**. The 22 previously included P008 requirements are not duplicated. P007-GUI-016 (Group C, comprehensive Plot 2D/3D campaign) remains separately excluded by the owner.

**Coverage:** 29 requirements classified Y + 5 classified J = **34 omitted requirements**.

## Y — Expected simple/local intervention (or evidence-based no change)

For these items, implementation is expected to remain localized to existing UI labels, diagnostics, layout, presentation refresh or small owner-approved integration. If a deeper defect is discovered, report it rather than silently expanding the solution.

### Y-01 — P007-GUI-001 — Storage panel geometry

**Original audit surface:** C01 Storage

**Original requirement / observation (verbatim):** Improve defaults expander/profile-list space handling where narrow/expanded layouts impair use; preserve current settings/actions and validate real windows

**Historical classification:** Observed UX geometry, not confirmed defect

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely a local Tk panel-sizing/scrolling adjustment; no change to storage profiles or persistence.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-02 — P007-GUI-003 — NGspice diagnostic/version display

**Original audit surface:** C03 Runtime tools

**Original requirement / observation (verbatim):** Obtain a meaningful NGspice/version diagnostic rather than naive first-line-as-version; never claim program missing when available

**Historical classification:** Display limitation

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely a bounded diagnostic parsing or label fix using the existing runtime-tool probe.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-03 — P007-GUI-004 — Runtime contract/provider status explanations

**Original audit surface:** C04 Runtime → Contracts

**Original requirement / observation (verbatim):** Clarify `missing_provider`, disabled `document.text`/`document.uml` Preview, CORE fallback and registered/available distinctions; do not invent missing data or install providers without evidence

**Historical classification:** Mixed catalog/status explanatory UX, not confirmed product defect

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely status text or catalog presentation based on available fields; do not change provider admission.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-04 — P007-GUI-005 — Execution node Test connection side-effect disclosure

**Original audit surface:** C06 Execution

**Original requirement / observation (verbatim):** Make it explicit that **Test connection / capabilities** first saves/validates node configuration; review feasibility of separate nonmutating Test versus Save, preserve authenticated node trust

**Historical classification:** Side effect warning, not proven bug

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely label/help clarification of existing Save/Validate-before-Test behavior; a new nonmutating test workflow is not presumed.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-05 — P007-GUI-006 — Registry root: saved setting versus draft

**Original audit surface:** C07 Libraries

**Original requirement / observation (verbatim):** Distinguish saved Registry root from unsaved Root editor draft; display path existence/availability appropriately before actual save/migration, without making valid deferred paths illegal

**Historical classification:** Draft vs confirmed state and path validation UX

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely GUI state/baseline labeling and path availability feedback; do not migrate the Registry.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-06 — P007-GUI-007 — Credential-directory permission diagnostics

**Original audit surface:** C08 Credential profiles

**Original requirement / observation (verbatim):** Keep secure 0700/0600 ancestor/file policy, provide a truthful nonsecret explanation of invalid parent permissions and a safe resolution route; do not chmod user directories automatically

**Historical classification:** Security rejection with opaque diagnostic; no permission bypass

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely a clearer error about existing secure permissions; no automatic chmod or security-policy relaxation.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-07 — P007-GUI-009 — Truncated LaTeX inventory and targeted resource search

**Original audit surface:** C10 LaTeX

**Original requirement / observation (verbatim):** Provide explicit incomplete-inventory status and targeted `kpsewhich` search for actual queried TeX resources, so zero scanned-subset matches cannot masquerade as an absent installed package

**Historical classification:** **Observed misleading search result under truncation**

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** The existing Python TeX inventory exposes a truncated flag and caps entries at 20,000; provide honest incomplete-search UI and a bounded targeted kpsewhich query through the existing diagnostic owner. Do not rebuild the TeX inventory or scan all installed files.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-08 — P007-GUI-012 — Analysis/Services status terminology

**Original audit surface:** C13 Modules → Analysis & Services

**Original requirement / observation (verbatim):** Clarify Health Available vs ON/OFF/ALWAYS/CORE/Installed vs analysis Run-eligible, and distinguish Session/user draft settings from saved state; preserve provider activation semantics

**Historical classification:** Catalog-state distinction, not execution defect

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely UI/help clarification of existing enabled, installed, available and runnable states; no activation changes.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-09 — P007-GUI-013 — Outdated tab labels in documentation

**Original audit surface:** F01 & documentation navigation

**Original requirement / observation (verbatim):** Reconcile any *actual* stale live GUI labels/help with current tabs; documentation-only mismatches should be fixed in public/technical guide revision, NOT by redesigning correct product GUI

**Historical classification:** Guide plan contained historical Analysis/Channels/Experiment labels

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely a documentation/string-only correction if the live GUI is already accurate.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-10 — P007-GUI-014 — Contract-open versus media-class routing help

**Original audit surface:** C04/C11 & API visibility

**Original requirement / observation (verbatim):** Verify discoverability/help text that makes this separation explicit without introducing two competing routing systems; combine implementation with 004/010 if same fix

**Historical classification:** Contract-Open vs generic media-class route may confuse researchers

**Historical status:** OPEN_REVIEW

**Complexity assessment (Y):** Likely existing help/diagnostic text changes; no second routing mechanism.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-11 — P007-GUI-015 — Environment-only versus actual software issue

**Original audit surface:** C08 & C02 environmental qualification

**Original requirement / observation (verbatim):** Independently distinguish **deployment/test environment** from product bug. Track and close with evidence; correct product diagnostics if demonstrably misleading, do not weaken security or invent an OS failure

**Historical classification:** Audit observed group-writable private installation and missing global root

**Historical status:** OPEN_QUALIFICATION

**Complexity assessment (Y):** Normally investigation and an explicit no-change disposition, not a code change; repair only a verified misleading product diagnostic.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-12 — P007-GUI-020 — Mouser connector persistence description

**Original audit surface:** C14; Library Importers

**Original requirement / observation (verbatim):** Mouser declares `read_through` / `persistent_import_available=false` but GUI shares generic Persistent Library Source Connector explanatory text. Check whether installed P006 actually communicates persistence and supported provider-specific capability honestly.

**Historical classification:** STATE_LABEL_AMBIGUITY; no data-loss transaction proved

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely provider-specific explanatory text using declared read-through and persistence capability; no storage changes.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-13 — P007-GUI-021 — Viewer visibility versus module activation status

**Original audit surface:** C16 + C18; Viewer Manager / Preview Components

**Original requirement / observation (verbatim):** Viewer Manager displayed `Presentation Enabled` for 53 rows even though four owning modules were OFF. Preview Components 7/7 OFF despite `default_enabled=1` descriptors (actual saved enabled set empty). Distinguish **presentation visibility**, **module ON/OFF**, **provider availability** and **actual launch eligibility** in status/help if ambiguous; do not auto-enable modules. Cross-reference original ``P007-GUI-012` and owner GUI filter ``P007-GUI-018`, not another manager.

**Historical classification:** TRUE_STATE_CLARITY_REVIEW; no viewer launch failure demonstrated

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely clearer labels in existing Viewer Manager/Preview Components; do not auto-enable anything or change activation.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-14 — P007-GUI-022 — Incomplete Resource Manager scan statistics

**Original audit surface:** C20; Resource Manager

**Original requirement / observation (verbatim):** GUI displayed `0 accounted` / `0 recoverable` while scanning was **incomplete** owing to an absent old path and correctly refused private directory permissions. Verify incomplete-count warning and differentiation from genuine zero usage, without weakening 0700/0600 ownership or deleting protected material.

**Historical classification:** INCOMPLETE_MEASUREMENT_UX; not a cleanup/CORE defect

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely make existing incomplete-scan status clear instead of presenting partial zero counts as final; no cleanup logic change.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-15 — P007-GUI-024 — Logs filter limited to loaded page

**Original audit surface:** C23; Logs & Diagnostics

**Original requirement / observation (verbatim):** Filter searches only the **loaded bounded page**, not the archive; no nonempty pagination test was done. Verify that P006 labels this limitation clearly and returns correct results with real nonempty multi-page logs. No new log storage/search engine mandated.

**Historical classification:** CONDITIONAL_UX / NOT_PROVEN_BUG

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely clarify page-scoped search and verify multi-page behavior; no new archive-search engine.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-16 — P007-GUI-026 — Python Source Surface syntax sample

**Original audit surface:** C33; Source Surface appearance

**Original requirement / observation (verbatim):** Toggling real Python syntax-highlighting checkbox OFF then clicking Preview did not visibly change the sample framebuffer. This may be lexer readiness/asynchronous rendering; test the actual P006 preview and a genuine editor before asserting a defect. Do not recode the lexer merely because a synthetic preview showed equal pixels.

**Historical classification:** UNVERIFIED_PREVIEW_NUANCE

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** May be correct asynchronous behavior; inspect real UI first. If defective, prefer localized preview refresh/binding correction; no wholesale lexer rewrite.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-17 — P007-GUI-027 — Pending Dataset variable preview freshness

**Original audit surface:** M02; Pending Dataset Variables

**Original requirement / observation (verbatim):** Unchecking Use on a Pending variable did not immediately change cached Preview text; calling the installed pending renderer showed the correct `Use=no`. Verify normal GUI navigation/refresh/pending state on P006 and invalidate stale **presentation cache** if necessary; do not alter Dataset scientific Use semantics.

**Historical classification:** UNVERIFIED_CACHE_REFRESH_NUANCE

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely invalidate or refresh stale presentation after Use changes; no change to scientific Use semantics.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-18 — P007-GUI-029 — Legacy numeric Plot Target points feedback

**Original audit surface:** M05; Analysis / Calculation configuration

**Original requirement / observation (verbatim):** Numeric UI Field provides inline invalid-number feedback; legacy Plot Target points integer Tk Entry does not visibly provide equivalent inline error for `7000.5` although public integer validator rejects it. Verify actual save/run guard and consider reusing existing UI Field validation or a concise error, without replacing module parameter contracts.

**Historical classification:** CONTROL_CONSISTENCY_UX; NO_INVALID_JOB_OBSERVED

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely reuse existing integer validation and supply truthful inline error text; no parameter-contract replacement.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-19 — P007-GUI-031 — Module Graphics dialog compact-size access

**Original audit surface:** M10 (corrected M09); Module graphics layout

**Original requirement / observation (verbatim):** Source/real-widget inspection found **33 controls**, not 28 as earlier M09 report said, including five colorbar/CLim controls. Actual dialog requires about 1,063 px on a 1,000-px display. Verify full control reachability via scroll/resize/keyboard at ordinary screen sizes; fix GUI clipping if reproduced. The earlier M09 count mismatch is an **audit erratum**, not a missing product field.

**Historical classification:** ACCESSIBILITY_LAYOUT_CANDIDATE

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely scrollbar/geometry/keyboard reachability for the existing 33 controls; no new controls or renderer.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-20 — P007-GUI-033 — Use setting for unmanaged Session PNG

**Original audit surface:** M13 + M15; Plots Use state

**Original requirement / observation (verbatim):** Unrecognized Session PNG `Use` toggle was transient on Session reentry, while detached Clone `Use NO` persisted. Verify this is intentional and clearly indicated; do not invent a scientific Graph Provider identity or require persistence of unmanaged PNG if that is original contract. Clarify labeling if users can misunderstand selection storage.

**Historical classification:** SEMANTIC_PERSISTENCE_REVIEW; NOT_PROVEN_BUG

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Potentially intentional transient state; likely correct label/help, not new persistent graph ownership.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-21 — P007-GUI-035 — Immediate commit semantics in mixed dialogs

**Original audit surface:** M03 + C33 + M15; independently committed UI actions

**Original requirement / observation (verbatim):** Some actions save **immediately** despite nearby draft/Cancel controls: Show Script Workspace preference, Source Surface Scheme Save/Delete and Variant `New` creating an identity before its editor Save. Verify actual P006 transaction semantics, visible user confirmation/labels and appropriate cancel expectations; do not demand rollback of an explicitly committed New/Save/Delete operation unless a user-facing contradiction is established.

**Historical classification:** IMMEDIATE_COMMIT_EXPLANATION / CONDITIONAL_UX

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely clarify which actions commit immediately; do not invent Cancel rollback for completed New/Save/Delete actions.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-22 — P007-GUI-042 — Print button readiness versus CUPS state

**Original audit surface:** M19; Print / PDF CUPS readiness

**Original requirement / observation (verbatim):** Print became enabled after Cancel query while CUPS destination verified=0; actual host guards printing. No physical Print was attempted. Verify P006 button/status accurately reflect effective destination readiness; no printer Job or security policy change on old evidence alone.

**Historical classification:** P004_UI_AFFORDANCE_REVIEW; MAIN_P006_PRINT_REVIEW

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely align existing button enabled state and diagnostics with existing verified-destination guard; no CUPS or printer execution policy changes.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-23 — P007-GUI-045 — Session Files tree and preview proportions

**Original audit surface:** M20; Session Files layout

**Original requirement / observation (verbatim):** Treeview column allocated width 950 without stretch, leaving Preview cramped at ordinary window widths. Verify real current layout, resize, scroll, Tab and keyboard controls; narrow-screen UX only if still problematic.

**Historical classification:** P004_LAYOUT_OBSERVATION; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely adjust Treeview column stretch/initial width and compact geometry.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-24 — P007-GUI-047 — Raw INI scrolling and parser-scope explanation

**Original audit surface:** M24; Raw INI readability / diagnostics

**Original requirement / observation (verbatim):** Nonwrapped Raw INI has vertical but no horizontal scroll; invalid INI lines and duplicated keys can be silently omitted/last-wins in Structured projection while status says saved Manifest. Verify accessibility and clear read-only/parser-scope descriptions; no unrequested strict parser rewrite.

**Historical classification:** P004_UX_CONDITIONAL; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely add horizontal scrollbar and clarify structured-view parser limitations; no new strict INI parser.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-25 — P007-GUI-048 — Session parameter editor diagnostic

**Original audit surface:** M25; Session Parameters

**Original requirement / observation (verbatim):** Basic parameter editor exposes only Name/Formula although CORE supports typed bounds/unit/description; deleting referenced name returns ambiguous Unknown parameter although dependency guard correctly refuses. Assess current P006 GUI/diagnostics; do not invent an entire advanced parameter editor without a separate design decision.

**Historical classification:** P004_SCOPE_AND_DIAGNOSTIC_REVIEW; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely clarify dependency-refusal feedback; full typed-parameter advanced editor is not in scope.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-26 — P007-GUI-049 — Experiment Date input guidance

**Original audit surface:** M26; Experiment Date

**Original requirement / observation (verbatim):** Date field accepted not-a-date as an unsaved text draft, with no native date validation. Verify documented current contract and Save validation; consider concise format guidance if genuinely misleading. No claim of a persisted invalid date or data loss.

**Historical classification:** P004_CONDITIONAL_UX; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely date-format indication or bounded save-time feedback; no new date-widget subsystem.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-27 — P007-GUI-051 — Scientific Viewers catalog Module ID search

**Original audit surface:** M31; Scientific Viewers catalog search

**Original requirement / observation (verbatim):** The Scientific Viewers tile catalog search indexed title/provider/group but not owning Module ID, while Module Viewer manager search is independently owner-requested in P007-GUI-018. Check P006 catalog discoverability separately and avoid conflating the two search surfaces.

**Historical classification:** P004_UX_SCOPE_LIMIT; CROSSREF_018; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely extend existing tile-catalog search terms; distinct from the already requested Viewer Manager filter.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-28 — P007-GUI-054 — Help indexing and obsolete version notices

**Original audit surface:** M32; Help indexing/version text

**Original requirement / observation (verbatim):** Installed docs/help had 13 Markdown files but only 10 core guides indexed (projects, storage_profiles, script_module_builder omitted); Registry details cited v0.8.5 as though current. Check P006 current guide inventory, installed-version notices and historical compatibility wording; no guessed module activation or Digitalizer changes.

**Historical classification:** P004_DOC_COVERAGE_AND_LABEL; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely include known existing help documents and correct misleading version labels in the existing index; no HTML Guides packaging project.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### Y-29 — P007-GUI-056 — Unpacked secondary Dataset editor widgets

**Original audit surface:** M34/M36/M37; Dataset secondary editors

**Original requirement / observation (verbatim):** Edit Metadata..., Edit Notes... and Open Temporal Sets... widgets existed but were never packed in the corresponding notebook tabs; the visible Dataset toolbar pencil provided a working route. Assess whether P006 intentionally uses one toolbar entry or a discoverability error; do not blindly add duplicate buttons.

**Historical classification:** P004_REPRODUCED_UNMANAGED_UI; VERIFY_P006

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (Y):** Likely verify whether the existing toolbar route is intentional; avoid duplicate buttons. If the current UI is misleading, correct only discoverability.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

## J — Potentially substantial code correction if still defective

J does not mean a change is definitely needed or that a large rewrite is authorized. These are comparatively higher-risk investigations because they may reach multiple existing components, security-sensitive routing, a shared catalog, or distinct PDF renderers.

### J-01 — P007-GUI-008 — Platform-aware Python import inventory classification

**Original audit surface:** C09 Python Scripts

**Original requirement / observation (verbatim):** Visibly distinguish missing platform-inapplicable Windows-only modules from genuine optional/unresolved Python dependencies, and static UNKNOWN from runtime failure. Do not mass-install optional scientific dependencies

**Historical classification:** Static import inventory classification limitation

**Historical status:** OPEN_REVIEW

**Complexity assessment (J):** May require coordinated static-import inventory classification, platform capability semantics and GUI reporting, rather than a simple label; preserve runtime-failure distinctions and do not install dependencies.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### J-02 — P007-GUI-010 — Viewer gxtxt token parsing and provider routing

**Original audit surface:** C11 Configuration → Viewers

**Original requirement / observation (verbatim):** Reject malformed `gxtxt:` Viewer tokens as tokens (not external commands), verify compatible provider identity and availability at proper stage, make unresolved external-command/provider states explicit; preserve safe no-shell admission

**Historical classification:** Validation / routing hazard, not verified exploit

**Historical status:** OPEN_REVIEW

**Complexity assessment (J):** Potentially touches security-sensitive token admission, provider identity, launch routing and validation; needs careful source-specific correction if current behavior is wrong.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### J-03 — P007-GUI-019 — Search over declared metadata in four catalog browsers

**Original audit surface:** C14, C15, C17, C18; `ISSUES_FOUND.md` and four `Cxx_CHAPTER_REPORT.md`

**Original requirement / observation (verbatim):** Search/filter discoverability omits relevant **declared metadata fields**: Library Importers `electronics.components` (search `electronics`), Export `output_format`/`stl`, Acquisition `*.jdx`, Preview `dataset_contracts=spectrum.scientific`. Verify four existing browser searches and actual metadata before deciding whether to index these fields or clarify search scope. Reuse current search owners; do not create a global search system.

**Historical classification:** MULTI_SURFACE_UX_CANDIDATE; no scientific importer/export failure established

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (J):** Potentially spans Library Importers, Export, Acquisition and Preview search owners, and declared metadata/indexing; reuse existing search functions, not a global engine.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### J-04 — P007-GUI-023 — API Catalog stale/fingerprint status

**Original audit surface:** C21 + C25; Framework Status / API Catalog

**Original requirement / observation (verbatim):** P004 showed 2,799 retained entries, `stale` / `failed` with a **healthy packaged DB manifest**, but changed loaded CORE fingerprint. Verify the P006 accepted installed catalog is current or clearly warns about this precise condition; do not call `stale` a corrupt database or regenerate its contents as an audit-side effect. Correct only a surviving real packaging/refresh/notification defect using existing catalog owner.

**Historical classification:** ACTUAL_P004_STALE_STATE; VERIFY_CURRENT_PACKAGE_AND_ACTIONABILITY

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (J):** May involve catalog freshness, packaged database fingerprints, asynchronous refresh and provenance/status notification, beyond a simple display change.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

### J-05 — P007-GUI-040 — Print/PDF Grid versus Poster background semantics

**Original audit surface:** M18; Print / PDF Grid/Poster

**Original requirement / observation (verbatim):** A custom page background appeared in native Poster PDF but was white in Grid PDF in P004 despite same stored field. Determine whether P006 deliberately has different layout semantics, explains them or has a surviving preview/export inconsistency.

**Historical classification:** P004_SEMANTIC_UX_REVIEW; MAIN_P006_PRINT_REVIEW

**Historical status:** Historical observation; current P007 status unverified

**Complexity assessment (J):** May involve layout-specific PDF generation and shared recipe/rendering semantics; first examine revised P007 Print/PDF Studio and distinguish intended behavior from a surviving defect.

**Required handling:** Verify on P007 before any change. If no longer defective, record the no-change result. If defective, correct only the demonstrated cause and preserve established behavior.

## Completeness and scope reconciliation

| Category | Original issue IDs | Count |
| --- | --- | ---: |
| Y | P007-GUI-001, P007-GUI-003, P007-GUI-004, P007-GUI-005, P007-GUI-006, P007-GUI-007, P007-GUI-009, P007-GUI-012, P007-GUI-013, P007-GUI-014, P007-GUI-015, P007-GUI-020, P007-GUI-021, P007-GUI-022, P007-GUI-024, P007-GUI-026, P007-GUI-027, P007-GUI-029, P007-GUI-031, P007-GUI-033, P007-GUI-035, P007-GUI-042, P007-GUI-045, P007-GUI-047, P007-GUI-048, P007-GUI-049, P007-GUI-051, P007-GUI-054, P007-GUI-056 | 29 |
| J | P007-GUI-008, P007-GUI-010, P007-GUI-019, P007-GUI-023, P007-GUI-040 | 5 |
| **Total** | **All previously omitted requirements** | **34** |

**Excluded as already agreed:** P007-GUI-016, comprehensive Plot 2D/3D campaign (Group C).

**Already covered by existing P008-request.md:** P007-GUI-002, P007-GUI-011, P007-GUI-017, P007-GUI-018, P007-GUI-025, P007-GUI-028, P007-GUI-030, P007-GUI-032, P007-GUI-034, P007-GUI-036, P007-GUI-037, P007-GUI-038, P007-GUI-039, P007-GUI-041, P007-GUI-043, P007-GUI-044, P007-GUI-046, P007-GUI-050, P007-GUI-052, P007-GUI-053, P007-GUI-055, P007-GUI-057.

**Handoff boundary:** This is a separate supplemental document, not a silent modification to the instructions of an already running MAIN agent. P008-request.md remains unchanged. Incorporation into active development requires an explicit owner instruction to MAIN; mere file presence does not prove MAIN has read or accepted it.
