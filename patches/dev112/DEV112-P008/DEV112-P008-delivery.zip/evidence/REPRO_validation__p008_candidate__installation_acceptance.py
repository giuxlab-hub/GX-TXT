import json,hashlib,pathlib
R=pathlib.Path('/srv/gxtxt/agents/scratch/DEV112-P008-VALIDATOR-20261112');C=R/'child-release';S=pathlib.Path('/srv/gxtxt/agents/scratch/DEV112-P008-MAIN-20261112/stage01')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
run=read(C/'stage-run01/RESULT.json');assert run['result']=='PASS_FOUR_ROUTES'
tech=read(R/'TECHNICAL_SOURCE_ACCEPTANCE.json');pre=read(C/'evidence/final-preflight.json');assert pre['result']=='PASS'
for name,digest in pre['pins'].items():assert sha(S/name)==digest
assert set(x['route'] for x in run['routes'])=={'r2','post-p005','post-p006-r5','post-p007'}
evidence={};routes=[]
for row in run['routes']:
 case=C/'stage-run01'/row['route'];assert read(case/'RESULT.json')==row
 assert row['result']=='PASS' and row['full_managed_identity_and_sentinels_preserved']
 assert sha(case/'apply.json')==row['receipt_sha256'];assert read(case/'apply.json')['status']=='COMPLETE'
 outputs={}
 for label in ['before','apply','after','apply-idempotent','rollback','rollback-idempotent','restored']:
  p=case/(label+'-stdout.json');d=read(p);assert d['result']=='PASS';outputs[label]=sha(p)
 for label in ['apply-idempotent','rollback-idempotent']:
  d=read(case/(label+'-stdout.json'));assert d['coherent_noop'] and not d['writes']
 for label in ['wrong-route','modified-byte','modified-mode','missing-receipt','bad-receipt-hash','wrong-rollback-route']:
  p=case/(label+'-stderr.txt');assert 'REFUSED:' in p.read_text();outputs[label]=sha(p)
 routes.append(dict(row,command_output_sha256=outputs,receipt_path=str(case/'apply.json')))
extra=read(C/'stage-run01/extra-negatives/RESULT.json');assert extra['result']=='PASS' and len(extra['cases'])==9
assert all(x['result']=='PASS_REFUSED_NO_WRITES' and x['returncode']!=0 for x in extra['cases'])
for p in [C/'stage-run01/RESULT.json',C/'evidence/final-preflight.json',C/'RELEASE_PREP_RESULTS.json',C/'stage-run01/extra-negatives/RESULT.json',C/'evidence/wait-supervisor.jsonl',R/'TECHNICAL_SOURCE_ACCEPTANCE.json',R/'SOURCE_INTEGRITY.json']:
 evidence[str(p)]=sha(p)
report={'status':'ACCEPTED_INDEPENDENT_INSTALLATION_AND_ROLLBACK','source_commit':pre['source_commit'],'stage_pins':pre['pins'],'postimage_files':pre['postimage_files'],'canonical_postimage_sha256':pre['canonical_postimage_sha256'],'routes':routes,'additional_refusal_cases':extra['cases'],'evidence_sha256':evidence,'source_and_patch_binding':'Previously completed independent TECHNICAL_SOURCE_ACCEPTANCE and SOURCE_INTEGRITY bind the identical final 6403-file bytes/modes to this exact patch.','preservation':'Each full managed file set/byte/mode inventory and synthetic Session/configuration/unrelated sentinel was checked before apply, after apply and after rollback.','supervision':'Healthy slow durable I/O was retained. Scratch-only watcher paused only harness timeout waiting and resumed after actual installer exit; no installer/fsync/product changes.','limits':['No owner installation or activation performed.','Installer durability is per-file; no whole-install crash recovery claim.','Outer delivery ZIP and canonical deposited readback remain separate final artifact gates.'],'blockers':[]}
p=R/'INSTALLATION_ACCEPTANCE.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n');digest=sha(p);(R/'INSTALLATION_ACCEPTANCE.sha256').write_text(digest+'  INSTALLATION_ACCEPTANCE.json\n');print(digest)
