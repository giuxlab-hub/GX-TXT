# P008 supplementary GUI handoff

Cherry-pick **a186ced5095c25ff9052c13a6de9b2c2af3a7fed** from own independent
`/srv/gxtxt/agents/scratch/DEV112-P008-DEV-GUI-20261112/framework` branch
`dev112-p008-dev-gui-supplement`, based on MAIN
`9e89001a43e3dac223b1dddce418edc7c0ad2864`. Worktree clean. Original a740 branch,
pristine P007 baseline copy and all earlier evidence remain intact.

All ten original IDs are documented in the committed
`validation/dev112_p008_gui_supplement/AUTHOR_RESULTS.md` with exact baseline and
candidate observations:

- 013: public Getting started label correction only (Dataset versus Datasets).
- 033: unmanaged PNG Use intentionally temporary; visible/help clarification only.
- 035: preference/Scheme actions and Variant identity creation remain immediate;
  labels explain boundaries. No rollback/transaction change.
- 042: Print enabled state mirrors existing verified/matching printer and document
  guards; PDF export remains independent. Existing submission owner unchanged.
- 045: existing file-tree request no longer consumes text preview. At1100px,
  preview703px/tree333px; at existing920px minimum, preview582px/tree274px.
  Original950px scrollable path column and existing keyboard traversal retained.
- 047: read-only Raw INI horizontal scrollbar and truthful parser-projection scope.
- 048: existing dependency refusal receives correct editor diagnostic; unchanged
  parameter evaluator and state. No advanced parameter editor introduced.
- 049: recommendation-only Date guidance; existing free-text metadata preserved.
- 054: all13 shipped help guides indexed and current framework Registry notice.
- 056: CORRECT_BEHAVIOR_NOCHANGE; actual existing pencil opens each editor with
  section-specific tooltips. No duplicate buttons added.

Evidence is sibling directories of this HANDOFF. Exact-P007 baseline01 covers all
10; baseline02 proves genuine Session reentry/Clone comparison and actual Variant
New/editor Close; baseline03 proves actual three existing pencil routes. All exit0
and zero background errors. Full candidate supplement_fixed02 passes all10 expected
assertions, zero background errors. Final wording/new-guide-open observations from
fixed03 pass separate read-only WORDING_AND_GUIDE_REVIEW.json. The fixed03 final
assertion incorrectly assumed disabled Text received Tab; its preserved data shows
established traversal reaches a mapped Session Jobs control. Corrected045-only
fixed04 exits0 and verifies actual mapped focus and both compact geometries.

Preserved candidate failure supplement_fixed01 occurred before any functional
observation at existing managed ImageMagick5-second icon rasterization limit.
No timeout/icon/native source modification was made. No physical Print, CUPS
mutation, real scientific data, owner installation, frozen module, forbidden J IDs,
Group C, HTML packaging or public API change occurred. Scripts use own private
XDG/cache/temp/Job/Resource/installation/Session roots; HOME unchanged.

Product scope is16 existing local Tcl/help files plus catalog and three author
validation documents. Two shared source files carry isolated changes:
`core/tcl/module_api_v1.tcl` only Documentation Registry notice;
`core/tcl/project_api_v1.tcl` only existing Date label. Source Surface changes are
only Scheme action notice/status; no lexer/highlighting/source editor API changes.
`core/tcl/parameter_service_api_v1.tcl`, CUPS host submission guard, renderer and
public contracts remain byte-unchanged. No viewer_catalog edits.

`SUPPLEMENT_WORK_STATE.json` and `SUPPLEMENT_SOURCE_AND_EVIDENCE_SHA256.json`
preserve the checkpoint and source/evidence pins. MAIN alone updates its acceptance
matrix, integrates, accepts and deposits; independent GUI/technical acceptance is
still required. Do not rerun accepted P007 or first-batch campaigns merely to test
these local presentation changes.
