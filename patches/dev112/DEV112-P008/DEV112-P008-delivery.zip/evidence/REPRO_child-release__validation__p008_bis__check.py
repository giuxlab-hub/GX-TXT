import hashlib, importlib.util, json, os, shutil, stat, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; FW=ROOT/'framework'
FIX=ROOT/'bis_private02'; FIX.mkdir(mode=0o700)
os.umask(0o077)
sys.dont_write_bytecode=True
sys.path.insert(0,str(FW/'core/python'))
def load(name):
    spec=importlib.util.spec_from_file_location(name,FW/'core/python'/f'{name}.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def run(command,input=None):
    p=subprocess.run(command,input=input,text=True,capture_output=True,timeout=30,cwd=FIX)
    return dict(command=command,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
def tcl(body):
    return run(['tclsh'],f'namespace eval ::GX {{variable scriptDir {{{FW}}}}}\n'+body)
r={'head':run(['git','-C',str(FW),'rev-parse','HEAD']), 'fixture_root':str(FIX),'fixture_mode':oct(stat.S_IMODE(FIX.stat().st_mode))}
py=load('gxtxt_python_environment')
r['python_inventory']=py.inventory(limit=2000)
sources={
 'windows_unconditional':'import winreg\n',
 'windows_guarded':'import sys\nif sys.platform == "win32":\n    import winreg\n',
 'genuine_missing':'import p008_nonexistent_dependency_7c0ec490\n',
 'optional_missing':'try:\n    import p008_nonexistent_dependency_7c0ec490\nexcept ImportError:\n    pass\n',
 'dynamic_unknown':'__import__("p008_nonexistent_dependency_7c0ec490")\n'}
r['python_fixtures']={}
for name,source in sources.items():
    p=FIX/(name+'.py');p.write_text(source)
    admission={'schema':'gxtxt.python_import_audit_request.v1','scope':'project','scope_identity':'synthetic:'+name,'sources':[{'path':str(p),'root':str(FIX),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'logical_id':name}]}
    r['python_fixtures'][name]={'source':source,'analyze':py.analyze(source),'audit':py.audit_imports(admission)}
creds=load('scientific_library_credentials_v1'); manager=load('scientific_library_manager')
r['credential_guards']={}
for name,mode in [('secure',0o700),('unsafe_group_writable',0o770)]:
    d=FIX/name;d.mkdir(mode=mode);d.chmod(mode)
    item={'mode':oct(stat.S_IMODE(d.stat().st_mode))}
    try:creds.ProfileStore._directory(d.stat(),private=True);item['direct_private_guard']='ACCEPT'
    except creds.ProfileError as e:item['direct_private_guard']={'code':e.code,'reason':e.reason,'text':str(e)}
    store=creds.ProfileStore(d/'configuration.ini')
    try:item['list_profiles']=store.list_profiles()
    except creds.ProfileError as e:item['list_profiles_error']={'code':e.code,'reason':e.reason,'text':str(e)}
    try:item['manager_projection']=manager._credential_profile_call(store.list_profiles)
    except Exception as e:item['manager_projection_error']={'type':type(e).__name__,'text':str(e),'fields':vars(e)}
    r['credential_guards'][name]=item
# Observe directory metadata only; never read configuration files or secrets.
r['fixture_ancestor_modes']=[{'path':str(p),'mode':oct(stat.S_IMODE(p.stat().st_mode)),'uid':p.stat().st_uid} for p in reversed(FIX.parents)]
ng=shutil.which('ngspice');r['ngspice_native']=run([ng,'--version']) if ng else {'available':False}
tool=FIX/'synthetic_ngspice';tool.write_text('#!/bin/sh\nprintf "******\\nngspice-TEST 99\\n"\n');tool.chmod(0o700)
fail=FIX/'synthetic_ngspice_exit1';fail.write_text('#!/bin/sh\nprintf "ngspice-TEST 99\\n"\nexit 1\n');fail.chmod(0o700)
r['runtime_tcl']=tcl(f'''source {{{FW}/core/tcl/configuration_api_v1.tcl}}
dict set ::GX::configurationSchema runtime.spice {{group Runtime label spice type string default auto scope user}}
dict set ::GX::configurationValues runtime.spice auto
puts [list actual [::GX::runtimeToolStatus spice]]
set ::GX::configurationValues(runtime.spice) unused
dict set ::GX::configurationValues runtime.spice {{{tool}}}
puts [list synthetic_banner [::GX::runtimeToolStatus spice]]
dict set ::GX::configurationValues runtime.spice {{{fail}}}
puts [list synthetic_nonzero [::GX::runtimeToolStatus spice]]
'''.replace('set ::GX::configurationValues(runtime.spice) unused\n',''))
kpse=shutil.which('kpsewhich');r['kpsewhich']={}
if kpse:
    for query in ['--version','article.cls','p008_nonexistent_resource_7c0ec490.sty']:
        p=subprocess.run([kpse,query],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=5,cwd=FIX)
        r['kpsewhich'][query]={'returncode':p.returncode,'stdout':p.stdout[:4096],'stderr':p.stderr[:4096]}
r['latex_truncated_search']=tcl(f'''source {{{FW}/core/tcl/configuration_latex_v1.tcl}}
proc winfo {{op path}} {{return 1}}
proc .top.nb.configuration.sections.scripts.latex.items {{args}} {{return {{}}}}
set ::GX::LatexEnvironment::inventory [dict create entries [list [dict create name irrelevant.sty kind package version {{not advertised}} location synthetic status {{installed resource}}]] total 20000 truncated 1]
set ::GX::LatexEnvironment::search article.cls
::GX::_latexEnvironmentSearch
puts $::GX::LatexEnvironment::status
source {{{FW}/core/tcl/scientific_library_credentials_gui_v1.tcl}}
puts [list credential_gui_message [::GX::LibraryCredentialsGUI::_failureText integrity_failure]]
source {{{FW}/core/tcl/workspace_profiles_api_v1.tcl}}
set ::GX::cfg(output_root) {{{FIX}/missing_global_root}}
puts [list missing_root_initial_dir [::GX::workspaceInitialDir session_root] exists [file exists {{{FIX}/missing_global_root}}]]
''')
paths=['core/python/gxtxt_python_environment.py','core/python/gxtxt_latex_environment.py','core/python/scientific_library_credentials_v1.py','core/python/scientific_library_manager.py','core/tcl/configuration_api_v1.tcl','core/tcl/configuration_latex_v1.tcl','core/tcl/python_environment_api_v1.tcl','core/tcl/scientific_library_credentials_gui_v1.tcl','core/tcl/workspace_profiles_api_v1.tcl']
r['source_sha256']={p:hashlib.sha256((FW/p).read_bytes()).hexdigest() for p in paths}
r['git_status_after']=run(['git','-C',str(FW),'status','--porcelain=v1','--untracked-files=all'])
(ROOT/'evidence/bis-runtime02.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:r[k] for k in ['runtime_tcl','credential_guards','kpsewhich','latex_truncated_search','git_status_after']},indent=2))
