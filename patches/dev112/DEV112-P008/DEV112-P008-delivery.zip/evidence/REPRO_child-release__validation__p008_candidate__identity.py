import hashlib,json,subprocess,sys,os,zipfile
from pathlib import Path
repo,commit,root,receipt=sys.argv[1:];root=Path(root).resolve();receipt=Path(receipt);assert not receipt.exists()
with zipfile.ZipFile('/srv/gxtxt/releases/GXTXT/framework/archives/patches/DEV112-P007-20261112/DEV112-P007.zip') as z: baseline=json.loads(z.read('patch_notes/DEV112-P007/FILES.json'))['postimage']
items=subprocess.check_output(['git','-C',repo,'ls-tree','-rz','--full-tree',commit]).split(b'\0');expected={};errors=[];inventory={}
for item in items:
 if not item:continue
 meta,name=item.split(b'\t',1);mode,typ,oid=meta.decode().split();name=name.decode();expected[name]=oid
 path=root/name
 if not path.is_file() or path.is_symlink():errors.append([name,'missing or symlink']);continue
 data=path.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 actualmode=path.stat().st_mode&0o777
 expectedmode=baseline.get(name,{}).get('mode',0o755 if mode=='100755' else 0o644)
 if actual!=oid or actualmode!=expectedmode:errors.append([name,actual,oid,oct(actualmode),mode])
 inventory[name]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'mode':actualmode}
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() or p.is_symlink()}
if actual!=set(expected):errors.append(['file-set',sorted(actual-set(expected)),sorted(set(expected)-actual)])
result={'commit':commit,'root':str(root),'files':len(expected),'result':'FAIL' if errors else 'PASS','errors':errors,'inventory':inventory}
receipt.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='inventory'}));assert not errors
