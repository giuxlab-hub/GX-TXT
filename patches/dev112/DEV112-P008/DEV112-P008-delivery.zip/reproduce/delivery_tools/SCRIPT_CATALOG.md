# DEV112-P008 cumulative delivery tools

Scope: GX-TXT0.9.8.10-dev-112 patch008, exact accepted P007 commit a10f5a99fdab93e251efe9c415d5ad76d14c5259 and cumulative r2/P005/P006r5 routes. Adapted P007 tooling; no historical deployment script is run unchanged.

- `python3 -I -B assemble.py FRAMEWORK NEW_STAGE --source-commit FULL_SHA --documents DOCUMENTS`: reads clean frozen source and four exact hash-pinned baseline inventories/archives, creates fresh cumulative ZIP/preimages/manifest/helper/checksums. No installation or activation.
- `python3 -I -B check_install.py STAGE NEW_OUTPUT`: creates four disposable baseline trees, exercises existing stopped-target check/apply/receipt rollback, full bytes/modes and Session/config/unrelated sentinels, tamper refusal. Only new private output, up to1200seconds per durable fsync-heavy installer command.
- `baselines.py`: verifies exact admitted r2/P005/P006r5/P007 bytes/modes and inventories in memory.
- `apply_p008_template.py`: existing installer algorithm adapted only for P008 marker, fourth exact baseline and explicit reusable-check allowlist. Not runnable release helper before assembly substitutes manifest pin. Default check reads only; explicit apply/rollback require existing stopped/authorized/receipt acknowledgements.
- `python3 -I -B package_bundle.py STAGE DOCUMENTS EVIDENCE_INPUTS_JSON NEW_OUTPUT`: copies exact patch/English docs/hash-pinned named evidence/tools into fresh delivery ZIP and complete checksum inventory. No activation/deposit.
- `python3 -I -B publish.py PREPARED_BUNDLE FINAL_REVIEW EXPECTED_REVIEW_SHA256`: only exact independent ACCEPT_FOR_DELIVERY source/patch/bundle identities and zero blockers permit fresh workspace/dev112/framework archives+expanded deposits. Preserves historical releases and checks complete bytes/mode parity. No working install/data/activation. external_plugins and session_generators unchanged.

All outputs new, MAIN only integrates/deposits. These tools never authorize release acceptance by themselves.

- `git -C FRAMEWORK bundle create DOCUMENTS/DEV112-P008-source.bundle HEAD ^a10f5a99fdab93e251efe9c415d5ad76d14c5259` and `git -C FRAMEWORK bundle verify BUNDLE`: read-only final P008 Git delta preservation with acceptedP007 precondition, writes only new delivery artifact. No remote push/history rewrite/source changes. Installation remains the existing cumulative helper; Git is not required to install.
