"""Exercise the current cumulative helper on four fresh, private baselines."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import stat
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from baselines import admitted_baselines


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify(root, inventory):
    for name, expected in inventory.items():
        path = root / name
        observed = path.lstat()
        assert stat.S_ISREG(observed.st_mode) and observed.st_nlink == 1, name
        assert observed.st_size == expected['size'], name
        assert stat.S_IMODE(observed.st_mode) == expected['mode'], name
        assert digest(path) == expected['sha256'], name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', type=Path)
    parser.add_argument('new_output', type=Path)
    args = parser.parse_args()
    stage = args.stage.resolve(strict=True)
    output = args.new_output.resolve()
    assert not output.exists() and output.parent.is_dir()
    output.mkdir(mode=0o700)
    manifest = json.loads((stage / 'FILES.json').read_text())
    routes, contents, _ = admitted_baselines()
    assert routes == manifest['routes']
    results = []
    for route, before in routes.items():
        case = output / route
        case.mkdir(mode=0o700)
        target = case / 'framework'
        target.mkdir(mode=0o700)
        for name, row in before.items():
            path = target / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(contents[route][name])
            path.chmod(row['mode'])
        sentinel = target / 'Sessions/P008_KEEP/user-data.bin'
        sentinel.parent.mkdir(parents=True)
        sentinel.write_bytes(b'Private installation preservation sentinel\x00\xff\n')
        sentinel_hash = digest(sentinel)
        config_sentinel = target / 'Configuration/p008-preserve.ini'
        config_sentinel.parent.mkdir(parents=True, exist_ok=True)
        config_sentinel.write_text('[private]\nunchanged = yes\n')
        config_hash = digest(config_sentinel)
        unrelated = target / 'p008-user-notes.txt'
        unrelated.write_text('Private unrelated file preservation sentinel\n')
        unrelated_hash = digest(unrelated)
        receipt = case / 'apply.json'

        def command(label, *arguments):
            argv = [sys.executable, '-I', '-B', str(stage / 'apply.py'),
                    str(target), str(stage / 'DEV112-P008.zip'), *arguments]
            (case / (label + '-command.json')).write_text(json.dumps(argv) + '\n')
            with (case / (label + '-stdout.json')).open('xb') as stdout, \
                    (case / (label + '-stderr.txt')).open('xb') as stderr:
                result = subprocess.run(argv, stdout=stdout, stderr=stderr, timeout=1200,
                                        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
            assert result.returncode == 0, (route, label, result.returncode)
            audit = json.loads((case / (label + '-stdout.json')).read_text())
            assert audit['result'] == 'PASS', (route, label)
            return audit

        verify(target, before)
        command('before', '--check')
        # A changed managed byte must refuse before modifying any other file.
        marker = target / 'PATCH_LEVEL.txt'
        original_marker = marker.read_bytes()
        marker.write_bytes(original_marker + b'tampered\n')
        negative = subprocess.run([sys.executable, '-I', '-B', str(stage / 'apply.py'),
            str(target), str(stage / 'DEV112-P008.zip'), '--check'],
            capture_output=True, timeout=1200)
        (case / 'modified-baseline-refusal.txt').write_bytes(negative.stdout + negative.stderr)
        assert negative.returncode != 0 and b'no writes' in negative.stderr
        marker.write_bytes(original_marker)
        verify(target, before)
        applied = command('apply', '--apply', '--stopped', '--owner-authorized',
                          '--receipt', str(receipt))
        verify(target, manifest['postimage'])
        assert digest(sentinel) == sentinel_hash
        assert digest(config_sentinel) == config_hash
        assert digest(unrelated) == unrelated_hash
        command('after', '--check')
        receipt_hash = digest(receipt)
        assert applied['external_receipt_sha256'] == receipt_hash
        (case / 'retained-receipt.sha256').write_text(receipt_hash + '\n')
        command('rollback', '--rollback', '--route', route, '--stopped',
                '--owner-authorized', '--receipt', str(receipt),
                '--receipt-sha256', receipt_hash)
        verify(target, before)
        assert digest(sentinel) == sentinel_hash
        assert digest(config_sentinel) == config_hash
        assert digest(unrelated) == unrelated_hash
        assert all(not (target / name).exists()
                   for name in set(manifest['postimage']) - set(before))
        command('restored', '--check')
        results.append({'route': route, 'result': 'PASS',
                        'complete_install_and_rollback_identity': True,
                        'unrelated_session_sentinel_preserved': True,
                        'configuration_and_unrelated_files_preserved': True,
                        'modified_managed_baseline_refused': True,
                        'final_inventory_sha256': applied['final_inventory_sha256'],
                        'receipt_sha256': receipt_hash})
    assert len({r['final_inventory_sha256'] for r in results}) == 1
    record = {'identical_final_framework_contents': True, 'result': 'PASS_ALL_FOUR_BASELINES_INSTALL_AND_ROLLBACK',
              'archive_sha256': digest(stage / 'DEV112-P008.zip'),
              'installer_sha256': digest(stage / 'apply.py'),
              'manifest_sha256': digest(stage / 'FILES.json'), 'routes': results,
              'production_activation': False}
    (output / 'RESULT.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))


if __name__ == '__main__':
    main()
