# Reproducing the scoped P008 checks

Use only disposable, independent scratch framework copies of the stated exact
baseline or candidate. Do not run these scripts against the owner's installation,
Sessions or scientific data. Each script is version-pinned evidence; read its
catalog entry, arguments and fixture side effects first. Embedded scratch paths
identify the original run and may need deliberate adjustment in a new scratch
copy. They are not deployment destinations.

The tools in `reproduce/delivery_tools/` build and check this cumulative release
through the established installer infrastructure. The authoritative installer is
`patch/apply.py`, whose exact bytes are independently accepted; reviewed historical
templates are not alternative installation authorities.

Technical validation harnesses are included under `evidence/` with `REPRO_`
names. `EVIDENCE_PATH_INDEX.json` maps every original absolute script path to its
flat artifact name. Reconstruct each original relative folder arrangement in a
new scratch directory where sibling imports are needed. The included parent and
child SCRIPT_CATALOG.md explain version scope and side effects. The final source
and runtime harnesses cover the affected transactions, state projections, B1/B2,
API signatures, normal catalog provenance and source identity. Child release
harnesses reconstruct exact authentic baselines, preflight package bytes and
check all four direct apply/check/rollback routes plus refusal cases.

The `wait_supervisor.py` script was a disposable test-budget aid for slow durable
writes. It paused only the child test orchestrator while the unchanged actual
installer continued; it never paused, modified or replaced an installer. Its
recorded log and authentic helper receipts distinguish waiting from product
execution. No resume/model substitution occurred.

GUI reports include real framebuffer captures and native keyboard observations.
Their final source/patch binding identifies precisely which unchanged earlier
checks remain applicable and which corrected surfaces were rechecked. No static
widget existence check alone is used as GUI acceptance.

Compare each result's source and package identities before reusing it. Historical
interim findings and canceled optional MAIN installation evidence are retained
for traceability and are not release PASS results. The final independent reports
and detached FINAL_ACCEPTANCE.json determine qualification.
