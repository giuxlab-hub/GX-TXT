// Original Native2D legend planning. Metrics, painting and hit geometry all
// use the existing shaped-text service, never byte-count width estimates.
struct LegendItem {std::string source;std::vector<std::string> display;std::vector<CaptionMeasure> lineSizes;CaptionMeasure size;};
struct LegendLayout {
 std::vector<LegendItem> items;std::vector<double> columns,rows;
 double width=0,height=0,left=0,top=0;bool clamped=false;
};
CaptionMeasure legendMeasure(Model&m,const std::string&line){
 Tcl_Obj*argv[]={s("::gx::native2d::text_metrics"),s("sans"),num(m.legendFont),s(line)};
 for(auto item:argv)Tcl_IncrRefCount(item);
 int code=Tcl_EvalObjv(m.ip,4,argv,TCL_EVAL_GLOBAL);
 for(auto item:argv)Tcl_DecrRefCount(item);
 if(code!=TCL_OK)throw std::runtime_error(Tcl_GetStringResult(m.ip));
 Ref result(Tcl_GetObjResult(m.ip));CaptionMeasure size{number(m.ip,result.p,"width",NAN),number(m.ip,result.p,"height",NAN)};
 if(!std::isfinite(size.width)||!std::isfinite(size.height)||size.width<0||size.height<1)throw std::runtime_error("Native legend text metrics are unavailable");
 return size;
}
LegendLayout legendLayout(Model&m,Panel&p,const std::string&placement,double available=INFINITY){
 LegendLayout plan;if(placement=="none"||p.series.empty())return plan;
 auto spec=get(m.ip,m.presentation.p,"legend");std::string mode=text(m.ip,spec,"layout","auto");
 size_t count=p.series.size(),columns=1;
 if(mode=="row"||(mode=="auto"&&(placement=="above"||placement=="below")))columns=count;
 else if(mode=="wrapped")columns=std::min(count,size_t(std::max(1.,number(m.ip,spec,"columns",1))));
 plan.columns.assign(columns,0);plan.rows.assign((count+columns-1)/columns,0);
 for(auto&q:p.series){auto size=legendMeasure(m,q.label);plan.items.push_back({q.label,{q.label},{size},size});}
 auto dimensions=[&](){
  std::fill(plan.columns.begin(),plan.columns.end(),0);std::fill(plan.rows.begin(),plan.rows.end(),0);
  for(size_t i=0;i<count;++i){plan.columns[i%columns]=std::max(plan.columns[i%columns],std::max(65.,plan.items[i].size.width+38));plan.rows[i/columns]=std::max(plan.rows[i/columns],plan.items[i].size.height);}
  plan.width=16;for(double width:plan.columns)plan.width+=width;
  plan.height=14+7*(plan.rows.size()-1);for(double height:plan.rows)plan.height+=height;
 };
 dimensions();
 if(plan.width>available){
  double cell=(available-16)/columns,textWidth=cell-38;
  if(textWidth<1)throw std::runtime_error("Viewport is too small for the selected legend columns; enlarge the Plot or reduce its font/columns");
  for(auto&item:plan.items){
   std::vector<std::string> lines;std::string line;
   for(const auto&run:captionRuns(item.source)){
    if(!line.empty()&&legendMeasure(m,line+run).width>textWidth){lines.push_back(line);line.clear();}
    line+=run;
    if(legendMeasure(m,line).width>textWidth)throw std::runtime_error("An indivisible legend caption exceeds the viewport; enlarge the Plot or reduce its font/columns");
   }
   if(!line.empty())lines.push_back(line);item.display=lines;item.lineSizes.clear();item.size={};
   for(const auto&part:lines){auto size=legendMeasure(m,part);if(!item.lineSizes.empty())item.size.height+=2;item.lineSizes.push_back(size);item.size.width=std::max(item.size.width,size.width);item.size.height+=size.height;}
  }
  dimensions();
 }
 return plan;
}
double legendAligned(double start,double extent,double size,const std::string&alignment){
 if(alignment=="start"||alignment=="left")return start;
 if(alignment=="end"||alignment=="right")return start+extent-size;
 return start+(extent-size)/2;
}
void legendPosition(Model&m,Panel&p,LegendLayout&plan,const std::string&placement,double margin,double aboveY,double belowY){
 if(plan.items.empty())return;
 auto spec=get(m.ip,m.presentation.p,"legend");auto align=text(m.ip,spec,"alignment","center");
 plan.left=p.right-plan.width-margin;plan.top=p.top+margin;
 auto preset=text(m.ip,spec,"inside_preset","northeast");
 if(preset.find("west")!=std::string::npos)plan.left=p.left+margin;
 if(preset.find("south")!=std::string::npos)plan.top=p.bottom-plan.height-margin;
 if(preset=="north"||preset=="south"||preset=="center")plan.left=(p.left+p.right-plan.width)/2;
 if(preset=="east"||preset=="west"||preset=="center")plan.top=(p.top+p.bottom-plan.height)/2;
 if(placement=="right"||placement=="left"){
  plan.left=placement=="right"?m.width-8-plan.width:8;
  plan.top=legendAligned(p.top,p.bottom-p.top,plan.height,align);
  if(plan.height>p.bottom-p.top)throw std::runtime_error("Viewport is too small for the complete external legend; enlarge the Plot or reduce its font/rows");
 }
 if(placement=="above"||placement=="below"){
  plan.left=legendAligned(p.left,p.right-p.left,plan.width,align);plan.top=placement=="above"?aboveY:belowY;
 }
 if(placement=="manual"){
  double x=number(m.ip,spec,"manual_x",.75)*m.width,y=(1-number(m.ip,spec,"manual_y",.85))*m.height;
  plan.left=x-plan.width/2;plan.top=y-plan.height/2;
  // Keep each original panel's legend in its own scientific ownership area,
  // matching the established historical clamp_legend_to_panel policy.
  double l=m.panels.size()>1?p.left+4:8,t=m.panels.size()>1?p.top+4:8;
  double r=m.panels.size()>1?p.right-4:m.width-8,b=m.panels.size()>1?p.bottom-4:m.height-8;
  if(plan.width>r-l||plan.height>b-t)throw std::runtime_error("Viewport is too small for the panel-owned manual legend; enlarge the Plot or reduce its font/columns");
  plan.left=std::clamp(plan.left,l,r-plan.width);plan.top=std::clamp(plan.top,t,b-plan.height);
  plan.clamped=std::abs(plan.left+plan.width/2-x)>1e-9||std::abs(plan.top+plan.height/2-y)>1e-9;
 }
 if(placement=="inside"&&(plan.width>p.right-p.left-2*margin||plan.height>p.bottom-p.top-2*margin))throw std::runtime_error("Viewport is too small for the complete inside legend; enlarge the Plot or reduce its font/columns");
 if(plan.left<0||plan.top<0||plan.left+plan.width>m.width||plan.top+plan.height>m.height)throw std::runtime_error("Selected legend placement exceeds the viewport; enlarge the Plot or adjust its alignment/font");
}
void legendDraw(Model&m,Panel&p,Tcl_Obj*out,Tcl_Obj*receipts,const LegendLayout&plan,const std::string&placement){
 if(plan.items.empty())return;
 HitScope legendHit({"legend",p.id+".legend",p.id});auto spec=get(m.ip,m.presentation.p,"legend");
 auto background=text(m.ip,spec,"background","none"),border=text(m.ip,spec,"border","off");
 primitive(out,"rectangle",{plan.left,plan.top,plan.left+plan.width,plan.top+plan.height},border=="off"||border=="0"||border=="none"?"":text(m.ip,spec,"border_color","#596777"),background);
 auto record=Tcl_NewDictObj(),items=Tcl_NewListObj(0,nullptr);put(record,"panel_id",s(p.id));put(record,"placement",s(placement));put(record,"alignment",s(text(m.ip,spec,"alignment","center")));put(record,"box",values({plan.left,plan.top,plan.left+plan.width,plan.top+plan.height}));put(record,"metrics_owner",s("Native2D.PangoCairo"));put(record,"clamped",Tcl_NewBooleanObj(plan.clamped));
 if(placement=="manual")put(record,"requested_center",values({number(m.ip,spec,"manual_x",.75)*m.width,(1-number(m.ip,spec,"manual_y",.85))*m.height}));
 for(size_t i=0;i<plan.items.size();++i){
  const auto&q=p.series[i];const auto&item=plan.items[i];HitScope itemHit({"legend",p.id+".legend."+q.id,p.id,"",q.id});
  double x=plan.left+8,y=plan.top+7;
  for(size_t c=0;c<i%plan.columns.size();++c)x+=plan.columns[c];
  for(size_t r=0;r<i/plan.columns.size();++r)y+=plan.rows[r]+7;
  y+=(plan.rows[i/plan.columns.size()]-item.size.height)/2;
  primitive(out,"line",{x,y+item.size.height/2,x+23,y+item.size.height/2},q.color,"",q.width);
  double lineY=y;
  for(size_t line=0;line<item.display.size();++line){
   auto textPrimitive=primitive(out,"text",{x+30,lineY},"#233746");put(textPrimitive,"text",s(item.display[line]));put(textPrimitive,"font_size",num(m.legendFont));put(textPrimitive,"anchor",s("nw"));put(textPrimitive,"text_engine",s("PangoCairo"));put(textPrimitive,"text_engine_version",Tcl_NewIntObj(1));put(textPrimitive,"text_layout_size",values({item.lineSizes[line].width,item.lineSizes[line].height}));
   lineY+=item.lineSizes[line].height+2;
  }
  auto identity=Tcl_NewDictObj();put(identity,"series_id",s(q.id));put(identity,"label",s(item.source));put(identity,"text_box",values({x+30,y,x+30+item.size.width,y+item.size.height}));Tcl_ListObjAppendElement(nullptr,items,identity);
 }
 put(record,"items",items);Tcl_ListObjAppendElement(nullptr,receipts,record);
}
