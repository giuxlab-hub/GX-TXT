/* Native3D Plot v4 scientific geometry adapter. Public Dataset streams supply
 * exact numerical samples and source row identity; VTK owns triangulation,
 * contours and native polydata. No legacy plot runtime is called. */
#include <tcl.h>
#include <vtkSmartPointer.h>
#include <vtkNew.h>
#include <vtkPoints.h>
#include <vtkCellArray.h>
#include <vtkPolyData.h>
#include <vtkDoubleArray.h>
#include <vtkUnsignedLongLongArray.h>
#include <vtkPointData.h>
#include <vtkFieldData.h>
#include <vtkStringArray.h>
#include <vtkDelaunay2D.h>
#include <vtkContourFilter.h>
#include <vtkXMLPolyDataWriter.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <map>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
namespace {
Tcl_Obj*s(const std::string&a){return Tcl_NewStringObj(a.c_str(),a.size());}
Tcl_Obj*get(Tcl_Interp*ip,Tcl_Obj*d,const char*k){Tcl_Obj*v=nullptr;Tcl_DictObjGet(ip,d,s(k),&v);return v;}
std::string text(Tcl_Interp*ip,Tcl_Obj*d,const char*k,std::string fallback=""){auto p=get(ip,d,k);return p?Tcl_GetString(p):fallback;}
void put(Tcl_Obj*d,const char*k,Tcl_Obj*v){Tcl_DictObjPut(nullptr,d,s(k),v);}
struct Point{double x,y,z,color;uint64_t row;bool gap=false;};
// Keep the original pd_prepare_3d grid/scatter display policies in the native
// geometry owner. Validate the complete source before retaining display samples.
struct GridIndex {
 std::map<std::pair<double,double>,vtkIdType> cells;
 std::vector<double> x,y;
};
GridIndex gridIndex(const std::vector<Point>&points){
 GridIndex grid;
 for(size_t i=0;i<points.size();++i){const auto&p=points[i];
  if(!grid.cells.emplace(std::make_pair(p.x,p.y),i).second)throw std::runtime_error("Gridded Plot has duplicate X/Y coordinates within a family");
  grid.x.push_back(p.x);grid.y.push_back(p.y);
 }
 for(auto axis:{&grid.x,&grid.y}){std::sort(axis->begin(),axis->end());axis->erase(std::unique(axis->begin(),axis->end()),axis->end());}
 if(grid.x.size()<2||grid.y.size()<2||grid.x.size()>100000||grid.y.size()>100000||grid.x.size()*grid.y.size()!=points.size())throw std::runtime_error("This Plot kind requires a complete rectangular X/Y grid within the original axis limits");
 return grid;
}
struct DisplayBudget {std::string mode;double target,threshold;bool canonical;};
double displayInteger(Tcl_Interp*ip,Tcl_Obj*request,const char*key,double fallback){
 auto value=get(ip,request,key);double n=fallback;
 if(value&&(Tcl_GetDoubleFromObj(ip,value,&n)!=TCL_OK||!std::isfinite(n)||n<100||n!=std::floor(n)))throw std::runtime_error(std::string("Invalid finite 3D display integer: ")+key);
 return n;
}
DisplayBudget displayBudget(Tcl_Interp*ip,Tcl_Obj*request){
 DisplayBudget b{text(ip,request,"reduction_mode","auto"),displayInteger(ip,request,"target_points",6000),displayInteger(ip,request,"auto_reduce_threshold",12000),text(ip,request,"source_layout")=="canonical_grid_yx"};
 if(b.mode!="auto"&&b.mode!="none"&&b.mode!="stride"&&b.mode!="minmax")throw std::runtime_error("Invalid 3D reduction mode");
 return b;
}
std::vector<size_t> displayIndices(size_t count,size_t stride){
 std::vector<size_t> result;for(size_t i=0;i<count;i+=stride)result.push_back(i);
 if(result.back()!=count-1)result.push_back(count-1);return result;
}
using DisplaySources=std::map<std::string,std::map<uint64_t,std::array<double,3>>>;
std::map<std::string,std::string> reduceDisplay(std::map<std::string,std::vector<Point>>&groups,const std::string&kind,const DisplayBudget&budget,DisplaySources&origins){
 const bool gridded=kind=="surface"||kind=="mesh"||kind=="contour3"||kind=="heatmap";
 if(gridded&&budget.canonical&&budget.mode=="minmax")throw std::runtime_error("Canonical grids do not move cell values to different physical coordinates for display reduction");
 size_t valid=0,displayed=0;for(const auto&entry:groups)valid+=entry.second.size();
 std::map<std::string,std::string> effective;
 for(auto&entry:groups){auto&points=entry.second;std::vector<Point> reduced;std::string mode="none";
  if(gridded){
   auto grid=gridIndex(points);const size_t nx=grid.x.size(),ny=grid.y.size();
   size_t stride=1;
   if(budget.mode!="none"&&(budget.mode!="auto"||points.size()>budget.threshold/groups.size()))stride=std::max(size_t(1),size_t(std::ceil(std::sqrt(points.size()/std::max(4.,std::floor(budget.target/groups.size()+.5))))));
   auto xi=displayIndices(nx,stride),yi=displayIndices(ny,stride);
   if(displayed+xi.size()*yi.size()>8000000)throw std::runtime_error("Displayed grid exceeds 8 million cells; enable display reduction");
   if(stride>1){
    const bool peak=!budget.canonical&&(budget.mode=="auto"||budget.mode=="minmax");
    mode=peak?(budget.mode=="minmax"?"grid_peak_magnitude":"grid_peak_max"):"grid_stride";
    if(peak){
     std::vector<Point> selected(xi.size()*yi.size());std::vector<bool> present(selected.size(),false);
     for(const auto&p:points){size_t x=std::lower_bound(grid.x.begin(),grid.x.end(),p.x)-grid.x.begin(),y=std::lower_bound(grid.y.begin(),grid.y.end(),p.y)-grid.y.begin();
      size_t dx=x==nx-1?xi.size()-1:std::min(x/stride,xi.size()-1),dy=y==ny-1?yi.size()-1:std::min(y/stride,yi.size()-1),index=dy+dx*yi.size();
      double score=budget.mode=="minmax"?std::abs(p.z):p.z;
      if(!present[index]||score>=(budget.mode=="minmax"?std::abs(selected[index].z):selected[index].z)){selected[index]=p;present[index]=true;}
     }
     // As in the original long-table bucket display, retain the selected
     // source-row/C pair while placing its Z at the declared grid anchor.
     for(size_t x=0;x<xi.size();++x)for(size_t y=0;y<yi.size();++y){size_t index=y+x*yi.size();if(!present[index])throw std::runtime_error("Display grid bucket has no source sample");auto p=selected[index];origins[entry.first][p.row]={p.x,p.y,p.z};p.x=grid.x[xi[x]];p.y=grid.y[yi[y]];reduced.push_back(p);}
    }else{
     for(const auto&p:points){size_t x=budget.canonical?p.row/ny:std::lower_bound(grid.x.begin(),grid.x.end(),p.x)-grid.x.begin(),y=budget.canonical?p.row%ny:std::lower_bound(grid.y.begin(),grid.y.end(),p.y)-grid.y.begin();if(budget.canonical&&p.row>=nx*ny)throw std::runtime_error("Canonical grid source ordinal exceeds its exact dimensions");if(std::binary_search(xi.begin(),xi.end(),x)&&std::binary_search(yi.begin(),yi.end(),y))reduced.push_back(p);}
    }
    points=std::move(reduced);
   }
  }else{
   bool active=budget.mode!="none"&&(budget.mode!="auto"||valid>budget.threshold);
   if(active){mode=budget.mode=="minmax"?"stride_3d":"stride";double target=std::max(3.,std::floor(budget.target*points.size()/std::max(size_t(1),valid)+.5));size_t stride=std::max(size_t(1),size_t(std::ceil(points.size()/target)));bool gap=false;
    for(size_t i=0;i<points.size();++i){gap=gap||points[i].gap;if(i%stride==0||i+1==points.size()){auto p=points[i];p.gap=gap;reduced.push_back(p);gap=false;}}points=std::move(reduced);
   }
  }
  displayed+=points.size();effective[entry.first]=mode;
 }
 return effective;
}
int geometry(ClientData,Tcl_Interp*ip,int n,Tcl_Obj*const v[]){try{if(n!=3)throw std::runtime_error("Usage: plotV4Geometry request outputDirectory");std::string kind=text(ip,v[1],"kind","line3"),path=text(ip,v[1],"input"),destination=Tcl_GetString(v[2]);std::ifstream file(path);if(!file)throw std::runtime_error("Exact staged XYZ source is unavailable");std::map<std::string,std::vector<Point>>groups;std::string line;size_t sourceCount=0;std::map<std::string,bool>gap;while(std::getline(file,line)){std::istringstream in(line);Point p;std::string family;std::string row,x,y,z,color;if(!(in>>row>>x>>y>>z>>family>>color))throw std::runtime_error("Invalid staged XYZ row");p.row=std::stoull(row);p.x=std::stod(x);p.y=std::stod(y);p.z=std::stod(z);p.color=std::stod(color);++sourceCount;if(!std::isfinite(p.x)||!std::isfinite(p.y)||!std::isfinite(p.z)||!std::isfinite(p.color)){gap[family]=true;continue;}p.gap=gap[family];gap[family]=false;groups[family].push_back(p);if(sourceCount>100000000)throw std::runtime_error("Native3D source exceeds the explicit 100M row geometry budget");}if(groups.empty())throw std::runtime_error("XYZ source has no finite coordinates");auto outputs=Tcl_NewListObj(0,nullptr);double bounds[6]={INFINITY,-INFINITY,INFINITY,-INFINITY,INFINITY,-INFINITY},scalarLo=INFINITY,scalarHi=-INFINITY;for(auto&g:groups)for(auto&p:g.second){double value=p.color;if(std::isfinite(value)){scalarLo=std::min(scalarLo,value);scalarHi=std::max(scalarHi,value);}}auto budget=displayBudget(ip,v[1]);std::map<std::string,size_t>sourceSizes;for(const auto&entry:groups)sourceSizes[entry.first]=entry.second.size();DisplaySources origins;auto reductions=reduceDisplay(groups,kind,budget,origins);int group=0;for(auto&entry:groups){auto&points=entry.second;if(text(ip,v[1],"point_order")=="sort_x")std::stable_sort(points.begin(),points.end(),[](auto&a,auto&b){return a.x<b.x;});vtkNew<vtkPoints>vertices;vertices->SetDataTypeToDouble();vtkNew<vtkDoubleArray>scalar;scalar->SetName("scientific_scalar");vtkNew<vtkUnsignedLongLongArray>rows;rows->SetName("source_row_ordinal");bool bucket=reductions[entry.first].find("grid_peak_")==0;vtkNew<vtkDoubleArray>sourceCoordinates;sourceCoordinates->SetName("source_display_coordinate");sourceCoordinates->SetNumberOfComponents(3);for(auto&p:points){vertices->InsertNextPoint(p.x,p.y,kind=="heatmap"?0:p.z);scalar->InsertNextValue(p.color);rows->InsertNextValue(p.row);if(bucket)sourceCoordinates->InsertNextTuple(origins[entry.first].at(p.row).data());scalarLo=std::min(scalarLo,p.color);scalarHi=std::max(scalarHi,p.color);}vtkNew<vtkPolyData>poly;poly->SetPoints(vertices);poly->GetPointData()->AddArray(rows);if(bucket)poly->GetPointData()->AddArray(sourceCoordinates);poly->GetPointData()->SetScalars(scalar);vtkNew<vtkCellArray>cells;if(kind=="line3"){std::vector<vtkIdType>segment;auto flush=[&](){if(segment.size()>1)cells->InsertNextCell(segment.size(),segment.data());segment.clear();};for(size_t i=0;i<points.size();++i){if(points[i].gap)flush();segment.push_back(i);}flush();poly->SetLines(cells);}else if(kind=="scatter3"){for(vtkIdType i=0;i<(vtkIdType)points.size();++i)cells->InsertNextCell(1,&i);poly->SetVerts(cells);}else if(kind=="trisurf"){vtkNew<vtkDelaunay2D>triangles;triangles->SetInputData(poly);triangles->SetTolerance(0);triangles->Update();poly->DeepCopy(triangles->GetOutput());}else{auto grid=gridIndex(points);auto&map=grid.cells;auto&xs=grid.x;auto&ys=grid.y;for(size_t j=0;j+1<ys.size();++j)for(size_t i=0;i+1<xs.size();++i){vtkIdType ids[4]={map.at({xs[i],ys[j]}),map.at({xs[i+1],ys[j]}),map.at({xs[i+1],ys[j+1]}),map.at({xs[i],ys[j+1]})};cells->InsertNextCell(4,ids);}poly->SetPolys(cells);if(kind=="contour3"){vtkNew<vtkDoubleArray> contourCoordinate;contourCoordinate->SetName("plot_v4_contour_coordinate");for(const auto& p:points)contourCoordinate->InsertNextValue(p.z);poly->GetPointData()->AddArray(contourCoordinate);double range[2];contourCoordinate->GetRange(range);int levels=12;auto l=get(ip,v[1],"contour_levels");if(l)Tcl_GetIntFromObj(ip,l,&levels);vtkNew<vtkContourFilter>contours;contours->SetInputData(poly);contours->SetInputArrayToProcess(0,0,0,vtkDataObject::FIELD_ASSOCIATION_POINTS,"plot_v4_contour_coordinate");contours->GenerateValues(std::max(2,std::min(512,levels)),range);contours->Update();poly->DeepCopy(contours->GetOutput());poly->GetPointData()->SetActiveScalars("scientific_scalar");poly->GetPointData()->RemoveArray("plot_v4_contour_coordinate");poly->GetPointData()->RemoveArray("source_row_ordinal");poly->GetPointData()->RemoveArray("source_display_coordinate");}}bool logarithmic[3]={text(ip,v[1],"x_scale")=="log",text(ip,v[1],"y_scale")=="log",text(ip,v[1],"z_scale")=="log"};
if(logarithmic[0]||logarithmic[1]||logarithmic[2]){vtkNew<vtkPolyData> mapped;vtkNew<vtkPoints> coordinates;coordinates->SetDataTypeToDouble();std::vector<vtkIdType> indices(poly->GetNumberOfPoints(),-1);mapped->GetPointData()->CopyAllocate(poly->GetPointData());for(vtkIdType i=0;i<poly->GetNumberOfPoints();++i){double p[3];poly->GetPoint(i,p);bool valid=true;for(int a=0;a<3;++a)if(logarithmic[a]){if(p[a]<=0){valid=false;break;}p[a]=std::log10(p[a]);}if(valid){auto id=coordinates->InsertNextPoint(p);indices[i]=id;mapped->GetPointData()->CopyData(poly->GetPointData(),i,id);}}mapped->SetPoints(coordinates);auto copyCells=[&](vtkCellArray*from){auto to=vtkSmartPointer<vtkCellArray>::New();from->InitTraversal();vtkIdType size;const vtkIdType*items;while(from->GetNextCell(size,items)){bool valid=true;std::vector<vtkIdType> cell;for(vtkIdType i=0;i<size;++i){auto id=indices[items[i]];if(id<0){valid=false;break;}cell.push_back(id);}if(valid)to->InsertNextCell(size,cell.data());}return to;};mapped->SetVerts(copyCells(poly->GetVerts()));mapped->SetLines(copyCells(poly->GetLines()));mapped->SetPolys(copyCells(poly->GetPolys()));poly->DeepCopy(mapped);}
if(!poly->GetNumberOfPoints())throw std::runtime_error("Logarithmic native Plot has no positive valid geometry");
double b[6];poly->GetBounds(b);for(int j=0;j<3;++j){bounds[j*2]=std::min(bounds[j*2],b[j*2]);bounds[j*2+1]=std::max(bounds[j*2+1],b[j*2+1]);}auto paletteObj=get(ip,v[1],"palette");if(paletteObj){int count;Tcl_Obj**items;if(Tcl_ListObjGetElements(ip,paletteObj,&count,&items)!=TCL_OK||count<2||count>256)throw std::runtime_error("Invalid bounded native color palette");std::vector<std::array<double,3>>palette;for(int j=0;j<count;++j){std::string color=Tcl_GetString(items[j]);std::replace(color.begin(),color.end(),';',' ');std::istringstream rgb(color);std::array<double,3>c;if(!(rgb>>c[0]>>c[1]>>c[2]))throw std::runtime_error("Invalid native RGB palette");palette.push_back(c);}double low=scalarLo,high=scalarHi;auto minimum=get(ip,v[1],"color_min"),maximum=get(ip,v[1],"color_max");double tmp;if(minimum&&Tcl_GetDoubleFromObj(ip,minimum,&tmp)==TCL_OK&&std::isfinite(tmp))low=tmp;if(maximum&&Tcl_GetDoubleFromObj(ip,maximum,&tmp)==TCL_OK&&std::isfinite(tmp))high=tmp;Tcl_ResetResult(ip);if(!(high>low)){low-=.5;high+=.5;}vtkNew<vtkDoubleArray>colors;colors->SetName("plot_v4_rgb");colors->SetNumberOfComponents(3);auto values=poly->GetPointData()->GetArray("scientific_scalar");for(vtkIdType i=0;i<poly->GetNumberOfPoints();++i){double x=values?values->GetComponent(i,0):low;double t=std::isfinite(x)?std::max(0.,std::min(1.,(x-low)/(high-low))):.5;double index=t*(count-1);int k=std::min(count-2,int(index));double f=index-k,c[3];for(int j=0;j<3;++j)c[j]=palette[k][j]*(1-f)+palette[k+1][j]*f;colors->InsertNextTuple(c);}poly->GetPointData()->AddArray(colors);}
// Persist preparation semantics in the scientific VTP artifact referenced by
// the original Workspace layer; temporary receipt fields are not provenance.
auto metadata=[&](const char*name,const std::string&value){vtkNew<vtkStringArray>field;field->SetName(name);field->InsertNextValue(value);poly->GetFieldData()->AddArray(field);};
std::string association=kind=="contour3"?"derived_contour":bucket?"display_bucket_source_row":"source_row";
metadata("plot_requested_reduction",budget.mode);metadata("plot_effective_reduction",reductions[entry.first]);metadata("plot_source_layout",text(ip,v[1],"source_layout","xyz_table"));metadata("point_identity_kind",association);metadata("input_sample_identity_kind",bucket?"display_bucket_source_row":"source_row");
if(bucket&&kind!="contour3")metadata("source_display_coordinate_space","display_coordinate_before_grid_anchor_and_native_log");
for(auto field:{std::pair<const char*,size_t>{"original_source_points",sourceSizes[entry.first]},{"display_samples",points.size()}}){vtkNew<vtkUnsignedLongLongArray>count;count->SetName(field.first);count->InsertNextValue(field.second);poly->GetFieldData()->AddArray(count);}
vtkNew<vtkDoubleArray>sourceRange;sourceRange->SetName("full_source_scalar_range");sourceRange->SetNumberOfComponents(2);double fullRange[2]={scalarLo,scalarHi};sourceRange->InsertNextTuple(fullRange);poly->GetFieldData()->AddArray(sourceRange);
std::string output=destination+"/native_plot_"+std::to_string(++group)+".vtp";vtkNew<vtkXMLPolyDataWriter>writer;writer->SetFileName(output.c_str());writer->SetInputData(poly);writer->SetDataModeToAppended();if(!writer->Write())throw std::runtime_error("Native3D scientific geometry export failed");auto d=Tcl_NewDictObj();put(d,"path",s(output));put(d,"family_identity",s(entry.first));put(d,"points",Tcl_NewWideIntObj(poly->GetNumberOfPoints()));put(d,"cells",Tcl_NewWideIntObj(poly->GetNumberOfCells()));put(d,"kind",s(kind));put(d,"point_identity_kind",s(kind=="contour3"?"derived_contour":reductions[entry.first].find("grid_peak_")==0?"display_bucket_source_row":"source_row"));put(d,"effective_reduction",s(reductions[entry.first]));put(d,"source_points",Tcl_NewWideIntObj(sourceSizes[entry.first]));put(d,"display_samples",Tcl_NewWideIntObj(points.size()));Tcl_ListObjAppendElement(ip,outputs,d);}auto result=Tcl_NewDictObj();put(result,"layers",outputs);put(result,"source_rows",Tcl_NewWideIntObj(sourceCount));put(result,"requested_reduction",s(budget.mode));put(result,"target_points",Tcl_NewDoubleObj(budget.target));put(result,"auto_reduce_threshold",Tcl_NewDoubleObj(budget.threshold));auto limits=Tcl_NewListObj(0,nullptr);for(int j=0;j<6;++j)Tcl_ListObjAppendElement(ip,limits,Tcl_NewDoubleObj(bounds[j]));put(result,"bounds",limits);auto range=Tcl_NewListObj(0,nullptr);Tcl_ListObjAppendElement(ip,range,Tcl_NewDoubleObj(scalarLo));Tcl_ListObjAppendElement(ip,range,Tcl_NewDoubleObj(scalarHi));put(result,"scalar_range",range);put(result,"owner",s("Native3D.C++.VTK.PlotDataset.v4"));Tcl_SetObjResult(ip,result);return TCL_OK;}catch(std::exception&e){Tcl_SetObjResult(ip,s(e.what()));Tcl_SetErrorCode(ip,"GXTXT","PlotV4","Native3D",nullptr);return TCL_ERROR;}}
}
extern "C" int Gx3deplotv4_Init(Tcl_Interp*ip){if(!Tcl_InitStubs(ip,"8.6",0))return TCL_ERROR;Tcl_CreateNamespace(ip,"::GX::Native3D",nullptr,nullptr);Tcl_CreateObjCommand(ip,"::GX::Native3D::plotV4Geometry",geometry,nullptr,nullptr);return TCL_OK;}
