% SPDX-License-Identifier: GPL-3.0-or-later
function active=gxtxt_plot_has_line_opacity(fig)
  active=false;lines=findall(fig,'type','line');
  for h=lines(:)'
    if(strcmpi(get(h,'visible'),'off')),continue;endif
    if(isappdata(h,'gxtxt_line_opacity'))
      value=getappdata(h,'gxtxt_line_opacity');
      if(isnumeric(value)&&isscalar(value)&&isfinite(value)&&value>=0&&value<1),active=true;return;endif
    endif
  endfor
endfunction
