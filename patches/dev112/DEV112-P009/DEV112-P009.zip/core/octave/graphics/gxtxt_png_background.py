#!/usr/bin/env python3
"""Tint the white GNUplot canvas in an already rendered PNG without redrawing data."""
import re
import json
import math
import sys
from PIL import Image


def main():
    source, target, color = sys.argv[1:4]
    protected = json.loads(sys.argv[4]) if len(sys.argv) > 4 else []
    # Octave jsonencode flattens a single four-value matrix row.
    if protected and isinstance(protected[0], (int, float)):
        protected = [protected]
    rectangles = []
    for rect in protected:
        if len(rect) != 4 or not all(type(v) in (int, float) and math.isfinite(v) for v in rect):
            raise ValueError("Invalid owned legend rectangle")
        x, y, width, height = rect
        if width < 0 or height < 0:
            raise ValueError("Invalid owned legend dimensions")
        rectangles.append((x, y, x + width, y + height))
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", color):
        raise ValueError("Plot background must be #RRGGBB")
    background = tuple(int(color[index:index + 2], 16) for index in (1, 3, 5))
    with Image.open(source) as original:
        image = original.convert("RGB")
    pixels = image.load()
    protected_pixels = [(max(0, math.floor(x0 * image.width)),
                         max(0, math.floor((1 - y1) * image.height)),
                         min(image.width, math.ceil(x1 * image.width)),
                         min(image.height, math.ceil((1 - y0) * image.height)))
                        for x0, y0, x1, y1 in rectangles]
    for y in range(image.height):
        for x in range(image.width):
            if any(x0 <= x < x1 and y0 <= y < y1 for x0, y0, x1, y1 in protected_pixels):
                continue
            red, green, blue = pixels[x, y]
            if max(red, green, blue) - min(red, green, blue) <= 2 and min(red, green, blue) >= 235:
                shade = (red + green + blue) / (3 * 255)
                pixels[x, y] = tuple(round(channel * shade) for channel in background)
    image.save(target, format="PNG")


if __name__ == "__main__":
    main()
