% SPDX-License-Identifier: GPL-3.0-or-later
function gxtxt_plot_print_line_opacity(fig,target,device,python)
% Keep the original Octave/GNUplot layout and binary scientific records; add
% only the missing ARGB line-style field supported by its Cairo terminals.
  if(nargin<4),python='python3';endif
  if(!strcmpi(graphics_toolkit(fig),'gnuplot'))
    error('GXTXT:LineOpacityToolkit','Partial line opacity requires the existing GNUplot Cairo exporter; the selected toolkit has no native RGBA line property');
  endif
  [folder,~,~]=fileparts(target);if(isempty(folder)),folder=pwd();endif
  helper=fullfile(fileparts(mfilename('fullpath')),'gxtxt_gnuplot_opacity.py');
  command=sprintf('%s %s --allocate %s',shell_quote(python),shell_quote(helper),shell_quote(folder));
  [status,message]=system(command);if(status!=0),error('GXTXT:LineOpacityTemporary','Private native export allocation failed (exit %d): %s',status,message);endif
  work=jsondecode(message);
  saved={};mapping={};reserved={};
  objects=findall(fig);fields={'color','facecolor','edgecolor','markerfacecolor','markeredgecolor'};
  for h=objects(:)'
    for fi=1:numel(fields)
      field=fields{fi};if(!isprop(h,field)),continue;endif
      value=get(h,field);
      if(isnumeric(value)&&numel(value)==3),reserved{end+1}=rgb_key(value);endif
    endfor
  endfor
  palette=get(fig,'colormap');for k=1:rows(palette),reserved{end+1}=rgb_key(palette(k,:));endfor
  next=hex2dec('010101');
  unwind_protect
    lines=findall(fig,'type','line');
    for h=lines(:)'
    if(strcmpi(get(h,'visible'),'off')),continue;endif
      if(!isappdata(h,'gxtxt_line_opacity')),continue;endif
      opacity=getappdata(h,'gxtxt_line_opacity');
      if(!isnumeric(opacity)||!isscalar(opacity)||!isfinite(opacity)||opacity<0||opacity>1),error('GXTXT:LineOpacity','Line opacity must be finite and between zero and one');endif
      if(opacity==1),continue;endif
      original=get(h,'color');
      while(true)
        key=sprintf('%06x',next);next+=1;
        if(next>hex2dec('ffffff')),error('GXTXT:LineOpacity','No unambiguous native style identity remains');endif
        if(!any(strcmp(reserved,key))),reserved{end+1}=key;break;endif
      endwhile
      rgb=[hex2dec(key(1:2)),hex2dec(key(3:4)),hex2dec(key(5:6))]/255;
      mapping{end+1}=struct('key',key,'rgb',rgb_key(original),'opacity',opacity);
      for name={'color','markerfacecolor','markeredgecolor'}
        field=name{1};value=get(h,field);
        if(isnumeric(value)&&numel(value)==3&&all(abs(value(:)-original(:))<1e-12))
          saved{end+1}=struct('handle',h,'field',field,'value',value);set(h,field,rgb);
        endif
      endfor
    endfor
    if(isempty(mapping)),error('GXTXT:LineOpacity','No declared partial-opacity line remains');endif
    if(!any(strcmp(device,{'pngcairo','svg','pdfcairo'}))),error('GXTXT:LineOpacityDevice','Unsupported original opacity export terminal');endif
    if(strcmp(device,'pdfcairo'))
      % The original PDF path is PostScript plus Ghostscript: PostScript's
      % half-scale text is prepared at twice the declared point size. Cairo's
      % .5 fontscale and Pango's 96/72 text units instead require a 1.5 factor
      % to preserve the original physical point size.
      fonts=findall(fig,'-property','fontsize');sizes=get(fonts,'fontsize');
      if(!iscell(sizes)),sizes={sizes};endif
      names=get(fonts,'fontname');if(!iscell(names)),names={names};endif
      axes_mask=arrayfun(@(h) strcmp(get(h,'type'),'axes'),fonts);
      order=[find(axes_mask(:));find(!axes_mask(:))];
      for k=order(:)'
        h=fonts(k);if(!ishandle(h)),continue;endif
        if(isprop(h,'fontsizemode')),saved{end+1}=struct('handle',h,'field','fontsizemode','value',get(h,'fontsizemode'));endif
        saved{end+1}=struct('handle',h,'field','fontsize','value',sizes{k});
        saved{end+1}=struct('handle',h,'field','fontname','value',names{k});
        if(isempty(names{k})||strcmp(names{k},'*')),set(h,'fontname','Helvetica');endif
        set(h,'fontsize',1.5*sizes{k});
      endfor
    endif
    native=fullfile(work,'native.gp');patched=fullfile(work,'opacity.gp');map=fullfile(work,'styles.json');
    [~,~,extension]=fileparts(target);rendered=fullfile(work,['rendered' extension]);
    file=fopen(map,'w');if(file<0),error('GXTXT:LineOpacityTemporary','Unable to open private native style metadata');endif
    fprintf(file,'%s\n',jsonencode(mapping));fclose(file);
    % Capture the original complete print preparation, including hardcopy
    % colors, marker/line units, nominal fonts and terminal-specific layout.
    gxtxt_plot_print(fig,rendered,['-d' device],['-debug:' native]);
    restore(saved);saved={};
    command=sprintf('%s %s %s %s %s',shell_quote(python),shell_quote(helper),shell_quote(native),shell_quote(patched),shell_quote(map));
    [status,message]=system(command);if(status!=0),error('GXTXT:LineOpacityTransport','Native style transport failed (exit %d): %s',status,message);endif
    [program,program_args]=gnuplot_binary();command=shell_quote(program);
    for k=1:numel(program_args),command=[command ' ' shell_quote(program_args{k})];endfor
    command=[command ' ' shell_quote(patched)];
    [status,message]=system(command);if(status!=0),error('GXTXT:LineOpacityRender','Original GNUplot export failed (exit %d): %s',status,message);endif
    [ok,message]=movefile(rendered,target,'f');if(!ok),error('GXTXT:LineOpacityPublish','Completed native export publication failed: %s',message);endif
  unwind_protect_cleanup
    restore(saved);
    if(exist(work,'dir')==7),rmdir(work,'s');endif
  end_unwind_protect
endfunction

function restore(saved)
  for k=numel(saved):-1:1
    item=saved{k};if(ishandle(item.handle)),set(item.handle,item.field,item.value);endif
  endfor
endfunction
function key=rgb_key(value)
  rgb=round(255*min(1,max(0,value(:)')));key=sprintf('%02x%02x%02x',rgb(1),rgb(2),rgb(3));
endfunction
function quoted=shell_quote(value)
  quoted=['''' strrep(value,'''','''\''''') ''''];
endfunction
