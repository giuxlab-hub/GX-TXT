#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Connect declared line opacity to the original GNUplot Cairo exporter.

Only generated style colors change. Native inline scientific data are copied
as opaque, length-checked binary records, never searched or decoded as commands.
The original Octave/GNUplot owners retain geometry, axes, layout and rendering.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import tempfile


def command(stream):
    data=bytearray();quote=None;escape=False;comment=False
    while True:
        char=stream.read(1)
        if not char:
            if quote is not None:raise ValueError('Truncated native command string')
            return bytes(data)
        data.extend(char)
        if len(data)>1048576:raise ValueError('Native command exceeds the bounded label budget')
        value=char[0]
        if comment:
            if value==10:return bytes(data)
            continue
        if quote is not None:
            if escape:escape=False
            elif value==92:escape=True
            elif value==quote:quote=None
        elif value in (34,39):quote=value
        elif value==35:comment=True
        elif value==10 and (len(data)<2 or data[-2]!=92):return bytes(data)


def syntax(data):
    """Remove quoted captions so their contents cannot impersonate headers."""
    output=bytearray();index=0
    while index<len(data):
        value=data[index]
        if value not in (34,39):output.append(value);index+=1;continue
        start=index;delimiter=value;index+=1
        while index<len(data):
            value=data[index];index+=1
            if value==92:index+=1
            elif value==delimiter:break
        else:raise ValueError('Unterminated native quoted string')
        quoted=data[start:index]
        if quoted in (b'"-"',b"'-'"):output.extend(b'__inline__')
        elif quoted in (b"'%float64'",b'"%float64"'):output.extend(b'__float64__')
        else:output.extend(b' ')
    return bytes(output)


def binary_size(data):
    text=syntax(data).strip()
    if text.startswith(b'set palette ') and b'binary' in text:
        found=re.search(rb'file\s+__inline__\s+binary\s+record=(\d+)\s+using\s+1:2:3:4',text)
        if not found:raise ValueError('Unsupported native palette record shape')
        return 16*int(found[1]),False
    if not re.match(rb'^(plot|splot)\s',text):return 0,False
    if text.startswith(b'splot '):raise ValueError('Line opacity adapter accepts original two-dimensional figures only')
    clauses=list(re.finditer(rb'(?:^plot|,)\s+__inline__\s*',text))
    if not clauses:raise ValueError('Unsupported native plot data source')
    total=0
    for position,found in enumerate(clauses):
        end=clauses[position+1].start() if position+1<len(clauses) else len(text)
        clause=text[found.end():end]
        if b'binary' not in clause:
            if len(clauses)==1 and re.fullmatch(rb';\s*',clause):return 0,True
            raise ValueError('Unsupported native nonbinary plot record')
        if not re.search(rb"^binary\s+format=__float64__\s",clause):
            raise ValueError('Unsupported native scientific record type')
        record=re.search(rb'\brecord=(\d+(?:x\d+)*)\b',clause)
        if not record:raise ValueError('Missing native scientific record dimensions')
        rows=math.prod(int(value) for value in record[1].split(b'x'))
        using=re.search(rb'\busing\s+(.*?)(?:\s+axes\s|\s+title\b|\s+with\b|$)',clause,re.S)
        if using:
            columns=[int(value) for value in re.findall(rb'\$(\d+)',using[1])]
            if not columns:raise ValueError('Unsupported native scientific column convention')
            width=max(columns)
        else:width=2
        if not 1<=width<=16:raise ValueError('Unsupported native scientific tuple width')
        total+=rows*width*8
    return total,False


def rewrite(source,target,mapping):
    colors={};hits={}
    for item in mapping:
        key=item['key'].lower();rgb=item['rgb'].lower();opacity=item['opacity']
        if not re.fullmatch('[0-9a-f]{6}',key) or not re.fullmatch('[0-9a-f]{6}',rgb):raise ValueError('Invalid native color identity')
        if type(opacity) not in (int,float) or not math.isfinite(opacity) or not 0<=opacity<=1:raise ValueError('Invalid finite opacity')
        if key in colors:raise ValueError('Duplicate native color identity')
        colors[key]=f'{round(255*(1-opacity)):02x}'+rgb;hits[key]=0
    records=[]
    with Path(source).open('rb') as incoming,Path(target).open('xb') as outgoing:
        while True:
            native=command(incoming)
            if not native:break
            match=re.fullmatch(rb'(\s*set style line \d+\s+linecolor rgb\s+")#([0-9a-fA-F]{6})(".*)',native,re.S)
            if match:
                key=match[2].decode().lower()
                if key in colors:
                    native=match[1]+b'#'+colors[key].encode()+match[3];hits[key]+=1
            outgoing.write(native)
            size,ascii_data=binary_size(native)
            if ascii_data:
                while True:
                    row=incoming.readline(1048577)
                    if not row or len(row)>1048576:raise ValueError('Truncated native empty-panel data')
                    outgoing.write(row)
                    if row.strip()==b'e':break
            if size:
                digest=hashlib.sha256();remaining=size
                while remaining:
                    chunk=incoming.read(min(remaining,1048576))
                    if not chunk:raise ValueError('Truncated native scientific binary record')
                    outgoing.write(chunk);digest.update(chunk);remaining-=len(chunk)
                records.append({'bytes':size,'sha256':digest.hexdigest()})
    if not all(hits.values()):raise ValueError('Original exporter omitted a declared line color')
    return {'schema':'gxtxt.gnuplot.opacity_transport.v1','changed_style_commands':sum(hits.values()),
            'opaque_binary_records_preserved':records,'renderer':'original_gnuplot_cairo'}


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allocate',type=Path,help='Allocate one private native transport directory')
    parser.add_argument('source',type=Path,nargs='?');parser.add_argument('target',type=Path,nargs='?');parser.add_argument('mapping',type=Path,nargs='?')
    args=parser.parse_args()
    try:
        if args.allocate is not None:
            if any(value is not None for value in (args.source,args.target,args.mapping)):raise ValueError('Choose allocation or rewrite')
            print(json.dumps(tempfile.mkdtemp(prefix='.gxtxt-line-opacity-',dir=args.allocate.resolve(strict=True))))
        else:
            if any(value is None for value in (args.source,args.target,args.mapping)):raise ValueError('Native source, target and style mapping are required')
            print(json.dumps(rewrite(args.source,args.target,json.loads(args.mapping.read_text()))))
    except (OSError,ValueError,KeyError,TypeError) as error:raise SystemExit('Native opacity export refused: '+str(error))
