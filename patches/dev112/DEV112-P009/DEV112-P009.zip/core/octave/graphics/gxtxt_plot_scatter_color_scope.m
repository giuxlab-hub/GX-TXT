% SPDX-License-Identifier: GPL-3.0-or-later
function lifetime=gxtxt_plot_scatter_color_scope(fig)
% GNUplot's 3D scalar-marker palette clause uses geometric Z instead of the
% separate colour column. Project only disposable original marker properties.
% Dense GNUplot scatter uses one patch; its RGB-variable packing also loses
% colour precision. Use the same per-point native patches as small scatter.
  saved={};created=[];complete=false;lifetime=[];
  if(!strcmpi(graphics_toolkit(fig),'gnuplot')),return;endif
  unwind_protect
    groups=findall(fig,'type','hggroup');
    for group=groups(:)'
      if(!isappdata(group,'__creator__')||!strcmp(getappdata(group,'__creator__'),'__scatter__')),continue;endif
      c=get(group,'cdata');z=get(group,'zdata');
      % Empty/unbound C and explicit RGB keep the original unchanged path.
      if(isempty(z)||isempty(c)||!isnumeric(c)||columns(c)!=1||numel(c)!=numel(z)),continue;endif
      ax=ancestor(group,'axes');palette=colormap(ax);limits=get(ax,'clim');
      children=findall(group,'type','patch');
      for original=children(:)'
        if(strcmp(get(original,'visible'),'off')),continue;endif
        face=get(original,'markerfacecolor');edge=get(original,'markeredgecolor');
        flat_face=ischar(face)&&strcmp(face,'flat');flat_edge=ischar(edge)&&strcmp(edge,'flat');
        if(!flat_face&&!flat_edge),continue;endif
        values=get(original,'cdata');x=get(original,'xdata');y=get(original,'ydata');zz=get(original,'zdata');
        if(columns(values)!=1||numel(values)!=numel(x)||numel(y)!=numel(x)||numel(zz)!=numel(x))
          error('GXTXT:ScatterColorShape','Original scalar scatter marker shape is inconsistent');
        endif
        rgb=gxtxt_plot_scalar_rgb(values,palette,limits);
        if(isscalar(values))
          if(flat_face),saved{end+1}=struct('handle',original,'field','markerfacecolor','value',face);set(original,'markerfacecolor',rgb);endif
          if(flat_edge),saved{end+1}=struct('handle',original,'field','markeredgecolor','value',edge);set(original,'markeredgecolor',rgb);endif
        else
          marker=get(original,'marker');size=get(original,'markersize');width=get(original,'linewidth');
          for i=1:numel(values)
            fc=face;ec=edge;if(flat_face),fc=rgb(i,:);endif;if(flat_edge),ec=rgb(i,:);endif
            h=patch('parent',group,'facecolor','none','edgecolor','none', ...
              'xdata',x(i),'ydata',y(i),'zdata',zz(i),'faces',1,'vertices',[x(i) y(i) zz(i)], ...
              'cdata',values(i),'facevertexcdata',values(i),'marker',marker, ...
              'markersize',size,'linewidth',width,'markerfacecolor',fc, ...
              'markeredgecolor',ec,'linestyle','none');
            created(end+1)=h;
          endfor
          saved{end+1}=struct('handle',original,'field','visible','value',get(original,'visible'));set(original,'visible','off');
        endif
      endfor
    endfor
    lifetime=onCleanup(@() restore(saved,created));complete=true;
  unwind_protect_cleanup
    if(!complete),restore(saved,created);endif
  end_unwind_protect
endfunction

function restore(saved,created)
  for h=created(:)',if(ishandle(h)),delete(h);endif;endfor
  for i=numel(saved):-1:1
    item=saved{i};if(ishandle(item.handle)),set(item.handle,item.field,item.value);endif
  endfor
endfunction
