% SPDX-License-Identifier: GPL-3.0-or-later
function rgb=gxtxt_plot_scalar_rgb(scalar,palette,limits)
% Existing Plot preview palette policy, shared with original hardcopy markers.
% Source values and colour-axis units remain independent of disposable RGB.
  span=diff(limits);
  if(numel(limits)!=2||any(!isfinite(limits))||span<=0)
    error('GXTXT:ScalarColorLimits','Invalid scalar colour limits');
  endif
  if(!isnumeric(palette)||columns(palette)!=3||isempty(palette)||any(!isfinite(palette(:)))||any(!isfinite(scalar(:))))
    error('GXTXT:ScalarColor','Scalar colour projection requires finite values and an RGB palette');
  endif
  idx=max(1,min(rows(palette),1+floor((scalar(:)-limits(1))/span*rows(palette))));
  rgb=palette(idx,:);
endfunction
