% SPDX-License-Identifier: GPL-3.0-or-later
function gxtxt_plot_print(fig,varargin)
% Preserve the original legend owner's background through Octave hardcopy.
% Octave exempts only its exact native legend tag from color inversion; the
% existing GNUplot legend is an ordinary owned axes, with its original tag.
  marker_projection=gxtxt_plot_scatter_color_scope(fig);
  tick_projection=gxtxt_plot_3d_tick_scope(fig);
  axs=findall(fig,'-depth',1,'type','axes');owned=false(size(axs));
  for k=1:numel(axs)
    owned(k)=isappdata(axs(k),'gxtxt_plot_legend_owner')&&isequal(getappdata(axs(k),'gxtxt_plot_legend_owner'),true);
  endfor
  if(!strcmpi(graphics_toolkit(fig),'gnuplot')||!any(owned)||!strcmpi(get(fig,'inverthardcopy'),'on'))
    print(fig,varargin{:});return;
  endif
  prior_background=get(fig,'color');changed=[];colors={};
  unwind_protect
    % Retain the original figure/data hardcopy defaults. Only the declared
    % original legend background is exempt, as native legends already are.
    set(fig,'color',[1 1 1],'inverthardcopy','off');
    for k=1:numel(axs)
      color=get(axs(k),'color');
      if(!owned(k)&&!strcmp(get(axs(k),'tag'),'legend')&&isnumeric(color))
        changed(end+1)=axs(k);colors{end+1}=color;set(axs(k),'color',[1 1 1]);
      endif
    endfor
    print(fig,varargin{:});
  unwind_protect_cleanup
    if(ishandle(fig)),set(fig,'color',prior_background,'inverthardcopy','on');endif
    for k=1:numel(changed),if(ishandle(changed(k))),set(changed(k),'color',colors{k});endif;endfor
  end_unwind_protect
endfunction
