% SPDX-License-Identifier: GPL-3.0-or-later
function lifetime = gxtxt_plot_3d_tick_scope(fig)
% Measure the original GNUplot hardcopy before thinning generated numeric text.
% Keep all tick/grid positions and arbitrary explicit labels. Data/camera/aspect/font
% owners remain unchanged; only a disposable print projection uses fewer words.
  lifetime=[];original_figure=get(0,'currentfigure');original_axes=get(fig,'currentaxes');
  previous_axes=[];if(!isempty(original_figure)&&ishandle(original_figure)),previous_axes=get(original_figure,'currentaxes');endif
  if(!strcmpi(graphics_toolkit(fig),'gnuplot')),return;endif
  axes_list=findall(fig,'type','axes');candidates={};caption_candidates={};
  for ax=axes_list(:)'
    if(!gxtxt_plot_axis_is_3d(ax)||!strcmp(get(ax,'dataaspectratiomode'),'manual')),continue;endif
    for role={'x','y','z'}
      label=get(ax,[role{1} 'label']);words=get(label,'string');
      if(ischar(words)&&!isempty(words)&&strcmp(get(label,'positionmode'),'auto')&&strcmp(get(label,'visible'),'on'))
        caption_candidates{end+1}=struct('handle',label,'axes',ax,'axis',role{1},'words',words,'interpreter',get(label,'interpreter'));
      endif
    endfor
    for which={'x','y','z'}
      axis_name=which{1};if(!strcmp(get(ax,[axis_name 'scale']),'linear')),continue;endif
      ticks=get(ax,[axis_name 'tick']);labels=get(ax,[axis_name 'ticklabel']);
      label_mode=get(ax,[axis_name 'ticklabelmode']);generated=strcmp(label_mode,'auto');
      marker=['gxtxt_numeric_tick_labels_' axis_name];
      if(!generated&&isappdata(ax,marker))
        original=getappdata(ax,marker);
        generated=isstruct(original)&&isfield(original,'ticks')&&isfield(original,'labels')&& ...
                  isequal(ticks,original.ticks)&&isequal(labels,original.labels);
      endif
      if(!generated),continue;endif
      if(ischar(labels)),labels=cellstr(labels);endif
      if(numel(ticks)<2||numel(labels)!=numel(ticks)),continue;endif
      candidates{end+1}=struct('handle',ax,'axis',axis_name,'labels',{labels}, ...
        'count',numel(ticks),'label_mode',label_mode);
    endfor
  endfor
  if(isempty(candidates)),return;endif
  work=tempname();[~,nonce]=fileparts(work);nonce=regexprep(nonce,'[^A-Za-z0-9]','');prefix=['GXZT' nonce];
  prior_mask=umask(0077);states={};anchors=[];probe_overlay=[];
  fields={'xlim','ylim','zlim','dataaspectratio','plotboxaspectratio','view', ...
          'cameraposition','cameratarget','cameraupvector','cameraviewangle', ...
          'xtick','ytick','ztick','zticklabel','xticklabel','yticklabel','xlimmode','ylimmode','zlimmode', ...
          'dataaspectratiomode','plotboxaspectratiomode','camerapositionmode', ...
          'cameratargetmode','cameraupvectormode','cameraviewanglemode', ...
          'xtickmode','ytickmode','ztickmode','xticklabelmode','yticklabelmode','zticklabelmode', ...
          'units','position','outerposition','looseinset','positionconstraint'};
  unwind_protect
    [ok,message]=mkdir(work);if(!ok),error('GXTXT:TickLayout','Cannot allocate native tick measurement: %s',message);endif
    measured_axes=unique(cellfun(@(item) item.handle,candidates));
    for ax=measured_axes(:)'
      values=cell(size(fields));
      for j=1:numel(fields),values{j}=get(ax,fields{j});endfor
      children=allchild(ax);visibility=get(children,'visible');
      if(!iscell(visibility)),visibility={visibility};endif
      text_states={};for j=1:numel(children)
        if(strcmp(get(children(j),'type'),'text'))
          text_fields={'interpreter','string','units','position','rotation','horizontalalignment','verticalalignment', ...
                       'positionmode','rotationmode','horizontalalignmentmode','verticalalignmentmode', ...
                       'xliminclude','yliminclude','zliminclude','__autopos_tag__'};
          text_values=cell(size(text_fields));for q=1:numel(text_fields),text_values{q}=get(children(j),text_fields{q});endfor
          text_states{end+1}=struct('handle',children(j),'fields',{text_fields},'values',{text_values});
        endif
      endfor
      states{end+1}=struct('handle',ax,'values',{values},'children',children,'visibility',{visibility},'text_states',{text_states});
      % Print only axes/labels through the very same splot path. A zero-length
      % private line retains that path without copying large scientific arrays.
      set(ax,'xlim',values{1},'ylim',values{2},'zlim',values{3}, ...
             'dataaspectratio',values{4},'plotboxaspectratio',values{5});
      for j=1:numel(children)
        if(!strcmp(get(children(j),'type'),'text')),set(children(j),'visible','off');endif
      endfor
      point=[mean(values{1}),mean(values{2}),mean(values{3})];
      anchors(end+1)=line('parent',ax,'xdata',point([1 1]),'ydata',point([2 2]), ...
        'zdata',point([3 3]),'color',[1 1 1],'linewidth',.001,'marker','none','handlevisibility','off','createfcn',[],'deletefcn',[]);
    endfor
    % Read fixed captions with the actual original words, independently of
    % the private tokens used only to identify generated numeric graduations.
    path=fullfile(work,'original.svg');print(fig,path,'-dsvg','-nosvgconvert');original_svg=fileread(path);
    path=fullfile(work,'original.eps');print(fig,path,'-depsc2','-loose','-nosvgconvert');original_postscript=fileread(path);
    for k=1:numel(candidates)
      tokens=arrayfun(@(i) sprintf('%sA%dL%d',prefix,k,i),1:candidates{k}.count,'uniformoutput',false);
      set(candidates{k}.handle,[candidates{k}.axis 'ticklabel'],tokens);
    endfor
    probe_overlay=text_overlay(fig);
    for k=1:numel(candidates)
      native_word(probe_overlay,candidates{k},sprintf('%sM%d',prefix,k),[.5 .5 0],'middle',0);
    endfor
    for k=1:numel(caption_candidates)
      native_caption_word(probe_overlay,caption_candidates{k},sprintf('%sC%d',prefix,k),[.5 .5 0],'middle',0);
    endfor
    path=fullfile(work,'ticks.svg');print(fig,path,'-dsvg','-nosvgconvert');svg=fileread(path);
    % The original opaque exporter uses PostScript text layout, whose native
    % caption baselines can differ from SVG even with the same requested font.
    path=fullfile(work,'ticks.eps');print(fig,path,'-depsc2','-loose','-nosvgconvert');postscript=fileread(path);
  unwind_protect_cleanup
    if(!isempty(probe_overlay)&&ishandle(probe_overlay)),delete(probe_overlay);endif
    for h=anchors(:)',if(ishandle(h)),delete(h);endif;endfor
    restore_snapshot(states,fields);
    % Refresh original derived text extents after restoring the labels; do not
    % leave token widths in the axes' read-only layout cache.
    unwind_protect
      drawnow('expose');
    unwind_protect_cleanup
      unwind_protect
        if(exist(work,'dir')==7),rmdir(work,'s');endif
      unwind_protect_cleanup
        umask(prior_mask);restore_current(fig,original_axes,original_figure,previous_axes);
      end_unwind_protect
    end_unwind_protect
  end_unwind_protect
  % Native SVG supplies screen anchors, font identity and text alignment.
  % Original Octave text extents supply glyph metrics at 100 POINTS, avoiding
  % small-font pixel quantization. No new 3D projection or font engine is used.
  [entries,offsets,canvas]=native_svg_entries(svg,candidates,prefix);
  if(isempty(canvas)),return;endif
  [original_entries,~,original_canvas]=native_svg_entries(original_svg,candidates,prefix);
  if(!isequal(canvas,original_canvas)),error('GXTXT:TickLayout','Native print canvases disagree');endif
  numeric=entries(cellfun(@(item) item.candidate>0,entries));fixed_entries={};
  for i=1:numel(original_entries)
    item=original_entries{i};generated=false;
    for j=1:numel(numeric)
      if(strcmp(item.words,numeric{j}.words)&&norm(item.point-numeric{j}.point)<.05),generated=true;break;endif
    endfor
    if(!generated),fixed_entries{end+1}=item;endif
  endfor
  entries=[numeric fixed_entries];
  caption_offsets=nan(numel(caption_candidates),2);
  if(!isempty(caption_candidates))
    [templates,~,~]=native_svg_entries(svg,candidates,[prefix 'TEMPLATE']);
    for k=1:numel(caption_candidates)
      key=sprintf('%sC%d',prefix,k);at=find(cellfun(@(item) strcmp(item.words,key),templates));
      if(numel(at)!=1),error('GXTXT:TickLayout','Native automatic caption template is unavailable');endif
      [native,matched]=opaque_text_entries(templates(at),postscript,prefix,canvas,postscript);
      if(!matched),error('GXTXT:TickLayout','Native opaque caption template is unavailable');endif
      caption_offsets(k,:)=native{1}.point-canvas/2;
    endfor
  endif
  boxes=native_text_boxes(entries);selected=cell(size(candidates));native_indices=cell(size(candidates));
  % Keep the accepted Z-spacing policy exactly where it already fits. The XY
  % additions must not replace healthy original Z output with a new policy.
  for k=1:numel(candidates)
    indices=find(cellfun(@(item) item.candidate==k,entries));
    [~,permutation]=sort(cellfun(@(item) item.index,entries(indices)));indices=indices(permutation);
    if(numel(indices)!=candidates{k}.count||!isequal(cellfun(@(item) item.index,entries(indices)),1:candidates{k}.count)),continue;endif
    native_indices{k}=indices;
    if(strcmp(candidates{k}.axis,'z'))
      points=cell2mat(cellfun(@(item) item.point,entries(indices),'uniformoutput',false)');
      sizes=cellfun(@(item) item.size,entries(indices));
      selected{k}=z_selection(points,sizes);
    else
      selected{k}=1:candidates{k}.count;
    endif
  endfor
  % Captions and all caller-owned labels are fixed obstacles. Generated words
  % may disappear only from this disposable print; every tick/grid stays put.
  fixed=find(cellfun(@(item) item.candidate==0,entries));
  accepted=fixed;
  order=[find(cellfun(@(item) strcmp(item.axis,'z'),candidates)), ...
         find(cellfun(@(item) !strcmp(item.axis,'z'),candidates))];
  for k=order
    indices=native_indices{k};if(isempty(indices)),continue;endif
    available=selected{k};keep=[];
    if(strcmp(candidates{k}.axis,'z'))
      % Retain the accepted Z calibration. Its fixed text/stroke conflicts
      % are resolved by placement, rather than losing another selected word.
      accepted=[accepted indices(available)];continue;
    endif
    for i=available
      at=indices(i);
      if(!collides(boxes(at,:),boxes(accepted,:))&&!collides(boxes(at,:),boxes(indices(keep),:)))
        keep(end+1)=i;
      endif
    endfor
    % Prefer the opposite calibration endpoint when it fits the fixed text;
    % if an entire edge fits one number, retain its central native graduation.
    last=available(end);
    if(!ismember(last,keep)&&!collides(boxes(indices(last),:),boxes(accepted,:)))
      while(!isempty(keep)&&collides(boxes(indices(last),:),boxes(indices(keep),:))),keep(end)=[];endwhile
      keep(end+1)=last;
    endif
    if(numel(keep)==1&&numel(available)>2)
      middle=available(ceil(numel(available)/2));
      if(!collides(boxes(indices(middle),:),boxes(accepted,:))),keep=middle;endif
    endif
    selected{k}=keep;accepted=[accepted indices(keep)];
  endfor
  caption_indices=zeros(1,numel(caption_candidates));
  for k=1:numel(caption_candidates)
    item=caption_candidates{k};at=find(cellfun(@(entry) entry.candidate==0&&strcmp(entry.words,item.words),entries));
    if(numel(at)==1),caption_indices(k)=at;
    elseif(!isempty(at))
      relevant=find(cellfun(@(entry) entry.handle==item.axes,candidates));reference=[];
      for j=relevant,reference=[reference native_indices{j}];endfor
      center=mean(cell2mat(cellfun(@(entry) entry.point,entries(reference),'uniformoutput',false)'),1);
      distances=cellfun(@(entry) norm(entry.point-center),entries(at));[~,j]=min(distances);caption_indices(k)=at(j);
    endif
  endfor
  caption_plans=struct('candidate',{},'point',{},'alignment',{},'angle',{});
  % Native numerical text can intersect a fixed 3D grid even when words do
  % not touch each other. Relocate only those generated words through Octave's
  % original screen-plane text painter; the scientific axes/grid stay intact.
  segments=native_strokes(svg);
  pixel_position=getpixelposition(fig);pixel=canvas./pixel_position(3:4);
  placement_boxes=native_text_boxes(entries,true);
  [opaque_entries,opaque_matched]=opaque_text_entries(entries,postscript,prefix,canvas,original_postscript);
  opaque_boxes=native_text_boxes(opaque_entries);
  placement_boxes=[min(placement_boxes(:,1:2),opaque_boxes(:,1:2)), ...
                   max(placement_boxes(:,3:4),opaque_boxes(:,3:4))];
  placements=outside_edge(entries,placement_boxes,native_indices,selected,candidates,segments,canvas,pixel);
  % Native caption layout can depend on which native tick words remain.
  % Measure the actual final mask, then refine only generated word placement.
  maximum_passes=sum(cellfun(@(item) item.count,candidates))+numel(caption_candidates)+5;
  for pass=1:maximum_passes
    plans=label_plans(candidates,native_indices,selected,placements);
    if(isempty(placements)&&isempty(caption_candidates)),break;endif
    [masked_svg,masked_postscript]=measure_masked_captions(fig,states,fields,plans,placements,candidates,offsets,canvas,caption_plans,caption_candidates,caption_offsets,original_axes,original_figure,previous_axes);
    [masked_entries,~,masked_canvas]=native_svg_entries(masked_svg,candidates,prefix);
    if(!isequal(canvas,masked_canvas)),error('GXTXT:TickLayout','Native masked print canvas changed');endif
    for i=find(cellfun(@(item) item.candidate==0,entries))
      item=entries{i};best=Inf;found=0;
      for j=1:numel(masked_entries)
        other=masked_entries{j};
        if(strcmp(item.words,other.words)&&strcmp(item.alignment,other.alignment)&&item.angle==other.angle)
          distance=norm(item.point-other.point);if(distance<best),best=distance;found=j;endif
        endif
      endfor
      if(!found),error('GXTXT:TickLayout','Original fixed caption is unavailable under the native print mask: %s',item.words);endif
      entries{i}=masked_entries{found};
    endfor
    scene_entries=entries;
    for j=find(cellfun(@(item) item.candidate>0,entries))
      item=entries{j};scene_entries{j}.candidate=0;
      moved=find([placements.candidate]==item.candidate&[placements.index]==item.index);
      if(!isempty(moved)),scene_entries{j}.point=placements(moved).point;endif
    endfor
    [opaque_entries,opaque_matched]=opaque_text_entries(scene_entries,masked_postscript,prefix,canvas,masked_postscript);

    placement_boxes=native_text_boxes(entries,true);opaque_boxes=native_text_boxes(opaque_entries);
    placement_boxes=[min(placement_boxes(:,1:2),opaque_boxes(:,1:2)),max(placement_boxes(:,3:4),opaque_boxes(:,3:4))];
    [caption_plans,caption_changed,science]=place_automatic_captions(fig,masked_svg,masked_postscript,entries,opaque_entries,caption_indices,caption_candidates,caption_plans,candidates,native_indices,pixel,canvas);
    refined=place_native_numbers(fig,masked_svg,masked_postscript,entries,opaque_entries,native_indices,selected,candidates,placements,pixel,canvas,science);
    same=isequal(placements,refined);
    placements=refined;if(same&&!caption_changed),break;endif
    if(pass==maximum_passes),error('GXTXT:TickLayout','Native numeric print mask did not stabilize');endif
  endfor
  if(!isempty(placements)||!isempty(caption_plans))
    required=find(cellfun(@(item) item.candidate==0&&!isempty(strtrim(item.words)),entries));
    for j=1:numel(placements)
      item=placements(j);required=[required native_indices{item.candidate}(item.index)];
    endfor
    missing=required(!opaque_matched(required));
    if(!isempty(missing)),error('GXTXT:TickLayout','Original opaque text footprint is unavailable for: %s',entries{missing(1)}.words);endif
  endif
  plans=label_plans(candidates,native_indices,selected,placements);
  if(isempty(plans)&&isempty(caption_plans)),return;endif
  overlay=[];if(!isempty(placements)||!isempty(caption_plans)),overlay=text_overlay(fig);endif
  lifetime=onCleanup(@() restore_labels(plans,overlay,states,fields,fig,original_axes,original_figure,previous_axes));
  freeze_science(states,fields);
  for k=1:numel(plans),set(plans{k}.handle,[plans{k}.axis 'ticklabel'],plans{k}.printed);endfor
  for j=1:numel(placements)
    item=placements(j);k=item.candidate;
    if(any(!isfinite(offsets(k,:)))),error('GXTXT:TickLayout','Native numeric text anchor is unavailable');endif
    anchor=item.point-offsets(k,:);
    position=[anchor(1)/canvas(1),1-anchor(2)/canvas(2),0];
    native_word(overlay,candidates{k},candidates{k}.labels{item.index},position,item.alignment,item.angle);
  endfor
  for j=1:numel(caption_plans)
    item=caption_plans(j);k=item.candidate;candidate=caption_candidates{k};set(candidate.handle,'string',' ');
    angle=item.angle*pi/180;offset=([cos(angle) -sin(angle);sin(angle) cos(angle)]*caption_offsets(k,:)')';
    anchor=item.point-offset;position=[anchor(1)/canvas(1),1-anchor(2)/canvas(2),0];
    native_caption_word(overlay,candidate,candidate.words,position,item.alignment,item.angle);
  endfor
  restore_current(fig,original_axes,original_figure,previous_axes);
endfunction
function plans=label_plans(candidates,native_indices,selected,placements)
  plans={};
  for k=1:numel(candidates)
    if(isempty(native_indices{k})),continue;endif
    moved=find([placements.candidate]==k);
    if(numel(selected{k})==candidates{k}.count&&isempty(moved)),continue;endif
    labels=repmat({''},size(candidates{k}.labels));labels(selected{k})=candidates{k}.labels(selected{k});
    for j=moved,labels{placements(j).index}='';endfor
    plans{end+1}=struct('handle',candidates{k}.handle,'axis',candidates{k}.axis, ...
      'labels',{candidates{k}.labels},'label_mode',candidates{k}.label_mode,'printed',{labels});
  endfor
endfunction

function restore_snapshot(states,fields)
  % Keep transient text extents out of automatic scientific limit updates.
  freeze_science(states,fields);
  for k=1:numel(states)
    state=states{k};if(!ishandle(state.handle)),continue;endif
    for j=1:numel(state.children)
      if(ishandle(state.children(j))),set(state.children(j),'visible',state.visibility{j});endif
    endfor
    for j=1:numel(fields)
      if(!endsWith(fields{j},'mode')),set(state.handle,fields{j},state.values{j});endif
    endfor
    for j=1:numel(state.text_states)
      item=state.text_states{j};if(!ishandle(item.handle)),continue;endif
      for q=1:numel(item.fields),set(item.handle,item.fields{q},item.values{q});endfor
    endfor
    for j=1:numel(fields)
      if(endsWith(fields{j},'mode')),set(state.handle,fields{j},state.values{j});endif
    endfor
    restore_frame(state,fields);
  endfor
endfunction
function freeze_science(states,fields)
  for k=1:numel(states)
    state=states{k};if(!ishandle(state.handle)),continue;endif
    values=state.values;set(state.handle,'xlim',values{1},'ylim',values{2},'zlim',values{3}, ...
      'dataaspectratio',values{4},'plotboxaspectratio',values{5});
    restore_frame(state,fields);
  endfor
endfunction
function restore_frame(state,fields)
  ax=state.handle;value=@(name) state.values{find(strcmp(fields,name),1)};
  set(ax,'units',value('units'),'looseinset',value('looseinset'),'positionconstraint',value('positionconstraint'));
  if(strcmp(value('positionconstraint'),'innerposition'))
    set(ax,'outerposition',value('outerposition'),'position',value('position'));
  else set(ax,'position',value('position'),'outerposition',value('outerposition'));
  endif
endfunction

function [svg,postscript]=measure_masked_captions(fig,states,fields,plans,placements,candidates,offsets,canvas,caption_plans,caption_candidates,caption_offsets,original_axes,original_figure,previous_axes)
  work=tempname();prior_mask=umask(0077);anchors=[];overlay=[];
  unwind_protect
    [ok,message]=mkdir(work);if(!ok),error('GXTXT:TickLayout','Cannot allocate native caption measurement: %s',message);endif
    % Use the actual original scientific plot style for this readback.
    % GNUplot's opaque automatic label layout can differ for a surface and
    % an axis-only splot even at identical limits/aspect; no arrays are copied.
    freeze_science(states,fields);
    for k=1:numel(plans),set(plans{k}.handle,[plans{k}.axis 'ticklabel'],plans{k}.printed);endfor
    if(!isempty(placements)||!isempty(caption_plans)),overlay=text_overlay(fig);endif
    for j=1:numel(placements)
      item=placements(j);k=item.candidate;anchor=item.point-offsets(k,:);
      native_word(overlay,candidates{k},candidates{k}.labels{item.index},[anchor(1)/canvas(1),1-anchor(2)/canvas(2),0],item.alignment,item.angle);
    endfor
    for j=1:numel(caption_plans)
      item=caption_plans(j);k=item.candidate;candidate=caption_candidates{k};set(candidate.handle,'string',' ');
      angle=item.angle*pi/180;offset=([cos(angle) -sin(angle);sin(angle) cos(angle)]*caption_offsets(k,:)')';
      anchor=item.point-offset;
      native_caption_word(overlay,candidate,candidate.words,[anchor(1)/canvas(1),1-anchor(2)/canvas(2),0],item.alignment,item.angle);
    endfor
    path=fullfile(work,'captions.svg');print(fig,path,'-dsvg','-nosvgconvert');svg=fileread(path);
    path=fullfile(work,'captions.eps');print(fig,path,'-depsc2','-loose','-nosvgconvert');postscript=fileread(path);
  unwind_protect_cleanup
    if(!isempty(overlay)&&ishandle(overlay)),delete(overlay);endif
    for h=anchors(:)',if(ishandle(h)),delete(h);endif;endfor
    restore_snapshot(states,fields);
    unwind_protect
      drawnow('expose');
    unwind_protect_cleanup
      unwind_protect
        if(exist(work,'dir')==7),rmdir(work,'s');endif
      unwind_protect_cleanup
        umask(prior_mask);restore_current(fig,original_axes,original_figure,previous_axes);
      end_unwind_protect
    end_unwind_protect
  end_unwind_protect
endfunction

function restore_labels(plans,overlay,states,fields,fig,axes_handle,previous_figure,previous_axes)
  if(!isempty(overlay)&&ishandle(overlay)),delete(overlay);endif
  for k=1:numel(plans)
    if(ishandle(plans{k}.handle))
      set(plans{k}.handle,[plans{k}.axis 'ticklabel'],plans{k}.labels,[plans{k}.axis 'ticklabelmode'],plans{k}.label_mode);
    endif
  endfor
  restore_snapshot(states,fields);
  drawnow('expose');
  restore_current(fig,axes_handle,previous_figure,previous_axes);
endfunction

function keep=z_selection(points,sizes)
  n=rows(points);keep=1;
  for i=2:n
    last=keep(end);
    if(norm(points(i,:)-points(last,:))>=.6*(sizes(i)+sizes(last))),keep(end+1)=i;endif
  endfor
  if(keep(end)!=n)
    while(numel(keep)>1&&norm(points(n,:)-points(keep(end),:))<.6*(sizes(n)+sizes(keep(end))))
      keep(end)=[];
    endwhile
    if(norm(points(n,:)-points(keep(end),:))>=.6*(sizes(n)+sizes(keep(end)))),keep(end+1)=n;
    elseif(numel(keep)==1),keep=ceil(n/2);endif
  endif
endfunction
function tf=collides(box,others)
  tf=!isempty(others)&&any(box(1)<others(:,3)&box(3)>others(:,1)& ...
                           box(2)<others(:,4)&box(4)>others(:,2));
endfunction
function words=svg_words(body)
  words=regexprep(body,'<[^>]*>','');
  encoded={'&lt;','&gt;','&quot;','&apos;','&amp;'};decoded={'<','>','"',"'",'&'};
  for i=1:numel(encoded),words=strrep(words,encoded{i},decoded{i});endfor
endfunction
function boxes=native_text_boxes(entries,opaque_fallback)
  if(nargin<2),opaque_fallback=false;endif
  boxes=nan(numel(entries),4);old_figure=get(0,'currentfigure');old_axes=[];
  if(!isempty(old_figure)&&ishandle(old_figure)),old_axes=get(old_figure,'currentaxes');endif
  metric_figure=[];
  unwind_protect
    metric_figure=figure('__graphics_toolkit__','gnuplot','visible','off', ...
      'handlevisibility','off','createfcn',[],'deletefcn',[]);
    metric_axes=axes('parent',metric_figure,'visible','off','createfcn',[],'deletefcn',[]);
    measure=text('parent',metric_axes,'units','pixels','position',[0 0 0], ...
      'fontunits','points','fontsize',100,'verticalalignment','baseline', ...
      'interpreter','none','createfcn',[],'deletefcn',[]);
    for i=1:numel(entries)
      item=entries{i};align='left';
      if(strcmp(item.alignment,'middle')),align='center';elseif(strcmp(item.alignment,'end')),align='right';endif
      set(measure,'string',item.words,'fontname',item.family,'horizontalalignment',align);
      extent=get(measure,'extent')*item.size/100;
      if(opaque_fallback&&strcmpi(item.family,'Arial'))
        % The original opaque EPS/Ghostscript path defaults to Helvetica,
        % whereas GNUplot SVG names Arial. Use both original native font
        % extents for placement without changing accepted label selection.
        set(measure,'fontname','Helvetica');fallback=get(measure,'extent')*item.size/100;
        low=min(extent(1:2),fallback(1:2));high=max(extent(1:2)+extent(3:4),fallback(1:2)+fallback(3:4));
        extent=[low high-low];
      endif
      corners=[extent(1) extent(1)+extent(3) extent(1)+extent(3) extent(1); ...
               -extent(2) -extent(2) -extent(2)-extent(4) -extent(2)-extent(4)];
      theta=item.angle*pi/180;corners=[cos(theta) -sin(theta);sin(theta) cos(theta)]*corners;
      boxes(i,:)=[min(corners(1,:))+item.point(1),min(corners(2,:))+item.point(2), ...
                  max(corners(1,:))+item.point(1),max(corners(2,:))+item.point(2)];
    endfor
  unwind_protect_cleanup
    if(!isempty(metric_figure)&&ishandle(metric_figure)),delete(metric_figure);endif
    if(isempty(old_figure)),set(0,'currentfigure',[]);
    elseif(ishandle(old_figure))
      set(0,'currentfigure',old_figure);
      if(!isempty(old_axes)&&ishandle(old_axes)),set(old_figure,'currentaxes',old_axes);endif
    endif
  end_unwind_protect
endfunction

function [entries,offsets,canvas]=native_svg_entries(svg,candidates,prefix)
  groups=regexp(svg,'<g([^>]*)>\s*<text[^>]*>([\s\S]*?)</text>\s*</g>','tokens');
  entries={};offsets=nan(numel(candidates),2);canvas=[];
  dimensions=regexp(svg,'viewBox="0 0 ([0-9.]+) ([0-9.]+)"','tokens','once');
  if(isempty(dimensions)),return;endif
  canvas=[str2double(dimensions{1}),str2double(dimensions{2})];
  for j=1:numel(groups)
    attributes=groups{j}{1};body=groups{j}{2};
    position=regexp(attributes,'transform="translate\(([^,]+),([^\)]+)\)','tokens','once');
    font=regexp(attributes,'font-size="([^"]+)"','tokens','once');
    family=regexp(attributes,'font-family="([^"]+)"','tokens','once');
    alignment=regexp(attributes,'text-anchor="([^"]+)"','tokens','once');
    rotation=regexp(attributes,'rotate\(([^\)]+)\)','tokens','once');
    if(isempty(position)||isempty(font)||isempty(family)||isempty(alignment)),continue;endif
    metric=regexp(body,[prefix 'M([0-9]+)'],'tokens','once');
    if(!isempty(metric))
      k=str2double(metric{1});
      if(k>=1&&k<=numel(candidates)),offsets(k,:)=[str2double(position{1}),str2double(position{2})]-canvas/2;endif
      continue;
    endif
    token=regexp(body,[prefix 'A([0-9]+)L([0-9]+)'],'tokens','once');
    candidate=0;index=0;words=svg_words(body);
    if(!isempty(token))
      candidate=str2double(token{1});index=str2double(token{2});
      if(candidate<1||candidate>numel(candidates)||index<1||index>candidates{candidate}.count),continue;endif
      words=candidates{candidate}.labels{index};
    endif
    angle=0;if(!isempty(rotation)),angle=str2double(rotation{1});endif
    entry=struct('point',[str2double(position{1}),str2double(position{2})], ...
      'size',str2double(font{1}),'family',svg_words(family{1}),'alignment',alignment{1}, ...
      'angle',angle,'words',words,'candidate',candidate,'index',index);
    if(any(!isfinite([entry.point entry.size entry.angle]))||entry.size<=0),continue;endif
    entries{end+1}=entry;
  endfor
endfunction

function [opaque,matched]=opaque_text_entries(entries,postscript,prefix,canvas,original_postscript)
  opaque=entries;matched=false(1,numel(entries));
  scale=regexp(postscript,'\n([0-9.]+) ([0-9.]+) scale\n','tokens','once');
  if(isempty(scale)),return;endif
  factor=[str2double(scale{1}),str2double(scale{2})];
  if(any(!isfinite(factor))||any(factor<=0)),return;endif
  % These are the original GNUplot PostScript text calls, not a new text
  % layout or 3D projection. Unmatched enhanced words retain the SVG fallback.
  numerical_calls=native_ps_calls(postscript);caption_calls=native_ps_calls(original_postscript);
  for i=1:numel(entries)
    item=entries{i};key=item.words;calls=caption_calls;
    if(item.candidate>0),key=sprintf('%sA%dL%d',prefix,item.candidate,item.index);calls=numerical_calls;endif
    best=Inf;
    for j=1:numel(calls)
      call=calls{j};words=call{5};
      words=strrep(strrep(strrep(words,'\(','('),'\)',')'),'\\','\');
      if(!strcmp(key,words)),continue;endif
      alignment='start';if(strcmp(call{7},'MCshow')),alignment='middle';elseif(strcmp(call{7},'MRshow')),alignment='end';endif
      angle=str2double(call{8});
      if(!strcmp(alignment,item.alignment)||abs(item.angle+angle)>1e-8),continue;endif
      theta=angle*pi/180;delta=[cos(theta) -sin(theta);sin(theta) cos(theta)]*[0;str2double(call{6})*factor(2)];
      point=[str2double(call{1})*factor(1)+delta(1), ...
             canvas(2)-str2double(call{2})*factor(2)-delta(2)];
      distance=norm(point-item.point);
      if(distance<best)
        best=distance;matched(i)=true;opaque{i}.point=point;opaque{i}.size=str2double(call{4})*factor(2);opaque{i}.family=call{3};opaque{i}.ps_span=[call{9} call{10}];
      endif
    endfor
  endfor
endfunction

function calls=native_ps_calls(postscript)
  pattern=['\n([-+0-9.]+) ([-+0-9.]+) M\s*\[\s*\[\(([^)]+)\) ' ...
    '([0-9.]+) [^\n]*? \(([^\n]*)\)\]\s*\]\s*([-+0-9.]+) (M[CLR]show)'];
  calls=regexp(postscript,pattern,'tokens');[starts,ends]=regexp(postscript,pattern);
  for j=1:numel(calls),calls{j}{8}='0';calls{j}{9}=starts(j);calls{j}{10}=ends(j);endfor
  pattern=['\n([-+0-9.]+) ([-+0-9.]+) M\s*' ...
    'currentpoint gsave translate ([-+0-9.]+) rotate 0 0 moveto\s*\[\s*\[\(([^)]+)\) ' ...
    '([0-9.]+) [^\n]*? \(([^\n]*)\)\]\s*\]\s*([-+0-9.]+) (M[CLR]show)'];
  rotated=regexp(postscript,pattern,'tokens');[starts,ends]=regexp(postscript,pattern);
  for j=1:numel(rotated),calls{end+1}=[rotated{j}([1 2 4 5 6 7 8 3]) {starts(j),ends(j)}];endfor
  % Source captions with interpreter=none use ordinary native show calls.
  pattern=['/[^\s/]+ findfont [0-9.]+ scalefont setfont|/vshift [-+0-9.]+ def|' ...
    '\n[-+0-9.]+ [-+0-9.]+ M\n|currentpoint gsave translate [-+0-9.]+ rotate 0 0 (?:moveto|M)|' ...
    '\((?:\\.|[^\\\n)])*\) [CLR]show'];
  tags=regexp(postscript,pattern,'match');[starts,ends]=regexp(postscript,pattern);
  family='';size='';shift='';point={};angle='0';
  for j=1:numel(tags)
    tag=tags{j};font=regexp(tag,'^/([^\s/]+) findfont ([0-9.]+) scalefont setfont$','tokens','once');
    if(!isempty(font)),family=font{1};size=font{2};continue;endif
    value=regexp(tag,'^/vshift ([-+0-9.]+) def$','tokens','once');
    if(!isempty(value)),shift=value{1};continue;endif
    value=regexp(tag,'^\n([-+0-9.]+) ([-+0-9.]+) M\n$','tokens','once');
    if(!isempty(value)),point=value;angle='0';continue;endif
    value=regexp(tag,'^currentpoint gsave translate ([-+0-9.]+) rotate','tokens','once');
    if(!isempty(value)),angle=value{1};continue;endif
    value=regexp(tag,'^\((.*)\) ([CLR]show)$','tokens','once');
    if(!isempty(value)&&!isempty(point)&&!isempty(family)&&!isempty(size)&&!isempty(shift))
      calls{end+1}={point{1},point{2},family,size,value{1},shift,['M' value{2}],angle,starts(j),ends(j)};
    endif
  endfor
endfunction

function [plans,changed,science]=place_automatic_captions(fig,svg,postscript,entries,opaque,indices,captions,plans,candidates,native_indices,pixel,canvas)
  changed=false;science=[];if(isempty(captions)),return;endif
  vector_boxes=native_text_boxes(entries,true);opaque_boxes=native_text_boxes(opaque);
  vector_boxes=[min(vector_boxes(:,1:2),opaque_boxes(:,1:2)),max(vector_boxes(:,3:4),opaque_boxes(:,3:4))];
  segments=native_strokes(svg);polygons=native_polygon_boxes(svg);
  for k=1:numel(captions)
    at=indices(k);if(!at),continue;endif
    item=opaque{at};box=vector_boxes(at,:)+pixel([1 2 1 2]).*[-1 -1 1 1];
    generated=find(cellfun(@(entry) entry.candidate>0,entries));
    other_text=setdiff(1:numel(entries),[at generated]);
    vector_contact=stroke_contact(box,segments,true)||collides(box,polygons)||collides(box,vector_boxes(other_text,:));
    if(!vector_contact)
      if(isempty(native_ghostscript())),continue;endif
      if(isempty(science)),science=native_ink_mask(fig,postscript,[],'science',pixel);endif
      if(!native_box_ink(box,science,pixel)),continue;endif
    endif
    if(isempty(native_ghostscript()))
      relevant=find(cellfun(@(entry) entry.handle==captions{k}.axes,candidates));reference=[];edge=[];
      for j=relevant
        reference=[reference native_indices{j}];
        if(strcmp(candidates{j}.axis,captions{k}.axis)),edge=native_indices{j};endif
      endfor
      normal=measured_normal(entries,edge,reference,item.point);
      shift=vector_clearance(vector_boxes(at,:),segments,polygons,vector_boxes(other_text,:),normal,pixel,canvas);
      if(any(shift))
        point=item.point+shift;old=find([plans.candidate]==k);
        if(isempty(old)),plans(end+1)=struct('candidate',k,'point',point,'alignment',entries{at}.alignment,'angle',entries{at}.angle);else plans(old).point=point;endif
        changed=true;
      endif
      continue;
    endif
    if(isempty(science)),science=native_ink_mask(fig,postscript,[],'science',pixel);endif
    if(!isfield(item,'ps_span')),error('GXTXT:TickLayout','Native automatic caption footprint is unavailable: %s',captions{k}.words);endif
    glyph=native_ink_mask(fig,postscript,item.ps_span,'glyph',pixel);
    [yy,xx]=find(glyph);
    if(isempty(xx)),error('GXTXT:TickLayout','Native automatic caption ink is unavailable: %s',captions{k}.words);endif
    excluded=native_spans(opaque,[at generated]);
    other=native_ink_mask(fig,postscript,excluded,'other',pixel);
    obstacles=science|other;
    if(!vector_contact&&!ink_overlap(xx,yy,obstacles)),continue;endif
    if(!ink_contact(xx,yy,obstacles)),continue;endif
    relevant=find(cellfun(@(entry) entry.handle==captions{k}.axes,candidates));reference=[];edge=[];
    for j=relevant
      reference=[reference native_indices{j}];
      if(strcmp(candidates{j}.axis,captions{k}.axis)),edge=native_indices{j};endif
    endfor
    points=cell2mat(cellfun(@(entry) entry.point,entries(reference),'uniformoutput',false)');center=mean(points,1);
    if(numel(edge)>=2)
      tangent=entries{edge(end)}.point-entries{edge(1)}.point;normal=[-tangent(2),tangent(1)];
      midpoint=(entries{edge(1)}.point+entries{edge(end)}.point)/2;
      if(dot(midpoint-center,normal)<0),normal=-normal;endif
    else normal=item.point-center;
    endif
    if(norm(normal)==0),error('GXTXT:TickLayout','Native automatic caption has no measured outside direction');endif
    normal=normal/norm(normal);found=false;last=[0 0];
    for distance=1:max(size(glyph))
      shift=round(normal*distance);if(isequal(shift,last)),continue;endif;last=shift;
      if(!ink_contact(xx+shift(1),yy+shift(2),obstacles)),found=true;break;endif
    endfor
    if(!found),error('GXTXT:TickLayout','Automatic caption cannot fit outside its native edge; enlarge the output viewport');endif
    point=item.point+shift.*pixel;old=find([plans.candidate]==k);
    if(isempty(old)),plans(end+1)=struct('candidate',k,'point',point,'alignment',entries{at}.alignment,'angle',entries{at}.angle);else plans(old).point=point;endif
    changed=true;
  endfor
endfunction
function placements=place_native_numbers(fig,svg,postscript,entries,opaque,indices,selected,candidates,placements,pixel,canvas,science)
  segments=native_strokes(svg);polygons=native_polygon_boxes(svg);
  scene_boxes=native_text_boxes(opaque);visible=find(cellfun(@(item) item.candidate==0,entries));
  for k=1:numel(indices),if(!isempty(indices{k})),visible=[visible indices{k}(selected{k})];endif;endfor
  priority=[find(cellfun(@(item) strcmp(item.axis,'z'),candidates)),find(cellfun(@(item) strcmp(item.axis,'x'),candidates)),find(cellfun(@(item) strcmp(item.axis,'y'),candidates))];
  pending=[];for k=priority,pending=[pending indices{k}(selected{k})];endfor
  for k=priority
    if(isempty(indices{k})),continue;endif
    for n=selected{k}
      at=indices{k}(n);item=opaque{at};box=scene_boxes(at,:)+pixel([1 2 1 2]).*[-1 -1 1 1];
      pending=setdiff(pending,at);
      others=setdiff(visible,[at pending]);
      vector_contact=stroke_contact(box,segments,true)||collides(box,polygons)||collides(box,scene_boxes(others,:));
      if(!vector_contact)
        if(isempty(native_ghostscript())),continue;endif
        % SVG can omit a fixed stroke that intersects the same word in EPS.
        % The one shared original native science mask is authoritative for
        % opaque output; a clear SVG envelope alone cannot skip this test.
        if(isempty(science)),science=native_ink_mask(fig,postscript,[],'science',pixel);endif
        if(!native_box_ink(box,science,pixel)),continue;endif
      endif
      if(isempty(native_ghostscript()))
        reference=[];relevant=find(cellfun(@(entry) entry.handle==candidates{k}.handle,candidates));
        for j=relevant,reference=[reference indices{j}];endfor
        normal=measured_normal(entries,indices{k},reference,item.point);
        shift=vector_clearance(scene_boxes(at,:),segments,polygons,scene_boxes(others,:),normal,pixel,canvas);
        if(any(shift))
          moved=find([placements.candidate]==k&[placements.index]==n);
          if(!isempty(moved)),placements(moved).point+=shift;
          else placements(end+1)=struct('candidate',k,'index',n,'point',item.point+shift,'alignment',entries{at}.alignment,'angle',entries{at}.angle);endif
        endif
        continue;
      endif
      if(!isfield(item,'ps_span')),error('GXTXT:TickLayout','Native generated numeric footprint is unavailable: %s',entries{at}.words);endif
      if(isempty(science)),science=native_ink_mask(fig,postscript,[],'science',pixel);endif
      glyph=native_ink_mask(fig,postscript,item.ps_span,'glyph',pixel);[yy,xx]=find(glyph);
      if(isempty(xx)),error('GXTXT:TickLayout','Native generated numeric ink is unavailable: %s',entries{at}.words);endif
      other=native_ink_mask(fig,postscript,native_spans(opaque,[at pending]),'other',pixel);obstacles=science|other;
      % Preserve an already clear vector control when the newly consulted
      % opaque mask has only adjacent pixels, rather than shared glyph ink.
      if(!vector_contact&&!ink_overlap(xx,yy,obstacles)),continue;endif
      if(!ink_contact(xx,yy,obstacles)),continue;endif
      ends=cell2mat(cellfun(@(entry) entry.point,entries(indices{k}([1 end])),'uniformoutput',false)');
      tangent=ends(2,:)-ends(1,:);normal=[-tangent(2),tangent(1)];reference=[];
      relevant=find(cellfun(@(entry) entry.handle==candidates{k}.handle,candidates));
      for j=relevant,reference=[reference indices{j}];endfor
      center=mean(cell2mat(cellfun(@(entry) entry.point,entries(reference),'uniformoutput',false)'),1);
      if(dot(mean(ends,1)-center,normal)<0),normal=-normal;endif
      if(norm(normal)==0),error('GXTXT:TickLayout','Native generated number has no measured outside direction');endif
      normal=normal/norm(normal);found=false;last=[0 0];
      for distance=1:max(size(glyph))
        shift=round(normal*distance);if(isequal(shift,last)),continue;endif;last=shift;
        if(!ink_contact(xx+shift(1),yy+shift(2),obstacles)),found=true;break;endif
      endfor
      if(!found),error('GXTXT:TickLayout','Generated number cannot fit outside its native edge; enlarge the output viewport');endif
      moved=find([placements.candidate]==k&[placements.index]==n);
      if(!isempty(moved)),placements(moved).point+=shift.*pixel;
      else
        % Ordinary middle-aligned overlay baseline and SVG differ only by
        % their measured vertical text offset; the following iteration reads
        % its exact new native ink before accepting the print.
        point=item.point+shift.*pixel;
        placements(end+1)=struct('candidate',k,'index',n,'point',point,'alignment',entries{at}.alignment,'angle',entries{at}.angle);
      endif
    endfor
  endfor
endfunction
function boxes=native_polygon_boxes(svg)
  boxes=zeros(0,4);polygons=regexp(svg,'<polygon([^>]*)>','tokens');
  for j=1:numel(polygons)
    points=regexp(polygons{j}{1},'points=["'']([^"'']+)','tokens','once');if(isempty(points)),continue;endif
    values=sscanf(strrep(points{1},',',' '),'%f');if(mod(numel(values),2)||isempty(values)),continue;endif
    values=reshape(values,2,[])';boxes(end+1,:)=[min(values,[],1) max(values,[],1)];
  endfor
endfunction
function yes=native_box_ink(box,ink,pixel)
  % Check an already measured native text envelope against existing native
  % paint. These are hardcopy/output coordinates, not a new 3D projection.
  first=max([1 1],floor(box(1:2)./pixel)+1);
  last=min([columns(ink) rows(ink)],ceil(box(3:4)./pixel)+1);
  yes=all(first<=last)&&any(any(ink(first(2):last(2),first(1):last(1))));
endfunction
function yes=ink_overlap(xx,yy,obstacles)
  yes=any(obstacles(sub2ind(size(obstacles),yy,xx)));
endfunction
function yes=ink_contact(xx,yy,obstacles)
  yes=true;[height,width]=size(obstacles);
  if(any(xx<=1)||any(yy<=1)||any(xx>=width)||any(yy>=height)),return;endif
  for dy=-1:1,for dx=-1:1
    if(any(obstacles(sub2ind([height width],yy+dy,xx+dx)))),return;endif
  endfor;endfor
  yes=false;
endfunction
function normal=measured_normal(entries,edge,reference,point)
  center=mean(cell2mat(cellfun(@(entry) entry.point,entries(reference),'uniformoutput',false)'),1);
  if(numel(edge)>=2)
    tangent=entries{edge(end)}.point-entries{edge(1)}.point;normal=[-tangent(2),tangent(1)];
    midpoint=(entries{edge(1)}.point+entries{edge(end)}.point)/2;
    if(dot(midpoint-center,normal)<0),normal=-normal;endif
  else normal=point-center;
  endif
  if(norm(normal)==0),error('GXTXT:TickLayout','Native text has no measured outside direction');endif
  normal=normal/norm(normal);
endfunction
function shift=vector_clearance(box,segments,polygons,other,normal,pixel,canvas)
  % Without the original optional rasterizer, use conservative original
  % native font/path envelopes. This is vector clearance, not raster proof.
  shift=[0 0];
  for distance=0:max(pixel):norm(canvas)
    shift=normal*distance;current=box+shift([1 2 1 2]);
    current=[floor(current(1:2)./pixel).*pixel-pixel,ceil(current(3:4)./pixel).*pixel+pixel];
    if(any(current(1:2)<0)||any(current(3:4)>canvas)),continue;endif
    if(!stroke_contact(current,segments,true)&&!collides(current,polygons)&&!collides(current,other)),return;endif
  endfor
  error('GXTXT:TickLayout','Native vector text envelopes cannot fit outside their edge; enlarge the output viewport');
endfunction
function value=native_ghostscript()
  value=getenv('GSC');
  if(!isempty(value)&&exist(value,'file')!=2),value=file_in_path(getenv('PATH'),value);endif
  if(isempty(value)),value=file_in_path(getenv('PATH'),'gs');endif
endfunction
function spans=native_spans(entries,indices)
  spans=zeros(0,2);for j=indices
    if(isfield(entries{j},'ps_span')),spans(end+1,:)=entries{j}.ps_span;endif
  endfor
  spans=sortrows(unique(spans,'rows'),1);
endfunction
function ink=native_ink_mask(fig,postscript,span,kind,pixel)
  % Original GNUplot has already laid out this hardcopy. Reuse its configured
  % Ghostscript font/path painter; select paint only, never project or copy data.
  work=tempname();prior_mask=umask(0077);
  unwind_protect
    [ok,message]=mkdir(work);if(!ok),error('GXTXT:TickLayout','Cannot allocate native ink readback: %s',message);endif
    for j=rows(span):-1:1
      first=span(j,1);last=span(j,2);
      postscript=[postscript(1:first-1) sprintf('\n/GXTXTInkSelected true def\n') ...
        postscript(first:last) sprintf('\n/GXTXTInkSelected false def\n') postscript(last+1:end)];
    endfor
    condition='false';paint='';
    if(strcmp(kind,'glyph')),condition='GXTXTInkSelected';elseif(strcmp(kind,'other')),condition='GXTXTInkSelected not';endif
    if(!strcmp(kind,'science')),paint=['/stroke {newpath} bind def /fill {newpath} bind def /eofill {newpath} bind def ' ...
        '/image {gsave newpath 0 0 moveto 0 0 lineto closepath clip systemdict /image get exec grestore} bind def ' ...
        '/colorimage {gsave newpath 0 0 moveto 0 0 lineto closepath clip systemdict /colorimage get exec grestore} bind def ' ...
        '/imagemask {gsave newpath 0 0 moveto 0 0 lineto closepath clip systemdict /imagemask get exec grestore} bind def'];endif
    program=sprintf(['\n%%%%GXTXT-Native-Ink-Mask\n/GXTXTInkSelected false def\n%s\n' ...
      '/show {gsave 0 setgray dup %s {systemdict /show get exec} {pop} ifelse grestore stringwidth rmoveto} bind def\n'],paint,condition);
    first=find(postscript==sprintf('\n'),1);postscript=[postscript(1:first) program postscript(first+1:end)];
    source=fullfile(work,'native.eps');target=fullfile(work,'native.png');fid=fopen(source,'w');
    if(fid<0),error('GXTXT:TickLayout','Cannot write native ink readback');endif
    unwind_protect,fputs(fid,postscript);unwind_protect_cleanup,fclose(fid);end_unwind_protect
    ghostscript=native_ghostscript();
    if(isempty(ghostscript)),error('GXTXT:TickLayout','The configured original Ghostscript renderer is unavailable');endif
    position=getpixelposition(fig);dpi=round(72./pixel);
    command=sprintf(['%s -dQUIET -dNOPAUSE -dBATCH -dSAFER -dAutoRotatePages=/None -sDEVICE=png16m ' ...
      '-dLanguageLevel=2 -dTextAlphaBits=4 -dGraphicsAlphaBits=4 -r%dx%d -g%dx%d -dFIXEDMEDIA -dEPSCrop -sOutputFile=%s %s'], ...
      gxtxt_shell_quote_v1(ghostscript),dpi(1),dpi(2),round(position(3)),round(position(4)),gxtxt_shell_quote_v1(target),gxtxt_shell_quote_v1(source));
    [status,message]=system(command);if(status!=0),error('GXTXT:TickLayout','Original native ink readback failed: %s',message);endif
    pixels=imread(target);background=[255 255 255];
    if(strcmp(kind,'science'))
      value=regexp(postscript,'/BackgroundColor \{([-+0-9.]+) ([-+0-9.]+) ([-+0-9.]+)\}','tokens','once');
      if(!isempty(value)),rgb=cellfun(@str2double,value);if(all(rgb>=0)),background=round(255*rgb);endif;endif
    endif
    ink=any(pixels!=reshape(uint8(background),1,1,3),3);
  unwind_protect_cleanup
    unwind_protect
      if(exist(work,'dir')==7),rmdir(work,'s');endif
    unwind_protect_cleanup
      umask(prior_mask);
    end_unwind_protect
  end_unwind_protect
endfunction

function overlay=text_overlay(fig)
  overlay=axes('parent',fig,'units','normalized','position',[0 0 1 1], ...
    'positionconstraint','innerposition','color','none','visible','off', ...
    'handlevisibility','off','xlim',[0 1],'ylim',[0 1],'xtick',[],'ytick',[], ...
    'clipping','off','createfcn',[],'deletefcn',[]);
endfunction
function word=native_word(parent,candidate,words,position,alignment,angle)
  ax=candidate.handle;align='left';
  if(strcmp(alignment,'middle')),align='center';elseif(strcmp(alignment,'end')),align='right';endif
  % GNUplot's original get_fontname_and_size serializes this exact axes
  % fontsize. Retain its physical hardcopy size; copying normalized units
  % onto a full-figure overlay would reinterpret them against another box.
  % Use the overlay's explicit [0,1] data coordinates. GNUplot converts
  % normalized child text during print; its first conversion can retain the
  % preceding scientific axes transform after a hardcopy resize.
  word=text('parent',parent,'units','data','position',position,'string',words, ...
    'fontunits','points','fontsize',get(ax,'fontsize'), ...
    'fontname',get(ax,'fontname'),'fontweight',get(ax,'fontweight'),'fontangle',get(ax,'fontangle'), ...
    'color',get(ax,[candidate.axis 'color']),'interpreter',get(ax,'ticklabelinterpreter'), ...
    'horizontalalignment',align,'verticalalignment','middle','rotation',angle, ...
    'clipping','off','handlevisibility','off','createfcn',[],'deletefcn',[]);
endfunction
function word=native_caption_word(parent,candidate,words,position,alignment,angle)
  original=candidate.handle;align='left';if(strcmp(alignment,'middle')),align='center';elseif(strcmp(alignment,'end')),align='right';endif
  word=text('parent',parent,'units','data','position',position,'string',words, ...
    'fontunits','points','fontsize',get(original,'fontsize'),'fontname',get(original,'fontname'), ...
    'fontweight',get(original,'fontweight'),'fontangle',get(original,'fontangle'), ...
    'color',get(original,'color'),'interpreter',candidate.interpreter, ...
    'horizontalalignment',align,'verticalalignment','middle', ...
    'rotation',-angle,'clipping','off','handlevisibility','off','createfcn',[],'deletefcn',[]);
endfunction
function restore_current(fig,axes_handle,previous_figure,previous_axes)
  if(ishandle(fig)&&!isempty(axes_handle)&&ishandle(axes_handle)),set(fig,'currentaxes',axes_handle);endif
  if(isempty(previous_figure)),set(0,'currentfigure',[]);
  elseif(ishandle(previous_figure))
    set(0,'currentfigure',previous_figure);
    if(!isempty(previous_axes)&&ishandle(previous_axes)),set(previous_figure,'currentaxes',previous_axes);endif
  endif
endfunction
function segments=native_strokes(svg)
  segments=zeros(0,5);widths=1;
  % Retain the original native stroke width as well as its centerline. Grid
  % and tick ink occupies half that width on either side in the opaque output.
  tags=regexp(svg,'<g(?:\s[^>]*)?>|</g>|<path[^>]*>','match');
  for j=1:numel(tags)
    attributes=tags{j};
    if(strcmp(attributes,'</g>')),if(numel(widths)>1),widths(end)=[];endif;continue;endif
    width=widths(end);specified=regexp(attributes,'stroke-width=["'']([0-9.]+)','tokens','once');
    if(!isempty(specified)),width=str2double(specified{1});endif
    if(strncmp(attributes,'<g',2)),widths(end+1)=width;continue;endif
    if(!isempty(regexp(attributes,'stroke=["''](?:none|rgb\(\s*255,\s*255,\s*255\))','once'))),continue;endif
    d=regexp(attributes,'d=["'']([^"'']*)','tokens','once');if(isempty(d)),continue;endif
    points=regexp(d{1},'([ML])([-+0-9.]+),([-+0-9.]+)','tokens');previous=[];
    for k=1:numel(points)
      point=[str2double(points{k}{2}),str2double(points{k}{3})];
      if(strcmp(points{k}{1},'L')&&!isempty(previous)&&any(point!=previous)),segments(end+1,:)=[previous point width/2];endif
      previous=point;
    endfor
  endfor
endfunction
function tf=stroke_contact(box,segments,include_width)
  if(nargin<3),include_width=false;endif
  tf=false;
  if(isempty(segments)),return;endif
  radius=zeros(rows(segments),1);if(include_width),radius=segments(:,5);endif
  possible=segments(max(segments(:,[1 3]),[],2)+radius>=box(1)&min(segments(:,[1 3]),[],2)-radius<=box(3)& ...
                    max(segments(:,[2 4]),[],2)+radius>=box(2)&min(segments(:,[2 4]),[],2)-radius<=box(4),:);
  for i=1:rows(possible)
    test_box=box;if(include_width),test_box+=possible(i,5)*[-1 -1 1 1];endif
    p=possible(i,1:2);delta=possible(i,3:4)-p;low=0;high=1;
    normals=[-delta(1),delta(1),-delta(2),delta(2)];
    distances=[p(1)-test_box(1),test_box(3)-p(1),p(2)-test_box(2),test_box(4)-p(2)];
    for j=1:4
      if(normals(j)==0)
        if(distances(j)<0),low=1;high=0;break;endif
      elseif(normals(j)<0),low=max(low,distances(j)/normals(j));
      else high=min(high,distances(j)/normals(j));endif
    endfor
    if(low<=high),tf=true;return;endif
  endfor
endfunction
function placements=outside_edge(entries,boxes,indices,selected,candidates,segments,canvas,pixel,prior)
  if(nargin<9),prior=[];endif
  placements=struct('candidate',{},'index',{},'point',{},'alignment',{},'angle',{});
  if(isempty(entries)),return;endif
  numeric=find(cellfun(@(item) item.candidate>0,entries));
  if(isempty(numeric)),return;endif
  points=cell2mat(cellfun(@(item) item.point,entries(numeric),'uniformoutput',false)');
  center=(min(points,[],1)+max(points,[],1))/2;
  visible=find(cellfun(@(item) item.candidate==0,entries));
  for k=1:numel(indices),if(!isempty(indices{k})),visible=[visible indices{k}(selected{k})];endif;endfor
  current=boxes;
  for k=1:numel(indices)
    if(isempty(indices{k})||isempty(selected{k})),continue;endif
    group=indices{k}(selected{k});
    obstacles=setdiff(visible,group);
    affected=group(arrayfun(@(i) stroke_contact(current(i,:),segments)||collides(current(i,:),current(obstacles,:)),group));
    if(!isempty(prior))
      forced=find([prior.candidate]==k);
      if(!isempty(forced)),affected=union(affected,indices{k}([prior(forced).index]));endif
    endif
    if(isempty(affected)),continue;endif
    % Retain healthy Z anchors; only its actually obstructed selected words
    % need an independent outward placement. Existing Z selection is unchanged.
    if(strcmp(candidates{k}.axis,'z')),group=affected;endif
    ends=cell2mat(cellfun(@(item) item.point,entries(indices{k}([1 end])),'uniformoutput',false)');
    tangent=ends(2,:)-ends(1,:);normal=[-tangent(2),tangent(1)];
    if(norm(normal)==0),continue;endif
    normal=normal/norm(normal);
    if(dot(mean(ends,1)-center,normal)<0),normal=-normal;endif
    obstacles=setdiff(visible,group);found=false;
    % Search on the requested output pixel lattice. Quantize both text
    % footprints outward and reserve one physical pixel of clear background;
    % this covers opaque PS/Ghostscript phase without percentage font padding.
    for distance=max(pixel):max(pixel):norm(canvas)
      shift=normal*distance;clearance=true;
      for i=group
        box=current(i,:)+shift([1 2 1 2]);
        ink=[floor(box(1:2)./pixel).*pixel-pixel,ceil(box(3:4)./pixel).*pixel+pixel];
        other=[floor(current(obstacles,1:2)./pixel).*pixel,ceil(current(obstacles,3:4)./pixel).*pixel];
        if(any(ink(1:2)<0)||any(ink(3:4)>canvas)||stroke_contact(ink,segments,true)||collides(ink,other))
          clearance=false;break;
        endif
      endfor
      if(clearance),found=true;break;endif
    endfor
    if(!found),error('GXTXT:TickLayout','Generated 3D numbers cannot fit outside their native edge; enlarge the output viewport');endif
    for i=group
      item=entries{i};current(i,:)+=shift([1 2 1 2]);
      placements(end+1)=struct('candidate',k,'index',item.index,'point',item.point+shift, ...
        'alignment',item.alignment,'angle',item.angle);
    endfor
  endfor
endfunction
