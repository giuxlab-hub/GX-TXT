# SPDX-License-Identifier: GPL-3.0-or-later
# Read/render-only transient exporter. Owned by the consultation cancellation path.
lassign $argv octave script cache runtime output python converter expectation
if {[catch {
    set arguments [list $cache $runtime [file join $output plot]]
    if {$expectation ne {}} {lappend arguments $expectation}
    exec -- $octave --quiet --no-gui $script {*}$arguments 2>@1
    if {[info exists ::env(GXTXT_PLOT_PREVIEW_METADATA_ONLY)] && $::env(GXTXT_PLOT_PREVIEW_METADATA_ONLY) eq {1}} {
        set metadata [file join $output plot presentation.json]
        if {![file isfile $metadata] || [file size $metadata]<1 || [file size $metadata]>8388608} {error {Original Source legend metadata is missing or exceeds its intake budget}}
        puts NATIVE3D_METADATA_PREPARED
    } else {puts [exec -- $python -B $converter $output 2>@1]}
} message]} {puts stderr $message;exit 1}
