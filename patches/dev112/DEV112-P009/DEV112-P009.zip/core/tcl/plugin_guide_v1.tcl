# SPDX-License-Identifier: GPL-3.0-or-later
# Data-only admission and projections of the existing Plugin Install registry.
proc ::GX::pluginGuideValidate {kind path} {
    set python [runtimeToolRequired python]
    exec $python -I -B [file join $::GX::scriptDir core python gxtxt_guide_validate_v1.py] $kind $path
}
proc ::GX::pluginGuideRead {root {verify 1}} {
    if {$verify} {pluginGuideValidate tree $root}
    set manifest [file join $root documentation-package.ini]
    set d [parseIni $manifest]
    set required {api_version id guide_id guide_title edition title part_id part_order framework_version framework_patch entrypoint entry_sha256 license origin}
    set optional {component_id component_version language source_url}
    set values {}
    foreach key [dict keys $d] {
        if {![string match documentation_package.* $key] || [string range $key 22 end] ni [concat $required $optional]} {error {Unknown guide manifest field}}
    }
    foreach key [concat $required $optional] {
        set value [descriptorValue $d documentation_package $key {}]
        if {$key in $required && $value eq {}} {error "Guide manifest requires $key"}
        if {[string bytelength $value]>1024 || [regexp {[\x00\r\n]} $value]} {error {Invalid guide manifest text}}
        dict set values $key $value
    }
    if {[dict get $values api_version] ne {2}} {error {Guide packages require documentation manifest version 2}}
    foreach key {id guide_id part_id} {pluginSafeId [dict get $values $key]}
    if {![string is integer -strict [dict get $values part_order]] || [dict get $values part_order]<0 || [dict get $values part_order]>1000000} {error {Guide part_order must be an integer from 0 to 1000000}}
    if {([dict get $values component_id] eq {}) != ([dict get $values component_version] eq {})} {error {Guide component ID and exact version must be declared together}}
    if {[dict get $values component_id] ne {}} {pluginSafeId [dict get $values component_id]}
    if {[dict get $values source_url] ne {} && ![regexp {^https://[^\s]+$} [dict get $values source_url]]} {error {Guide source_url must be HTTPS}}
    set entry [documentationBrowserContainedFile $root [dict get $values entrypoint]]
    if {[string tolower [file extension $entry]] ni {.html .htm}} {error {Guide entrypoint must be HTML}}
    if {![regexp {^[0-9a-f]{64}$} [dict get $values entry_sha256]] || [sha256File $entry] ne [dict get $values entry_sha256]} {error {Guide entrypoint SHA-256 mismatch}}
    return [dict merge $values [dict create path $entry asset_root [file normalize $root] manifest_path $manifest manifest_sha256 [sha256File $manifest]]]
}
proc ::GX::pluginGuideConflicts {package} {
    set id [dict get $package id]
    foreach type {module model instrument analysis_definition} {
        if {[file exists [pluginTargetPath $type $id]]} {error {Guide package ID conflicts with an installed executable component}}
    }
    if {[dict exists $::GX::documentationBrowserEntries content:$id] && ![dict exists $::GX::documentationBrowserEntries content:$id guide_package]} {error {Guide package ID conflicts with existing documentation content}}
    set base [file dirname [pluginTargetPath guide $id]]
    foreach manifest [glob -nocomplain [file join $base * documentation-package.ini]] {
        set root [file dirname $manifest]
        if {[file tail $root] eq [dict get $package id]} continue
        # A damaged installed manifest cannot silently lend its identity to a new package.
        set other [pluginGuideRead $root 0]
        if {[dict get $other id] eq [dict get $package id]} {error {Guide package identity collision}}
        if {[dict get $other guide_id] ne [dict get $package guide_id]} continue
        foreach field {guide_title component_id} {
            if {[dict get $other $field] ne [dict get $package $field]} {error "Logical guide $field conflicts with installed parts"}
        }
        if {[dict get $other part_id] eq [dict get $package part_id] || [dict get $other part_order]==[dict get $package part_order]} {error {Logical guide part identity/order conflicts with an installed package}}
    }
}
proc ::GX::pluginGuideNotices {guide} {
    set notices {}
    set identity [frameworkInstalledIdentity]
    set installedPatch [dict get $identity patch]
    set installedVersion [dict get $identity version]
    foreach {field installed label} [list framework_version $installedVersion Framework framework_patch $installedPatch Patch] {
        if {[dict get $guide $field] ne $installed} {lappend notices "$label reference [dict get $guide $field]; installed $installed"}
    }
    set component [dict get $guide component_id]
    set installedComponent {}
    if {$component ne {}} {
        set installedComponent [moduleField $component version {}]
        if {$installedComponent eq {}} {lappend notices "Referenced component missing: $component"
        } elseif {$installedComponent ne [dict get $guide component_version]} {lappend notices "Component $component reference [dict get $guide component_version]; installed $installedComponent"}
    }
    return [dict create notices $notices installed_framework $installedVersion installed_patch $installedPatch installed_component $installedComponent]
}
proc ::GX::pluginGuideList {{query {}}} {
    pluginRegistryLoad
    set rows {}
    foreach id $::GX::pluginRegistryOrder {
        if {[pluginInstalledField $id type] ne {guide}} continue
        set root [pluginTargetPath guide $id]
        set row [dict create id $id title [pluginInstalledField $id name] version [pluginInstalledField $id version] integrity failed status {Integrity error} reason {}]
        if {[catch {set guide [pluginGuideRead $root]} reason]} {
            dict set row reason $reason
        } else {
            set row [dict merge $row $guide [pluginGuideNotices $guide]]
            dict set row integrity verified
            dict set row status [expr {[llength [dict get $row notices]] ? {⚠ Advisory} : {Installed}}]
        }
        if {$query ne {} && [string first [string tolower [string trim $query]] [string tolower $row]]<0} continue
        lappend rows $row
    }
    return $rows
}
