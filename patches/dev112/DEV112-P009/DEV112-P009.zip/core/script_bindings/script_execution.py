"""Original Registry/Project management, supervised identity and Job admission."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

_ARGS = {'callable_list': [], 'callable_describe': ['reference', 'callable_id'], 'current_callable': [], 'job_wait': ['job_id', 'timeout_seconds'], 'job_submit': ['reference', 'parameters'], 'provided_api_inventory': []}
REGISTRATION = {
    'api_id': 'SCRIPT_EXECUTION_API_v1', 'api_version': 1,
    'provider_kind': 'core', 'provider_id': 'script_execution',
    'documentation_ref': 'docs/api/SCRIPT_EXECUTION_API_v1.md',
    'capabilities': ['registered_callable_declarations', 'supervised_callable_identity', 'owned_job_dependency_wait', 'supervised_job_submission', 'provided_function_jobs_v1', 'provided_bridge_control_arrays_v1'],
    'operations': {name: {'name': name, 'summary': 'Registered Script ' + name,
        'arguments': [{'name': arg, 'kind': {'parameters': 'dictionary', 'timeout_seconds': 'integer'}.get(arg, 'string'), 'required': True} for arg in args],
        'argument_convention': ', '.join(args),
        'result_contract': 'Verified declaration/identity or bounded supervised Job receipt; no arbitrary source paths'}
        for name, args in _ARGS.items()},
}
REGISTRATION['operations']['provided_api_inventory'].update(
    summary='Inspect static PROVIDED declarations of this exact registered runtime snapshot',
    argument_convention='No arguments; current Session, runtime module and registered source identity only',
    result_contract='Typed static inventory, declared counts and path-free Registry stamp; execution_authority none. No caller Session/draft/path/owner context or public API registration.')


def _descriptor(host, raw):
    result = host.as_dict(raw)
    for key, value in result.items():
        result[key] = value.decode('ascii') if isinstance(value, bytes) else str(value)
    result['revision'] = int(result['revision'])
    return result


def invoke(host, operation, args):
    if operation in _WORKSPACE_ARGS:
        return _workspace_invoke(host, operation, args)
    if operation not in _ARGS or len(args) != len(_ARGS[operation]):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid Script Execution operation arguments')
    if operation == 'provided_api_inventory':
        return _provided_api_inventory(host)
    if operation == 'job_submit':
        if not isinstance(args[0], str) or not isinstance(args[1], dict):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Job submission requires a registered reference and parameter dictionary')
        if host.config.has_section('direct_invocation'):
            metadata = host.as_dict(host.call('::GX::scriptRegistryDescribe', args[0], host.session))
            expected = {'expected_' + key: metadata[key] for key in ('sha256', 'revision', 'record_sha256', 'owner_context')}
            _language(host, str(metadata['language']))
            _direct_grant(host, 'run', args[0], expected)
            raw = host.as_dict(host.call('::GX::scriptJobSubmit', *args, {'session': host.session, 'expected_script': expected}))
        else:
            raw = host.as_dict(host.call('::GX::scriptJobSubmit', *args))
        _direct_job_owner(host, str(raw['id']), submitted=True, deduplicated=bool(host.tcl.getboolean(raw.get('deduplicated', 0))))
        return {'job_id': str(raw['id']), 'state': str(raw['state'])}
    if operation == 'job_wait':
        if host.config.has_section('direct_invocation'):
            from pathlib import Path
            _direct_job_owner(host, args[0])
            record = host.as_dict(host.call('::GX::scriptJobDescribe', args[0]))
            if Path(str(record['session'])).resolve() != Path(host.session).resolve():
                raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Job belongs to another Session')
            _direct_grant(host, 'run', str(record['reference']), {
                'expected_sha256': record['source_sha256'], 'expected_revision': record['script_revision'],
                'expected_record_sha256': record.get('source_record_sha256', ''),
                'expected_owner_context': record.get('source_owner_context', '')})
        if host.tcl.getboolean(host.call('::GX::scientificExecutionRemoteId', args[0])):
            # This API waits for a supervised same-Session Script child.
            # Raw host remote references must pass that same owner admission
            # before they can reach any configured remote transport.
            host.call('::GX::scriptJobCall', 'wait_begin', args[0])
        raw = host.as_dict(host.call('::GX::scriptJobWait', *args))
        return {'job_id': str(raw['id']), 'state': str(raw['state']),
                'wait_cancel_requested': bool(int(raw['wait_cancel_requested']))}
    if operation == 'callable_list':
        return [_descriptor(host, value) for value in host.as_list(host.call('::GX::scriptRegistryCallableList', host.session))]
    if operation == 'callable_describe':
        return _descriptor(host, host.call('::GX::scriptRegistryCallableDescribe', *args, host.session))
    if not host.config.has_section('registered_callable'):
        raise BridgeError('GXTXT:ScriptCallback:NoInvocation', 'This Job has no registered callable invocation')
    invocation = dict(host.config.items('registered_callable'))
    reference = host.config.get('config', 'registered_script')
    if invocation['source_sha256'] != host.config.get('config', 'script_sha256'):
        raise BridgeError('GXTXT:ScriptCallback:IdentityMismatch', 'Callable source differs from its Job snapshot')
    request = {key: invocation[key] for key in ('callable_id','source_sha256','revision','declaration_sha256','consumer_api','consumer_operation','payload_json')}
    host.call('::GX::scriptCallableInvocationValidate', reference, request, host.session)
    result = _descriptor(host, host.call('::GX::scriptRegistryCallableDescribe', reference, invocation['callable_id'], host.session))
    for key in ('source_sha256', 'revision', 'declaration_sha256'):
        if str(result[key]) != invocation[key]:
            raise BridgeError('GXTXT:ScriptCallback:IdentityMismatch', 'Registered callable changed during identity resolution')
    result.update({key: invocation[key] for key in ('consumer_api', 'consumer_operation')})
    result['run_id'] = host.run_id
    return result


def _provided_api_inventory(host):
    """Same Registry/Project owner and parser; explicit metadata kinds only."""
    import re

    def mismatch():
        raise BridgeError('GXTXT:ScriptCallback:IdentityMismatch',
                          'Registered inventory snapshot is unavailable or changed')

    config=host.config
    reference=config.get('config','registered_script',fallback='')
    language=config.get('config','script_language',fallback='')
    source_sha=config.get('config','script_sha256',fallback='')
    revision=config.get('config','script_revision',fallback='')
    if (config.get('config','source_mode',fallback='')!='registered_script' or
        not re.fullmatch(r'(user|session):[A-Za-z][A-Za-z0-9_.-]*',reference) or
        language not in {'Python','Octave'} or not re.fullmatch(r'[a-f0-9]{64}',source_sha) or
        not re.fullmatch(r'[1-9][0-9]*',revision) or not host.session):
        raise BridgeError('GXTXT:ScriptCallback:NoRegisteredSnapshot',
                          'Inventory requires this execution registered Script snapshot')
    if host.module_id!=str(host.call('::GX::scriptAnalysisModule',language)):
        mismatch()
    try:
        metadata=host.as_dict(host.call('::GX::scriptRegistryDescribe',reference,host.session))
        if (str(metadata['language'])!=language or str(metadata['sha256'])!=source_sha or
            int(metadata['revision'])!=int(revision)):
            mismatch()
        expected={'expected_sha256':source_sha,'expected_revision':revision,
                  'expected_record_sha256':metadata['record_sha256'],
                  'expected_owner_context':metadata['owner_context']}
        # The unchanged owner checks the full expected source/record/root
        # identity before AND after its fixed static parser. No caller options.
        result=host.as_dict(host.call('::GX::scriptRegistryProvidedApiInventory',reference,expected,host.session))
    except Exception:
        mismatch()
    if (str(result['schema'])!='gxtxt.script_provided_api_inventory.v1' or
        str(result['source_scope'])!='registered_snapshot' or
        str(result['execution_authority'])!='none' or str(result['language'])!=language):
        mismatch()

    def text(raw):return str(host.tcl.call('format','%s',raw))
    def strings(raw):return [text(value) for value in host.as_list(raw)]

    def default(raw,spec):
        # Transport conversion follows the original owner-declared kind, never
        # Tcl cache representation or dict/list/string parseability. No source
        # parser, default validator or scientific logic is duplicated here.
        kind=spec['kind']
        if kind=='null':return None
        if kind=='string':return text(raw)
        if kind=='boolean':return bool(host.tcl.getboolean(raw))
        if kind=='integer':return int(raw)
        if kind in {'number','double'}:
            value=text(raw)
            return int(value) if re.fullmatch(r'[+-]?[0-9]+',value) else float(value)
        if kind=='array':return [default(value,spec['items']) for value in host.as_list(raw)]
        fields={field['name']:field for field in spec['fields']}
        return {name:default(value,fields[name]) for name,value in host.as_dict(raw).items()}

    def schema(raw):
        fields=host.as_dict(raw)
        out={key:text(fields[key]) for key in ('kind','name','units','description') if key in fields}
        for key in ('max_length','max_items'):
            if key in fields:out[key]=int(fields[key])
        if 'required' in fields:out['required']=bool(host.tcl.getboolean(fields['required']))
        if 'items' in fields:out['items']=schema(fields['items'])
        if 'fields' in fields:out['fields']=[schema(value) for value in host.as_list(fields['fields'])]
        if 'default' in fields:out['default']=default(fields['default'],out)
        return out

    provided=[]
    for raw in host.as_list(result['provided']):
        fields=host.as_dict(raw)
        provided.append({'id':text(fields['id']),'version':int(fields['version']),
                         'name':text(fields['name']),'operations':strings(fields['operations'])})
    operations=[]
    for raw in host.as_list(result['operations']):
        fields=host.as_dict(raw)
        out={key:text(fields[key]) for key in ('id','summary','result_contract','unit_behavior','api_id','declaration_file','declaration_file_sha256')}
        for key in ('api_version','declaration_line'):out[key]=int(fields[key])
        out['read_only']=bool(host.tcl.getboolean(fields['read_only']))
        for key in ('effects','capabilities','required_apis'):out[key]=strings(fields[key])
        out['arguments']=[schema(value) for value in host.as_list(fields['arguments'])]
        out['result']=schema(fields['result'])
        out['implementation']={key:(int(value) if key=='line' else text(value))
                               for key,value in host.as_dict(fields['implementation']).items()
                               if key in {'file','function','module','line','sha256','signature'}}
        operations.append(out)
    files=[]
    for raw in host.as_list(result['files']):
        fields=host.as_dict(raw)
        hazards=[]
        for value in host.as_list(fields['load_hazards']):
            item=host.as_dict(value);hazards.append({'line':int(item['line']),'reason':text(item['reason'])})
        files.append({'path':text(fields['path']),'sha256':text(fields['sha256']),
                      'size':int(fields['size']),'load_hazards':hazards})
    diagnostics=[]
    for raw in host.as_list(result['diagnostics']):
        fields=host.as_dict(raw)
        diagnostics.append({key:(int(value) if key=='line' else text(value))
                            for key,value in fields.items() if key in {'code','message','file','line','severity'}})
    consumed=strings(result['consumed']);baseline=host.as_dict(result['registry_baseline'])
    return {'schema':text(result['schema']),'language':language,'entrypoint':text(result['entrypoint']),
            'provided':provided,'operations':operations,'consumed':consumed,'files':files,'diagnostics':diagnostics,
            'valid':bool(host.tcl.getboolean(result['valid'])),'declaration_sha256':text(result['declaration_sha256']),
            'discovery_scope':text(result['discovery_scope']),'reference':reference,'runtime_module':host.module_id,
            'source_scope':text(result['source_scope']),'execution_authority':text(result['execution_authority']),
            'registry_stamp':{'source_sha256':text(baseline['expected_sha256']),
                              'revision':int(baseline['expected_revision']),
                              'record_sha256':text(baseline['expected_record_sha256'])},
            'counts':{'provided_apis':len(provided),'operations':len(operations),'consumed_apis':len(consumed),
                      'files':len(files),'diagnostics':len(diagnostics)}}

# These are missing bindings to the original owners, not a second Registry.
_WORKSPACE_ARGS = {
    'language_support': ['language'],
    'registry_list': ['language', 'scope'],
    'registry_read': ['language', 'reference'],
    'registry_save': ['language', 'scope', 'id', 'name', 'code', 'metadata'],
    'registry_update': ['language', 'reference', 'expected', 'metadata', 'code'],
    'registry_remove': ['language', 'reference', 'expected'],
    'registry_copy_snapshot': ['language', 'reference', 'expected', 'target_id'],
    'registry_assign_to_session': ['language', 'reference', 'expected'],
    'registry_export': ['language', 'reference', 'expected'],
    'registry_import': ['language', 'scope', 'id', 'name', 'package'],
    'project_save': ['language', 'scope', 'id', 'name', 'entrypoint', 'files', 'metadata'],
    'project_update': ['language', 'reference', 'expected', 'metadata', 'entrypoint', 'files'],
    'project_files': ['language', 'reference', 'expected'],
    'registered_submit': ['language', 'reference', 'expected', 'parameters', 'inputs'],
}
_DICTIONARIES = {'expected', 'metadata', 'package', 'files', 'parameters', 'inputs'}
_EXPECTED = {'expected_sha256', 'expected_revision', 'expected_record_sha256', 'expected_owner_context'}
_METADATA = {'version', 'description', 'required_apis', 'explicit_apis', 'parameters', 'default_arguments'}
for _name, _args in _WORKSPACE_ARGS.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Original language-selected Script Registry owner: ' + _name,
        'arguments': [{'name': arg, 'kind': 'dictionary' if arg in _DICTIONARIES else 'string', 'required': True} for arg in _args],
        'argument_convention': ', '.join(_args),
        'result_contract': 'Same admitted Session; Python or Octave; verified Registry reference/revision/SHA/record/owner. Complete expected identity on existing sources; no executable paths. Original errors and provider admission apply.',
    }
REGISTRATION['capabilities'] += ['common_python_octave_registry_v1', 'whole_project_sources_v1', 'full_source_record_owner_cas_v1']


def _language(host, language):
    if language not in ('Python', 'Octave'):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'language must be Python or Octave')
    # Reading the real component authority neither enables nor installs it.
    module = str(host.call('::GX::scriptAnalysisModule', language))
    if not str(host.call('::GX::moduleField', module, 'kind', '')):
        raise BridgeError('GXTXT:ScriptBridge:MissingProvider', 'Script component is not installed')
    if not host.tcl.getboolean(host.call('::GX::moduleIsEnabled', module)):
        raise BridgeError('GXTXT:ScriptBridge:ProviderUnavailable', 'Script component is disabled')
    return module


def _identity(host, language, reference, expected=None):
    raw = host.call('::GX::scriptRegistryDescribe', reference, host.session)
    m = host.as_dict(raw)
    if str(m['language']) != language:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Registered source belongs to another language')
    if expected is not None:
        if not isinstance(expected, dict) or set(expected) != _EXPECTED:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Complete expected source, revision, record and owner identity is required')
        host.call('::GX::_scriptRegistryExpectedCheck', raw, expected)
    return m


def _record(host, raw):
    m = raw if isinstance(raw, dict) else host.as_dict(raw)
    text_fields = ('id', 'name', 'scope', 'language', 'kind', 'version', 'description', 'sha256', 'record_sha256', 'owner_context', 'entrypoint', 'entrypoint_sha256', 'project_sha256', 'project_revision', 'created_at', 'updated_at', 'default_arguments', 'required_apis', 'explicit_apis')
    out = {key: str(m[key]) for key in text_fields if key in m}
    out['reference'] = str(m['scope']) + ':' + str(m['id'])
    out['revision'] = int(m['revision'])
    out['parameters'] = {str(k): {str(a): str(b) for a, b in host.as_dict(v).items()} for k, v in host.as_dict(m.get('parameters', '')).items()}
    return out


def _metadata(value):
    if not isinstance(value, dict) or set(value) - _METADATA:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Only editable Registry metadata fields are accepted')
    return value


def _source(host, m):
    # This path is a verified original owner result, never a caller path.
    return str(host.as_dict(host.call('::GX::scriptRegistryReadChosenSource', str(m['source_path'])))['source'])


def _workspace_invoke(host, operation, args):
    names = _WORKSPACE_ARGS[operation]
    if len(args) != len(names):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid common Script operation arguments')
    a = dict(zip(names, args))
    for key, value in a.items():
        if not isinstance(value, dict if key in _DICTIONARIES else str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid type for ' + key)
    language = a['language']; module = _language(host, language)
    if operation in {'registry_save', 'registry_update', 'registry_remove', 'registry_copy_snapshot', 'registry_assign_to_session', 'registry_import', 'project_save', 'project_update'}:
        _direct_grant(host, 'author')
    if operation == 'registered_submit':
        _direct_grant(host, 'run', a['reference'], a['expected'])
    if operation == 'language_support':
        return {'language': language, 'module_id': module, 'available': True,
                'contract': 'gxtxt.common_script_management.v1',
                'debugger': _debug_capabilities(host, language)}
    if 'scope' in a and a['scope'] not in ('user', 'session', 'all'):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'scope must be user or session (all for list)')
    if a.get('scope') == 'all' and operation != 'registry_list':
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Creation scope must be user or session')
    if operation == 'registry_list':
        records = host.as_list(host.call('::GX::scriptRegistryList', a['scope'], host.session))
        return [_record(host, m) for m in records if str(host.as_dict(m)['language']) == language]
    if 'metadata' in a:
        _metadata(a['metadata'])
    if operation in ('registry_save', 'project_save'):
        options = dict(a['metadata'], language=language)
        if operation == 'registry_save':
            raw = host.call('::GX::scriptRegistrySave', a['scope'], a['id'], a['name'], a['code'], options, host.session)
        else:
            raw = host.call('::GX::scriptRegistryProjectSave', a['scope'], a['id'], a['name'], language, a['entrypoint'], a['files'], options, host.session)
        return _record(host, raw)
    if operation == 'registry_import':
        package = a['package']
        if set(package) != {'schema', 'language', 'kind', 'metadata', 'entrypoint', 'files'} or package['schema'] != 'gxtxt.script_sources.v1' or package['language'] != language:
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid portable Script source package')
        metadata = _metadata(package['metadata'])
        files = package['files']; entrypoint = package['entrypoint']
        if not isinstance(files, dict) or not isinstance(entrypoint, str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid portable source tree')
        if package['kind'] == 'project':
            return _workspace_invoke(host, 'project_save', [language, a['scope'], a['id'], a['name'], entrypoint, files, metadata])
        if package['kind'] != 'script' or set(files) != {entrypoint} or entrypoint != str(host.call('::GX::scriptRegistrySourceName', language)):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid single Script source package')
        return _workspace_invoke(host, 'registry_save', [language, a['scope'], a['id'], a['name'], files[entrypoint], metadata])
    m = _identity(host, language, a['reference'], a.get('expected'))
    if operation == 'registry_read':
        out = _record(host, m)
        out['code'] = _source(host, m)
        pinned = {'expected_' + key: m[key] for key in ('sha256', 'revision', 'record_sha256', 'owner_context')}
        _identity(host, language, a['reference'], pinned)
        return out
    if operation in ('project_files', 'registry_export'):
        files = {str(k): str(v) for k, v in host.as_dict(host.call('::GX::scriptRegistryProjectFiles', m)).items()} if str(m['kind']) == 'project' else {str(host.call('::GX::scriptRegistrySourceName', language)): _source(host, m)}
        if operation == 'project_files':
            if str(m['kind']) != 'project':
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Select a Script Project')
            _identity(host, language, a['reference'], a['expected'])
            return files
        record = _record(host, host.call('::GX::scriptRegistryDescribe', a['reference'], host.session))
        _identity(host, language, a['reference'], a['expected'])
        return {'schema': 'gxtxt.script_sources.v1', 'language': language, 'kind': str(m['kind']),
                'metadata': {key: record[key] for key in _METADATA if key in record},
                'entrypoint': str(m.get('entrypoint') or host.call('::GX::scriptRegistrySourceName', language)), 'files': files}
    if operation in ('registry_update', 'project_update'):
        metadata = dict(a['metadata'], **a['expected'])
        if operation == 'registry_update':
            raw = host.call('::GX::scriptRegistryUpdate', m['scope'], m['id'], a['expected']['expected_sha256'], metadata, a['code'], host.session)
        else:
            raw = host.call('::GX::scriptRegistryProjectUpdate', m['scope'], m['id'], a['expected']['expected_sha256'], metadata, a['entrypoint'], a['files'], host.session)
        return _record(host, raw)
    if operation == 'registry_remove':
        return str(host.call('::GX::resourceLifecycleDeleteScript', a['reference'], a['expected']))
    if operation == 'registry_copy_snapshot':
        return _record(host, host.call('::GX::scriptRegistryCopySnapshot', a['reference'], a['target_id'], a['expected'], host.session))
    if operation == 'registry_assign_to_session':
        if str(m['scope']) != 'user':
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Assign requires a User Script')
        return _record(host, host.call('::GX::scriptRegistryAssignToSession', m['id'], host.session, a['expected']))
    if operation == 'registered_submit':
        raw = host.call('::GX::scriptJobSubmit', a['reference'], a['parameters'],
                        {'session': host.session, 'inputs': a['inputs'], 'expected_script': a['expected']})
        receipt = host.as_dict(raw)
        _direct_job_owner(host, str(receipt['id']), submitted=True, deduplicated=bool(host.tcl.getboolean(receipt.get('deduplicated', 0))))
        return {'job_id': str(receipt['id']), 'state': str(receipt['state']),
                'reference': a['reference'], 'language': language, 'source_sha256': str(m['sha256']), 'revision': int(m['revision'])}
    raise BridgeError('GXTXT:ScriptBridge:UnknownOperation', 'Unknown common Script operation')


def _direct_grant(host, grant, reference=None, expected=None):
    """Optional authenticated direct-host context; ordinary Jobs keep admission."""
    config = host.config
    if not config.has_section('direct_invocation'):
        return
    if (config.get('direct_invocation', 'schema', fallback='') != 'gxtxt.direct_bridge_context.v1' or
            not config.getboolean('direct_invocation', grant, fallback=False)):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Direct invocation requires the explicit ' + grant + ' grant')
    if grant == 'author':
        actual = getattr(host, 'direct_request_sha256', '')
        if not actual or config.get('direct_invocation', 'approved_request_sha256', fallback='') != actual:
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Author approval does not match this exact request')
    if grant == 'run':
        if not isinstance(expected, dict):
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Run requires exact reviewed source approval')
        approved = {'approved_reference': reference, **{'approved_' + key.removeprefix('expected_'): value for key, value in expected.items()}}
        if any(config.get('direct_invocation', key, fallback='') != str(value) for key, value in approved.items()):
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Run approval does not match the exact reviewed source identity')


def _debug_capabilities(host, language):
    result = host.as_dict(host.call('::GX::scriptJobDebugCapabilities', language))
    return {'language': str(result['language']), 'backend': str(result['backend']),
            'controls': [str(v) for v in host.as_list(result['controls'])],
            'pause_supported': bool(host.tcl.getboolean(result['pause_supported'])),
            'pause_reason': str(result['pause_reason'])}


def _direct_job_owner(host, job_id, submitted=False, deduplicated=False):
    """Reuse the original Supervisor's finite client owner CAS and process check."""
    if not host.config.has_section('direct_invocation'):
        return
    import json
    import os
    client = host.config.get('direct_invocation', 'client_id', fallback='')
    if not client:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Authenticated direct client identity is required')
    instance = 'mcp:' + client
    row = json.loads(str(host.call('::GX::_scriptJobReadJson', 'describe', job_id)))
    owner = row.get('client_owner')
    if owner is None:
        if not submitted or deduplicated:
            raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Job has no matching direct client owner')
    elif owner.get('instance') != instance:
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Job belongs to another client principal')
    reattach = owner is not None and str(host.call('::GX::scriptJobCall', 'process_identity', owner['pid'])) != owner['process']
    if submitted or reattach:
        process = str(host.call('::GX::scriptJobCall', 'process_identity', os.getpid()))
        proposed = {'pid': os.getpid(), 'process': process, 'instance': instance}
        host.call('::GX::scriptJobCall', 'client_owner_claim', job_id, json.dumps(owner, separators=(',', ':')), json.dumps(proposed, separators=(',', ':')))

# Runtime discovery and the shared manifest describe the same exact binding.
_WORKSPACE_RETURNS = {
    'language_support': 'language_support', 'registry_list': 'registry_record[]',
    'registry_read': 'registry_record_with_code', 'registry_save': 'registry_record',
    'registry_update': 'registry_record', 'registry_remove': 'qualified_reference',
    'registry_copy_snapshot': 'registry_record', 'registry_assign_to_session': 'registry_record',
    'registry_export': 'portable_source_package', 'registry_import': 'registry_record',
    'project_save': 'registry_record', 'project_update': 'registry_record',
    'project_files': 'relative_path_to_utf8_source', 'registered_submit': 'supervised_job_receipt',
}
_WORKSPACE_OWNERS = {
    'language_support': 'moduleField/moduleIsEnabled/scriptJobDebugCapabilities',
    'registry_list': 'scriptRegistryList', 'registry_read': 'scriptRegistryDescribe/scriptRegistryReadChosenSource',
    'registry_save': 'scriptRegistrySave', 'registry_update': 'scriptRegistryUpdate',
    'registry_remove': 'resourceLifecycleDeleteScript', 'registry_copy_snapshot': 'scriptRegistryCopySnapshot',
    'registry_assign_to_session': 'scriptRegistryAssignToSession',
    'registry_export': 'scriptRegistryDescribe/scriptRegistryProjectFiles/scriptRegistryReadChosenSource',
    'registry_import': 'scriptRegistrySave/scriptRegistryProjectSave', 'project_save': 'scriptRegistryProjectSave',
    'project_update': 'scriptRegistryProjectUpdate', 'project_files': 'scriptRegistryProjectFiles',
    'registered_submit': 'scriptJobSubmit',
}
for _name in _WORKSPACE_ARGS:
    _operation = REGISTRATION['operations'][_name]
    _operation.update(result_schema=_WORKSPACE_RETURNS[_name], host_owner=_WORKSPACE_OWNERS[_name],
                      lifetime='Current admitted Session and original enabled module; Registry owner identity pinned on existing-source mutations',
                      concurrency='Original Registry locks and complete four-field compare-and-swap; no implicit overwrite',
                      error_ids=['GXTXT:ScriptBridge:InvalidArguments', 'GXTXT:ScriptBridge:Ownership',
                                 'GXTXT:ScriptBridge:MissingProvider', 'GXTXT:ScriptBridge:ProviderUnavailable',
                                 'GXTXT:ScriptBridge:RemoteError'])
    for _argument in _operation['arguments']:
        if _argument['name'] == 'language': _argument['values'] = ['Python', 'Octave']
        if _argument['name'] == 'expected':
            _argument['schema'] = {'expected_sha256': 'sha256', 'expected_revision': 'positive integer',
                                   'expected_record_sha256': 'sha256', 'expected_owner_context': 'sha256'}
        if _argument['name'] == 'scope':
            _argument['values'] = ['user', 'session', 'all'] if _name == 'registry_list' else ['user', 'session']
