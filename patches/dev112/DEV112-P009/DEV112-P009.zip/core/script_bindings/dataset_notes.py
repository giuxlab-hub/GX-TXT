"""Python/Octave binding for the existing CORE Dataset Notes API."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError

REGISTRATION = {
    "api_id": "DATASET_NOTES_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "dataset_notes",
    "documentation_ref": "docs/api/DATASET_NOTES_API_v1.md",
    "operations": {
        "read": {
            "name": "read", "summary": "Read the Dataset's existing UTF-8 Markdown notes",
            "arguments": [{"name": "dataset_id", "kind": "Dataset ID", "required": True}],
            "argument_convention": "dataset_id",
            "result_convention": "UTF-8 Markdown text", "result_contract": "UTF-8 Markdown text",
        },
        "write": {
            "name": "write", "summary": "Save Dataset Markdown through the existing CORE owner",
            "arguments": [{"name": "dataset_id", "kind": "Dataset ID", "required": True},
                          {"name": "markdown", "kind": "UTF-8 string", "required": True}],
            "argument_convention": "dataset_id, markdown",
            "result_convention": "CORE save result", "result_contract": "Existing note file path",
        },
    },
}


def invoke(host, operation, args):
    if operation == "read" and len(args) == 1 and isinstance(args[0], str):
        return str(host.call("::GX::datasetUserNotes", args[0]))
    if operation == "write" and len(args) == 2 and all(isinstance(value, str) for value in args):
        if hasattr(host, "direct_invocation"):
            return str(host.call("::GX::datasetUserNotesSave", *args))
        return str(host.call("::GX::_datasetPrivateWithModule", host.module_id,
                             "::GX::datasetUserNotesSave", *args))
    raise BridgeError("GXTXT:ScriptBridge:InvalidArguments",
                      "Dataset Notes expects read(dataset_id) or write(dataset_id, markdown)")
