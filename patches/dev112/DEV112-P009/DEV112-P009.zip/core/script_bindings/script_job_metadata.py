"""Native debugger and managed Job bindings to the original CORE Supervisor."""
# SPDX-License-Identifier: GPL-3.0-or-later
from gxtxt_script_bridge_server import BridgeError, NumericArray, ResourceNumericArray

REGISTRATION = {
    "api_id": "SCRIPT_JOB_API_v1", "api_version": 1,
    "provider_kind": "core", "provider_id": "script_job",
    "documentation_ref": "docs/api/SCRIPT_JOB_API_v1.md",
    "operations": {"debug_capabilities": {
        "name": "debug_capabilities", "summary": "Read inert native debugger protocol capabilities",
        "host_command": "::GX::scriptJobDebugCapabilities",
        "arguments": [{"name": "language", "kind": "Python or Octave", "required": True}],
        "argument_convention": "language", "result_contract": "language/backend, ordered control IDs and explicit pause availability; no Job is started",
    }},
}


REGISTRATION['operations']['policy_read'] = {
    'name': 'policy_read', 'summary': 'Read the original same-admitted LOCAL Job policy snapshot',
    'host_command': '::GX::scriptJobPolicyRead', 'arguments': [],
    'argument_convention': 'no arguments',
    'result_contract': 'Original schema/configured/origin/seven positive integer policy fields/policy_sha256; no caller root, remote budget or admission lease',
}


def _policy_read(host, args):
    if args:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'policy_read takes no arguments')
    result = host.as_dict(host.call('::GX::scriptJobPolicyRead'))
    return {'schema': str(result['schema']),
            'configured': bool(host.tcl.getboolean(result['configured'])),
            'origin': str(result['origin']),
            'policy': {str(key): int(value) for key, value in host.as_dict(result['policy']).items()},
            'policy_sha256': str(result['policy_sha256'])}


def invoke(host, operation, args):
    if operation == 'policy_read': return _policy_read(host, args)
    if operation != "debug_capabilities":
        raise BridgeError("GXTXT:ScriptBridge:UnknownOperation", "No host Job operation is registered by this metadata adapter")
    if len(args) != 1 or not isinstance(args[0], str) or args[0] not in {"Python", "Octave"}:
        raise BridgeError("GXTXT:ScriptBridge:InvalidArguments", "Debugger metadata requires Python or Octave")
    result = host.as_dict(host.call("::GX::scriptJobDebugCapabilities", args[0]))
    result["controls"] = [str(value) for value in host.as_list(result["controls"])]
    result["pause_supported"] = bool(host.tcl.getboolean(result["pause_supported"]))
    return result

# Native controls remain in the existing Supervisor. No GUI state is authority.
_JOB_ARGS = {
    'debug_submit': ['language', 'reference', 'expected', 'parameters', 'inputs', 'breakpoints'],
    'debug_read': ['language', 'job_id', 'source_sha256'],
    'debug_control': ['language', 'job_id', 'source_sha256', 'control', 'frame'],
    'inspect': ['language', 'job_id', 'source_sha256'],
    'stream_read': ['language', 'job_id', 'source_sha256', 'role', 'offset', 'count', 'tail'],
    'cancel': ['language', 'job_id', 'source_sha256'],
}
for _name, _args in _JOB_ARGS.items():
    REGISTRATION['operations'][_name] = {
        'name': _name, 'summary': 'Original supervised native Job owner: ' + _name,
        'arguments': [{'name': arg, 'kind': ('dictionary' if arg in {'expected', 'parameters', 'inputs'} else 'value' if arg == 'breakpoints' else 'integer' if arg in {'frame', 'offset', 'count'} else 'boolean' if arg == 'tail' else 'string'), 'required': True} for arg in _args],
        'argument_convention': ', '.join(_args),
        'result_contract': 'Same admitted Session and exact language/source snapshot; native state/stack/locals or bounded streams. Octave asynchronous Pause is unsupported. No shell, source paths or debugger tokens accepted.',
    }

_legacy_invoke = invoke


def invoke(host, operation, args):
    if operation not in _JOB_ARGS:
        return _legacy_invoke(host, operation, args)
    from pathlib import Path
    import json
    # Import the same existing provider module through its original loader.
    import importlib.util
    spec = importlib.util.spec_from_file_location('_gxtxt_script_execution_contract', Path(__file__).with_name('script_execution.py'))
    registry = importlib.util.module_from_spec(spec); spec.loader.exec_module(registry)
    names = _JOB_ARGS[operation]
    if len(args) != len(names):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid native Job arguments')
    a = dict(zip(names, args)); language = a['language']
    registry._language(host, language)
    if operation == 'debug_submit':
        registry._direct_grant(host, 'run', a['reference'], a['expected'])
        m = registry._identity(host, language, a['reference'], a['expected'])
        if not isinstance(a['parameters'], dict) or not isinstance(a['inputs'], dict):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Parameters and inputs must be dictionaries')
        bp = a['breakpoints']
        if str(m['kind']) == 'project':
            if not isinstance(bp, dict):
                raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Project breakpoints require admitted file-to-lines dictionary')
            bp = {path: _breakpoint_lines(lines) for path, lines in bp.items()}
        else:
            bp = _breakpoint_lines(bp)
        raw = host.as_dict(host.call('::GX::scriptJobDebugSubmit', a['reference'], a['parameters'],
                           {'session': host.session, 'inputs': a['inputs'], 'expected_script': a['expected'], 'debug_breakpoints': bp}))
        registry._direct_job_owner(host, str(raw['id']), submitted=True, deduplicated=bool(host.tcl.getboolean(raw.get('deduplicated', 0))))
        return {'job_id': str(raw['id']), 'state': str(raw['state']), 'reference': a['reference'],
                'source_sha256': str(m['sha256']), 'revision': int(m['revision']), 'language': language}
    registry._direct_job_owner(host, a['job_id'])
    raw = host.call('::GX::scriptJobDescribe', a['job_id']); record = host.as_dict(raw)
    if (Path(str(record['session'])).resolve() != Path(host.session).resolve() or str(record['language']) != language or
            str(record['source_sha256']) != a['source_sha256'] or str(record.get('origin', 'user_script')) == 'core_service'):
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Job Session, language or exact source snapshot does not match')
    if operation in {'debug_read', 'debug_control'} and str(record.get('debug', '0')) != '1':
        raise BridgeError('GXTXT:ScriptBridge:Ownership', 'Job was not admitted in native Debug mode')
    if operation in {'debug_control', 'cancel'}:
        registry._direct_grant(host, 'run', str(record['reference']), {
            'expected_sha256': a['source_sha256'], 'expected_revision': record['script_revision'],
            'expected_record_sha256': record.get('source_record_sha256', ''),
            'expected_owner_context': record.get('source_owner_context', '')})
    if operation == 'debug_read':
        return json.loads(str(host.call('::GX::_scriptJobReadJson', 'debug_read', a['job_id'])))
    if operation == 'debug_control':
        if not isinstance(a['control'], str):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Native control and frame have invalid types')
        a['frame'] = _integer(a['frame'], 0, 31, 'frame')
        if a['control'] == 'pause' and language == 'Octave':
            raise BridgeError('GXTXT:ScriptJob:Unsupported', 'GNU Octave native asynchronous Pause is unsupported')
        # Stop also verifies snapshot ownership before original cancellation.
        raw = host.as_dict(host.call('::GX::scriptJobDebugControl', a['job_id'], a['control'], a['source_sha256'], a['frame']))
        return {key: (bool(host.tcl.getboolean(value)) if key in {'accepted', 'cancel_requested'} else str(value)) for key, value in raw.items()}
    if operation == 'cancel':
        return {'cancel_requested': bool(host.tcl.getboolean(host.as_dict(host.call('::GX::scriptJobCancel', a['job_id']))['cancel_requested']))}
    if operation == 'stream_read':
        if a['role'] not in {'stdout', 'stderr', 'diagnostics'} or not isinstance(a['tail'], bool):
            raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Invalid bounded stream request')
        a['offset'] = _integer(a['offset'], 0, 2**63-1, 'offset')
        a['count'] = _integer(a['count'], 4, 262144, 'count')
        page = json.loads(str(host.call('::GX::_scriptJobReadJson', 'stream_read', a['job_id'], a['role'], a['offset'], a['count'], a['tail'])))
        if isinstance(page, dict):page.pop('path', None)
        return page
    out = json.loads(str(host.call('::GX::_scriptJobReadJson', 'inspect', a['job_id'])))
    fields = ('id', 'state', 'reference', 'language', 'source_sha256', 'script_revision', 'script_name', 'started', 'finished', 'error', 'snapshot_validation', 'origin', 'log_streams', 'parameters', 'inputs', 'diagnostics', 'published_datasets', 'output')
    return {key: out[key] for key in fields if key in out}

for _name in _JOB_ARGS:
    _operation = REGISTRATION['operations'][_name]
    _operation.update(
        host_owner={'debug_submit': 'scriptJobDebugSubmit', 'debug_read': 'scriptJobDebugRead', 'debug_control': 'scriptJobDebugControl', 'inspect': 'scriptJobInspect', 'stream_read': 'scriptJobStreamRead', 'cancel': 'scriptJobCancel'}[_name],
        result_schema={'debug_submit': 'supervised_job_receipt', 'debug_read': 'gxtxt.script_debug.v1',
                       'debug_control': 'native_control_receipt', 'inspect': 'script_job_inspection',
                       'stream_read': 'bounded_stream_page', 'cancel': 'cancel_requested_boolean'}[_name],
        lifetime='Original same-Session Job and immutable exact source snapshot; native paused/running/terminal state remains authoritative',
        concurrency='Debugger native sequence changes must be observed before sending another control; original Supervisor owns cancellation',
        error_ids=['GXTXT:ScriptBridge:InvalidArguments', 'GXTXT:ScriptBridge:Ownership',
                   'GXTXT:ScriptBridge:MissingProvider', 'GXTXT:ScriptBridge:ProviderUnavailable',
                   'GXTXT:ScriptBridge:RemoteError', 'GXTXT:ScriptJob:Unsupported'])
    for _argument in _operation['arguments']:
        if _argument['name'] == 'language': _argument['values'] = ['Python', 'Octave']
        if _argument['name'] == 'control': _argument['values'] = ['continue', 'into', 'over', 'out', 'frame', 'stop', 'pause']
        if _argument['name'] == 'frame': _argument.update(minimum=0, maximum=31)
        if _argument['name'] == 'count': _argument.update(minimum=4, maximum=262144)
        if _argument['name'] == 'offset': _argument.update(minimum=0)
        if _argument['name'] == 'expected':
            _argument['schema'] = {'expected_sha256': 'sha256', 'expected_revision': 'positive integer',
                                   'expected_record_sha256': 'sha256', 'expected_owner_context': 'sha256'}


def _integer(value, minimum, maximum, name):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not minimum <= value <= maximum or int(value) != value:
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', name + ' requires an exact integer in the declared bounds')
    return int(value)


def _breakpoint_lines(value):
    if isinstance(value, (NumericArray, ResourceNumericArray)):
        value = value.values.tolist() if hasattr(value.values, 'tolist') else list(value.values)
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        value = [value]
    if not isinstance(value, list):
        raise BridgeError('GXTXT:ScriptBridge:InvalidArguments', 'Breakpoints require a physical source line list')
    return [_integer(line, 1, 2**31-1, 'breakpoint line') for line in value]
