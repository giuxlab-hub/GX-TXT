# SPDX-License-Identifier: GPL-3.0-or-later
"""Data-only guide admission checks; Plugin Install retains all mutation ownership."""
import configparser
import hashlib
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
import re
import os
import stat
import sys
from urllib.parse import unquote, urlsplit
import zipfile

MAX_FILES = 4096
MAX_BYTES = 64 * 1024 * 1024
MAX_FILE = 8 * 1024 * 1024
ASSETS = {'.html', '.htm', '.css', '.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico',
          '.svg', '.woff', '.woff2', '.ttf', '.otf', '.txt', '.md', '.pdf'}


def read_asset(path, maximum=MAX_FILE):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode) or before.st_size > maximum:
            raise ValueError('Guide asset is not an ordinary bounded file')
        data = bytearray()
        while len(data) <= maximum:
            chunk = os.read(descriptor, min(65536, maximum + 1 - len(data)))
            if not chunk:
                break
            data.extend(chunk)
        after = os.fstat(descriptor)
        current = os.stat(path, follow_symlinks=False)
        if len(data) > maximum or (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns) or (after.st_dev, after.st_ino) != (current.st_dev, current.st_ino):
            raise ValueError('Guide asset changed while verifying')
        return bytes(data)
    finally:
        os.close(descriptor)


def relative(name):
    if not name or '\\' in name or '%' in name or '\x00' in name or ':' in name:
        raise ValueError('Guide paths must be portable relative paths')
    p = PurePosixPath(name)
    if p.is_absolute() or any(x in {'', '.', '..'} for x in name.rstrip('/').split('/')):
        raise ValueError('Unsafe guide path: ' + name)
    return p


def zip_check(path):
    with zipfile.ZipFile(path) as z:
        manifests = [i for i in z.infolist() if PurePosixPath(i.filename).name == 'plugin-package.ini']
        guide = False
        for info in manifests:
            if info.file_size > 16384:
                raise ValueError('Package manifest exceeds 16 KiB')
            c = configparser.ConfigParser(interpolation=None, strict=True)
            c.read_string(z.read(info).decode('utf-8'))
            guide |= c.get('package', 'type', fallback='').strip().lower() == 'guide'
        if not guide:
            return
        if any(PurePosixPath(i.filename).name == 'plugin-bundle.ini' for i in z.infolist()):
            raise ValueError('Guide packages cannot be members of plugin bundles')
        if len(manifests) != 1:
            raise ValueError('A guide ZIP contains exactly one package')
        prefix = PurePosixPath(manifests[0].filename).parent
        names = set()
        total = 0
        if len(z.infolist()) > MAX_FILES:
            raise ValueError('Guide ZIP exceeds 4096 entries')
        for info in z.infolist():
            member = relative(info.filename)
            if prefix != PurePosixPath('.') and member != prefix and prefix not in member.parents:
                raise ValueError('Guide ZIP contains content outside its one package root')
            name = str(member).casefold()
            if name in names:
                raise ValueError('Duplicate or case-conflicting guide ZIP path')
            names.add(name)
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in {0, stat.S_IFREG, stat.S_IFDIR}):
                raise ValueError('Guide ZIP contains a nonordinary entry')
            if info.flag_bits & 1:
                raise ValueError('Encrypted guide ZIPs are unsupported')
            total += info.file_size
            if info.file_size > MAX_FILE or total > MAX_BYTES:
                raise ValueError('Guide ZIP exceeds resource limits')
            if info.file_size > 1024 * 1024 and info.compress_size * 1000 < info.file_size:
                raise ValueError('Guide ZIP compression ratio exceeds limit')


def link_check(root, path, target, resource=False):
    target = target.strip()
    uri = urlsplit(target)
    if uri.scheme or uri.netloc:
        if not resource and uri.scheme in {'https', 'http', 'mailto'}:
            return
        raise ValueError('Executable or remote guide resource is forbidden: ' + target)
    if not uri.path:
        return
    if '\\' in uri.path or '%' in uri.path or uri.path.startswith('/') or '\x00' in uri.path:
        raise ValueError('Unsafe guide link')
    dest = (path.parent / unquote(uri.path)).resolve()
    if not dest.is_relative_to(root) or not dest.is_file():
        raise ValueError('Missing or escaping guide link: ' + target)


class ReaderHTML(HTMLParser):
    def __init__(self, root, path):
        super().__init__(convert_charrefs=True)
        self.root, self.path = root, path

    def handle_starttag(self, tag, attrs):
        if tag.lower() in {'script', 'iframe', 'object', 'embed', 'applet', 'form', 'base'}:
            raise ValueError('Active HTML element is forbidden: ' + tag)
        for key, value in attrs:
            key = key.lower()
            if key.startswith('on') or key in {'srcdoc', 'formaction', 'action', 'srcset', 'http-equiv'}:
                raise ValueError('Active HTML attribute is forbidden: ' + key)
            if value is None:
                continue
            if key in {'src', 'href', 'poster', 'xlink:href'}:
                link_check(self.root, self.path, value, resource=not (tag == 'a' and key == 'href'))
            if key == 'style':
                css_check(self.root, self.path, value)

    handle_startendtag = handle_starttag


def css_check(root, path, text):
    if re.search(r'(?i)(expression\s*\(|javascript:|@import|-moz-binding|behavior\s*:|\\)', text):
        raise ValueError('Active or escaped CSS is forbidden')
    for value in re.findall(r'(?i)url\(\s*[\'"]?([^\)\'\"]+)', text):
        link_check(root, path, value.strip(), resource=True)


def tree_check(path):
    if Path(path).is_symlink() or not Path(path).is_dir():
        raise ValueError('Guide root must be an ordinary directory')
    root = Path(path).resolve()
    files = []
    total = 0
    seen = set()
    for p in root.rglob('*'):
        relative(p.relative_to(root).as_posix())
        if p.is_symlink() or not (p.is_file() or p.is_dir()):
            raise ValueError('Guide payload contains a nonordinary entry')
        name = p.relative_to(root).as_posix()
        if name.casefold() in seen:
            raise ValueError('Case-conflicting guide path')
        seen.add(name.casefold())
        if len(seen) > MAX_FILES:
            raise ValueError('Guide payload exceeds 4096 entries')
        if p.is_dir():
            continue
        files.append(p)
        size = p.stat().st_size
        total += size
        if size > MAX_FILE or total > MAX_BYTES:
            raise ValueError('Guide payload exceeds resource limits')
        if name not in {'plugin-package.ini', 'documentation-package.ini', 'SHA256SUMS.txt'}:
            if p.suffix.lower() not in ASSETS:
                raise ValueError('Executable or unsupported guide asset: ' + name)
        if p.stat().st_mode & 0o111:
            raise ValueError('Guide files must not have executable permissions')
        if p.suffix.lower() in {'.html', '.htm'}:
            ReaderHTML(root, p).feed(read_asset(p).decode('utf-8'))
        elif p.suffix.lower() == '.css':
            css_check(root, p, read_asset(p).decode('utf-8'))
        elif p.suffix.lower() == '.svg':
            text = read_asset(p).decode('utf-8')
            if re.search(r'(?i)(<!DOCTYPE|<!ENTITY|<\s*(?:\w+:)?(?:script|foreignObject)\b)', text):
                raise ValueError('Active SVG is forbidden')
            ReaderHTML(root, p).feed(text)
    inventory = root / 'SHA256SUMS.txt'
    entries = {}
    for line in read_asset(inventory).decode('utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64}) [ *](.+)', line)
        if not match:
            raise ValueError('Malformed guide SHA256SUMS.txt')
        sha, name = match.groups()
        relative(name)
        if name in entries or name == 'SHA256SUMS.txt':
            raise ValueError('Duplicate/self-referential guide checksum')
        entries[name] = sha
    actual = {p.relative_to(root).as_posix(): hashlib.sha256(read_asset(p)).hexdigest()
              for p in files if p != inventory}
    if entries != actual:
        raise ValueError('Guide inventory must match every payload file and SHA-256')


if __name__ == '__main__':
    try:
        {'zip': zip_check, 'tree': tree_check}[sys.argv[1]](sys.argv[2])
    except Exception as exc:
        sys.stderr.write('Guide admission failed: ' + str(exc) + '\n')
        sys.exit(1)
