# Independently installable HTML Guides

P009 extends the existing `PLUGIN_INSTALL_API_v1` package family with `type=guide`.
The original Plugin Manager, transaction staging, registry and documentation index
own these packages. A guide is reading data: it has no `module.ini`, MODULE_API
registration, enabled state, installer hook, scientific capability or activation.
No guides are bundled by this feature, and there is no downloader.

## Package layout

A ZIP contains exactly one package, either at its root or in one enclosing folder:

```text
plugin-package.ini
documentation-package.ini
SHA256SUMS.txt
index.html
sections/...
assets/...
```

`plugin-package.ini` retains Plugin Install manifest version 1:

```ini
[package]
api_version=1
id=publisher.framework-guide.part01
type=guide
version=1.0.0
name=Framework guide, first part
```

The package ID/version identify the independently managed ZIP. Package IDs share
the existing managed-plugin identity namespace. Updates require the same package
ID and a newer package version. Uninstall removes only that package/part.

`documentation-package.ini` uses the additive version 2 reading-data contract:

```ini
[documentation_package]
api_version=2
id=publisher.framework-guide.part01
guide_id=publisher.framework-guide
guide_title=GX-TXT guide
edition=2026.1
title=Getting started
part_id=first
part_order=10
framework_version=0.9.8.10-dev-112
framework_patch=008
entrypoint=index.html
entry_sha256=REPLACE_WITH_64_LOWERCASE_HEX_DIGITS
license=CC-BY-4.0
origin=Publisher name and publication provenance
language=English
source_url=https://giux-lab.it/example-article
component_id=
component_version=
```

Required fields are all fields above except `language`, `source_url`,
`component_id` and `component_version`. The two component fields must both be
present/nonempty or both empty. A general framework guide leaves them empty.
A component/Viewer guide supplies the stable module ID and exact documented
version. Missing components do not prevent installation or reading.

The guide edition is distinct from the package version. All installed parts of
one logical guide share its title and component identity. Editions and exact
component versions are part references and may differ during independent updates. Each
part has a unique stable part ID and a unique integer order from 0 to 1000000.
The documentation index groups parts by `guide_id`, orders them numerically, and
presents the same logical guide regardless of package installation sequence.
HTML remains in separate files. Individual parts may record different exact
framework/patch references. Local links resolve within their own package;
part-to-part navigation uses the indexed section selector and Previous/Next.

`framework_patch` uses the distinct three-digit installed patch identity, such as
`008`, separately from `framework_version`. The recorded references are exact
preparation references. The Guides page compares both with the current installed
identity and compares a component reference with its current installed version.
Differences carry an advisory icon; a missing component has a separate notice.
Neither differences nor absence imply that an updated guide exists. Executable
plugin `framework_min` and `framework_max` checks do not block guide packages.
No Internet lookup or language-dependent admission is performed.

## Integrity and inert content

`SHA256SUMS.txt` contains exactly one lowercase SHA-256 line for every payload
file, including both manifests, excluding the inventory itself:

```text
0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef  index.html
```

This inventory checks consistency and provenance bytes; it is not a publisher
signature or a trust certificate. Installation and each indexed document open
verify the complete inventory and entrypoint hash. Altered/missing resources are
reported as integrity errors. Previously bundled version-1 module manuals and
tutorials keep their original manifest/index semantics.

Paths are portable relative paths without absolute roots, drive prefixes,
backslashes, percent encoding, NUL, symlinks or nonordinary filesystem entries.
ZIP duplicates and case collisions are refused before extraction. Package limits
are 4096 entries, 64 MiB total and 8 MiB per file; HTML entrypoints retain the
Documentation Browser's 2 MiB limit. Extreme compression, encryption and executable
file permissions are rejected. The payload permits HTML, CSS, PNG/JPEG/GIF/WebP,
ICO/SVG, WOFF/WOFF2/TTF/OTF, TXT/Markdown and PDF reading assets only, alongside
the three fixed manifest/inventory filenames. Executable payload extensions,
installer scripts and module descriptors are refused.

Guide HTML forbids scripts, event handlers, forms, embedded frames/objects,
active redirects and executable URLs. CSS expressions/imports/escaped active
constructs and active SVG are refused. HTML resources and CSS URLs must reference
existing local files inside the package. Normal HTTP/HTTPS/mailto anchor links
may be recorded, but no external content is required for offline reading. Use
UTF-8 HTML with local assets. Any language is permitted; optional language text
is descriptive only. There is no language selector or translation.

The existing shared HTML viewer owns rendering, local asset containment and
navigation. Guide data receives no new API/host grants. CORE does not source or
execute anything from the guide package.

## Installation and Help

Configuration → Modules → Guides is the last Modules subtab. Search filters
installed guide/package/part/provenance/reference metadata. The list and details
show managed status, integrity, origin and exact recorded/installed references.
Install/Update/Uninstall call the original Plugin Install transaction. The normal
Plugin Manager inventory also recognizes guide packages. Guides-only actions
refuse other package types in the same transaction admission.

The main Help retains its Markdown/reference content and provides an HTML Guide
tab for installed general guides, grouped sections and ordered part navigation.
Component guides use the existing external component Help window's tutorial/
guide selector, retaining its Manual tab and existing tutorials. A guide with a
missing component can still be opened from Guides in the main shared HTML host.

Default workers and Maximum workers are presented in Runtime → Tools and settings
→ Computation resources. Their original `computation.default_workers` and
`computation.max_workers` keys, defaults, validation, persistence and execution
owners are unchanged. The empty top-level Computation tab is removed.
