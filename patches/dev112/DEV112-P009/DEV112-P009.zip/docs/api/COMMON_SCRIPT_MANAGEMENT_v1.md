# Common Python/Octave scripting management v1

Both existing editors reference `core/contracts/common_script_management_v1.json`.
The contract extends the existing `SCRIPT_EXECUTION_API_v1` and
`SCRIPT_JOB_API_v1` registrations. Their original Registry, Script Projects,
Resource Lifecycle, Runner and native debugger remain the authorities. The
Python and Octave editor-specific public APIs retain their existing contracts.

Every common operation takes `language` exactly `Python` or `Octave`. The
original module must be installed and enabled. Calls neither install nor enable
it. The current admitted Session is implicit; callers cannot supply another
Session, Registry root, Job database, executable path or debugger token.

Use normal `gxtxt_api_describe` and `gxtxt_api_call` in either language. The
shared manifest records exact argument order. Existing callable discovery,
`job_submit`, `job_wait` and provided-API inventory remain compatible.

| SCRIPT_EXECUTION operation | Arguments after language | Result |
| --- | --- | --- |
| language_support | none | Original component and native debugger capabilities |
| registry_list | scope (`user`, `session`, `all`) | Language-filtered verified records |
| registry_read | reference | Verified record and UTF-8 entrypoint code |
| registry_save | scope, id, name, code, metadata | New original Registry record |
| registry_update | reference, expected, metadata, code | Atomic update receipt |
| registry_remove | reference, expected | Deleted reference after dependency refusal |
| registry_copy_snapshot | reference, expected, target_id | New same-scope snapshot |
| registry_assign_to_session | user reference, expected | Original Session snapshot |
| registry_export | reference, expected | Portable UTF-8 source package |
| registry_import | scope, id, name, package | New Script or whole Project |
| project_save | scope, id, name, entrypoint, files, metadata | New original Project record |
| project_update | reference, expected, metadata, entrypoint, files | Atomic whole-tree Save All |
| project_files | reference, expected | Verified relative-path-to-source dictionary |
| registered_submit | reference, expected, parameters, inputs | Original supervised Job receipt |

Creation never overwrites an existing identity. Editable metadata fields are
`version`, `description`, `required_apis`, `explicit_apis`, `parameters` and
`default_arguments`; their original Registry validators apply. `files` maps admitted
relative Project paths to UTF-8 source strings. Original project size, path,
manifest, entrypoint and language checks apply. A source package has exactly
`schema=gxtxt.script_sources.v1`, `language`, `kind`, `metadata`, `entrypoint`
and `files`. It contains no executable host path. The original trusted-host
`scriptRegistryProjectImport` and `scriptRegistryProjectExport` retain ZIP and
source-authoring archive behavior. Portable source export is explicitly a source
exchange, not a substitute for those archive operations.

Existing-source mutations, copy/assignment, export and submission require all
four `expected` fields from the opened Registry record:

```python
expected = {"expected_" + key: opened[key] for key in
            ("sha256", "revision", "record_sha256", "owner_context")}
```

`revision` detects metadata-only edits. `record_sha256` pins the entire original
record; `owner_context` pins its original physical Registry root. Updates retain
identity, scope and language. Existing owner locks prevent concurrent silent
overwrite. Submission checks the full identity in the fresh original preparer
before and after snapshot preparation. The submitted Job retains its exact
source revision and source-owner projections independently of future edits.

| SCRIPT_JOB operation | Arguments after language | Result |
| --- | --- | --- |
| debug_submit | reference, expected, parameters, inputs, breakpoints | Supervised native Debug Job |
| debug_read | job_id, source_sha256 | Actual paused/running/terminal state, stack, selected frame and typed locals |
| debug_control | job_id, source_sha256, control, frame | Original native control receipt |
| inspect | job_id, source_sha256 | Status, diagnostics, inputs, parameters and canonical published Dataset receipts |
| stream_read | job_id, source_sha256, role, offset, count, tail | Bounded original stdout/stderr/diagnostics page |
| cancel | job_id, source_sha256 | Original supervisor cancellation receipt |

Single-Script `breakpoints` is a list of positive physical line numbers. Project
breakpoints map admitted relative filenames to those lists. No arbitrary source
path is accepted. Frame indices are integers 0 through 31, subject to the native
paused stack. Controls are `continue`, `into`, `over`, `out`, `frame`, `stop` and
Python `pause`. GNU Octave asynchronous Pause is **unsupported** and returns
`GXTXT:ScriptJob:Unsupported`; no interrupt emulation is supplied. Debugging
requires a registered Session source. Python uses the original `bdb` backend;
Octave uses its original `dbstop`, `dbstep`, `dbstack` and `whos` adapter.

Poll `debug_read` for a new sequence before sending another control. Native
stepping requires an actual paused frame, Python Pause requires a running trace,
and terminal Jobs refuse further native controls. A stop/cancel request is
asynchronous: poll `inspect` until the original supervisor reports terminal
state. All Job operations first resolve the original record and refuse another
Session, language, private CORE origin or stale source digest. Immutable Job
snapshot identity remains authoritative if a Registry source is edited later.

Stream roles are `stdout`, `stderr`, `diagnostics`; offset is nonnegative and
count is bounded to 4–262144 bytes. `tail` is boolean. Pages preserve distinct
program streams and original lifecycle diagnostics without disclosing retained
filesystem paths or debugger credentials.

An authenticated direct-host caller may carry the optional
`gxtxt.direct_bridge_context.v1` context. Authoring then requires `author=true`
and an approval digest matching the exact original typed Bridge request. Running
requires `run=true` and approved reference, SHA, revision, full record digest and
owner digest. Read-only contexts cannot mutate sources or submit/control Jobs.
Direct Jobs retain the original Supervisor client-owner CAS, using the protected
`mcp:<client_id>` principal and the actual Bridge process identity. Another client
in the same Session cannot read or control them. A dead previous process can be
reattached through that same original CAS; a foreign live owner cannot be stolen.
These checks belong to the existing scripting bindings, and do not add a second
MCP operation catalog. Ordinary registered Script Jobs retain their original
admission and API requirements.

Stable adapter error identifiers include `GXTXT:ScriptBridge:InvalidArguments`,
`Ownership`, `MissingProvider`, `ProviderUnavailable`, and
`GXTXT:ScriptJob:Unsupported`. Original Registry, source validation, CAS,
dependency, supervisor and native debugger failures retain their diagnostics
through `GXTXT:ScriptBridge:RemoteError`. No failed save authorizes execution.
