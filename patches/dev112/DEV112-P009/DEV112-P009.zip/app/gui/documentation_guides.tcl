# SPDX-License-Identifier: GPL-3.0-or-later
# Main Help uses the existing index and HTML presentation, with ordered parts.
proc ::GX::documentationBrowserMainGuideBuild {parent} {
    variable ::GX::DocumentationManual::state
    set state($parent,module) framework
    set state($parent,tutorial_handle) {}
    set state($parent,tutorial_status) {}
    ttk::frame $parent.navigation
    ttk::button $parent.navigation.previous -text {Previous section} -command [list ::GX::documentationBrowserMainGuideStep -1]
    ttk::button $parent.navigation.next -text {Next section} -command [list ::GX::documentationBrowserMainGuideStep 1]
    pack $parent.navigation.previous $parent.navigation.next -side left -padx 3
    pack $parent.navigation -fill x -pady 3
    ttk::panedwindow $parent.split -orient horizontal
    ttk::frame $parent.split.sections
    ttk::treeview $parent.split.sections.tree -show tree -selectmode browse -height 6
    ttk::scrollbar $parent.split.sections.scroll -command [list $parent.split.sections.tree yview]
    $parent.split.sections.tree configure -yscrollcommand [list $parent.split.sections.scroll set]
    pack $parent.split.sections.scroll -side right -fill y
    pack $parent.split.sections.tree -fill both -expand 1
    ttk::frame $parent.split.host
    $parent.split add $parent.split.sections -weight 1
    $parent.split add $parent.split.host -weight 3
    pack $parent.split -fill both -expand 1
    ttk::label $parent.status -textvariable ::GX::DocumentationManual::state($parent,tutorial_status) -wraplength 500
    pack $parent.status -fill x
    bind $parent.split.sections.tree <<TreeviewSelect>> ::GX::documentationBrowserMainGuideSelected
    bind $parent <Destroy> [list ::GX::documentationBrowserMainGuideDestroyed $parent %W]
}
proc ::GX::documentationBrowserMainGuideDestroyed {parent actual} {
    if {$parent ne $actual} return
    documentationBrowserHtmlClose $parent tutorial_handle
    array unset ::GX::DocumentationManual::state $parent,*
}
proc ::GX::documentationBrowserMainGuidePopulate {} {
    set parent .top.nb.help.right.tabs.html
    set tree $parent.split.sections.tree
    if {![winfo exists $tree]} return
    set selected [$tree selection]
    $tree delete [$tree children {}]
    set parts [documentationBrowserGuideParts]
    foreach id $::GX::documentationBrowserOrder {
        set entry [dict get $::GX::documentationBrowserEntries $id]
        if {[dict exists $entry guide_package] && [dict get $entry component_id] ne {} && [moduleField [dict get $entry component_id] descriptor {}] eq {}} {lappend parts $entry}
    }
    foreach entry $parts {
        set group guide:[dict get $entry guide_id]
        if {![$tree exists $group]} {$tree insert {} end -id $group -text "[dict get $entry guide_title]" -open 1}
        $tree insert $group end -id [dict get $entry id] -text "[dict get $entry part_order]. [dict get $entry part_id] — [dict get $entry part_title] ([dict get $entry edition])"
    }
    if {[llength $selected]==1 && [$tree exists [lindex $selected 0]]} {$tree selection set $selected
    } elseif {[llength $parts]} {$tree selection set [dict get [lindex $parts 0] id]
    } else {
        documentationBrowserHtmlClose $parent tutorial_handle
        set ::GX::DocumentationManual::state($parent,tutorial_status) {No general HTML guide is installed. Install a local guide package in Configuration → Modules → Guides.}
    }
}
proc ::GX::documentationBrowserMainGuideSelected {} {
    set tree .top.nb.help.right.tabs.html.split.sections.tree
    if {[.top.nb.help.right.tabs select] ne {.top.nb.help.right.tabs.html}} return
    set selected [$tree selection]
    if {[llength $selected]!=1 || ![string match content:* [lindex $selected 0]]} return
    documentationBrowserMainGuideShow [lindex $selected 0] 0
}
proc ::GX::documentationBrowserMainGuideShow {id {selectTab 1}} {
    set parent .top.nb.help.right.tabs.html
    set entry [documentationBrowserResolve $id]
    if {$selectTab} {.top.nb.help.right.tabs select $parent}
    set tree $parent.split.sections.tree
    if {[$tree exists $id]} {
        if {[$tree selection] ne [list $id]} {$tree selection set $id}
        $tree see $id
    }
    if {[info exists ::GX::DocumentationManual::state($parent,current)] && $::GX::DocumentationManual::state($parent,current) eq $id && $::GX::DocumentationManual::state($parent,tutorial_handle) ne {}} return
    set ::GX::DocumentationManual::state($parent,current) $id
    documentationBrowserHtmlClose $parent tutorial_handle
    foreach child [winfo children $parent.split.host] {destroy $child}
    documentationBrowserHtmlOpen $parent tutorial_handle $parent.split.host $id
}
proc ::GX::documentationBrowserMainGuideStep {offset} {
    set tree .top.nb.help.right.tabs.html.split.sections.tree
    set selected [$tree selection]
    if {[llength $selected]!=1} return
    set id [lindex $selected 0]
    set siblings [$tree children [$tree parent $id]]
    set at [expr {[lsearch -exact $siblings $id]+$offset}]
    if {$at>=0 && $at<[llength $siblings]} {documentationBrowserMainGuideShow [lindex $siblings $at]}
}
proc ::GX::documentationBrowserGuidesChanged {} {
    # Refresh existing component selectors and retire old document handles after
    # transactional replacement/removal; readers never retain stale package data.
    variable ::GX::DocumentationManual::state
    foreach key [array names state *,tutorial_ids] {
        set window [string range $key 0 end-13]
        if {[winfo exists $window]} {documentationBrowserHtmlClose $window tutorial_handle;documentationBrowserTutorialRefresh $window}
    }
    set parent .top.nb.help.right.tabs.html
    if {[winfo exists $parent]} {
        documentationBrowserHtmlClose $parent tutorial_handle
        unset -nocomplain state($parent,current)
        documentationBrowserMainGuidePopulate
    }
}
