# SPDX-License-Identifier: GPL-3.0-or-later
# Guides is a filtered projection of Plugin Install's original managed registry.
namespace eval ::GX::ConfigurationGuides {variable query {};variable rows {};variable selected {}}
proc ::GX::configurationGuidesBuild {parent} {
    ttk::frame $parent.search
    ttk::label $parent.search.label -text {Search guides}
    ttk::entry $parent.search.query -textvariable ::GX::ConfigurationGuides::query
    ttk::button $parent.search.refresh -text Refresh -command ::GX::configurationGuidesRefresh
    pack $parent.search.label -side left -padx 4
    pack $parent.search.refresh -side right -padx 4
    pack $parent.search.query -fill x -expand 1 -padx 4
    pack $parent.search -fill x -pady 6
    bind $parent.search.query <KeyRelease> ::GX::configurationGuidesRefresh
    bind $parent.search.query <Escape> {set ::GX::ConfigurationGuides::query {};::GX::configurationGuidesRefresh}
    ttk::frame $parent.actions
    foreach {key label} {install Install… update Update… uninstall Uninstall open Open} {
        ttk::button $parent.actions.$key -text $label -command [list ::GX::configurationGuidesAction $key]
        pack $parent.actions.$key -side left -padx 3
    }
    ttk::button $parent.actions.manager -text {Plugin Manager…} -command ::GX::pluginManagerDialog
    pack $parent.actions.manager -side left -padx 3
    pack $parent.actions -side bottom -fill x -pady 5
    ttk::label $parent.note -text {Version differences are advisory. Guides remain available offline. No guide is activated as a module.} -wraplength 500 -justify left
    pack $parent.note -side bottom -fill x -padx 6 -pady 5
    ttk::panedwindow $parent.split -orient vertical
    ttk::frame $parent.split.list
    ttk::treeview $parent.split.list.tree -columns {edition status} -show {tree headings} -selectmode browse -height 7
    $parent.split.list.tree heading #0 -text {Logical guide / Part / Package}
    $parent.split.list.tree heading edition -text {Package version}
    $parent.split.list.tree heading status -text Status
    $parent.split.list.tree column #0 -width 400 -minwidth 170
    $parent.split.list.tree column edition -width 130 -minwidth 110
    $parent.split.list.tree column status -width 140 -minwidth 100
    ttk::scrollbar $parent.split.list.y -command [list $parent.split.list.tree yview]
    ttk::scrollbar $parent.split.list.x -orient horizontal -command [list $parent.split.list.tree xview]
    $parent.split.list.tree configure -yscrollcommand [list $parent.split.list.y set] -xscrollcommand [list $parent.split.list.x set]
    grid $parent.split.list.tree -row 0 -column 0 -sticky nsew
    grid $parent.split.list.y -row 0 -column 1 -sticky ns
    grid $parent.split.list.x -row 1 -column 0 -sticky ew
    grid columnconfigure $parent.split.list 0 -weight 1
    grid rowconfigure $parent.split.list 0 -weight 1
    ttk::frame $parent.split.detail
    text $parent.split.detail.text -wrap word -height 8 -state disabled -yscrollcommand [list $parent.split.detail.scroll set]
    ttk::scrollbar $parent.split.detail.scroll -command [list $parent.split.detail.text yview]
    pack $parent.split.detail.scroll -side right -fill y
    pack $parent.split.detail.text -fill both -expand 1
    $parent.split add $parent.split.list -weight 2
    $parent.split add $parent.split.detail -weight 1
    pack $parent.split -fill both -expand 1 -padx 5
    bind $parent.split.list.tree <<TreeviewSelect>> ::GX::configurationGuidesSelect
    bind $parent.split.list.tree <Return> {::GX::configurationGuidesAction open;break}
    bind $parent <Configure> [list ::GX::configurationGuidesResize $parent %W %w]
}
proc ::GX::configurationGuidesResize {parent actual width} {
    if {$parent eq $actual} {$parent.note configure -wraplength [expr {max(200,$width-20)}]}
}
proc ::GX::configurationGuidesRefresh {} {
    variable ::GX::ConfigurationGuides::query
    variable ::GX::ConfigurationGuides::rows
    variable ::GX::ConfigurationGuides::selected
    set parent .top.nb.configuration.sections.modules.kinds.guides
    if {![winfo exists $parent]} return
    set tree $parent.split.list.tree
    $tree delete [$tree children {}]
    set rows {}
    foreach row [pluginGuideList $query] {
        set id [dict get $row id]
        dict set rows $id $row
        set title [dict get $row title]
        if {[dict exists $row guide_id]} {set title "[dict get $row guide_title] / [dict get $row part_order]. [dict get $row part_id] / $id"}
        $tree insert {} end -id $id -text $title -values [list [dict get $row version] [dict get $row status]]
    }
    if {$selected ne {} && [$tree exists $selected]} {$tree selection set $selected
    } elseif {[llength [$tree children {}]]} {$tree selection set [lindex [$tree children {}] 0]}
    configurationGuidesSelect
}
proc ::GX::configurationGuidesSelect {} {
    variable ::GX::ConfigurationGuides::rows
    variable ::GX::ConfigurationGuides::selected
    set parent .top.nb.configuration.sections.modules.kinds.guides
    set choice [$parent.split.list.tree selection]
    set selected {}
    set text {No installed guides match the search. Use Install to choose a local type=guide ZIP.}
    set verified 0
    if {[llength $choice]==1 && [dict exists $rows [lindex $choice 0]]} {
        set selected [lindex $choice 0];set row [dict get $rows $selected]
        set text "Package: $selected\nPackage version: [dict get $row version]\nStatus: [dict get $row status]\nIntegrity: [dict get $row integrity]\n"
        set verified [expr {[dict get $row integrity] eq {verified}}]
        if {$verified} {
            append text "Logical guide: [dict get $row guide_id] — [dict get $row guide_title]\nEdition: [dict get $row edition]\nPart: [dict get $row part_id] (order [dict get $row part_order])\nFramework reference: [dict get $row framework_version]; installed [dict get $row installed_framework]\nPatch reference: [dict get $row framework_patch]; installed [dict get $row installed_patch]\n"
            if {[dict get $row component_id] ne {}} {append text "Component: [dict get $row component_id]; reference [dict get $row component_version]; installed [dict get $row installed_component]\n"}
            append text "Origin: [dict get $row origin]\nSource article: [dict get $row source_url]\nLicense: [dict get $row license]\nLanguage (informative): [dict get $row language]\n"
            if {[llength [dict get $row notices]]} {append text "⚠ [join [dict get $row notices] {; }]\nDifferences do not prevent reading or imply that an updated guide exists."}
        } else {append text [dict get $row reason]}
    }
    $parent.split.detail.text configure -state normal
    $parent.split.detail.text delete 1.0 end
    $parent.split.detail.text insert end $text
    $parent.split.detail.text configure -state disabled
    foreach action {update uninstall} {$parent.actions.$action state [expr {$selected eq {} ? {disabled} : {!disabled}}]}
    $parent.actions.open state [expr {$verified ? {!disabled} : {disabled}}]
}
proc ::GX::configurationGuidesAction {action} {
    variable ::GX::ConfigurationGuides::selected
    set id $selected
    if {$action ne {install} && $id eq {}} return
    if {[catch {
        switch -- $action {
            install - update {
                set file [pluginInstallChoosePackage "[string totitle $action] HTML guide"]
                if {$file eq {}} return
                set expected [expr {$action eq {update} ? $id : {}}]
                set result [pluginInstallPackage $file $action $expected guide]
                tk_messageBox -icon info -title {Guide package} -message "[dict get $result action]: [dict get $result id] [dict get $result version]. Guide is available offline."
            }
            uninstall {
                if {[tk_messageBox -type yesno -default no -icon question -title {Uninstall guide} -message "Uninstall guide package $id? Other parts remain installed."] ne {yes}} return
                pluginUninstall guide $id
            }
            open {
                documentationBrowserRefresh
                set entry [documentationBrowserResolve content:$id]
                if {[dict get $entry component_id] eq {} || [moduleField [dict get $entry component_id] descriptor {}] eq {}} {
                    # Missing component references remain readable in the same
                    # main Help HTML host; no replacement external Help window.
                    .top.nb select .top.nb.help
                    documentationBrowserMainGuideShow content:$id
                } else {
                    set host [documentationBrowserOpenModuleWindow [dict get $entry component_id]]
                    documentationBrowserTutorialRefresh $host
                    set at [lsearch -exact $::GX::DocumentationManual::state($host,tutorial_ids) content:$id]
                    $host.tabs.tutorial.choice current $at
                    $host.tabs select $host.tabs.tutorial
                    documentationBrowserTutorialSelected $host
                }
            }
        }
    } reason]} {tk_messageBox -icon error -title {Guide operation failed} -message $reason}
    configurationGuidesRefresh
}
