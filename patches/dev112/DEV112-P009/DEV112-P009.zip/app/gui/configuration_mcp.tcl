# SPDX-License-Identifier: GPL-3.0-or-later
# Optional adapter projection; its protected CLI is the only settings owner.
namespace eval ::GX::McpPanel {variable state;array set state {busy 0 command {} revision {} client {} enabled 0 transport stdio port 8765 read 0 author 0 run 0 invoke 0 session {} status {Not installed} health {} errors {} reports {}}}

proc ::GX::configurationMcpBuild {page} {
    upvar #0 ::GX::McpPanel::state s
    configurationGuiScrollForm $page
    set p $page.viewport.body
    set s(page) $p
    set s(command) [auto_execok gxtxt-mcp]
    if {[info exists ::env(GXTXT_MCP_EXECUTABLE)] && [file executable $::env(GXTXT_MCP_EXECUTABLE)]} {set s(command) [list $::env(GXTXT_MCP_EXECUTABLE)]}
    ttk::label $p.status -textvariable ::GX::McpPanel::state(status) -anchor w
    ttk::label $p.health -textvariable ::GX::McpPanel::state(health) -justify left -wraplength 650
    grid $p.status -row 0 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 4
    grid $p.health -row 1 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 4
    ttk::frame $p.actions
    foreach {name title command} {init {Initialize selected framework} {init} refresh Refresh {info} check {Check capabilities} {check} start Start {start} stop Stop {stop} test Test {test}} {
        ttk::button $p.actions.$name -text $title -command [list ::GX::configurationMcpAction {*}$command]
        pack $p.actions.$name -side left -padx 3 -pady 3
    }
    bind $p.actions <Configure> [list ::GX::uiFieldControlsLayout $p.actions %w]
    grid $p.actions -row 2 -column 0 -columnspan 3 -sticky ew -padx 5
    ttk::checkbutton $p.enabled -text {Enable optional MCP service (default OFF)} -variable ::GX::McpPanel::state(enabled)
    grid $p.enabled -row 3 -column 0 -columnspan 3 -sticky w -padx 8 -pady 4
    ttk::label $p.transportLabel -text Transport
    ttk::combobox $p.transport -state readonly -values {stdio streamable-http} -textvariable ::GX::McpPanel::state(transport) -width 20
    ttk::label $p.portLabel -text {Loopback port (127.0.0.1)}
    ttk::spinbox $p.port -from 1024 -to 65535 -textvariable ::GX::McpPanel::state(port) -width 10
    ttk::button $p.save -text {Apply MCP settings} -command ::GX::configurationMcpSave
    grid $p.transportLabel -row 4 -column 0 -sticky w -padx 8
    grid $p.transport -row 4 -column 1 -sticky ew -padx 8
    grid $p.portLabel -row 5 -column 0 -sticky w -padx 8
    grid $p.port -row 5 -column 1 -sticky w -padx 8
    grid $p.save -row 5 -column 2 -sticky e -padx 8
    ttk::label $p.setup -text {Local stdio: gxtxt-mcp serve --transport stdio; pass GXTXT_MCP_CLIENT_TOKEN in the client environment. HTTP: http://127.0.0.1:PORT/mcp with Bearer authentication. Tokens never belong in command arguments. Cloud connectivity requires a separate authorized connection. Stop affects only the adapter; accepted Jobs retain their original Supervisor.} -wraplength 650 -justify left
    grid $p.setup -row 6 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 6
    ttk::labelframe $p.clients -text {Explicit client grants} -padding 6
    grid $p.clients -row 7 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 5
    ttk::treeview $p.clients.list -columns {read author run invoke} -show {tree headings} -height 3 -selectmode browse
    $p.clients.list heading #0 -text Client
    $p.clients.list column #0 -width 160 -stretch 1
    foreach key {read author run invoke} {$p.clients.list heading $key -text [string totitle $key];$p.clients.list column $key -width 65 -stretch 0}
    pack $p.clients.list -fill x
    bind $p.clients.list <<TreeviewSelect>> ::GX::configurationMcpClientSelect
    ttk::frame $p.clients.fields
    ttk::entry $p.clients.fields.id -textvariable ::GX::McpPanel::state(client) -width 20
    pack $p.clients.fields.id -side left -padx 3
    foreach key {read author run invoke} {ttk::checkbutton $p.clients.fields.$key -text [string totitle $key] -variable ::GX::McpPanel::state($key);pack $p.clients.fields.$key -side left -padx 3}
    pack $p.clients.fields -fill x -pady 3
    bind $p.clients.fields <Configure> [list ::GX::uiFieldControlsLayout $p.clients.fields %w]
    ttk::frame $p.clients.sessions
    ttk::label $p.clients.sessions.label -text {Authorized Session paths (one per line)}
    text $p.clients.sessions.paths -height 2 -width 35 -wrap none -undo 0
    pack $p.clients.sessions.label -anchor w
    pack $p.clients.sessions.paths -fill x
    pack $p.clients.sessions -fill x
    ttk::frame $p.clients.buttons
    foreach {name title command} {add {Add client…} add grant {Apply explicit grants} grant revoke Revoke revoke source {Review source identity…} source request {Review exact request…} request library {Open original Script Library…} library} {
        ttk::button $p.clients.buttons.$name -text $title -command [list ::GX::configurationMcpClientAction $command]
        pack $p.clients.buttons.$name -side left -padx 3 -pady 3
    }
    bind $p.clients.buttons <Configure> [list ::GX::uiFieldControlsLayout $p.clients.buttons %w]
    pack $p.clients.buttons -fill x
    ttk::label $p.trust -text {Read, Author, Run and general direct Invoke are separate grants. Review exact requests before source creation/update, and exact Registry SHA/revision before execution. Registered Python/Octave source has normal OS capabilities. Review source in the original Library/editor; this panel does not edit code.} -wraplength 650 -justify left
    grid $p.trust -row 8 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 4
    ttk::labelframe $p.reports -text {Local redacted issue reports} -padding 6
    grid $p.reports -row 9 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 5
    ttk::treeview $p.reports.list -columns {client api classification digest} -show headings -height 3 -selectmode browse
    foreach {key label width} {client Client 100 api API 190 classification Classification 190 digest SHA256 150} {$p.reports.list heading $key -text $label;$p.reports.list column $key -width $width -stretch 1}
    pack $p.reports.list -fill x
    ttk::frame $p.reports.buttons
    foreach {name title command} {refresh Refresh {reports} review {Review staged report} {review-staged} approve {Review and approve report preview…} {report} export {Export reviewed report…} {export-report}} {
        ttk::button $p.reports.buttons.$name -text $title -command [list ::GX::configurationMcpReportAction $command]
        pack $p.reports.buttons.$name -side left -padx 3 -pady 3
    }
    bind $p.reports.buttons <Configure> [list ::GX::uiFieldControlsLayout $p.reports.buttons %w]
    pack $p.reports.buttons -fill x
    ttk::label $p.errors -textvariable ::GX::McpPanel::state(errors) -wraplength 650 -justify left
    grid $p.errors -row 10 -column 0 -columnspan 3 -sticky ew -padx 8 -pady 5
    bind $page.viewport <Configure> +[list ::GX::configurationMcpResize $p %w]
    if {$s(command) eq {}} {
        set s(status) {Not installed — optional gxtxt-mcp-server Debian package}
        set s(health) {GX-TXT works without this component. Install the independent package, then reopen Configuration or restart GX-TXT. No endpoint or client grants are created by installation.}
    } else {configurationMcpRequest {info} info}
}

proc ::GX::configurationMcpResize {p width} {foreach name {health setup trust errors} {if {[winfo exists $p.$name]} {$p.$name configure -wraplength [expr {max(160,$width-30)}]}}}
proc ::GX::configurationMcpRequest {arguments action {payload {}}} {
    upvar #0 ::GX::McpPanel::state s
    if {$s(command) eq {}} {set s(status) {Not installed};return}
    if {$s(busy)} {set s(status) {An MCP request is still active};return}
    set s(busy) 1;set s(status) "Working: $action"
    if {[catch {scriptJobAsync [list {*}$s(command) --format tcl {*}$arguments] $payload [list ::GX::configurationMcpComplete $action] {timeout_ms 90000 max_bytes 262144 process_group 1 ui_lifetime 1 separate_stderr 1 label {MCP configuration request}}} reason]} {
        set s(busy) 0;set s(status) Error;set s(errors) $reason
    }
}
proc ::GX::configurationMcpComplete {action response} {
    upvar #0 ::GX::McpPanel::state s
    set s(busy) 0
    if {![info exists s(page)] || ![winfo exists $s(page)]} return
    if {![dict get $response ok]} {set s(status) Error;set s(errors) [string range [dict get $response error] 0 3000];return}
    set result [dict get $response result];set s(errors) {}
    if {$action eq {info}} {
        set s(snapshot) $result
        foreach key {enabled transport port revision} {set s($key) [dict get $result $key]}
        set s(status) "[dict get $result component_state] — [dict get $result state]"
        set s(health) "Adapter [dict get $result component_version]; SDK [dict get $result sdk_version]; MCP [dict get $result protocol_version]. Selected installation: [dict get $result framework_root]. Use Check capabilities for exact version/patch; Test verifies a real authenticated client and Prompt/catalog discovery."
        if {[dict exists $result framework]} {
            append s(health) "\nGX-TXT [dict get $result framework version], patch [dict get $result framework patch_level]."
        } else {append s(health) "\nCapability error: [dict get $result capability_error]"}
        if {[dict get $result transport] eq {streamable-http}} {append s(health) " Endpoint: http://127.0.0.1:[dict get $result port]/mcp"}
        if {[dict exists $result health last_boundary_error http_status]} {
            set recent [dict get $result health last_boundary_error]
            append s(health) "\nRecent HTTP boundary refusal: [dict get $recent http_status] at [dict get $recent time_utc]; total [dict get $result health boundary_refusals]. No private request contents are logged."
        }
        set tree $s(page).clients.list;$tree delete [$tree children {}]
        dict for {client grant} [dict get $result clients] {$tree insert {} end -id $client -text $client -values [list [dict get $grant read] [dict get $grant author] [dict get $grant run] [dict get $grant invoke]]}
        # Refresh the editable projection from the same authoritative client
        # inventory. A new/revoked client must never inherit another's grants.
        if {$s(client) ne {} && [dict exists $result clients $s(client)]} {
            $tree selection set $s(client)
            configurationMcpClientSelect
        } else {
            set s(client) {}
            foreach key {read author run invoke} {set s($key) 0}
            $s(page).clients.sessions.paths delete 1.0 end
        }
    } elseif {$action eq {check}} {
        set s(status) Ready
        set s(health) "GX-TXT [dict get $result version], patch [dict get $result patch_level]; [dict get $result declared_api_count] original API declarations verified. Runtime provider/Session availability is checked through the live Bridge during Test."
    } elseif {$action eq {test}} {
        set s(status) {Ready — authenticated MCP Test passed}
        set s(health) "Real [dict get $result transport] SDK handshake [dict get $result protocol_version]; scientific-workflow Prompt, catalog Resource and authenticated server-info verified. Live authorized Session catalog checked: [dict get $result live_catalog]."
    } elseif {$action eq {client-add}} {
        set s(client) [dict get $result client_id]
        configurationMcpToken [dict get $result client_id] [dict get $result token]
        configurationMcpRequest {info} info
    } elseif {$action eq {review-file}} {
        configurationMcpReview $result
    } elseif {$action eq {reports}} {
        set tree $s(page).reports.list;$tree delete [$tree children {}]
        set s(reports) [dict get $result reports]
        set index 0
        foreach row $s(reports) {$tree insert {} end -id [incr index] -values [list [dict get $row client_id] [dict get $row api_id] [dict get $row classification] [dict get $row report_sha256]]}
        set s(status) {Ready — local report inventory refreshed}
    } elseif {$action eq {review-staged}} {
        configurationMcpReadOnly {Local staged redacted report} $result
    } else {set s(status) "Completed: $action";configurationMcpRequest {info} info}
}
proc ::GX::configurationMcpAction {action} {
    upvar #0 ::GX::McpPanel::state s
    switch -- $action {
        init {configurationMcpRequest [list init $::GX::scriptDir] init}
        test {configurationMcpTestDialog}
        default {configurationMcpRequest [list $action] $action}
    }
}
proc ::GX::configurationMcpSave {} {
    upvar #0 ::GX::McpPanel::state s
    if {$s(revision) eq {}} {set s(errors) {Initialize or refresh the protected service configuration first};return}
    configurationMcpRequest [list configure --expected-revision $s(revision) --enabled [expr {$s(enabled)?{true}:{false}}] --transport $s(transport) --port $s(port)] configure
}
proc ::GX::configurationMcpClientSelect {} {
    upvar #0 ::GX::McpPanel::state s
    set selected [$s(page).clients.list selection];if {[llength $selected]!=1} return
    set s(client) [lindex $selected 0]
    set grant [dict get $s(snapshot) clients $s(client)]
    foreach key {read author run invoke} {set s($key) [dict get $grant $key]}
    $s(page).clients.sessions.paths delete 1.0 end
    $s(page).clients.sessions.paths insert 1.0 [join [dict get $grant sessions] \n]
}
proc ::GX::configurationMcpClientAction {action} {
    upvar #0 ::GX::McpPanel::state s
    if {$action eq {library}} {scriptLibraryOpen;return}
    if {$s(client) eq {}} {set s(errors) {Enter or select an exact client ID first};return}
    switch -- $action {
        add {configurationMcpRequest [list client-add $s(client)] client-add}
        revoke {configurationMcpRequest [list revoke $s(client)] revoke}
        grant {
            set command [list grant $s(client)]
            foreach key {read author run invoke} {lappend command --$key [expr {$s($key)?{true}:{false}}]}
            set paths [string trim [$s(page).clients.sessions.paths get 1.0 end]]
            if {$paths eq {}} {lappend command --clear-sessions} else {foreach path [split $paths \n] {lappend command --session [string trim $path]}}
            configurationMcpRequest $command grant
        }
        source - request {configurationMcpChooseReview $action}
    }
}
proc ::GX::configurationMcpChooseReview {kind} {
    upvar #0 ::GX::McpPanel::state s
    if {$s(client) eq {}} {set s(errors) {Select the client receiving this explicit approval first};return}
    set file [tk_getOpenFile -title "Review exact MCP $kind JSON" -filetypes {{{JSON} {.json}}}]
    if {$file eq {}} return
    set s(reviewPath) $file;set s(reviewClient) $s(client)
    configurationMcpRequest [list review-file $kind $file] review-file
}
proc ::GX::configurationMcpReadOnly {title content} {
    set w .gxtxtMcpReview
    catch {destroy $w};uiFieldDialogCreate $w . $title
    text $w.text -width 80 -height 20 -wrap word -undo 0
    $w.text insert 1.0 $content;$w.text configure -state disabled
    ttk::scrollbar $w.scroll -command [list $w.text yview];$w.text configure -yscrollcommand [list $w.scroll set]
    ttk::frame $w.buttons;pack $w.buttons -side bottom -fill x
    pack $w.scroll -side right -fill y;pack $w.text -fill both -expand 1
    ttk::button $w.buttons.close -text Close -command [list ::GX::uiFieldDialogClose $w];pack $w.buttons.close -side right -padx 4 -pady 4
    bind $w.buttons <Configure> [list ::GX::configurationMcpReviewLayout $w.buttons %w]
    return [uiFieldDialogPresent $w $w.text]
}
proc ::GX::configurationMcpReviewLayout {frame width} {
    set controls {}
    foreach name {approve library close} {if {[winfo exists $frame.$name]} {lappend controls $frame.$name}}
    uiFieldControlsLayout $frame $width $controls
}
proc ::GX::configurationMcpReview {result} {
    upvar #0 ::GX::McpPanel::state s
    set s(review) $result
    set w [configurationMcpReadOnly {Review exact MCP approval} "Approval client: $s(reviewClient)\n\n[dict get $result review_json]"]
    ttk::button $w.buttons.approve -text {Approve exact identity} -command ::GX::configurationMcpApprove
    pack $w.buttons.approve -side left -padx 4 -pady 4
    if {[dict get $result kind] eq {source}} {
        ttk::button $w.buttons.library -text {Review in Library…} -command ::GX::configurationMcpReviewSource
        pack $w.buttons.library -side left -padx 4
    }
}
proc ::GX::_configurationMcpReviewSourceIdentity {review} {
    if {[dict get $review kind] ne {source}} {error {This review does not identify a Script source}}
    set identity [nativeWorkspaceDecode [nativeWorkspaceJsonDecode [dict get $review review_json]]]
    if {[lsort [dict keys $identity]] ne [lsort {reference sha256 revision record_sha256 owner_context}]} {error {Review the complete original Script Registry identity}}
    set reference [dict get $identity reference]
    if {$reference ne [dict get $review reference]} {error {The reviewed Script reference changed}}
    set expected {}
    foreach field {sha256 revision record_sha256 owner_context} {dict set expected expected_$field [dict get $identity $field]}
    _scriptRegistryExpectedCheck [scriptRegistryDescribe $reference] $expected
    return $reference
}
proc ::GX::configurationMcpReviewSource {} {
    upvar #0 ::GX::McpPanel::state s
    if {[catch {set reference [_configurationMcpReviewSourceIdentity $s(review)]} reason]} {
        set s(errors) $reason
        tk_messageBox -parent .gxtxtMcpReview -icon error -title {MCP source review} -message "The reviewed identity does not match the current Script Library. Open its Session or review the updated source, then try again.\n\n$reason"
        return
    }
    scriptLibraryOpen $reference
}
proc ::GX::configurationMcpApprove {} {
    upvar #0 ::GX::McpPanel::state s
    set kind [dict get $s(review) kind]
    if {$kind eq {report}} {set args [list approve-report $s(reviewClient) [dict get $s(review) report_sha256]]} else {
        set args [list approve-$kind $s(reviewClient) $s(reviewPath) --expected-file-sha256 [dict get $s(review) file_sha256]]
    }
    uiFieldDialogClose .gxtxtMcpReview
    configurationMcpRequest $args approval
}
proc ::GX::configurationMcpToken {client token} {
    set w .gxtxtMcpToken;catch {destroy $w};uiFieldDialogCreate $w . {New MCP credential — shown once}
    ttk::label $w.note -text "Client $client: save this credential in your MCP client's protected settings. It is not included in status or reports."
    ttk::entry $w.value -width 72 -show •
    $w.value insert 0 $token
    ttk::button $w.reveal -text {Reveal once} -command [list $w.value configure -show {}]
    ttk::button $w.close -text {Saved — close} -command [list ::GX::uiFieldDialogClose $w]
    pack $w.note $w.value $w.reveal $w.close -fill x -padx 8 -pady 5
    uiFieldDialogPresent $w $w.value 1
}
proc ::GX::configurationMcpTestDialog {} {
    set w .gxtxtMcpTest;catch {destroy $w};uiFieldDialogCreate $w . {Authenticated MCP Test}
    ttk::label $w.note -text {Enter an existing client token; it is passed privately through stdin and is not saved.}
    ttk::entry $w.token -show • -width 60
    ttk::label $w.sessionLabel -text {Optional exact authorized Session path (checks the live Bridge catalog)}
    ttk::entry $w.session -width 60
    ttk::button $w.run -text {Run real client Test} -command ::GX::configurationMcpTestRun
    pack $w.note $w.token $w.sessionLabel $w.session $w.run -fill x -padx 8 -pady 5
    bind $w.token <Return> {::GX::configurationMcpTestRun;break}
    uiFieldDialogPresent $w $w.token
}
proc ::GX::configurationMcpTestRun {} {
    set w .gxtxtMcpTest;set token [$w.token get];set session [$w.session get]
    uiFieldDialogClose $w
    set args [list test --token-stdin];if {$session ne {}} {lappend args --session $session}
    configurationMcpRequest $args test "$token\n"
}
proc ::GX::configurationMcpReportAction {action} {
    upvar #0 ::GX::McpPanel::state s
    if {$action eq {reports}} {configurationMcpRequest {reports} reports;return}
    if {$action eq {report}} {configurationMcpChooseReview report;return}
    set selected [$s(page).reports.list selection];if {[llength $selected]!=1} {set s(errors) {Select a local staged report first};return}
    set row [lindex $s(reports) [expr {[lindex $selected 0]-1}]]
    set args [list [dict get $row client_id] [dict get $row report_sha256]]
    if {$action eq {review-staged}} {configurationMcpRequest [list review-report {*}$args] review-staged;return}
    set destination [tk_getSaveFile -title {Export exact approved redacted report} -defaultextension .json]
    if {$destination ne {}} {configurationMcpRequest [list export-report {*}$args $destination] export-report}
}
