# viewer.dataset_curve_fit

SPDX-License-Identifier: GPL-3.0-or-later

Scientific Dataset fitting with the accepted numerical engine, resizable controls/plot layout, grouped existing commands and exact-ID named Session Workspaces. Existing source/selection/accepted-result algorithms are preserved.

Explicit nonlinear profile likelihood retains constrained trials, physical
parameter identities and shared CORE interpretation across GUI, recipes and
Python/Octave result pages. See [the public API](../../../docs/api/DATASET_CURVE_FIT_API_v1.md#retained-profile-likelihood).

See [MANUAL.md](MANUAL.md), [CHANGELOG.md](CHANGELOG.md) and
[TEST_RESULTS.md](TEST_RESULTS.md). Install this normal module package through
the existing Plugin Manager; dependencies and public API entrypoints are declared
in module.ini.

## P011 results and History

Curve Fitter uses four spacious results tabs: Fit & Plot, Residuals,
Parameters & Statistics, and Technical Details. Residuals have exact anchored
200-row pages and17-digit numeric cells. Residual Zoom/Fit operates the visible
diagnostic independently of the main geometric aspect; saved presentation
retains that view and tab through the existing Workspace auxiliary channel.

Ordinary Preview reuses its exact current successful GUI result only after
validating live source, selected observations and every existing fit setting.
This prevents unchanged clicks from creating History entries solely for repeated
Resource receive timestamps. **Fit → Recompute Preview** explicitly runs the
original computation again, including its existing stochastic/solver semantics.
The public fitting API is unchanged. Registered asynchronous models keep their
existing execution path. Accepted results retain their accepted state on reuse.
Resource audit metadata is preserved; no scientific History is silently pruned.
Clear History uses the existing guarded CORE confirmation/optional backup for
saved Workspaces and unsaved drafts. Return to latest before clearing a browsed
history. Save Workspace and publishing a fitted scientific Dataset are separate.

Result and source tables use the shared CORE font/row/column metric owner,
including larger Tk text scaling. Explanatory notes in statistical, covariance,
bootstrap, profile and solver settings scroll within their original forms.
Short assumption labels retain the same stored statistical model identifiers;
no numerical assumption or solver setting changes automatically.

Technical Details is read-only and participates in normal Tab traversal. Focus
the report to scroll with Page Up/Page Down or select/copy its exact text.
Changing tabs or scrolling the report does not recompute a fit or resize the
main plot within its tab. Screen-reader compatibility requires an actual
platform test and is not inferred from keyboard navigation.

Shared Surface Fitter restoration and Undo/Redo describe the actual retained
accepted/preview/History state. This feedback does not change a fitted result,
source binding, model calculation or saved Workspace payload.
