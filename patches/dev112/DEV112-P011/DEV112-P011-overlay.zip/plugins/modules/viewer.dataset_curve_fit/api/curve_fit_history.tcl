# SPDX-License-Identifier: GPL-3.0-or-later
# Host projections only. CORE Recipe owns History and Document owns persistence.
proc ::GX::DatasetCurveFit::_historyValidate {record} {
    workspaceValidate [dict get $record base]
    return 1
}
proc ::GX::DatasetCurveFit::_historyCapture {w} {
    set payload [_payload $w]
    # Presentation belongs to CORE's journaled auxiliary channel. In particular,
    # a per-source view change must not replace its full scientific fit receipt.
    dict set payload presentation {}
    dict set payload view_bounds {}
    dict unset payload panel
    dict unset payload gui_presentation
    set sources {}
    foreach source [dict get $payload workspace_sources] {
        dict set source state viewBounds {}
        lappend sources $source
    }
    dict set payload workspace_sources $sources
    return $payload
}
proc ::GX::DatasetCurveFit::_historyPresentationCapture {w} {
    variable state
    set sourceViews {}
    dict for {id entry} $state($w,sources) {
        dict set sourceViews $id [::GX::datasetPublicationV2DictDefault [dict get $entry state] viewBounds {}]
    }
    if {$state($w,activeSource) ne {}} {dict set sourceViews $state($w,activeSource) $state($w,viewBounds)}
    return [dict create presentation [::GX::Native2D::core presentation $state($w,scene)] view_bounds $state($w,viewBounds) \
        source_views $sourceViews panel [dict create visible $state($w,showResiduals) fraction $state($w,residualFraction) residual_axis $state($w,residualAxis)] \
        residual_view_bounds [expr {[info exists state($w,residualViewBounds)] ? $state($w,residualViewBounds) : {}}] \
        active_tab [expr {[info exists state($w,resultTab)] ? $state($w,resultTab) : {plot}}]]
}
proc ::GX::DatasetCurveFit::_historyPresentationMerge {payload auxiliary} {
    dict set payload gui_presentation $auxiliary
    foreach key {presentation view_bounds panel} {if {[dict exists $auxiliary $key]} {dict set payload $key [dict get $auxiliary $key]}}
    if {[dict exists $auxiliary source_views]} {
        set sources {}
        foreach source [dict get $payload workspace_sources] {
            set id [dict get $source id]
            if {[dict exists $auxiliary source_views $id]} {dict set source state viewBounds [dict get $auxiliary source_views $id]}
            lappend sources $source
        }
        dict set payload workspace_sources $sources
    }
    return $payload
}
proc ::GX::DatasetCurveFit::_historyPresentationRestore {w auxiliary} {
    variable state
    if {$auxiliary eq {}} return
    if {[dict exists $auxiliary presentation]} {::GX::Native2D::core presentation $state($w,scene) [dict get $auxiliary presentation]}
    if {[dict exists $auxiliary view_bounds]} {set state($w,viewBounds) [dict get $auxiliary view_bounds]}
    if {[dict exists $auxiliary source_views]} {
        dict for {id bounds} [dict get $auxiliary source_views] {
            if {[dict exists $state($w,sources) $id]} {dict set state($w,sources) $id state viewBounds $bounds}
        }
    }
    if {[dict exists $auxiliary panel]} {
        set state($w,showResiduals) [dict get $auxiliary panel visible]
        set state($w,residualFraction) [dict get $auxiliary panel fraction]
        set state($w,residualAxis) [dict get $auxiliary panel residual_axis]
    }
    set state($w,residualViewBounds) [::GX::datasetPublicationV2DictDefault $auxiliary residual_view_bounds {}]
    if {[dict exists $auxiliary active_tab]} {set state($w,resultTab) [dict get $auxiliary active_tab]}
    if {[winfo exists $w.right] && [winfo class $w.right] eq {TNotebook} && [info exists state($w,resultTab)]} {
        catch {$w.right select $w.right.$state($w,resultTab)}
    }
    redraw $w
}
proc ::GX::DatasetCurveFit::_historyPresentationEncode {auxiliary} {
    return [::GX::nativeWorkspaceEncode {record {presentation {named presentation2d} view_bounds {array real} source_views {map {array real}} panel {record {visible bool fraction real residual_axis text}} active_tab text residual_view_bounds {array real}}} $auxiliary]
}
proc ::GX::DatasetCurveFit::_savePresentation {w} {
    variable state
    if {[info exists state($w,restoringWorkspace)] && $state($w,restoringWorkspace)} return
    if {![dict exists $::GX::ScientificHistory::viewers $w]} return
    if {![::GX::scientificHistoryViewerEditable $w]} return
    set receipt [::GX::scientificHistoryViewerAuxiliary $w [_historyPresentationCapture $w]]
    if {[dict exists $receipt error] && [dict get $receipt error] ne {}} {set state($w,status) "Presentation could not be journaled: [dict get $receipt error]. The current scientific state and view remain open; pending presentation changes are not saved. Resolve the reported History/storage error, then reopen the Workspace to recover its last durable state. Review unsaved scientific edits before closing."}
    return $receipt
}
proc ::GX::DatasetCurveFit::_historyReplay {record} {return [::GX::scientificHistoryState $record]}
::GX::scientificRecipeHostRegister viewer.dataset_curve_fit [dict create capture ::GX::DatasetCurveFit::_historyCapture validate ::GX::DatasetCurveFit::_historyValidate replay ::GX::DatasetCurveFit::_historyReplay]
proc ::GX::DatasetCurveFit::_historyGuard {w} {
    variable state
    return [expr {(![info exists state($w,loading)] || !$state($w,loading)) && ![info exists state($w,press)] && ![info exists state($w,pan)]}]
}
proc ::GX::DatasetCurveFit::_historyEditable {w} {
    return [expr {[_historyGuard $w] && [::GX::scientificHistoryViewerEditable $w]}]
}
proc ::GX::DatasetCurveFit::_historyCommit {w record} {
    set payload [_historyPresentationMerge [::GX::scientificHistoryState $record] [_historyPresentationCapture $w]]
    dict set payload scientific_history $record
    _writePayload $w $payload
}
proc ::GX::DatasetCurveFit::_historyRestore {w payload} {
    variable state
    set auxiliary [_historyPresentationCapture $w]
    set payload [_historyPresentationMerge $payload $auxiliary]
    set state($w,restoringWorkspace) 1
    try {
        _workspaceCapture $w
        unset -nocomplain state($w,templateBinding) state($w,recipePointMask) state($w,influenceLinkedPoint)
        foreach entry [dict values $state($w,sources)] {
            set source [dict get $entry state]
            if {[dict get $source sourceToken] ne {}} {::GX::curveSourceClose [dict get $source sourceToken]}
            if {[dict get $source selectionScene] ne $state($w,selectionScene)} {::GX::Native2D::core destroy [dict get $source selectionScene]}
        }
        ::GX::Native2D::core destroy $state($w,scene)
        ::GX::Native2D::core destroy $state($w,selectionScene)
        if {[info exists state($w,residualViewScene)]} {::GX::Native2D::core destroy $state($w,residualViewScene);unset state($w,residualViewScene)}
        set state($w,scene) [::GX::Native2D::core scene];set state($w,selectionScene) [::GX::Native2D::core scene]
        foreach field {source selectionObject accepted previewFitId sourceToken activeSource} {set state($w,$field) {}}
        foreach field {sources records preview rows filters loadedBinding rects sourceDescriptor} {set state($w,$field) {}}
        set state($w,previewAccepted) 0
        _applyPayload $w $payload
        if {$state($w,preview) ne {}} {
            _resultPresentation $w
            _residualColumns $w $state($w,preview);_residualPageUi $w 0
        } else {set state($w,report) {}; $w.right.residuals.rows.table delete [$w.right.residuals.rows.table children {}]}
        _uiModelFields $w;_uiDomainFields $w
        $w.actions.accept configure -state [expr {$state($w,preview) ne {} && !$state($w,previewAccepted) ? "normal" : "disabled"}]
        $w.actions.publish configure -state [expr {$state($w,preview) ne {} ? "normal" : "disabled"}]
        $w.actions.export configure -state [expr {$state($w,records) ne {} ? "normal" : "disabled"}]
        redraw $w
    } finally {unset -nocomplain state($w,restoringWorkspace)}
}
proc ::GX::DatasetCurveFit::_historyAttach {w} {
    variable state
    if {$state($w,sessionToken) eq {}} return
    set record {}
    if {$state($w,documentId) ne {}} {set record [::GX::datasetPublicationV2DictDefault [dict get [::GX::interactiveDocumentRead $state($w,documentId)] payload] scientific_history {}]}
    ::GX::scientificHistoryViewerAttach $w viewer.dataset_curve_fit [dict create document_id $state($w,documentId) capture [list ::GX::DatasetCurveFit::_historyCapture $w] restore [list ::GX::DatasetCurveFit::_historyRestore $w] commit [list ::GX::DatasetCurveFit::_historyCommit $w] guard [list ::GX::DatasetCurveFit::_historyGuard $w] \
        capture_aux [list ::GX::DatasetCurveFit::_historyPresentationCapture $w] restore_aux [list ::GX::DatasetCurveFit::_historyPresentationRestore $w] \
        archive_auxiliary_encode ::GX::DatasetCurveFit::_historyPresentationEncode strip_description_lines 2] $record
    ::GX::scientificHistoryViewerStrip $w $w.footer $w.footer.status modules.dataset_curve_fit.history_strip [list -fill x -before $w.footer.coordinateReadout]
    ::GX::viewerCommandMenusRefresh $w
    trace add variable ::GX::DatasetCurveFit::state($w,status) write [list ::GX::DatasetCurveFit::_footerStatusChanged $w]
}
proc ::GX::DatasetCurveFit::_footerStatusChanged {w args} {
    after idle [list ::GX::_scientificHistoryStripSize $w]
}
proc ::GX::DatasetCurveFit::_commandEnabled {w id} {
    variable state
    if {$id in {model_card surface_workflow}} {return 1}
    if {$id eq "filter_cancel"} {return [expr {![ _historyGuard $w]}]}
    if {![_historyGuard $w]} {return 0}
    if {$id eq "profile_details"} {return [expr {[dict exists $state($w,preview) statistical_results profile]||[llength [$w.left.viewport.content.accepted.list curselection]]==1}]}
    if {$id eq "bootstrap_details"} {return [expr {[dict exists $state($w,preview) statistical_results bootstrap]||[llength [$w.left.viewport.content.accepted.list curselection]]==1}]}
    if {$id eq "residual_sequence"} {return [expr {[llength [$w.left.viewport.content.accepted.list curselection]]==1}]}
    if {$id eq "influence_details"} {return [expr {[dict exists $state($w,preview) statistical_results influence]||[llength [$w.left.viewport.content.accepted.list curselection]]==1}]}
    if {$id eq "parameter_dataset"} {return [expr {[llength $state($w,records)]>0}]}
    if {$id eq "covariance_details"} {return [dict exists $state($w,preview) covariance_binding]}
    if {$id eq "model_suggestions"} {return [expr {$state($w,source) ne {}&&$state($w,orientation) in {y_of_x x_of_y}}]}
    if {$id eq "model_comparison"} {return [expr {[llength $state($w,records)]>=2}]}
    if {$id in {recipe_python recipe_octave model_export model_workbench derived_properties physical_plausibility retained_query}} {return [expr {[llength [$w.left.viewport.content.accepted.list curselection]]==1}]}
    if {$id eq "template_apply"} {return [expr {[llength [::GX::interactiveDocumentList viewer.dataset_curve_fit dataset_curve_fit_recipe]]>0}]}
    if {$id in {parameter_correlation solver_details}} {return [expr {$state($w,preview) ne {}&&[dict exists $state($w,preview) statistical_results training]}]}
    if {$id eq "smoothing_details"} {return [dict exists $state($w,preview) statistical_results training provenance smoothing]}
    if {$id eq "log_details"} {return [dict exists $state($w,preview) statistical_results training context response_transform]}
    if {$id eq "prediction_details"} {return [expr {$state($w,preview) ne {}&&[dict exists $state($w,preview) prediction_plan]}]}
    if {$id eq "scientific_report"} {return [expr {$state($w,preview) ne {}}]}
    if {$id eq "measurement_details"} {return [expr {$state($w,preview) ne {}&&[dict exists $state($w,preview) measurement_binding]}]}
    if {$id in {undo redo previous next latest branch}} {
        if {![dict exists $::GX::ScientificHistory::viewers $w]} {return 0}
        set adapter [dict get $::GX::ScientificHistory::viewers $w];set record [dict get $adapter record]
        set count [llength [dict get $record steps]];set cursor [dict get $record cursor]
        switch $id {
            undo {return [expr {![dict get $adapter browsing] && $cursor>0}]}
            redo {return [expr {![dict get $adapter browsing] && $cursor<$count}]}
            branch {return [expr {[dict get $adapter browse_cursor]<$count}]}
            default {return [expr {$count>0}]}
        }
    }
    if {$id in {timeline strip history_details workspace_close workspace_open workspace_manager}} {return 1}
    if {![_historyEditable $w]} {return 0}
    if {$id in {template_save log_publish}} {return [expr {[llength [$w.left.viewport.content.accepted.list curselection]]==1}]}
    if {$id eq "knot_settings"} {return [expr {$state($w,activeSource) ne {}&&$state($w,model) in {akima bspline}&&$state($w,orientation) in {y_of_x x_of_y}}]}
    if {$id eq "smoothing_settings"} {return [expr {$state($w,model) eq "smoothing_spline"}]}
    if {$id eq "solver_settings"} {return [expr {$state($w,model) in {exponential power_law gaussian components regions formula rational implicit complex_response registered}||($state($w,model) in {linear polynomial}&&$state($w,measurementKind) eq "sigma_xy")}]}
    if {$id eq "parameter_settings"} {return [expr {$state($w,activeSource) ne {}&&(($state($w,model) in {linear polynomial exponential power_law gaussian components regions formula rational registered fourier}&&$state($w,orientation) in {y_of_x x_of_y})||($state($w,model) in {circular_arc quadratic_bezier cubic_bezier parametric_polynomial}&&$state($w,orientation) eq "parametric")||($state($w,model) in {linear polynomial exponential power_law gaussian}&&$state($w,orientation) eq "r_of_theta"))}]}
    if {$id eq "registered_cancel"} {return [expr {[info exists state($w,registeredJob)]&&$state($w,registeredJob) ne {}}]}
    if {$id in {component_settings region_settings formula_settings rational_settings implicit_settings complex_settings registered_settings registered_declare}} {return [expr {$state($w,activeSource) ne {}&&$state($w,orientation) in {y_of_x x_of_y}}]}
    if {$id eq "covariance_settings"} {return [expr {$state($w,activeSource) ne {}&&$state($w,sourceKind) eq "dataset"&&$state($w,model) in {linear polynomial}&&$state($w,orientation) in {y_of_x x_of_y}}]}
    if {$id in {baseline_settings log_settings smooth_source}} {return [expr {$state($w,activeSource) ne {}&&$state($w,sourceKind) eq "dataset"&&$state($w,sourceTransformManifest) eq {}}]}
    if {$id eq {recompute_preview}} {return [expr {[$w.actions.preview cget -state] ne {disabled}}]}
    if {$id in {preview accept}} {return [expr {[$w.actions.$id cget -state] ne "disabled"}]}
    if {$id eq "workspace_clear_history"} {
        set record [::GX::scientificHistoryViewerSummary $w]
        return [expr {[dict get $record steps] ne {} && [dict get $record cursor]==[llength [dict get $record steps]]}]
    }
    if {$id in {workspace_duplicate workspace_rename workspace_delete workspace_clear_history}} {return [expr {$state($w,documentId) ne {}}]}
    dict for {name label} [_commandWidgets] {
        if {[string map {. _} $name] ne $id} continue
        set parts [split $name .];set widget [_widget $w [lindex $parts 0]].[join [lrange $parts 1 end] .]
        if {[$widget cget -state] eq "disabled"} {return 0}
        if {[string match workspace.actions.* $name] && $name ni {workspace.actions.reload workspace.actions.reverse workspace.actions.span}} {return [expr {[$w.left.viewport.content.sources.body.sources selection] ne {}}]}
        if {[string match accepted.* $name]} {return [expr {[$w.left.viewport.content.accepted.list curselection] ne {}}]}
        if {$name eq "filter.remove"} {return [expr {[$w.left.viewport.content.filters.list curselection] ne {}}]}
        if {[string match residualPager.* $name]} {return [expr {$state($w,preview) ne {}}]}
    }
    return 1
}
proc ::GX::DatasetCurveFit::_commandInvoke {w id} {
    if {$id eq {recompute_preview}} {return [_uiSafe $w [list ::GX::DatasetCurveFit::_uiPreview $w 1]]}
    if {$id in {undo redo previous next latest branch}} {return [::GX::scientificHistoryViewerNavigate $w $id]}
    if {$id eq "save"} {return [::GX::sessionWorkspaceViewerAction dataset_curve_fit [_workspaceCallbacks $w] $w save]}
    variable state
    if {$id eq "workspace_clear_history"} {return [::GX::scientificHistoryViewerClear $w $state($w,documentId)]}
    if {$id in {workspace_new workspace_open workspace_duplicate workspace_rename workspace_manager workspace_close workspace_delete}} {
        set callbacks [_workspaceCallbacks $w]
        return [::GX::sessionWorkspaceViewerAction dataset_curve_fit $callbacks $w [string range $id 10 end]]
    }
    switch $id {
        configuration {return [::GX::configurationModuleDialog viewer.dataset_curve_fit $w]}
        panels_reset {return [_panelsReset $w]}
        translation {return [_uiSafe $w [list ::GX::DatasetCurveFit::_translationSettings $w]]}
        statistics_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_statisticalSettings $w]]}
        smoothing_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_smoothingSettings $w]]}
        smoothing_details {return [_smoothingDetails $w]}
        solver_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_solverSettings $w]]}
        registered_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_registeredSettings $w]]}
        registered_declare {return [_uiSafe $w [list ::GX::DatasetCurveFit::_registeredDeclareDialog $w]]}
        registered_cancel {return [_uiSafe $w [list ::GX::DatasetCurveFit::_registeredCancel $w]]}
        component_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_componentSettings $w]]}
        knot_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_knotSettings $w]]}
        rational_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_rationalSettings $w]]}
        implicit_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_implicitSettings $w]]}
        complex_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_complexSettings $w]]}
        surface_workflow {return [_uiSafe $w [list ::GX::DatasetCurveFit::openSurface]]}
        formula_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_formulaSettings $w]]}
        parameter_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_parameterSettings $w]]}
        region_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_regionSettings $w]]}
        log_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_logSettings $w]]}
        log_publish {return [_uiSafe $w [list ::GX::DatasetCurveFit::_logPublishDialog $w]]}
        log_details {return [_logDetails $w]}
        smooth_source {return [_uiSafe $w [list ::GX::DatasetCurveFit::_smoothSettings $w]]}
        baseline_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_baselineSettings $w]]}
        residual_source {return [_uiSafe $w [list ::GX::DatasetCurveFit::_residualAxis $w source]]}
        residual_predicted {return [_uiSafe $w [list ::GX::DatasetCurveFit::_residualAxis $w predicted]]}
        parameter_correlation {return [_correlationWindow $w]}
        solver_details {return [_solverDetails $w]}
        residual_sequence {return [_sequenceDetails $w]}
        influence_details {return [_influenceDetails $w]}
        bootstrap_details {return [_bootstrapDetails $w]}
        profile_details {return [_profileDetails $w]}
        profile_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_profileSettings $w]]}
        bootstrap_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_bootstrapSettings $w]]}
        prediction_details {return [_predictionDetails $w]}
        scientific_report {return [_scientificReportDetails $w]}
        model_card {return [_modelCardDetails $w]}
        covariance_settings {return [_uiSafe $w [list ::GX::DatasetCurveFit::_covarianceSettings $w]]}
        covariance_details {return [_uiSafe $w [list ::GX::DatasetCurveFit::_covarianceDetails $w]]}
        measurement_details {return [_measurementDetails $w]}
        parameter_dataset {return [_uiSafe $w [list ::GX::DatasetCurveFit::_parameterDatasetDialog $w]]}
        family_sources {return [_uiSafe $w [list ::GX::DatasetCurveFit::_familyDialog $w]]}
        global_family {return [_uiSafe $w [list ::GX::DatasetCurveFit::_globalFamilyDialog $w]]}
        global_family_results {return [_globalResults $w]}
        model_comparison {return [_comparisonWindow $w]}
        retained_query {return [_uiSafe $w [list ::GX::DatasetCurveFit::_queryOpen $w]]}
        model_suggestions {return [_uiSafe $w [list ::GX::DatasetCurveFit::_suggestionOpen $w]]}
        physical_plausibility {return [_uiSafe $w [list ::GX::DatasetCurveFit::_plausibilityOpen $w]]}
        derived_properties {return [_uiSafe $w [list ::GX::DatasetCurveFit::_derivedOpen $w]]}
        model_workbench {return [_uiSafe $w [list ::GX::DatasetCurveFit::_workbenchTransfer $w]]}
        model_export {return [_uiSafe $w [list ::GX::DatasetCurveFit::_modelExport $w]]}
        recipe_python {return [_uiSafe $w [list ::GX::DatasetCurveFit::_recipeExport $w Python]]}
        recipe_octave {return [_uiSafe $w [list ::GX::DatasetCurveFit::_recipeExport $w Octave]]}
        template_save {return [_uiSafe $w [list ::GX::DatasetCurveFit::_templateSaveDialog $w]]}
        template_apply {return [_uiSafe $w [list ::GX::DatasetCurveFit::_templateDialog $w]]}
        timeline {return [::GX::scientificHistoryViewerStripSet $w {mode History visible 1}]}
        strip {return [::GX::scientificHistoryViewerStripToggle $w]}
        history_details {return [::GX::scientificHistoryViewerDetails $w]}
        source_activate {return [_uiSafe $w [list ::GX::DatasetCurveFit::_workspaceSelect $w]]}
    }
    if {[string match selection_* $id] && $id in {selection_replace selection_add selection_subtract}} {set state($w,rectMode) [string totitle [string range $id 10 end]];return}
    if {$id in {preview accept}} {return [$w.actions.$id invoke]}
    dict for {name label} [_commandWidgets] {
        if {[string map {. _} $name] ne $id} continue
        set parts [split $name .];set widget [_widget $w [lindex $parts 0]].[join [lrange $parts 1 end] .]
        return [$widget invoke]
    }
}
proc ::GX::DatasetCurveFit::_commandsAttach {w} {
    set handlers {}
    dict for {id entry} [::GX::viewerCommandCatalog viewer.dataset_curve_fit] {
        dict set handlers $id [dict create command [list ::GX::DatasetCurveFit::_commandInvoke $w $id] enabled [list ::GX::DatasetCurveFit::_commandEnabled $w $id]]
    }
    ::GX::viewerCommandsAttach $w viewer.dataset_curve_fit $handlers
}
