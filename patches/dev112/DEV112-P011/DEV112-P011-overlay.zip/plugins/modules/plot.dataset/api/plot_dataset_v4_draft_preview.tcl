# SPDX-License-Identifier: GPL-3.0-or-later
# Public trusted-host draft adapter for the original Native3D preview host.
# It creates no Graph, Variant, Dataset, Document or alternative renderer.
proc ::GX::PlotDatasetAPIv4::previewSpecSource {spec} {
    _ready;validateSpec $spec
    if {[_get $spec graph_type cartesian_2d] ne {cartesian_3d}} {error {The Native3D draft host requires a genuine cartesian_3d PlotSpec}}
    set id [dict get $spec dataset_id]
    set identity [::GX::curveSourceDatasetIdentity $::GX::currentSession $id]
    set coordinates [::GX::datasetCoordinateRead $::GX::currentSession $id]
    set bindings {}
    foreach role {x y z family color} {
        if {[dict exists $spec ${role}_variable_id] && [dict get $spec ${role}_variable_id] ne {}} {
            dict set bindings $role [dict create dataset_id $id variable_id [dict get $spec ${role}_variable_id]]
        }
    }
    set key [list [::GX::interactiveDocumentSessionToken] PLOT_DATASET_API_v4 draft $spec $identity $coordinates]
    return [dict create renderer_owner PLOT_DATASET_API_v4 source_key $key \
        source_info [dict create source_dataset_id $id draft 1 source_identity $identity bindings $bindings \
            plot_ref [dict create kind draft module_id plot.dataset graph_id plot.dataset.xyz variant_id {}] \
            fingerprint [::GX::datasetStorageSha256Text $::GX::currentSession [list $spec $identity $coordinates]]] spec $spec]
}
proc ::GX::PlotDatasetAPIv4::_previewSpecKey {spec} {dict get [previewSpecSource $spec] source_key}
proc ::GX::PlotDatasetAPIv4::previewSpecExportCommand {spec directory} {
    variable apiDir
    previewSpecSource $spec
    set spec [_3dCapturedSpec $spec]
    if {[string bytelength $spec]>8388608} {error {Native draft exceeds the existing 8 MiB scene intake budget}}
    file mkdir $directory
    set channel [file tempfile snapshot [file join $directory .native_v4_draft_XXXXXX]]
    try {fconfigure $channel -encoding utf-8 -translation lf;puts -nonewline $channel $spec} finally {close $channel}
    # The original worker supports a pinned immutable spec without a persistent
    # reference. The reference below supplies only its graph-kind check.
    return [list [auto_execok tclsh] [file join [file dirname $apiDir] runtime native_v4_preview.tcl] \
        $::GX::scriptDir $::GX::currentSession [dict create graph_id plot.dataset.xyz] \
        $directory $snapshot [::GX::sha256File $snapshot] {} {}]
}
proc ::GX::PlotDatasetAPIv4::previewSpecScene {spec expected directory} {
    set source [previewSpecSource $spec]
    if {[dict get $source source_key] ne $expected} {error {Draft source changed during Native3D preparation; render the draft again}}
    set path [file join $directory scene.tcldict]
    if {![file isfile $path] || [file type $path] ne {file} || [file size $path]>8388608} {error {Prepared native draft descriptor is missing or exceeds the intake budget}}
    set channel [open $path r]
    try {fconfigure $channel -encoding utf-8;set descriptor [read $channel 8388609]} finally {close $channel}
    if {[string bytelength $descriptor]>8388608} {error {Prepared native draft descriptor exceeds the intake budget}}
    foreach key {layers view caption scientific_figure presentation} {if {![dict exists $descriptor $key]} {error "Prepared native draft lacks $key"}}
    _consultationLayers [dict get $descriptor layers] $directory
    dict set descriptor renderer_owner PLOT_DATASET_API_v4
    dict set descriptor source_key $expected
    dict set descriptor source_info [dict get $source source_info]
    return $descriptor
}
proc ::GX::PlotDatasetAPIv4::_previewSpecPrepare {spec w} {
    variable ::GX::DatasetViewer::state
    ::GX::datasetViewerCheck $w
    set source [previewSpecSource $spec]
    set state($w,sourceInfo) [dict get $source source_info]
    set state($w,plotV4SourceKey) [dict get $source source_key]
    set state($w,plotV4SourceReceipt) $source
    set command [previewSpecExportCommand $spec $state($w,temp)]
    set state($w,prepareLog) {}
    if {[auto_execok prlimit] ne {}} {set command [concat [list [auto_execok prlimit] --as=[expr {[::GX::configurationGet viewers.native3d.worker_address_space_budget_mib]*1024*1024}] --] $command]}
    if {[auto_execok setsid] ne {}} {set command [concat [list [auto_execok setsid]] $command];set state($w,prepareGroup) 1}
    set state($w,preparePipe) [open [concat [list |] $command [list 2>@1]] r]
    fconfigure $state($w,preparePipe) -blocking 0 -buffering line
    fileevent $state($w,preparePipe) readable [list ::GX::native3DPreviewPrepared $w]
}
proc ::GX::PlotDatasetAPIv4::previewSpecAcquire {parent spec {options {}}} {
    foreach key [dict keys $options] {if {$key ne {controls_visible}} {error {Unknown Native3D draft host option}}}
    if {[dict exists $options controls_visible] && ![string is boolean -strict [dict get $options controls_visible]]} {error {Camera control visibility must be boolean}}
    set source [previewSpecSource $spec];set key [dict get $source source_key]
    return [::GX::native3DPreviewAcquire $parent [dict get $spec dataset_id] $key \
        [list ::GX::PlotDatasetAPIv4::_previewSpecKey $spec] \
        [list ::GX::PlotDatasetAPIv4::_previewSpecPrepare $spec] \
        [dict merge $options [dict create prepared_scene [list ::GX::PlotDatasetAPIv4::previewSpecScene $spec $key]]]]
}
proc ::GX::PlotDatasetAPIv4::previewSpecReceipt {host} {
    variable ::GX::DatasetViewer::state
    ::GX::datasetViewerCheck $host
    if {![info exists state($host,preparedScene)]} {error {This host is not a Plot v4 draft}}
    set receipt [dict create renderer_owner PLOT_DATASET_API_v4 draft 1 ready $state($host,ready) busy $state($host,busy) \
        pending [llength $state($host,pending)] source_key $state($host,sourceKey)]
    foreach {field key} {lastReceipt render_receipt view view plotV4Receipt preparation_receipt scientificFigure scientific_figure status status} {
        if {[info exists state($host,$field)]} {dict set receipt $key $state($host,$field)}
    }
    dict set receipt controls_visible $state($host,controlsVisible)
    return $receipt
}
proc ::GX::PlotDatasetAPIv4::previewSpecControls {host visible} {previewSpecReceipt $host;::GX::native3DPreviewSetControls $host $visible}
proc ::GX::PlotDatasetAPIv4::previewSpecCamera {host action} {
    previewSpecReceipt $host
    if {$action ni {left right up down cw ccw fit reset}} {error {Unknown native camera action}}
    ::GX::native3DPreviewCamera $host $action
}
proc ::GX::PlotDatasetAPIv4::previewSpecRelease {parent} {::GX::native3DPreviewRelease $parent}
