# SPDX-License-Identifier: GPL-3.0-or-later
# The installed viewer.curve_viewer identity now hosts Plot v4 drafts.
# CURVE_VIEWER_API_v1 source addition/open adapters remain explicitly documented;
# CURVE_VIEWER_API_v2 owns the versioned Plot workbench receipt contract.
namespace eval ::GX::CurveViewer {variable apiDir [file dirname [file normalize [info script]]];variable version 2.0.0}
foreach file {plot_viewer_v2.tcl plot_viewer_inspector_v2.tcl plot_viewer_structure_v2.tcl plot_viewer_lifecycle_v2.tcl plot_viewer_advanced_v2.tcl curve_viewer_settings.tcl} {
    source [file join $::GX::CurveViewer::apiDir $file]
}
proc ::GX::CurveViewer::apiInfo {} {
    return [dict create api_id CURVE_VIEWER_API_v2 api_version 2 renderer_owner PLOT_DATASET_API_v4 \
        compatibility_api CURVE_VIEWER_API_v1 workspace_versions {1 2} legacy_policy readonly_then_explicit_new_workspace \
        operations {open viewerDispatch plotDatasetIds add nativeReceipt publishPlot workspaceSave} \
        publication {explicit persistent_graph_variant} workspace_save {separate_from_plot_publication}]
}
proc ::GX::CurveViewer::publishPlot {w mode {title auto}} {return [::GX::CurveViewer::_publishApply $w [dict create mode $mode title $title]]}
proc ::GX::CurveViewer::workspaceSave {w} {::GX::CurveViewer::_workspaceSaveCommand $w}
