# SPDX-License-Identifier: GPL-3.0-or-later
# Retained source path for exact incremental installation compatibility.
# The retired private renderer is replaced by the versioned Plot v4 host in
# curve_viewer_api_v1.tcl and plot_viewer_v2.tcl. This file is intentionally inert.
