# SPDX-License-Identifier: GPL-3.0-or-later
# Typed GUI draft persistence; CORE continues to own PlotSpecs and Documents.
::GX::nativeWorkspaceShapeRegister curve_viewer_xyz_spec {named plot_xyz_spec}
proc ::GX::CurveViewer::_specEncode {spec} {
    set shape [expr {[::GX::datasetPublicationV2DictDefault $spec graph_type cartesian_2d] eq {cartesian_3d} ? {curve_viewer_xyz_spec} : {plot_spec}}]
    return [::GX::nativeWorkspaceEncode [list named $shape] $spec]
}
proc ::GX::CurveViewer::_specDecode {typed} {
    set fields [lindex $typed 1]
    set dimension [expr {[dict exists $fields graph_type] ? [lindex [dict get $fields graph_type] 1] : {cartesian_2d}}]
    return [::GX::nativeWorkspaceShapeDecode [list named [expr {$dimension eq {cartesian_3d} ? {curve_viewer_xyz_spec} : {plot_spec}}]] $typed]
}
::GX::nativeWorkspaceCodecDecodeRegister ::GX::CurveViewer::_specEncode ::GX::CurveViewer::_specDecode
::GX::nativeWorkspaceShapeRegister curve_viewer_plot_v2 {record {
    version int draft {codec ::GX::CurveViewer::_specEncode} published_ref {map text}
    source_pins {array {record {dataset_id text sha256 text schema_identity text}}}
    next int layout {record {sources_visible bool inspector_visible bool left_sash int right_sash int}}
    view_axes {array {record {panel_id text axis text limits {array real} scale text direction text}}}
}}
proc ::GX::CurveViewer::workspaceEncode {payload} {
    set shape [expr {[dict get $payload version]==1 ? {curve_viewer} : {curve_viewer_plot_v2}}]
    tailcall ::GX::nativeWorkspaceShapePayloadEncode [dict get $::GX::WorkspaceScientificCodec::shapes $shape] $payload
}
proc ::GX::CurveViewer::workspaceDecode {typed} {
    set version [lindex [dict get [lindex $typed 1] version] 1]
    set shape [expr {$version==1 ? {curve_viewer} : {curve_viewer_plot_v2}}]
    tailcall ::GX::nativeWorkspaceShapeDecode [dict get $::GX::WorkspaceScientificCodec::shapes $shape] $typed
}
proc ::GX::CurveViewer::workspaceValidate {payload} {
    if {![dict exists $payload version]} {error {Curve Viewer Workspace needs its format version}}
    switch [dict get $payload version] {
        1 {foreach key {records next presentation view_requested} {if {![dict exists $payload $key]} {error "Legacy Curve Viewer Workspace requires $key"}}}
        2 {foreach key {draft published_ref source_pins next layout view_axes} {if {![dict exists $payload $key]} {error "Plot Viewer Workspace requires $key"}}}
        default {error {Unsupported Curve Viewer Workspace version}}
    }
    return 1
}
