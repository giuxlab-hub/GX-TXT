# SPDX-License-Identifier: GPL-3.0-or-later
# Curve Viewer owns GUI drafts. Plot v4 owns admission, drawing and publication.
namespace eval ::GX::CurveViewer {variable st;variable nextWindow 0}
proc ::GX::CurveViewer::_get {value key default} {::GX::datasetPublicationV2DictDefault $value $key $default}
proc ::GX::CurveViewer::_ready {} {::GX::modulePublicApiActivate plot.dataset PLOT_DATASET_API_v4}
proc ::GX::CurveViewer::_scope {w} {
    variable st
    if {![info exists st($w,session)] || $st($w,session) ne [::GX::interactiveDocumentSessionToken]} {error {Session changed; reopen Curve Viewer in the intended Session}}
}
proc ::GX::CurveViewer::_safe {w command} {
    variable st
    if {[catch {_scope $w;uplevel #0 $command} message options]} {
        set st($w,status) $message
        if {[winfo exists $w]} {tk_messageBox -parent $w -title {Curve Viewer} -icon error -message $message}
        return
    }
}
proc ::GX::CurveViewer::plotDatasetIds {} {
    set result {}
    foreach id [::GX::datasetRegistryIds] {
        foreach variable [::GX::datasetVariableSchemaV3 $id] {
            if {[dict get $variable enabled] && [dict get $variable dtype] ne {string} && [dict get $variable rank] in {1 2}} {lappend result $id;break}
        }
    }
    return $result
}
# Preserve the v1 Script Bridge discovery heuristic exactly. The v2 GUI uses
# plotDatasetIds and performs enabled/rank/dtype admission through Plot v4.
proc ::GX::CurveViewer::datasetIds {} {
    set result {}
    foreach id [::GX::datasetRegistryIds] {
        set n 0
        foreach v [::GX::datasetVariableSchemaV3 $id] {if {[dict get $v rank]==1&&[dict get $v dtype] ne {string}} {incr n}}
        if {$n>=2} {lappend result $id}
    }
    return $result
}
proc ::GX::CurveViewer::_variables {dataset {text 0} {ranks {1 2}}} {
    set result {}
    foreach variable [::GX::datasetVariableSchemaV3 $dataset] {
        if {![dict get $variable enabled] || [dict get $variable rank] ni $ranks} continue
        if {!$text && [dict get $variable dtype] eq {string}} continue
        lappend result [dict get $variable variable_id]
    }
    return $result
}
proc ::GX::CurveViewer::_blank {dimension} {
    if {$dimension eq {3D}} {return [dict create schema PLOT_DATASET_PLOTSPEC_v2 graph_type cartesian_3d graph_id plot.dataset.xyz title auto config {plot_type scatter3}]}
    return [::GX::PlotDatasetAPIv4::newSpec -title auto]
}
proc ::GX::CurveViewer::_dimension {w} {variable st;expr {[_get $st($w,spec) graph_type cartesian_2d] eq {cartesian_3d} ? {3D} : {2D}}}
proc ::GX::CurveViewer::_pins {spec} {
    set ids {}
    if {[_get $spec graph_type cartesian_2d] eq {cartesian_3d}} {
        if {[dict exists $spec dataset_id]} {lappend ids [dict get $spec dataset_id]}
    } else {
        foreach panel [dict get $spec panels] {
            foreach series [dict get $panel series] {
                lappend ids [dict get $series dataset_id]
                if {[dict exists $series cell_field]} {lappend ids [dict get $series cell_field nodes_dataset_id]}
            }
        }
    }
    if {[dict exists $spec comparison]} {
        foreach source [dict get $spec comparison sources] {if {[dict get $source kind] eq {dataset}} {lappend ids [dict get $source dataset_id]}}
    }
    set result {}
    foreach id [lsort -unique $ids] {lappend result [::GX::curveSourceDatasetIdentity $::GX::currentSession $id]}
    return $result
}
proc ::GX::CurveViewer::_refreshTree {w} {
    variable st
    set tree $w.body.sources.tree;set selection [$tree selection]
    $tree delete [$tree children {}]
    $tree insert {} end -id plot -text "[_dimension $w] Plot draft" -open 1
    if {[_dimension $w] eq {3D}} {
        $tree insert plot end -id scene -text "[dict get $st($w,spec) config plot_type] · [_get $st($w,spec) dataset_id {Choose Dataset}]" -open 1
        foreach axis {x y z} {$tree insert scene end -id axis:$axis -text "[string toupper $axis] axis"}
    } else {
        set pi 0
        foreach panel [dict get $st($w,spec) panels] {
            set pid [dict get $panel id]
            $tree insert plot end -id panel:$pi -text "Panel: $pid" -open 1
            foreach axis {x y_left y_right} {$tree insert panel:$pi end -id axis:$pi:$axis -text "[string map {_ { }} $axis] axis"}
            set si 0
            foreach series [dict get $panel series] {
                set label [_get $series label [dict get $series id]]
                $tree insert panel:$pi end -id series:$pi:$si -text "[expr {[_get $series enabled 1] ? {●} : {○}}] $label" -values [list [dict get $series dataset_id] [_get $series kind auto]]
                incr si
            }
            set ai 0
            foreach annotation [_get $panel annotations {}] {$tree insert panel:$pi end -id annotation:$pi:$ai -text "Annotation: [dict get $annotation type]";incr ai}
            incr pi
        }
    }
    if {[llength $selection] && [$tree exists [lindex $selection 0]]} {$tree selection set [lindex $selection 0]} else {$tree selection set plot}
    _inspect $w
    if {[dict exists $::GX::ViewerCommands::windows $w]} {::GX::viewerCommandWidgetsRefresh $w}
    set ref $st($w,published)
    set st($w,identity) [expr {$ref eq {} ? {Unpublished draft · Save Workspace and Publish Plot are separate actions} : "Draft of [dict get $ref graph_id] / [expr {[dict get $ref variant_id] eq {} ? {base} : [dict get $ref variant_id]}] · [expr {$st($w,dirty) ? {unpublished edits} : {published}}]"}]
}
proc ::GX::CurveViewer::_selection {w} {
    set selected [$w.body.sources.tree selection]
    return [expr {$selected eq {} ? {plot} : [lindex $selected 0]}]
}
proc ::GX::CurveViewer::_inspect {w} {
    variable st
    set selected [_selection $w]
    set st($w,inspection) "Selected: $selected\n[expr {$st($w,published) eq {} ? {The canvas is an unpublished draft.} : {Edit this draft, then explicitly Publish or Update.}}]"
    set type [lindex [split $selected :] 0]
    set visible [expr {$type eq {series} ? {series style uncertainty distribution filters advanced} : $type eq {axis} ? {axis graphics layout advanced} : $type eq {panel} ? {source panel annotation graphics legend layout advanced} : $type eq {annotation} ? {annotation advanced} : [_dimension $w] eq {3D} ? {plot source scene camera graphics legend layout advanced} : {plot source panel graphics legend layout field advanced}}]
    set parent $w.body.inspector.viewport.content
    foreach button {plot source series axis panel annotation style uncertainty distribution filters scene graphics legend layout camera field advanced} {
        if {![winfo exists $parent.$button]} continue
        pack forget $parent.$button
        if {$button ni $visible} continue
        set active 1
        if {$button in {series style uncertainty distribution filters} && ![string match series:* $selected]} {set active 0}
        if {$button in {panel annotation} && [_dimension $w] eq {3D}} {set active 0}
        if {$button eq {axis} && ![string match axis:* $selected]} {set active 0}
        if {$button in {scene camera} && [_dimension $w] ne {3D}} {set active 0}
        $parent.$button configure -state [expr {$active ? {normal} : {disabled}}]
        pack $parent.$button -fill x -pady 3
    }
}
proc ::GX::CurveViewer::_cameraCapture {w spec} {
    variable st
    if {[info exists st($w,pendingHost)]} {error {Wait for Native3D preparation, or cancel it before saving or publishing}}
    if {![info exists st($w,host)] || $st($w,host) eq {}} {return $spec}
    set receipt [::GX::PlotDatasetAPIv4::previewSpecReceipt $st($w,host)]
    if {![dict get $receipt ready] || [dict get $receipt busy] || [dict get $receipt pending]} {error {Wait for the current Native3D camera frame before saving or publishing}}
    set camera {}
    foreach key {camera_position camera_target camera_up projection orthographic_height near_clip far_clip vertical_fov_degrees} {
        if {[dict exists $receipt view $key]} {dict set camera $key [dict get $receipt view $key]}
    }
    dict set spec native_presentation schema GXTXT_NATIVE_GRAPH_PRESENTATION_v1
    dict set spec native_presentation camera [::GX::viewerCameraValidate $camera]
    return $spec
}
proc ::GX::CurveViewer::_render {w {spec {}} {preserveView 0}} {
    variable st
    _scope $w;_ready
    if {$spec eq {}} {set spec $st($w,spec)}
    ::GX::PlotDatasetAPIv4::validateSpec $spec
    set parent $w.body.view
    if {[_get $spec graph_type cartesian_2d] eq {cartesian_3d}} {
        _pendingCancel $w
        set stage $parent.stage[incr st($w,stageSerial)]
        ttk::frame $stage
        place $stage -relwidth 1 -relheight 1
        lower $stage
        set st($w,pendingParent) $stage
        set st($w,pendingSpec) $spec
        if {[catch {set st($w,pendingHost) [::GX::PlotDatasetAPIv4::previewSpecAcquire $stage $spec {controls_visible 0}]} message options]} {
            _pendingCancel $w
            return -options $options $message
        }
        set st($w,status) {Preparing Native3D. The previous accepted draft remains available until the new frame succeeds.}
        _poll3D $w
    } else {
        _pendingCancel $w
        set existing [winfo exists $parent.native2d]
        if {$existing} {
            set priorAxes [dict get [::GX::PlotDatasetAPIv4::widgetReceipt $parent.native2d] axes]
            ::GX::PlotDatasetAPIv4::widgetConfigure $parent.native2d $spec
        } else {
            ::GX::PlotDatasetAPIv4::widgetCreate $parent.native2d $spec
            pack forget $parent.placeholder
            pack $parent.native2d -fill both -expand 1
            bind $parent.native2d <Button-1> [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_hit $w %x %y]]
            bind $parent.native2d <Motion> [list ::GX::CurveViewer::_pointer $w %x %y]
        }
        # Native layout admission needs the mapped canvas size, especially for
        # an inside legend. A newly packed child initially reports one pixel.
        update idletasks
        _scope $w
        if {$existing && $preserveView} {::GX::PlotDatasetAPIv4::widgetView $parent.native2d restore $priorAxes}
        if {[catch {::GX::PlotDatasetAPIv4::widgetDraw $parent.native2d} message options]} {
            if {$existing} {
                if {[catch {
                    ::GX::PlotDatasetAPIv4::widgetConfigure $parent.native2d $st($w,acceptedSpec)
                    ::GX::PlotDatasetAPIv4::widgetView $parent.native2d restore $priorAxes
                    ::GX::PlotDatasetAPIv4::widgetDraw $parent.native2d
                } recovery]} {
                    catch {::GX::PlotDatasetAPIv4::widgetRetain $parent.native2d $message}
                    append message "\nThe prior frame is retained; restoring its controller failed: $recovery. Reopen the saved Workspace before retrying."
                }
            } else {
                ::GX::PlotDatasetAPIv4::widgetDestroy $parent.native2d
                destroy $parent.native2d
                if {$st($w,host) eq {}} {pack $parent.placeholder -fill both -expand 1}
            }
            return -options $options $message
        }
        if {$st($w,host) ne {}} {::GX::PlotDatasetAPIv4::previewSpecRelease $st($w,hostParent);catch {destroy $st($w,hostParent)};set st($w,host) {};set st($w,hostParent) {}}
        set st($w,acceptedSpec) $spec
        after idle [list ::GX::CurveViewer::_paneResize $w]
        set st($w,status) {Native2D draft ready. Click a series or axis; middle drag pans; wheel zooms; double-click fits.}
    }
    if {[winfo exists $parent.placeholder]} {pack forget $parent.placeholder}
    return $spec
}
proc ::GX::CurveViewer::_pendingCancel {w} {
    variable st
    if {[info exists st($w,poll)]} {after cancel $st($w,poll);unset st($w,poll)}
    if {[info exists st($w,pendingParent)]} {
        ::GX::PlotDatasetAPIv4::previewSpecRelease $st($w,pendingParent)
        catch {destroy $st($w,pendingParent)}
    }
    foreach key {pendingParent pendingHost pendingSpec pendingDescription pendingPins} {unset -nocomplain st($w,$key)}
}
proc ::GX::CurveViewer::_poll3D {w} {
    variable st
    if {![winfo exists $w]} return
    if {[info exists st($w,poll)]} {after cancel $st($w,poll);unset st($w,poll)}
    if {[catch {_scope $w} reason]} {_pendingCancel $w;set st($w,status) $reason;return}
    set preparing [info exists st($w,pendingHost)]
    set host [expr {$preparing ? $st($w,pendingHost) : $st($w,host)}]
    if {$host eq {}} return
    if {[catch {set receipt [::GX::PlotDatasetAPIv4::previewSpecReceipt $host]} reason]} {
        if {$preparing} {
            set diagnostic $st($w,pendingParent).native3dError
            if {[winfo exists $diagnostic]} {set reason [$diagnostic cget -text]}
            _pendingCancel $w
            set st($w,spec) $st($w,acceptedSpec)
            _refreshTree $w
        }
        set st($w,status) "Native3D failed: $reason. The previous accepted draft is preserved."
        return
    }
    if {[dict get $receipt ready] && ![dict get $receipt busy] && ![dict get $receipt pending] && [dict exists $receipt render_receipt]} {
        if {$preparing} {
            if {$st($w,host) ne {}} {::GX::PlotDatasetAPIv4::previewSpecRelease $st($w,hostParent);catch {destroy $st($w,hostParent)}}
            set st($w,host) $host;set st($w,hostParent) $st($w,pendingParent)
            set st($w,spec) $st($w,pendingSpec);set st($w,acceptedSpec) $st($w,pendingSpec)
            raise $st($w,hostParent)
            if {[winfo exists $w.body.view.native2d]} {::GX::PlotDatasetAPIv4::widgetDestroy $w.body.view.native2d;destroy $w.body.view.native2d}
            set description [_get [array get st] $w,pendingDescription {}]
            if {[info exists st($w,pendingPins)]} {set st($w,pins) $st($w,pendingPins);set st($w,dirty) 1}
            foreach key {pendingParent pendingHost pendingSpec pendingDescription pendingPins} {unset -nocomplain st($w,$key)}
            _refreshTree $w
            if {$description ne {}} {_record $w $description}
        }
        set st($w,status) {Native3D draft ready. Orbit, pan, zoom and Fit use the CORE camera; Publish Plot creates a real Graph.}
        return
    }
    set st($w,status) [_get $receipt status {Preparing Native3D draft…}]
    set st($w,poll) [after 100 [list ::GX::CurveViewer::_poll3D $w]]
}
proc ::GX::CurveViewer::_setSpec {w spec description {sourceRebind 0} {preserveCamera 1} {preserveView 0}} {
    variable st
    _scope $w
    if {[dict exists $::GX::ScientificHistory::viewers $w] && ![::GX::scientificHistoryViewerPrepareEdit $w]} return
    if {$preserveCamera && [_get $spec graph_type cartesian_2d] eq {cartesian_3d} && $st($w,host) ne {} && [_get [_get $spec native_presentation {}] camera {}] eq [_get [_get $st($w,spec) native_presentation {}] camera {}]} {
        set spec [_cameraCapture $w $spec]
    }
    set pins [_pins $spec]
    if {!$sourceRebind} {
        foreach previous $st($w,pins) {
            foreach current $pins {
                if {[dict get $previous dataset_id] eq [dict get $current dataset_id] && $previous ne $current} {
                    error {A canonical source revision changed. Use Dataset and variables to explicitly rebind the current source before editing its presentation. The previous draft remains intact.}
                }
            }
        }
    }
    _render $w $spec $preserveView
    if {[info exists st($w,pendingHost)]} {
        set st($w,pendingDescription) $description;set st($w,pendingPins) $pins
        return
    }
    set st($w,spec) $spec;set st($w,pins) $pins;set st($w,dirty) 1
    _refreshTree $w
    _record $w $description
}
proc ::GX::CurveViewer::_new {w dimension} {
    variable st
    if {$st($w,dirty) && [tk_messageBox -parent $w -type okcancel -default cancel -icon warning -message {Replace the current local draft? Published Graphs remain intact. Save Workspace first to retain this draft.}] ne {ok}} return
    _pendingCancel $w
    if {$st($w,host) ne {}} {::GX::PlotDatasetAPIv4::previewSpecRelease $st($w,hostParent);catch {destroy $st($w,hostParent)};set st($w,host) {};set st($w,hostParent) {}}
    if {[winfo exists $w.body.view.native2d]} {::GX::PlotDatasetAPIv4::widgetDestroy $w.body.view.native2d;destroy $w.body.view.native2d}
    set st($w,spec) [_blank $dimension];set st($w,acceptedSpec) $st($w,spec);set st($w,pins) {};set st($w,published) {};set st($w,opened) 0;set st($w,dirty) 1
    pack $w.body.view.placeholder -fill both -expand 1
    set st($w,status) {Choose a Dataset to configure this unpublished Plot.}
    _refreshTree $w
    _record $w "New $dimension Plot draft"
}
proc ::GX::CurveViewer::_fit {w {reset 0}} {
    variable st
    if {[_dimension $w] eq {3D}} {
        if {$st($w,host) eq {}} {error {Render a valid XYZ source first}}
        ::GX::PlotDatasetAPIv4::previewSpecCamera $st($w,host) [expr {$reset ? {reset} : {fit}}]
        _poll3D $w
    } else {
        if {![winfo exists $w.body.view.native2d]} {error {Add a valid source series first}}
        ::GX::PlotDatasetAPIv4::widgetView $w.body.view.native2d fit
    }
}
proc ::GX::CurveViewer::_pointSummary {hit} {
    set fields {}
    foreach key {series_id panel_id source_row source_row_ordinal point_index x y dataset_id} {
        if {[dict exists $hit $key]} {lappend fields "$key: [dict get $hit $key]"}
    }
    return [join $fields { · }]
}
proc ::GX::CurveViewer::_pointer {w x y} {
    variable st
    if {[catch {set receipt [::GX::PlotDatasetAPIv4::widgetHit $w.body.view.native2d $x $y]}]} return
    set st($w,coordinates) [_pointSummary $receipt]
}
proc ::GX::CurveViewer::_hit {w x y} {
    variable st
    set hit [::GX::PlotDatasetAPIv4::widgetHit $w.body.view.native2d $x $y]
    if {$hit eq {}} {
        set receipt [::GX::PlotDatasetAPIv4::widgetReceipt $w.body.view.native2d]
        foreach axis [dict get $receipt axes] {
            lassign [dict get $axis plot_rect] left top right bottom
            set side [dict get $axis axis]
            set match [expr {$side eq {x} ? ($x>=$left && $x<=$right && $y>=$bottom && $y<=$bottom+55) : $side eq {left} ? ($y>=$top && $y<=$bottom && $x>=$left-65 && $x<=$left) : ($y>=$top && $y<=$bottom && $x>=$right && $x<=$right+65)}]
            if {$match} {set hit [dict create panel_id [dict get $axis panel_id] axis $side];break}
        }
        if {$hit eq {}} return
    }
    set st($w,coordinates) [_pointSummary $hit]
    set sid [_get $hit series_id {}];set pid [_get $hit panel_id {}]
    set pi 0
    foreach panel [dict get $st($w,spec) panels] {
        set si 0
        foreach series [dict get $panel series] {
            if {$sid ne {} && [dict get $series id] eq $sid} {$w.body.sources.tree selection set series:$pi:$si;_inspect $w;return}
            incr si
        }
        if {$pid ne {} && [dict get $panel id] eq $pid && [_get $hit axis {}] ne {}} {
            set axis [_get {left y_left right y_right x x} [dict get $hit axis] x]
            $w.body.sources.tree selection set axis:$pi:$axis;_inspect $w;return
        }
        incr pi
    }
}
proc ::GX::CurveViewer::open {{context {}}} {
    variable st
    _ready
    if {$::GX::currentSession eq {} || ![file isdirectory $::GX::currentSession]} {error {Open a Session before opening Curve Viewer}}
    set w .curve_viewer
    if {[winfo exists $w]} {raise $w;return $w}
    toplevel $w;wm title $w {Curve Viewer — Plot v4};wm geometry $w [format {%dx%d} [expr {min(1366,[winfo screenwidth $w]-40)}] [expr {min(860,[winfo screenheight $w]-60)}]];wm minsize $w 760 520
    foreach {key value} {documentId {} documentRevision {} documentGeneration {} published {} pins {} opened 0 dirty 0 next 0 host {} hostParent {} stageSerial 0 sourcesVisible 1 inspectorVisible 1 inspectorLabels {} workspaceName {} status {Choose a Dataset to begin.} coordinates {}} {set st($w,$key) $value}
    set st($w,session) [::GX::interactiveDocumentSessionToken]
    set st($w,spec) [_blank 2D];set st($w,acceptedSpec) $st($w,spec)
    ttk::frame $w.toolbar -padding 5
    foreach {id label command} {
        new2d {New 2D} {_new 2D} new3d {New 3D} {_new 3D}
        open {Open Plot…} {_openDialog} source {Add source…} {_sourceDialog}
        save {Save Workspace} {_workspaceSaveCommand} publish {Publish Plot…} {_publishDialog}
        export {Export…} {_exportDialog} fit Fit {_fit} reset Reset {_fit 1}
    } {
        set callback [list ::GX::CurveViewer::[lindex $command 0] $w {*}[lrange $command 1 end]]
        ttk::button $w.toolbar.$id -text $label -command [list ::GX::CurveViewer::_safe $w $callback]
        pack $w.toolbar.$id -side left -padx 3 -pady 2
    }
    ttk::menubutton $w.toolbar.more -text Advanced -menu $w.toolbar.more.menu
    menu $w.toolbar.more.menu -tearoff 0
    foreach {label command} {{Toggle sources panel} {_panelToggle sources} {Toggle inspector} {_panelToggle inspector} {Open Workspace…} {_workspaceOpenDialog} {Session Workspaces…} {_workspaceManager} {Undo draft edit} {_navigate undo} {Redo draft edit} {_navigate redo} {History timeline…} {_timeline} {Clear draft History…} {_clearHistory} {Inspect selected Dataset…} {_datasetInspect} {Consult selected provider 3D Plot…} {_providerConsultation} {Inspect Workbench comparison…} {_workbenchComparison} {Toggle 3D camera controls} {_cameraControls} {Add row predicate…} {_filterPredicateDialog} {Compare source series…} {_comparisonDialog} {Independent 3D representations…} {_representationsDialog} {Capture scientific Clone…} {_captureClone} {Open scientific snapshot…} {_snapshotOpen} {Original Plot editor…} {_originalEditor} {Capability guide…} {_help}} {
        $w.toolbar.more.menu add command -label $label -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::[lindex $command 0] $w {*}[lrange $command 1 end]]]
    }
    pack $w.toolbar.more -side right -padx 3
    ::GX::uiMenuRowAttach $w.toolbar [pack slaves $w.toolbar]
    pack $w.toolbar -side top -fill x
    ttk::frame $w.footer -padding 5
    ttk::label $w.footer.identity -textvariable ::GX::CurveViewer::st($w,identity) -anchor w
    ttk::label $w.footer.status -textvariable ::GX::CurveViewer::st($w,status) -anchor w -wraplength 1100
    ttk::label $w.footer.coordinates -textvariable ::GX::CurveViewer::st($w,coordinates) -anchor w
    pack $w.footer.identity $w.footer.status $w.footer.coordinates -fill x
    bind $w.footer <Configure> [list ::GX::CurveViewer::_footerSize $w %w]
    pack $w.footer -side bottom -fill x
    ttk::panedwindow $w.body -orient horizontal
    ttk::frame $w.body.sources -width 205 -padding 5
    ttk::frame $w.body.view -width 700
    ttk::frame $w.body.inspector -width 245 -padding 8
    $w.body add $w.body.sources -weight 0;$w.body add $w.body.view -weight 1;$w.body add $w.body.inspector -weight 0
    ttk::label $w.body.sources.title -text {Plot · Panels · Series} -font TkHeadingFont
    ttk::treeview $w.body.sources.tree -show tree -selectmode browse -height 12
    ttk::scrollbar $w.body.sources.scroll -command [list $w.body.sources.tree yview]
    ttk::scrollbar $w.body.sources.horizontal -orient horizontal -command [list $w.body.sources.tree xview]
    $w.body.sources.tree configure -yscrollcommand [list $w.body.sources.scroll set] -xscrollcommand [list $w.body.sources.horizontal set]
    pack $w.body.sources.title -fill x -pady 5
    pack $w.body.sources.horizontal -side bottom -fill x
    pack $w.body.sources.scroll -side right -fill y;pack $w.body.sources.tree -fill both -expand 1
    bind $w.body.sources <Configure> [list ::GX::CurveViewer::_sourcesSize $w %w]
    ttk::frame $w.body.sources.actions
    ttk::button $w.body.sources.actions.add -text + -width 2 -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_sourceDialog $w]]
    ::GX::native2DViewportTooltip $w.body.sources.actions.add {Add canonical source}
    ttk::menubutton $w.body.sources.actions.more -text Edit -menu $w.body.sources.actions.menu
    menu $w.body.sources.actions.menu -tearoff 0 -postcommand [list ::GX::CurveViewer::_sourceActionsPost $w]
    set st($w,sourceActions) {}
    foreach {id label command} {remove {Remove selected draft element} {_removeSelected} up {Move selected element up} {_moveSelected -1} down {Move selected element down} {_moveSelected 1} show {Show selected series} {_showSelected 1} hide {Hide selected series} {_showSelected 0}} {
        $w.body.sources.actions.menu add command -label $label -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::[lindex $command 0] $w {*}[lrange $command 1 end]]]
        dict set st($w,sourceActions) $id [$w.body.sources.actions.menu index end]
    }
    pack $w.body.sources.actions.add $w.body.sources.actions.more -side left -padx 2
    pack $w.body.sources.actions -side bottom -fill x
    bind $w.body.sources.tree <<TreeviewSelect>> [list ::GX::CurveViewer::_inspect $w]
    ttk::label $w.body.view.placeholder -text {Choose a canonical Dataset to build an interactive Plot.} -anchor center
    pack $w.body.view.placeholder -fill both -expand 1
    canvas $w.body.inspector.viewport -highlightthickness 0 -width 230 -yscrollcommand [list $w.body.inspector.scroll set]
    ttk::scrollbar $w.body.inspector.scroll -command [list $w.body.inspector.viewport yview]
    ttk::frame $w.body.inspector.viewport.content -padding 5
    set inspector $w.body.inspector.viewport.content
    $w.body.inspector.viewport create window 0 0 -window $inspector -anchor nw -tags content
    bind $w.body.inspector.viewport <Configure> [list ::GX::CurveViewer::_inspectorSize $w %w]
    bind $inspector <Configure> [list $w.body.inspector.viewport configure -scrollregion [list 0 0 %w %h]]
    pack $w.body.inspector.scroll -side right -fill y
    pack $w.body.inspector.viewport -fill both -expand 1
    ttk::label $inspector.title -text {Inspector} -font TkHeadingFont
    ttk::label $inspector.context -textvariable ::GX::CurveViewer::st($w,inspection) -wraplength 210 -justify left
    pack $inspector.title $inspector.context -fill x -pady 5
    foreach {id label} {plot {Plot title…} source {Dataset and variables…} series {Series kind and identity…} style {Line, markers and color…} uncertainty {Error bars and bands…} distribution {Histogram / box options…} filters {Families, order and filters…} axis {Axis, units and bounds…} panel {Panels and shared X…} annotation {Annotations…} scene {3D kind and scalar…} graphics {Fonts and renderer settings…} legend {Legend and colorbar…} layout {Layout and numeric aspect…} camera {Native camera…} field {Exact cell field…} advanced {Advanced PlotSpec…}} {
        ttk::button $inspector.$id -text $label -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_edit $w $id]]
        dict set st($w,inspectorLabels) $id $label
        ::GX::native2DViewportTooltip $inspector.$id $label
        pack $inspector.$id -fill x -pady 2
    }
    ::GX::uiFieldScrollAreaAttach $w.body.inspector.viewport $inspector
    pack $w.body -fill both -expand 1
    bind $w.body <Configure> [list ::GX::CurveViewer::_paneResize $w]
    bind $w <Escape> [list ::GX::CurveViewer::_cancel $w]
    wm protocol $w WM_DELETE_WINDOW [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_close $w]]
    after idle [list ::GX::CurveViewer::_initialSashes $w]
    _restoreContext $w $context
    _refreshTree $w
    _historyAttach $w
    _commandsAttachV2 $w
    menu $w.toolbar.more.menu.workspaces -tearoff 0
    ::GX::sessionWorkspaceViewerMenu $w.toolbar.more.menu.workspaces curve_viewer [_workspaceCallbacks $w] $w
    $w.toolbar.more.menu add cascade -label {Workspace actions} -menu $w.toolbar.more.menu.workspaces
    ::GX::sessionWorkspaceViewerTitle $w {Curve Viewer — Plot v4} [list ::GX::CurveViewer::_currentWorkspace $w] [list set ::GX::CurveViewer::st($w,workspaceName)]
    return $w
}
proc ::GX::CurveViewer::_footerSize {w width} {
    if {$width<2 || ![winfo exists $w.footer]} return
    foreach field {identity status coordinates} {$w.footer.$field configure -width 1 -wraplength [expr {max(100,$width-12)}]}
}
proc ::GX::CurveViewer::_sourcesSize {w width} {
    if {$width<2 || ![winfo exists $w.body.sources.tree]} return
    $w.body.sources.title configure -wraplength [expr {max(70,$width-12)}]
    ::GX::uiFieldInspectionColumnsSchedule $w.body.sources.tree {recursive 1}
}
proc ::GX::CurveViewer::_sourceActionsPost {w} {
    variable st
    set kind [lindex [split [_selection $w] :] 0]
    dict for {id index} $st($w,sourceActions) {
        set enabled [_commandEnabledV2 $w $id]
        if {$id in {show hide}} {set enabled [expr {$enabled && [_dimension $w] eq {2D} && $kind eq {series}}]}
        if {$id in {up down}} {set enabled [expr {$enabled && $kind in {panel series}}]}
        if {$id eq {remove}} {set enabled [expr {$enabled && $kind in {panel series annotation}}]}
        $w.body.sources.actions.menu entryconfigure $index -state [expr {$enabled?{normal}:{disabled}}]
    }
}
proc ::GX::CurveViewer::_inspectorSize {w width} {
    variable st
    if {$width<2 || ![winfo exists $w.body.inspector.viewport]} return
    set viewport $w.body.inspector.viewport;set content $viewport.content
    $viewport itemconfigure content -width $width
    $content.context configure -width 1 -wraplength [expr {max(60,$width-12)}]
    set font [ttk::style lookup TButton -font]
    if {$font eq {}} {set font TkDefaultFont}
    dict for {id label} $st($w,inspectorLabels) {
        set wrapped [::GX::native2DCanvasTextWrap $label $font [expr {max(40,$width-30)}]]
        if {[$content.$id cget -text] ne $wrapped} {$content.$id configure -text $wrapped}
    }
}
proc ::GX::CurveViewer::viewerDispatch {action scene} {
    if {$action ni {open rerender}} {error {Unsupported Curve Viewer lifecycle action}}
    return [open [_get $scene open_context {}]]
}
::GX::viewerBackendRegister curve_viewer_tk ::GX::CurveViewer::viewerDispatch
