# SPDX-License-Identifier: GPL-3.0-or-later
# Shared GX-TXT command/shortcut ownership, including retained command aliases.
set ::GX::CurveViewer::plotCommands {}
foreach {id label} {
    provider_consultation {Consult selected provider 3D Plot…} workbench_comparison {Inspect Workbench comparison…} camera_controls {Toggle 3D camera controls}
    predicate {Add row predicate…} comparison {Compare source series…} representations {Independent native representations…}
    capture_clone {Capture scientific Clone…} snapshot_open {Open scientific snapshot…} original_editor {Edit published Plot in original editor…}
    new2d {New 2D Plot} new3d {New 3D Plot} openplot {Open Plot / Variant…}
    add {Add canonical source…} filters {Source filters…} preview {Inspect canonical Dataset}
    show {Show selected series} hide {Hide selected series} remove {Remove draft element}
    properties {Series style…} label {Series label and kind…} fit_selected {Fit Plot} fit_all {Fit Plot} reset {Reset native view}
    presentation {Renderer presentation…} configuration {Viewer Configuration…}
    export {Export native rendering…} publish {Publish Plot…} save {Save Workspace}
    undo Undo redo Redo previous {Previous History step} next {Next History step}
    latest {Return to latest} branch {Restart here…} timeline {History timeline…}
    workspace_new {New Workspace…} workspace_open {Open Workspace…} workspace_duplicate {Duplicate Workspace…}
    workspace_rename {Rename Workspace…} workspace_manager {Session Workspaces…} workspace_close {Close Workspace}
    workspace_delete {Delete Workspace…} clear_history {Clear draft History…} cancel {Cancel native preparation}
    strip {Show Description / History strip} history_details {Full status / History details…}
} {
    set key [::GX::datasetPublicationV2DictDefault {undo Ctrl+z redo Ctrl+Shift+z save Ctrl+s} $id {}]
    dict set ::GX::CurveViewer::plotCommands $id [dict create label $label default $key]
}
foreach section {plot source series axis panel annotation style uncertainty distribution filters scene graphics legend layout camera field advanced} {
    dict set ::GX::CurveViewer::plotCommands edit_$section [dict create label "Edit $section…" default {}]
}
::GX::viewerCommandCatalogRegister viewer.curve_viewer $::GX::CurveViewer::plotCommands modules.curve_viewer.shortcuts
proc ::GX::CurveViewer::_commandEnabledV2 {w id} {
    variable st
    if {[catch {_scope $w}]} {return [expr {$id in {workspace_close cancel}}]}
    if {[info exists st($w,pendingHost)] && $id ni {cancel workspace_close history_details}} {return 0}
    if {$id in {publish export fit_all fit_selected reset}} {return [expr {$st($w,pins) ne {}}]}
    if {$id eq {cancel}} {return [info exists st($w,pendingHost)]}
    if {$id in {undo redo previous next latest branch clear_history}} {
        if {![dict exists $::GX::ScientificHistory::viewers $w]} {return 0}
        set adapter [dict get $::GX::ScientificHistory::viewers $w];set record [::GX::scientificHistoryViewerSummary $w]
        set count [llength [dict get $record steps]];set cursor [dict get $record cursor]
        switch $id {
            undo {return [expr {![dict get $adapter browsing] && $cursor>0}]}
            redo {return [expr {![dict get $adapter browsing] && $cursor<$count}]}
            clear_history {return [expr {$count>0 && $cursor==$count && ![dict get $adapter browsing] && [::GX::scientificHistoryViewerEditable $w]}]}
            default {return [expr {$count>0}]}
        }
    }
    return 1
}
proc ::GX::CurveViewer::_commandsAttachV2 {w} {
    set handlers {}
    dict for {id descriptor} $::GX::CurveViewer::plotCommands {
        dict set handlers $id [dict create command [list ::GX::CurveViewer::_commandV2 $w $id] enabled [list ::GX::CurveViewer::_commandEnabledV2 $w $id]]
    }
    ::GX::viewerCommandsAttach $w viewer.curve_viewer $handlers
    set widgets {}
    foreach {widget id} {new2d new2d new3d new3d open openplot source add save save publish publish export export fit fit_all reset reset} {dict set widgets $id [list $w.toolbar.$widget]}
    ::GX::viewerCommandWidgetsAttach $w $widgets
}
proc ::GX::CurveViewer::_commandV2 {w id} {
    if {[string match edit_* $id]} {return [_safe $w [list ::GX::CurveViewer::_edit $w [string range $id 5 end]]]}
    if {$id in {undo redo previous next latest branch}} {return [_safe $w [list ::GX::CurveViewer::_navigate $w $id]]}
    if {[string match workspace_* $id]} {return [::GX::sessionWorkspaceViewerAction curve_viewer [_workspaceCallbacks $w] $w [string range $id 10 end]]}
    switch $id {
        provider_consultation {set command {_providerConsultation}} workbench_comparison {set command {_workbenchComparison}} camera_controls {set command {_cameraControls}}
        predicate {set command {_filterPredicateDialog}} comparison {set command {_comparisonDialog}}
        representations {set command {_representationsDialog}} capture_clone {set command {_captureClone}}
        snapshot_open {set command {_snapshotOpen}} original_editor {set command {_originalEditor}}
        new2d {set command {_new 2D}} new3d {set command {_new 3D}}
        openplot {set command {_openDialog}} add {set command {_sourceDialog}}
        save {set command {_workspaceSaveCommand}} publish {set command {_publishDialog}}
        export {set command {_exportDialog}} fit_all - fit_selected {set command {_fit}}
        reset {set command {_fit 1}} properties {set command {_edit style}}
        label {set command {_edit series}} filters {set command {_edit filters}}
        remove {set command {_removeSelected}} show {set command {_showSelected 1}} hide {set command {_showSelected 0}}
        presentation {set command {_presentationDialog graphics}} configuration {return [::GX::configurationModuleDialog viewer.curve_viewer $w]}
        clear_history {set command {_clearHistory}} cancel {set command {_cancel}}
        timeline {set command {_timeline}}
        history_details {return [::GX::scientificHistoryViewerDetails $w]}
        strip {return [::GX::scientificHistoryViewerStripToggle $w]}
        preview {set command {_datasetInspect}}
        default {error "Unknown Plot Viewer command '$id'"}
    }
    return [_safe $w [list ::GX::CurveViewer::[lindex $command 0] $w {*}[lrange $command 1 end]]]
}
proc ::GX::CurveViewer::_showSelected {w visible} {
    variable st
    _scope $w;_assertPins $w
    if {![::GX::scientificHistoryViewerPrepareEdit $w]} return
    lassign [_seriesLocation $w] pi si
    set spec $st($w,spec);set panels [dict get $spec panels];set panel [lindex $panels $pi];set series [dict get $panel series];set item [lindex $series $si]
    dict set item enabled $visible;lset series $si $item;dict set panel series $series;lset panels $pi $panel;dict set spec panels $panels
    if {[catch {
        ::GX::PlotDatasetAPIv4::widgetVisibility $w.body.view.native2d [dict get $panel id] [dict get $item id] $visible
        ::GX::PlotDatasetAPIv4::widgetDraw $w.body.view.native2d
    } message options]} {
        catch {::GX::PlotDatasetAPIv4::widgetVisibility $w.body.view.native2d [dict get $panel id] [dict get $item id] [expr {!$visible}]}
        catch {::GX::PlotDatasetAPIv4::widgetDraw $w.body.view.native2d}
        return -options $options $message
    }
    set st($w,spec) $spec;set st($w,acceptedSpec) $spec;set st($w,dirty) 1
    _refreshTree $w
    _record $w {Set retained series visibility}
}
proc ::GX::CurveViewer::_datasetInspect {w} {
    variable st
    if {[_dimension $w] eq {3D}} {set id [dict get $st($w,spec) dataset_id]} else {
        lassign [_seriesLocation $w] pi si;set id [dict get [lindex [dict get [lindex [dict get $st($w,spec) panels] $pi] series] $si] dataset_id]
    }
    ::GX::datasetViewerOpen $id
}
