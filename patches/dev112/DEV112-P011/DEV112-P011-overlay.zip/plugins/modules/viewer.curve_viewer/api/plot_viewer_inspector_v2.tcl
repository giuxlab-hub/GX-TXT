# SPDX-License-Identifier: GPL-3.0-or-later
# Progressive property forms use shared GX-TXT fields and public Plot admission.
proc ::GX::CurveViewer::_field {label {type string} {values {}}} {
    set field [dict create label $label type $type required 0]
    if {$type eq {choice}} {dict set field values $values}
    return $field
}
proc ::GX::CurveViewer::_form {w id title fields values apply {sections {}}} {
    variable st
    _scope $w
    ::GX::uiFieldFormCreate $w.$id $title $fields $values \
        [list ::GX::CurveViewer::_formApply $w $w.$id $st($w,spec) $apply] $w $sections
}
proc ::GX::CurveViewer::_formApply {w dialog expected apply values} {
    variable st
    _scope $w
    if {$st($w,spec) ne $expected || [info exists st($w,pendingHost)]} {error {The draft changed or is still preparing. Close this form and reopen the relevant inspector before applying.}}
    set result [uplevel #0 [list {*}$apply $values]]
    if {[winfo exists $dialog]} {destroy $dialog}
    return $result
}
proc ::GX::CurveViewer::_sourceDialog {w} {
    set ids [plotDatasetIds]
    if {$ids eq {}} {error {No published numeric Dataset is available. Publish or import a Dataset through the normal Session facilities first.}}
    set fields [dict create dataset [_field {Canonical Dataset ID} choice $ids]]
    _form $w chooseSource {Choose canonical Dataset} $fields [dict create dataset [lindex $ids 0]] [list ::GX::CurveViewer::_sourceChosen $w]
}
proc ::GX::CurveViewer::_sourceChosen {w values} {
    destroy $w.chooseSource
    _seriesDialog $w [dict get $values dataset]
}
proc ::GX::CurveViewer::_seriesLocation {w} {
    set parts [split [_selection $w] :]
    if {[lindex $parts 0] ne {series}} {error {Select one series in the source tree}}
    return [lrange $parts 1 2]
}
proc ::GX::CurveViewer::_panelIndex {w} {
    set parts [split [_selection $w] :]
    if {[lindex $parts 0] in {panel series axis} && [string is integer -strict [lindex $parts 1]]} {return [lindex $parts 1]}
    return 0
}
proc ::GX::CurveViewer::_seriesDialog {w dataset {location {}}} {
    variable st
    set ranks [expr {[_dimension $w] eq {3D} ? {1 2} : {1}}]
    set numeric [_variables $dataset 0 $ranks];set all [_variables $dataset 1 {1}]
    if {[llength $numeric]<2} {error {This Dataset needs at least two admitted numeric Variables}}
    set values [dict create dataset_id $dataset x_variable_id [lindex $numeric 0] y_variable_id [lindex $numeric 1] \
        z_variable_id [lindex $numeric 2] kind line axis left label $dataset enabled 1 family_variable_id {} color_variable_id {}]
    if {[_dimension $w] eq {3D}} {
        if {[llength $numeric]<3} {error {A genuine 3D Plot needs explicit X, Y and Z Variables}}
        if {[dict exists $st($w,spec) dataset_id]} {set values [dict merge $values $st($w,spec)];dict set values label [_get $st($w,spec) title $dataset]}
        dict set values kind [_get [_get $st($w,spec) config {}] plot_type scatter3]
    } elseif {$location ne {}} {
        lassign $location pi si
        set series [lindex [dict get [lindex [dict get $st($w,spec) panels] $pi] series] $si]
        set values [dict merge $values $series]
        foreach key {x_error y_error} {
            foreach field {mode variable_id lower_variable_id upper_variable_id} {if {[dict exists $series $key $field]} {dict set values ${key}_$field [dict get $series $key $field]}}
        }
        foreach key {band bar_bounds} {foreach field {lower_variable_id upper_variable_id} {if {[dict exists $series $key $field]} {dict set values ${key}_$field [dict get $series $key $field]}}}
    }
    set fields {}
    dict set fields dataset_id [dict merge [_field {Canonical Dataset ID} choice [list $dataset]] {section source}]
    foreach role {x y} {dict set fields ${role}_variable_id [dict merge [_field "[string toupper $role] Variable ID" choice $numeric] {section source}]}
    dict set fields label [dict merge [_field {Series label / Plot title}] {section plot}]
    if {[_dimension $w] eq {3D}} {
        dict set fields z_variable_id [dict merge [_field {Z Variable ID} choice $numeric] {section source}]
        dict set fields color_variable_id [dict merge [_field {Independent scalar C Variable (optional)} choice [linsert $numeric 0 {}]] {section source}]
        dict set fields family_variable_id [dict merge [_field {Family Variable (optional)} choice [linsert $all 0 {}]] {section source}]
        dict set fields kind [dict merge [_field {Native 3D kind} choice [dict get [::GX::PlotDatasetAPIv4::apiInfo] supported_3d_kinds]] {section plot}]
    } else {
        set kinds [dict get [::GX::PlotDatasetAPIv4::apiInfo] supported_2d_kinds]
        set kinds [lsearch -all -inline -not -exact $kinds cell_field]
        dict set fields kind [dict merge [_field {Series kind} choice $kinds] {section plot}]
        dict set fields axis [dict merge [_field {Y axis} choice {left right}] {section plot}]
        dict set fields enabled [dict merge [_field {Visible} boolean] {section plot}]
        dict set fields family_variable_id [dict merge [_field {Family Variable (optional)} choice [linsert $all 0 {}]] {section source}]
        foreach key {x_error y_error} {
            dict set fields ${key}_mode [dict merge [_field "[string toupper [string index $key 0]] uncertainty mode" choice {none symmetric asymmetric}] {section errors default none}]
            foreach field {variable_id lower_variable_id upper_variable_id} {dict set fields ${key}_$field [dict merge [_field "$key · $field" choice [linsert $numeric 0 {}]] {section errors}]}
        }
        foreach key {band bar_bounds} {foreach field {lower_variable_id upper_variable_id} {dict set fields ${key}_$field [dict merge [_field "$key · $field" choice [linsert $numeric 0 {}]] {section errors}]}}
    }
    _form $w series {Dataset bindings and scientific Plot kind} $fields $values [list ::GX::CurveViewer::_seriesApply $w $location] \
        [dict create source {Source and family} plot Plot errors {Errors and exact bounds}]
}
proc ::GX::CurveViewer::_seriesApply {w location values} {
    variable st
    _scope $w
    set spec $st($w,spec)
    if {[_dimension $w] eq {3D}} {
        foreach field {dataset_id x_variable_id y_variable_id z_variable_id family_variable_id color_variable_id} {
            if {[dict get $values $field] eq {}} {dict unset spec $field} else {dict set spec $field [dict get $values $field]}
        }
        dict set spec config plot_type [dict get $values kind]
        dict set spec title [dict get $values label]
    } else {
        set pi [_panelIndex $w];set si -1
        if {$location ne {}} {lassign $location pi si}
        set panels [dict get $spec panels];set panel [lindex $panels $pi];set series [dict get $panel series]
        if {$si>=0} {set item [lindex $series $si]} else {set item [dict create id series[incr st($w,next)]]}
        foreach field {dataset_id x_variable_id y_variable_id kind axis label enabled family_variable_id} {
            set value [dict get $values $field]
            if {$value eq {} && $field eq {family_variable_id}} {dict unset item $field} else {dict set item $field $value}
        }
        foreach key {x_error y_error} {
            set mode [_get $values ${key}_mode none]
            if {$mode eq {none}} {dict unset item $key} else {
                set error [dict create mode $mode]
                foreach field [expr {$mode eq {symmetric} ? {variable_id} : {lower_variable_id upper_variable_id}}] {dict set error $field [dict get $values ${key}_$field]}
                dict set item $key $error
            }
        }
        foreach key {band bar_bounds} {
            if {[_get $values ${key}_lower_variable_id {}] eq {} && [_get $values ${key}_upper_variable_id {}] eq {}} {dict unset item $key} else {
                dict set item $key [dict create lower_variable_id [dict get $values ${key}_lower_variable_id] upper_variable_id [dict get $values ${key}_upper_variable_id]]
            }
        }
        if {$si>=0} {lset series $si $item} else {lappend series $item}
        dict set panel series $series;lset panels $pi $panel;dict set spec panels $panels
    }
    _setSpec $w $spec {Edit canonical source and Plot kind} 1
}
proc ::GX::CurveViewer::_seriesSectionApply {w location section values} {
    variable st
    lassign $location pi si
    set spec $st($w,spec);set panels [dict get $spec panels];set panel [lindex $panels $pi];set series [dict get $panel series];set item [lindex $series $si]
    if {$section eq {style}} {set cleaned {};dict for {key value} $values {if {$value ne {}} {dict set cleaned $key $value}};dict set item style $cleaned} else {
        dict for {key value} $values {if {$value eq {}} {dict unset item $key} else {dict set item $key $value}}
    }
    lset series $si $item;dict set panel series $series;lset panels $pi $panel;dict set spec panels $panels
    _setSpec $w $spec "Edit series $section" 0 1 [expr {$section eq {style}}]
}
proc ::GX::CurveViewer::_edit {w section} {
    variable st
    _scope $w
    set spec $st($w,spec)
    if {$section eq {plot}} {return [_plotDialog $w]}
    if {$section eq {source}} {return [_sourceDialog $w]}
    if {$section eq {series}} {
        set location [_seriesLocation $w];lassign $location pi si
        return [_seriesDialog $w [dict get [lindex [dict get [lindex [dict get $spec panels] $pi] series] $si] dataset_id] $location]
    }
    if {$section eq {filters}} {return [_filtersDialog $w]}
    if {$section in {uncertainty}} {return [_edit $w series]}
    if {$section in {style distribution filters}} {
        set location [_seriesLocation $w];lassign $location pi si
        set series [lindex [dict get [lindex [dict get $spec panels] $pi] series] $si]
        set fields {};set values $series
        if {$section eq {style}} {
            set values [_get $series style {}]
            foreach {key label type choices} {
                color Color string {} line_style {Line style} choice {auto inherit solid dashed dotted dashdot none}
                marker Marker choice {auto inherit none circle square diamond triangle_up triangle_down plus x star}
                marker_fill {Marker fill} choice {auto inherit none full}
                line_width {Line width} string {} marker_size {Marker size} string {} opacity Opacity string {}
            } {dict set fields $key [_field $label $type $choices]}
        } elseif {$section eq {distribution}} {
            foreach {key label type choices default} {
                step_mode {Step convention} choice {{} pre post mid} {}
                bar_width {Bar width (blank/auto or scientific X units)} string {} {}
                bar_baseline {Bar baseline (blank/auto or scientific Y value)} string {} {}
                histogram_bins {Histogram bins (auto or 2–512)} string {} {}
                histogram_normalization {Histogram normalization} choice {{} count probability density} {}
                box_whisker_iqr {Whisker IQR multiplier} string {} {}
                box_show_outliers {Box outlier visibility} choice {{} 0 1} {}
            } {dict set fields $key [dict merge [_field $label $type $choices] [dict create default $default]]}
        } else {
            set ids [_variables [dict get $series dataset_id] 1]
            foreach key {family_variable_id secondary_variable_id ordering_variable_id} {dict set fields $key [_field [string map {_ { }} $key] choice [linsert $ids 0 {}]]}
            dict set fields family_label_prefix [_field {Family label prefix}]
            dict set fields source_row_ordinals [_field {Exact source row ordinals (Tcl list; blank means all)}]
            dict set fields source_row_continuity [_field {Break lines at gaps in original rows} boolean]
            dict set fields row_filters [_field {Validated exact filter records (advanced)}]
        }
        return [_form $w editSeries "Series $section" $fields $values [list ::GX::CurveViewer::_seriesSectionApply $w $location $section]]
    }
    switch $section {
        axis {return [_axisDialog $w]}
        panel {return [_panelDialog $w]}
        annotation {return [_annotationDialog $w]}
        scene {return [_sceneDialog $w]}
        camera {return [_cameraDialog $w]}
        field {return [_cellFieldDialog $w]}
        advanced {return [_advancedDialog $w]}
        default {return [_presentationDialog $w $section]}
    }
}
proc ::GX::CurveViewer::_axisDialog {w} {
    variable st
    set selection [split [_selection $w] :]
    if {[_dimension $w] eq {3D}} {set axis [lindex $selection end];set values [_get [_get $st($w,spec) axes {}] $axis {}];set pi -1} else {
        lassign [lrange $selection 1 end] pi axis
        if {![string is integer -strict $pi]} {set pi 0;set axis x}
        set values [_get [_get [lindex [dict get $st($w,spec) panels] $pi] axes {}] $axis {}]
    }
    set fields {}
    foreach {key label type choices} {label Label string {} display_unit {Display unit (source or compatible unit)} string {} scale Scale choice {{} auto linear log} direction Direction choice {{} auto normal reverse} min Minimum string {} max Maximum string {} major_step {Major step (blank = auto)} string {}} {dict set fields $key [_field $label $type $choices]}
    if {$axis eq {x}} {
        dict set fields tick_positions [_field {Exact custom X tick positions (semicolon-separated)}]
        dict set fields tick_labels [_field {Matching custom X labels (semicolon-separated)}]
        dict set fields minor_grid [_field {X minor grid} choice {{} off auto}]
    }
    _form $w axis "[string toupper $axis] axis and physical units" $fields $values [list ::GX::CurveViewer::_axisApply $w $pi $axis]
}
proc ::GX::CurveViewer::_axisApply {w pi axis values} {
    variable st
    set cleaned {};dict for {key value} $values {if {$value ne {}} {dict set cleaned $key $value}}
    set spec $st($w,spec)
    if {$pi<0} {dict set spec axes $axis $cleaned} else {
        set panels [dict get $spec panels];set panel [lindex $panels $pi];dict set panel axes $axis $cleaned;lset panels $pi $panel;dict set spec panels $panels
    }
    _setSpec $w $spec {Edit scientific axis presentation}
}
proc ::GX::CurveViewer::_sceneDialog {w} {
    variable st
    set spec $st($w,spec);set fields {}
    foreach key [::GX::moduleGraphConfigKeys plot.dataset plot.dataset.xyz] {
        set type [::GX::moduleGraphConfigField plot.dataset plot.dataset.xyz $key type string]
        set choices [::GX::splitList [::GX::moduleGraphConfigField plot.dataset plot.dataset.xyz $key values {}]]
        set field [_field [::GX::moduleGraphConfigField plot.dataset plot.dataset.xyz $key label $key] [expr {$type eq {choice} ? {choice} : {string}}] [linsert $choices 0 {}]]
        dict set fields $key $field
    }
    _form $w scene {Native 3D configuration} $fields [_get $spec config {}] [list ::GX::CurveViewer::_sceneApply $w]
}
proc ::GX::CurveViewer::_sceneApply {w values} {
    variable st
    set cleaned {};dict for {key value} $values {if {$value ne {}} {dict set cleaned $key $value}}
    set spec $st($w,spec);dict set spec config $cleaned
    _setSpec $w $spec {Edit Native3D scene presentation}
}
proc ::GX::CurveViewer::_cameraDialog {w} {
    variable st
    set spec [_cameraCapture $w $st($w,spec)]
    set fields {}
    foreach key {camera_position camera_target camera_up projection orthographic_height near_clip far_clip vertical_fov_degrees} {
        dict set fields $key [_field [string map {_ { }} $key] [expr {$key eq {projection} ? {choice} : {string}}] {orthographic perspective}]
    }
    _form $w camera {Native3D camera · semicolon-separated XYZ vectors} $fields [_get [_get $spec native_presentation {}] camera {}] [list ::GX::CurveViewer::_presentationApply $w camera]
}
proc ::GX::CurveViewer::_presentationDialog {w section} {
    variable st
    set fields {};set values [_get [_get $st($w,spec) native_presentation {}] $section {}]
    if {$section eq {legend}} {
        foreach {key label type choices} {
            placement Placement choice {{} inside below above left right manual none}
            inside_preset {Inside anchor} choice {{} northeast northwest southeast southwest north south east west center}
            layout Layout choice {{} auto row stacked wrapped} columns Columns string {}
            font_size {Legend font size} string {} font_unit {Font unit} choice {{} inherit px pt}
            alignment Alignment choice {{} start center end} margin_px {Legend margin (px)} string {}
            manual_x {Manual X (0–1)} string {} manual_y {Manual Y (0–1)} string {}
            background Background string {} border Border choice {{} 0 1} border_color {Border color} string {}
        } {dict set fields $key [_field $label $type $choices]}
    } else {
        set types [::GX::PlotDatasetAPIv4::renderSettingsFieldTypes $section [dict get $st($w,spec) graph_id]]
        dict for {key type} $types {
            set field [_field [string map {_ { }} $key]]
            if {$type eq {boolean}} {set field [_field [string map {_ { }} $key] choice {{} inherit 0 1}]}
            set choices [_get {font_unit {inherit px pt} legend_font_unit {inherit px pt} projection {inherit orthographic perspective} aspect_mode {inherit auto equal manual} grid_mode {inherit none major minor both} legend_placement {inherit inside below above left right manual none} legend_inside_preset {inherit northeast northwest southeast southwest center} legend_layout {inherit auto row stacked wrapped} legend_alignment {inherit start center end}} $key {}]
            if {$choices ne {}} {set field [_field [string map {_ { }} $key] choice [linsert $choices 0 {}]]}
            dict set fields $key $field
        }
    }
    # Explicit blank removes a draft override and lets the established owner
    # resolve inheritance; booleans retain meaningful 0 rather than Tcl truth.
    _form $w presentation "[string totitle $section] · blank inherits" $fields $values [list ::GX::CurveViewer::_presentationApply $w $section]
}
proc ::GX::CurveViewer::_presentationApply {w section values} {
    variable st
    set cleaned {};dict for {key value} $values {if {$value ne {}} {dict set cleaned $key $value}}
    if {$section eq {camera}} {set cleaned [::GX::viewerCameraValidate $cleaned]}
    set spec $st($w,spec);dict set spec native_presentation schema GXTXT_NATIVE_GRAPH_PRESENTATION_v1;dict set spec native_presentation $section $cleaned
    _setSpec $w $spec "Edit $section presentation" 0 [expr {$section ne {camera}}] 1
}
