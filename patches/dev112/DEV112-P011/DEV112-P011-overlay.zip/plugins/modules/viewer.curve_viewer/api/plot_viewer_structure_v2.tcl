# SPDX-License-Identifier: GPL-3.0-or-later
# Local PlotSpec edits are always admitted and drawn by the public v4 facade.
proc ::GX::CurveViewer::_panelDialog {w} {
    variable st
    set pi [_panelIndex $w];set panel [lindex [dict get $st($w,spec) panels] $pi]
    set fields [dict create action [_field {Panel action} choice {{Edit selected panel} {Add panel}}] \
        id [_field {Stable panel ID}] title [_field {Panel title}] multi_panel [_field {Separate panels with shared X} boolean]]
    _form $w panel {Panels and shared X layout} $fields [dict create action {Edit selected panel} id [dict get $panel id] title [_get $panel title {}] multi_panel [_get $st($w,spec) multi_panel 0]] [list ::GX::CurveViewer::_panelApply $w $pi]
}
proc ::GX::CurveViewer::_panelApply {w pi values} {
    variable st
    set spec $st($w,spec);set panels [dict get $spec panels]
    if {[dict get $values action] eq {Add panel}} {
        set panel [dict create id [dict get $values id] title [dict get $values title] axes {} series {} annotations {}]
        if {[dict exists [lindex $panels 0] axes x]} {dict set panel axes x [dict get [lindex $panels 0] axes x]}
        lappend panels $panel
    } else {
        set panel [lindex $panels $pi];dict set panel id [dict get $values id];dict set panel title [dict get $values title];lset panels $pi $panel
    }
    dict set spec panels $panels;dict set spec multi_panel [dict get $values multi_panel]
    _setSpec $w $spec {Edit panels and shared-X composition}
}
proc ::GX::CurveViewer::_removeSelected {w} {
    variable st
    set selection [split [_selection $w] :];set spec $st($w,spec)
    if {[lindex $selection 0] eq {series}} {
        lassign [lrange $selection 1 end] pi si
        set panels [dict get $spec panels];set panel [lindex $panels $pi];dict set panel series [lreplace [dict get $panel series] $si $si];lset panels $pi $panel;dict set spec panels $panels
    } elseif {[lindex $selection 0] eq {panel}} {
        set panels [dict get $spec panels]
        if {[llength $panels]==1} {error {The Plot must retain a panel; remove or replace its series instead}}
        set pi [lindex $selection 1];dict set spec panels [lreplace $panels $pi $pi]
    } elseif {[lindex $selection 0] eq {annotation}} {
        lassign [lrange $selection 1 end] pi ai
        set panels [dict get $spec panels];set panel [lindex $panels $pi];dict set panel annotations [lreplace [dict get $panel annotations] $ai $ai];lset panels $pi $panel;dict set spec panels $panels
    } else {error {Select a series, panel or annotation to remove from the local draft}}
    _setSpec $w $spec {Remove selected draft element}
}
proc ::GX::CurveViewer::_moveSelected {w delta} {
    variable st
    set parts [split [_selection $w] :];set spec $st($w,spec);set panels [dict get $spec panels]
    if {[lindex $parts 0] eq {series}} {
        lassign [lrange $parts 1 end] pi index
        set panel [lindex $panels $pi];set items [dict get $panel series]
        set destination [expr {max(0,min([llength $items]-1,$index+$delta))}]
        set moved [lindex $items $index];set items [lreplace $items $index $index];set items [linsert $items $destination $moved]
        # Explicit native presentation order must agree with the tree order.
        set ordered {};set rank 0
        foreach item $items {dict set item order $rank;incr rank;lappend ordered $item}
        set items $ordered;set selected series:$pi:$destination
        dict set panel series $items;lset panels $pi $panel
    } elseif {[lindex $parts 0] eq {panel}} {
        set index [lindex $parts 1];set destination [expr {max(0,min([llength $panels]-1,$index+$delta))}]
        set moved [lindex $panels $index];set panels [lreplace $panels $index $index];set panels [linsert $panels $destination $moved]
        set selected panel:$destination
    } else {error {Select a series or panel to reorder}}
    dict set spec panels $panels
    _setSpec $w $spec {Reorder draft elements}
    $w.body.sources.tree selection set $selected
    $w.body.sources.tree focus $selected
    $w.body.sources.tree see $selected
    _inspect $w
}
proc ::GX::CurveViewer::_visibility {w} {
    variable st
    lassign [_seriesLocation $w] pi si
    set spec $st($w,spec);set panels [dict get $spec panels];set panel [lindex $panels $pi];set series [dict get $panel series];set item [lindex $series $si]
    _showSelected $w [expr {![_get $item enabled 1]}]
}
proc ::GX::CurveViewer::_annotationDialog {w} {
    variable st
    set pi [_panelIndex $w];set ai -1
    set values {type reference_line axis x value 0 min 0 max 1 x 0 y 0 label {} color #555555 line_style dashed line_width 1}
    set parts [split [_selection $w] :]
    if {[lindex $parts 0] eq {annotation}} {
        lassign [lrange $parts 1 end] pi ai
        set values [dict merge $values [lindex [dict get [lindex [dict get $st($w,spec) panels] $pi] annotations] $ai]]
    }
    set fields {}
    foreach {key label type choices} {type Type choice {reference_line reference_region text} axis {Associated axis} choice {x left right} value {Reference line value} number {} min {Region minimum} number {} max {Region maximum} number {} x {Text annotation X position} number {} y {Text annotation Y position} number {} label {Text annotation content (type text only)} string {} color Color string {} line_style {Line style} choice {solid dashed dotted dashdot none} line_width {Line width} number {}} {dict set fields $key [_field $label $type $choices]}
    _form $w annotation {Scientific annotation · positions use the associated display units} $fields $values [list ::GX::CurveViewer::_annotationApply $w $pi $ai]
    ::GX::uiFieldFormNote $w.annotation {Reference lines use Value; reference regions use Minimum and Maximum. Text annotations use X, Y and Text annotation content. Text on a reference line or region requires a separate text annotation; nonempty text with either reference type is refused.}
}
proc ::GX::CurveViewer::_annotationApply {w pi ai values} {
    variable st
    set type [dict get $values type];set annotation [dict create type $type axis [dict get $values axis]]
    if {$type ne {text} && [dict get $values label] ne {}} {error {Text annotation content requires type text. Add a separate text annotation for a reference line or region.}}
    set fields [expr {$type eq {reference_line} ? {value} : $type eq {reference_region} ? {min max} : {x y label}}]
    foreach field [concat $fields {color line_style line_width}] {dict set annotation $field [dict get $values $field]}
    set spec $st($w,spec);set panels [dict get $spec panels];set panel [lindex $panels $pi];set annotations [_get $panel annotations {}]
    if {$ai<0} {lappend annotations $annotation} else {lset annotations $ai $annotation}
    dict set panel annotations $annotations;lset panels $pi $panel;dict set spec panels $panels
    _setSpec $w $spec {Edit scientific annotation}
}
proc ::GX::CurveViewer::_cellFieldDialog {w} {
    set ids [plotDatasetIds]
    if {$ids eq {}} {error {Publish the canonical cell and node Datasets first}}
    set fields [dict create mode [_field {Scientific presentation} choice {{Exact cell field} {Actual centroid profile}}]]
    foreach key {cells nodes} {dict set fields $key [_field "[string totitle $key] Dataset" choice $ids]}
    foreach {key label} {centroid_x {Cell sample X Variable ID} centroid_y {Cell sample Y Variable ID} node_id {True integer node identity Variable ID} node_x {Node X Variable ID} node_y {Node Y Variable ID} cell_id {True integer cell identity Variable ID} n1 {Triangle node reference 1} n2 {Triangle node reference 2} n3 {Triangle node reference 3} scalar {Cell scalar Variable ID}} {dict set fields $key [_field $label]}
    _form $w cellField {Exact triangular cell field · original topology, no interpolation} $fields [dict create mode {Exact cell field} cells [lindex $ids 0] nodes [lindex $ids 0]] [list ::GX::CurveViewer::_cellFieldApply $w]
}
proc ::GX::CurveViewer::_cellFieldApply {w values} {
    set binding [dict create schema GXTXT_CELL_FIELD_BINDING_v1 nodes_dataset_id [dict get $values nodes] node_id_variable_id [dict get $values node_id] x_variable_id [dict get $values node_x] y_variable_id [dict get $values node_y] \
        cell_id_variable_id [dict get $values cell_id] node_variable_ids [list [dict get $values n1] [dict get $values n2] [dict get $values n3]] scalar_variable_id [dict get $values scalar]]
    set spec [::GX::PlotDatasetAPIv4::cellFieldSpec [dict get $values cells] [dict get $values centroid_x] [dict get $values centroid_y] $binding]
    if {[dict get $values mode] eq {Actual centroid profile}} {set spec [::GX::PlotDatasetAPIv4::cellFieldProfileSpec $spec]}
    _setSpec $w $spec {Bind exact canonical cell field or actual centroid samples} 1
}
proc ::GX::CurveViewer::_advancedDialog {w} {
    variable st
    set dialog $w.advanced
    if {[winfo exists $dialog]} {raise $dialog;return}
    toplevel $dialog;wm title $dialog {Advanced PlotSpec · validated data, never executed code};wm transient $dialog $w;wm geometry $dialog 850x650
    ttk::label $dialog.help -text {Advanced portable PlotSpec dictionary. Apply uses the original v4 source and renderer admission. Canonical Dataset values remain unchanged.} -wraplength 790
    pack $dialog.help -side top -fill x -padx 8 -pady 8
    ttk::frame $dialog.actions
    ttk::button $dialog.actions.apply -text {Validate and apply draft} -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_advancedApply $w]]
    ttk::button $dialog.actions.close -text Close -command [list destroy $dialog]
    pack $dialog.actions.apply $dialog.actions.close -side left -padx 5;pack $dialog.actions -side bottom -fill x -padx 8 -pady 8
    ttk::scrollbar $dialog.sy -command [list $dialog.text yview]
    text $dialog.text -wrap word -undo 1 -yscrollcommand [list $dialog.sy set]
    pack $dialog.sy -side right -fill y;pack $dialog.text -fill both -expand 1 -padx 8
    $dialog.text insert 1.0 $st($w,spec)
    bind $dialog <Escape> [list destroy $dialog]
}
proc ::GX::CurveViewer::_advancedApply {w} {_setSpec $w [$w.advanced.text get 1.0 end-1c] {Apply validated advanced PlotSpec} 1}
proc ::GX::CurveViewer::_legacyOpen {w document} {
    variable st
    set st($w,legacyDocument) $document
    set dialog $w.legacy
    toplevel $dialog;wm title $dialog {Legacy Curve Viewer Workspace · read-only};wm transient $dialog $w;wm geometry $dialog 850x600
    ttk::label $dialog.info -text {This version-1 Workspace remains unchanged. Inspect its original source records below. Explicit conversion creates a new Plot Workspace only when every scientific record is faithfully representable.} -wraplength 790
    pack $dialog.info -fill x -padx 10 -pady 10
    text $dialog.records -wrap word -height 20
    $dialog.records insert 1.0 "Original source records:\n[dict get $document payload records]\n\nOriginal view and presentation:\n[dict remove [dict get $document payload] records scientific_history workspace_metadata]";$dialog.records configure -state disabled
    pack $dialog.records -fill both -expand 1 -padx 10
    ttk::button $dialog.convert -text {Convert to a new Plot Workspace…} -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_legacyConvert $w]]
    ttk::button $dialog.close -text {Close read-only record} -command [list destroy $dialog]
    pack $dialog.convert $dialog.close -side left -padx 10 -pady 10
    set st($w,status) {Legacy Workspace opened read-only. Its original Document is preserved; conversion is explicit.}
}
# Convert only the canonical bindings and presentation fields with exact v4
# counterparts. Saved direction markers stay in the preserved legacy Document.
proc ::GX::CurveViewer::_legacySeries {record id} {
    set request [dict get $record request]
    foreach key [dict keys $request] {if {$key ni {dataset_id x_variable_id y_variable_id filters rows display_budget}} {error "source option '$key' needs an explicit supported conversion"}}
    set direction [_get $record direction {}]
    if {$direction ne {} && [_get $direction present 1] && [_get $direction visible 0]} {error {a visible native direction marker is not implicitly converted}}
    set pattern [_get $record line_style 0];set marker [_get $record marker 0]
    if {$pattern ni {0 1 2} || $marker ni {0 1 2 3}} {error {unsupported legacy native line or marker style}}
    set style [dict create color [_get $record color auto] line_width [_get $record width 2] \
        line_style [lindex {solid dashed dotted} $pattern] marker [lindex {none circle square plus} $marker]]
    if {$marker in {1 2}} {dict set style marker_fill full}
    set item [dict create id $id dataset_id [dict get $request dataset_id] x_variable_id [dict get $request x_variable_id] y_variable_id [dict get $request y_variable_id] \
        kind [expr {$marker?{line_marker}:{line}}] axis left label [_get $record presentation_label [_get $record name $id]] enabled [_get $record visible 1] style $style]
    if {[dict exists $request filters]} {dict set item row_filters [dict get $request filters]}
    if {[dict exists $request rows]} {dict set item source_row_ordinals [dict get $request rows]}
    return $item
}
proc ::GX::CurveViewer::_legacyConvert {w} {
    variable st
    set original $st($w,legacyDocument);set series {};set next 0;set failures {}
    foreach record [dict get $original payload records] {
        set id [_get $record id legacy[incr next]]
        if {[catch {set item [_legacySeries $record legacy[incr next]]} reason]} {lappend failures "$id: $reason"} else {lappend series $item}
    }
    if {$failures ne {}} {error "Original Workspace preserved. These records cannot be silently converted:\n[join $failures \n]"}
    if {$series eq {}} {error {The legacy Workspace has no faithfully representable source curves}}
    set spec [::GX::PlotDatasetAPIv4::newSpec -title {Converted Curve Viewer}]
    set panel [lindex [dict get $spec panels] 0];dict set panel series $series
    set payload [dict get $original payload]
    if {[dict exists $payload presentation aspect]} {
        set aspect [dict get $payload presentation aspect]
        if {$aspect ni {auto xy_equal}} {error "Legacy aspect '$aspect' cannot be silently converted"}
        dict set spec native_presentation schema GXTXT_NATIVE_GRAPH_PRESENTATION_v1
        dict set spec native_presentation axes xy_aspect_mode $aspect
    }
    if {[dict exists $payload view_requested]} {
        set bounds [lindex [dict get $payload view_requested] 6]
        if {[llength $bounds]!=4} {error {Legacy requested view has no exact supported bounds}}
        lassign $bounds xmin ymin xmax ymax
        dict set panel axes x min $xmin;dict set panel axes x max $xmax
        dict set panel axes y_left min $ymin;dict set panel axes y_left max $ymax
    }
    dict set spec panels [list $panel]
    _setSpec $w $spec {Explicitly convert legacy source records to a new Plot draft} 1
    set st($w,workspaceName) {Converted Curve Viewer Plot}
    _workspaceSaveCommand $w
    if {[winfo exists $w.legacy]} {destroy $w.legacy}
    set st($w,status) "Created Workspace $st($w,documentId) with original numeric aspect and requested bounds. Other legacy presentation remains in original [dict get $original id]; Publish Plot is separate."
}
# Compatibility adapter for canonical source additions. Prepared private drawing
# buffers are not transferred into a second renderer; v4 opens the source itself.
proc ::GX::CurveViewer::add {w record {token {}} {prepared {}}} {
    variable st
    _scope $w
    if {[_dimension $w] ne {2D}} {error {Canonical Curve Source additions require a 2D Plot draft}}
    set item [_legacySeries $record [_get $record id series[incr st($w,next)]]]
    set spec $st($w,spec);set panels [dict get $spec panels];set panel [lindex $panels 0];dict lappend panel series $item;lset panels 0 $panel;dict set spec panels $panels
    _setSpec $w $spec {Add canonical curve through v4} 1
    if {$token ne {}} {::GX::curveSourceClose $token}
    return [dict get $item id]
}
