# SPDX-License-Identifier: GPL-3.0-or-later
# Explicit Graph publication and Workspace/History lifecycle use CORE owners.
proc ::GX::CurveViewer::_viewAxes {w} {
    set result {}
    if {![winfo exists $w.body.view.native2d]} {return $result}
    foreach axis [dict get [::GX::PlotDatasetAPIv4::widgetReceipt $w.body.view.native2d] axes] {
        set value {};foreach field {panel_id axis limits scale direction} {dict set value $field [dict get $axis $field]}
        # Native2D owns requested/effective aspect limits. Persist its request,
        # never feed the expanded display rectangle back as a fresh request.
        if {[dict exists $axis requested_limits]} {
            dict set value limits [dict get $axis requested_limits]
        } elseif {[dict get $axis aspect] eq {xy_equal}} {
            error {NATIVE_PLOT_BACKEND_v1 requires capability requested_axis_limits to save an equal-aspect view. Use the matching public Native2D adapter.}
        }
        lappend result $value
    }
    return $result
}
proc ::GX::CurveViewer::_capturePresentation {w} {
    variable st
    if {[_dimension $w] eq {3D}} {set st($w,spec) [_cameraCapture $w $st($w,spec)];return}
    if {![winfo exists $w.body.view.native2d]} return
    set panels [dict get $st($w,spec) panels]
    foreach view [_viewAxes $w] {
        set pi 0
        foreach panel $panels {
            if {[dict get $panel id] eq [dict get $view panel_id]} {
                set axis [dict get {x x left y_left right y_right} [dict get $view axis]]
                lassign [dict get $view limits] low high
                dict set panel axes $axis min $low;dict set panel axes $axis max $high
                lset panels $pi $panel;break
            }
            incr pi
        }
    }
    dict set st($w,spec) panels $panels
}
proc ::GX::CurveViewer::_payload {w} {
    variable st
    set sashes {0 0}
    if {[llength [$w.body panes]]==3} {set sashes [list [$w.body sashpos 0] [$w.body sashpos 1]]}
    return [dict create version 2 draft $st($w,spec) published_ref $st($w,published) source_pins $st($w,pins) next $st($w,next) \
        view_axes [_viewAxes $w] layout [dict create sources_visible $st($w,sourcesVisible) inspector_visible $st($w,inspectorVisible) left_sash [lindex $sashes 0] right_sash [lindex $sashes 1]]]
}
proc ::GX::CurveViewer::_historyCapture {w} {
    set payload [_payload $w]
    dict set payload view_axes {}
    dict set payload layout {sources_visible 1 inspector_visible 1 left_sash 0 right_sash 0}
    return $payload
}
proc ::GX::CurveViewer::_historyValidate {record} {workspaceValidate [dict get $record base];return 1}
proc ::GX::CurveViewer::_historyReplay {record} {::GX::scientificHistoryState $record}
proc ::GX::CurveViewer::_layoutCapture {w} {dict get [_payload $w] layout}
proc ::GX::CurveViewer::_layoutRestore {w layout} {
    variable st
    if {$layout eq {}} return
    foreach panel {sources inspector} {
        set frame $w.body.$panel
        set visible [dict get $layout ${panel}_visible]
        set st($w,${panel}Visible) $visible
        if {!$visible && $frame in [$w.body panes]} {$w.body forget $frame}
        if {$visible && $frame ni [$w.body panes]} {
            if {$panel eq {sources}} {$w.body insert 0 $frame -weight 0} else {$w.body add $frame -weight 0}
        }
    }
    set st($w,restoredLayout) $layout
    after idle [list ::GX::CurveViewer::_initialSashes $w]
}
proc ::GX::CurveViewer::_layoutEncode {layout} {::GX::nativeWorkspaceEncode {record {sources_visible bool inspector_visible bool left_sash int right_sash int}} $layout}
proc ::GX::CurveViewer::_historyRestore {w payload} {
    dict set payload layout [dict get [_payload $w] layout]
    _restorePayload $w $payload
}
proc ::GX::CurveViewer::_historyGuard {w} {
    variable st
    expr {[winfo exists $w] && ![info exists st($w,pendingHost)] && (![info exists st($w,closing)] || !$st($w,closing))}
}
proc ::GX::CurveViewer::_historyAttach {w} {
    variable st
    set record {}
    if {$st($w,documentId) ne {}} {
        set saved [::GX::interactiveDocumentRead $st($w,documentId)]
        set record [_get [dict get $saved payload] scientific_history {}]
    }
    ::GX::scientificHistoryViewerAttach $w viewer.curve_viewer [dict create document_id $st($w,documentId) \
        capture [list ::GX::CurveViewer::_historyCapture $w] restore [list ::GX::CurveViewer::_historyRestore $w] \
        commit [list ::GX::CurveViewer::_historyCommit $w] guard [list ::GX::CurveViewer::_historyGuard $w] \
        auxiliary [_layoutCapture $w] capture_aux [list ::GX::CurveViewer::_layoutCapture $w] \
        restore_aux [list ::GX::CurveViewer::_layoutRestore $w] archive_auxiliary_encode ::GX::CurveViewer::_layoutEncode strip_description_lines 2] $record
    ::GX::scientificHistoryViewerStrip $w $w.footer $w.footer.status modules.curve_viewer.history_strip [list -fill x -before $w.footer.coordinates]
}
proc ::GX::CurveViewer::_record {w description} {
    variable st
    if {[info exists st($w,restoring)] && $st($w,restoring)} return
    if {[dict exists $::GX::ScientificHistory::viewers $w]} {::GX::scientificHistoryViewerRecordOperation $w $description}
}
proc ::GX::CurveViewer::_historyCommit {w record} {
    set payload [_payload $w]
    dict set payload scientific_history $record
    _writeWorkspace $w $payload
}
proc ::GX::CurveViewer::_writeWorkspace {w payload} {
    variable st
    _scope $w
    if {$st($w,documentId) eq {}} {
        set name [expr {[string trim $st($w,workspaceName)] ne {} ? $st($w,workspaceName) : {Curve Viewer Plot}}]
        set saved [::GX::sessionWorkspaceCreate curve_viewer [::GX::sessionWorkspaceAvailableName $name] $payload]
    } else {
        set expected [::GX::interactiveDocumentMetadata $st($w,documentId)]
        if {[dict get $expected generation] ne $st($w,documentGeneration) || [dict get $expected revision] ne $st($w,documentRevision)} {error {Workspace changed in another editor; reopen it before saving}}
        set saved [::GX::sessionWorkspaceUpdate $st($w,documentId) $payload $expected]
    }
    set st($w,documentId) [dict get $saved workspace_id]
    set st($w,documentGeneration) [dict get $saved generation];set st($w,documentRevision) [dict get $saved revision]
    set st($w,savedPayload) [dict get $saved payload]
    ::GX::sessionWorkspaceViewerTitlesRefresh
}
proc ::GX::CurveViewer::_workspaceSave {w} {
    variable st
    _scope $w
    _capturePresentation $w
    _record $w {Save current Plot draft presentation}
    set auxiliary [::GX::scientificHistoryViewerAuxiliary $w [_layoutCapture $w]]
    if {[dict exists $auxiliary error] && [dict get $auxiliary error] ne {}} {error [dict get $auxiliary error]}
    ::GX::scientificHistoryViewerFlush $w
    if {$st($w,documentId) eq {}} {_writeWorkspace $w [_payload $w]}
    if {[dict get $::GX::ScientificHistory::viewers $w document_id] ne $st($w,documentId)} {::GX::scientificHistoryViewerBindDocument $w $st($w,documentId)}
    set st($w,status) {Curve Viewer Workspace saved. Publish Plot separately to create or update a main-window Graph.}
}
proc ::GX::CurveViewer::_workspaceSaveCommand {w} {::GX::sessionWorkspaceViewerAction curve_viewer [_workspaceCallbacks $w] $w save propagate}
proc ::GX::CurveViewer::_currentWorkspace {w} {variable st;return $st($w,documentId)}
proc ::GX::CurveViewer::_workspaceDirty {w} {
    variable st
    if {$st($w,documentId) eq {}} {return 1}
    # Dirty-state inquiry must still reach CORE's Save/Discard/Cancel review
    # after an external source revision invalidates the retained native frame.
    # Actual Save and publication retain their original source guards.
    if {[catch {set current [_payload $w]}]} {return 1}
    return [expr {![info exists st($w,savedPayload)] || [dict remove $st($w,savedPayload) workspace_metadata scientific_history] ne $current}]
}
proc ::GX::CurveViewer::_workspacePrepare {w action} {_scope $w;return}
proc ::GX::CurveViewer::_workspaceCallbacks {w} {
    return [dict create current [list ::GX::CurveViewer::_currentWorkspace $w] save [list ::GX::CurveViewer::_workspaceSave $w] \
        open ::GX::CurveViewer::open close [list ::GX::CurveViewer::_close $w 0] discard [list ::GX::CurveViewer::_close $w 0] \
        dirty [list ::GX::CurveViewer::_workspaceDirty $w] prepare [list ::GX::CurveViewer::_workspacePrepare $w]]
}
proc ::GX::CurveViewer::_restorePayload {w payload} {
    variable st
    workspaceValidate $payload
    if {[dict get $payload version]!=2} {error {Legacy Workspaces require explicit conversion to a new Plot Workspace}}
    set st($w,restoring) 1
    try {
        set st($w,spec) [dict get $payload draft];set st($w,published) [dict get $payload published_ref]
        set st($w,pins) [dict get $payload source_pins];set st($w,next) [dict get $payload next]
        set st($w,sourcesVisible) [dict get $payload layout sources_visible];set st($w,inspectorVisible) [dict get $payload layout inspector_visible]
        set st($w,restoredLayout) [dict get $payload layout]
        if {[catch {set currentPins [_pins $st($w,spec)]}] || $currentPins ne $st($w,pins)} {
            set st($w,status) {Canonical sources changed. The saved draft is preserved; explicitly rebind Dataset and variables before rendering or publishing.}
        } elseif {![catch {::GX::PlotDatasetAPIv4::validateSpec $st($w,spec)}]} {
            _render $w
            if {[_dimension $w] eq {2D} && [dict get $payload view_axes] ne {}} {::GX::PlotDatasetAPIv4::widgetView $w.body.view.native2d restore [dict get $payload view_axes]}
        } else {set st($w,status) {Saved incomplete draft restored. Choose valid source bindings before rendering or publishing.}}
        _refreshTree $w
        after idle [list ::GX::CurveViewer::_initialSashes $w]
    } finally {set st($w,restoring) 0}
}
proc ::GX::CurveViewer::_restoreContext {w context} {
    variable st
    set st($w,workspaceName) [_get $context workspace_name {}]
    set requested [_get $context workspace_id new]
    if {$requested ni {{} new}} {
        set doc [::GX::interactiveDocumentRead $requested]
        if {[dict get $doc module_id] ne {viewer.curve_viewer}} {error {Workspace belongs to another Viewer}}
        set payload [dict get $doc payload]
        if {[dict get $payload version]==1} {return [_legacyOpen $w $doc]}
        set st($w,documentId) [dict get $doc id];set st($w,documentGeneration) [dict get $doc generation];set st($w,documentRevision) [dict get $doc revision]
        set st($w,savedPayload) [dict get $doc payload]
        _restorePayload $w $payload
    }
    if {[dict exists $context plot_ref]} {_openPlot $w [dict get $context plot_ref]}
}
proc ::GX::CurveViewer::_workspaceOpenDialog {w} {::GX::sessionWorkspaceViewerAction curve_viewer [_workspaceCallbacks $w] $w open}
proc ::GX::CurveViewer::_workspaceManager {w} {::GX::sessionWorkspaceViewerAction curve_viewer [_workspaceCallbacks $w] $w manager}
proc ::GX::CurveViewer::_initialSashes {w} {
    variable st
    if {![winfo exists $w.body]} return
    set width [winfo width $w.body]
    if {[info exists st($w,restoredLayout)]} {
        set layout $st($w,restoredLayout);unset st($w,restoredLayout)
        foreach panel {sources inspector} {
            set frame $w.body.$panel
            if {![dict get $layout ${panel}_visible] && $frame in [$w.body panes]} {$w.body forget $frame}
        }
        if {[llength [$w.body panes]]==3 && [dict get $layout left_sash]>0 && [dict get $layout right_sash]>0} {
            $w.body sashpos 0 [dict get $layout left_sash]
            $w.body sashpos 1 [dict get $layout right_sash]
            _paneResize $w
            return
        }
    }
    if {[llength [$w.body panes]]==3} {$w.body sashpos 0 [expr {min(220,int(.2*$width))}];$w.body sashpos 1 [expr {max(420,$width-260)}]}
}
proc ::GX::CurveViewer::_paneResize {w} {
    if {![winfo exists $w.body] || [llength [$w.body panes]]!=3} return
    set width [winfo width $w.body]
    if {$width<400} return
    set left [$w.body sashpos 0];set right [$w.body sashpos 1]
    if {$width-$right<190 || $right-$left<240} {
        $w.body sashpos 0 [expr {min($left,max(145,int(.18*$width)))}]
        $w.body sashpos 1 [expr {$width-min(260,int(.25*$width))}]
    }
}
proc ::GX::CurveViewer::_panelToggle {w which} {
    variable st
    set frame $w.body.[expr {$which eq {sources} ? {sources} : {inspector}}]
    set field [expr {$which eq {sources} ? {sourcesVisible} : {inspectorVisible}}]
    if {$st($w,$field)} {$w.body forget $frame;set st($w,$field) 0} else {
        if {$which eq {sources}} {$w.body insert 0 $frame -weight 0} else {$w.body add $frame -weight 0}
        set st($w,$field) 1
    }
    _initialSashes $w
    if {[dict exists $::GX::ScientificHistory::viewers $w]} {
        set receipt [::GX::scientificHistoryViewerAuxiliary $w [_layoutCapture $w]]
        if {[dict exists $receipt error] && [dict get $receipt error] ne {}} {error [dict get $receipt error]}
    }
}
proc ::GX::CurveViewer::_navigate {w action} {::GX::scientificHistoryViewerNavigate $w $action}
proc ::GX::CurveViewer::_timeline {w} {::GX::scientificHistoryViewerStripSet $w {mode History visible 1};::GX::scientificHistoryViewerDetails $w}
proc ::GX::CurveViewer::_clearHistory {w} {variable st;::GX::scientificHistoryViewerClear $w $st($w,documentId)}
proc ::GX::CurveViewer::_cancel {w} {
    variable st
    if {[info exists st($w,pendingHost)]} {
        _pendingCancel $w
        set st($w,spec) $st($w,acceptedSpec)
        _refreshTree $w
        set st($w,status) {Native3D preparation cancelled. The previous accepted draft remains available.}
    }
}
proc ::GX::CurveViewer::_close {w {review 1}} {
    variable st
    if {$review} {return [::GX::sessionWorkspaceViewerAction curve_viewer [_workspaceCallbacks $w] $w close propagate]}
    _pendingCancel $w
    if {$st($w,host) ne {}} {::GX::PlotDatasetAPIv4::previewSpecRelease $st($w,hostParent)}
    if {[winfo exists $w.body.view.native2d]} {::GX::PlotDatasetAPIv4::widgetDestroy $w.body.view.native2d}
    destroy $w
    array unset st "$w,*"
}
proc ::GX::CurveViewer::_assertPins {w} {
    variable st
    if {[_pins $st($w,spec)] ne $st($w,pins)} {error {Canonical Dataset identity changed. Rebind and render the current source before publishing; the previous Graph remains intact.}}
    ::GX::PlotDatasetAPIv4::validateSpec $st($w,spec)
    if {[_dimension $w] eq {2D}} {::GX::PlotDatasetAPIv4::widgetValidateSources $st($w,spec)}
}
proc ::GX::CurveViewer::_openDialog {w} {
    variable st
    set choices {};set refs {}
    foreach graph [::GX::moduleGraphIds plot.dataset] {
        foreach variant [linsert [::GX::plotVariantIds plot.dataset $graph] 0 {}] {
            set ref [::GX::PlotDatasetAPIv4::openPlot $graph $variant]
            if {[catch {::GX::PlotDatasetAPIv4::loadSpec $ref}]} continue
            set label "$graph / [expr {$variant eq {} ? {base} : $variant}]"
            lappend choices $label;dict set refs $label $ref
        }
    }
    if {$choices eq {}} {error {No configured source Plot is available. Add a Dataset source to create a new draft. Image-only Clones have no editable PlotSpec.}}
    set st($w,openChoices) $refs
    _form $w openPlot {Open existing source Plot or Variant} [dict create plot [_field {Graph / Variant} choice $choices]] [dict create plot [lindex $choices 0]] [list ::GX::CurveViewer::_openChosen $w]
}
proc ::GX::CurveViewer::_openChosen {w values} {variable st;_openPlot $w [dict get $st($w,openChoices) [dict get $values plot]]}
proc ::GX::CurveViewer::_openPlot {w ref} {
    variable st
    if {[_get $ref kind provider] eq {clone}} {error {An image-only Clone has no editable canonical source Plot. Open it in the original Plots window or choose a live source Plot.}}
    set ref [::GX::PlotDatasetAPIv4::openPlot [dict get $ref graph_id] [_get $ref variant_id {}]]
    set spec [::GX::PlotDatasetAPIv4::loadSpec $ref]
    _setSpec $w $spec {Open source Plot as editable local draft} 1 0
    set st($w,openedSpec) $spec
    set st($w,published) $ref;set st($w,opened) [::GX::PlotDatasetAPIv4::isOwned $ref];set st($w,dirty) 0
    _refreshTree $w
    if {!$st($w,opened)} {set st($w,status) {Legacy source opened as a local v4 draft. Explicit new publication preserves its original renderer/Graph; Update is unavailable.}}
}
proc ::GX::CurveViewer::_publishDialog {w} {
    variable st
    _scope $w;_assertPins $w
    _capturePresentation $w
    set modes {{Create new Graph} {Publish as new Variant}}
    if {$st($w,opened) && $st($w,published) ne {} && [::GX::PlotDatasetAPIv4::isOwned $st($w,published)]} {lappend modes {Update opened Graph/Variant}}
    _form $w publish {Publish the current Plot into main Plots} [dict create mode [_field {Explicit publication action} choice $modes] title [_field {Plot title}]] \
        [dict create mode [lindex $modes 0] title [_get $st($w,spec) title auto]] [list ::GX::CurveViewer::_publishApply $w]
}
proc ::GX::CurveViewer::_publishApply {w values} {
    variable st
    _scope $w;_assertPins $w;_capturePresentation $w
    set spec $st($w,spec);dict set spec title [dict get $values title]
    set mode [dict get $values mode];set previous {};set created 0;set applied 0;set ref {};set rendered 0
    set st($w,status) {Validating and rendering through the canonical Plot v4 publication owner…}
    update idletasks
    try {
        if {$mode eq {Update opened Graph/Variant}} {
            if {!$st($w,opened) || $st($w,published) eq {} || ![::GX::PlotDatasetAPIv4::isOwned $st($w,published)]} {error {Explicitly open a live owned v4 Plot before Update}}
            set ref $st($w,published);set previous [::GX::PlotDatasetAPIv4::loadSpec $ref]
            if {[info exists st($w,openedSpec)] && ![::GX::PlotDatasetAPIv4::specEquivalent $previous $st($w,openedSpec)]} {error {The published Plot changed after it was opened here. Reopen it before Update; the external edit is preserved.}}
            ::GX::PlotDatasetAPIv4::applySpec $ref $spec
            set applied 1
            set appliedSpec [::GX::PlotDatasetAPIv4::loadSpec $ref]
        } else {
            set kind variant;set origin {}
            if {$mode eq {Publish as new Variant}} {
                if {$st($w,published) eq {} || [dict get $st($w,published) graph_id] ne [dict get $spec graph_id]} {error {Open or publish the intended source Graph before creating its new Variant}}
                set origin [dict get $st($w,published) variant_id]
            } elseif {[dict get $spec graph_type] eq {cartesian_2d}} {
                set base [::GX::PlotDatasetAPIv4::openPlot [dict get $spec graph_id]]
                if {[::GX::PlotDatasetAPIv4::listSeries $base] eq {}} {set kind base}
            }
            set ref [::GX::PlotDatasetAPIv4::createPlotFromSpec $spec $kind $origin]
            set created 1
        }
        set result [::GX::PlotDatasetAPIv4::render $ref]
        set rendered 1
        ::GX::writeManifest [file join $::GX::currentSession metadata manifest.ini]
    } on error {message options} {
        set recovery {}
        if {$ref ne {} && ($created || $applied)} {
            if {$created} {set rollback [list ::GX::PlotDatasetAPIv4::deletePlot $ref]} elseif {$previous ne {}} {set rollback [list ::GX::PlotDatasetAPIv4::applySpec $ref $previous]} else {set rollback {}}
            if {$applied} {
                if {[catch {
                    if {![info exists appliedSpec] || ![::GX::PlotDatasetAPIv4::isOwned $ref]} {error {The applied target snapshot or v4 ownership is no longer available}}
                    set current [::GX::PlotDatasetAPIv4::loadSpec $ref]
                    set unchanged [::GX::PlotDatasetAPIv4::specEquivalent $current $appliedSpec]
                } checkError]} {
                    set rollback {};set recovery "\nTarget state could not be verified for rollback: $checkError. Inspect the original Plots target before retrying."
                } elseif {!$unchanged} {
                    set rollback {};set recovery "\nThe target changed after this Update began. Its current external edit was preserved; reopen the target before retrying."
                }
            }
            if {$rollback ne {} && [catch {uplevel #0 $rollback} rollbackError]} {set recovery "\nThe owner could not completely restore Plot state: $rollbackError. Inspect $ref in the original Plots window before retrying."}
        }
        if {$rendered} {append recovery {
Rendering completed before Session persistence failed. Configuration restoration does not restore newly rendered artifacts; inspect this target in original Plots before retrying.}}
        catch {::GX::refreshGraphs}
        set st($w,status) "Publication failed: $message$recovery"
        return -options $options $st($w,status)
    }
    set st($w,spec) $spec;set st($w,published) $ref;set st($w,dirty) 0
    if {$mode eq {Update opened Graph/Variant}} {set st($w,openedSpec) [::GX::PlotDatasetAPIv4::loadSpec $ref]}
    set st($w,lastPublication) $result
    ::GX::refreshGraphs
    catch {::GX::refreshOpenGraphWindow}
    _refreshTree $w
    set st($w,status) "Published real Graph [dict get $ref plot_id]. It is available in the original main-window Plots list. Save Workspace separately to retain this Viewer draft."
    _record $w {Publish Plot through canonical Graph owner}
    return [dict create plot_ref $ref render $result]
}
proc ::GX::CurveViewer::_exportDialog {w} {
    variable st
    _scope $w;_assertPins $w
    set output [tk_getSaveFile -parent $w -title {Export actual native Plot rendering} -defaultextension .png -filetypes {{{PNG image} .png} {{SVG vector} .svg} {{PDF document} .pdf}}]
    if {$output eq {}} return
    _capturePresentation $w
    if {[_dimension $w] eq {3D}} {::GX::PlotDatasetAPIv4::render3DSpec $st($w,spec) $output} else {::GX::PlotDatasetAPIv4::widgetExport $w.body.view.native2d $output}
    set st($w,status) "Exported native rendering to $output. No Graph or Dataset was created."
    return $output
}
proc ::GX::CurveViewer::nativeReceipt {w} {
    variable st
    _scope $w
    if {[_dimension $w] eq {3D}} {return [::GX::PlotDatasetAPIv4::previewSpecReceipt $st($w,host)]}
    return [::GX::PlotDatasetAPIv4::widgetReceipt $w.body.view.native2d]
}
proc ::GX::CurveViewer::_help {w} {::GX::documentationBrowserOpenModuleWindow viewer.curve_viewer $w}
::GX::scientificRecipeHostRegister viewer.curve_viewer [dict create capture ::GX::CurveViewer::_historyCapture validate ::GX::CurveViewer::_historyValidate replay ::GX::CurveViewer::_historyReplay]

proc ::GX::CurveViewer::snapshot {w} {
    _scope $w
    return -code error -errorcode {GXTXT CURVE_VIEWER LEGACY_SNAPSHOT_UNAVAILABLE} {The rewritten Plot v4 Viewer has no legacy Native2D scene snapshot. Activate CURVE_VIEWER_API_v2 and use nativeReceipt for the actual Native2D/Native3D renderer receipt.}
}
