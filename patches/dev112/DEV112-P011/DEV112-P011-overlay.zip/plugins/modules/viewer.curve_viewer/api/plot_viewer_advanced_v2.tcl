# SPDX-License-Identifier: GPL-3.0-or-later
# Advanced GUI routes reuse the existing scientific/Plot/Workspace owners.
proc ::GX::CurveViewer::_filtersDialog {w} {
    variable st
    set location [_seriesLocation $w];lassign $location pi si
    set series [lindex [dict get [lindex [dict get $st($w,spec) panels] $pi] series] $si]
    set fields {}
    set ids [_variables [dict get $series dataset_id] 1 {1}]
    foreach key {family_variable_id secondary_variable_id ordering_variable_id} {
        dict set fields $key [_field [string map {_ { }} $key] choice [linsert $ids 0 {}]]
    }
    dict set fields family_label_prefix [_field {Family label prefix}]
    dict set fields source_row_continuity [_field {Break lines at gaps in original rows} boolean]
    dict set fields source_row_ordinals [_field {Exact original row ordinals (blank means all)}]
    dict set fields row_filters [_field {Current exact predicates (advanced; Add row predicate is in More)}]
    _form $w filters {Canonical families, order and row selection} $fields [dict merge {source_row_continuity 1} $series] [list ::GX::CurveViewer::_seriesSectionApply $w $location filters]
    ttk::button $w.filters.actions.predicate -text {Add row predicate…} -command [list ::GX::CurveViewer::_safe $w [list ::GX::CurveViewer::_filterPredicateDialog $w]]
    pack $w.filters.actions.predicate -side left -padx 4
}
proc ::GX::CurveViewer::_filterPredicateDialog {w} {
    variable st
    set location [_seriesLocation $w];lassign $location pi si
    set series [lindex [dict get [lindex [dict get $st($w,spec) panels] $pi] series] $si]
    set ids [_variables [dict get $series dataset_id] 1 {1}]
    set fields [dict create action [_field {Predicate action} choice {{Append predicate} {Replace predicates} {Clear predicates}}] \
        variable [_field {Stable source Variable ID} choice $ids] \
        predicate [_field {Exact CORE predicate} choice {exact_equal not_equal less_than less_equal greater_than greater_equal between_inclusive in_set is_finite is_nonfinite}] \
        value [_field {Source-unit value / exact membership list}] upper [_field {Inclusive upper bound (between only)}]]
    _form $w predicate {Rows included in this draft · original Dataset remains unchanged} $fields \
        [dict create action {Append predicate} variable [lindex $ids 0] predicate exact_equal value {} upper {}] \
        [list ::GX::CurveViewer::_filterPredicateApply $w $location]
}
proc ::GX::CurveViewer::_filterPredicateApply {w location values} {
    variable st
    lassign $location pi si
    set series [lindex [dict get [lindex [dict get $st($w,spec) panels] $pi] series] $si]
    set filters {}
    if {[dict get $values action] eq {Append predicate}} {set filters [_get $series row_filters {}]}
    if {[dict get $values action] ne {Clear predicates}} {
        set predicate [dict get $values predicate]
        set filter [dict create filter_variable_id [dict get $values variable] predicate $predicate]
        switch $predicate {
            is_finite - is_nonfinite {}
            between_inclusive {dict set filter lower [dict get $values value];dict set filter upper [dict get $values upper]}
            in_set {dict set filter values [dict get $values value]}
            default {dict set filter value [dict get $values value]}
        }
        lappend filters $filter
    }
    set filters [::GX::graphSeriesNormalizeFilters [dict get $series dataset_id] $filters]
    _seriesSectionApply $w $location filters [dict create row_filters $filters]
}
proc ::GX::CurveViewer::_comparisonDialog {w} {
    variable st
    if {[_dimension $w] ne {2D}} {error {Scientific source comparison is a 2D capability}}
    set sources {}
    foreach panel [dict get $st($w,spec) panels] {
        foreach series [dict get $panel series] {
            if {![_get $series enabled 1]} continue
            if {[_get $series row_filters {}] ne {} || [_get $series source_row_ordinals {}] ne {} || [dict exists $series cell_field]} {
                error {This comparison owner requires complete canonical source series. Publish an explicit canonical subset before comparing filtered or cell-associated data.}
            }
            lappend sources [::GX::comparisonPlotSourceDataset [dict get $series dataset_id] [dict get $series x_variable_id] [dict get $series y_variable_id]]
        }
    }
    if {[llength $sources]<2} {error {Add at least two distinct enabled canonical source series to this 2D draft first}}
    set st($w,comparisonSources) $sources
    _form $w comparison {Compare enabled source series using CORE Numeric} \
        [dict create mode [_field Mode choice {overlay top_bottom stacked difference ratio}] \
            normalization [_field {Explicit display normalization} choice {none minmax}] \
            offset [_field {Stacked display offset} number] denominator_floor [_field {Ratio denominator floor} number]] \
        {mode overlay normalization none offset 0 denominator_floor 0} [list ::GX::CurveViewer::_comparisonApply $w]
}
proc ::GX::CurveViewer::_comparisonApply {w values} {
    variable st
    set config [dict merge $values [dict create schema GXTXT_COMPARISON_PLOT_v1 sources $st($w,comparisonSources) interpolation linear domain intersection_first_source_grid]]
    set spec [::GX::comparisonPlotSpec $config]
    _setSpec $w $spec {Configure scientific source comparison through CORE}
}
proc ::GX::CurveViewer::_publishedRef {w} {
    variable st
    if {$st($w,published) eq {}} {error {Explicitly publish or open the intended source Plot first}}
    return $st($w,published)
}
proc ::GX::CurveViewer::_originalEditor {w} {
    set ref [_publishedRef $w]
    if {![::GX::PlotDatasetAPIv4::isOwned $ref]} {error {The original source is not v4-owned. Preserve it and explicitly publish a new v4 Graph first}}
    if {[tk_messageBox -parent $w -type okcancel -default cancel -icon warning -message {Open the original editor for the published Plot? Changes there directly affect that Graph/Variant. This Viewer draft stays separate; reopen the Plot here to load those edits.}] ne {ok}} return
    return [::GX::PlotDatasetAPIv4::openEditor $ref]
}
proc ::GX::CurveViewer::_representationsDialog {w} {
    variable st
    set sources {};set sourceLabels {}
    foreach ref [::GX::PlotDatasetAPIv4::interactiveSources] {set label [dict get $ref plot_id];dict set sources $label $ref;lappend sourceLabels $label}
    set retained {};set retainedLabels {}
    foreach item [::GX::PlotDatasetAPIv4::interactiveRepresentations] {
        set label "[dict get $item id] · [dict get $item status]"
        dict set retained $label [dict get $item id];lappend retainedLabels $label
    }
    set st($w,representationSources) $sources;set st($w,representations) $retained
    _form $w representations {Independent native representations · original CORE Workspace owner} \
        [dict create action [_field Action choice {{Open current source} {Open retained representation} {Sync retained representation}}] \
            source [_field {Current canonical 3D Plot} choice [linsert $sourceLabels 0 {}]] \
            representation [_field {Retained identity and actual source status} choice [linsert $retainedLabels 0 {}]]] \
        [dict create action {Open current source} source [lindex $sourceLabels 0] representation [lindex $retainedLabels 0]] \
        [list ::GX::CurveViewer::_representationApply $w]
}
proc ::GX::CurveViewer::_representationApply {w values} {
    variable st
    switch [dict get $values action] {
        {Open current source} {
            if {![dict exists $st($w,representationSources) [dict get $values source]]} {error {Choose an available canonical source Plot}}
            set result [::GX::PlotDatasetAPIv4::openInteractive [dict get $st($w,representationSources) [dict get $values source]]]
        }
        {Open retained representation} - {Sync retained representation} {
            if {![dict exists $st($w,representations) [dict get $values representation]]} {error {Choose an existing retained representation}}
            set id [dict get $st($w,representations) [dict get $values representation]]
            if {[dict get $values action] eq {Sync retained representation}} {set result [::GX::PlotDatasetAPIv4::syncInteractive $id]} else {set result [::GX::PlotDatasetAPIv4::openRepresentation $id]}
        }
        default {error {Unknown native representation action}}
    }
    set st($w,status) "Original Native3D owner opened [dict get $result representation_id]. Inspect source status in Independent 3D representations; Sync is explicit."
    return $result
}
proc ::GX::CurveViewer::_captureClone {w} {
    variable st
    set ref [_publishedRef $w]
    if {[dict exists [::GX::PlotDatasetAPIv4::loadSpec $ref] comparison]} {
        error {This CORE scientific snapshot format does not detach derived comparison sources. Preserve its Workspace and canonical source Datasets; use the original Plots image capture for a rendered-only copy.}
    }
    if {[tk_messageBox -parent $w -type okcancel -default cancel -message {Capture the published Plot as an independent scientific Clone using CORE? This explicitly freezes its canonical source resources. Unpublished draft edits are not included.}] ne {ok}} return
    set artifact [dict get [::GX::PlotDatasetAPIv4::artifacts $ref] graph_artifact]
    set captured [::GX::PlotClone::captureRendered $artifact]
    set info [::GX::PlotClone::infoForPath $captured]
    ::GX::refreshGraphs
    set st($w,status) "Captured [dict get $info clone.capture_mode] Clone: $captured. It appears separately in the original Plots list."
    return $captured
}
proc ::GX::CurveViewer::_snapshotOpen {w} {
    set directory [tk_chooseDirectory -parent $w -title {Open a complete native scientific snapshot directory} -mustexist 1]
    if {$directory eq {}} return
    set manifest [::GX::PlotDatasetAPIv4::snapshotValidate $directory]
    set artifact [::GX::PlotDatasetAPIv4::renderSnapshot $directory [dict get $manifest graph_id]]
    set dialog $w.snapshot
    catch {destroy $dialog};toplevel $dialog;wm title $dialog {Detached scientific snapshot · actual native rendering};wm geometry $dialog 1050x780
    ttk::label $dialog.info -text {Read-only canonical capture. This is its actual native rendered artifact; it does not create an editable source Graph or publish a Dataset.} -wraplength 950
    pack $dialog.info -side top -fill x -padx 8 -pady 8
    canvas $dialog.canvas -highlightthickness 0 -xscrollcommand [list $dialog.sx set] -yscrollcommand [list $dialog.sy set]
    ttk::scrollbar $dialog.sx -orient horizontal -command [list $dialog.canvas xview]
    ttk::scrollbar $dialog.sy -command [list $dialog.canvas yview]
    pack $dialog.sx -side bottom -fill x;pack $dialog.sy -side right -fill y;pack $dialog.canvas -fill both -expand 1
    set photo [image create photo -file $artifact]
    $dialog.canvas create image 0 0 -anchor nw -image $photo
    $dialog.canvas configure -scrollregion [list 0 0 [image width $photo] [image height $photo]]
    bind $dialog <Destroy> [list ::GX::CurveViewer::_snapshotImageDestroyed $dialog $photo %W]
    return $artifact
}
proc ::GX::CurveViewer::_snapshotImageDestroyed {dialog photo actual} {if {$actual eq $dialog} {image delete $photo}}
proc ::GX::CurveViewer::_cameraControls {w} {
    variable st
    if {$st($w,host) eq {}} {error {Render a genuine 3D draft first}}
    set receipt [::GX::PlotDatasetAPIv4::previewSpecReceipt $st($w,host)]
    ::GX::PlotDatasetAPIv4::previewSpecControls $st($w,host) [expr {![dict get $receipt controls_visible]}]
}
proc ::GX::CurveViewer::_providerConsultation {w} {
    set path [::GX::currentGraphPath]
    if {$path eq {}} {error {Select the intended scientific provider Graph in the original main Plots list first}}
    set ref [::GX::graphResourceRefForPath $path]
    set source [::GX::PlotDatasetAPIv4::consultationSource $ref]
    set dialog $w.consultation
    catch {destroy $dialog};toplevel $dialog;wm title $dialog {Original provider Plot · read-only native consultation};wm geometry $dialog 1050x780
    ttk::label $dialog.identity -text "Original provider: [dict get $ref module_id] / [dict get $ref graph_id] / [dict get $ref variant_id]. No Graph conversion or publication."
    pack $dialog.identity -side bottom -fill x -padx 8 -pady 6
    ttk::frame $dialog.view;pack $dialog.view -fill both -expand 1
    set host [::GX::native3DPreviewAcquire $dialog.view [dict get $source source_info source_dataset_id] \
        [::GX::native3DPreviewPlotKey $ref] [list ::GX::native3DPreviewPlotKey $ref] [list ::GX::native3DPreviewPlotPrepare $ref]]
    wm protocol $dialog WM_DELETE_WINDOW [list ::GX::CurveViewer::_consultationClose $dialog]
    return $host
}
proc ::GX::CurveViewer::_consultationClose {dialog} {::GX::native3DPreviewRelease $dialog.view;destroy $dialog}
proc ::GX::CurveViewer::_workbenchComparison {w} {
    variable st
    ::GX::modulePublicApiActivate viewer.curve_workbench CURVE_WORKBENCH_API_v1
    set choices {};set sources {}
    foreach candidate [winfo children .] {
        if {[winfo toplevel $candidate] ne $candidate} continue
        if {[catch {set source [::GX::CurveWorkbench::comparisonDisplaySource $candidate]}]} continue
        set label "[wm title $candidate] · $candidate"
        lappend choices $label;dict set sources $label $source
    }
    if {$choices eq {}} {error {No current Curve Workbench comparison is available. Compute it in its original Workbench first; this Viewer never fabricates comparison statistics.}}
    set st($w,workbenchComparisons) $sources
    _form $w workbenchComparison {Inspect an existing numerical comparison} [dict create comparison [_field {Original comparison owner} choice $choices]] \
        [dict create comparison [lindex $choices 0]] [list ::GX::CurveViewer::_workbenchComparisonApply $w]
}
proc ::GX::CurveViewer::_workbenchComparisonApply {w values} {
    variable st
    set source [dict get $st($w,workbenchComparisons) [dict get $values comparison]]
    set model [::GX::PlotDatasetAPIv4::comparisonModel $source [dict get $source comparison_identity]]
    set dialog $w.comparisonView
    catch {destroy $dialog};toplevel $dialog;wm title $dialog {Derived comparison · original scientific owner};wm geometry $dialog 1050x780
    ttk::label $dialog.info -text {Derived evaluation samples retain their comparison identity. They are not canonical Dataset row numbers. Keep the original Workbench open.} -wraplength 950
    pack $dialog.info -side bottom -fill x -padx 8 -pady 6
    ::GX::PlotDatasetAPIv4::widgetCreate $dialog.plot $model {prepared_model 1 refresh_hint {Refresh the original Workbench comparison before reopening this view.}}
    pack $dialog.plot -fill both -expand 1
    update idletasks
    ::GX::PlotDatasetAPIv4::widgetDraw $dialog.plot
    return $dialog
}

proc ::GX::CurveViewer::_plotDialog {w} {
    variable st
    _form $w plotProperties {Plot title} [dict create title [_field {Scientific Plot title}]] [dict create title [_get $st($w,spec) title auto]] [list ::GX::CurveViewer::_plotApply $w]
}
proc ::GX::CurveViewer::_plotApply {w values} {
    variable st
    ::GX::PlotDatasetAPIv4::newSpec -title [dict get $values title]
    set spec $st($w,spec);dict set spec title [dict get $values title]
    if {$st($w,pins) eq {}} {
        set st($w,spec) $spec;set st($w,acceptedSpec) $spec;set st($w,dirty) 1
        _refreshTree $w;_record $w {Edit incomplete draft title}
        set st($w,status) {Draft title saved. Choose canonical source bindings to render and publish.}
    } else {_setSpec $w $spec {Edit Plot title} 0 1 1}
}
