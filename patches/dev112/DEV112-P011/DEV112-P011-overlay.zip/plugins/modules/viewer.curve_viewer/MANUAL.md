# Curve Viewer — Plot v4

Curve Viewer edits local scientific Plot drafts with the existing CORE Native2D
and Native3D renderers. Open its normal Viewer tile in an open Session.

1. Choose **New 2D** or **New 3D**, then **Add source**. Select a published
   canonical Dataset and stable Variable IDs. A 3D Plot requires actual XYZ
   roles; rank-two grids use the admitted CORE grid topology.
2. Select a Plot, panel, axis or series in the source tree. Its contextual
   inspector opens source, kind, uncertainty, style, filters, physical units,
   annotation and presentation settings. Validation reports unsupported
   combinations. Scientific source values are never edited here.
3. Use the large native canvas. In 2D, the wheel zooms, middle drag pans,
   double-click fits, and click selects a source point/series or axis. In 3D,
   drag orbits, middle drag pans and the wheel zooms. Fit/Reset use the CORE
   camera. Both side panels collapse from **Advanced** and their sashes resize.
4. **Save Workspace** preserves the local draft using the normal Session
   Workspace/History services. It is independent of Graph publication.
5. **Publish Plot** explicitly creates a real main-window Graph, creates a
   new Variant of its source Graph, or updates an intentionally opened live
   v4-owned target. Actual successful rendering precedes the main Plots refresh.
   Canonical 3D publication uses the existing `plot.dataset.xyz` Variant owner.
6. **Export** writes the actual native renderer result as a supported PNG,
   SVG or PDF. This is distinct from publishing a scientific Graph or Dataset.

A new draft does not change a published Graph. Source identities are pinned
and rechecked before publication. A failed publication reports the owner error
and any incomplete restoration. Native3D edits prepare a new frame while
retaining the previous accepted draft; Escape cancels the pending preparation.

Old version-1 Workspaces open read-only. **Convert to a new Plot Workspace**
requires every record to be faithfully representable and preserves the original
Document. Unsupported transformations are named rather than discarded.
Image-only Clones have no editable canonical PlotSpec.

The trusted host contract is [CURVE_VIEWER_API_v2](CURVE_VIEWER_API_v2.md).
The legacy v1 Script Bridge `datasetIds` operation keeps its original discovery
heuristic. No new generic Script permissions are granted by opening GUI controls.

Controls in **Advanced** expose explicit exact row predicates, CORE source
comparisons, retained native representation Open/Sync with actual source status,
read-only original-provider3D consultation, existing Workbench numerical
comparison display, scientific Clone capture and complete snapshot validation/
rerender. They preserve the original scientific owners and source identities.
Original Plot editor access explicitly edits the published target; reopen that
Plot here before updating a draft based on it. Stale property forms and external
source/target revisions are rejected rather than applied to a different object.
The ordinary3D canvas hides its camera control overlay; Advanced can toggle it.
Native drag/pan/wheel and the top Fit/Reset controls remain available.

The current CORE scientific snapshot format detaches canonical source Plots.
Derived comparison Plots require their Workspace and canonical sources; this
Viewer refuses to advertise an incomplete detached scientific comparison.
Use the original Plots rendered-image capture when an image-only copy is wanted.

Explicit legacy conversion preserves supported record styles, numeric aspect
and the original requested bounds. Other original presentation remains visible
in the read-only legacy record. Fit respects explicit configured axis bounds;
change or clear those bounds in the axis inspector to use a different range.
Inspector labels wrap using original Tk font metrics, the source tree scrolls
horizontally, and the footer wraps to the actual window width. The action-row
More overflow remains separate from Advanced and retains hidden top actions.

Use **Edit** below the source tree to move/remove/show/hide the selected draft
element. Selection follows a moved element. Annotation types use distinct
fields: reference lines use Value, regions use Minimum/Maximum, and text
annotations use X/Y/Content. Add a separate text annotation to label a reference
line or region; unsupported text is explicitly refused. Equal-aspect Workspace
persistence retains the native requested bounds separately from the expanded
display rectangle, so repeated Save/reopen does not widen the request.

Export retains the current native camera or axis request in the local draft
so that view can be saved with the Workspace. It creates neither a Graph nor
a scientific Dataset; only explicit Publish changes the main Plots list.
