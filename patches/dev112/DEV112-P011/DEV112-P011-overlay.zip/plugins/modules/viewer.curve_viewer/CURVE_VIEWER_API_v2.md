# Curve Viewer API v2

The trusted Viewer host uses `PLOT_DATASET_API_v4` for source admission,
interactive Native2D and Native3D presentation, scientific PlotSpecs and explicit
Graph/Variant publication. It owns local GUI drafts and existing CORE Workspaces.

`open(context)` opens the installed `viewer.curve_viewer` tile. `plotDatasetIds`
discovers published numeric source identities. `add(window, record, token,
prepared)` adapts canonical Curve Source records; Plot v4 rereads the original
source rather than transferring private display buffers. `nativeReceipt(window)`
returns the actual native widget or draft-host receipt. `publishPlot(window,
mode,title)` explicitly creates a main Plots Graph, a new Variant, or updates an
intentionally opened owned target. `workspaceSave(window)` saves the independent
Viewer draft. No operation duplicates canonical scientific Dataset values.

Mode labels are `Create new Graph`, `Publish as new Variant`, and
`Update opened Graph/Variant`. XYZ content uses the existing persistent
`plot.dataset.xyz` Variant identity. Existing base/sibling settings are preserved.
Image-only Clones have no editable source PlotSpec.

Version-1 Workspaces open read-only and require explicit conversion to a new
Workspace. Unrepresentable records are reported; the original is preserved.
The v1 open/source-add entrypoint remains a compatibility route. The new native
receipt contract is explicitly v2; it does not fabricate an old private scene.

These are live trusted GUI-host operations. They grant no generic Script Bridge
callback, foreign window, private renderer or arbitrary publication authority.

Version-1 `datasetIds` retains its original Script Bridge heuristic. The old
`snapshot` operation explicitly rejects the incompatible legacy scene contract
with `GXTXT CURVE_VIEWER LEGACY_SNAPSHOT_UNAVAILABLE`; use v2 `nativeReceipt`.
The installed tile/catalog identity and legacy Workspace decoding are retained.
