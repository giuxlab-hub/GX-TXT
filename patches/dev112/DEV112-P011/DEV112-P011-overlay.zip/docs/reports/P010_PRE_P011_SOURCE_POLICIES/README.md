# Retained P010 source-policy evidence

These are exact accepted P010 policy bytes, including historical authority
definitions and qualifications. They are not current P011 runtime proof.
Current adjacent policies name actual current source definitions; missing
retired helpers remain explicit. Runtime admission and independent tests
remain with their original owners and candidate-specific evidence.
