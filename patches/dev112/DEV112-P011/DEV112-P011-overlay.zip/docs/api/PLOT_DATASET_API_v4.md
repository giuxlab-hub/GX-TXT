# Plot Dataset API v4

Native Plot v4 is the required public scientific plotting API for every new or
rebuilt Viewer, in both 2D and 3D. PlotSpec v2, Graph Series, Variants, Dataset
schemas, canonical values and physical units retain their existing authorities.
Activate `PLOT_DATASET_API_v4` through the Module API; the Tcl namespace is
`::GX::PlotDatasetAPIv4`. APIs v1/v2 retain their compatibility behavior.
**v3 is DEPRECATED for historical compatibility only and is denied to new
restricted C++ Viewer authoring.**

The v4 facade preserves the public v3 lifecycle/specification operations and exposes native `widgetCreate path spec ?context?`, `widgetConfigure`, `widgetDraw`, `widgetHit`, `widgetView`, `widgetEdit`, `widgetExport`, `widgetDestroy` and `widgetReceipt`. Native2D C++ retains a disposable typed view and projects through CORE C geometry to the shared native Cairo/Tk surface. Source access uses bounded public Curve Source/Table Stream services; full source extrema remain independent of display reduction. Hit receipts retain exact source-row strings, including uint64 values above 2^53.

`widgetCreate` validates prepared source snapshots before allocating its native
controller or surface. A rejected stale source leaves the path available for an
explicit valid retry. `widgetConfigure` likewise validates the replacement before
changing the accepted controller; rejection preserves its previous model.

Host-only `widgetValidateSources spec ?context?` runs the same model/source
snapshot checks without creating, configuring or destroying a controller or
surface. It returns `valid 1` and `source_count`, or raises the existing source
admission error. Hosts can check a replacement before clearing accepted UI.
`prepared_model 1` has the same meaning as in widget creation. This is a source
preflight, not a guarantee of later widget allocation or full UI transaction
success; create/configure still revalidate. It publishes no Dataset or cache,
and adds no Script Bridge or restricted C++ method.

A widget context containing `prepared_model 1` accepts an explicit disposable native presentation model; it does not publish scientific data. Canonical plot publication requires actual Dataset identities. Wheel zoom, middle-button pan and double-click complete fit change presentation only. Grid lines and labels use the same numeric ticks from the existing CORE axis authority.

Automatic native layout keeps the full rotated Y-axis caption inside its panel
using the same Cairo ink metrics as the painter. It retains the exact text,
font, axis limits and samples; captions already inside the panel keep their position.
If the complete caption cannot fit, drawing explicitly refuses with a viewport
diagnostic. Explicit manual layout retains its declared placement behavior.

## Canonical Scientific Dataset consultation

`scientificModel datasetId xId series coordinateContext ?options?` admits the
Scientific Dataset Viewer's existing asynchronous Curve Source results into the
same native Plot v4 model. Each trace supplies `id`, `y_variable_id`, `label`,
`filters`, the actual `source_descriptor` captured before closing its Curve
Source, and its prepared `display`. Descriptor Dataset/X/Y and `source_id` must
match that display; canonical `dataset_row` identities remain exact integers.
Canonical and displayed coordinates are separate. A presentation buffer is not
a new Dataset or an independent scientific authority.

Scientific consultations admit up to512 traces and100000 displayed points in
aggregate, while retaining the existing4096-point limit per trace. These bounds
affect presentation only. Source hashes/schema are validated for every descriptor,
including later descriptors naming an already watched Dataset; only watch
subscriptions are de-duplicated. An explicit source descriptor must identify at
least one canonical source. No caller-provided trust flag bypasses validation.
The consultation envelope is rechecked at final prepared-model admission,
including `widgetValidateSources`, widget creation/configuration and `renderModel`;
copying or expanding a prepared consultation cannot bypass these bounds. Unrelated
generic Plot/comparison/transient model classes keep their existing contracts.

Options are `title`, `axis_labels {x caption y caption}`, `aspect auto|xy_equal`,
the existing `native_presentation`, and an optional `progress` callback prefix.
Fit uses full finite source bounds. Nonlinear coordinate bounds use the existing
complete public Curve Source pass, yielding at bounded cooperative boundaries;
the callback must retain the host's cancellation/epoch check. Source, Session and
coordinate context are revalidated at preparation and controller admission.
Declared display units, magnification and canonical pivot use the existing
coordinate API. No numerical calibration is applied to canonical samples.

Create/configure with context `{prepared_model 1 retain_presentation 1}`.
`widgetDraw`, `widgetReceipt` and `renderModel` additionally return
`coordinate_presentation`, including reference bounds, actual painter view
bounds and coordinate ranges. The native receipt retains its original owner.
`xy_equal` uses the shared Native2D equal numeric aspect service for one linear
X/Y scale; it does not assert equal physical dimensions or CAD calibration.
Right-Y and logarithmic equal-aspect panels are rejected explicitly. A legacy
numeric/boolean axis outside the real-number coordinate contract remains
drawable, but its PNG metadata does not claim supported inverse calibration.

`widgetPointer path operation x y ?factor?` dispatches `pan_start`, `pan`, `zoom`
and `fit` through the owned controller. `widgetRetain path reason` freezes the
previous frame and pending draw/pointer activity during preparation, cancellation
or failure. A valid explicit `widgetConfigure` re-enables it. Fit cannot reactivate
an incomplete or cancelled preparation. These are trusted-host methods and add
no Script Bridge or restricted C++ SDK permission.

A valid filtered trace containing one observation uses the existing native
scatter/circle painter. It is not drawn as an invisible markerless one-vertex line.

## Derived numerical comparison display

`comparisonModel ownerBinding comparisonRecord ?options?` accepts the actual
public Curve Workbench comparison source and unchanged numerical result record.
The companion `CURVE_WORKBENCH_API_v1::comparisonDisplayValidate` must validate
the live owner, Session, window incarnation, Document generation, active request,
geometry fingerprints and coordinate signature. Validation runs both at model
admission and every live widget operation, even when no Dataset file changed.
Missing companion support is an explicit error. This is a live derived display;
it is not a detached scientific snapshot.

The existing Plot v4 line painter displays receipt samples and its scatter
painter highlights the recorded maximum. Comparison evaluation indices and
display-relative maximum indices remain distinct from Dataset row identities;
no canonical `source_rows` or fabricated Curve Source is attached. The complete
original comparison/statistics receipt and sampling policy remain in the model
and returned receipt. Statistics are not recomputed from display rows. Captured
source provenance is labeled `source_provenance_at_admission`; editable cached
geometry is not promoted to a claim of current canonical Dataset content.

Widget context may provide `refresh_hint {Select Compare to refresh.}` for a
stale derived display. The shared controller retains the old frame and reports
the appropriate action without recurring modal errors. Canonical publication
continues through the original comparison owner, never from Plot display data.

## Source-grounded 3D consultation

`consultationSource reference`, `consultationExportCommand reference directory`
and `consultationScene reference expectedSourceKey directory` provide the v4
construction/admission boundary for existing scientific provider graphs. Graph
Workflow still proves the producer's actual bindings, geometry, cache and units.
The original module, graph and base/Variant identity remain unchanged; the
provider is never relabeled `plot.dataset.xyz`. The existing native preparation
command is reused. Source/Session/coordinate keys and real native artifact hashes
are revalidated before adopting the bounded scene descriptor.

For numerical Dataset Preview, `xyzConsultationSource datasetId axes` resolves
three explicit distinct enabled rank-one numeric Variables and their canonical
source/coordinate identity. `xyzConsultationPrepare id axes w` and
`xyzConsultationChunk w` own the existing bounded stream and VTP construction,
using the existing shared host, cancellation and Native3D worker. They preserve
the limits of 100000 scanned rows and 12000 displayed points, without invented
connectivity or interpolation. `xyzCoordinatePresentation context axes
canonicalPoints` retains the existing unit conversion and magnification policy;
its normalized display frame does not modify canonical triples. Spatial X/Y in
millimetres and temperature Z in kelvin remain separately identified quantities.

`consultationReceipt hostWindow` verifies the current source and real layer
hashes and reports `preparing`, `updating` or `current`. A retained old frame is
insufficient to claim a current scene. These host-only methods reuse Native3D;
they create no additional renderer, scientific Dataset or Script/SDK permission.

Public Graph Metadata records `renderer_owner=PLOT_DATASET_API_v4` and `renderer_owner_api_version=1`. This selects native render, capture and portable dispatch without rebinding legacy sources.

`captureForArtifact artifact directory` captures complete public portable Dataset archives and a data-only `native_v4_snapshot.tcldict` manifest. `snapshotValidate`, `snapshotCopy`, `renderSnapshot`, `snapshotPresentationFields` and `snapshotPresentationSet` preserve the scientific capture after source deletion. Rendering imports into a newly owned disposable Session; no caller Session is changed. SHA and public ZIP validation precede use.

Python and Octave use their existing Script Bridge `gxtxt_api_call` interface
under `PLOT_DATASET_API_v4`. Discover exact operation/argument/result descriptors
with `gxtxt_api_describe('PLOT_DATASET_API_v4')` in the active managed script
context. Tcl host procedures, Script Bridge operation names and restricted C++
SDK methods are distinct surfaces: a host method is not automatically callable
by scripts or admitted to C++. The C++ Workspace API catalog and project profile
are authoritative for that author's admitted typed subset.

## Exact cell-associated triangular fields

`cellFieldSpec cellDatasetId centroidXVariableId centroidYVariableId binding ?title?` constructs a canonical PlotSpec with an explicit `cell_field` extension on its stable series ID. Python and Octave call `cell_field_spec` with the same five operands (title optional). The binding is an inert dictionary with exactly these fields:

```
schema GXTXT_CELL_FIELD_BINDING_v1
nodes_dataset_id canonicalNodeDataset
node_id_variable_id stableIntegerNodeId
x_variable_id nodeCoordinateX
y_variable_id nodeCoordinateY
cell_id_variable_id stableIntegerCellId
node_variable_ids {firstNodeId secondNodeId thirdNodeId}
scalar_variable_id cellAssociatedScalar
```

All names resolve through actual Variable Schema v3; no physical column positions or producer-specific headers are assumed. Connectivity contains three distinct existing node IDs. Node and cell identities are unique, coordinates and scalar values finite, triangles nondegenerate. Clockwise and counterclockwise source orientation are both retained. Node coordinate units are converted through the existing public coordinate context. The complete exact node domain determines bounds independently of scalar samples or display reduction. Colors are constant within each source cell; there is no Delaunay triangulation, nodal interpolation or implicit averaging of unrelated values. Picking returns the actual cell ID, source-row ordinal, scalar variable ID, value and unit.

Canonical Graph Metadata retains the binding by stable series identity alongside the renderer-owner marker. A missing required binding fails explicitly; it cannot silently become a scatter plot. Complete scientific snapshots, Clones and portable graphs include both canonical node and cell Datasets and their exact role dependencies. Current bounded projection supports at most 60,000 nodes and 30,000 cells. Filters, grouping and row selection on this extension require an explicitly published canonical submesh; unsupported selections fail rather than changing topology silently. Other native plot kinds retain their existing behavior. A host without the `native_cell_field` capability rejects the binding.

## Retained explicit presentation

Host widget context `retain_presentation 1` opts a prepared model into persistent explicit-view semantics. CORE Dataset Viewer's `datasetViewerScientificIdentity` binds content, schema, public metadata, coordinate calibration and storage revision. Changes confined to user Preview controls/visibility can refresh the guard without rebuilding geometry or resetting navigation. A scientific dependency change still refuses interaction and preserves the previous frame until explicit reconfiguration. Ordinary widgets retain their stricter existing revision policy. This is a host-only presentation capability; it creates no alternate Dataset or source identity.

Native wheel, pan and double-click Fit now treat a rejected source/controller as
an inactive previous render. The first rejection records its message/options and
reports it through nonmodal status; subsequent pointer events leave the retained
frame untouched. Successful explicit `widgetConfigure` validates source checks
before changing native buffers and then re-enables interaction. Direct public
operations retain their strict revision/Session errors. This dev109 event-boundary
correction requires focused positive, stale-source and Render-recovery GUI tests;
it does not weaken scientific validation or certify an untested original Session.

## Planar cell field presentation through Native3D

`cellFieldSourceIdentity spec` validates a single complete cell-field panel and
returns its spec, both canonical scientific identities and coordinate contexts.
`cellFieldNativeScene spec` returns the same exact node/triangle/cell-value
projection used by the 2D owner, an ordinary Native3D scene and its source identity.
Use `native3DViewportBind handle {kind cell_field spec ...}` for the managed
interactive lifecycle. These operations neither publish a Dataset nor run a Job.

Coordinates are compatible physical lengths; field amplitude retains its own
unit and cell association. Z=0 expresses a planar display embedding. There is
no centroid triangulation, nodal interpolation, fictitious thickness or volume.
Initial framing delegates to the existing native Fit Scene service.

`cellFieldProfileSpec fieldSpec` authenticates one complete canonical cell-field
binding and returns a source-bound scatter of the actual stored cell-centroid X
and cell scalar, including all Y locations. It performs no interpolation,
centerline selection or new scientific calculation. The original EM Viewer and
Builder Host share this adapter. Its profile is an independent numerical chart;
only the field scene requires linked node geometry.


### Cell-field color normalization

`cellFieldNativeScene` supplies the existing native layer `scalar_range` explicitly.
Its `scalar_display` receipt preserves full-precision `source_scalar_range`, the
separate `color_range` and `display_range_expanded`. As in Native2D, a scalar span
at most 1e-12 of its magnitude uses a five-percent display margin (minimum scale
1e-300), with finite bounds. This avoids exaggerating floating-point roundoff in
an effectively constant field. The margin is a color display choice, never a
measurement uncertainty, a new physical range or a change to stored values.
The caption identifies coordinate/scalar units, Z=0 and an expanded display scale.
Nonconstant data retain their actual range. Canonical cell values, node/triangle
identities, source revisions and coordinate transformations remain unchanged.

### Scientific 3D scalar labels

Automatic colorbar labels describe the actual scalar binding: C when explicitly
bound, otherwise Z. An independent C uses its public variable label and scalar
display unit, including an explicit C that uses the same Variable ID as Z.
`color_unit=auto` retains C's source unit for an explicit binding;
without C it follows Z's display unit. An explicit color unit takes precedence.
Z's coordinate-only level-scale suffix is not added to the untransformed scalar.
An explicit `colorbar_label` still overrides the automatic text. This changes
descriptor text only; scalar values, coordinate transformations, source guards,
PlotSpec identities and the existing table/grid preparation defaults are retained.

`interactiveStatus` also checks the retained figure's scalar label against this
current contract, including manual override. An unchanged source fingerprint
does not make an older Z-for-C label current: that representation reports
`OUT OF SYNC` and the existing explicit Sync operation can replace it. Status
inspection leaves the stored representation and canonical source untouched.

Prepared 3D layers also receive the effective per-plot `marker_size` and
`line_width`, with per-plot values preceding inherited graphics defaults.
`marker_size` maps to the existing public Viewer Layer `point_size`; both styles
pass its finite `(0,64]` validation before native use. This changes presentation
parameters, not coordinates, source-row identities, scalar values or geometry.
Existing independently saved scene styles are not rewritten by this projection.
Explicit Sync also retains compatible saved `point_size` and `line_width`,
including when synchronizing an inactive representation after Session reopen.
An older representation without those fields receives the current source's
validated defaults. Source Plot settings and each saved view retain their
separate persistent identities.

Scientific `scatter3` layers request native screen-sized points through public
Viewer Layer `sphere_glyphs=0` and `representation=points`. Their marker size
stays in pixels when physical axes use different units and independent scales.
Explicit saved point/sphere choices survive Sync; an older unset choice receives
the scientific point default. This requires the public Viewer Layer capability
from CORE commit `2c2e2fb`; no engine, source values or physical units change.


## Inert native host reference

`widgetVisibility path panel series visible` changes the presentation visibility
of the selected native panel/series. It returns a dictionary containing `widget`,
`model_token`, `panel_id`, `series_id` and `visible`; it preserves canonical
source data and the existing widget's strict Session/source guards.

The provider descriptor declares exact named formals, parameter/result types and context for the current native widget lifecycle and the four cell-field adapters, including `widgetValidateSources spec ?context?` and the existing `widgetEdit path spec` companion. API Browser reads this metadata without invoking those operations. These Tcl host methods do not grant new Script Bridge or C++ SDK calls. `widgetView` and `widgetDestroy` have no stable scientific-result return; query `widgetReceipt` for authoritative view state. Cell-field profiles retain all actual centroid samples, and their Native3D presentation remains a planar XY mesh with Z=0 and scalar color, never a CAD volume or a new simulation.

Finite line runs containing one actual sample use the native circle painter even
when the retained line style has no general markers. This keeps isolated finite
observations visible between missing-data gaps without connecting those gaps,
changing point/row identity or adding interpolated samples. Ordinary multi-point
line runs retain their configured style.

## Shared GUI chrome (DEV111-P006)

Host-only `::GX::PlotDatasetAPIv4::widgetChrome path` returns an existing/shared
Native2D ViewportHost for GUI panels over this Plot surface. It validates the
ordinary Plot source/Session binding, uses native plot bounds and creates no
scientific scene or controller. Zoom/pan/Fit remain Plot-owned. See
[Preview Component GUI API v1](PREVIEW_COMPONENT_GUI_API_v1.md) for scoped use by
Preview components. This adds no native provider or SDK operation.

## Generic Comparison profile (P034)

Optional PlotSpec.comparison uses GXTXT_COMPARISON_PLOT_v1 through the same
native renderer and existing Graph/PlotSpec resource. CORE admits actual source
pins; Numeric prepares five modes without fake canonical Graph Series or payload
publication. Top/Bottom synchronizes X zoom/pan/retained restoration while keeping
independent Y scales. Invalid ranges and contradictory X restoration are atomic.
`widgetComparisonReceipt(path)` returns the source-validated scientific receipt.
Missing/stale references refuse without deleting the saved comparison or binding
a neighbor. Ordinary empty PlotSpecs still refuse; comparison cannot mix another
canonical series owner. The old Workbench comparisonModel remains distinct.
See [Comparison API](COMPARISON_PLOT_API_v1.md).


Comparison PlotSpec presentation uses the same complete `validateSpec` boundary
before numerical preparation and native frame replacement. CORE projects the
existing panel annotations and versioned display-series styles onto the derived
model while retaining its computed physical units. Scalar style fields, primary
Plot commands and existing Graph/Workspace persistence are documented in
[COMPARISON_PLOT_API_v1](COMPARISON_PLOT_API_v1.md).

## Complete interactive Plot window (DEV112-P009)

`openInteractive ref`, `openRepresentation id`, `syncInteractive id` and
`refreshInteractive ref` open the existing full Native3D host for retained v4
XYZ representations. The compact Dataset consultation remains a separate
read-only preview. The full Plot window exposes the original reversible view
sidebar, camera/projection, lighting, layer presentation, navigation and PNG
export controls.

The original Plots tab retains its existing Axes and Variant controls for
source ranges, units, kinds, bindings and graphics. No duplicate 3D action or
additional source-action strip is introduced. The public `syncInteractive`
operation explicitly refreshes a retained representation through its original
Workspace owner. Successful native redraw and close retain the independent
Viewer scene; source Plot and Dataset identities remain independent.

Sync retains user navigation and compatible layer presentation. An optional
`source_view` receipt records the generated source presentation so a changed
source projection/background reaches the refreshed scene while unchanged source
settings preserve the saved interactive view. Old representations without this
receipt remain readable. Scene activation does not resave the pre-Sync live
transform over the rebuilt payload when native geometry bytes are unchanged.
Integer and fractional manual axis limits use the same floating-point normalized
frame, and producer labels already carrying the displayed unit are not suffixed
with that unit a second time.

Scientific v4 layers carry the source-owned `plot_v4_rgb` array. Native3D direct
RGB takes precedence over layer scalar-LUT and base-color fields. Those
inapplicable layer fields are disabled with an explanation; the original Plots tab **Axes...** remains the working colormap, colorbar and
CLim editor, followed by
explicit Sync. Direct layer calls that would silently change an overridden field
now refuse before writing. Layer line/point size controls follow their actual
surface/wireframe/trajectory/points applicability. A failed native layer render
restores its prior authoritative layer fields and presents an owned error dialog.
The toolbar reports the retained representation's source synchronization status.

Camera presets, Fit, the navigation cube and mouse navigation retain the native
projection receipt's orthographic height and clipping distances in the same
Viewer scene. Orthographic wheel zoom uses the existing native projection zoom
operation, rather than a camera dolly that leaves orthographic scale unchanged.
The saved/cold-restored frame therefore uses the actual native magnification.
When converting units, a recognized source-unit suffix is replaced by the
requested display unit rather than displaying both old and new units.

Changing/activating a retained representation or explicitly saving it while a
native render/navigation transaction is in flight refuses with a finish/cancel
message before replacing shared layers. Automatic intermediate redraw does not
save ahead of queued navigation. Historical explicit XY Graph Series ignore an
unused inherited Z binding both in runtime admission and in their scientific
data-cache fingerprint; XYZ bindings retain their existing behavior.

Native Fit Scene/Object/Selection now clears an earlier explicit orthographic
height after the original successful bounds-based camera fit. The existing
camera-distance/FOV policy supplies the fitted height. Orientation-only presets
retain magnification; scientific geometry and the public native ABI are unchanged.


Scientific axis rendering rebuilds its disposable VTK CubeAxes presentation prop
for each completed frame. This invalidates projected label/follower caches after
navigation and Fit, so a same-pose full rerender and cold reopen use the same
label layout. The retained figure labels, geometry, camera and C ABI are unchanged.


For native XYZ plots, Axes obtains available display units from the exact
canonical Variable binding when a native PNG has no legacy pixel calibration
receipt. This includes affine K/°C conversion; no Dataset values or 2D selection
metadata are fabricated. Contour geometry uses its original displayed Z values,
while its separately converted scientific color scalar retains its own unit and
range. The existing ASCII vector axis font displays conventional `degC` and `u`
unit spellings, so degree/micro symbols cannot silently disappear; canonical unit
identities retain their original registry spellings.

Explicit XYZ major steps and numeric tick formats now reach the existing native
scientific figure. Steps start at the displayed minimum (at the displayed maximum
for a reversed axis); log axes apply the step in log10 coordinates. The existing
64-label budget is enforced before rendering. Every requested tick/grid position
is retained; projected label text is thinned where its requested format would
overlap. The original VTK CubeAxes/Axis actors, camera and native capture pipeline
own this presentation, including the complete final frame after initialization.

The disposable scientific VTK actor initializes its original tick/follower layout
once under restored VTK OpenGL state before its visible draw. Native capture
reads the completed frame without a hidden second render. PDF retains the
original GL2PS route. SVG is a self-contained, raster-backed serialization of
the exact completed native PNG frame: it preserves geometry, scientific axes,
text and overlays, but does not expose editable vector primitives.

The six native_style tick-start/step fields are optional typed Workspace fields.
Older saved figures without them retain their original automatic tick behavior;
opening them requires no migration, sidecar creation or document rewrite.

### Registered client source values and headless Sync

Python and Octave PlotSpec readback preserves nested axis structures. Native
presentation values use the original Workspace presentation codec, including
level-scale records and panel projections; literal source settings remain text.
The effective presentation still follows the authoritative original graph/axis
configuration and applicable panels.

`sync_interactive` rebuilds the original persistent scientific representation
and records its source fingerprint through the existing Workspace owner. In a
headless registered client it completes without opening a Tk desktop; v4 returns
an empty `window` field. In a real Tk host the existing interactive window opens
as before. Normal Workspace ownership and single-writer refusals remain active.

### Original scientific 3D legend presentation

Native consultation projects the original provider `legend_content` and CORE
Legend settings through the prepared presentation. For a single gridded field,
provider `auto`/`none` remains empty unless the original CORE Legend override is
active; an active override admits the existing single-field series label, as
in the original Source renderer. Provider `series` remains applicable without
that override. An optional text-valued
`native_presentation.legend.source_override_enabled` carries this existing
precedence through registered clients and frozen scientific captures. It does
not change the Source graph's Registry owner or add another legend store.

For genuine historical Source graphs with Family bindings, native preparation
obtains resolved labels and layout from the original guarded prepared exporter.
Its metadata-only mode uses the same Source/cache/config/module/binding and
coordinate guards, but does not invoke the older geometry converter's unrelated
log/reversed-axis or group-count limitations. The original legend owner exports
its actual effective placement, rows and columns after fitting. Canonical Family
keys remain separate from formatted prefix/unit labels and are matched through
the existing declared-dtype canonical-member owner; ambiguous historical integer
identities are refused rather than compared after binary64 rounding.

The safe resolved projection is carried as optional text-valued
`native_presentation.legend.prepared_source`. Frozen captures retain it through
the existing presentation codec. Explicit new presentation edits retain priority;
unchanged Clone form values preserve the original automatic intent. A private
hashed preparation input carries only the caller-guarded command across the
existing worker boundary, so a newly created unsaved live Variant does not need
a forced manifest save. This command is never stored in PlotSpec or Workspace
presentation. Source pixels, Registry ownership and scientific values are not
rewritten by metadata preparation.

Native-owned authoring stays on the existing native path, without an Octave
metadata dependency. Its Family prefix uses the public Variable canonical name
for blank/auto, or the explicit `family_label_prefix`. Explicit
`family_display_unit` uses the existing Dataset coordinate/Unit Registry owner;
source/none preserves exact categorical identity values. Native auto follows the
Dataset's captured display-unit preference, which is the source unit by default.
Historical Source auto retains its original prepared automatic-unit policy.
The effective preference and coordinate revision participate in the existing
Source fingerprint and frozen `native_presentation.plot_config`; changed live
preferences stale retained views without rewriting their payload. No SI-prefix
or time-unit selection algorithm is duplicated in the native adapter.

The original scientific figure text actor draws the legend. Inside/manual
annotation props share the existing figure's foreground composition so filled
scientific geometry cannot paint over them. External placements reserve a band
measured with the original VTK text metrics; start/center/end aligns the whole
box. Inside presets fit within the data viewport; manual coordinates retain
the existing normalized figure-center meaning. The original calibrated
CubeAxes fitting owner accounts for the measured legend box. Declared fonts,
ticks, source coordinates, aspect and camera are preserved. An impossible
layout reports an owned size diagnostic instead of clipping text or silently
shrinking the declared font.

Optional typed `scientific_figure.native_style` fields are `legend_placement`
(0 original/default, 1 inside, 2 below, 3 above, 4 left, 5 right, 6 manual),
`legend_external_alignment` (0 start/top, 1 center, 2 end/bottom), and
`legend_margin_px` (nonnegative pixels), and `legend_wrap` (optional boolean).
For an overwide multi-entry row, the same original VTK text metrics flow text at
its visible separators; fonts, text, camera and scientific coordinates remain
unchanged. Existing rows that fit and old records without this flag retain their
original rendering. A single overwide entry still reports the owned fit error. Existing numeric style-set/get transport
and the original Workspace figure codec own these values. Old records with
these fields absent keep their original rectangle and require no migration or
rewrite on read. A changed derived Source presentation may require explicit
Sync; opening an old representation does not rewrite its saved payload.
A required legend omitted by an older adapter also reports OUT OF SYNC even
when its stored Source fingerprint matches; explicit Sync repairs that figure.
The same scientific viewport rectangle remains authoritative for native
rendering, panning and world/screen projection.

Historical scientific Source consultation retains its original automatic
scalar-colourbar default. Effective plot-specific colourbar choices take
priority; an inactive or inherited Source override uses the existing native
kind default. Native-v4-owned authoring keeps its normal graphics inheritance.
The existing Source fingerprint hashes this same projection, so older derived
views require explicit Sync without being rewritten by a status read.

Effective layout maps use deterministic key order. Reopening a Session or
reordering equivalent named layout settings does not change the Source
fingerprint; changing a layout value still does. Existing stored views are
not rewritten by status inspection.

### Native 2D legend layout

Native 2D legends use the existing PangoCairo text metrics and painter. The
complete measured box reserves space beside the scientific plot; font size,
labels, columns and row heights are retained. External `alignment` positions the
whole box: start/center/end means top/center/bottom for left/right and
left/center/right for above/below. `stacked`, `row` and `wrapped` retain their
selected column policy.

Manual X/Y specifies the box center in normalized figure coordinates (Y grows
upward). In multiple panels, each box is clamped to its owning panel, following
the historical panel policy; the receipt records the requested center and whether
clamping was necessary. This prevents one panel legend from hiding another.
Inside captions may wrap at existing text boundaries while retaining their exact
source labels. A layout that cannot fit the complete box and useful scientific
axes refuses explicitly instead of clipping or shrinking the declared font.

The additive native `legends` receipt reports panel/series identity, measured
box and text boxes, placement/alignment and metrics owner. Painting, hit testing,
plot rectangles and export metadata use that same completed layout. Scientific
samples, axis ranges, units and source pins are unchanged by legend placement.

### Source and local 3D layer presentation on Sync

Historical XYZ references keep their original Source displayed-unit Step
semantics. An active logarithmic axis with an explicit historical Step cannot
be projected faithfully through the current native uniform calibration; native
render/export, preparation, consultation and scene build/open refuse it with
axis-specific clear-Step/automatic recovery guidance. This does not block the
original v3 Octave Source renderer or read-only spec/source/fingerprint queries.
Native-v4-owned logarithmic Step retains its decade meaning. Automatic legacy
log axes, linear steps and inactive overrides retain their existing behavior.
The original Plots preview shows this applicability reason in its existing
diagnostic surface when the 3D entry is hidden. Clearing Step removes that
diagnostic and restores the original entry; no extra action is introduced.

A saved representation containing the older mismatched tick projection reports
`OUT OF SYNC` while this setting remains active. Status/open do not rewrite its
stored payload or migrate the Source. Clear the explicit Step and explicitly
Sync or rebuild through the original owner to obtain a compatible view.

The original persistent representation retains an optional typed
`source_layer_presentation` receipt for the styles generated by its Plot source.
When a source style changes, explicit Sync applies it to the original native
layer. A local Viewer edit is retained while that particular source style stays
unchanged. This covers line width, point size and representation as well as the
existing retained presentation fields; numeric formatting differences do not
turn an unchanged numeric style into a source edit.

Opening an older document without this receipt does not migrate or rewrite it.
Explicit Sync establishes the receipt. With an unchanged source it retains the
older document's local styles; with a changed source it admits the current
source representation, line/point and colour settings while preserving local
visibility, opacity and navigation. Canonical Dataset values, geometry and source
identities remain governed by their original owners.

### Existing 2D axis controls

The native model now applies numeric tick formats from the original CORE
axis presentation owner, including per-panel Left and Right Y overrides.
Explicit custom X tick labels retain priority. Automatic/inherited formats
retain their existing output. Numeric formats accept one bounded floating
conversion; invalid formats refuse rendering without replacing the prior image.
Positive major steps are admitted on both Y axes as well as X: linear steps
use display units and logarithmic steps use decades. Native tick receipts and
the completed image share the same labels and positions. These presentation
edits do not change canonical data, units, source identities or calibration.

The existing native Viewer Background RGB owns a flat backdrop. The stored
Gradient bottom RGB is retained while gradients are off and becomes effective
when Gradient background is enabled. The original scientific figure backdrop
uses the same view colours and gradient flag as its native scene. This fixes
projection of the existing fields without changing native C API set/get
semantics, saved Workspace fields, source data, camera or declared fonts.


### Original axis-control boundaries

Native 2D uses the saved series order for both drawing and legends. Panel grid
policy, colour and Y-axis source override the inherited global grid settings.
An explicit Left or Right Y-grid source enables that axis grid; None disables
it. Automatic logarithmic minor grids use 2 through 9 in each decade.
`ylabel_x` positions the Left caption relative to its panel; Right captions
retain their existing automatic layout. Equal numeric aspect requires linear
X and Left Y and one enabled Y axis, as in the original Native2D contract.
Unsupported dual-Y or logarithmic combinations are refused before GUI save.

Numeric tick formats retain one bounded floating-point printf conversion,
including literal prefixes, suffixes and `%%`. Invalid conversions are refused
before saving the Axes draft. Historical v3 render-time refusal preserves the
previous PNG and its geometry metadata. Explicit logarithmic major spacing is
measured in decades for Plot Dataset 2D in both renderers.

The original historical GNUplot/PostScript/Ghostscript path declares exact PNG
pixel media when the requested physical size has fractional points. It retains
the same PostScript, renderer, DPI, fonts and scientific geometry; the original
integer-point path is unchanged. This prevents integer EPS bounding boxes from
truncating a requested 1200 by 720 pixel canvas to 1200 by 719.

The existing native 3D `line3` and `contour3` kinds do not support an independent
C binding. They retain their explicit refusal with guidance to clear C or choose
another scientific kind. Surface and mesh support their original independent C
path.


The original compact 3D preview wheel uses the existing native orthographic
zoom operation when that camera mode is active. Optional CAD projection metadata
does not control whether scientific zoom takes effect. Perspective navigation
retains its original dolly behavior. The existing preview controller retains the
authoritative orthographic height for subsequent render requests; no controls or
window layout are added.


Blank or inherited grid colors retain the original native default ink instead
of hiding an otherwise enabled grid. Original global and panel grid policies
continue to use their established precedence. The original Axes dialog refuses
equal numeric aspect with logarithmic X or Left Y before committing its draft;
the renderer's existing linear-coordinate restriction is unchanged.

Original native Fit/preset replies include the actual orthographic height so
the existing preview controller retains that view on the next render or orbit.
This changes the view receipt, not the source Dataset or window controls.


Original Fit/preset replies also retain the native camera's field of view and
near/far clipping range. The existing preview view-state owner already accepts
these fields; it can reproduce the actual fitted frame instead of reusing stale
clipping values.

Historical Graph ZIP export includes the original numerical snapshot, portable
presentation and PlotSpec. Regenerated graph.svg/graph.pdf outputs are omitted
from scientific-source members, just like graph.png; the selected PNG is kept
as the graph preview. Scientific import reproduces the original image. Incoming
package validation still refuses undeclared executable or unsupported resources.


The original Variant Manager **New from base** action assigns newly authored
Plot Dataset variants to the existing v4 renderer owner. It retains the same
source/configuration editor and canonical PlotSpec v2 schema. **Duplicate**
preserves its source's renderer ownership, including historical v3 documents;
explicit historical API calls and existing plots are not silently migrated.

Read-only 3D consultation uses the current effective PlotSpec, including original
Axes and Variant settings saved before an explicit Session manifest save. Its
existing preparation worker receives a private hash-checked disposable input;
it does not persist unrelated Session configuration or create another document
store. The original source fingerprint/revision checks remain effective. A
returned preparation command is an opaque argv list and must be executed intact.

The existing native scientific owner preserves requested major tick and grid
positions and numeric formats. It may thin numeric text when the projected
glyphs cannot fit, while retaining the underlying calibration. Cross-axis
intersections use the same original follower-placement owner without changing
fonts, source coordinates or camera state. Explicit unavailable mathematical
colormap names are refused; auto/inherit/default and installed palettes retain
their original behavior.

Scientific Clone presentation edits preserve their frozen Dataset archives.
The existing size fields report uniform visible series sizes and explicit edits
update retained per-series overrides. Grid edits reach the retained panel
overrides; the original `inherit` selection uses native grid inheritance.
Snapshot rendering stages its image and calibration through the existing
Resource owner before publication. A live-descendant retirement refusal leaves
the previous image, calibration and presentation intact; it never forces a lease
release. A normal retry after the owned descendant finishes remains supported.

CORE-created family members retain their exact row filters, stable series IDs,
ordering and source-row bindings when projected to PlotSpec and native models.
An already expanded exact-equal family member is rendered directly; unexpanded
family declarations continue through the original group planner. The existing
historical Bridge writer notifies the original Plots Refresh cache after a
successful manifest write, preserving v3 ownership without a Session reopen.

The shared scientific Clone editor maps its Y caption and range fields to the
actual XYZ Y axis for 3D snapshots. A title-only complete-form save preserves
the frozen XYZ labels and limits. Inherited line sizes resolve through existing
graphics defaults. An empty secondary-Y field is ignored for 3D; an explicit
nonempty secondary-Y request is refused before mutation because XYZ has no
secondary Y axis.

The original complete Clone form admits the native owner's automatic bounds.
Unchanged first-panel captions and limits remain unchanged on other panels
during unrelated presentation edits, such as Gap. Explicit changed global
fields still use the existing global override semantics; an explicit full-spec
caller retains its requested override semantics.

The shared panel-ID query returns an empty 2D panel set for XYZ plots. Existing
Title and labels and Graph information interfaces can inspect XYZ without
assuming a Cartesian2D panel dictionary; their original XYZ fields are retained.
Historical pre-read window planning also honors the established CORE axis
authority: a declared automatic state cannot crop source rows through stale
PlotSpec bounds. Explicit safe CORE windows and undeclared PlotSpec fallback
retain their original behavior.

Original Plot controls retain the accepted Plots tab and existing 3D entry.
Native stacked panels share one measured X rectangle for rendering, hit tests
and interval selection. Tick strings, automatic aligned Left captions and the
X-caption band use the existing renderer metrics. Transparent chart export
preserves real alpha and ordinary opaque rendering. Numeric Graphics values
must be finite and positive; invalid editor drafts are refused before saving.

The retained historical renderer applies declared CORE Restore Auto to each
panel and both Y sides, including display units, while retaining provider
limits when no CORE authority is declared. Wide formatted ticks use existing
font measurements and reserve caption clearance. Automatic large-font single
plots reuse existing content, legend and title layout; explicit manual margins
retain priority. Fitting ordinary layouts remain unchanged.

### Original 3D display reduction

Native 3D preparation resolves the existing per-Variant `reduction_mode` and
`target_points` over the Plot Dataset module's mode, target and
`auto_reduce_threshold`. Inherited settings remain literal inherited settings;
their effective module values participate in the original source fingerprint.
Changing an inherited budget therefore requires the normal explicit Sync of a
retained representation. The canonical Dataset is never rewritten.

The native geometry adapter follows the original `pd_prepare_3d` policies:

| Source / kind | Existing display policy |
| --- | --- |
| Long-form rectangular surface, mesh, contour3 or heatmap | `none` retains all grid samples; `stride` retains sampled grid coordinates and final endpoints. Above the automatic threshold, `auto` selects maximum Z per display bucket; explicit `minmax` selects largest absolute Z. The chosen C and source row remain paired. |
| Canonical rank-two Y/X grid | `none`, `stride`, and thresholded automatic stride retain actual logical cells and their column-major source ordinals, including descending axes. `minmax` is refused because it would relocate canonical cell values. |
| line3, scatter3, trisurf | Existing proportional per-family stride with final endpoint retention; `auto` activates above the module threshold. The historical `minmax` behavior is the existing `stride_3d` policy. |

Grid stride is the original `ceil(sqrt(source_count / family_target))`, with
both final axis endpoints retained. Target points are approximate: endpoint
retention and grid shape can produce more or fewer points than the target.
The complete source grid is validated before display reduction; a duplicate or
missing unsampled cell cannot be hidden by a display budget.

For long-form peak buckets, Z is displayed at the original sampled grid anchor,
while C and the selected source-row identity refer to the same original chosen
sample. This is the existing display-bucket policy, not a new scientific
interpolation or a claim that the anchor is that sample's canonical X/Y. The
geometry receipt identifies it as `display_bucket_source_row`. Exact stride
samples retain `source_row`; derived contour vertices retain their existing
`derived_contour` identity. Source coordinates remain available from the
canonical Dataset, independently of these display derivatives.

The original geometry receipt reports requested/effective reduction, full
source counts and displayed sample counts. Explicit Variant targets must be
finite integers in 100..8000000. Existing source-axis and displayed-grid resource
limits remain enforced. Failed preparation retains the previous published
artifact and representation and does not leave a staged source channel open.

The original VTP artifact persists this preparation provenance in FieldData:
requested/effective reduction, source layout, point/input-sample identity kind,
full source and displayed counts, and full-source scalar range. Peak-bucket
outputs also retain `source_display_coordinate` PointData: the selected sample's
XYZ in the staged display coordinates before grid anchoring and native log
projection. The existing source-row and C arrays remain paired with it. Derived
contours remove interpolated source-row/coordinate claims and retain their
explicit derived identity. The original layer's resource checksum covers these
bytes across Workspace save/reopen; no additional provenance store is created.

Resolving an inherited display budget changes the derived live source
fingerprint when effective module settings change. It does not rewrite an old
saved Workspace, its stored fingerprint, VTP resource, generation or revision.
A stored older fingerprint may truthfully require explicit Sync; merely reading
or opening the saved record does not migrate it. Frozen scientific captures
use the existing snapshot/export owner to retain effective mode, target and
threshold in native_presentation.plot_config. Their rendering stays independent
of a later Session's module defaults; the live Variant keeps literal inheritance.

The existing preparation worker captures the same effective inherited budget
as scientific snapshots, including unsaved module settings, without forcing a
Session save or changing live configuration. Source fingerprints and Dataset
values remain with their original owners.

Original Global/Module Graphics reject non-finite numeric settings; blank module
aspect retains its documented parent inheritance. The original Variant editor
validates only fields it actually owns, preserving the omitted Background
field's Axes authority. XYZ Axes keep their original controls but disable the
unavailable secondary-Y and 2D-aspect entries; forced unsupported edits refuse
before mutation while old unchanged stored fields remain compatible.

Family category selection retains canonical scalar text through filtering,
group identity and labels. The existing effective presentation also captures
CORE family category colors and line styles. Native rendering uses those values
where the provider series has no explicit style, matching the historical
fallback. Explicit provider colors and automatic-color requests retain their
precedence. A frozen scientific Clone retains its captured category styles when
the live Graph Series colors later change. The existing typed Plot presentation
codec carries this nested map through both Python and Octave public calls.

Failed native Plot rerenders preserve the original bounded diagnostic in the
existing Analysis error dialog, including empty or incompatible XYZ source
failures. Detailed execution logs retain their existing owner and location.

The historical display helper routes explicit
compatible units such as Kelvin to Celsius through the existing unit converter;
automatic Kelvin and original time/SI policies remain unchanged. Contour3 keeps
its documented requirement that its coupled Z/Color units match.

### Automatic scientific 3D title

For Dataset-backed XYZ plots, a case-insensitive `auto` title uses the original
3D Plot contract: `Z vs X / Y`, with each bound canonical Variable name's
underscores displayed as spaces. The existing public Variable metadata supplies
those names; axis display-unit changes do not rename the source variables.
Native figure and consultation caption use the same resolved title. Explicit
CORE title precedence remains unchanged. Blank/no-title, other literal titles
(including `inherit`) and transient curve labels keep their existing behavior.
Only disposable presentation is resolved; source config, Dataset values, source
fingerprint and saved source identities are unchanged.

## P011 unpublished Native3D draft host

The trusted host methods `previewSpecSource(spec)`,
`previewSpecExportCommand(spec,directory)` and
`previewSpecScene(spec,expected,directory)` use the same canonical Dataset,
coordinate context, original worker and validated scene/layer intake as the
existing Native3D preview. The returned source key pins the exact Session, draft
and public source identity. A source change during preparation refuses adoption.
These methods do not publish a Graph, Variant, Dataset or Document.

`previewSpecAcquire(parent,spec,options={})` returns the original asynchronous
host. The only option is boolean `controls_visible` (default true).
`previewSpecReceipt(host)` exposes actual ready/busy/pending/source/view/render
receipts and `controls_visible`. `previewSpecControls(host,visible)` changes only
the existing camera-control overlay. `previewSpecCamera(host,action)` admits
left/right/up/down/cw/ccw/fit/reset through the original camera owner.
`previewSpecRelease(parent)` releases only that parent's original host. Actual
canonical source, Session and owned Tk/native host lifetimes remain mandatory.
No generic Script Bridge registration or caller callback/executable grant is added.

Complete native camera presentation retains optional vertical_fov_degrees through
the existing scene3d/independent representation Workspace codec. Its range is the
same declared0.01..179.99degrees; absent values retain original defaults.

### Requested and effective Native2D view limits

The existing `NATIVE_PLOT_BACKEND_v1` advertises the additive
`requested_axis_limits` capability. Each axis in `widgetReceipt` includes
`requested_limits {min max}` alongside the existing effective display `limits`.
For `xy_equal`, Native2D returns its retained request before aspect expansion;
for other axes these equal the existing limits. Neither rendering nor geometry
changes. Persist `requested_limits` for an interactive view and pass them as
`limits` to the existing `widgetView ... restore` operation. Feeding effective
aspect-expanded limits back as requests can progressively widen a saved view.
Curve Viewer refuses equal-aspect persistence with an explicit missing-contract
message when a mismatched adapter omits this field. No framework patch number
is used to negotiate the contract.

### Complete PlotSpec comparison

`specEquivalent first second` is a trusted Tcl host operation returning a
boolean. It validates both complete specifications with the existing v4 owner,
then uses the existing CORE `plot_spec` codec and native JSON encoder. Only
object dictionary-key order is canonicalized. Array order, physical numeric
values (including signed zero), text, units, source bindings, styles and all
declared fields remain part of the comparison. Numeric spelling follows the
original typed codec. Unknown/invalid fields are refused by that codec rather
than omitted. This operation does not mutate either specification, publish or
render, and grants no Script Bridge authority. Ordered native Workspace and
History equality are unchanged.

Curve Viewer uses this owner operation for its opened-target conflict guard.
An original-owner rollback that changes dictionary insertion order can then be
retried without reopening; a real external PlotSpec change is still refused.

Failed Viewer Update rolls back only an applied target that still matches the
original public owner's post-apply snapshot and retains v4 ownership. A genuine
intervening edit or unverifiable target is preserved and named in the failure
status; a pre-apply conflict does not write the target.
