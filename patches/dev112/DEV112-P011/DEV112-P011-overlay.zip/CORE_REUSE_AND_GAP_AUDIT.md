# P011 CORE reuse and remaining limits

| Work | Existing authority retained |
| --- | --- |
| Run | Analysis descriptor policy, Registry source preflight, original Python/Octave Run queue, ScriptJob and actual terminal/publication receipts. |
| Curve Viewer | Plot v4/v2 PlotSpec, Graph Series, units, Native2D widgets/picking, original Native3D worker/host/camera, Graph/Variant/manifest/main Plots, Workspace and History. |
| Advanced controls | CORE exact predicates/families/comparison, original cell-field projection, independent3D representation Open/Sync/status, provider consultation and scientific Clone/snapshot owners. |
| Curve Fitter | Original numerical fit/source/resource owners; exact receipts, CORE auxiliary History, Document/Workspace codec, publication and confirmation/backup guards. |
| Plot conflict comparison | Public Plot owner specEquivalent reuses original validation and typed plot_spec/plot_xyz_spec/JSON codecs. The existing XYZ shape is shared by CORE and the original Viewer alias without changing persisted bytes. It canonicalizes only comparison-copy object keys; native ordered History equality and all persisted data remain unchanged. |
| Equal-aspect persistence | Native2D retained aspectRequest is exposed in the public receipt. Curve Viewer saves requested limits; existing geometry projection still determines effective limits. No duplicated aspect mathematics or hidden history normalization. |
| 3D occupancy | Existing Native3D figure_rect and text layout; same source geometry, camera, projection and explicit margin policy. |
| MCP | Pinned standard SDK transports, public original Script Bridge metadata/runtime API catalog, protected adapter configuration, authentication/grants, original Registry/Job/Resource authorities. |

No second numerical fitter, renderer, camera model, Dataset registry, scientific
comparison implementation, resource store or scripting transport is introduced.
The narrow new Plot v4 draft3D facade prepares the original canonical scene and
uses the existing worker/host; previews create no Graph or Dataset.

Version1 Curve Viewer Workspaces are preserved read-only. Explicit conversion
maps only supported canonical bindings, predicates/row ordinals and matching
styles. Visible direction markers and unsupported source options require a named
conversion rather than silent loss. Prepared private geometry is never adopted
as canonical data. Legacy snapshot callers receive a versioned incompatibility
error and may use v2 nativeReceipt.

The original scientific snapshot format does not detach derived comparison
sources. Preserve comparison Workspace and canonical sources; use original
rendered-image capture when an image-only Clone is intended. Existing renderer
kind/binding limitations remain explicit public validation errors. Native3D SVG
retains its original raster representation, not editable vector geometry.

MCP generic invocation remains governed by its explicit client grant and the
original operation owners. Missing optional APIs disable their specific feature;
missing runtime Bridge contract/version/profile/transport produces a precise
context error. Framework patch identifiers never substitute for these checks.
MCP protocol/SDK compatibility is independently enforced by standard SDK rules.

Independent evidence is candidate-specific. Native geometry occupancy is judged
with fixed scientific fixtures/camera and visible labels, separately from widget
size. Accessibility and performance claims are limited to actually executed
checks. Exact acceptance is defined by the accompanying hash-bound release records.
