# Session-centric Run page and transparent execution plan.
# SPDX-License-Identifier: GPL-3.0-or-later
namespace eval ::GX { variable runPlanState }

proc ::GX::runPlanInputs {id} {
    variable moduleCfg
    variable moduleAnalysisSource
    set inputs {}
    if {[moduleSupportsAnalysisSources $id]} {
        foreach row [analysisSourceRows $id] {
            set source [expr {[info exists moduleAnalysisSource($id,$row,id)] ? $moduleAnalysisSource($id,$row,id) : "primary"}]
            set dataset [expr {[info exists moduleAnalysisSource($id,$row,dataset_id)] ? $moduleAnalysisSource($id,$row,dataset_id) : ""}]
            if {$dataset ne ""} { lappend inputs "$source: $dataset" }
        }
    } elseif {[info exists moduleCfg($id,dataset_id)] && $moduleCfg($id,dataset_id) ne ""} {
        lappend inputs $moduleCfg($id,dataset_id)
    }
    return [join $inputs {; }]
}

proc ::GX::runPlanEntries {} {
    variable moduleOrder
    variable currentSession
    set out {}
    set order 0
    foreach id $moduleOrder {
        # CORE workspace replacement controls Analysis panels, not execution
        # eligibility. The Module owner defines Analysis identity for Run.
        if {![moduleAnalysisEligible $id]} continue
        set enabled [moduleIsEnabled $id]
        if {!$enabled} continue
        set selected [moduleRunIsSelected $id]
        set runner [moduleField $id runner ""]
        set reason ""
        if {![moduleAnalysisIsShown $id]} {set reason "Hidden from Analysis"}
        if {$reason eq "" && !$selected} { set reason "Not selected for this run" }
        if {$reason eq "" && $runner ni {standard_octave script_execution script_module}} { set reason "No standard analysis runner" }
        if {$reason eq "" && ($currentSession eq "" || ![file isdirectory $currentSession])} { set reason "Open a Session" }
        set status [expr {$reason eq "" ? "PENDING" : "SKIPPED"}]
        set scriptSource [expr {[moduleConfigField $id registered_script type {}] eq {registered_script}}]
        if {$reason eq "" && !$scriptSource && [moduleSupportsAnalysisSources $id] && [catch {analysisSourceValidateModule $id} inputError]} {
            set status BLOCKED
            set reason "Dataset inputs: $inputError"
        }
        if {$reason eq {} && $scriptSource &&
            [catch {scriptAnalysisPreflight $id} scriptError]} {
            set status BLOCKED
            set reason "Script preflight: $scriptError"
        }
        if {$reason eq ""} { incr order }
        lappend out [dict create id $id name [moduleField $id name $id] version [moduleField $id version ""] \
            enabled $enabled selected $selected order [expr {$reason eq "" ? $order : ""}] \
            inputs [runPlanInputs $id] status $status reason $reason]
    }
    return $out
}

proc ::GX::runPlanRefresh {} {
    variable runPlanState
    variable ui
    set tree .top.nb.run.plan.tree
    if {![winfo exists $tree]} return
    if {[info exists ::GX::analysisPipe] && $::GX::analysisPipe ne ""} return
    $tree delete [$tree children {}]
    array unset runPlanState *
    set ready 0; set skipped 0; set blocked 0
    foreach entry [runPlanEntries] {
        set id [dict get $entry id]
        set status [dict get $entry status]
        if {$status eq "PENDING"} { incr ready } elseif {$status eq "BLOCKED"} {incr blocked} else { incr skipped }
        set runPlanState($id) $status
        $tree insert {} end -id $id -text [dict get $entry name] -values [list \
            [dict get $entry order] [dict get $entry version] \
            [expr {[dict get $entry enabled] ? "Enabled" : "Disabled"}] \
            [dict get $entry inputs] $status [dict get $entry reason]]
    }
    set ui(runPlanSummary) "$ready analysis module(s) have valid required Dataset inputs; $blocked blocked; $skipped skipped. Execution performs its normal preflight."
}

proc ::GX::runPlanStatus {id status {reason ""}} {
    variable runPlanState
    variable ui
    set tree .top.nb.run.plan.tree
    if {$id eq "" || ![winfo exists $tree] || ![$tree exists $id]} return
    set runPlanState($id) $status
    set values [$tree item $id -values]
    lset values 4 $status
    lset values 5 $reason
    $tree item $id -values $values
    $tree see $id
    set counts [dict create]
    foreach key [array names runPlanState] { dict incr counts $runPlanState($key) }
    set pieces {}
    foreach state {PASS RUNNING PENDING BLOCKED FAILED SKIPPED} {
        set count [expr {[dict exists $counts $state] ? [dict get $counts $state] : 0}]
        if {$count} { lappend pieces "$state $count" }
    }
    set ui(runPlanSummary) [join $pieces { | }]
}

proc ::GX::runPageStart {} {
    runPlanRefresh
    startAnalysis
}

# This is a projection of the original queue identity, not another Job store.
# Standalone Script Runner, targeted Analysis and rerender cannot update it.
proc ::GX::runPlanQueueBegin {queue operation} {
    set ::GX::ui(runPlanQueue) {}
    set ::GX::ui(runPlanSession) $::GX::currentSession
    if {$operation ne {Selective analysis}} return
    foreach item $queue {
        if {[llength $item] >= 4} {
            dict lappend ::GX::ui(runPlanQueue) [lindex $item 2] [lindex $item 3]
        }
    }
}

proc ::GX::runPlanQueueStatus {id runId status {reason {}}} {
    if {![info exists ::GX::ui(runPlanQueue)] ||
        ![info exists ::GX::analysisOperation] || $::GX::analysisOperation ne {Selective analysis} ||
        $::GX::currentSession ne $::GX::ui(runPlanSession) ||
        ![dict exists $::GX::ui(runPlanQueue) $id] ||
        $runId ni [dict get $::GX::ui(runPlanQueue) $id]} return
    runPlanStatus $id $status $reason
    if {$status in {PASS FAILED}} {
        set remaining [dict get $::GX::ui(runPlanQueue) $id]
        set remaining [lreplace $remaining [lsearch -exact $remaining $runId] [lsearch -exact $remaining $runId]]
        dict set ::GX::ui(runPlanQueue) $id $remaining
        if {$status eq {PASS} && [llength $remaining]} {
            runPlanStatus $id PENDING {Remaining graph stages are queued}
        }
    }
    if {$status eq {FAILED}} {
        foreach pending [array names ::GX::runPlanState] {
            if {$::GX::runPlanState($pending) eq {PENDING}} {
                runPlanStatus $pending SKIPPED {Not executed because an earlier Run stage failed}
            }
        }
    }
}

proc ::GX::runPageScriptRunner {} {
    if {$::GX::currentSession eq {} || ![file isdirectory $::GX::currentSession]} {
        tk_messageBox -parent . -icon info -title {Script Runner requires a Session} -message {Open or create the intended scientific Session first, then choose Script Runner again. Opening the Runner only prepares a review; Run explicitly submits the Job. Job Manager remains available without a Session.}
        return
    }
    if {[info exists ::GX::scriptWorkspaceChoice] && $::GX::scriptWorkspaceChoice ne {} && ![catch {scriptRegistryDescribe $::GX::scriptWorkspaceChoice}]} {
        scriptWorkspaceRunDialog
    } else {
        # The Library already owns registered-source selection and its Run
        # action. Do not introduce a second script picker or execution path.
        scriptLibraryDialog
    }
}

proc ::GX::buildRunPage {} {
    variable ui
    set f .top.nb.run
    grid columnconfigure $f 0 -weight 1
    grid rowconfigure $f 3 -weight 1
    ttk::frame $f.buttons
    ttk::button $f.buttons.analysis -text "Run enabled analyses" -command ::GX::runPageStart
    ttk::button $f.buttons.stop -text Stop -command ::GX::stopCurrent -state disabled
    ttk::button $f.buttons.copy -text "Copy log" -command [list ::GX::copyTextWidget $f.log "Run log"]
    ttk::button $f.buttons.refresh -text "Refresh plan" -command ::GX::runPlanRefresh
    # Legacy callback targets remain as hidden widgets for headless/old paths.
    ttk::button $f.buttons.start -text "Legacy import" -command ::GX::startAsync
    ttk::button $f.buttons.all -text "Legacy combined run" -command ::GX::startAll
    pack $f.buttons.analysis $f.buttons.stop $f.buttons.refresh $f.buttons.copy -side left -padx 4
    ttk::menubutton $f.buttons.executions -text {Scripts & Jobs…} -menu $f.buttons.executions.menu
    menu $f.buttons.executions.menu -tearoff 0
    $f.buttons.executions.menu add command -label {Script Runner…} -command ::GX::runPageScriptRunner
    $f.buttons.executions.menu add command -label {Job Manager (local / remote)…} -command ::GX::scriptJobsDialog
    $f.buttons.executions.menu add separator
    $f.buttons.executions.menu add command -label {Execution help} -command {::GX::documentationBrowserOpenApi SCRIPT_WORKSPACE_GUI_HOST}
    pack $f.buttons.executions -side right -padx 4
    native2DViewportTooltip $f.buttons.executions {Script Runner prepares a registered script in the current Session. Job Manager inspects local executions or reconnects an exact remote Job ID; opening either does not submit a Job.}
    grid $f.buttons -row 0 -column 0 -sticky ew -padx 5 -pady 7
    set ui(startButton) $f.buttons.start
    set ui(analysisStart) $f.buttons.analysis
    set ui(runAllButton) $f.buttons.all
    set ui(stopButton) $f.buttons.stop
    set ui(analysisStop) $f.buttons.stop
    ttk::labelframe $f.plan -text "Execution plan"
    grid $f.plan -row 1 -column 0 -sticky nsew -padx 5 -pady 4
    grid columnconfigure $f.plan 0 -weight 1
    grid rowconfigure $f.plan 0 -weight 1
    ttk::treeview $f.plan.tree -columns {order version enabled inputs status reason} -show {tree headings} -height 9
    $f.plan.tree heading #0 -text "Analysis module"
    $f.plan.tree column #0 -width 245
    foreach {key title width} {order Order 55 version Version 75 enabled State 80 inputs {Input Dataset(s)} 280 status Status 85 reason Reason 200} {
        $f.plan.tree heading $key -text $title
        $f.plan.tree column $key -width $width
    }
    ttk::scrollbar $f.plan.sy -orient vertical -command [list $f.plan.tree yview]
    $f.plan.tree configure -yscrollcommand [list $f.plan.sy set]
    grid $f.plan.tree -row 0 -column 0 -sticky nsew
    grid $f.plan.sy -row 0 -column 1 -sticky ns
    ttk::label $f.plan.summary -textvariable ::GX::ui(runPlanSummary) -anchor w
    grid $f.plan.summary -row 1 -column 0 -sticky ew -pady 3
    set ui(status) "Ready"
    ttk::frame $f.status
    ttk::label $f.status.lab -textvariable ::GX::ui(status) -width 48
    ttk::progressbar $f.status.pb -orient horizontal -mode determinate -maximum 100
    set ui(progress) $f.status.pb
    pack $f.status.lab -side left -padx 4
    pack $f.status.pb -side left -fill x -expand 1 -padx 4
    grid $f.status -row 2 -column 0 -sticky ew -padx 5 -pady 4
    text $f.log -wrap none -height 12 -state disabled -font TkFixedFont
    ttk::scrollbar $f.sy -orient vertical -command [list $f.log yview]
    ttk::scrollbar $f.sx -orient horizontal -command [list $f.log xview]
    $f.log configure -yscrollcommand [list $f.sy set] -xscrollcommand [list $f.sx set]
    grid $f.log -row 3 -column 0 -sticky nsew -padx {5 0} -pady {4 0}
    grid $f.sy -row 3 -column 1 -sticky ns -pady {4 0}
    grid $f.sx -row 4 -column 0 -sticky ew -padx {5 0}
    set ui(log) $f.log
    runPlanRefresh
}

proc ::GX::runNextAnalysis {} {
    ::GX::runNextAnalysis_before_plan_status
}

proc ::GX::onAnalysisReadable {pipe} {
    # The original queue owner reports completion before starting another item.
    # A recursive next item or an unrelated Job cannot certify this invocation.
    tailcall ::GX::onAnalysisReadable_before_plan_status $pipe
}

proc ::GX::stopAnalysis {{message 1}} {
    variable runPlanState
    if {$message && [info exists ::GX::ui(analysisCurrentModuleId)] && $::GX::currentSession ne {}} {
        set module $::GX::ui(analysisCurrentModuleId)
        set marker [file join $::GX::currentSession analysis $module .registered_job_id]
        if {$module in {analysis.python_script analysis.octave_script} && [file isfile $marker]} {
            set f [open $marker r];set id [string trim [read $f]];close $f
            scriptJobAsync [scriptJobCommand cancel $id] {} ::GX::scriptJobsActionDone
        }
    }
    set result [::GX::stopAnalysis_before_plan_status $message]
    foreach id [array names runPlanState] {
        if {$runPlanState($id) in {RUNNING PENDING}} { runPlanStatus $id SKIPPED "Run stopped" }
    }
    return $result
}

proc ::GX::onNotebookChanged {nb} {
    set result [::GX::onNotebookChanged_before_run_plan $nb]
    if {[$nb select] eq "$nb.run"} { catch {runPlanRefresh} }
    return $result
}
