/* Plot Dataset v4 typed presentation model. Scientific values and identities
 * arrive through CORE bounded Dataset/Curve Source access; this model owns
 * only a disposable view. Projection reuses Native2D C world/device geometry. */
#include "gx2d_plot_v4.h"
#include "gx2d.h"
#include <cairo.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <limits>
#include <map>
#include <memory>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>
namespace {
Tcl_Obj *s(const std::string &v){return Tcl_NewStringObj(v.c_str(),v.size());}
Tcl_Obj *num(double v){return Tcl_NewDoubleObj(v);}
Tcl_Obj *get(Tcl_Interp *ip,Tcl_Obj *d,const char *k){Tcl_Obj *v=nullptr;if(d&&Tcl_DictObjGet(ip,d,s(k),&v)!=TCL_OK)throw std::runtime_error("Expected a dictionary");return v;}
std::string text(Tcl_Interp *ip,Tcl_Obj*d,const char*k,std::string v=""){auto p=get(ip,d,k);return p?Tcl_GetString(p):v;}
double number(Tcl_Interp*ip,Tcl_Obj*d,const char*k,double v){auto p=get(ip,d,k);double a;if(p&&Tcl_GetDoubleFromObj(ip,p,&a)==TCL_OK&&std::isfinite(a))return a;Tcl_ResetResult(ip);return v;}
std::vector<Tcl_Obj*> list(Tcl_Interp *ip,Tcl_Obj *v){int n=0;Tcl_Obj **a=nullptr;if(v&&Tcl_ListObjGetElements(ip,v,&n,&a)!=TCL_OK)throw std::runtime_error("Expected a list");return std::vector<Tcl_Obj*>(a,a+n);}
double value(Tcl_Interp *ip,Tcl_Obj *p){double a;if(!p||Tcl_GetDoubleFromObj(ip,p,&a)!=TCL_OK){Tcl_ResetResult(ip);return std::numeric_limits<double>::quiet_NaN();}return a;}
void put(Tcl_Obj*d,const char*k,Tcl_Obj*v){Tcl_DictObjPut(nullptr,d,s(k),v);}
Tcl_Obj *values(const std::vector<double>&a){auto v=Tcl_NewListObj(0,nullptr);for(auto x:a)Tcl_ListObjAppendElement(nullptr,v,num(x));return v;}
struct Ref{Tcl_Obj*p=nullptr;Ref(){}Ref(Tcl_Obj*q):p(q){if(p)Tcl_IncrRefCount(p);}Ref(const Ref&r):Ref(r.p){}Ref&operator=(const Ref&r){if(r.p)Tcl_IncrRefCount(r.p);if(p)Tcl_DecrRefCount(p);p=r.p;return *this;}~Ref(){if(p)Tcl_DecrRefCount(p);}};
struct Axis{double lo=0,hi=1;bool log=false,reverse=false,manual=false;std::string label;Ref spec;double transform(double x)const{return log?(x>0?std::log10(x):NAN):x;}double inv(double x)const{return log?std::pow(10.,x):x;}};
struct Point{double x=0,y=0,deviceX=0,deviceY=0;std::string row;bool gap=false;};
struct MeshCell{std::string id,row;std::array<size_t,3>nodes;double scalar;};
struct Series{bool visible=true;std::string id,label,kind,axis,color,marker,line,step,fill;double width=1.5,size=4,opacity=1,baseline=0,barWidth=.8;std::vector<Point>points,meshNodes;std::vector<MeshCell>meshCells;double scalarMin=0,scalarMax=0,sourceScalarMin=0,sourceScalarMax=0;std::vector<double>xl,xu,yl,yu,lower,upper,barLower,barUpper;std::array<double,4>bounds;Ref original;};
struct Panel{std::string id,title,aspect="auto";Axis x,y,r;bool aspectApplied=false;std::array<double,4>aspectRequest{};std::vector<Series>series;Ref annotations;double left=75,top=45,right=700,bottom=450;gx2d_scene*scene=gx2d_create();Panel(){gx2d_view_aspect_set(scene,GX2D_ASPECT_AUTO);}Panel(const Panel&)=delete;Panel(Panel&&a)noexcept:id(std::move(a.id)),title(std::move(a.title)),aspect(std::move(a.aspect)),x(a.x),y(a.y),r(a.r),aspectApplied(a.aspectApplied),aspectRequest(a.aspectRequest),series(std::move(a.series)),annotations(a.annotations),left(a.left),top(a.top),right(a.right),bottom(a.bottom),scene(a.scene){a.scene=nullptr;}~Panel(){if(scene)gx2d_destroy(scene);}};
struct Model{Tcl_Interp*ip;std::string title;Ref presentation;double font=12,axisFont=14,titleFont=18,legendFont=12;int width=800,height=600;bool sharedXInteractive=false;std::vector<Panel>panels;Ref original;Ref receipt;Ref hitPrimitives;uint64_t revision=1,drawRevision=0;};
struct State{uint64_t serial=0;std::map<std::string,std::unique_ptr<Model>>models;};
const char*palette[]={"#1f77b4","#d62728","#2ca02c","#9467bd","#ff7f0e","#17becf","#8c564b","#e377c2"};
std::vector<double> doubles(Tcl_Interp*ip,Tcl_Obj*d,const char*k){std::vector<double>v;for(auto p:list(ip,get(ip,d,k)))v.push_back(value(ip,p));return v;}
Axis readAxis(Tcl_Interp*ip,Tcl_Obj*o){Axis a;a.spec=Ref(o);a.log=text(ip,o,"scale")=="log";a.reverse=text(ip,o,"direction")=="reverse";a.label=text(ip,o,"label");return a;}
void bounds(Axis&a,double lo,double hi){if(!std::isfinite(lo)||!std::isfinite(hi)){lo=a.log?1:0;hi=a.log?10:1;}if(a.log){if(lo<=0)lo=std::min(1.,hi/1000.);if(hi<=0)throw std::runtime_error("A logarithmic axis has no positive source values");}lo=a.transform(lo);hi=a.transform(hi);double pad=hi>lo?(hi-lo)*.045:std::max(1.,std::abs(lo)*.05);a.lo=a.inv(lo-pad);a.hi=a.inv(hi+pad);auto ip=(Tcl_Interp*)nullptr;(void)ip;}
void setLimits(Tcl_Interp*ip,Axis&a){auto min=get(ip,a.spec.p,"min"),max=get(ip,a.spec.p,"max");double low=value(ip,min),high=value(ip,max);if(std::isfinite(low)){a.lo=low;a.manual=true;}if(std::isfinite(high)){a.hi=high;a.manual=true;}if(!(a.hi>a.lo)||!std::isfinite(a.transform(a.lo))||!std::isfinite(a.transform(a.hi)))throw std::runtime_error("Invalid axis limits for selected scale");}
// Empty panels have no scientific X extent. Share only genuine source bounds
// or explicit user limits; retain the common range in empty presentation slots.
void shareXBounds(Model&m){
 if(m.panels.size()<2)return;
 double lo=INFINITY,hi=-INFINITY;
 for(auto&p:m.panels){
  bool source=p.x.manual;
  for(auto&q:p.series)if(std::isfinite(q.bounds[0])&&std::isfinite(q.bounds[2])){source=true;break;}
  if(source){lo=std::min(lo,p.x.lo);hi=std::max(hi,p.x.hi);}
 }
 if(std::isfinite(lo)&&std::isfinite(hi))for(auto&p:m.panels){p.x.lo=lo;p.x.hi=hi;}
}
void fit(Model&m){for(auto &p:m.panels){p.aspectApplied=false;double xl=INFINITY,xh=-INFINITY,yl=INFINITY,yh=-INFINITY,rl=INFINITY,rh=-INFINITY;for(auto &q:p.series){auto b=q.bounds;xl=std::min(xl,b[0]);xh=std::max(xh,b[2]);double &l=q.axis=="right"?rl:yl,&h=q.axis=="right"?rh:yh;l=std::min(l,b[1]);h=std::max(h,b[3]);if(p.x.log||p.y.log||p.r.log)for(auto &pt:q.points){if(pt.x>0&&p.x.log)xl=xl<=0?pt.x:std::min(xl,pt.x);if(pt.y>0&&(q.axis=="right"?p.r:p.y).log)l=l<=0?pt.y:std::min(l,pt.y);}}bounds(p.x,xl,xh);bounds(p.y,yl,yh);bounds(p.r,rl,rh);setLimits(m.ip,p.x);setLimits(m.ip,p.y);setLimits(m.ip,p.r);}shareXBounds(m);}
// Explicit cell association: never triangulate, interpolate, or invent node data.
void readCellField(Tcl_Interp*ip,Series&q){
 auto spec=q.original.p;std::map<std::string,size_t>nodes;std::set<std::string>cells,rows;
 auto sourceNodes=list(ip,get(ip,spec,"mesh_nodes")),sourceCells=list(ip,get(ip,spec,"mesh_cells"));
 if(sourceNodes.size()<3||sourceNodes.size()>2000000||sourceCells.empty()||sourceCells.size()>2000000)throw std::runtime_error("Cell field requires 3..2000000 nodes and 1..2000000 explicit triangles");
 q.bounds={INFINITY,INFINITY,-INFINITY,-INFINITY};
 for(auto node:sourceNodes){auto a=list(ip,node);if(a.size()!=3)throw std::runtime_error("Mesh node must contain exact ID, X and Y");
  std::string id=Tcl_GetString(a[0]);double x=value(ip,a[1]),y=value(ip,a[2]);
  if(id.empty()||!nodes.emplace(id,q.meshNodes.size()).second||!std::isfinite(x)||!std::isfinite(y))throw std::runtime_error("Duplicate/empty node identity or nonfinite node coordinate");
  Point pt;pt.x=x;pt.y=y;pt.row=id;q.meshNodes.push_back(pt);
  q.bounds[0]=std::min(q.bounds[0],x);q.bounds[2]=std::max(q.bounds[2],x);q.bounds[1]=std::min(q.bounds[1],y);q.bounds[3]=std::max(q.bounds[3],y);
 }
 double lo=INFINITY,hi=-INFINITY;
 for(auto cell:sourceCells){auto a=list(ip,cell);if(a.size()!=6)throw std::runtime_error("Mesh cell requires ID, three node IDs, scalar and original source row");
  MeshCell c;c.id=Tcl_GetString(a[0]);c.row=Tcl_GetString(a[5]);c.scalar=value(ip,a[4]);Tcl_WideInt row;
  if(c.id.empty()||!cells.insert(c.id).second||!std::isfinite(c.scalar)||Tcl_GetWideIntFromObj(ip,a[5],&row)!=TCL_OK||row<0)throw std::runtime_error("Duplicate/empty cell identity, duplicate/invalid row or nonfinite scalar");
  c.row=std::to_string(row);if(!rows.insert(c.row).second)throw std::runtime_error("Duplicate cell source row");
  for(size_t j=0;j<3;++j){auto found=nodes.find(Tcl_GetString(a[j+1]));if(found==nodes.end())throw std::runtime_error("Triangle references an unknown node identity");c.nodes[j]=found->second;}
  const auto&a0=q.meshNodes[c.nodes[0]],&b=q.meshNodes[c.nodes[1]],&d=q.meshNodes[c.nodes[2]];
  long double area=((long double)b.x-a0.x)*((long double)d.y-a0.y)-((long double)b.y-a0.y)*((long double)d.x-a0.x);
  if(area==0||!std::isfinite(area))throw std::runtime_error("Degenerate/nonfinite explicit triangle geometry");
  lo=std::min(lo,c.scalar);hi=std::max(hi,c.scalar);q.meshCells.push_back(c);
 }
 q.sourceScalarMin=lo;q.sourceScalarMax=hi;
 auto range=doubles(ip,spec,"color_range");if(!range.empty()){if(range.size()!=2||!std::isfinite(range[0])||!std::isfinite(range[1])||range[1]<range[0]||range[0]>lo||range[1]<hi)throw std::runtime_error("Color range must contain the complete finite cell scalar range");lo=range[0];hi=range[1];}
 if(range.empty()){long double scale=std::max({fabsl((long double)lo),fabsl((long double)hi),1e-300L});if((long double)hi-lo<=1e-12L*scale){long double center=((long double)lo+hi)/2,pad=.05L*scale,limit=std::numeric_limits<double>::max();lo=double(std::max(-limit,center-pad));hi=double(std::min(limit,center+pad));}}
 q.scalarMin=lo;q.scalarMax=hi;
}
std::string cellColor(const Series&q,double scalar){double t=q.scalarMax>q.scalarMin?double(((long double)scalar-q.scalarMin)/((long double)q.scalarMax-q.scalarMin)):.5;t=std::clamp(t,0.,1.);char color[16];int r=int(255*t),b=int(255*(1-t)),g=int(160*(1-std::abs(2*t-1)));snprintf(color,sizeof(color),"#%02x%02x%02x",r,g,b);return color;}
std::unique_ptr<Model>parse(Tcl_Interp*ip,Tcl_Obj*d){auto m=std::make_unique<Model>();m->ip=ip;m->original=Ref(d);m->sharedXInteractive=text(ip,d,"shared_x_interaction","0")=="1";m->title=text(ip,d,"title");m->presentation=Ref(get(ip,d,"native_presentation"));auto graphics=get(ip,m->presentation.p,"graphics");double dpi=number(ip,graphics,"dpi",100),factor=(text(ip,graphics,"font_unit")=="pt"||text(ip,graphics,"font_unit")=="points")?dpi/72.:1.;m->font=number(ip,graphics,"font_size",12)*factor;m->axisFont=number(ip,graphics,"axis_label_font_size",14)*factor;m->titleFont=number(ip,graphics,"title_font_size",18)*factor;auto legend=get(ip,m->presentation.p,"legend");double lf=(text(ip,legend,"font_unit")=="pt"||text(ip,legend,"font_unit")=="points")?dpi/72.:text(ip,legend,"font_unit")=="inherit"?factor:1.;m->legendFont=number(ip,legend,"font_size",12)*lf;int color=0;for(auto pd:list(ip,get(ip,d,"panels"))){Panel p;p.id=text(ip,pd,"id");p.title=text(ip,pd,"title");p.aspect=text(ip,pd,"aspect","auto");if(p.aspect!="auto"&&p.aspect!="xy_equal")throw std::runtime_error("Plot aspect must be auto or xy_equal");auto axes=get(ip,pd,"axes");p.x=readAxis(ip,get(ip,axes,"x"));p.y=readAxis(ip,get(ip,axes,"left"));p.r=readAxis(ip,get(ip,axes,"right"));p.annotations=Ref(get(ip,pd,"annotations"));for(auto sd:list(ip,get(ip,pd,"series"))){Series q;q.original=Ref(sd);q.id=text(ip,sd,"id");q.label=text(ip,sd,"label",q.id);q.kind=text(ip,sd,"kind","line");if(q.kind=="auto")q.kind="line";q.axis=text(ip,sd,"axis","left");auto st=get(ip,sd,"style");q.color=text(ip,st,"color");if(q.color.empty()||q.color=="auto"||q.color=="inherit")q.color=palette[color++%8];q.marker=text(ip,st,"marker",q.kind=="scatter"||q.kind=="line_marker"||q.kind=="errorbar"||q.kind=="box_whisker"?"circle":"none");q.fill=text(ip,st,"marker_fill","none");q.line=text(ip,st,"line_style",q.kind=="scatter"||q.kind=="errorbar"||q.kind=="bar"||q.kind=="histogram"?"none":"solid");if(q.marker=="auto"||q.marker=="inherit")q.marker=q.kind=="scatter"||q.kind=="line_marker"||q.kind=="errorbar"||q.kind=="box_whisker"?"circle":"none";if(q.line=="auto"||q.line=="inherit")q.line=q.kind=="scatter"||q.kind=="errorbar"||q.kind=="bar"||q.kind=="histogram"?"none":"solid";if(q.fill=="auto"||q.fill=="inherit")q.fill="none";q.width=number(ip,st,"line_width",number(ip,graphics,"line_width",1.5));q.size=number(ip,st,"marker_size",4);q.opacity=number(ip,st,"opacity",1);q.step=text(ip,sd,"step_mode","post");q.baseline=number(ip,sd,"bar_baseline",0);q.barWidth=number(ip,sd,"bar_width",.8);auto rows=list(ip,get(ip,sd,"source_rows"));std::set<size_t>gaps;for(auto z:list(ip,get(ip,sd,"breaks")))gaps.insert((size_t)value(ip,z));size_t index=0;for(auto z:list(ip,get(ip,sd,"points"))){auto xy=list(ip,z);if(xy.size()!=2)throw std::runtime_error("A plot point must contain X and Y");Point pt;pt.x=value(ip,xy[0]);pt.y=value(ip,xy[1]);pt.row=index<rows.size()?Tcl_GetString(rows[index]):text(ip,sd,"point_identity_kind")=="derived_statistic"?"":std::to_string(index);pt.gap=index>0&&gaps.count(index-1)>0;q.points.push_back(pt);++index;}q.xl=doubles(ip,sd,"x_lower");q.xu=doubles(ip,sd,"x_upper");q.yl=doubles(ip,sd,"y_lower");q.yu=doubles(ip,sd,"y_upper");q.lower=doubles(ip,sd,get(ip,sd,"band_lower")?"band_lower":"lower");q.upper=doubles(ip,sd,get(ip,sd,"band_upper")?"band_upper":"upper");q.barLower=doubles(ip,sd,"bar_lower");q.barUpper=doubles(ip,sd,"bar_upper");auto b=doubles(ip,sd,"full_bounds");q.bounds={INFINITY,INFINITY,-INFINITY,-INFINITY};if(b.size()==4)std::copy(b.begin(),b.end(),q.bounds.begin());else for(auto&pt:q.points){if(std::isfinite(pt.x)&&std::isfinite(pt.y)){q.bounds[0]=std::min(q.bounds[0],pt.x);q.bounds[2]=std::max(q.bounds[2],pt.x);q.bounds[1]=std::min(q.bounds[1],pt.y);q.bounds[3]=std::max(q.bounds[3],pt.y);}}for(size_t i=0;i<q.points.size();++i){if(i<q.xl.size()&&std::isfinite(q.xl[i]))q.bounds[0]=std::min(q.bounds[0],q.xl[i]);if(i<q.xu.size()&&std::isfinite(q.xu[i]))q.bounds[2]=std::max(q.bounds[2],q.xu[i]);if(i<q.barLower.size()&&std::isfinite(q.barLower[i]))q.bounds[0]=std::min(q.bounds[0],q.barLower[i]);if(i<q.barUpper.size()&&std::isfinite(q.barUpper[i]))q.bounds[2]=std::max(q.bounds[2],q.barUpper[i]);for(auto*v:{&q.yl})if(i<v->size()&&std::isfinite((*v)[i]))q.bounds[1]=std::min(q.bounds[1],(*v)[i]);for(auto*v:{&q.yu})if(i<v->size()&&std::isfinite((*v)[i]))q.bounds[3]=std::max(q.bounds[3],(*v)[i]);if(q.kind=="band"||q.kind=="box_whisker"||get(ip,sd,"band")){if(i<q.lower.size()&&std::isfinite(q.lower[i]))q.bounds[1]=std::min(q.bounds[1],q.lower[i]);if(i<q.upper.size()&&std::isfinite(q.upper[i]))q.bounds[3]=std::max(q.bounds[3],q.upper[i]);}}if(q.kind=="bar"||q.kind=="histogram"){q.bounds[1]=std::min(q.bounds[1],q.baseline);q.bounds[3]=std::max(q.bounds[3],q.baseline);q.bounds[0]-=q.barWidth/2;q.bounds[2]+=q.barWidth/2;}if(q.kind=="cell_field"){if(p.x.log||(q.axis=="right"?p.r:p.y).log)throw std::runtime_error("Explicit cell geometry requires linear physical axes");if(!q.points.empty())throw std::runtime_error("Cell field does not accept invented point observations");readCellField(ip,q);}p.series.push_back(std::move(q));}if(p.aspect=="xy_equal"){if(p.x.log||p.y.log)throw std::runtime_error("Equal numeric aspect requires linear axes");for(const auto&q:p.series)if(q.axis=="right")throw std::runtime_error("Equal numeric aspect requires one Y axis");}m->panels.push_back(std::move(p));}if(m->panels.empty())throw std::runtime_error("A native Plot model requires at least one panel");fit(*m);return m;}
gx2d_point project(Model&m,Panel&p,Axis&y,double x,double v){gx2d_view view{double(m.width),double(m.height),p.left,p.top,m.width-p.right,m.height-p.bottom,{p.x.transform(p.x.lo),y.transform(y.lo),p.x.transform(p.x.hi),y.transform(y.hi)}};gx2d_view_set(p.scene,&view);gx2d_point src{p.x.transform(x),y.transform(v)},out{NAN,NAN};gx2d_world_to_device(p.scene,src,&out);if(p.x.reverse)out.x=p.left+p.right-out.x;if(y.reverse)out.y=p.top+p.bottom-out.y;return out;}
// Hit metadata belongs to the same bounded display list painted by Native2D.
// It never creates or changes canonical scientific identities.
struct HitContext{std::string kind,id,panel,axis,series;};
thread_local HitContext hitContext;
struct HitScope{HitContext old;HitScope(HitContext next):old(hitContext){hitContext=std::move(next);}~HitScope(){hitContext=old;}};
void hitTag(Tcl_Obj*d,const HitContext&h){if(!d||h.kind.empty())return;put(d,"hit_kind",s(h.kind));put(d,"hit_id",s(h.id));if(!h.panel.empty())put(d,"hit_panel_id",s(h.panel));if(!h.axis.empty())put(d,"hit_axis",s(h.axis));if(!h.series.empty())put(d,"hit_series_id",s(h.series));}
Tcl_Obj *primitive(Tcl_Obj*out,const char*type,std::vector<double>xy,std::string stroke="#233746",std::string fill="",double width=1){for(double v:xy)if(!std::isfinite(v))return nullptr;auto d=Tcl_NewDictObj();put(d,"type",s(type));put(d,"coords",values(xy));put(d,"stroke",s(stroke));put(d,"fill",s(fill));put(d,"width",num(width));hitTag(d,hitContext);Tcl_ListObjAppendElement(nullptr,out,d);return d;}
Tcl_Obj* label(Tcl_Obj*out,double x,double y,std::string text,double angle=0,double font=12){auto d=primitive(out,"text",{x,y},"#233746");put(d,"text",s(text));put(d,"font_size",num(font));put(d,"angle",num(angle));return d;}
// Wrap title presentation with the same Cairo font metrics as the painter.
// Source title bytes and scientific data remain in the original model.
std::vector<std::string> titleLines(const std::string&source,double width,double font){
 auto surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);
 auto cr=cairo_create(surface);
 cairo_select_font_face(cr,"sans",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);
 cairo_set_font_size(cr,font);
 std::vector<std::string> lines;std::string line;size_t breakAt=0;
 for(size_t at=0;at<source.size();){
  unsigned char c=source[at];
  size_t bytes=c<0x80?1:(c&0xe0)==0xc0?2:(c&0xf0)==0xe0?3:4;
  bytes=std::min(bytes,source.size()-at);
  if(c=='\n'){lines.push_back(line);line.clear();breakAt=0;++at;continue;}
  line.append(source,at,bytes);at+=bytes;
  cairo_text_extents_t ext;cairo_text_extents(cr,line.c_str(),&ext);
  if(std::max(ext.x_advance,ext.width+2*std::abs(ext.x_bearing))>width && line.size()>bytes){
   size_t end=breakAt?breakAt:line.size()-bytes;
   lines.push_back(line.substr(0,end));line.erase(0,end);breakAt=0;
   for(size_t i=0;i<line.size();++i)if(line[i]==' '||line[i]=='\t')breakAt=i+1;
  }
  if(c==' '||c=='\t')breakAt=line.size();
 }
 lines.push_back(line);cairo_destroy(cr);cairo_surface_destroy(surface);return lines;
}
// Use exact admitted display-range endpoints; wrapping changes presentation
// only and never rounds or rewrites the scientific cell scalars.
std::string cellLegendCaption(const Series& q,Tcl_Interp* ip){
 char low[80],high[80];
 for(int precision=8;precision<=17;++precision){
  snprintf(low,sizeof(low),"%.*g",precision,q.scalarMin);
  snprintf(high,sizeof(high),"%.*g",precision,q.scalarMax);
  if(strcmp(low,high)||q.scalarMin==q.scalarMax)break;
 }
 return std::string(low)+" … "+high+" "+text(ip,q.original.p,"scalar_unit")+" (cell values)";
}
void titleDraw(Tcl_Obj*out,const std::vector<std::string>&lines,double x,double y,double font,const HitContext&hit){
 for(size_t i=0;i<lines.size();++i)hitTag(label(out,x,y+i*font*1.25,lines[i],0,font),hit);
}
// Keep a fitting rotated caption inside its panel using the painter's exact
// Cairo ink extents. This changes presentation only, not axes, samples or font.
double axisLabelCenter(const std::string&text,double center,double font,double top,double bottom){
 auto surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);auto cr=cairo_create(surface);
 cairo_select_font_face(cr,"sans",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);cairo_set_font_size(cr,font);
 cairo_text_extents_t ext;cairo_text_extents(cr,text.c_str(),&ext);
 cairo_destroy(cr);cairo_surface_destroy(surface);
 // The shared painter centers the advance before applying its 90-degree turn.
 double first=ext.x_advance/2.-ext.x_bearing-ext.width,last=ext.x_advance/2.-ext.x_bearing;
 double room=bottom-top,ink=last-first;
 if(ink>room)throw std::runtime_error("Viewport is too small for the complete axis caption; enlarge the Plot or adjust its declared font");
 double margin=std::min(4.,(room-ink)/2.);
 double low=top+margin-first,high=bottom-margin-last;
 return std::max(low,std::min(center,high));
}
void style(Tcl_Obj*d,Series&q,Panel&p){if(!d)return;hitTag(d,{"series",q.id,p.id,q.axis,q.id});put(d,"opacity",num(q.opacity));put(d,"clip",values({p.left,p.top,p.right,p.bottom}));if(q.line=="dashed")put(d,"dash",values({6,4}));if(q.line=="dotted")put(d,"dash",values({1,3}));if(q.line=="dashdot")put(d,"dash",values({6,3,1,3}));}
void marker(Tcl_Obj*out,Panel&p,Series&q,double x,double y,const char*shapeOverride=nullptr){const std::string shape=shapeOverride?shapeOverride:q.marker;double r=q.size;std::string fill=q.fill=="none"?"":q.color;Tcl_Obj*d=nullptr;if(shape=="none")return;if(shape=="circle"||shape=="auto")d=primitive(out,"oval",{x-r,y-r,x+r,y+r},q.color,fill,q.width);else if(shape=="square")d=primitive(out,"rectangle",{x-r,y-r,x+r,y+r},q.color,fill,q.width);else if(shape=="diamond")d=primitive(out,"polygon",{x,y-r,x+r,y,x,y+r,x-r,y},q.color,fill,q.width);else if(shape=="triangle_up"||shape=="triangle_down"){double z=shape=="triangle_up"?1:-1;d=primitive(out,"polygon",{x,y-z*r,x+r,y+z*r,x-r,y+z*r},q.color,fill,q.width);}else{if(shape=="plus"||shape=="star"){style(primitive(out,"line",{x-r,y,x+r,y},q.color,"",q.width),q,p);d=primitive(out,"line",{x,y-r,x,y+r},q.color,"",q.width);}if(shape=="x"||shape=="star"){style(primitive(out,"line",{x-r,y-r,x+r,y+r},q.color,"",q.width),q,p);d=primitive(out,"line",{x-r,y+r,x+r,y-r},q.color,"",q.width);}}style(d,q,p);}
std::string axisTickLabel(Model&m,Axis&a,double x){
 auto formatObject=get(m.ip,a.spec.p,"format");int formatLength=0;const char* formatBytes=formatObject?Tcl_GetStringFromObj(formatObject,&formatLength):"";
 std::string format(formatBytes,size_t(formatLength));
 if(format.empty()||format=="auto"||format=="inherit")format="%.12g";
 // One bounded floating conversion; never pass an unchecked format to printf.
 if(format.size()>64||format.find('\0')!=std::string::npos||Tcl_RegExpMatch(m.ip,format.c_str(),"^([^%\r\n]|%%)*%[-+ #0]*([0-9]{1,2})?(\\.[0-9]{1,2})?[eEfFgG]([^%\r\n]|%%)*$")!=1)
  throw std::runtime_error("Numeric tick format must contain one bounded floating-point conversion");
 char buffer[512];int count=snprintf(buffer,sizeof(buffer),format.c_str(),x==0?0:x);
 if(count<0||count>=int(sizeof(buffer)))throw std::runtime_error("Numeric tick label exceeds bounded display capacity");
 return buffer;
}
Tcl_Obj*ticks(Model&m,Axis&a,double pixels){auto custom=get(m.ip,a.spec.p,"tick_positions");if(custom&&std::string(Tcl_GetString(custom))!=""){auto result=Tcl_NewListObj(0,nullptr);std::string raw=Tcl_GetString(custom),labs=text(m.ip,a.spec.p,"tick_labels");std::vector<std::string>labels;size_t at=0,pos;while((pos=labs.find(';',at))!=std::string::npos){labels.push_back(labs.substr(at,pos-at));at=pos+1;}labels.push_back(labs.substr(at));at=0;size_t i=0;do{pos=raw.find(';',at);std::string token=raw.substr(at,pos==std::string::npos?pos:pos-at);char*end;double x=strtod(token.c_str(),&end);if(end!=token.c_str()&&x>=a.lo&&x<=a.hi){auto d=Tcl_NewDictObj();put(d,"value",num(x));put(d,"label",s(i<labels.size()?labels[i]:token));Tcl_ListObjAppendElement(nullptr,result,d);}++i;at=pos+1;}while(pos!=std::string::npos);return result;}double step=number(m.ip,a.spec.p,"major_step",0);
 if(a.log||step>0){
  auto result=Tcl_NewListObj(0,nullptr);
  double spacing=a.log?(step>0?step:1):step;
  double low=a.log?log10(a.lo):a.lo,high=a.log?log10(a.hi):a.hi;
  double first=a.log&&step<=0?floor(low):ceil(low/spacing);
  double last=a.log&&step<=0?ceil(high):floor(high/spacing);
  if(!std::isfinite(first)||!std::isfinite(last)||last-first>1000)
   throw std::runtime_error("Requested major tick spacing exceeds bounded display capacity");
  double stride=a.log&&step<=0?std::max(1.,ceil((last-first)/std::max(2.,pixels/(m.font*5)))):1.;
  for(double n=first;n<=last;n+=stride){
   double x=a.log?pow(10,n*spacing):n*spacing;if(x<a.lo||x>a.hi)continue;
   auto d=Tcl_NewDictObj();put(d,"value",num(x));put(d,"label",s(axisTickLabel(m,a,x)));
   Tcl_ListObjAppendElement(nullptr,result,d);
  }
  return result;
 }
 Tcl_Obj*argv[]={s("::GX::native2DAxisPlan"),num(a.lo),num(a.hi),num(pixels),num(m.font)};
 for(auto p:argv)Tcl_IncrRefCount(p);int code=Tcl_EvalObjv(m.ip,5,argv,TCL_EVAL_GLOBAL);
 for(auto p:argv)Tcl_DecrRefCount(p);
 if(code!=TCL_OK)throw std::runtime_error(Tcl_GetStringResult(m.ip));
 auto planned=get(m.ip,Tcl_GetObjResult(m.ip),"ticks");
 std::string format=text(m.ip,a.spec.p,"format");
 if(format.empty()||format=="auto"||format=="inherit")return planned;
 Ref held(planned);auto result=Tcl_NewListObj(0,nullptr);
 for(auto tick:list(m.ip,planned)){
  auto item=Tcl_DuplicateObj(tick);put(item,"label",s(axisTickLabel(m,a,number(m.ip,tick,"value",NAN))));
  Tcl_ListObjAppendElement(nullptr,result,item);
 }
 return result;
}
// Keep fitting Left tick centers unchanged, but anchor wide formatted ink
// outside the scientific border using the exact metrics used by its painter.
double leftTickOffset(const cairo_text_extents_t& ext,double font){
 return std::max(2.5*font,.5*font+ext.x_bearing+ext.width-ext.x_advance/2.);
}
double leftTickCenter(const std::string& caption,double edge,double font){
 auto surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);auto cr=cairo_create(surface);
 cairo_select_font_face(cr,"sans",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);cairo_set_font_size(cr,font);
 cairo_text_extents_t ext;cairo_text_extents(cr,caption.c_str(),&ext);
 double center=edge-leftTickOffset(ext,font),left=center-ext.x_advance/2.+ext.x_bearing;
 cairo_destroy(cr);cairo_surface_destroy(surface);
 if(left<1)throw std::runtime_error("Viewport has insufficient Left margin for complete tick text; enlarge the Plot or increase its declared Left margin");
 return center;
}
// The centered Cairo baseline leaves ink below the caption center. Reserve
// that measured descent without changing the declared physical font size.
double axisCaptionDescent(const std::string& caption,double font){
 auto surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);auto cr=cairo_create(surface);
 cairo_select_font_face(cr,"sans",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);cairo_set_font_size(cr,font);
 cairo_text_extents_t ext;cairo_text_extents(cr,caption.c_str(),&ext);
 cairo_destroy(cr);cairo_surface_destroy(surface);return ext.y_bearing/2.+ext.height;
}
double axisLabelDistance(Model&m,Axis&a,double pixels,bool right=false){
 auto surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);auto cr=cairo_create(surface);
 cairo_select_font_face(cr,"sans",CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);cairo_set_font_size(cr,m.font);
 double halfWidth=0;Ref planned(ticks(m,a,pixels));
 for(auto tick:list(m.ip,planned.p)){cairo_text_extents_t ext;cairo_text_extents(cr,text(m.ip,tick,"label").c_str(),&ext);halfWidth=std::max(halfWidth,ext.width/2.);
  if(!right&&leftTickOffset(ext,m.font)>2.5*m.font)
   halfWidth=std::max(halfWidth,leftTickOffset(ext,m.font)+ext.x_advance/2.-ext.x_bearing-2.5*m.font);}
 cairo_destroy(cr);cairo_surface_destroy(surface);
 return m.font*2.5+halfWidth+6+m.axisFont/2.;
}
#include "gx2d_plot_caption_layout.inc"
#include "gx2d_plot_legend_layout.inc"
Tcl_Obj*draw(Model&m,int width,int height){
 HitScope drawHit({});m.drawRevision=0;m.width=std::max(240,width);m.height=std::max(180,height);
 auto graphics=get(m.ip,m.presentation.p,"graphics"),legend=get(m.ip,m.presentation.p,"legend"),layout=get(m.ip,m.presentation.p,"layout"),axisStyle=get(m.ip,m.presentation.p,"axes");
 std::string placement=text(m.ip,legend,"placement","inside");double margin=std::max(0.,number(m.ip,legend,"margin_px",10));
 auto out=Tcl_NewListObj(0,nullptr),receipt=Tcl_NewDictObj(),axisReceipts=Tcl_NewListObj(0,nullptr),legendReceipts=Tcl_NewListObj(0,nullptr);
 Ref outOwner(out),receiptOwner(receipt),axesOwner(axisReceipts),legendsOwner(legendReceipts);
 hitTag(primitive(out,"rectangle",{0,0,double(m.width),double(m.height)},"",text(m.ip,graphics,"background","#ffffff")),{"chart","chart"});
 std::vector<Tcl_Obj*> automaticLeftCaptions;
 double chartTitleBottom=0;
 if(!m.title.empty()&&m.title!="auto"){
  auto lines=titleLines(m.title,m.width-24,m.titleFont);double y=std::max(18.,m.titleFont);
  titleDraw(out,lines,m.width/2.,y,m.titleFont,{"title","chart_title"});
  chartTitleBottom=y+(lines.size()-1)*m.titleFont*1.25+m.titleFont/2+8;
 }
 double panelHeight=double(m.height-45)/m.panels.size();size_t panelIndex=0;
 struct PanelLayout {double rightCaptionDistance,xCaptionClearance;LegendLayout legend;};
 std::vector<PanelLayout> panelLayouts;panelLayouts.reserve(m.panels.size());
 double sharedLeft=-INFINITY,sharedRight=INFINITY;
 // Plan the existing measured axis/legend bands before painting any panel.
 // Stacked panels share one X domain and must also share its device mapping.
 for(auto&p:m.panels){
  if(p.aspectApplied){p.x.lo=p.aspectRequest[0];p.y.lo=p.aspectRequest[1];p.x.hi=p.aspectRequest[2];p.y.hi=p.aspectRequest[3];p.aspectApplied=false;}
  p.left=m.width*number(m.ip,layout,"layout_margin_left",9)/100.;p.right=m.width*(1-number(m.ip,layout,"layout_margin_right",9)/100.);
  double marginHeight=m.panels.size()>1?panelHeight:m.height;
  p.top=marginHeight*number(m.ip,layout,"layout_margin_top",7)/100.+panelIndex*panelHeight;
  p.bottom=(panelIndex+1)*panelHeight-marginHeight*number(m.ip,layout,"layout_margin_bottom",8)/100.;
  if(m.panels.size()>1&&panelIndex>0)p.top+=m.height*number(m.ip,layout,"layout_gap",2)/100.;
  bool rightAxis=false;for(const auto&q:p.series)if(q.axis=="right")rightAxis=true;
  double leftCaptionDistance=std::max(m.width*number(m.ip,layout,"layout_ylabel_dist",6)/100.,axisLabelDistance(m,p.y,p.bottom-p.top));
  double rightCaptionDistance=rightAxis?axisLabelDistance(m,p.r,p.bottom-p.top,true):0;
  double leftBand=leftCaptionDistance+m.axisFont/2+8,rightBand=rightAxis?rightCaptionDistance+m.axisFont/2+8:0;
  double xCaptionClearance=p.x.label.empty()?10:std::max(10.,axisCaptionDescent(p.x.label,m.axisFont)+1);
  if(number(m.ip,layout,"layout_auto",1)!=0){
   p.left=std::max(p.left,leftBand);p.right=std::min(p.right,m.width-(rightAxis?rightBand:15));
   if(panelIndex==0&&chartTitleBottom>0)p.top=std::max(p.top,chartTitleBottom);
   p.bottom=std::min(p.bottom,double(m.height)-m.font*2-m.axisFont-10);
  }
  LegendLayout seriesLegend=legendLayout(m,p,placement);
  if(!seriesLegend.items.empty()&&placement!="inside"&&seriesLegend.width>m.width-16)throw std::runtime_error("Complete legend exceeds viewport width; enlarge the Plot or reduce its declared font/columns");
  if(!seriesLegend.items.empty()&&placement=="right")p.right=std::min(p.right,m.width-8-seriesLegend.width-margin-rightBand);
  if(!seriesLegend.items.empty()&&placement=="left")p.left=std::max(p.left,8+seriesLegend.width+margin+leftBand);
  if(p.right-p.left<40)throw std::runtime_error("Viewport is too small for the measured legend and scientific axes; enlarge the Plot or reduce its declared font/columns");
  sharedLeft=std::max(sharedLeft,p.left);sharedRight=std::min(sharedRight,p.right);
  panelLayouts.push_back({rightCaptionDistance,xCaptionClearance,std::move(seriesLegend)});++panelIndex;
 }
 if(m.panels.size()>1){
  if(sharedRight-sharedLeft<40)throw std::runtime_error("Viewport is too small for the common shared-X scientific rectangle; enlarge the Plot or reduce its declared fonts/legend");
  for(auto&p:m.panels){p.left=sharedLeft;p.right=sharedRight;}
 }
 panelIndex=0;
 for(auto&p:m.panels){
  auto&plan=panelLayouts[panelIndex];auto&seriesLegend=plan.legend;
  double rightCaptionDistance=plan.rightCaptionDistance,xCaptionClearance=plan.xCaptionClearance;
  if(!p.title.empty()){
   auto lines=titleLines(p.title,p.right-p.left,m.titleFont);
   if(number(m.ip,layout,"layout_auto",1)!=0)p.top+=m.titleFont+5+(lines.size()-1)*m.titleFont*1.25;
   titleDraw(out,lines,(p.left+p.right)/2,p.top-m.titleFont-(lines.size()-1)*m.titleFont*1.25,m.titleFont,{"title",p.id+".title",p.id});
  }
  double legendAboveY=p.top,legendBelowY=0;
  if(!seriesLegend.items.empty()&&placement=="above")p.top+=seriesLegend.height+margin;
  if(!seriesLegend.items.empty()&&placement=="below"){
   double tileEnd=panelIndex+1==m.panels.size()?m.height:(panelIndex+1)*panelHeight;
   legendBelowY=tileEnd-8-seriesLegend.height;
   double captions=panelIndex+1==m.panels.size()?m.font*2+m.axisFont+10:0;
   p.bottom=std::min(p.bottom,legendBelowY-margin-captions);
  }
  double rightAxisCaptionX=placement=="right"?p.right+rightCaptionDistance:m.width-m.axisFont;
  ++panelIndex;
  if(p.bottom-p.top<40)throw std::runtime_error("Viewport is too small for selected panels and measured legend");
 // Reserve a real presentation band outside the scientific plot rectangle.
 // The original field bar/caption used an in-plot clipped overlay and could
 // obscure cells, collide with the series legend and truncate its unit/range.
 double fieldLegendBase=p.top,fieldLegendEnd=p.top;
 std::map<std::string,std::pair<double,std::vector<std::string>>> fieldLegends;
 for(const auto& q:p.series)if(q.visible&&q.kind=="cell_field"){
  auto lines=titleLines(cellLegendCaption(q,m.ip),std::max(1.,p.right-p.left),m.font);
  fieldLegends.emplace(q.id,std::make_pair(fieldLegendEnd,std::move(lines)));
  fieldLegendEnd+=12+fieldLegends.at(q.id).second.size()*m.font*1.25+8;
 }
 p.top=fieldLegendEnd;
 CaptionLayout customCaptions;
 if(panelIndex==m.panels.size())customCaptions=captionLayout(m,p);
 double captionBand=customCaptions.shaped?customCaptions.height:0;
 if(customCaptions.shaped){
  p.bottom=std::min(p.bottom,double(m.height)-captionBand-m.axisFont-14);
  if(placement=="below"&&!seriesLegend.items.empty())p.bottom=std::min(p.bottom,legendBelowY-margin-captionBand-m.axisFont-14);
 }
 // Ordinary centered X captions need their measured ink descent. The
 // existing shaped-caption band already reserves its own larger clearance.
 if(panelIndex==m.panels.size()&&!customCaptions.shaped&&number(m.ip,layout,"layout_auto",1)!=0){
  p.bottom=std::min(p.bottom,double(m.height)-m.font*2-m.axisFont-xCaptionClearance);
  if(placement=="below"&&!seriesLegend.items.empty())
   p.bottom=std::min(p.bottom,legendBelowY-margin-m.font*2-m.axisFont-xCaptionClearance);
 }
 if(placement=="inside")seriesLegend=legendLayout(m,p,placement,p.right-p.left-2*margin);
 legendPosition(m,p,seriesLegend,placement,margin,legendAboveY,legendBelowY);
 if(customCaptions.shaped&&p.bottom-p.top<std::max(120.,8*m.font))throw std::runtime_error("Viewport is too small to retain a useful scientific plot beneath custom X captions; enlarge the plot or reduce font size");
 if(p.bottom-p.top<40)throw std::runtime_error("Viewport is too small for cell-field legend and scientific panel");
 // Equal numeric aspect is owned by the existing Native2D viewport. Keep
 // requested bounds separately so resizing does not accumulate expansions.
 if(p.aspect=="xy_equal"){
  p.aspectRequest={p.x.lo,p.y.lo,p.x.hi,p.y.hi};
  gx2d_view requested{double(m.width),double(m.height),p.left,p.top,m.width-p.right,m.height-p.bottom,{p.x.lo,p.y.lo,p.x.hi,p.y.hi}};
  if(gx2d_view_aspect_set(p.scene,GX2D_ASPECT_XY_EQUAL)!=GX2D_OK||gx2d_view_set(p.scene,&requested)!=GX2D_OK)throw std::runtime_error("Invalid equal-aspect viewport");
  gx2d_view effective;if(gx2d_view_get(p.scene,&effective)!=GX2D_OK)throw std::runtime_error("Equal-aspect viewport is unavailable");
  p.x.lo=effective.world.x0;p.y.lo=effective.world.y0;p.x.hi=effective.world.x1;p.y.hi=effective.world.y1;
  gx2d_view_aspect_set(p.scene,GX2D_ASPECT_AUTO);
  p.aspectApplied=true;
 }
 if(customCaptions.shaped){customCaptions=captionLayout(m,p);if(customCaptions.height>captionBand+.01)throw std::runtime_error("Exact custom X caption layout needs a larger viewport for the selected aspect");}
 hitTag(primitive(out,"rectangle",{p.left,p.top,p.right,p.bottom},"#526678"),{"panel",p.id,p.id});bool hasRight=false;for(auto&q:p.series)if(q.axis=="right")hasRight=true;
 std::string gridSource=text(m.ip,p.y.spec.p,"grid_source","inherit");
 if(gridSource.empty()||gridSource=="inherit")gridSource="inherit";
 if(gridSource=="right"&&!hasRight)gridSource="left";
 if(gridSource!="inherit"&&gridSource!="left"&&gridSource!="right"&&gridSource!="none")throw std::runtime_error("Invalid Y grid source");
 for(auto axis:{&p.x,&p.y,&p.r}){bool x=axis==&p.x,right=axis==&p.r;if(right&&!hasRight)continue;bool gridY=!x&&(gridSource=="inherit"?!right:gridSource==(right?"right":"left"));HitScope axisHit({"axis",x?"x":right?"right":"left",p.id,x?"x":right?"right":"left"});Ref tickRef(ticks(m,*axis,x?p.right-p.left:p.bottom-p.top));auto tickReceipt=Tcl_NewDictObj();put(tickReceipt,"panel_id",s(p.id));put(tickReceipt,"axis",s(x?"x":right?"right":"left"));put(tickReceipt,"limits",values({axis->lo,axis->hi}));put(tickReceipt,"requested_limits",p.aspectApplied&&!right?values({p.aspectRequest[x?0:1],p.aspectRequest[x?2:3]}):values({axis->lo,axis->hi}));put(tickReceipt,"plot_rect",values({p.left,p.top,p.right,p.bottom}));put(tickReceipt,"scale",s(axis->log?"log":"linear"));put(tickReceipt,"direction",s(axis->reverse?"reverse":"normal"));put(tickReceipt,"aspect",s(p.aspect));auto positions=Tcl_NewListObj(0,nullptr);for(auto t:list(m.ip,tickRef.p)){double val=number(m.ip,t,"value",NAN);auto q=project(m,p,x?p.y:*axis,x?val:p.x.lo,x?p.y.lo:val);double pos=x?q.x:q.y;auto item=Tcl_DuplicateObj(t);put(item,"device",num(pos));Tcl_ListObjAppendElement(nullptr,positions,item);if(x){{auto grid=primitive(out,"line",{pos,p.top,pos,p.bottom},"#e2e7ed");put(grid,"grid_kind",s("major"));}if(panelIndex==m.panels.size()&&!customCaptions.shaped)label(out,pos,p.bottom+m.font+4,text(m.ip,t,"label"),0,m.font);}else{if(gridY){auto grid=primitive(out,"line",{p.left,pos,p.right,pos},"#e2e7ed");put(grid,"grid_kind",s("major"));if(gridSource!="inherit")put(grid,"axis_grid_enabled",s("on"));}label(out,right?p.right+m.font*2.5:leftTickCenter(text(m.ip,t,"label"),p.left,m.font),pos,text(m.ip,t,"label"),0,m.font);}}if(x||gridY){
 auto major=list(m.ip,tickRef.p);
 auto minorLine=[&](double value){
  auto q=project(m,p,x?p.y:*axis,x?value:p.x.lo,x?p.y.lo:value);
  auto grid=primitive(out,"line",x?std::vector<double>{q.x,p.top,q.x,p.bottom}:std::vector<double>{p.left,q.y,p.right,q.y},"#e2e7ed","",.45);
  if(grid){put(grid,"grid_kind",s("minor"));put(grid,"axis_minor_enabled",s(text(m.ip,axis->spec.p,"minor_grid","off")));}
 };
 if(x&&axis->log&&text(m.ip,axis->spec.p,"minor_grid")=="auto"){
  for(int exponent=int(std::floor(std::log10(axis->lo)));exponent<=int(std::floor(std::log10(axis->hi)));++exponent){
   double decade=std::pow(10.,exponent);
   for(int multiplier=2;multiplier<=9;++multiplier){
    double value=multiplier*decade;if(!std::isfinite(value)||value<=axis->lo||value>=axis->hi)continue;
    bool coincides=false;
    for(auto tick:major){double v=number(m.ip,tick,"value",NAN);if(std::abs(value-v)<=1e-10*std::max(std::abs(value),std::abs(v))){coincides=true;break;}}
    if(!coincides)minorLine(value);
   }
  }
 }else{
  for(size_t j=1;j<major.size();++j){
   double a=number(m.ip,major[j-1],"value",NAN),b=number(m.ip,major[j],"value",NAN);
   for(int minor=1;minor<5;++minor)minorLine(axis->log?std::pow(10.,std::log10(a)+(std::log10(b)-std::log10(a))*minor/5.):a+(b-a)*minor/5.);
  }
 }
}
put(tickReceipt,"ticks",positions);Tcl_ListObjAppendElement(nullptr,axisReceipts,tickReceipt);if(x&&customCaptions.shaped)captionDraw(m,out,receipt,p,customCaptions);
 if(!axis->label.empty()&&(!x||panelIndex==m.panels.size())){
  double captionY=x?p.bottom+(customCaptions.shaped?captionBand+m.axisFont/2:m.font*2+m.axisFont):(p.top+p.bottom)/2;
  if(!x&&number(m.ip,layout,"layout_auto",1)!=0)captionY=axisLabelCenter(axis->label,captionY,m.axisFont,m.panels.size()==1?0:(panelIndex-1)*panelHeight,m.panels.size()==1?m.height:panelIndex*panelHeight);
  double captionX=x?(p.left+p.right)/2:right?rightAxisCaptionX:p.left-(number(m.ip,layout,"layout_auto",1)!=0?std::max(m.width*number(m.ip,layout,"layout_ylabel_dist",6)/100.,axisLabelDistance(m,*axis,p.bottom-p.top)):m.width*number(m.ip,layout,"layout_ylabel_dist",6)/100.);
  double manualX=number(m.ip,axis->spec.p,"label_position_x",NAN);
  if(!x&&!right&&std::isfinite(manualX)){
   captionX=p.left+(p.right-p.left)*manualX;
   if(!std::isfinite(captionX))throw std::runtime_error("Manual Y-label position exceeds finite viewport coordinates");
  }
  if(x&&captionY+axisCaptionDescent(axis->label,m.axisFont)>m.height-1+.1)
   throw std::runtime_error("Viewport has insufficient bottom margin for the complete X caption; enlarge the Plot or increase its declared bottom margin");
  auto caption=label(out,captionX,captionY,axis->label,x?0:90,m.axisFont);
  if(!x&&!right&&!std::isfinite(manualX))automaticLeftCaptions.push_back(caption);
 }
}
 size_t annotationIndex=0;for(auto a:list(m.ip,p.annotations.p)){HitScope annotationHit({"annotation","annotation_"+std::to_string(++annotationIndex),p.id});auto type=text(m.ip,a,"type"),ax=text(m.ip,a,"axis","x");Axis&ay=ax=="right"?p.r:p.y;double val=number(m.ip,a,"value",0);std::string color=text(m.ip,a,"color","#777777");if(type=="reference_line"){auto q=project(m,p,ay,ax=="x"?val:p.x.lo,ax=="x"?p.y.lo:val);auto line=primitive(out,"line",ax=="x"?std::vector<double>{q.x,p.top,q.x,p.bottom}:std::vector<double>{p.left,q.y,p.right,q.y},color,"",number(m.ip,a,"line_width",1));if(line){put(line,"clip",values({p.left,p.top,p.right,p.bottom}));put(line,"opacity",num(number(m.ip,a,"opacity",1)));auto mode=text(m.ip,a,"line_style","solid");if(mode=="dashed")put(line,"dash",values({6,4}));if(mode=="dotted")put(line,"dash",values({2,3}));if(mode=="dashdot")put(line,"dash",values({6,3,2,3}));}}else if(type=="reference_region"){double low=number(m.ip,a,"min",0),high=number(m.ip,a,"max",1);auto q=project(m,p,ay,ax=="x"?low:p.x.lo,ax=="x"?p.y.lo:low),r=project(m,p,ay,ax=="x"?high:p.x.hi,ax=="x"?p.y.hi:high);auto d=primitive(out,"rectangle",{std::min(q.x,r.x),std::min(q.y,r.y),std::max(q.x,r.x),std::max(q.y,r.y)},"",color);if(d){put(d,"opacity",num(number(m.ip,a,"opacity",.15)));put(d,"clip",values({p.left,p.top,p.right,p.bottom}));}}else if(type=="text"){auto q=project(m,p,ay,number(m.ip,a,"x",0),number(m.ip,a,"y",0));auto d=primitive(out,"text",{q.x,q.y},color);if(d){put(d,"text",s(text(m.ip,a,"label")));put(d,"font_size",num(m.font));put(d,"clip",values({p.left,p.top,p.right,p.bottom}));}}}
 size_t si=0;for(auto&q:p.series){if(!q.visible)continue;Axis&y=q.axis=="right"?p.r:p.y;if(q.kind=="cell_field"){
 for(const auto&c:q.meshCells){std::vector<double>xy;for(auto index:c.nodes){auto&node=q.meshNodes[index];auto z=project(m,p,y,node.x,node.y);xy.insert(xy.end(),{z.x,z.y});}
  auto poly=primitive(out,"polygon",xy,"#596777",cellColor(q,c.scalar),.35);style(poly,q,p);if(poly){hitTag(poly,{"cell",c.id,p.id,q.axis,q.id});put(poly,"cell_id",s(c.id));put(poly,"source_row_ordinal",s(c.row));put(poly,"value",num(c.scalar));for(auto key:{"dataset_id","mesh_dataset_id","scalar_variable_id","scalar_unit"})put(poly,key,s(text(m.ip,q.original.p,key)));}}
 const auto& fieldLegend=fieldLegends.at(q.id);
 double barLeft=p.left,barTop=fieldLegend.first,barWidth=std::min(150.,p.right-p.left);
 for(int n=0;n<32;++n)primitive(out,"rectangle",{barLeft+n*barWidth/32,barTop,barLeft+(n+1)*barWidth/32,barTop+8},"",cellColor(q,double((long double)q.scalarMin*(1-(n+.5)/32)+(long double)q.scalarMax*(n+.5)/32)));
 for(size_t line=0;line<fieldLegend.second.size();++line){
  auto caption=label(out,barLeft,barTop+12+line*m.font*1.25,fieldLegend.second[line],0,m.font);
  put(caption,"anchor",s("nw"));
  hitTag(caption,{"legend",q.id+".cell_range",p.id,q.axis,q.id});
 }
 auto field=Tcl_NewDictObj();put(field,"series_id",s(q.id));put(field,"legend_rect",values({p.left,barTop,p.right,barTop+12+fieldLegend.second.size()*m.font*1.25}));put(field,"plot_rect",values({p.left,p.top,p.right,p.bottom}));put(field,"node_count",Tcl_NewWideIntObj(q.meshNodes.size()));put(field,"cell_count",Tcl_NewWideIntObj(q.meshCells.size()));put(field,"color_range",values({q.scalarMin,q.scalarMax}));put(field,"source_scalar_range",values({q.sourceScalarMin,q.sourceScalarMax}));put(field,"full_bounds",values({q.bounds[0],q.bounds[1],q.bounds[2],q.bounds[3]}));put(field,"association",s("explicit_constant_per_cell_no_interpolation"));put(field,"scalar_unit",s(text(m.ip,q.original.p,"scalar_unit")));auto fields=get(m.ip,receipt,"cell_fields");if(!fields){fields=Tcl_NewListObj(0,nullptr);put(receipt,"cell_fields",fields);}Tcl_ListObjAppendElement(nullptr,fields,field);
 }for(size_t i=1;i<q.points.size();++i)if((q.kind=="band"||get(m.ip,q.original.p,"band"))&&!q.points[i].gap&&i<q.lower.size()&&i<q.upper.size()){auto a=project(m,p,y,q.points[i-1].x,q.lower[i-1]),b=project(m,p,y,q.points[i].x,q.lower[i]),c=project(m,p,y,q.points[i].x,q.upper[i]),d=project(m,p,y,q.points[i-1].x,q.upper[i-1]);auto f=primitive(out,"polygon",{a.x,a.y,b.x,b.y,c.x,c.y,d.x,d.y},"",q.color);style(f,q,p);if(f)put(f,"opacity",num(q.opacity<1?q.opacity:.18));}std::vector<double>path;auto flush=[&](){
   if(q.line!="none"){
    if(path.size()>=4)style(primitive(out,"polyline",path,q.color,"",q.width),q,p);
    // A finite run bounded by missing observations can contain one sample.
    // Show its actual coordinate without inventing a segment across the gap.
    // Reuse the marker painter without changing retained series style/identity.
    else if(path.size()==2&&q.marker=="none")marker(out,p,q,path[0],path[1],"circle");
   }
   path.clear();
  };for(size_t i=0;i<q.points.size();++i){auto&pt=q.points[i];auto z=project(m,p,y,pt.x,pt.y);pt.deviceX=z.x;pt.deviceY=z.y;if(pt.gap||!std::isfinite(z.x)||!std::isfinite(z.y))flush();if(!std::isfinite(z.x)||!std::isfinite(z.y))continue;bool line=q.kind=="line"||q.kind=="line_marker"||q.kind=="step"||q.kind=="errorbar"||q.kind=="band";if(q.kind=="band"&&text(m.ip,get(m.ip,q.original.p,"band"),"draw_center","1")=="0")line=false;if(line){if(q.kind=="step"&&!path.empty()){double px=path[path.size()-2],py=path.back();if(q.step=="pre"){path.insert(path.end(),{px,z.y});}else if(q.step=="mid"){double middle=(q.points[i-1].x+pt.x)/2;double mid=project(m,p,y,middle,pt.y).x;path.insert(path.end(),{mid,py,mid,z.y});}else path.insert(path.end(),{z.x,py});}path.insert(path.end(),{z.x,z.y});}if(q.kind=="scatter"||q.kind=="line_marker"||q.marker!="none")marker(out,p,q,z.x,z.y);
 auto errorbar=[&](bool x,const std::vector<double>&lo,const std::vector<double>&hi){if(i>=lo.size()||i>=hi.size())return;auto l=project(m,p,y,x?lo[i]:pt.x,x?pt.y:lo[i]),r=project(m,p,y,x?hi[i]:pt.x,x?pt.y:hi[i]);style(primitive(out,"line",{l.x,l.y,r.x,r.y},q.color,"",q.width),q,p);for(auto v:{l,r})style(primitive(out,"line",x?std::vector<double>{v.x,v.y-4,v.x,v.y+4}:std::vector<double>{v.x-4,v.y,v.x+4,v.y},q.color,"",q.width),q,p);};errorbar(true,q.xl,q.xu);errorbar(false,q.yl,q.yu);

 if(q.kind=="bar"||q.kind=="histogram"){double lo=i<q.barLower.size()?q.barLower[i]:q.kind=="histogram"&&i<q.lower.size()?q.lower[i]:pt.x-q.barWidth/2,hi=i<q.barUpper.size()?q.barUpper[i]:q.kind=="histogram"&&i<q.upper.size()?q.upper[i]:pt.x+q.barWidth/2;auto l=project(m,p,y,lo,q.baseline),r=project(m,p,y,hi,pt.y);style(primitive(out,"rectangle",{std::min(l.x,r.x),std::min(l.y,r.y),std::max(l.x,r.x),std::max(l.y,r.y)},q.color,q.color,q.width),q,p);}
 if(q.kind=="box_whisker"&&i<q.lower.size()&&i<q.upper.size()&&i<q.yl.size()&&i<q.yu.size()){auto l=project(m,p,y,pt.x-q.barWidth/2,q.lower[i]),r=project(m,p,y,pt.x+q.barWidth/2,q.upper[i]),low=project(m,p,y,pt.x,q.yl[i]),high=project(m,p,y,pt.x,q.yu[i]);style(primitive(out,"line",{low.x,low.y,high.x,high.y},q.color),q,p);style(primitive(out,"rectangle",{std::min(l.x,r.x),std::min(l.y,r.y),std::max(l.x,r.x),std::max(l.y,r.y)},q.color,"#ffffff",q.width),q,p);style(primitive(out,"line",{l.x,z.y,r.x,z.y},q.color,"",2),q,p);}}
 flush();for(auto o:list(m.ip,get(m.ip,q.original.p,"outliers"))){auto xy=list(m.ip,o);if(xy.size()==2){auto z=project(m,p,y,value(m.ip,xy[0]),value(m.ip,xy[1]));std::string old=q.marker;q.marker="circle";marker(out,p,q,z.x,z.y);q.marker=old;}}++si;}
legendDraw(m,p,out,legendReceipts,seriesLegend,placement);
}

 // The original alignment option shares a physical caption column across
 // stacked Left axes. Explicit panel/global manual positions stay authoritative.
 if(m.panels.size()>1&&number(m.ip,layout,"align_ylabels",0)!=0&&automaticLeftCaptions.size()>1){
  double column=INFINITY;
  for(auto caption:automaticLeftCaptions)column=std::min(column,doubles(m.ip,caption,"coords")[0]);
  for(auto caption:automaticLeftCaptions){auto xy=doubles(m.ip,caption,"coords");xy[0]=column;put(caption,"coords",values(xy));}
 }
 auto defaultGridColor=text(m.ip,graphics,"grid_color","#e2e7ed");
 if(defaultGridColor.empty()||defaultGridColor=="inherit"||defaultGridColor=="auto")defaultGridColor="#e2e7ed";
 for(auto d:list(m.ip,out)){
  if(text(m.ip,d,"type")!="line"||text(m.ip,d,"stroke")!="#e2e7ed"||text(m.ip,d,"grid_kind").empty())continue;
  auto mode=text(m.ip,graphics,"grid_mode","major");auto xy=doubles(m.ip,d,"coords");
  bool vertical=xy.size()==4&&xy[0]==xy[2],minor=text(m.ip,d,"grid_kind")=="minor";
  auto panelStyle=get(m.ip,get(m.ip,m.presentation.p,"panels"),text(m.ip,d,"hit_panel_id").c_str());
  auto resolved=[&](const char*key,const std::string&fallback){
   auto value=text(m.ip,panelStyle,key);
   if(value.empty()||value=="inherit"||value=="auto")value=text(m.ip,axisStyle,key);
   return value.empty()||value=="inherit"||value=="auto"?fallback:value;
  };
  auto policy=resolved(vertical?"xgrid":"ygrid",mode);
  bool hide=policy=="off"||policy=="none"||policy=="0"||
   (vertical&&(policy=="horizontal"||policy=="y"))||(!vertical&&(policy=="vertical"||policy=="x"))||
   (minor&&policy!="both"&&policy!="minor"&&text(m.ip,d,"axis_minor_enabled")!="auto")||(!minor&&policy=="minor");
  if(!vertical&&!minor&&text(m.ip,d,"axis_grid_enabled")=="on")hide=false;
  if(hide)put(d,"stroke",s("none"));
  else put(d,"stroke",s(resolved("grid_color",defaultGridColor)));
 }
size_t resident=0,bytes=0;uint64_t sourceRows=0;for(auto&p:m.panels)for(auto&q:p.series){resident+=q.points.size();bytes+=q.points.capacity()*sizeof(Point);sourceRows+=(uint64_t)number(m.ip,q.original.p,"row_count",q.points.size());}
put(receipt,"resident_point_count",Tcl_NewWideIntObj(resident));put(receipt,"resident_point_capacity_bytes",Tcl_NewWideIntObj(bytes));put(receipt,"point_copy_count",Tcl_NewWideIntObj(resident));put(receipt,"point_copy_batches",Tcl_NewIntObj(1));put(receipt,"selected_series_source_rows",Tcl_NewWideIntObj(sourceRows));put(receipt,"memory_accounting",s("Native Point vector capacity only; excludes allocator, row-string heaps, Tcl input objects and painter display lists"));
put(receipt,"native_presentation",m.presentation.p?m.presentation.p:Tcl_NewDictObj());put(receipt,"axes",axisReceipts);put(receipt,"legends",legendReceipts);put(receipt,"width",Tcl_NewIntObj(m.width));put(receipt,"height",Tcl_NewIntObj(m.height));put(receipt,"revision",Tcl_NewWideIntObj(m.revision));put(receipt,"owner",s("Native2D.C++.PlotDataset.v4"));put(receipt,"hit_geometry_owner",s("Same Native2D painter display list; exact point identities have priority"));m.receipt=Ref(receipt);m.hitPrimitives=Ref(out);m.drawRevision=m.revision;auto result=Tcl_NewDictObj();put(result,"primitives",out);put(result,"receipt",receipt);return result;}
double segmentDistance(double x,double y,double ax,double ay,double bx,double by){double dx=bx-ax,dy=by-ay,den=dx*dx+dy*dy,t=den?std::clamp(((x-ax)*dx+(y-ay)*dy)/den,0.,1.):0.;return std::hypot(x-ax-t*dx,y-ay-t*dy);}
bool paintedHit(Model&m,Tcl_Obj*d,double x,double y){
 auto xy=doubles(m.ip,d,"coords"),clip=doubles(m.ip,d,"clip");if(xy.size()<2||number(m.ip,d,"opacity",1)<=0)return false;
 if(clip.size()==4&&(x<clip[0]||y<clip[1]||x>clip[2]||y>clip[3]))return false;
 auto type=text(m.ip,d,"type"),stroke=text(m.ip,d,"stroke"),fill=text(m.ip,d,"fill");bool hasStroke=!stroke.empty()&&stroke!="none",hasFill=!fill.empty()&&fill!="none";double tolerance=std::max(3.,number(m.ip,d,"width",1)/2+2);
 if(type=="text"&&text(m.ip,d,"text_engine")=="PangoCairo") {auto size=doubles(m.ip,d,"text_layout_size");if(size.size()!=2)return false;bool nw=text(m.ip,d,"anchor","center")=="nw";double left=xy[0]-(nw?0:size[0]/2),top=xy[1]-(nw?0:size[1]/2);return x>=left-2&&x<=left+size[0]+2&&y>=top-2&&y<=top+size[1]+2;}
 if(type=="text") {if(!hasStroke||text(m.ip,d,"text").empty())return false;auto surface=cairo_image_surface_create(CAIRO_FORMAT_A8,1,1);auto cr=cairo_create(surface);cairo_select_font_face(cr,text(m.ip,d,"font_family","sans").c_str(),CAIRO_FONT_SLANT_NORMAL,CAIRO_FONT_WEIGHT_NORMAL);cairo_set_font_size(cr,number(m.ip,d,"font_size",12));cairo_text_extents_t ex;cairo_text_extents(cr,text(m.ip,d,"text").c_str(),&ex);cairo_destroy(cr);cairo_surface_destroy(surface);double angle=number(m.ip,d,"angle",0)*3.141592653589793/180.,dx=x-xy[0],dy=y-xy[1],lx=cos(angle)*dx-sin(angle)*dy,ly=sin(angle)*dx+cos(angle)*dy;bool nw=text(m.ip,d,"anchor","center")=="nw";double left=(nw?0:-ex.x_advance/2)+ex.x_bearing,top=(nw?-ex.y_bearing:-ex.y_bearing/2)+ex.y_bearing;return lx>=left-2&&lx<=left+ex.width+2&&ly>=top-2&&ly<=top+ex.height+2;}
 if(type=="rectangle"&&xy.size()==4){double l=std::min(xy[0],xy[2]),r=std::max(xy[0],xy[2]),t=std::min(xy[1],xy[3]),b=std::max(xy[1],xy[3]);if(text(m.ip,d,"hit_kind")=="panel")return x>=l&&x<=r&&y>=t&&y<=b;if(hasFill&&x>=l&&x<=r&&y>=t&&y<=b)return true;return hasStroke&&std::min({segmentDistance(x,y,l,t,r,t),segmentDistance(x,y,r,t,r,b),segmentDistance(x,y,r,b,l,b),segmentDistance(x,y,l,b,l,t)})<=tolerance;}
 if(type=="oval"&&xy.size()==4){double rx=std::abs(xy[2]-xy[0])/2,ry=std::abs(xy[3]-xy[1])/2;if(rx<=0||ry<=0)return false;double norm=std::hypot((x-(xy[0]+xy[2])/2)/rx,(y-(xy[1]+xy[3])/2)/ry);return hasFill?norm<=1:hasStroke&&std::abs(norm-1)*std::min(rx,ry)<=tolerance;}
 if(type=="polygon"&&hasFill){bool inside=false;size_t count=xy.size()/2;for(size_t i=0,j=count-1;i<count;j=i++){double xi=xy[2*i],yi=xy[2*i+1],xj=xy[2*j],yj=xy[2*j+1];if((yi>y)!=(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi)inside=!inside;}if(inside)return true;if(text(m.ip,d,"hit_kind")=="cell"){for(size_t i=0,j=count-1;i<count;j=i++)if(segmentDistance(x,y,xy[2*j],xy[2*j+1],xy[2*i],xy[2*i+1])<=1e-7)return true;return false;}}
 if(hasStroke){for(size_t i=2;i+1<xy.size();i+=2)if(segmentDistance(x,y,xy[i-2],xy[i-1],xy[i],xy[i+1])<=tolerance)return true;if(type=="polygon"&&xy.size()>=6&&segmentDistance(x,y,xy[0],xy[1],xy[xy.size()-2],xy.back())<=tolerance)return true;}return false;
}
Tcl_Obj*hit(Model&m,double x,double y){auto out=Tcl_NewDictObj();put(out,"hit",Tcl_NewIntObj(0));if(!std::isfinite(x)||!std::isfinite(y)||!m.hitPrimitives.p||m.drawRevision!=m.revision)return out;
 double best=64;for(auto&p:m.panels)for(auto&q:p.series)if(q.visible&&q.opacity>0)for(auto&pt:q.points){double d=pow(pt.deviceX-x,2)+pow(pt.deviceY-y,2);if(d<best&&pt.deviceX>=p.left&&pt.deviceX<=p.right&&pt.deviceY>=p.top&&pt.deviceY<=p.bottom){best=d;Tcl_SetStringObj(out,"",0);put(out,"hit",Tcl_NewIntObj(1));put(out,"kind",s("point"));put(out,"object_kind",s("point"));put(out,"panel_id",s(p.id));put(out,"series_id",s(q.id));put(out,"source_series_id",s(text(m.ip,q.original.p,"source_series_id",q.id)));put(out,"point_identity_kind",s(pt.row.empty()?"derived_statistic":"source_row"));if(!pt.row.empty())put(out,"source_row_ordinal",s(pt.row));put(out,"x",num(pt.x));put(out,"y",num(pt.y));put(out,"distance_pixels",num(sqrt(d)));}}if(best<64)return out;
 int priority=-1;for(auto d:list(m.ip,m.hitPrimitives.p)){auto kind=text(m.ip,d,"hit_kind");if(kind.empty()||get(m.ip,d,"grid_kind")||!paintedHit(m,d,x,y))continue;int rank=kind=="chart"?0:kind=="panel"?1:kind=="axis"?3:kind=="series"?5:kind=="annotation"?text(m.ip,d,"type")=="rectangle"?2:6:7;if(rank<priority)continue;priority=rank;Tcl_SetStringObj(out,"",0);put(out,"hit",Tcl_NewIntObj(1));put(out,"kind",s(kind));put(out,"object_kind",s(kind));put(out,"object_id",s(text(m.ip,d,"hit_id")));for(auto names:{std::pair<const char*,const char*>{"hit_panel_id","panel_id"},{"hit_axis","axis"},{"hit_series_id","series_id"}}){auto v=get(m.ip,d,names.first);if(v)put(out,names.second,v);}if(kind=="cell")for(auto key:{"cell_id","source_row_ordinal","value","dataset_id","mesh_dataset_id","scalar_variable_id","scalar_unit"}){auto v=get(m.ip,d,key);if(v)put(out,key,v);}}
 // Axis spines are the actual shared panel border, not arbitrary viewport fractions.
 if(priority<3)for(auto&p:m.panels)if(x>=p.left-3&&x<=p.right+3&&y>=p.top-3&&y<=p.bottom+3){std::string axis;if(std::abs(x-p.left)<=3)axis="left";if(std::abs(y-p.bottom)<=3)axis="x";if(std::abs(x-p.right)<=3)for(auto&q:p.series)if(q.axis=="right")axis="right";if(!axis.empty()){Tcl_SetStringObj(out,"",0);put(out,"hit",Tcl_NewIntObj(1));put(out,"kind",s("axis"));put(out,"object_kind",s("axis"));put(out,"object_id",s(axis));put(out,"panel_id",s(p.id));put(out,"axis",s(axis));}}
 return out;
}
Tcl_Obj*distribution(Tcl_Interp*ip,Tcl_Obj*request){std::ifstream in(text(ip,request,"xy_file"),std::ios::binary);if(!in)throw std::runtime_error("Exact numerical input resource is unavailable");std::vector<double>sample,xSample;double pair[2];double scale=number(ip,request,"scale",1),offset=number(ip,request,"offset",0);while(in.read(reinterpret_cast<char*>(pair),16)){double y=pair[1]*scale+offset;if(std::isfinite(y)){sample.push_back(y);xSample.push_back(pair[0]);}}if(!in.eof())throw std::runtime_error("Incomplete exact numerical input");if(sample.empty())throw std::runtime_error("Distribution has no finite source samples");auto out=Tcl_NewDictObj();auto points=Tcl_NewListObj(0,nullptr);auto rows=Tcl_NewListObj(0,nullptr);auto emit=[&](double x,double y){Tcl_Obj*a[2]={num(x),num(y)};Tcl_ListObjAppendElement(nullptr,points,Tcl_NewListObj(2,a));};std::sort(sample.begin(),sample.end());std::string kind=text(ip,request,"kind");if(kind=="bar_width"){std::sort(xSample.begin(),xSample.end());double spacing=INFINITY;for(size_t i=1;i<xSample.size();++i)if(xSample[i]>xSample[i-1])spacing=std::min(spacing,xSample[i]-xSample[i-1]);if(!std::isfinite(spacing))spacing=1;put(out,"bar_width",num(spacing*number(ip,request,"bar_width",.8)*std::abs(number(ip,request,"x_scale",1))));return out;}double lo=sample.front(),hi=sample.back();put(out,"point_identity_kind",s("derived_statistic"));put(out,"sample_count",Tcl_NewWideIntObj(sample.size()));if(kind=="histogram"){int bins=int(number(ip,request,"histogram_bins",std::max(5.,std::min(100.,ceil(sqrt(double(sample.size())))))));bins=std::max(2,std::min(512,bins));if(lo==hi){double pad=std::max(.5,std::abs(lo)*.05);lo-=pad;hi+=pad;}double step=(hi-lo)/bins;std::vector<double>counts(bins,0),lower,upper;for(double x:sample)++counts[std::max(0,std::min(bins-1,int((x-lo)/step)))];auto norm=text(ip,request,"histogram_normalization","count");double factor=norm=="probability"?1./sample.size():norm=="density"?1./(sample.size()*step):1;double highest=0;for(int i=0;i<bins;++i){double h=counts[i]*factor;emit(lo+(i+.5)*step,h);lower.push_back(lo+i*step);upper.push_back(lo+(i+1)*step);highest=std::max(highest,h);}put(out,"lower",values(lower));put(out,"upper",values(upper));put(out,"bar_width",num(step));put(out,"full_bounds",values({lo,0,hi,highest}));}else{auto q=[&](double p){double pos=(sample.size()-1)*p;size_t low=floor(pos),high=ceil(pos);return sample[low]+(pos-low)*(sample[high]-sample[low]);};double q1=q(.25),med=q(.5),q3=q(.75),mult=number(ip,request,"box_whisker_iqr",1.5);auto low=std::lower_bound(sample.begin(),sample.end(),q1-mult*(q3-q1)),high=std::upper_bound(sample.begin(),sample.end(),q3+mult*(q3-q1));double wlo=low==sample.end()?lo:*low,whi=high==sample.begin()?hi:*(high-1);double position=number(ip,request,"position",1);emit(position,med);put(out,"lower",values({q1}));put(out,"upper",values({q3}));put(out,"y_lower",values({wlo}));put(out,"y_upper",values({whi}));put(out,"bar_width",num(.56));auto outliers=Tcl_NewListObj(0,nullptr);if(text(ip,request,"box_show_outliers","1")!="0")for(double y:sample)if(y<wlo||y>whi){Tcl_Obj*a[2]={num(position),num(y)};Tcl_ListObjAppendElement(nullptr,outliers,Tcl_NewListObj(2,a));}put(out,"outliers",outliers);put(out,"full_bounds",values({position-.4,lo,position+.4,hi}));}put(out,"points",points);put(out,"source_rows",rows);put(out,"scientific_sample_count",Tcl_NewWideIntObj(sample.size()));return out;}
void cleanup(ClientData d,Tcl_Interp*){delete(State*)d;}
int command(ClientData data,Tcl_Interp*ip,int n,Tcl_Obj*const v[]){auto state=(State*)data;try{if(n<2)throw std::runtime_error("Expected native Plot operation");std::string op=Tcl_GetString(v[1]);if(op=="api_info"){auto out=Tcl_NewDictObj();put(out,"api_id",s("NATIVE_PLOT_BACKEND_v1"));put(out,"api_version",Tcl_NewIntObj(1));put(out,"plot_api_version",Tcl_NewIntObj(4));put(out,"capabilities",s("comparison_shared_x_interaction atomic_view_state atomic_shared_x_restore requested_axis_limits"));Tcl_SetObjResult(ip,out);return TCL_OK;}if(op=="distribution"){if(n!=3)throw std::runtime_error("Expected exact distribution input");Tcl_SetObjResult(ip,distribution(ip,v[2]));return TCL_OK;}if(op=="create"){if(n!=3)throw std::runtime_error("Usage: plot_v4 create model");std::string id="native-plot-v4#"+std::to_string(++state->serial);state->models[id]=parse(ip,v[2]);Tcl_SetObjResult(ip,s(id));return TCL_OK;}if(n<3)throw std::runtime_error("Expected native Plot model token");std::string token=Tcl_GetString(v[2]);auto it=state->models.find(token);if(it==state->models.end())throw std::runtime_error("Unknown or destroyed native Plot model");auto&m=*it->second;if(op=="destroy"){state->models.erase(it);return TCL_OK;}if(op=="visibility"){int visible;if(n!=6||Tcl_GetBooleanFromObj(ip,v[5],&visible)!=TCL_OK)throw std::runtime_error("Expected panel ID, series ID and boolean visibility");for(auto&p:m.panels)if(p.id==Tcl_GetString(v[3]))for(auto&q:p.series)if(q.id==Tcl_GetString(v[4])){q.visible=visible;++m.revision;return TCL_OK;}throw std::runtime_error("Unknown retained series identity");}if(op=="configure"){if(n!=4)throw std::runtime_error("Expected replacement model");auto next=parse(ip,v[3]);next->revision=m.revision+1;it->second=std::move(next);return TCL_OK;}if(op=="draw"){int w,h;if(n!=5||Tcl_GetIntFromObj(ip,v[3],&w)!=TCL_OK||Tcl_GetIntFromObj(ip,v[4],&h)!=TCL_OK)throw std::runtime_error("Expected width and height");Tcl_SetObjResult(ip,draw(m,w,h));return TCL_OK;}if(op=="receipt"){if(m.receipt.p)Tcl_SetObjResult(ip,m.receipt.p);return TCL_OK;}if(op=="hit"){if(n!=5)throw std::runtime_error("Expected device X and Y");Tcl_SetObjResult(ip,hit(m,value(ip,v[3]),value(ip,v[4])));return TCL_OK;}if(op=="fit"){fit(m);++m.revision;return TCL_OK;}if(op=="restore"){if(n!=4)throw std::runtime_error("Expected receipt axis view state");struct Change{Axis*a;double lo,hi;};std::vector<Change>changes;std::set<Axis*>seen;for(auto item:list(ip,v[3])){std::string panel=text(ip,item,"panel_id"),name=text(ip,item,"axis");Axis*a=nullptr;for(auto&p:m.panels)if(p.id==panel){a=name=="x"?&p.x:name=="left"?&p.y:name=="right"?&p.r:nullptr;break;}if(!a||!seen.insert(a).second)throw std::runtime_error("Unknown or duplicate restored axis identity");if(text(ip,item,"scale",a->log?"log":"linear")!=(a->log?"log":"linear")||text(ip,item,"direction",a->reverse?"reverse":"normal")!=(a->reverse?"reverse":"normal"))throw std::runtime_error("Restored view axis scale or direction changed");auto range=doubles(ip,item,"limits");if(range.size()!=2||!std::isfinite(range[0])||!std::isfinite(range[1])||!(range[1]>range[0])||!std::isfinite(a->transform(range[0]))||!std::isfinite(a->transform(range[1])))throw std::runtime_error("Invalid restored axis limits");changes.push_back({a,range[0],range[1]});}if(changes.empty())throw std::runtime_error("Restored view state contains no axes");
if(m.sharedXInteractive){
 Axis* shared=nullptr;double low=0,high=0;
 for(const auto&c:changes)for(auto&p:m.panels)if(c.a==&p.x){
  if(shared&&(c.lo!=low||c.hi!=high))throw std::runtime_error("Restored shared X panel ranges conflict");
  shared=c.a;low=c.lo;high=c.hi;
 }
 if(shared){
  for(auto&p:m.panels)if(p.x.log!=shared->log||p.x.reverse!=shared->reverse)throw std::runtime_error("Restored shared X scales or directions conflict");
  for(auto&p:m.panels)if(!seen.count(&p.x))changes.push_back({&p.x,low,high});
 }
}
for(auto&c:changes){c.a->lo=c.lo;c.a->hi=c.hi;}for(auto&p:m.panels)p.aspectApplied=false;++m.revision;return TCL_OK;}if(op=="view"){
 if(n<5)throw std::runtime_error("Expected panel ID and zoom/pan/limits");
 std::string id=Tcl_GetString(v[3]),action=Tcl_GetString(v[4]);
 for(auto&p:m.panels)if(p.id==id){
  // Stage every range; invalid operations preserve the last valid frame.
  Axis nx=p.x,ny=p.y,nr=p.r;
  if(action=="limits"&&n==9){nx.lo=value(ip,v[5]);nx.hi=value(ip,v[6]);ny.lo=value(ip,v[7]);ny.hi=value(ip,v[8]);}
  else if(action=="zoom"&&n==8){
   double f=value(ip,v[5]),fx=value(ip,v[6]),fy=value(ip,v[7]);
   if(!(f>0&&std::isfinite(f)&&std::isfinite(fx)&&std::isfinite(fy)))throw std::runtime_error("Invalid zoom factor or anchor");
   for(auto axis:{&nx,&ny,&nr}){double lo=axis->transform(axis->lo),hi=axis->transform(axis->hi),anchor=lo+(hi-lo)*(axis==&nx?fx:fy);axis->lo=axis->inv(anchor+(lo-anchor)/f);axis->hi=axis->inv(anchor+(hi-anchor)/f);}
  }else if(action=="pan"&&n==7){
   double dx=value(ip,v[5]),dy=value(ip,v[6]);
   if(!std::isfinite(dx)||!std::isfinite(dy))throw std::runtime_error("Invalid pan displacement");
   for(auto axis:{&nx,&ny,&nr}){double lo=axis->transform(axis->lo),hi=axis->transform(axis->hi),shift=(hi-lo)*(axis==&nx?dx:dy);axis->lo=axis->inv(lo+shift);axis->hi=axis->inv(hi+shift);}
  }else throw std::runtime_error("Invalid native Plot view operation");
  for(auto axis:{&nx,&ny,&nr})if(!(axis->hi>axis->lo)||!std::isfinite(axis->lo)||!std::isfinite(axis->hi)||!std::isfinite(axis->transform(axis->lo))||!std::isfinite(axis->transform(axis->hi)))throw std::runtime_error("Invalid viewport range");
  if(m.sharedXInteractive)for(auto&other:m.panels)if(other.x.log!=nx.log||other.x.reverse!=nx.reverse)throw std::runtime_error("Shared X panels have conflicting axis scales or direction");
  p.x=nx;p.y=ny;p.r=nr;p.aspectApplied=false;
  if(m.sharedXInteractive)for(auto&other:m.panels){other.x.lo=nx.lo;other.x.hi=nx.hi;other.aspectApplied=false;}
  ++m.revision;return TCL_OK;
 }
 throw std::runtime_error("Unknown panel identity");
}throw std::runtime_error("Unknown native Plot operation");}catch(const std::exception&e){Tcl_SetObjResult(ip,s(e.what()));Tcl_SetErrorCode(ip,"GXTXT","PlotDatasetV4","NativeModel",nullptr);return TCL_ERROR;}}
}
extern "C" int gx2d_plot_v4_init(Tcl_Interp*ip){auto state=new State;Tcl_SetAssocData(ip,"gx2d.plot.v4",cleanup,state);Tcl_CreateObjCommand(ip,"::gx::native2d::plot_v4",command,state,nullptr);return TCL_OK;}
