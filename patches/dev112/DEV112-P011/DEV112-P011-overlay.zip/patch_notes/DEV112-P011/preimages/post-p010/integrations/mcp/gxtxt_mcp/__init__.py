"""Optional authenticated MCP transport for an existing GX-TXT installation."""
__version__ = '0.1.0'
SDK_VERSION = '2.3.0'
PROTOCOL_VERSION = '2025-11-25'
