# P011 owner handoff

MAIN develops only its isolated P011 scratch checkout from accepted deposited
P010. GUI remains Terra6.1 Medium, Technical Sol6.1 Low, Scientific Sol6.1 High
and MAIN Sol6.1 High. Required GUI/Technical child evidence is retained. Historical
P009/P010 deposits, active installation, real Sessions, ORION and SII are unchanged.

R01 uses common Analysis eligibility and source-only public preflight, then
associates status with the actual admitted Run Job and terminal publication.
R02 uses public Plot v4 native2D/native3D draft owners and explicit Graph/Variant
publication. Workspace Save does not publish. Version1 Workspaces open read-only
and require explicit supported conversion into a new Document. Unsupported
legacy transforms and detached derived comparisons fail with a precise reason.
R03 uses CORE History auxiliary journals for presentation, full scientific fit
receipts for operations, and four result/diagnostic tabs. Repeated identical
ordinary GUI Preview reuses its successful receipt after live identity checks;
explicit Recompute and public preview retain solver execution.
Native3D figure margins use declared text bands. Explicit margins, camera,
numeric aspect, topology, physical units and canonical values remain authoritative.
R04 adapter0.2.0 negotiates actual public Bridge metadata/runtime contracts.
P009/P010/P011 and future compatible framework identifiers are accepted through
capabilities. MCP SDK/protocol admission remains separate. Authentication, exact
Session grants, resource ownership, approved source and public API restrictions
are preserved. See integrations/mcp/README.md.

The accompanying release validation records define the exact accepted source,
package and independent role decisions. Candidate-specific records retain original
failures and scoped retests; author probes are not independent acceptance. Final
GUI, scientific/API, source/catalog and installed/rollback gates must pass before
deposition. Screen-reader compatibility is explicitly NOT TESTED. The source TODO
lists unfinished product verification; operational release gates remain in the
accompanying MAIN plan, matrices and coordination records.

Final delivery, when accepted, must include complete source/inventory, binary
patch/preimages, reversible installer, adapter package/source/lock, English
documentation, exact independent evidence and SHA-256 checksums at the owner
specified release destination. Do not install or activate without owner approval.

One technical diagnostic initially omitted its private catalog storage setting
and created one temporary owned snapshot outside scratch. The exact dead-owner
UUID was inspected and removed through the original public cleanup API; the
initial record and corrected private run remain evidence. No user Session,
canonical Dataset, active installation or client credential was modified.
This exception is disclosed rather than claiming zero outside-scratch writes.
